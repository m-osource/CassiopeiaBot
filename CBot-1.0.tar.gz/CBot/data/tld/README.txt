
CBOT data about top-level domain sizes.
This data can be obtained from:

 http://www.isc.org/index.pl?/ops/ds/
