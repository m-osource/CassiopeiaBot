/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include <config.h>

// System libraries

#include <iostream>
#include <assert.h>
#include <string.h> 
#include <stdlib.h>
#include <limits.h>

// Local libraries

#include "const.h"
#include "server.h"
#include "Entity.h"

const short PENUMCOLS = 20;
const short PENUMROWS = 20;
const unsigned short PENUMUCOLS = 20;
const unsigned short PENUMUROWS = 30;

const char dictionary_url [PENUMUROWS] [PENUMUCOLS] =
{{'c','g','i'},
{'h','t','m','*'},
{'h','o','m','e','*'},
{'s','i','t','o'},
{'i','m','s','i','t','e','*'},
{'c','o','n','t','*'},
{'p','a','g','e','*'},
{'i','n','d','e','x','*'},
{'e','x','p','o','r','t','*'},
{'d','e','f','a','u','l','t','*'},
{'l','e','f','t','*'},
{'p','a','g','e','*'},
{'p','a','g','i','n','*'},
{'p','h','p'},
{'a','s','p'},
{'s','i','n','i','s','t','r','a'},
{'s','e','r','v','l','e','t','*'},
{'s','i','t','e','*'},
{'d','o','w','n'},
{'r','i','g','h','t','*'},
{'d','e','s','t','r','a'}};

/*
 * E' vivamente consigliato dichiarare le constanti nell'header (dunque prima del main) in quanto se dichiarate dopo il main anche attraverso funzioni che
 * poi le esportano tramite puntatori possono crearsi problemi sulla lettura delle stesse.
 * Nel test precedente ad un certo punto i dati della constante di un array di struct entity, esportata tramite puntatore non restituiva tutti i dati dell'array
 * corretti, come se ad un certo punto ci fosse un problema di memoria corrotta.
 */

// N.B. La rimozione dei commenti html viene effettata del parser del crawler

#define HEADINGSINCONTENT true // 1 se si desidera che il contenuto dei tag headings (<h1>..<h6>) siano inseriti nel testo della pagina (opzione consigliabile)
#define MAXENTITIES 253

using namespace std;

Entities et;

const short PENUMSPACES = 18; // numero massimo di spazi consentiti all'interno dei tag (N.B. Il numero effettivo di spazi corrisponde a PENUMSPACES meno
			    // i caratteri in: 'meta,name,=' (che sono 9), perciò gli spazi di tolleranza sono PENUMSPACES - 9)
const short EBNUL = 8; // entity by num length
const short EBHUL = 9; // entity by hex length
const short EBALL = 12; // entity by alphabetical length
const char title_x_func[6] = {'T','t','i','t','l','e'};
const char dictionary_mtags [PENUMROWS] [PENUMCOLS] =
{{'D','d','e','s','c','r','i','p','t','i','o','n'},
{'K','k','e','y','w','o','r','d','s'},
{'M','c','b','o','t','l','o','c','m','o','n'}}; // tell us a local monetary as 'sardex'
const char body_x_func[5] = {'B','b','o','d','y'};
const char noframes_x_func[9] = {'F','n','o','f','r','a','m','e','s'};
const char dictionary_tags [PENUMROWS] [PENUMCOLS] =
{{'A','t','a','b','l','e'},
{'A','t','d'},
{'A','d','i','v'},
{'N','s','p','a','n'},
{'B','b','o','d','y'},
{'H','h','1'},
{'H','h','2'},
{'H','h','3'},
{'H','h','4'},
{'H','h','5'},
{'H','h','6'},
{'S','s','t','r','o','n','g'},
{'P','b','r'},
{'L','a'}, 
{'P','p'},
{'R','s','c','r','i','p','t'},
{'R','s','e','l','e','c','t'},
{'R','l','a','b','e','l'},
{'R','d','t'}, // definition term. Definition list al momento viene inclusa
//{'R','f','o','r','m'}, // meglio non controllarlo perchè potrebbe anche escludere molto testo a seconda di come è stato progettato il sito (probabilmente male)
{'R','n','o','s','c','r','i','p','t'}};
// A = indica che occorre sostituire il tag finale con un carattere newline
// N = nessuna interpretazione, tranne se si deve escludere il contenuto tra i tags
// R = indica che occorre rimuovere il contenuto tra i tag (anche per tag annidati)
// T = indica che occorre ricavare il testo tra i tag
// L = indica che occorre ricavare il testo tra i tags
// N.B. I Tag elaborati da 'parser_extended' non devono essere preservati nel file di configurazione
// Cerca un termine in un file di testo e ne restituisce la posizione
//  supporta i tag scritti nel modo <title> o <    title>

enum entity_status_t {
	ENTITY_ERROR		= 0, // entità trovata ma lo spazio disponibile per ospitare la sua conversione non è sufficiente
	ENTITY_FOUND		= 1, // entità trovata e convertità in caratteri a byte singolo o multiplo, dalla funzione convEntity
	ENTITY_IGNORED		= 2, // entità che appartiene ad una serie entità relative a caratteri speciali che non devono essere convertite
	ENTITY_NOT_FOUND	= 3  // entità non trovata
};

struct entity
{
	unsigned int specialch[4]; //all'interno risiede il cast di 4 wchar_t (utf-16) (4 interi unsigned cioè 16 byte)
	char entitybynumber[EBNUL];
	char entitybyhex[EBHUL]; // - mar 10 mar 2015, 18.52.08, CET
	char entitybyname[EBALL];
};

off64_t htmlParser( server_t *, char *, instance_t );

entity_status_t convEntity( char *, unsigned int &, off64_t, char [], unsigned int & );
char searchTitleTag( char &, int & );
char searchBodyTag( char &, int & );
char searchNoFramesTag( char &, int & );
char searchMetaTags( char *, off64_t &, const char [PENUMROWS][PENUMCOLS], unsigned short &, char &, int &, unsigned int &, unsigned short [] );
char scanTags( char **, const char [PENUMROWS][PENUMCOLS], unsigned short &, char &, int &, bool &, unsigned short [] );
char scanHibernate( char **, char &, int &, bool &, unsigned short [] );
void pulloutMeta ( char *, char [], unsigned int &, const unsigned short & );
void pulloutLocalMonetary ( char *, pes_t::lmon_t &, unsigned int &, const unsigned short & );
bool stylePropDisplayCheck ( char *, off64_t &, unsigned int & );
bool checkChar ( unsigned int c, char d, char s );
