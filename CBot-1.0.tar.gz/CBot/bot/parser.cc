/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "parser.h"

extern Entities et;

perfhash_t keep_tag;       // HTML elements keepd
perfhash_t keep_attribute; // HTML attrs keepd
perfhash_t accept_protocol; // Protocols to accept 
perfhash_t keep_special;    // Special domains keepd (see domainid) 
perfhash_t discard_content;    // Elements whose content is discarded
perfhash_t extensions_ignore;  // Extensions to ignore
perfhash_t extensions_log;     // Extensions to log, but not to download
perfhash_t extensions_stat;    // Extensions to count, but neither log nor download
perfhash_t extensions_dynamic; //
string_list_t *domain_suffixes; // List of admitted domains

map <string,bool> is_link;            // Elements that define a link
map <string,bool> is_link_with_content; // Attributes that define a link with the caption being the content
map <string,string> link_attribute;     // Attributes that define a link
map <string,string> link_caption;       // Attributes that define the caption for a link
map <string,docid_t> count_extensions_stat;   // For gathering statistics

regex_t reject_patterns;

regex_t sessionid_patterns;
char **sessionid_variables              = NULL;
int sessionid_variables_count   = 0;

// We want reserve a small space at the begin of href to insert protocol if needed
thread_local const static unsigned char reserve = strlen("https://");

//
// Name: parser_process
//
// Descriptions:
//   Parses a document
//
// Input:
//   doc - the document to be parsed
//   inbuf - text of the document
// 
// Return:
//   new content_length of the document
//

off64_t parser_process(starter_t *starter, siteid_t serverid, char *inbuf, char *report, int &rwritten, size_t &rspace)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);
	instance_t inst = starter->inst;

	doc_t *doc = server->pages->doc;

	assert(doc != NULL);
	assert(doc->docid != 0);
	assert(doc->raw_content_length > 0);

	assert(inbuf != NULL);

	char *outbuf = server->pages->buffer_two;
	assert(outbuf != NULL);

	off64_t content_length = 0;

	string path = server->pages->path;
	string site = server->hostname;

	// Socket used by eipm module
	char *SOCKET_PATH = NULL;
	const double socket_timeout = 2.00;

	off64_t ret = 0;

	// Nel caso 'server->pages->src_path' contenga la copia originale di 'server->pages->path',
	// in questo caso ènecessario verificare che il nuovo PATH inserito in 'server->pages->path'
	// attraverso i redirects, rispetti lo standard prima di essere processato.
	if (server->pages->src_path != NULL && strlen(server->pages->src_path) > 0)
	{
		// Reject certains hrefs
		if (regexec(&reject_patterns, server->pages->path, 0, NULL, 0) == 0)
				server->pages->redirect_with_invalid_path = true;

		// Remove sessionids in URLs
		if (regexec(&sessionid_patterns, server->pages->path, 0, NULL, 0) == 0) {
			for(int i=0; i<sessionid_variables_count; i++) {
				url->remove_variable(server->pages->path, sessionid_variables[i]);
			}
		}

		// Remove sessionids, heuristic
		url->remove_sessionids_heuristic(server->pages->path);
	}

	char *lsip = strrchr(server->pages->path, ASCII_SL); // Last Slash In Path

	if (lsip != NULL)
	{
		size_t len = (lsip - server->pages->path + 1);
		partial_path[inst] = CBALLOC(char, MALLOC, (len + 1));
		strncpy(partial_path[inst], server->pages->path, len); // se www.sito.it/it/lista/polo.pl -> 'it/lista'
		partial_path[inst][len] = ASCII_NUL;
	}
	else
		partial_path[inst] = NULL;

	// detect the type of document with libmagic
	const char *magic_mime_type = magic_buffer(starter->m_cookie, inbuf, doc->raw_content_length);

//	mime_type_t doc_magic_mime_type = meta->mime_type(NULL, (char *)magic_mime_type);

//	cout << LRE << server->pages->path << ' ' <<  magic_mime_type << ' ' << meta->mime_type(NULL, (char *)magic_mime_type) << NOR << endl;	

	// Select the parser
	switch(doc->mime_type) {
		case MIME_TEXT_HTML:

			// Verifica se il mime type dichiarato nell'header del server non corrisponde a quello reale del buffer
			if (doc->mime_type != meta->mime_type(NULL, (char *)magic_mime_type))
			{
				ret = 0;
				break;
			}

			// Html documents
			// Assegno al buffer la memoria necessaria per contenere i links scaricati e relativi logs (delle pagine nuove o aggiornate)
			// Verranno inseriti solo quando le pagine risultano nuove o "realmente" modificate (verifica attraverso le variazioni del testo (LSH))
			server->pages->bld_size = (server->pages->doc->raw_content_length / 2);
			server->pages->buffer_links_download = CBALLOC(char, MALLOC, (server->pages->bld_size + 1));
			assert (server->pages->buffer_links_download != NULL);
			server->pages->buffer_links_download[0] = ASCII_NUL;
			server->pages->bld_offset = 0;
			server->pages->bll_size = (server->pages->doc->raw_content_length / 2);
			server->pages->buffer_links_log = CBALLOC(char, MALLOC, (server->pages->bll_size + 1));
			assert (server->pages->buffer_links_log != NULL);
			server->pages->buffer_links_log[0] = ASCII_NUL;
			server->pages->bll_offset = 0;

			// Esegue il parsing parziale del contenuto html
			doc->raw_content_length = parser_process_html(starter, serverid, inbuf, report, rwritten, rspace); // Update raw_content_length

			if (doc->raw_content_length == 0)
			{
				ret = 0;
				break;
			}

			if (starter->testing == false)
			{
				instance_t linkidx_section = ((server->pages->doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);

				// Save current starter->adjacency list if the list has elements but only if they are all already found inside collection.
				// else the saving of adjacency list must be done by seeder WITHOUT save the relative hashing (changed only from parser)
				if (adjacency_list_new_link[inst] == false)
				{
					if (adjacency_list_length[inst] > 0)
					{
						if (server->pages->doc->hash_value_links == CONF_HASH_DOC_MAX_DEFINITIVE)
						{
							parser_lock_linkidx(linkidx_section);

							// Previous stored adjacency list is not equal to the new and It has element to save
							if (parser_compare_adjacency_list(linkidx_section, server->pages->doc, adjacency_list[inst], adjacency_list_length[inst]) == 0)
								parser_save_links(server->pages->doc, adjacency_list[inst], adjacency_list_length[inst]);

							parser_unlock_linkidx(linkidx_section);

							// Once saved adjacency_list, then save corrispondent hash.
							server->pages->doc->hash_value_links = parser_hash_adjacency_list(adjacency_list_length[inst], adjacency_list[inst]);

						}
						else
						{
							doc_hash_t newhash_value_links = parser_hash_adjacency_list(adjacency_list_length[inst], adjacency_list[inst]);

							// note that if hash is present, byte comparison is skipped for adjacency list comparison
							if (server->pages->doc->hash_value_links != newhash_value_links)
							{
								parser_lock_linkidx(linkidx_section);

								// It has elements, save
								parser_save_links(server->pages->doc, adjacency_list[inst], adjacency_list_length[inst]);

								parser_unlock_linkidx(linkidx_section);

								// Once saved adjacency_list, then save corrispondent hash.
								server->pages->doc->hash_value_links = newhash_value_links;
							}
						}
					}
				}
				else // If new links are present in the page, the saving of adjaceny must be done by seeder.
					server->pages->doc->hash_value_links = CONF_HASH_DOC_MAX_DEFINITIVE;
			}

			free (server->pages->buffer_one);

			// a questo punto si procede ad estrarre il testo PURO dal codice html restante.
			// Esegue lo 'swap' della memoria:
			server->pages->buffer_one = server->pages->buffer_two;
			server->pages->bo_size = server->pages->bt_size;
			server->pages->buffer_two = NULL;
			server->pages->buffer_two = (char *) malloc ((server->pages->bt_size + 1) * sizeof(char));
			assert (server->pages->buffer_two != NULL);
			server->pages->buffer_two[0] = ASCII_NUL;
			inbuf = server->pages->buffer_one;

			ret = htmlParser(server, inbuf, inst);

			if (ret <= HTMLMETAPREFIXSIZE)
			{
				ret = 0;
				break;
			}
			else
			{
				unsigned short c = 0;
				for (unsigned char i = 0; i < HTMLMETAPREFIXSIZE; i++)
					c += ((int)server->pages->buffer_two[i] + CHAR_MAX);
					
				if (ret < (c + HTMLMETAPREFIXSIZE))
				{
					ret = 0;
					break;
				}
			}

			break;

		case MIME_ROBOTS_TXT:

			// Verifica se il mime type dichiarato nell'header del server corrisponde a quello reale del buffer
			if (MIME_TEXT_PLAIN == meta->mime_type(NULL, (char *)magic_mime_type))
				ret = parser_process_robotstxt(starter, serverid, inbuf); // Robots exclusion protocol

			break;

		case MIME_ROBOTS_RDF:

			// Verifica se il mime type dichiarato nell'header del server corrisponde a quello reale del buffer
			if (MIME_TEXT_XML == meta->mime_type(NULL, (char *)magic_mime_type))
				ret = parser_process_robotsrdf(starter, serverid, inbuf, report, rwritten, rspace); // Robots site summary

			break;

		case MIME_ROBOTS_RDF_BROKEN:
			// sitemap rdf documents
			break;

		case MIME_ROBOTS_XML:

			// Robots site summary - sitemap
			if (server->pages->src_path == NULL)
			{ // Verifica se il mime type dichiarato nell'header del server corrisponde a quello reale del buffer
				if (MIME_TEXT_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_robotsxml(starter, serverid, inbuf, report, rwritten, rspace);
				else if (MIME_APPLICATION_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_robotsxml(starter, serverid, inbuf, report, rwritten, rspace);
			}
			else if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "*** siteid %llu sitemap with url redirect not admitted *** ", (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			break;

		case MIME_ROBOTS_XML_GZ:

			// Robots site summary - sitemap
			if (server->pages->src_path == NULL)
			{ // Verifica se il mime type dichiarato nell'header del server corrisponde a quello reale del buffer
				if (MIME_TEXT_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_robotsxml(starter, serverid, inbuf, report, rwritten, rspace);
				else if (MIME_APPLICATION_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_robotsxml(starter, serverid, inbuf, report, rwritten, rspace);
			}
			else if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "*** siteid %llu sitemap with url redirect not admitted *** ", (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			break;

		case MIME_ROBOTS_XML_BROKEN:
			// sitemap xml documents
			break;

		case MIME_FEEDS_ATOM_XML:

			// Robots site summary - atom feed
			if (server->pages->src_path == NULL)
			{ // Verifica se il mime type dichiarato nell'header del server corrisponde a quello reale del buffer
				if (MIME_TEXT_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_atom_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
				else if (MIME_APPLICATION_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_atom_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
				else if (MIME_APPLICATION_ATOM_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_atom_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
			}
			else if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "*** siteid %llu feed with url redirect not admitted *** ", (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			break;

		case MIME_FEEDS_ATOM_XML_GZ:

			// Robots site summary - atom feed
			if (server->pages->src_path == NULL)
			{ // Verifica se il mime type dichiarato nell'header del server corrisponde a quello reale del buffer
				if (MIME_TEXT_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_atom_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
				else if (MIME_APPLICATION_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_atom_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
				else if (MIME_APPLICATION_ATOM_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_atom_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
			}
			else if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "*** siteid %llu feed with url redirect not admitted *** ", (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			break;

		case MIME_FEEDS_ATOM_XML_BROKEN:
			// sitemap xml documents
			break;

		case MIME_FEEDS_RSS_XML:

			// Robots site summary - rss feed
			if (server->pages->src_path == NULL)
			{ // Verifica se il mime type dichiarato nell'header del server corrisponde a quello reale del buffer
				if (MIME_TEXT_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_rss_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
				else if (MIME_APPLICATION_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_rss_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
				else if (MIME_APPLICATION_RSS_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_rss_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
			}
			else if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "*** siteid %llu feed with special url redirect not admitted *** ", (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			break;

		case MIME_FEEDS_RSS_XML_GZ:

			// Robots site summary - rss feed
			if (server->pages->src_path == NULL)
			{ // Verifica se il mime type dichiarato nell'header del server corrisponde a quello reale del buffer
				if (MIME_TEXT_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_rss_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
				else if (MIME_APPLICATION_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_rss_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
				else if (MIME_APPLICATION_RSS_XML == meta->mime_type(NULL, (char *)magic_mime_type))
					ret = parser_process_rss_feedsxml(starter, serverid, inbuf, report, rwritten, rspace);
			}
			else if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "*** siteid %llu feed with special url redirect not admitted *** ", (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			break;

		case MIME_FEEDS_RSS_XML_BROKEN:
			// sitemap xml documents
			break;

		case MIME_REDIRECT:

			inbuf[doc->raw_content_length] = ASCII_NUL;
			// Assegno al buffer la memoria necessaria per contenere i links scaricati e relativi logs (delle pagine nuove o aggiornate)
			// Verranno inseriti solo quando le pagine risultano nuove o "realmente" modificate (verifica attraverso le variazioni del testo (LSH))
			server->pages->bld_size = (MAX_STR_LEN * 3);
			server->pages->buffer_links_download = (char *) malloc ((server->pages->bld_size + 1) * sizeof(char));
			assert (server->pages->buffer_links_download != NULL);
			server->pages->buffer_links_download[0] = ASCII_NUL;
			server->pages->bld_offset = 0;
			server->pages->bll_size = (MAX_STR_LEN * 3);
			server->pages->buffer_links_log = (char *) malloc ((server->pages->bll_size + 1) * sizeof(char));
			assert (server->pages->buffer_links_log != NULL);
			server->pages->buffer_links_log[0] = ASCII_NUL;
			server->pages->bll_offset = 0;

			if (server->pages->mime_type == MIME_FEEDS_ATOM_XML || server->pages->mime_type == MIME_FEEDS_ATOM_XML_GZ)
				parser_analyze_link_feeds(starter, serverid, inbuf, (char*)LINK_CAPTION_ATOM_FEED, false, -1, NULL);
			else if (server->pages->mime_type == MIME_FEEDS_RSS_XML || server->pages->mime_type == MIME_FEEDS_RSS_XML_GZ)
				parser_analyze_link_feeds(starter, serverid, inbuf, (char*)LINK_CAPTION_RSS_FEED, false, -1, NULL);
			else
				parser_analyze_link(starter, serverid, inbuf, (char*)"", (double)0, (em_tag_t)0, NULL);

			free (server->pages->buffer_one);
			server->pages->buffer_one = NULL;

			break;

		case MIME_TEXT_PLAIN:

			// Verifica se il mime type dichiarato nell'header del server non corrisponde a quello reale del buffer
			if (doc->mime_type != meta->mime_type(NULL, (char *)magic_mime_type))
			{
				ret = 0;
				break;
			}

			// Esegue lo 'swap' della memoria:
			server->pages->buffer_two = inbuf;
			server->pages->bt_size = doc->raw_content_length;
			server->pages->buffer_one = NULL;
			server->pages->buffer_one = (char *) malloc (sizeof(char));
			assert (server->pages->buffer_one != NULL);
			server->pages->bo_size = 1;
			server->pages->buffer_one[0] = ASCII_NUL;

			ret = doc->raw_content_length;
			break;

		case MIME_APPLICATION_PDF:

			// Verifica se il mime type dichiarato nell'header del server non corrisponde a quello reale del buffer
			if (doc->mime_type != meta->mime_type(NULL, (char *)magic_mime_type))
			{
				ret = 0;
				break;
			}


			SOCKET_PATH = CBALLOC(char, MALLOC, (MAX_STR_LEN + 1));
			SOCKET_PATH[0] = ASCII_NUL;
			sprintf(SOCKET_PATH, SOCK_PATH, (unsigned long int)inst);

			// pdf documents
			content_length = eipm((const char *)SOCKET_PATH, socket_timeout, inbuf, doc->raw_content_length, outbuf);

			free(SOCKET_PATH); SOCKET_PATH = NULL;

			ret = content_length;

			if (ret <= PDFMETAPREFIXSIZE)
			{
				ret = 0;
				break;
			}
			else
			{
				unsigned short c = 0;
				for (unsigned char i = 0; i < PDFMETAPREFIXSIZE; i++)
					c += ((int)server->pages->buffer_two[i] + CHAR_MAX); // N.B. 'outbuf' è un puntatore verso 'server->pages->buffer_two'
					
				if (ret <= (c + PDFMETAPREFIXSIZE)) // diverso dalla versione html perchè in pdf preferisco escludere un documento con contenuto vuoto
				{
					ret = 0;
					break;
				}
			}

			if (content_length > 0)
				doc->charset = CHARSET_UTF_8;

			break;

		case MIME_APPLICATION_PDF_BROKEN:
			// pdf documents
			break;

		default:

			// Esegue lo 'swap' della memoria:
			server->pages->buffer_two = server->pages->buffer_one;
			server->pages->bt_size = server->pages->bo_size;
			server->pages->buffer_one = NULL;
			server->pages->buffer_one = CBALLOC(char, MALLOC, 1);
			server->pages->bo_size = 1;
			server->pages->buffer_one[0] = ASCII_NUL;

			ret = doc->raw_content_length;
			break;
	}

	if (partial_path[inst] != NULL)
	{
		free(partial_path[inst]);
		partial_path[inst] = NULL;
	}

	return ret;
}

int has_protocol (char *url){
	return (strchr(url, ':') != NULL && ((strchr(url, '?')) == NULL || strchr(url, ':') < strchr(url, '?')) &&
			((strchr(url, '#')) == NULL || strchr(url, ':') < strchr(url, '#')));
}

//
// Name: parser_process_html
//
// Description:
//   Parse an html document
//
// Input:
//   doc - the document to be parsed
//   inbuf - text of the document
// 
// Return:
//   new content_length of the document
//

// First: define some macros
#define IS_START() (inbuf[inpos] == ASCII_MI)
#define IS_END() (inbuf[inpos] == ASCII_MA)
#define IS_SPACE() (inbuf[inpos] == ASCII_SP || inbuf[inpos] == ASCII_TB) // new
#define IS_SPACE_EXTENDED() (inbuf[inpos] == ASCII_SP || inbuf[inpos] == ASCII_TB ||inbuf[inpos] == ASCII_NL || inbuf[inpos] == ASCII_CR) // insert also ASCII_TB
#define IS_EOF() (inpos >= size)
#define IS_QUOTE() (inbuf[inpos] == ASCII_QU || inbuf[inpos] == ASCII_DQ)
#define IS_EQ() (inbuf[inpos] == ASCII_EQ)
#define IS_SLASH() (inbuf[inpos] == ASCII_SL)
#define IS_NEWLINE() (inbuf[inpos] == ASCII_CR || inbuf[inpos] == ASCII_NL)

off64_t parser_process_html(starter_t *starter, siteid_t serverid, char *inbuf, char *report, int &rwritten, size_t &rspace)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);
	instance_t inst = starter->inst;

	//função que realiza o parser das páginas html. Alterações nela
	//irão mudar a forma como o arquivo é armazenado do storage do CBOT
	//e como ele será visto pelas outras partes do programa.
	// Possible links
	char *href = CBALLOC(char, MALLOC, (MAX_STR_LEN + reserve + 1));
	char caption[MAX_STR_LEN];
	char base[MAX_STR_LEN] = {ASCII_NUL};
	bool is_robots_checked = false;
	bool is_refresh_checked	= false;
	bool is_language_checked = false;
	
	doc_t *doc = server->pages->doc;
	char *outbuf = server->pages->buffer_two;
	string path = server->pages->path;
	string site = server->hostname;
	number_lines_download[inst] = 0;
	number_lines_log[inst] = 0;
	adjacency_list_new_link[inst] = false;
	adjacency_list_length[inst] = 0;
	memset(adjacency_list[inst], 0, (sizeof(out_link_t) * LINK_MAX_OUTDEGREE));


	// Clean strings
	href[0]						= ASCII_NUL;
	caption[0]					= ASCII_NUL;
	bool have_base_tag			= false;


	// Position and status of the parser
	off64_t inpos				= 0;
	off64_t outpos				= 0;
	//off64_t start_text		= 0;
	status_t status				= STATUS_NORMAL;

	// The actual status must be kept in a stack. So, there won't be the problem of ending a tag
	// of the group that the text musn't be kept in side another one  of the same group
	stack <status_t> status_stack;
	status_stack.push(status);

	bool waiting_link_content	= false;
	bool follow_links		= true;
	off64_t size			= doc->raw_content_length;
	int caption_position		= 0;

	// Verify
	assert(size > 0);
	assert(doc != NULL);
	assert(inbuf != NULL);
	assert(outbuf != NULL);

	int_stack_t *tag_stack = CBALLOC(int_stack_t, MALLOC, 1);
	int_stack_init(tag_stack);

	// Clean the input buffer, leave only what is going to be saved
	for(off64_t in=0; in<size; in++)
		if (inbuf[in] == '\f' || inbuf[in] == ASCII_NL || inbuf[in] == ASCII_CR || inbuf[in] == ASCII_TB || inbuf[in] == '\v')
			inbuf[in] = ASCII_SP;

	// Utilizzo sistema ibernazione tag
	char temp_name_hibernate[MAX_STR_LEN + 1];
	temp_name_hibernate[0] = ASCII_NUL;

	restart_because_was_false_tag: // se si è tornati a questo punto significa che il tag che si stava esaminando NON era un tag!

	// Questi 3 array di caratteri, servono per accertarsi che le stringhe se troppo lunghe non siano salvate spezzate nella struttura tag_t, bensì scartate!
	// Il sistema in pratica scrivendo nell'array temporaneo verifica che la stringa sorgente non occupi tutta la massima lunghezza consentita.
	// Se la scrittura nell'array temporaneo non occupa la lunghezza massima consentita, si è certi che la stringa sorgente non supera la soglia di MAX_STR_LEN.
	// L'array temp_name_hibernate (vedi sopra) funziona con il principio di ibernazione dei tag in cui occorre escludere il contenuto racchiuso.
	char temp_name[MAX_STR_LEN + 1];
	char temp_attr_name[MAX_STR_LEN + 1];
	char temp_attr_value[MAX_STR_LEN + 1];
	temp_name[0] = ASCII_NUL;
	temp_attr_name[0] = ASCII_NUL;
	temp_attr_value[0] = ASCII_NUL;
	//

	// Main loop
	while (!IS_EOF())
	{
		// ------- EVENTS-ORIENTED PARSER  ----------
		// This is a pseudo-sax parser - Events parser -
		event_t event = EVENT_UNDEF;
		tag_t	tag;
		tag.attnum = 0;

		off64_t old_inpos = inpos;


		// Generate an EVENT_EOF
		if (IS_EOF())
			event = EVENT_EOF; //Removes the comments from the buffer
		else if (IS_START() && inpos + 6 < size && inbuf[inpos + 1] == ASCII_EM && inbuf[inpos + 2] == '-' && inbuf[inpos + 3] == '-')
		{
			inpos += 6; // this is the minimum size of a comment

			while (!IS_EOF() && (inbuf[inpos - 2] != '-' || inbuf[inpos -1] != '-' || inbuf[inpos] != ASCII_MA))
				inpos++;

			inpos++;

		// Generate an EVENT_START_TAG or EVENT_END_TAG
		}
		else if (IS_START())
		{
			event = EVENT_START_TAG;

			// Read the tag name
			inpos++;
			int i = 0;

			while (!IS_SPACE_EXTENDED() && !IS_END() && !IS_EOF())
			{
				if (inpos > 0 && IS_SLASH() && ((inbuf[inpos - 1] == ASCII_MI && isalpha(inbuf[inpos + 1]))))
				{
					if (i==0)
					{
						event = EVENT_END_TAG;
						inpos++;
					}
					else
					{
						event = EVENT_EMPTY_TAG;

						while (!IS_END() && !IS_EOF())
							inpos++;
					}
				}
				else
				{
					if (i < MAX_STR_LEN + 1)
						temp_name[i++] = tolower(inbuf[inpos]);

					inpos++;
				}
			} // end while reading tag name
			temp_name[i] = ASCII_NUL;

			if (temp_name[0] != ASCII_NUL)
			{
				for (int z = 0; z < i; z++)
				{
					if (temp_name_hibernate[0] != ASCII_NUL && strcmp (temp_name_hibernate,temp_name) != 0)
						goto restart_because_was_false_tag;

					if (temp_name_hibernate[0] != ASCII_NUL && event != EVENT_END_TAG)
						goto restart_because_was_false_tag;

					if (temp_name[z] == ASCII_MI)
					{
						inpos = (old_inpos + 1);
						goto restart_because_was_false_tag;
					}
				}
			}
			else
				goto restart_because_was_false_tag;

			temp_name_hibernate[0] = ASCII_NUL;

			if (i <= MAX_STR_LEN)
			{
				strcpy(tag.name, temp_name);

				if (IS_SPACE_EXTENDED())
				{
					// Read until too many attributes
					while (!IS_END() && !IS_EOF() && (tag.attnum < MAX_HTML_ATTRIBUTES))
					{
						// Advance to next non-space
						while (!IS_EOF() && !IS_SLASH() && IS_SPACE_EXTENDED() && !IS_END())
						{
							if (IS_START())
							{
								inpos = (old_inpos + 1);
								goto restart_because_was_false_tag;
							}

							inpos++;
						}
	
						if (IS_EOF())
							event = EVENT_EOF;
						else if (IS_SLASH())
						{ // Check if empty tag
							event = EVENT_EMPTY_TAG;

							while (!IS_END() && !IS_EOF())
							{
								if (IS_START())
								{
									inpos = (old_inpos + 1);
									goto restart_because_was_false_tag;
								}
								inpos++;
							}

							if (IS_EOF())
								event = EVENT_EOF;
						}
						else if (!IS_END())
						{
							// Start copying attribute name
							int i = 0;
							while (!IS_EQ() && !IS_END() && !IS_EOF())
							{
								if (IS_START())
								{
									inpos = (old_inpos + 1);
									goto restart_because_was_false_tag;
								}

								if (i < MAX_STR_LEN + 1)
									temp_attr_name[i++] = tolower(inbuf[inpos]);

								inpos++;
							}
							temp_attr_name[i] = ASCII_NUL;
	
							if (IS_EQ())
							{
								// Start copying value
								char quoted = ASCII_NUL;
								while (IS_EQ() && !IS_QUOTE() && !IS_EOF() && !IS_END())
								{
									if (IS_START())
									{
										inpos = (old_inpos + 1);
										goto restart_because_was_false_tag;
									}

									inpos++;
								}
								if (IS_QUOTE())
								{
									quoted = inbuf[inpos];
									inpos++;
								}
	
								int i = 0;
								while (!IS_EOF() &&
									((quoted  && (!(inbuf[inpos] == quoted)) && !IS_END()) ||
									 (!quoted && !IS_SPACE_EXTENDED() && !IS_END())))
								{
									if (IS_START())
									{
										inpos = (old_inpos + 1);
										goto restart_because_was_false_tag;
									}

									if (i < MAX_STR_LEN + 1)
										temp_attr_value[i++] = inbuf[inpos];	

									inpos++;
										
								}
								temp_attr_value[i] = ASCII_NUL;
//cout << ASCII_SP << inbuf[inpos] << ' ' << inpos << endl;	
								if (!IS_EOF() && IS_QUOTE())
									inpos++;
							}
							else if (IS_EOF())
								event = EVENT_EOF;	

							// Se la lunghezza è inferiore a MAX_STR_LEN signica che il termine è scritto completo
							// in questo modo gli url non possono essere salvati spezzati se si supera la lunghezza massima
							// consentita
							if (strlen(temp_attr_name) < MAX_STR_LEN && strlen(temp_attr_value) < MAX_STR_LEN)
							{
								strcpy(tag.attributes[tag.attnum].name, temp_attr_name);
								strcpy(tag.attributes[tag.attnum].value, temp_attr_value);
								tag.attnum++;
							}
						}
					}
				} // end while (what goes after tag name)
			}

			if (!IS_EOF() && IS_END())
				inpos++;

		// Generate an EVENT_TEXT
		}
		else if (!IS_EOF())
		{
			while (IS_SPACE_EXTENDED() && !IS_EOF())
				inpos++;

			if (!IS_START() && !IS_EOF())
				event = EVENT_TEXT; // In a normal SAX parser, we should copy the text to a temporary buffer. For efficiency reasons, we don't
			else if (IS_EOF())
				event = EVENT_EOF;
			else
				event = EVENT_UNDEF;
		}

		// ------ EVENT HANDLER ----------
		// Switch depending on type of event

		switch(event)
		{
			case EVENT_EOF:
			case EVENT_UNDEF:
				break;

			case EVENT_TEXT:
				//start_text = inpos;

				// See if waiting for link content
				caption_position = 0;
				if (waiting_link_content)
				{
					caption_position = strlen(caption);
					caption[caption_position++] = ASCII_SP;
				}

				// Copy the incoming text
				while (!IS_START() && !IS_EOF())
				{
					// Only if it's kept
					if (status_stack.top() == STATUS_NORMAL)
					{	// Copy link content to caption if necessary
						if (waiting_link_content && caption_position < MAX_STR_LEN)
								caption[caption_position++] = inbuf[inpos];

						// Copy to output buffer
						outbuf[outpos++] = inbuf[inpos];
					}

					// Swallow multiple spaces
					if (IS_SPACE_EXTENDED())
					{
						inpos++;

						while (IS_SPACE_EXTENDED() && !IS_EOF())
							inpos++;
					}
					else
						inpos++;
				}

				// If waiting for link content, close the caption
				if (waiting_link_content)
					caption[caption_position] = ASCII_NUL;

				break;

			case EVENT_START_TAG:
			case EVENT_EMPTY_TAG:

				// Check for we are in the meta tag
				if (!strcmp(tag.name, "meta"))
				{ // Scan for name="robots", Scan for http-equiv="refresh"
					bool is_robots = false;
					bool is_refresh	= false;
					bool is_language = false;
					for(int att=0; att<tag.attnum;att++)
					{	// Check if name="robots"
						if (!strcasecmp(tag.attributes[att].name, "name") &&
							!strcasecmp(tag.attributes[att].value, "robots"))
							is_robots = true;

						// Check if http-equiv="robots"
						if (!strcasecmp(tag.attributes[att].name, "http-equiv") &&
							!strcasecmp(tag.attributes[att].value, "refresh"))
							is_refresh = true;

						// Check if http-equiv="robots"
						if (!strcasecmp(tag.attributes[att].name, "http-equiv") &&
							!strcasecmp(tag.attributes[att].value, "content-language"))
							is_language = true;
					}

					// If it's <meta name="robots" ...> check for content="..."
					if (is_robots_checked == false && is_robots == true)
					{
						char robots[MAX_STR_LEN] = "";

						for(int att=0; att<tag.attnum;att++)
						{
							// Check content="..."
							if (!strcmp(tag.attributes[att].name, "content"))
								for(uint i=0; i<=strlen(tag.attributes[att].value); i++)
									robots[i] = tolower(tag.attributes[att].value[i]);
						}

						// Check for noindex
						if (strstr(robots, "noindex"))
						{
							// Report
							if (rspace > 0)
							{
								int _rwritten = rwritten;
								rwritten += snprintf(report + rwritten, rspace, "[noindex] ");
								rspace -= (rwritten - _rwritten);
							}

							// Empty output buffer
							outbuf[0] = ASCII_NUL;

							free(href);
							free(tag_stack);

							// Zero offset
							return (off64_t)0;
						}

						// Check for nofollow
						if (strstr(robots, "nofollow"))
						{
							// Report
							if (rspace > 0)
							{
								int _rwritten = rwritten;
								rwritten += snprintf(report + rwritten, rspace, "[index,nofollow] ");
								rspace -= (rwritten - _rwritten);
							}

							// Don't follow links
							follow_links = false;
						}

						is_robots_checked = true;
							
					// If it's meta http-equiv="refresh" check for content="..."
					}
					else if (is_refresh_checked == false && is_refresh == true)
					{
						char refresh_url[MAX_STR_LEN] = "";

						for(int att=0; att<tag.attnum;att++)
						{ // Check content="..."
							if (!strcmp(tag.attributes[att].name, "content"))
								strcpy(refresh_url, tag.attributes[att].value);
						}

						if (strlen(refresh_url) > 0)
						{
							// In a meta refresh, content is of the form
							// "5;URL=http://www.example.com/"
							// so we locate the ASCII_EQ sign and move to the right
							if (char *href = strchr(refresh_url, ASCII_EQ))
							{
								if (strlen(href) > 1)
								{
									href++;
									parser_analyze_link(starter, serverid, href, (char*)"", (double)inpos/(double)size, (em_tag_t)int_stack_peek(tag_stack), NULL);
									href[0] = ASCII_NUL;
								}
							}
						}

						is_refresh_checked = true;

					// If it's meta http-equiv="content-type" check for content="..."
					}
					else if (is_language_checked == false && is_language == true)
					{
						char language[MAX_STR_LEN];
						language[0] = ASCII_NUL;

						for(int att=0; att<tag.attnum;att++) // Check content="..."
							if (!strcmp(tag.attributes[att].name, "content"))
								strcpy(language, tag.attributes[att].value);

						Language metalanguage = http_language(language);

						// we assign language of document obtained with metatags, only if Language class cannot extrapolate stemming language
						// Stemming language must be extrapolate with much precision because words of text are needed for 'do you mean' process and
						// search engine can apply rigth stemming to documents
						if (metalanguage != Language::UNKNOWN && LANGUAGE_TO_STEMMING(metalanguage) == Stemming::UNKNOWN)
							server->pages->doc->language = metalanguage;

						is_language_checked = true;
					}
				}
				else if (CONF_SEEDER_ADD_FEEDSXML == true && !strcmp(tag.name, "link") && server->pages->doc->depth == 1)
				{ // Scan for rel="alternate", Scan for type="application/rss+xml"
					bool is_alternate = false;
					bool is_application_atom = false;
					bool is_application_rss = false;
					for(int att=0; att<tag.attnum;att++)
					{ // Check if rel="alternate"
						if (!strcasecmp(tag.attributes[att].name, "rel") && !strcasecmp(tag.attributes[att].value, "alternate"))
							is_alternate = true;

						// Check if type="application/rss+xml"
						if (!strcasecmp(tag.attributes[att].name, "type"))
						{
							if (!strcasecmp(tag.attributes[att].value, "application/atom+xml"))
								is_application_atom = true;
							else if (!strcasecmp(tag.attributes[att].value, "application/rss+xml"))
								is_application_rss = true;
						}
					}

					if (is_alternate == true && (is_application_atom == true || is_application_rss == true))
					{
						for(int att=0; att<tag.attnum;att++)
						{ // Check content="..."
							if (!strcmp(tag.attributes[att].name, "href"))
							{
								strcpy(href, tag.attributes[att].value);

								if (strlen(href) > 1)
								{
									if (is_application_atom == true)
										parser_analyze_link_feeds(starter, serverid, href, (char*)LINK_CAPTION_ATOM_FEED, false, -1, base);
									else if (is_application_rss == true)
										parser_analyze_link_feeds(starter, serverid, href, (char*)LINK_CAPTION_RSS_FEED, false, -1, base);

									href[0] = ASCII_NUL;
								}
							}
						}
					}
				}
				else if (!strcmp(tag.name, "base") && have_base_tag == false)
				{ // Scan for href=""
					for(int att=0; att<tag.attnum;att++)
					{
						if (!strcasecmp(tag.attributes[att].name, "href"))
						{
							char base_path[MAX_STR_LEN];
							base_path[0] = ASCII_NUL;

							if (! has_protocol(tag.attributes[att].value))
							{
								strcpy(base_path, tag.attributes[att].value);
								have_base_tag = true;
							}
							else
							{
								// Remote url
								// It's a url that has protocol

								// Parser variables
								char protocol[MAX_STR_LEN];
								char sitename[MAX_STR_LEN];
								//char src_sitename[MAX_STR_LEN];

								// Parse the input url
								have_base_tag = url->parse_complete_url(tag.attributes[att].value, protocol, sitename, base_path);

								if (have_base_tag == true && strncmp(site.c_str(),(const char *)sitename,site.length()) > 0)
									have_base_tag = false;
							}

							if (have_base_tag == true)
							{
				//				base = (char *) malloc (MAX_STR_LEN * sizeof(char));
								strcpy(base, LINK_CAPTION_BASE_URL);
								if (base_path[0] != ASCII_NUL)
									strcat(base, base_path);
							}
						}
					}
				}

				// Verify if the tag must be kept
				if (perfhash_check(&(keep_tag), tag.name))
				{ // Copy tag name
					int i = 0;
					outbuf[outpos++] = ASCII_MI;

					while (tag.name[i] != ASCII_NUL)
						outbuf[outpos++] = tag.name[i++];

					// Copy attributes
					bool tag_is_link	= is_link[tag.name];

					// If this tag is a the start of a link, and we
					// were already waiting for the content of a link,
					// then we must flush what we have up to now to disk,
					// to avoid loosing an href
					if (tag_is_link && waiting_link_content && follow_links)
					{
						parser_analyze_link(starter, serverid, href, caption, (double)inpos/(double)size, (em_tag_t)int_stack_peek(tag_stack), base);

						href[0] = ASCII_NUL;
						caption[0] = ASCII_NUL;
						waiting_link_content	= false;
					}

					for(int att=0;att<tag.attnum;att++)
					{

						// Check if the attribute must be kept
						if (perfhash_check(&(keep_attribute), tag.attributes[att].name))
						{
							int i = 0;
							outbuf[outpos++] = ASCII_SP;

							while (tag.attributes[att].name[i] != ASCII_NUL)
								outbuf[outpos++] = tag.attributes[att].name[i++];

							outbuf[outpos++] = ASCII_EQ;
							outbuf[outpos++] = ASCII_DQ;
							i = 0;

							while (tag.attributes[att].value[i] != ASCII_NUL)
								outbuf[outpos++] = tag.attributes[att].value[i++];

							outbuf[outpos++] = ASCII_DQ;

							// Check if this attribute contains a link
							if (tag_is_link)
							{
								if (!strcmp(link_attribute[tag.name].c_str(),tag.attributes[att].name))
									strcpy(href,tag.attributes[att].value);

								if (!strcmp(link_caption[tag.name].c_str(),tag.attributes[att].name))
									strcpy(caption,tag.attributes[att].value);
							}
						}
					}

					if (event == EVENT_EMPTY_TAG)
						outbuf[outpos++] = ASCII_SL;

					outbuf[outpos++] = ASCII_MA;
				}
				else // It must not be kept, but it's a word boundary
					outbuf[outpos++] = ASCII_SP;
				if (perfhash_check(&(discard_content), tag.name) && (event != EVENT_EMPTY_TAG))
				{
					strcpy(temp_name_hibernate,tag.name);
					status_stack.push(STATUS_IGNORE);
				}

				break;

			case EVENT_END_TAG:

				if (perfhash_check(&(keep_tag), tag.name)) // Verify if the tag must be kept
				{
					int i = 0;
					outbuf[outpos++] = ASCII_MI;
					outbuf[outpos++] = ASCII_SL;

					while (tag.name[i] != ASCII_NUL)
						outbuf[outpos++] = tag.name[i++];

					outbuf[outpos++] = ASCII_MA;
				}
				else // It must not be kept, but it's a word boundary
					outbuf[outpos++] = ASCII_SP;

				if (perfhash_check(&(discard_content), tag.name))
				{
					temp_name_hibernate[0] = ASCII_NUL;

					if (status_stack.size() > 1)
						status_stack.pop();
					else if (status_stack.size() == 0)
						status_stack.push(STATUS_NORMAL);
				}

				break;
		}

		// Check for the tag
		update_tag_stack(tag_stack, tag.name, event);

		// ------- LINKS ------
		// Deal with (possible) links

		// Check if the tag has an attribute indicating a link
		if (href[0] != ASCII_NUL)
		{ // If we are in a starting tag
			if (event == EVENT_START_TAG || event == EVENT_EMPTY_TAG)
			{	// We are starting a tag, or we are reading an empty tag.
				if (is_link_with_content[tag.name]) // Check if we have to wait for the caption ie: <a href=""> ... </a>
				{
					if (event == EVENT_START_TAG)
					{
						if (waiting_link_content == true)
						{	// This is a nested link, like <a href="...">......<a href="....">.... Nested links, save current link up to here
							if (follow_links)
								parser_analyze_link(starter, serverid, href, caption, (double)inpos/(double)size, (em_tag_t)int_stack_peek(tag_stack), base);

							href[0] = ASCII_NUL;
							caption[0] = ASCII_NUL;

						}

						// We have to wait for the caption
						waiting_link_content = true;
					}
					else if (event == EVENT_END_TAG)
					{	// Malformed "<a href=x.html/>blah</a>"
						if (follow_links)
							parser_analyze_link(starter, serverid, href, (char*)"" , (double)inpos/(double)size, (em_tag_t)int_stack_peek(tag_stack), base);

						href[0] = ASCII_NUL;
						caption[0] = ASCII_NUL;
					}
				}
				else
				{ // This is a tag in which the link content is not the caption
					if (waiting_link_content == true) // This is a nested link, like <a href="...">......<img src="....">.... We cannot save the second link now
						waiting_link_content = false;

					// The caption is an attribute, we don't need to wait
					// for the content of this tag
					if (follow_links)
						parser_analyze_link(starter, serverid, href, caption, (double)inpos/(double)size, (em_tag_t)int_stack_peek(tag_stack), base);

					href[0] = ASCII_NUL;
					caption[0] = ASCII_NUL;
				}

			}
			else if (event == EVENT_END_TAG)
			{


				// On closing tag, check if i was waiting for a link
				if (waiting_link_content)
				{ // I was waiting for a link, save it
					if (follow_links)
						parser_analyze_link(starter, serverid, href, caption, (double)inpos/(double)size,(em_tag_t)int_stack_peek(tag_stack), base);

					href[0] = ASCII_NUL;
					caption[0] = ASCII_NUL;
					waiting_link_content = false;
				}
			}
		}

	
	} // End While(1)

	free(href);
	free(tag_stack);

	// This may happen in the case of a short, anomalous
	// document like this:
	// "<html " without a closing tag.
	if (outpos < 0)
			outpos = 0;

	// Close output buffer; it might have ended a few chars
	// after the end, it depends if we ended on a tag or not
	while (outpos >= 1 && outbuf[outpos-1] == ASCII_NUL)
		outpos--;

	//assert(outpos < max_outbuf_len);

	outbuf[outpos] = ASCII_NUL;

	const doc_hash_t delta_hash = 5; // tolleranza di differenza minima dei due hash

	if (number_lines_download[inst] == 0 || adjacency_list_new_link[inst] == false)
	{
		free(server->pages->buffer_links_download);
		server->pages->buffer_links_download = NULL;
		free(server->pages->buffer_links_log);
		server->pages->buffer_links_log = NULL;
	}

	if (number_lines_log[inst] == 0)
	{
		free(server->pages->buffer_links_log);
		server->pages->buffer_links_log = NULL;
	}
			
	return outpos;
}

//
// Name: parser_charset_metadata
//
// Descriptions:
//   Parses de metadata tag that identifies the charset of the document
//
// Input:
//   doc - the document to be parsed
//   inbuf - text of the document
//
// Return:
//   the identified char set
//

charset_t parser_charset_metadata(server_t *server, char *inbuf)
{

	doc_t *doc = server->pages->doc;

	assert(doc != NULL);
	assert(doc->docid != 0);
	assert(doc->raw_content_length > 0);
	assert(doc->mime_type == MIME_TEXT_HTML);

	assert(inbuf != NULL);

	// Position and status of the parser
	off64_t inpos					= 0;

	// The actual status must be kept in a stack. So, there won't be the problem of ending a tag
	// of the group that the text musn't be kept in side another one  of the same group

	off64_t size					= doc->raw_content_length;

	// Main loop
	while (!IS_EOF()) {

		// ------- EVENTS-ORIENTED PARSER  ----------
		// This is a pseudo-sax parser
		// Events parser
		event_t event = EVENT_UNDEF;
		tag_t	tag;
		tag.attnum = 0;

		// Generate an EVENT_EOF
		if (IS_EOF()) {
			event = EVENT_EOF;

		//Removes the comments from the buffer
		}
		else if (IS_START() && inpos + 6 < size && inbuf[inpos + 1] == ASCII_EM && inbuf[inpos + 2] == '-' && inbuf[inpos + 3] == '-')
		{
			inpos += 6; // this is the minimum size of a comment

			while (!IS_EOF() && (inbuf[inpos - 2] != '-' || inbuf[inpos -1] != '-' || inbuf[inpos] != ASCII_MA))
				inpos++;
			inpos++;
		}
		else if (IS_START()) // Generate an EVENT_START_TAG or EVENT_END_TAG
		{

			event = EVENT_START_TAG;

			// Read the tag name
			inpos++;
			int i = 0;

			while (!IS_SPACE_EXTENDED() && !IS_END() && !IS_EOF()) {
				if (IS_SLASH()) {
					if (i==0) {
						event = EVENT_END_TAG;
						inpos++;
					} else {
						event = EVENT_EMPTY_TAG;
						while (!IS_END() && !IS_EOF()) {
							inpos++;
						}
					}
				} else  {
					if (i < MAX_STR_LEN - 1) {
						tag.name[i++] = tolower(inbuf[inpos]);
					}
					inpos++;
				}
			} // end while reading tag name
			tag.name[i] = ASCII_NUL;

			if (IS_SPACE_EXTENDED())
			{
				// Read until too many attributes
				while (!IS_END() && !IS_EOF() && (tag.attnum < MAX_HTML_ATTRIBUTES)) {

					// Advance to next non-space
					while (!IS_EOF() && !IS_SLASH() && IS_SPACE_EXTENDED() && !IS_END())
						inpos++;

					if (IS_EOF()) {
						event = EVENT_EOF;

					} else if (IS_SLASH()) {

						// Check if empty tag
						event = EVENT_EMPTY_TAG;
						while (!IS_END() && !IS_EOF()) {
							inpos++;
						}
						if (IS_EOF()) {
							event = EVENT_EOF;
						}
					} else if (!IS_END()) {
						// Start copying attribute name
						int i = 0;
						while (!IS_EQ() && !IS_END() && !IS_EOF()) {
							if (i < MAX_STR_LEN-1) {
								tag.attributes[tag.attnum].name[i++] = tolower(inbuf[inpos]);
							}
							inpos++;
						}
						tag.attributes[tag.attnum].name[i] = ASCII_NUL;

						if (IS_EQ()) {
							// Start copying value
							char quoted = ASCII_NUL;
							while (IS_EQ() && !IS_QUOTE() && !IS_EOF() && !IS_END()) {
									inpos++;
							}
							if (IS_QUOTE()) {
								quoted = inbuf[inpos];
								inpos++;
							}

							int i = 0;
							while (!IS_EOF() &&
								((quoted  && (!(inbuf[inpos] == quoted)) && !IS_END()) ||
								 (!quoted && !IS_SPACE_EXTENDED() && !IS_END())))  {
								if (i < MAX_STR_LEN-1) {
									tag.attributes[tag.attnum].value[i++] = inbuf[inpos];
								}
								inpos++;

							}
							tag.attributes[tag.attnum].value[i] = ASCII_NUL;

							if (IS_QUOTE()) {
								inpos++;
							}

						} else if (IS_EOF()) {
							event = EVENT_EOF;
						}
						tag.attnum++;
					}
				}


			} // end while (what goes after tag name)

			if (IS_END())
				inpos++;
			// Generate an EVENT_TEXT
		}
		else if (!IS_EOF())
		{
			while (IS_SPACE_EXTENDED() && !IS_EOF())
				inpos++;

			if (!IS_START() && !IS_EOF())
				event = EVENT_TEXT; // In a normal SAX parser, we should copy the text to a temporary buffer. For efficiency reasons, we don't
			else if (IS_EOF())
				event = EVENT_EOF;
			else
				event = EVENT_UNDEF;
		}

		// ------ EVENT HANDLER ----------
		// Switch depending on type of event

		switch(event) {
			case EVENT_EOF:
			case EVENT_UNDEF:
				break;

			case EVENT_TEXT:
				//ignore texts
				while (!IS_START() && !IS_EOF()) {
						inpos++;
				}
				break;

			case EVENT_START_TAG:
			case EVENT_EMPTY_TAG:

				// Check for we are in the meta tag
				if (!strcmp(tag.name, "meta")) {

					// Scan for http-equiv="content-type"
					bool is_content_type = false;

					for(int att=0; att<tag.attnum;att++) {


						// Check if http-equiv="robots"
						if (!strcasecmp(tag.attributes[att].name, "http-equiv") &&
							!strcasecmp(tag.attributes[att].value, "content-type")) {
							is_content_type = true;
						}

					}


					// If it's meta http-equiv="content-type" check for content="..."
					if (is_content_type) {
						char content_type[MAX_STR_LEN] = "";

						for(int att=0; att<tag.attnum;att++) {

							// Check content="..."
							if (!strcmp(tag.attributes[att].name, "content"))
								strcpy(content_type, tag.attributes[att].value);
						}

						char *charset;


						//if (doc->mime_type == NULL || doc->mime_type == MIME_UNKNOWN)
						if (doc->mime_type == MIME_UNKNOWN)
							doc->mime_type = meta->mime_type(NULL, content_type);


						// Get Charset
						(charset)=strchr(content_type, ';');

						if (charset == NULL)
							return CHARSET_UNKNOWN;
						else
						{
							(charset)++;

							while (*charset == ASCII_SP || (*charset != ASCII_EQ && *charset != ASCII_NUL))
								(charset)++;

							if (*charset != ASCII_NUL)
								(charset)++;
						}

						return http_charset(charset);

					}

				}

				break;

			case EVENT_END_TAG:

				// Verify if it's a /head, so the search must end
				if (!strcmp(tag.name, "head"))
					return CHARSET_UNKNOWN;
				break;
		}


	} // End While(1)


	return CHARSET_UNKNOWN;


}


//
// Name: parser_init
//
// Description:
//   Initializes the auxiliary vars of the parsers
//

void parser_init(void)
{
	bool index_status = false;

	if (showlanguages == true && debugonly == true)
		index_status = et.index_setup ((const size_t)1, true); // min_word_len == 1
	else
		index_status = et.index_setup ((const size_t)1, false); // min_word_len == 1

	assert (index_status == true);

	cerr << "Initializing mappings:" << endl << "discard_content, ";

	// Can be set to false for better speed, but less reliability
	// while discarding tags
	bool double_check_kept_markup = false;

	/* We don't want to loose text accidentaly */
	discard_content.check_matches = true;
	perfhash_create(&(discard_content), CONF_GATHERER_DISCARD_CONTENT);

	cerr << "keep tags, ";
	keep_tag.check_matches = double_check_kept_markup;
	perfhash_create(&(keep_tag), CONF_GATHERER_KEEP_TAG);

	cerr << "keep attributes, ";
	keep_attribute.check_matches = double_check_kept_markup;
	perfhash_create(&(keep_attribute), CONF_GATHERER_KEEP_ATTRIBUTE);

	cerr << "accepted protocols, ";
	accept_protocol.check_matches = true;
	perfhash_create(&(accept_protocol), CONF_SEEDER_LINK_ACCEPT_PROTOCOL);

	cerr << "keep special domains, ";
	keep_special.check_matches = true;
	perfhash_create(&(keep_special), CONF_COLLECTION_IT_SPECIAL_DOMAINS);

	cerr << "extensions to ignore, ";
	extensions_ignore.check_matches = true;
	perfhash_create(&(extensions_ignore), CONF_SEEDER_LINK_EXTENSIONS_IGNORE);

	cerr << "extensions to log, ";
	extensions_log.check_matches = true;
	perfhash_create(&(extensions_log), CONF_SEEDER_LINK_EXTENSIONS_LOG);

	cerr << "extensions to stat, ";
	extensions_stat.check_matches = true;
	perfhash_create(&(extensions_stat), CONF_SEEDER_LINK_EXTENSIONS_STAT);

	cerr << "extensions to dynamic, ";
    extensions_dynamic.check_matches = true;
    perfhash_create( &(extensions_dynamic), CONF_SEEDER_LINK_DYNAMIC_EXTENSION );

	cerr << "link attributes, ";
	parser_init_link_attributes(CONF_GATHERER_LINK_ATTRIBUTE);

	cerr << "domain suffixes, ";
    domain_suffixes = string_list_create(CONF_SEEDER_LINK_ACCEPT_DOMAIN_SUFFIXES);

	cerr << "[reject patterns] ";
	tokenizeToRegex(CONF_SEEDER_REJECTPATTERNS, &reject_patterns);

	cerr << "[sessionid variables] ";
	char sessionids_cpy[MAX_STR_LEN];
	assert(strlen(CONF_SEEDER_SESSIONIDS) < MAX_STR_LEN);
	strcpy(sessionids_cpy, CONF_SEEDER_SESSIONIDS);
	tokenizeToRegex(sessionids_cpy, &sessionid_patterns);
	sessionid_variables = tokenizeToTable(CONF_SEEDER_SESSIONIDS, &(sessionid_variables_count));
	
	// legge il file dei domini da salvare
	pwl = CBALLOC(char *, NEW, NUMROWS); // per creare un puntatore ad array bidimensionale occorre lavorare con puntatori di puntatori (ad array finali)
	pbl = CBALLOC(char *, NEW, NUMROWS); // per creare un puntatore ad array bidimensionale occorre lavorare con puntatori di puntatori (ad array finali)
	pgw = CBALLOC(char *, NEW, MAX_GOODWORDS); // puntatore di puntatore ad array per contenere le goodwords

	if (CONF_GATHERER_DOMAIN_USEWHITELIST)
	{
		cerr << "[loading domains in whitelist] ";
		unsigned int length;
		char *wlinbuf;

		ifstream inFile;  //input file stream variable

		inFile.open(CONF_GATHERER_DOMAIN_WHITELIST); //open the input file (same of seeder argument)

		if (inFile)
		{
			// posiziona in cursore alla fine del file per rilevarne la lunghezza per poi riposizionarlo all'inizio:
			inFile.seekg (0, ios::end);
			length = inFile.tellg();
			inFile.seekg (0, ios::beg);

			// alloca la memoria del wlinbuf:
			wlinbuf = CBALLOC(char, NEW, (length + 1));

			// legge i dati in un unico blocco:
			inFile.read (wlinbuf,length);
			wlinbuf[length] = ASCII_NUL;

			//cout.write (wlinbuf,length);
			unsigned short nc = 0;
			unsigned short countslash = 0;

			char temparray[MAX_STR_LEN] = {ASCII_NUL};

			//copio le parole contenute in CONF_GATHERER_DOMAIN_GOODWORDS e le inserisco nel puntatore di puntatori pgw
			for (unsigned int i = 0; i < strlen(CONF_GATHERER_DOMAIN_GOODWORDS); i++)
			{
				if (CONF_GATHERER_DOMAIN_GOODWORDS[i] != ASCII_SP)
					temparray[nc++] = CONF_GATHERER_DOMAIN_GOODWORDS[i];
				else
				{
					pgw[nrgw]= CBALLOC(char, NEW, (nc + 1));
					strncpy(pgw[nrgw], temparray, nc);
					pgw[nrgw][nc] = ASCII_NUL;
					memset(temparray, ASCII_NUL, nc);
					countslash = 0;
					nrgw++;
					nc = 0;
				}
	
				if (i == (strlen(CONF_GATHERER_DOMAIN_GOODWORDS) - 1))
				{
					pgw[nrgw]= CBALLOC(char, NEW, (nc + 1));
					strncpy(pgw[nrgw], temparray, nc);
					pgw[nrgw][nc] = ASCII_NUL;
					memset(temparray, ASCII_NUL, nc);
					countslash = 0;
					nrgw++;
					nc = 0;
				}

				if (nrgw >= MAX_GOODWORDS)
				{
					cerr << RED << "parser_init WARNING: Too much good words. Discarded those excess!" << NOR << endl;
					break;
				}
			}

			nc = 0;
			memset(temparray, ASCII_NUL, MAX_STR_LEN);

			//copio i dati del file ad il puntatore di puntatori pwl
			for (unsigned int i = 0; i < length; i++)
			{
				if (i == (length - 1))
				{
					temparray[nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti
					countslash = 0;
					// Il dominio non contiene goodwords (perchè non contiene una determinata parola chiave) allora
					// inseriscilo nell'array bidimensionale (che in effetti è un puntatore di puntatori)
					if (checkgword(temparray) == false)
					{
						pwl[nrwl]= CBALLOC(char, NEW, (nc + 1));
						strncpy(pwl[nrwl], temparray, nc);
						pwl[nrwl][nc] = ASCII_NUL;
						memset(temparray, ASCII_NUL, nc);
						nrwl++;
					}
					nc = 0;
				}
				else if (wlinbuf[i] != ASCII_NL)
				{
					if (wlinbuf[i] == ASCII_SL)
						countslash++;
					else if (countslash == 2 && wlinbuf[i] != ASCII_SP)
							temparray[nc++] = wlinbuf[i];
				}
				else
				{
					temparray[nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti
					countslash = 0;

					if (nc == 0)
						die("parser_init: Missing protocol prefixes in whitelist file?");

					// Il dominio non contiene goodwords (perchè non contiene una determinata parola chiave) allora
					// inseriscilo nell'array bidimensionale (che in effetti è un puntatore di puntatori)
					if (checkgword(temparray) == false)
					{
						pwl[nrwl]= CBALLOC(char, NEW, (nc + 1));
						strncpy(pwl[nrwl], temparray, nc);
						pwl[nrwl][nc] = ASCII_NUL;
						memset(temparray, ASCII_NUL, nc);
						nrwl++;
					}
					nc = 0;
				}

				if (nrwl >= NUMROWS)
				{
					cerr << RED << "parser_init WARNING: Too much words in white list. Discarded those excess!" << NOR << endl;
					break;
				}
			}

			inFile.close();
			delete [] wlinbuf;
			wlinbuf = NULL;
		}
		else
			die("parser_init: error file %s not found!", CONF_GATHERER_DOMAIN_WHITELIST);;
	}

	// leggo il file dei domini in blacklist
	if (CONF_GATHERER_DOMAIN_BLACKLIST != NULL)
	{
		unsigned int length;
		char *blinbuf;

		ifstream inFile;  //input file stream variable

		inFile.open(CONF_GATHERER_DOMAIN_BLACKLIST); //open the input file (same of seeder argument)

		if (inFile)
		{
			// posiziona in cursore alla fine del file per rilevarne la lunghezza per poi riposizionarlo all'inizio:
			inFile.seekg (0, ios::end);
			length = inFile.tellg();
			inFile.seekg (0, ios::beg);

			// alloca la memoria del blinbuf:
			blinbuf = CBALLOC(char, NEW, (length + 1));

			// legge i dati in un unico blocco:
			inFile.read (blinbuf,length);
			blinbuf[length] = ASCII_NUL;

			//cout.write (blinbuf,length);
			unsigned short nc = 0;
			unsigned short countslash = 0;

			char temparray[MAX_STR_LEN] = {ASCII_NUL};

			nc = 0;

			//copio i dati del file ad il puntatore di puntatori pbl
			for (unsigned int i = 0; i < length; i++)
			{
				if (i == (length - 1))
				{
					temparray[nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti
					countslash = 0;
					pbl[nrbl]= CBALLOC(char, NEW, (nc + 1));
					strncpy(pbl[nrbl], temparray, nc);
					pbl[nrbl][nc] = ASCII_NUL;
					memset(temparray, ASCII_NUL, nc);
					nrbl++;
					nc = 0;
				}
				else if (blinbuf[i] != ASCII_NL)
				{
					if (blinbuf[i] == ASCII_SL)
						countslash++;
					else if (countslash == 2 && blinbuf[i] != ASCII_SP)
							temparray[nc++] = blinbuf[i];
				}
				else
				{
					temparray[nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti
					countslash = 0;
					pbl[nrbl]= CBALLOC(char, NEW, (nc + 1));
					strncpy(pbl[nrbl], temparray, nc);
					pbl[nrbl][nc] = ASCII_NUL;
					memset(temparray, ASCII_NUL, nc);
					nrbl++;
					nc = 0;
				}

				if (nrbl >= NUMROWS)
				{
					cerr << RED << "parser_init WARNING: Too much words in black list. Discarded those excess!" << NOR << endl;
					break;
				}
			}
			inFile.close();
			delete [] blinbuf;
			blinbuf = NULL;
		}
		else
			die("parser_init: error file %s not found!", CONF_GATHERER_DOMAIN_BLACKLIST);
	}


	// 
	partial_path = CBALLOC(char *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	number_lines_download = CBALLOC(unsigned short, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	number_lines_log = CBALLOC(unsigned short, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	adjacency_list_new_link = CBALLOC(bool, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	adjacency_list_length = CBALLOC(unsigned int, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	adjacency_list = CBALLOC(out_link_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		adjacency_list[i] = CBALLOC(out_link_t, CALLOC, LINK_MAX_OUTDEGREE);

	cerr << "done." << endl;
}

//
// Name: parser_save_extensions_stats
//
// Description:
//   Saves the extensions that we need statistics about
//

void parser_save_extensions_stats(FILE *links_stat) {

	map<string,docid_t>::iterator extensions_it;

	for(extensions_it = count_extensions_stat.begin(); extensions_it != count_extensions_stat.end(); extensions_it++)
		if (debugonly == false)
			fprintf(links_stat, "%lu %s\n", (unsigned long int)(*extensions_it).second, ((*extensions_it).first).c_str());
}

//
// Name: parser_init_link_attributes
//
// Description:
//   Initialize several mapings regarding attributes that are links
//   in certain html elements.
//
// Input:
//   str - string containing configuration for linkattributes
// 

void parser_init_link_attributes(char *str)
{
	if (str == NULL)
		return;

	char *s = strtok(str,CONF_LIST_SEPARATOR);

	while (s != NULL)
	{
		char tagname[MAX_STR_LEN];
		char attname[MAX_STR_LEN];
		char caption[MAX_STR_LEN];

		uint i;
		uint j;

		// Copy the tag name
		j = 0;
		for(i=0; s[i]!=ASCII_SL; i++,j++) {
			assert(s[i]!=ASCII_NUL);
			tagname[j] = s[i];	
		}
		tagname[j] = ASCII_NUL;
		i++;

		// Copy the link attribute name
		j = 0;
		for(;s[i]!=ASCII_SL;i++,j++) {
			assert(s[i]!=ASCII_NUL);
			attname[j] = s[i];
		}
		attname[j] = ASCII_NUL;
		i++;

		// Copy the caption attribute
		j = 0;
		for(;s[i]!=ASCII_NUL && s[i]!='+';i++,j++) {
			caption[j] = s[i];
		}
		caption[j] = ASCII_NUL;


		is_link[tagname] = true;
		link_attribute[tagname] = attname;
		link_caption[tagname] = caption;

		// Check that the tag is preserved
		if (! perfhash_check(&(keep_tag), tagname)) {
			cerr << endl;
			cerr << "Error! failed to found " << tagname << " in tags: " << CONF_GATHERER_KEEP_TAG << endl;
			die("Tag for link discovery is not preserved");
		}

		// Check that the attributes are preserved
		if (! perfhash_check(&(keep_attribute), attname)) {
			cerr << endl;
			cerr << "Error! failed to found " << attname << " in attributes: " << CONF_GATHERER_KEEP_ATTRIBUTE << endl;
			die("Attribute for link discovery is not preserved");
		}
		if (! perfhash_check(&(keep_attribute), caption)) {
			cerr << endl;
			cerr << "Error! failed to found " << caption << " in attributes: " << CONF_GATHERER_KEEP_ATTRIBUTE << endl;
			die("Attribute for link discovery is not preserved");
		}

		if (s[i] == '+') {
			is_link_with_content[tagname] = true;
		}
		s = strtok(NULL,CONF_LIST_SEPARATOR);
	}
	return;
}

//
// Name: parser_analyze_link
//
// Description:
//   Analyze a link
//
// Input:
//   server - server structure
//   href - destination of link
//   caption - text of link
//

void parser_analyze_link(starter_t *starter, siteid_t serverid, char *href, char *caption, double rel_pos, em_tag_t tag, char *base)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);
	instance_t inst = starter->inst;

	//////////////////////
	//author heitor@nic.br
	//verify if the site belongs to the domain.
	//if the site isn't new and don't belongs to the domain, it means it was included by a redirect that only
	//the first page must be downloaded without follow links.
	if (starter->testing == false && string_list_suffix(domain_suffixes, server->hostname) == false)
		return;

	doc_t *doc = server->pages->doc;
	assert(server->pages->buffer_links_download != NULL);

	if (server->pages->bld_offset > 0)
		assert(server->pages->buffer_links_download[(server->pages->bld_offset - 1)] == ASCII_NL);

	char *pbuffer_links_download = &server->pages->buffer_links_download[server->pages->bld_offset];
	char *pbuffer_links_log = &server->pages->buffer_links_log[server->pages->bll_offset];
	size_t bld_space = (server->pages->bld_size - server->pages->bld_offset);
	size_t bll_space = (server->pages->bll_size - server->pages->bll_offset);

	// Reduce any %xx escape sequences to the characters they represent
	// dir/%7ejsmith -> dir/~jsmith
	unescape_url(href);

	char *_caption = caption;

	assert(doc != NULL && href != NULL);

	string path = server->pages->path;
	string site = server->hostname;

	size_t hreflen = strlen(href);
	unsigned char lcbu_len = strlen(LINK_CAPTION_BASE_URL);

	// As raccomanded by RFC 1808 section 2.4.3 if href begin with double slash (or more for us)
	// href is considerer as external link
	if (hreflen > 3 && (strncmp(href, "//", 2) == 0))
	{
		unsigned short s = 2;

		// skip more slash
		while (href[s] != ASCII_NUL && href[s] == '/')
			s++;

		if (server->ssl == NULL) // anche se ininfluente si inserisce il tipo protocollo del sito
		{
			if (s == 7)
				strncpy(href, "http:", 5);
			else if (s < 7)
			{
				size_t d = (7 - s);

				for (unsigned short c = (hreflen + d); c > d; c--)
				{
					href[c] = href[c - d]; // shift values on rigth
				}

				hreflen += d;
				strncpy(href, "http://", (reserve - 1));
			}
			else
			{
				size_t d = (s - 7);

				for (unsigned short c = s; c < (hreflen + 1); c++)
				{
					href[c - d] = href[c]; // shift values on left
				}

				hreflen -= d;
				strncpy(href, "http:", 5);
			} 
		}
		else
		{
			if (s == reserve)
				strncpy(href, "https:", 6);
			else if (s < reserve)
			{
				size_t d = (reserve - s);

				for (unsigned short c = (hreflen + d); c > d; c--)
				{
					href[c] = href[c - d]; // shift values on rigth
				}

				hreflen += d;
				strncpy(href, "https://", reserve);
			}
			else
			{
				size_t d = (s - reserve);

            	for (unsigned short c = s; c < (hreflen + 1); c++)
				{
					href[c - d] = href[c]; // shift values on left
				}

				hreflen -= d;
				strncpy(href, "https:", 6);
			} 
		}
	}
	else if (hreflen > 8)
	{
		if ((strchr(href, '/') == NULL) && strncmp(href, "www.", 4) == 0) // www.pizza.com
		{
			size_t d = 7;

           	for (unsigned short c = (hreflen + d); c > (d - 1); c--)
			{
				href[c] = href[c - d]; // shift values on rigth
			}

			hreflen += d;
			strncpy(href, "http://", (reserve - 1));
		}
		else if (strncmp(href, "www.", 4) == 0) // www.pizza.com/receive/info.php
			return; // heuristic method to find href poorly written because must have protocol prefix and we want discard this
	}

	// skip href with annidate other href like:
	// http://www.site.com/wp-json/oembed/1.0/embed?url=http://www.site.com/page
	if (hreflen > 3)
	{
		char *p = strstr(href, "://");

		if (p != NULL)
			p += 3;

		if (p != NULL && strstr(p, "://") != NULL)
			return;
	}

	// pulisce href da eventuali caratteri 'invisibili/inutili' iniziali (quelli finali allo stato attuale non occorre eliminarli)
	unsigned short s = 0;

	while ((href[s] == ASCII_SP || href[s] == ASCII_NL || href[s] == ASCII_CR || href[s] == ASCII_TB) && s < ((hreflen / 2) + 2) && s < USHRT_MAX)
		s++;

	if (s == USHRT_MAX || s > (hreflen / 2))
		return; // troppi spazi iniziali in href. Ignorato

	if (s > 0)
		href = &(href[s]);
	// spazi iniziali

	hreflen = (hreflen - s);

	// Create a complete url source
	char _url[MAX_STR_LEN + MAX_DOMAIN_LEN + URLDDX_PATH_LEN + 8]; // la lunghezza 8 è relativa a 'https://'
	_url[0] = ASCII_NUL;

	if (server->ssl == NULL) // anche se ininfluente si inserisce il tipo protocollo del sito
		strcpy(_url, "http://");
	else
		strcpy(_url, "https://");

	strcat(_url, server->hostname);
	strcat(_url, "/");

	if (server->pages->src_path == NULL)
	{
		if (server->pages->path[0] == ASCII_SL)
			strcat(_url, &(server->pages->path[1]));
		else
			strcat(_url, server->pages->path);
	}
	else if (strlen(server->pages->src_path) > 0) // si tratta di una redirezione gestita nello stesso ciclo di harvesting, perciò
		strcat(_url, server->pages->src_path);	  // in seguito occorrerà verificare che il server->pages->src_path sia scritto secondo standard

	// Ignore some common cases

	// Migliorato il parsing dei nomi dominio
	char *phref = NULL; // Attenzione phref non deve essere liberato in quanto eventualmente serve solo per puntare il puntatore href

	bool local = true;

	if (href[0] == ASCII_NU) // Local reference to the same page, ignore (#)
		return;
	else if (href[0] == ASCII_QM) // Begin with question mark (experimental)
	{
		size_t path_question_mark_offset = path.find("?");

		if (path_question_mark_offset == string::npos)
		{
			size_t _hreflen = hreflen;
			size_t path_size = path.size();
			hreflen += path_size;

			// shift href on rigth including nul char
			for (size_t o = 0; o <= _hreflen; o++)
			{
				href[(path_size + o)] = href[o];
			}

			href[0] = ASCII_NUL;

			// copy in empty space of href the path
			strncpy(href, path.c_str(), path_size);
		}
		else // convert ?lev=341 to path?lev=341
		{
			size_t _hreflen = hreflen;
			hreflen += path_question_mark_offset;

			// shift href on rigth including nul char
			for (size_t o = 0; o <= _hreflen; o++)
			{
				href[(path_question_mark_offset + o)] = href[o];
			}

			href[0] = ASCII_NUL;

			// copy in empty space of href the path excluding after it's question mark
			strncpy(href, path.c_str(), path_question_mark_offset);
		}
	}
	else if (href[0] != ASCII_SL && strchr(href,':') != NULL) // possible URL with protocol
	{
		unsigned short pos = 0;

		// caratteri ammessi al fine di specificare un protocollo secondo 'schema' rfc3986
		while (isalnum(href[pos]) || href[pos] == '+' || href[pos] == '-' || href[pos] == '.') pos++;

		size_t colon_pos = 0;

		while (href[colon_pos] != ':')
			colon_pos++;

		if (colon_pos > pos || colon_pos == 0)
			goto go_ahead; // secondo rfc3986 lo 'schema' non identifica un URI assoluto con protocollo, ma un _url relativo

		char *protocol = CBALLOC(char, MALLOC, (colon_pos + 1));
		assert(protocol != NULL);

		strncpy(protocol, href, colon_pos);

		protocol[colon_pos] = ASCII_NUL;

		// Ogni protocollo non consentito è ignorato.
		// N.B. Il crawler è sviluppato per funzionare con protocolli http e https
		if (! perfhash_check(&(accept_protocol), protocol))
		{
			free (protocol);
			return;
		}

		free (protocol);

		// Dopo il pattern '://' occorre verificare che il nome del sito sia valido
		// Si possono utilizzare tutte le cifre (0-9), le lettere (a-z) (ASCII),  il trattino (-)
		// e i caratteri  à, â, ä, è, é, ê, ë, ì, î, ï, ò, ô, ö, ù, û, ü, æ, oe, ç, ÿ, β
		// (NON ASCII ma convertiti in ascii attraverso la codifica IDN allo stato attuale non supportati dal crawler).
		// Il nome non può iniziare o terminare con il simbolo del trattino (-) e i primi quattro caratteri
		// I primi 4 caratteri con sequenza sequenza "xn--" nel dominio di secondo livello sono riservati alla codifica IDN di un nome a dominio.
		// I label devono essere almeno DUE occorre perciòsia presente ALMENO un punto separatore.
		char *psite = NULL;

		size_t offset = 0;

		if (strncmp(&(href[colon_pos]),"://", 3) == 0)
		{
			psite = &(href[(colon_pos + 3)]);

			bool sitename_have_dot = false;

			// Il nome non può iniziare con il simbolo score (-) o con il dot (.)
			if (psite[offset] == ASCII_HM || psite[offset] == ASCII_US || psite[offset] == ASCII_DT)
				return;

			while (psite[offset] != ASCII_SL && psite[offset] != ASCII_NUL)
			{
				if (isspace(psite[offset])) // Ha spazi o newline, ignorato
					return;

				// subito prima, o dopo, ogni punto non possono esserci simboli score o underscore
				if (psite[offset] == ASCII_DT)
				{
					if (offset > 1)
					{
						if (psite[(offset - 1)] == ASCII_HM || psite[(offset - 1)] == ASCII_US)
							return;
					}

					if (psite[(offset + 1)] == ASCII_DT || psite[(offset + 1)] == ASCII_HM || psite[(offset + 1)] == ASCII_US)
						return;
				}

				// subito dopo, ogni punto non possono esistere la sequenza "xn--" perchè allora si troverebbe all'inizio del nome dominio
				//if(psite[offset] == '.' && strncmp(&(psite[(offset - 1)]), "xn--", 4) == 0)
				//	return;

				if (offset > 1 && psite[offset] == ASCII_DT)
					sitename_have_dot = true;
				else if (psite[offset] != ASCII_HM && (! isdigit(psite[offset])) && (! isalpha(psite[offset])))// Ha caratteri non consentiti, ignorato
					return;

				offset++;
			};

			if (offset < 5 || sitename_have_dot == false)
				return;

			if (psite[(offset - 1)] == ASCII_HM || psite[(offset - 1)] == ASCII_SC || psite[(offset - 1)] == ASCII_DT)
				return;

			if (psite[(offset - 2)] == ASCII_HM || psite[(offset - 2)] == ASCII_SC || psite[(offset - 2)] == ASCII_DT)
				return;

			if (psite[offset] != ASCII_NUL && psite[(++offset)] != '\0')
				phref = &(psite[offset]);

			local = false;
		}
		else
			return; // Url assoluto non valido
	}
	else if (strchr(href, ASCII_AT) != NULL) // Malformed e-mail URL, ignore
		return;

	go_ahead: // not valid protocol (_url local)

	// Check the href (no spaces), cut at first hash mark
	if (local == true) // nel caso href non contenga il protocollo
	{
		for(uint i = 0; i <=strlen(href); i++)
		{
			if (isspace(href[i]))
				return; // Has spaces or newlines, ignore
			if (href[i] == ASCII_NU) // '#'
			{
				href[i] = ASCII_NUL;
				break;
			}
		}
	}
	else // nel caso href contenga il protocollo inutile controllare il nome del sito in quanto già controllato a monte
	{
		if (phref != NULL)
			for(uint i = 0; i <=strlen(phref); i++)
			{
				if (isspace(phref[i]))
					return; // Has spaces or newlines, ignore
				if (phref[i] == '#')
				{
					phref[i] = ASCII_NUL;
					break;
				}
		}
	}
	// end patch

	// Put the caption in one line and skip first spaces
	bool sc = true;

	for(uint i=0; i<=strlen(caption); i++)
	{
		if (isspace(caption[i]))
		{
			if (sc == true)
				_caption++;

			caption[i] = ASCII_SP;
		}
		else
			sc = false;
	}

	// Look for the type of extension
	char extension[MAX_STR_LEN];
	extension[0] = ASCII_NUL;
	extension_type_t extension_type = EXTENSION_NORMAL;

	if (local == true)
		extension_type = parser_check_extension(href, extension);
	else if (local == false && phref != NULL)
		extension_type = parser_check_extension(phref, extension);

	int written = 0;
	int _written = 0;
	int __written = 0;
	doc_hash_t hash_href = 0;

	if (server->pages->doc->duplicate_of > 0)
		return;

	siteid_t resolved_siteid = 0;
	bool need_reinsert = true;

	reinsert:

	if (need_reinsert == false)
		return;

	if (extension_type == EXTENSION_NORMAL)
	{
		if (strcmp(_caption, LINK_CAPTION_FORBIDDEN) != 0)
		{
			// We skip normal links that, by change, have the same caption that we use for marking
			// forbidden links in robots.txt files
			// Copy the href site name
			char hrefsitename[MAX_STR_LEN] = {ASCII_NUL};

			// Se cbot.conf contiene goodwords e il link contiene '://'
			if (local == true)
			{
				unsigned short i = 0;
				unsigned int p = 0;
				unsigned short countslash = 0;

				for(i = 0; _url[i] != ASCII_NUL; i++)
				{
					if (_url[i] == ASCII_SL)
						countslash++;
					else if (countslash == 2)
						hrefsitename[p++] = _url[i];
					else if (countslash == 3)
						break;
				}

				hrefsitename[p] = ASCII_NUL;
			}
			else
			{
				unsigned short i = 0;
				unsigned int p = 0;
				unsigned short countslash = 0;

				for(i = 0; href[i] != ASCII_NUL; i++)
				{
					if (href[i] == ASCII_SL)
						countslash++;
					else if (countslash == 2)
						hrefsitename[p++] = href[i];
					else if (countslash == 3)
						break;
				}

				hrefsitename[p] = ASCII_NUL;
			}


			const char *fqdn = NULL;

			// Check if the site has a normal tld
			char top_level_domain[MAX_STR_LEN];

			url->get_lowercase_extension(hrefsitename, top_level_domain);

			// Check if it has a TLD
			if (strlen(top_level_domain) == 0)
				return;

			// Verifico che almeno fqdn possa almeno avere un nome simile ad un dominio
			if (strlen(hrefsitename) > 2)
				fqdn = hrefsitename;

			// Invalid hrefsitename (fqdn MUST contain dot)
			if (fqdn == NULL)
				return;

			char *domain = NULL;
			char *special_domain = NULL;
			char *real_domain = NULL;

			// dominio che comprende le modifiche nel caso sia speciale
			fqdn_to_domain(keep_special, (char *)fqdn, domain, special_domain);

			if (special_domain)
			{
				free(domain);
				real_domain = special_domain;
			}
			else
				real_domain = domain;

			// Reject certains hrefs
			if (regexec(&reject_patterns, href, 0, NULL, 0) == 0)
			{
				free(real_domain);
				return;
			}

			// Remove sessionids in URLs
			if (regexec(&sessionid_patterns, href, 0, NULL, 0) == 0) {
				for(int i=0; i<sessionid_variables_count; i++) {
					url->remove_variable(href, sessionid_variables[i]);
				}
			}

			// Remove sessionids, heuristic
			url->remove_sessionids_heuristic(href);

			written = 0;
			_written = 0;
			__written = 0;

			// If href have nothing quit
			if (strlen(href) == 0)
			{
				free(real_domain);
				return;
			}

			// nel caso 'server->pages->src_path sia diverso da NULL e ci sia un path del tipo 'home/index.pl' viene estrapolato 'home/'.
			// Occorre effettuare questa operazione perchè cbot-seeder non può sapere che il sito http://www.nomesito.it/ in effetti viene rediretto
			// al link http://www.nomesito.it/home/index.pl nello stesso ciclo di harvesting, perciò i link relativi
			// dentro la pagina, per cbot-seeder non sono relativi a http://www.nomesito.it/home/ ma a http://www.nomesito.it/.
			// In questo caso (e solo in questo) il problema viene risolto assegnandoli i link assoluti con già preposto la directory 'home'.
			if (pgw[0] == NULL)
			{
				if (debugonly == false && bld_space > 0)
				{
					written = snprintf(pbuffer_links_download, bld_space, "%lu %d %d ", (unsigned long int)doc->docid, (int)(100.0*(1 - rel_pos)), tag);

					if (written >= 0)
						((bld_space >= (size_t)written) ? (bld_space -= (size_t)written) : bld_space = 0);
					else
						bld_space = 0;
				}

				_written = written;
				__written = written;

				if (bld_space > 0)
				{
					if (local == true)
					{
						if (href[0] != ASCII_SL)
						{
							size_t bl = 0;

							if (base != NULL)
								bl = strlen(base);

							char lc;

							if (bl > 0)
								lc = base[(bl -1)];

							if (bl > 0 && strstr(base, LINK_CAPTION_BASE_URL) != NULL && (lc == ASCII_MA || lc == ASCII_SL))
							{
								if (debugonly == false)
								{
									if (bl == 10)
										written += snprintf(pbuffer_links_download + written, bld_space, "%c%s %s\n", ASCII_SL, href, _url);
									else
										written += snprintf(pbuffer_links_download + written, bld_space, "%c%s%s %s\n", ASCII_SL, &(base[lcbu_len]), href, _url);
								}
							}
							else if (server->pages->doc->mime_type == MIME_REDIRECT && href[0] != ASCII_SL)
							{
								if (debugonly == false)
								{
									if (server->pages->redirect_is_relative == false)
										written += snprintf(pbuffer_links_download + written, bld_space, "%s%s\n", _url, href);
									else
									{
										char *__url = CBALLOC(char, MALLOC, (strlen(_url) + 1)); // la lunghezza 8 è relativa a 'https://'
										__url[0] = ASCII_NUL;
										strcpy(__url, _url);
										char *p = strrchr(__url, ASCII_SL);
										p[0] = ASCII_NUL;
										written += snprintf(pbuffer_links_download + written, bld_space, "%s/%s %s\n", __url, href, _url);
										free(__url);
									}
								}
							}
							else if (server->pages->src_path != NULL && href[0] != ASCII_SL)
							{
								if (debugonly == false)
								{
									if (partial_path[inst] == NULL)
										written += snprintf(pbuffer_links_download + written, bld_space, "%s %s\n", href, _url);
									else
									{
										if (server->pages->redirect_with_invalid_path == true)
										{
											free(real_domain);
											return;
										}

										written += snprintf(pbuffer_links_download + written, bld_space, "%c%s%s %s\n", ASCII_SL, partial_path[inst], href, _url);
									}
								}
							}
							else // nel caso estremo si lascia comunque il link relativo
								if (debugonly == false)
									written += snprintf(pbuffer_links_download + written, bld_space, "%s %s\n", href, _url); 
						}
						else if (debugonly == false)
								written += snprintf(pbuffer_links_download + written, bld_space, "%s %s\n", href, _url);
					}
					else if (debugonly == false)
						written += snprintf(pbuffer_links_download + written, bld_space,"%s %s\n", href, _caption);

					// If success written check for robots and/or deny politics rules 
					if (starter->testing == false && written > __written &&	(server->pages->bld_offset + written) <= server->pages->bld_size)
					{
						if (CONF_SEEDER_ADD_ROBOTSTXT == true)
							parser_check_robotstxt(server, local, written, __written, resolved_siteid);
						else
						{
							assert(server->pages->buffer_links_download != NULL);
						
							if (server->pages->bld_offset > 0)
								assert(server->pages->buffer_links_download[(server->pages->bld_offset - 1)] == ASCII_NL);
						
							char *pbuffer_links_download = &server->pages->buffer_links_download[server->pages->bld_offset];
						
							assert(pbuffer_links_download != NULL);
						
							resolved_siteid = 0;
							urlddx_status_t url_status = URLDDX_NOT_FOUND;
						
							if (local == false)
							{
								char *p = strstr(&pbuffer_links_download[__written], "://");
						
								if (p != NULL)
								{
									int ___written = __written;

									___written += ((p - &pbuffer_links_download[___written]) + 3);
						
									int c = ___written;

									while (pbuffer_links_download[___written] != ASCII_NUL &&
										   pbuffer_links_download[___written] != ASCII_SL &&
										   pbuffer_links_download[___written] != ASCII_SP)
										___written++;

									char *sitename = CBALLOC(char, MALLOC, ((___written - c) + 1));
						
									strncpy(sitename, &pbuffer_links_download[c], (___written - c));
						
									sitename[(___written - c)] = ASCII_NUL;
						
									url_status = url->resolve_site(sitename, &resolved_siteid, NOT_DEFINED);

									///////////////////////////
									//author heitor@nic.br
									//compares the site with the domain list.
									//Modified to download pages targeted by  redirects.
									//it do not downlaod page from redirects of redirects
									if (HTTP_IS_REDIRECT(server->pages->doc->http_status))
									{	// if source TLD is already outside our list, any redirect to other outside TLD is denied
										if (string_list_suffix(domain_suffixes, server->hostname) == false && string_list_suffix(domain_suffixes, sitename) == false)
										{
											free(sitename);

											server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
						
											written = __written;
						
											return;
										}
									}
									else if (string_list_suffix(domain_suffixes, sitename) == false)
									{
										free(sitename);

										server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
						
										written = __written;
						
										return;
									}

									free(sitename);
								}
							}
							else
								url_status = URLDDX_EXISTENT;
						
							// if new site we cannot know at prior whats urls are forbiddens
							// but only seeder can help us
							if (url_status == URLDDX_EXISTENT)
							{
								// find where rules are founds
								if (resolved_siteid > 0 && resolved_siteid != server->site->siteid)
								{
									// If resolved siteid is know but denied, skip his link
									if (meta->site_option_get(resolved_siteid, SITE_OPT_DENY, true) == METADDX_OK)
									{
										server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
						
										written = __written;
						
										return;
									}
								}
							}
						}
					}
				}
				else
					server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;

			}
			else
			{
				// si accettano solo i links che puntano allo stesso sito sorgente o che contengano determinate parole chiave - Opzione CONF_GATHERER_DOMAIN_USEWHITELIST
				if (debugonly == false && bld_space > 0)
				{
					written = snprintf(pbuffer_links_download, bld_space, "%lu %d %d ", (unsigned long int)doc->docid, (int)(100.0*(1 - rel_pos)), tag);

					if (written >= 0)
						((bld_space >= (size_t)written) ? (bld_space -= (size_t)written) : (bld_space = 0));
					else
						bld_space = 0;
				}

				_written = written;
				__written = written;

				if (bld_space > 0)
				{
					if (local == true && (checkname(fqdn, pbl, nrbl, false) == false && checkname(real_domain, pbl, nrbl, false) == false))
					{
						if (href[0] != ASCII_SL)
						{
							size_t bl = 0;

							if (base != NULL)
								bl = strlen(base);

							char lc = ASCII_NUL;

							if (bl > 0)
								lc = base[(bl -1)];

							if (bl > 0 && strstr(base, LINK_CAPTION_BASE_URL) != NULL && (lc == ASCII_MA || lc == ASCII_SL))
							{
								if (debugonly == false)
								{
									if (bl == 10)
										written += snprintf(pbuffer_links_download + written, bld_space, "%c%s %s\n", ASCII_SL, href, _url);
									else
										written += snprintf(pbuffer_links_download + written, bld_space, "%c%s%s %s\n", ASCII_SL, &(base[lcbu_len]), href, _url);
								}
							}
							else if (server->pages->doc->mime_type == MIME_REDIRECT && href[0] != ASCII_SL)
							{
								if (debugonly == false)
								{
									if (server->pages->redirect_is_relative == false)
										written += snprintf(pbuffer_links_download + written, bld_space, "%s%s\n", _url, href);
									else
									{
										char *__url = CBALLOC(char, MALLOC, (strlen(_url) + 1)); // la lunghezza 8 è relativa a 'https://'
										__url[0] = ASCII_NUL;
										strcpy(__url, _url);
										char *p = strrchr(__url, ASCII_SL);
										p[0] = ASCII_NUL;
										written += snprintf(pbuffer_links_download + written, bld_space, "%s/%s %s\n", __url, href, _url);
										free(__url);
									}
								}
							}
							else if (server->pages->src_path != NULL && href[0] != ASCII_SL)
							{
								if (debugonly == false)
								{
									if (partial_path[inst] == NULL)
										written += snprintf(pbuffer_links_download + written, bld_space, "%s %s\n", href, _url);
									else
									{
										if (server->pages->redirect_with_invalid_path == true)
										{
											free(real_domain);
											return;
										}

										written += snprintf(pbuffer_links_download + written, bld_space, "%c%s%s %s\n", ASCII_SL, partial_path[inst], href, _url);
									}
								}
							}
							else // nel caso estremo si lascia comunque il relativo
								if (debugonly == false)
									written += snprintf(pbuffer_links_download + written, bld_space, "%s %s\n", href, _url);
						}
						else if (debugonly == false)
								written += snprintf(pbuffer_links_download + written, bld_space, "%s %s\n", href, _url);

					}
					else if (local != true && fqdn != NULL &&
							(checkname(fqdn, pwl, nrwl, true) == true || checkname(real_domain, pwl, nrwl, true) == true) &&
							(checkname(fqdn, pbl, nrbl, false) == false && checkname(real_domain, pbl, nrbl, false) == false))
					{
						if (debugonly == false)
							written += snprintf(pbuffer_links_download + written, bld_space, "%s %s\n", href, _caption);
					}

					// If success written check for robots and/or deny politics rules 
					if (starter->testing == false && written > __written &&	(server->pages->bld_offset + written) <= server->pages->bld_size)
					{
						if (CONF_SEEDER_ADD_ROBOTSTXT == true)
							parser_check_robotstxt(server, local, written, __written, resolved_siteid);
						else
						{
							assert(server->pages->buffer_links_download != NULL);
						
							if (server->pages->bld_offset > 0)
								assert(server->pages->buffer_links_download[(server->pages->bld_offset - 1)] == ASCII_NL);
						
							char *pbuffer_links_download = &server->pages->buffer_links_download[server->pages->bld_offset];
						
							assert(pbuffer_links_download != NULL);
						
							resolved_siteid = 0;
							urlddx_status_t url_status = URLDDX_NOT_FOUND;
						
							if (local == false)
							{
								char *p = strstr(&pbuffer_links_download[__written], "://");
						
								if (p != NULL)
								{
									int ___written = __written;

									___written += ((p - &pbuffer_links_download[___written]) + 3);
						
									int c = ___written;

									while (pbuffer_links_download[___written] != ASCII_NUL &&
										   pbuffer_links_download[___written] != ASCII_SL &&
										   pbuffer_links_download[___written] != ASCII_SP)
										___written++;
						
									char *sitename = CBALLOC(char, MALLOC, ((___written - c) + 1));
						
									strncpy(sitename, &pbuffer_links_download[c], (___written - c));
						
									sitename[(___written - c)] = ASCII_NUL;
						
									url_status = url->resolve_site(sitename, &resolved_siteid, NOT_DEFINED);

									///////////////////////////
									//author heitor@nic.br
									//compares the site with the domain list.
									//Modified to download pages targeted by  redirects.
									//it do not downlaod page from redirects of redirects
									if (HTTP_IS_REDIRECT(server->pages->doc->http_status))
									{	// if source TLD is already outside our list, any redirect to other outside TLD is denied
										if (string_list_suffix(domain_suffixes, server->hostname) == false && string_list_suffix(domain_suffixes, sitename) == false)
										{
											free(sitename);

											server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
						
											written = __written;
						
											return;
										}
									}
									else if (string_list_suffix(domain_suffixes, sitename) == false)
									{
										free(sitename);

										server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
						
										written = __written;
						
										return;
									}

									free(sitename);
								}
							}
							else
								url_status = URLDDX_EXISTENT;
						
							// if new site we cannot know at prior whats urls are forbiddens
							// but only seeder can help us
							if (url_status == URLDDX_EXISTENT)
							{
								// find where rules are founds
								if (resolved_siteid > 0 && resolved_siteid != server->site->siteid)
								{
									// If siteid is know but denied, skip his link
									if (meta->site_option_get(resolved_siteid, SITE_OPT_DENY, true) == METADDX_OK) 
									{
										server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
						
										written = __written;
						
										return;
									}
								}
							}
						}
					}
				}
				else
					server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
			}

			free (real_domain);
		}
	}
	else if (extension_type == EXTENSION_LOG)
	{

		if (debugonly == false && bll_space > 0)
		{
			written = snprintf(pbuffer_links_log, bll_space, "%lu %d %d ", (unsigned long int)doc->docid, (int)(100.0*(1 - rel_pos)), tag);

			if (written >= 0)
				((bll_space >= (size_t)written) ? (bll_space -= (size_t)written) : (bll_space = 0));
			else
				bll_space = 0;
		}

		_written = written;

		if (bll_space > 0)
		{
			if (local == true)
			{
				if (href[0] != ASCII_SL)
				{
					size_t bl = 0;

					if (base != NULL)
						bl = strlen(base);

					char lc;

					if (bl > 0)
						lc = base[(bl -1)];

					if (bl > 0 && strstr(base, LINK_CAPTION_BASE_URL) != NULL && (lc == ASCII_MA || lc == ASCII_SL))
					{
						if (debugonly == false)
						{
							if (bl == 10)
								written += snprintf(pbuffer_links_log + written, bll_space, "%c%s %s\n", ASCII_SL, href, _url);
							else
								written += snprintf(pbuffer_links_log + written, bll_space, "%c%s%s %s\n", ASCII_SL, &(base[lcbu_len]), href, _url);
						}
					}
					else if (server->pages->doc->mime_type == MIME_REDIRECT && href[0] != ASCII_SL)
					{
						if (debugonly == false)
						{
							if (server->pages->redirect_is_relative == false)
								written += snprintf(pbuffer_links_log + written, bll_space, "%s%s\n", _url, href);
							else
							{
								char *__url = (char *) malloc ((strlen(_url) + 1) * sizeof(char)); // la lunghezza 8 è relativa a 'https://'
								__url[0] = ASCII_NUL;
								strcpy(__url, _url);
								char *p = strrchr(__url, ASCII_SL);
								p[0] = ASCII_NUL;
								written += snprintf(pbuffer_links_log + written, bll_space, "%s/%s %s\n", __url, href, _url);
								free(__url);
							}
						}
					}
					else if (server->pages->src_path != NULL && href[0] != ASCII_SL)
					{
						if (debugonly == false)
						{
							if (partial_path[inst] == NULL)
								written += snprintf(pbuffer_links_log + written, bll_space, "%s %s\n", href, _url);
							else
							{
								if (server->pages->redirect_with_invalid_path == true)
									return;

								written += snprintf(pbuffer_links_log + written, bll_space, "%c%s%s %s\n", ASCII_SL, partial_path[inst], href, _url);
							}
						}
					}
					else // nel caso estremo si lascia comunque il link relativo
						if (debugonly == false)
							written += snprintf(pbuffer_links_log + written, bll_space, "%s %s\n", href, _url); 
				}
				else
					if (debugonly == false)
						written += snprintf(pbuffer_links_log + written, bll_space, "%s %s\n", href, _url);
			}
			else
				if (debugonly == false)
					written += snprintf(pbuffer_links_log + written, bll_space,"%s %s\n", href, _caption);
		}
		else
			server->pages->buffer_links_log[server->pages->bll_offset] = ASCII_NUL;

	}
	else if (extension_type == EXTENSION_STAT)
	{
		// We count these items only if they are local links, because
		// as we use this for web characterization, we want to count
		// the number of say, images, INSIDE the collection
		if ((strlen(extension) > 0) && (strchr(href,':') == NULL))
			count_extensions_stat[extension]++;
		
	}
	else
		; // Ignore

	need_reinsert = false;

	auto delta = (size_t)(MAX_STR_LEN * 5);

	// salva nel buffer
	if (written > 0 && extension_type == EXTENSION_NORMAL)
	{
		if ((server->pages->bld_offset + written) <= server->pages->bld_size)
		{
			if (written > _written && pbuffer_links_download[(written - 1)] == ASCII_NL)
			{
				if (starter->testing == false && parser_analyze_line(starter, serverid, resolved_siteid) == -1)
					server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
				else
				{
					server->pages->bld_offset += written;
					number_lines_download[inst]++;
				}
			}
			else
				server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
		}
		else // skip last href and now memory is ready for next function's call
		{
			if (server->pages->bld_size <= server->pages->doc->raw_content_length)
			{
				const auto min_required_size = (const ssize_t)(server->pages->bld_offset + server->pages->bld_size + 1); // nul char see below

				char *p = CBREALLOC(char, ssize_t, server->pages->buffer_links_download, server->pages->bld_size, min_required_size, delta);

				if (p == NULL) need_reinsert = false;
				else
				{
					server->pages->buffer_links_download = p;
					server->pages->bld_size--; // after updated, must preserve space for nul char because see as only text buffer
					bld_space = (server->pages->bld_size - server->pages->bld_offset);
					pbuffer_links_download = &server->pages->buffer_links_download[server->pages->bld_offset];
					need_reinsert = true;
				}
			}

			server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
		}
	}
	else if (written > 0 && extension_type == EXTENSION_LOG)
	{
		if ((server->pages->bll_offset + written) <= server->pages->bll_size)
		{
			if (written > _written && pbuffer_links_log[(written - 1)] == ASCII_NL)
			{
				server->pages->bll_offset += written;
				number_lines_log[inst]++;
			}
			else
				server->pages->buffer_links_log[server->pages->bll_offset] = ASCII_NUL;
		}
		else // skip last href and now memory is ready for next function's call
		{
			if (server->pages->bll_size <= server->pages->doc->raw_content_length)
			{
				const auto min_required_size = (const ssize_t)(server->pages->bll_offset + server->pages->bll_size + 1); // nul char see below

				char *p = CBREALLOC(char, ssize_t, server->pages->buffer_links_log, server->pages->bll_size, min_required_size, delta);

				if (p == NULL) need_reinsert = false;
				else
				{
					server->pages->buffer_links_log = p;
					server->pages->bll_size--; // after updated, must preserve space for nul char because see as only text buffer
					bll_space = (server->pages->bll_size - server->pages->bll_offset);
					pbuffer_links_log = &server->pages->buffer_links_log[server->pages->bll_offset];
					need_reinsert = true;
				}
			}

			server->pages->buffer_links_log[server->pages->bll_offset] = ASCII_NUL;
		}
	}

	goto reinsert;

	// Blank both parts of the links, because for the next link
	// we don't know what are we going to get first (the href or the caption)

	return;
}

//
// Name: parser_analyze_link_sitemap
//
// Description:
//   Analyze a link
//
// Input:
//   doc - source document
//   href - destination of link
//   site - name of site
//   last_modified - timestamp of last modified
//   changefreq - interval of re-read document as specification sitemap.org
//   priority - priority of download document relative same site
//
bool parser_analyze_link_sitemap(starter_t *starter, siteid_t serverid, char *href, bool check_extension, time_t last_modified, sitemap_xml_changefreq_t changefreq, sitemap_xml_priority_t priority)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);
	instance_t inst = starter->inst;
	FILE *links_download = starter->links_download;

	doc_t *doc = server->pages->doc; // N.B. ci si riferisce al documento sitemap (documento sorgente)

	assert(doc != NULL);

	time_t now = time(NULL);

	if (doc->number_visits > 1 && check_extension == false)
	{
		// Gli href con changefreq impostato a 'NEVER' dopo la prima visita non vengono più aggiornati
		if (changefreq == NEVER)
			return false;

		// Gli url che non sono stati modificati dopo la data dell'ultima visita non vengono reinseriti nel file link_download
		if (changefreq == NONE && last_modified > (now - (time_t)CONF_MANAGER_MINPERIOD_ROBOTS_XML_VALID) && last_modified <= doc->last_visit && last_modified < now)
			return false;
	}

	assert(href != NULL);

	string path = server->pages->path;
	string site = server->hostname;

	size_t hreflen = strlen(href);

	size_t f = (hreflen - 1);
	while ((href[f] == ASCII_SP || href[f] == ASCII_NL || href[f] == ASCII_CR || href[f] == ASCII_TB)) f--; // elimina i caratteri 'invisibili/inutili' in coda

	hreflen = (f + 1);
	href[hreflen] = ASCII_NUL;

	// pulisce href da eventuali caratteri 'invisibili/inutili' iniziali (quelli finali allo stato attuale non occorre eliminarli)
	unsigned short s = 0;
	while ((href[s] == ASCII_SP || href[s] == ASCII_NL || href[s] == ASCII_CR || href[s] == ASCII_TB) && s < ((hreflen / 2) + 2) && s < USHRT_MAX) s++;

	if (s == USHRT_MAX || s > (hreflen / 2))
		return false; // troppi spazi iniziali in href. Ignorato

	if (s > 0)
		href = &(href[s]);
	// spazi iniziali

	hreflen = (hreflen - s); // anche se in seguito hreflen non serve è giusto sia però impostato al valore corretto

	// Ignore some common cases

	// Migliorato il parsing dei nomi dominio
	char *phref = NULL; // Attenzione phref non deve essere liberato in quanto eventualmente serve solo per puntare il puntatore href

	bool local = true;

	if (href[0] == '#') // Local reference to the same page, ignore
		return false;
	else if (href[0] != ASCII_SL && strchr(href,':') != NULL) // possible URL with protocol
	{
		unsigned short pos = 0;

		// caratteri ammessi al fine di specificare un protocollo secondo 'schema' rfc3986
		while (isalnum(href[pos]) || href[pos] == '+' || href[pos] == '-' || href[pos] == '.') pos++;

		size_t colon_pos = 0;

		while (href[colon_pos] != ':')
			colon_pos++;

		if (colon_pos > pos || colon_pos == 0)
			goto go_ahead; // secondo rfc3986 lo 'schema' non identifica un URI assoluto con protocollo, ma un url relativo

		char *protocol = (char *) malloc ((colon_pos + 1) * sizeof(char));

		strncpy(protocol, href, colon_pos);

		protocol[colon_pos] = ASCII_NUL;

		// Ogni protocollo non consentito è ignorato.
		// N.B. Il crawler è sviluppato per funzionare con protocolli http e https
		if (! perfhash_check(&(accept_protocol), protocol))
		{
			free (protocol);
			return false;
		}

		free (protocol);

		// Dopo il pattern '://' occorre verificare che il nome del sito sia valido
		// Si possono utilizzare tutte le cifre (0-9), le lettere (a-z) (ASCII),  il trattino (-)
		// e i caratteri  à, â, ä, è, é, ê, ë, ì, î, ï, ò, ô, ö, ù, û, ü, æ, oe, ç, ÿ, β
		// (NON ASCII ma convertiti in ascii attraverso la codifica IDN allo stato attuale non supportati dal crawler).
		// Il nome non può iniziare o terminare con il simbolo del trattino (-) e i primi quattro caratteri
		// I primi 4 caratteri con sequenza sequenza "xn--" nel dominio di secondo livello sono riservati alla codifica IDN di un nome a dominio.
		// I domini devono essere almeno DUE occorre perciò sia presente almeno un ALMENO un punto separatore.
		char *psite = NULL;

		size_t offset = 0;

		if (strncmp(&(href[colon_pos]),"://", 3) == 0)
		{
			psite = &(href[(colon_pos + 3)]);

			bool sitename_have_dot = false;

			// Il nome non può iniziare con il simbolo score (-) o con il dot (.)
			if (psite[offset] == '-' || psite[offset] == '.')
				return false;

			while (psite[offset] != ASCII_SL && psite[offset] != ASCII_NUL)
			{
				if (isspace(psite[offset])) // Ha spazi o newline, ignorato
					return false;

				// subito prima, o dopo, ogni punto non possono esserci simboli score
				if (psite[offset] == '.' && (psite[(offset - 1)] == '-' || psite[(offset + 1)] == '-'))
					return false;

				// subito dopo, ogni punto non possono esistere la sequenza "xn--" perchè allora si troverebbe all'inizio del nome dominio
				//if(psite[offset] == '.' && strncmp(&(psite[(offset - 1)]), "xn--", 4) == 0)
				//	return false;

				if (offset > 1 && psite[offset] == '.')
					sitename_have_dot = true;
				else if (psite[offset] != '-' && (! isdigit(psite[offset])) && (! isalpha(psite[offset])))// Ha caratteri non consentiti, ignorato
					return false;

				offset++;
			};

			if (psite[(offset - 1)] == '-' || psite[(offset - 1)] == '.' || offset < 5 || sitename_have_dot == false)
				return false;

			if (psite[offset] != ASCII_NUL && psite[(++offset)] != '\0')
				phref = &(psite[offset]);

			local = false;
		}
		else
			return false; // Url assoluto non valido
	}
	else if (strchr(href,'@') != NULL)
	{
		// Malformed e-mail URL, ignore
		return false;
	}

	go_ahead: // not valid protocol (url local)

	// Check the href (no spaces), cut at first hash mark
	if (local == true) // nel caso href non contenga il procollo
		return false; // url of sitemap not valid because it not contains protocol prefix
	else // nel caso href contenga il protocollo inutile controllare il nome del sito in quanto già controllato a monte
	{
		if (phref != NULL)
			for(uint i = 0; i <=strlen(phref); i++)
			{
				if (isspace(phref[i]))
					return false; // Has spaces or newlines, ignore
				if (phref[i] == '#')
				{
					phref[i] = ASCII_NUL;
					break;
				}
		}
	}
	// end patch

	// Look for the type of extension
	char extension[MAX_STR_LEN];
	extension[0] = ASCII_NUL;
	extension_type_t extension_type = EXTENSION_NORMAL;

	extension_type = parser_check_extension(phref, extension);

	if (check_extension == true && extension_type != EXTENSION_NORMAL)
		return false;

	bool link_sitemap_gz = false;

	// se 'check_extension == false' dovrebbe trattarsi di file tipo 'sitemap.xml' con le estensioni compatibili
	// es: nomefile.xml oppure nomefile.xml.gz
	// Vengono esclusi i path canonici tipo 'http://nomesito.it/sitemap.xml' o 'https://www.nomesito.it/sitemap.xml.gz'
	if (check_extension == false)
	{
		if (strncmp(extension, "gz", 2) == 0)
		{
			if (hreflen > 7 && strncmp(&(href[(hreflen - 7)]), ".xml", 4) == 0)
				link_sitemap_gz = true;
			else
				return false; // se il file non termina con lestensione '.xml.gz'
		}

		if (strncmp(extension, "xml", 3) != 0)
			return false; // se il file non termina con l'estensione '.xml'

		char *p = NULL;

		// verifica se si tratta dei sitemap canonici tipo 'http://nomesito.it/sitemap.xml' o 'http://nomesito.it/sitemap.xml.gz'
		p = strstr(href,"://");

		if (p != NULL)
		{
			p += 3;

			char *pslash = strchr(p,ASCII_SL);

			if (pslash != NULL)
			{
				pslash++;

				unsigned short pslashlen = strlen(pslash);

				if ((pslashlen == 11 && strncmp(pslash, "sitemap.xml", 11) != 0) || (pslashlen == 14 && strncmp(pslash, "sitemap.xml.gz", 14) != 0))
					return false;
			}
		}
	}

	// Reject certains hrefs
	if (regexec(&reject_patterns, href, 0, NULL, 0) == 0)
		return false;

	// Remove sessionids in URLs
	if (regexec(&sessionid_patterns, href, 0, NULL, 0) == 0) {
		for(int i=0; i<sessionid_variables_count; i++) {
			url->remove_variable(href, sessionid_variables[i]);
		}
	}

	// Remove sessionids, heuristic
	url->remove_sessionids_heuristic(href);

	// check robots.txt rules
	if (starter->testing == false &&
		parser_check_robotstxt(server, href) == true)
		return false;

	// sitemap.xml non deve consentire lo spoofing dei domini.
	// Anche il path della locazione deve far riferimento al path del file sitemap.xml
	// Es: http://www.sito.it/en/sitemap.xml -> http://www.sito.it/en/index.pl è OK -> http://www.sito.it/jp/index.pl è KO
	// per questo motivo è stata commentata la parte in alto e il comando 'else if' è stato modificato in if.
	// IMPORTANTE: Quando (priority == -1) significa che è quello di default e NON è necessario scriverlo sul file 'links_download'
	// in questo modo si risparmiano anche inutili scritture su disco perchè il priority di default è quello più utilizzato
	if (check_extension == true)
	{
		bool is_news = false;

		if (doc->mime_type == MIME_FEEDS_ATOM_XML
		|| doc->mime_type == MIME_FEEDS_ATOM_XML_GZ
		|| doc->mime_type == MIME_FEEDS_RSS_XML
		|| doc->mime_type == MIME_FEEDS_RSS_XML_GZ)
		is_news = true;

		if (debugonly == false && ((partial_path[inst] != NULL && strstr(href,("://" + site + "/" + partial_path[inst]).c_str()) != NULL) || strstr(href,("://" + site + "/").c_str()) != NULL))
		{
			if (changefreq == NONE)
			{
				if ((int)priority != -1)
				{
					if ((int)last_modified > 0)
					{
						if (is_news == true)
							fprintf(links_download, "%lu 0 0 %s %s %d %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_PRIORITY, (int)priority, LINK_CAPTION_NEWS_LAST_MODIFIED, (int)(last_modified));
						else
							fprintf(links_download, "%lu 0 0 %s %s %d %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_PRIORITY, (int)priority, LINK_CAPTION_LAST_MODIFIED, (int)(last_modified));
					}
					else
						fprintf(links_download, "%lu 0 0 %s %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_PRIORITY, (int)priority);
				}
				else
				{
					if ((int)last_modified > 0)
					{
						if (is_news == true)
							fprintf(links_download, "%lu 0 0 %s %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_NEWS_LAST_MODIFIED, (int)(last_modified));
						else
							fprintf(links_download, "%lu 0 0 %s %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_LAST_MODIFIED, (int)(last_modified));
					}
					else
						fprintf(links_download, "%lu 0 0 %s \n", (unsigned long int)doc->docid, href);
				}
			}
			else
			{
				if ((int)priority != -1)
				{
					if ((int)last_modified > 0)
					{
						if (is_news == true)
							fprintf(links_download, "%lu 0 0 %s %s %d %s %d %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_CHANGEFREQ, (int)changefreq, LINK_CAPTION_PRIORITY, (int)priority, LINK_CAPTION_NEWS_LAST_MODIFIED, (int)(last_modified));
						else
							fprintf(links_download, "%lu 0 0 %s %s %d %s %d %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_CHANGEFREQ, (int)changefreq, LINK_CAPTION_PRIORITY, (int)priority, LINK_CAPTION_LAST_MODIFIED, (int)(last_modified));
					}
					else
						fprintf(links_download, "%lu 0 0 %s %s %d %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_CHANGEFREQ, (int)changefreq, LINK_CAPTION_PRIORITY, (int)priority);
				}
				else
				{
					if ((int)last_modified > 0)
					{
						if (is_news == true)
							fprintf(links_download, "%lu 0 0 %s %s %d %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_CHANGEFREQ, (int)changefreq, LINK_CAPTION_NEWS_LAST_MODIFIED, (int)(last_modified));
						else
							fprintf(links_download, "%lu 0 0 %s %s %d %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_CHANGEFREQ, (int)changefreq, LINK_CAPTION_LAST_MODIFIED, (int)(last_modified));
					}
					else
						fprintf(links_download, "%lu 0 0 %s %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_CHANGEFREQ, (int)changefreq);
				}
			}

			return true;
		}
	}
	else // href come from robots.txt or sitemap index
	{
		if (starter->testing == false)
		{
			if (debugonly == false && strstr(href,("://" + site).c_str()) != NULL)
			{
				if (link_sitemap_gz == true)
				{
					char *t = strrchr(href, '.');
					t[0] = ASCII_NUL; // viene sempre eliminata l'estensione '.gz' perchè la discriminazione della compressione avviene attraverso il mime_type
				}

				if ((int)last_modified > 0)
					fprintf(links_download, "%lu 0 0 %s %s %d %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_SITEMAP, link_sitemap_gz, LINK_CAPTION_LAST_MODIFIED, (int)(last_modified));
				else
					fprintf(links_download, "%lu 0 0 %s %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_SITEMAP, link_sitemap_gz);

				return true;
			}
		}
		else
		{
			if (debugonly == false) // for testing use nothing check site
			{
				if (link_sitemap_gz == true)
				{
					char *t = strrchr(href, '.');
					t[0] = ASCII_NUL; // viene sempre eliminata l'estensione '.gz' perchè la discriminazione della compressione avviene attraverso il mime_type
				}

				if ((int)last_modified > 0)
					fprintf(links_download, "%lu 0 0 %s %s %d %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_SITEMAP, link_sitemap_gz, LINK_CAPTION_LAST_MODIFIED, (int)(last_modified));
				else
					fprintf(links_download, "%lu 0 0 %s %s %d\n", (unsigned long int)doc->docid, href, LINK_CAPTION_SITEMAP, link_sitemap_gz);

				return true;
			}
		}
	}

	return false;
}

//
// Name: parser_analyze_link_feeds
//
// Description:
//   Analyze a link
//
// Input:
// 	 server - 
//   href - destination of link
//   last_modified - timestamp of last modified
//
bool parser_analyze_link_feeds(starter_t *starter, siteid_t serverid, char *href, char *caption, bool check_extension, time_t last_modified, char *base)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);
	instance_t inst = starter->inst;
	FILE *links_download = starter->links_download;

	doc_t *doc = server->pages->doc; // N.B. ci si riferisce al documento sitemap (documento sorgente)

	assert(doc != NULL);

	assert(href != NULL);

	string path = server->pages->path;
	string site = server->hostname;

	size_t hreflen = strlen(href);

	size_t f = (hreflen - 1);
	while ((href[f] == ASCII_SP || href[f] == ASCII_NL || href[f] == ASCII_CR || href[f] == ASCII_TB)) f--; // elimina i caratteri 'invisibili/inutili' in coda


	hreflen = (f + 1);
	href[hreflen] = ASCII_NUL;

	// pulisce href da eventuali caratteri 'invisibili/inutili' iniziali (quelli finali allo stato attuale non occorre eliminarli)
	unsigned short s = 0;
	while ((href[s] == ASCII_SP || href[s] == ASCII_NL || href[s] == ASCII_CR || href[s] == ASCII_TB) && s < ((hreflen / 2) + 2) && s < USHRT_MAX) s++;

	if (s == USHRT_MAX || s > (hreflen / 2))
		return false; // troppi spazi iniziali in href. Ignorato

	if (s > 0)
		href = &(href[s]);
	// spazi iniziali

	hreflen = (hreflen - s); // anche se in seguito hreflen non serve è giusto sia però impostato al valore corretto

	// Ignore some common cases

	// Migliorato il parsing dei nomi dominio
	char *phref = NULL; // Attenzione phref non deve essere liberato in quanto eventualmente serve solo per puntare il puntatore href

	bool local = true;

	if (href[0] == '#') // Local reference to the same page, ignore
		return false;
	else if (href[0] != ASCII_SL && strchr(href,':') != NULL) // possible URL with protocol
	{
		unsigned short pos = 0;

		// caratteri ammessi al fine di specificare un protocollo secondo 'schema' rfc3986
		while (isalnum(href[pos]) || href[pos] == '+' || href[pos] == '-' || href[pos] == '.') pos++;

		size_t colon_pos = 0;

		while (href[colon_pos] != ':')
			colon_pos++;

		if (colon_pos > pos || colon_pos == 0)
			goto go_ahead; // secondo rfc3986 lo 'schema' non identifica un URI assoluto con protocollo, ma un _url relativo

		char *protocol = (char *) malloc ((colon_pos + 1) * sizeof(char));

		strncpy(protocol, href, colon_pos);

		protocol[colon_pos] = ASCII_NUL;

		// Ogni protocollo non consentito è ignorato.
		// N.B. Il crawler è sviluppato per funzionare con protocolli http e https
		if (! perfhash_check(&(accept_protocol), protocol))
		{
			free (protocol);
			return false;
		}

		free (protocol);

		// Dopo il pattern '://' occorre verificare che il nome del sito sia valido
		// Si possono utilizzare tutte le cifre (0-9), le lettere (a-z) (ASCII),  il trattino (-)
		// e i caratteri  à, â, ä, è, é, ê, ë, ì, î, ï, ò, ô, ö, ù, û, ü, æ, oe, ç, ÿ, β
		// (NON ASCII ma convertiti in ascii attraverso la codifica IDN allo stato attuale non supportati dal crawler).
		// Il nome non può iniziare o terminare con il simbolo del trattino (-) e i primi quattro caratteri
		// I primi 4 caratteri con sequenza sequenza "xn--" nel dominio di secondo livello sono riservati alla codifica IDN di un nome a dominio.
		// I domini devono essere almeno DUE occorre perciò sia presente almeno un ALMENO un punto separatore.
		char *psite = NULL;

		size_t offset = 0;

		if (strncmp(&(href[colon_pos]),"://", 3) == 0)
		{
			psite = &(href[(colon_pos + 3)]);

			bool sitename_have_dot = false;

			// Il nome non può iniziare con il simbolo score (-) o con il dot (.)
			if (psite[offset] == '-' || psite[offset] == '.')
				return false;

			while (psite[offset] != ASCII_SL && psite[offset] != ASCII_NUL)
			{
				if (isspace(psite[offset])) // Ha spazi o newline, ignorato
					return false;

				// subito prima, o dopo, ogni punto non possono esserci simboli score
				if (psite[offset] == '.' && (psite[(offset - 1)] == '-' || psite[(offset + 1)] == '-'))
					return false;

				// subito dopo, ogni punto non possono esistere la sequenza "xn--" perchè allora si troverebbe all'inizio del nome dominio
				//if(psite[offset] == '.' && strncmp(&(psite[(offset - 1)]), "xn--", 4) == 0)
				//	return false;

				if (offset > 1 && psite[offset] == '.')
					sitename_have_dot = true;
				else if (psite[offset] != '-' && (! isdigit(psite[offset])) && (! isalpha(psite[offset])))// Ha caratteri non consentiti, ignorato
					return false;

				offset++;
			};

			if (psite[(offset - 1)] == '-' || psite[(offset - 1)] == '.' || offset < 5 || sitename_have_dot == false)
				return false;

			if (psite[offset] != ASCII_NUL && psite[(++offset)] != '\0')
				phref = &(psite[offset]);

			local = false;
		}
		else
			return false; // Url assoluto non valido
	}
	else if (strchr(href,'@') != NULL)
	{
		// Malformed e-mail URL, ignore
		return false;
	}


	go_ahead: // not valid protocol (_url local)

	// Check the href (no spaces), cut at first hash mark
	// nel caso href contenga il protocollo inutile controllare il nome del sito in quanto già controllato a monte
	if (local == true) // nel caso href non contenga il procollo
	{
		for(uint i = 0; i <=strlen(href); i++)
		{
			if (isspace(href[i]))
				return false; // Has spaces or newlines, ignore

			if (check_extension == true && href[i] == '#')
			{
				href[i] = ASCII_NUL;
				break;
			}
			else if (href[i] == '#')
				return false;
		}
	}
	else
	{
		if (phref != NULL)
			for(uint i = 0; i <=strlen(phref); i++)
			{
				if (isspace(phref[i]))
					return false; // Has spaces or newlines, ignore

				if (check_extension == true && phref[i] == '#')
				{
					phref[i] = ASCII_NUL;
					break;
				}
				else if (phref[i] == '#')
					return false;
			}
	}
	// end patch

	// Look for the type of extension
	char extension[MAX_STR_LEN];
	extension[0] = ASCII_NUL;
	extension_type_t extension_type = EXTENSION_NORMAL;

	extension_type = parser_check_extension(phref, extension);

	if (check_extension == true && extension_type != EXTENSION_NORMAL)
		return false;

	char _url[MAX_STR_LEN + MAX_DOMAIN_LEN + URLDDX_PATH_LEN + 8]; // la lunghezza 8 è relativa a 'https://'
	_url[0] = ASCII_NUL;

	if (server->ssl == NULL) // anche se ininfluente si inserisce il tipo protocollo del sito
		strcpy(_url, "http://");
	else
		strcpy(_url, "https://");

	strcat(_url, server->hostname);
	strcat(_url, "/");

	if (server->pages->src_path == NULL)
	{
		if (server->pages->path[0] == ASCII_SL)
			strcat(_url, &(server->pages->path[1]));
		else
			strcat(_url, server->pages->path);
	}
	else if (strlen(server->pages->src_path) > 0) // si tratta di una redirezione gestita nello stesso ciclo di harvesting, perciò
		strcat(_url, server->pages->src_path);	  // in seguito occorrerà verificare che il server->pages->src_path sia scritto secondo standard

	bool link_feeds_gz = false;

	// se 'check_extension == false' dovrebbe trattarsi di file tipo 'sitemap.xml' con le estensioni compatibili
	// es: nomefile.xml oppure nomefile.xml.gz
	// Vengono esclusi i path canonici tipo 'http://nomesito.it/sitemap.xml' o 'https://www.nomesito.it/sitemap.xml.gz'
	if (check_extension == false)
	{
		if (strncmp(extension, "gz", 2) == 0)
			link_feeds_gz = true;
	}

	// Reject certains hrefs
	if (regexec(&reject_patterns, href, 0, NULL, 0) == 0)
		return false;

	// Remove sessionids in URLs
	if (regexec(&sessionid_patterns, href, 0, NULL, 0) == 0) {
		for(int i=0; i<sessionid_variables_count; i++) {
			url->remove_variable(href, sessionid_variables[i]);
		}
	}

	// Remove sessionids, heuristic
	url->remove_sessionids_heuristic(href);

	// check robots.txt rules
	if (starter->testing == false &&
		parser_check_robotstxt(server, href) == true)
		return false;

	// sitemap.xml non deve consentire lo spoofing dei domini.
	// Anche il path della locazione deve far riferimento al path del file sitemap.xml
	// Es: http://www.sito.it/en/sitemap.xml -> http://www.sito.it/en/index.pl è OK -> http://www.sito.it/jp/index.pl è KO
	// per questo motivo è stata commentata la parte in alto e il comando 'else if' è stato modificato in if.
	// IMPORTANTE: Quando (priority == -1) significa che è quello di default e NON è necessario scriverlo sul file 'links_download'
	// in questo modo si risparmiano anche inutili scritture su disco perchè il priority di default è quello più utilizzato
	if (check_extension == true)
	{
		if (debugonly == false && ((partial_path[inst] != NULL && strstr(href,("://" + site + "/" + partial_path[inst]).c_str()) != NULL) || strstr(href,("://" + site + "/").c_str()) != NULL))
		{
			if ((int)last_modified > 0)
				fprintf(links_download, "%lu 0 0 %s %s %d\n", (unsigned long int)doc->docid, href, caption, (int)(last_modified));
			else
				fprintf(links_download, "%lu 0 0 %s\n", (unsigned long int)doc->docid, href);

			return true;
		}
	}
	else // href del feed xml
	{
		if (debugonly == false)
		{
			if (link_feeds_gz == true)
			{
				char *t = strrchr(href, '.');
				t[0] = ASCII_NUL; // viene sempre eliminata l'estensione '.gz' perchè la discriminazione della compressione avviene attraverso il mime_type
			}

			if (local == true)
			{
				if (href[0] != ASCII_SL)
				{
					size_t bl = 0;

					if (base != NULL)
						bl = strlen(base);

					char lc;

					if (bl > 0)
						lc = base[(bl -1)];

					if (bl > 0 && strstr(base, LINK_CAPTION_BASE_URL) != NULL && (lc == ASCII_MA || lc == ASCII_SL))
					{
						if (debugonly == false)
						{
							if (bl == 10)
								fprintf(links_download, "%lu 0 0 %s%s %s %d\n", (unsigned long int)doc->docid, _url, href, caption, link_feeds_gz);
							else
								fprintf(links_download, "%lu 0 0 %s%s%s %s %d\n", (unsigned long int)doc->docid, _url, &(base[10]), href, caption, link_feeds_gz);
						}
					}
					else if (server->pages->doc->mime_type == MIME_REDIRECT && href[0] != ASCII_SL)
					{
						if (debugonly == false)
						{
							if (server->pages->redirect_is_relative == false)
								fprintf(links_download, "%lu 0 0 %s%s %s %d\n", (unsigned long int)doc->docid, _url, href, caption, link_feeds_gz);
							else
							{
								char *__url = (char *) malloc ((strlen(_url) + 1) * sizeof(char)); // la lunghezza 8 è relativa a 'https://'
								__url[0] = ASCII_NUL;
								strcpy(__url, _url);
								char *p = strrchr(__url, ASCII_SL);
								p[0] = ASCII_NUL;
								fprintf(links_download, "%lu 0 0 %s/%s %s %d\n", (unsigned long int)doc->docid, __url, href, caption, link_feeds_gz);
								free(__url);
							}
						}
					}
					else if (server->pages->src_path != NULL && href[0] != ASCII_SL)
					{
						if (debugonly == false)
						{
							if (partial_path[inst] == NULL)
								fprintf(links_download, "%lu 0 0 %s%s %s %d\n", (unsigned long int)doc->docid, _url, href, caption, link_feeds_gz);
							else
							{
								if (server->pages->redirect_with_invalid_path == true)
									return false;

								fprintf(links_download, "%lu 0 0 %s%s%s %s %d\n", (unsigned long int)doc->docid, _url, partial_path[inst], href, caption, link_feeds_gz);
							}
						}
					}
					else // nel caso estremo si lascia comunque il link relativo
						if (debugonly == false)
							fprintf(links_download, "%lu 0 0 %s%s %s %d\n", (unsigned long int)doc->docid, _url, href, caption, link_feeds_gz);
				}
				else if (debugonly == false)
					fprintf(links_download, "%lu 0 0 %s%s %s %d\n", (unsigned long int)doc->docid, _url, &(href[1]), caption, link_feeds_gz);

				return true;
			}
			else
			{
				if (debugonly == false && ((partial_path[inst] != NULL && strstr(href,("://" + site + "/" + partial_path[inst]).c_str()) != NULL) || strstr(href,("://" + site + "/").c_str()) != NULL))
				{
					fprintf(links_download, "%lu 0 0 %s %s %d\n", (unsigned long int)doc->docid, href, caption, link_feeds_gz);
					return true;
				}
				else
					return false;
			}
		}
	}

	return false;
}

//
// Name: parser_process_robotstxt
//
// Description:
//   Process a robots.txt file. These files usually are not very
//   strict, so this parser is not stricts and errs in the side
//   of caution, disallowing this robot to the specified directories.
//   This parser doesn't support excluding of a particular file,
//   because that should be done via a "noindex" tag.
//
// Input:
//   doc - the document object
//   inbuf - the contents of the robots.txt file
//
// Return:
//   the number of exclusions found
//

unsigned int parser_process_robotstxt(starter_t *starter, siteid_t serverid, char *inbuf)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);

	doc_t *doc = server->pages->doc;

	assert(doc != NULL);

	assert((off64_t)strlen(inbuf) == doc->raw_content_length);

	int written = 0;
	size_t space = doc->raw_content_length;
	char *rules = CBALLOC(char, MALLOC, (space + 1));

	// declaration needed for macro
	off64_t size = doc->raw_content_length;

	unsigned int exclusions = 0;
	unsigned int inclusions = 0;

	char line[MAX_STR_LEN];

	// This variable is true if the robots.txt file refers
	// to this user-agent, or to all user agents.
	bool useragent_match = false; // for exact useragent match
	bool ua_found = false; // for exact useragent match
	bool as_useragent_match = false;
	bool ua_banned = false;
	bool ua_banned_partial = false;

	bool ua_found_rules = false;

	size_t spilen = strlen((const char*)SPIDERNAME);

	char lower_spiname[MAX_STR_LEN] = {ASCII_NUL};

	for (unsigned short v = 0; v < spilen; v++)
		lower_spiname[v] = tolower(((const char*)SPIDERNAME)[v]);

	// First: check if are presents rules only for our crawler with exact name without extension (strict mode)
	// Sviluppabile ulteriormente in caso di nomi crawler diversi tipo: CBot Cbot-News ecc..
	for (off64_t inpos = 0; inpos < doc->raw_content_length; inpos++)
	{
		// Copy a single line
		off64_t linepos = 0;

		while (!IS_EOF() && !IS_NEWLINE())
		{
			// skip initial space or tabulators
			if (linepos == 0)
				while (IS_SPACE())
					inpos++;

			// Do not copy long lines
			if (linepos < MAX_STR_LEN - 10) line[linepos++] = inbuf[inpos];

			inpos++;
		}

		line[linepos++] = ASCII_NL;
		line[linepos]   = ASCII_NUL;

		// Skip the trailing newlines
		while (!IS_EOF() && IS_SPACE_EXTENDED()) inpos++;

		inpos--;

		// Skip comments (#)
		if (line[0] == ASCII_NU)
			continue;

		// Look for user-agent tags (space missing are permitted)
		if (((useragent_match == false) &&
			((strlen(line) > 11 && strncasecmp(line, "user-agent:", 11) == 0) ||
			(strlen(line) > 10 && strncasecmp(line, "useragent:", 10) == 0))) ||
			((ua_found_rules == true) &&
			((strlen(line) > 11 && strncasecmp(line, "user-agent:", 11) == 0) ||
			(strlen(line) > 10 && strncasecmp(line, "useragent:", 10) == 0))))
		{
			// break if our useragent was already found
			// ignorato perchèil nostro 'ua' potrebbe essere richiamato
			// piùvolte nel file (anche se si tratterebbe un uso improprio)
			// if (useragent_match == true)
			//	break;

			ua_found_rules = false;

			char *pua = &line[11];

			while (*pua != ASCII_NUL && *pua != ASCII_AS && !(isdigit(*pua)) && !(isalpha(*pua))) pua++;

			// It only needs to have the name of this bot
			useragent_match = false;

			if (pua != NULL && spilen > 0)
			{
				unsigned short s = 0;

				size_t len = strlen(pua);

				for (s = 0; s < spilen && s < len; s++)
					if (tolower(pua[s]) != lower_spiname[s])
						break;

				// Find exact user agent
				if (s == spilen && (pua[s] == ASCII_NUL || pua[s] == ASCII_NL || pua[s] == ASCII_CR))
				{
					useragent_match = true;
					ua_found = true;
				}
			}
		}
		else if (strlen(line) > 9 && strncasecmp(line, "disallow:", strlen("disallow:")) == 0) // Look for disallow tags
		{
			unsigned short i = 0;

			ua_found_rules = true;

			// Skip "disallow"
			while (line[i] != ':' && line[i] != ASCII_NL)
				i++;

			// Skip ' : '
			while ((line[i] == ':' || isspace(line[i])) && line[i] != ASCII_NL)
				i++;

			char dirname[MAX_STR_LEN];
			uint j = 0;

			// dirname must begin with slash because path must be only absolute
			if (line[i] != ASCII_SL && line[i] != ASCII_NL)
				dirname[j++] = ASCII_SL; // now it is an absolute path

			// Copy the directory name
			while (!isspace(line[i]) && line[i] != ASCII_NL)
			{
				if (line[i] == ASCII_AS)
				{
					// continue if we have consecutive ascii asterisk
					if (j > 0 && dirname[(j - 1)] == ASCII_AS)
					{
						i++;
						continue;
					}
				}
				else if (line[i] == ASCII_DO) // break if we have ascii dollar that can be only last character of regex
				{
					if (j > 1) // append 'dollar' only if we don't have a slash only
						dirname[j++] = line[i++];

					break;
				}

				dirname[j++] = line[i++];
			}

			// Remove last asterisks because not needed
			while (j > 0 && dirname[(j - 1)] == ASCII_AS) j--;

			dirname[j] = ASCII_NUL;

			// skip path '/robots.txt'
			if (j == 11 && strncasecmp(dirname, "/robots.txt", strlen("/robots.txt")) == 0)
				continue;

			// Save the disallow instruction only if:
			// - We match the useragent useragent
			if (j > 0 &&
				strstr(dirname, "://") == NULL &&
				strchr(dirname, ASCII_BS) == NULL)
			{
				if (useragent_match)
				{
					if (j == 1) ua_banned = true;

					if (space > 0)
					{
						int _written = written;
						written += snprintf(rules + written, space, "%c%s%c", ROBOTS_DISALLOW, dirname, ASCII_NUL);
						space -= (written - _written);
					}

					exclusions++;
				}
			}
		}
		else if (strlen(line) > 6 && strncasecmp(line, "allow:", strlen("allow:")) == 0) // Look for disallow tags
		{
			unsigned short i = 0;

			ua_found_rules = true;

			// Skip "allow"
			while (line[i] != ':' && line[i] != ASCII_NL)
				i++;

			// Skip ' : '
			while ((line[i] == ':' || isspace(line[i])) && line[i] != ASCII_NL)
				i++;

			char dirname[MAX_STR_LEN];
			uint j = 0;

			// dirname must begin with slash because path must be only absolute
			if (line[i] != ASCII_SL && line[i] != ASCII_NL)
				dirname[j++] = ASCII_SL; // now it is an absolute path

			// Copy the directory name
			while (!isspace(line[i]) && line[i] != ASCII_NL)
			{
				if (line[i] == ASCII_AS)
				{
					// continue if we have consecutive ascii asterisk
					if (j > 0 && dirname[(j - 1)] == ASCII_AS)
					{
						i++;
						continue;
					}
				}
				else if (line[i] == ASCII_DO) // break if we have ascii dollar that can be only last character of regex
				{
					if (j > 1) // append 'dollar' only if we don't have a slash only
						dirname[j++] = line[i++];

					break;
				}

				dirname[j++] = line[i++];
			}

			// Remove last asterisks because not needed
			while (j > 0 && dirname[(j - 1)] == ASCII_AS) j--;

			dirname[j] = ASCII_NUL;

			// skip path '/robots.txt'
			if (j == 11 && strncasecmp(dirname, "/robots.txt", strlen("/robots.txt")) == 0)
				continue;

			// Save the disallow instruction only if:
			// - We match the useragent useragent
			if (j > 0 &&
				strstr(dirname, "://") == NULL &&
				strchr(dirname, ASCII_BS) == NULL)
			{
				if (useragent_match)
				{
					ua_banned_partial = true;

					if (space > 0)
					{
						int _written = written;
						written += snprintf(rules + written, space, "%c%s%c", ROBOTS_ALLOW, dirname, ASCII_NUL);
						space -= (written - _written);
					}

					inclusions++;
				}
			}
		}
	}

	if (ua_found == true) goto end;

	line[0] = ASCII_NUL;

	// First check if are presents rules only for our crawler also with extensions
	for (off64_t inpos = 0; inpos < doc->raw_content_length; inpos++)
	{
		// Copy a single line
		off64_t linepos = 0;

		while (!IS_EOF() && !IS_NEWLINE())
		{
			// skip initial space or tabulators
			if (linepos == 0)
				while (IS_SPACE())
					inpos++;

			// Do not copy long lines
			if (linepos < MAX_STR_LEN - 10) line[linepos++] = inbuf[inpos];

			inpos++;
		}

		line[linepos++] = ASCII_NL;
		line[linepos]   = ASCII_NUL;

		// Skip the trailing newlines
		while (!IS_EOF() && IS_SPACE_EXTENDED()) inpos++;

		inpos--;

		// Skip comments (#)
		if (line[0] == ASCII_NU)
			continue;

		// Look for user-agent tags (space missing are permitted)
		if (((useragent_match == false) &&
			((strlen(line) > 11 && strncasecmp(line, "user-agent:", 11) == 0) ||
			(strlen(line) > 10 && strncasecmp(line, "useragent:", 10) == 0))) ||
			((ua_found_rules == true) &&
			((strlen(line) > 11 && strncasecmp(line, "user-agent:", 11) == 0) ||
			(strlen(line) > 10 && strncasecmp(line, "useragent:", 10) == 0))))
		{
			// break if our useragent was already found
			// ignorato perchèil nostro 'ua' potrebbe essere richiamato
			// piùvolte nel file (anche se si tratterebbe un uso improprio)
			if (useragent_match == true)
				break;

			ua_found_rules = false;

			char *pua = &line[11];

			while (*pua != ASCII_NUL && *pua != ASCII_AS && !(isdigit(*pua)) && !(isalpha(*pua))) pua++;

			// It only needs to have the name of this bot
			useragent_match = false;

			if (pua != NULL && spilen > 0)
			{
				unsigned short s = 0;

				size_t len = strlen(pua);

				for (s = 0; s < spilen && s < len; s++)
					if (tolower(pua[s]) != lower_spiname[s])
						break;

				if (s == spilen && (pua[s] == ASCII_NUL || pua[s] == ASCII_AS || !(isalpha(pua[s]))))
				{
					useragent_match = true;
					ua_found = true;
				}
			}
		}
		else if (strlen(line) > 9 && strncasecmp(line, "disallow:", strlen("disallow:")) == 0) // Look for disallow tags
		{
			unsigned short i = 0;

			ua_found_rules = true;

			// Skip "disallow"
			while (line[i] != ':' && line[i] != ASCII_NL)
				i++;

			// Skip ' : '
			while ((line[i] == ':' || isspace(line[i])) && line[i] != ASCII_NL)
				i++;

			char dirname[MAX_STR_LEN];
			uint j = 0;

			// dirname must begin with slash because path must be only absolute
			if (line[i] != ASCII_SL && line[i] != ASCII_NL)
				dirname[j++] = ASCII_SL; // now it is an absolute path

			// Copy the directory name
			while (!isspace(line[i]) && line[i] != ASCII_NL)
			{
				if (line[i] == ASCII_AS)
				{
					// continue if we have consecutive ascii asterisk
					if (j > 0 && dirname[(j - 1)] == ASCII_AS)
					{
						i++;
						continue;
					}
				}
				else if (line[i] == ASCII_DO) // break if we have ascii dollar that can be only last character of regex
				{
					if (j > 1) // append 'dollar' only if we don't have a slash only
						dirname[j++] = line[i++];

					break;
				}

				dirname[j++] = line[i++];
			}

			// Remove last asterisks because not needed
			while (j > 0 && dirname[(j - 1)] == ASCII_AS) j--;

			dirname[j] = ASCII_NUL;

			// skip path '/robots.txt'
			if (j == 11 && strncasecmp(dirname, "/robots.txt", strlen("/robots.txt")) == 0)
				continue;

			// Save the disallow instruction only if:
			// - We match the useragent useragent
			if (j > 0 &&
				strstr(dirname, "://") == NULL &&
				strchr(dirname, ASCII_BS) == NULL)
			{
				if (useragent_match)
				{
					if (j == 1) ua_banned = true;

					if (space > 0)
					{
						int _written = written;
						written += snprintf(rules + written, space, "%c%s%c", ROBOTS_DISALLOW, dirname, ASCII_NUL);
						space -= (written - _written);
					}

					exclusions++;
				}
			}
		}
		else if (strlen(line) > 6 && strncasecmp(line, "allow:", strlen("allow:")) == 0) // Look for disallow tags
		{
			unsigned short i = 0;

			ua_found_rules = true;

			// Skip "allow"
			while (line[i] != ':' && line[i] != ASCII_NL)
				i++;

			// Skip ' : '
			while ((line[i] == ':' || isspace(line[i])) && line[i] != ASCII_NL)
				i++;

			char dirname[MAX_STR_LEN];
			uint j = 0;

			// dirname must begin with slash because path must be only absolute
			if (line[i] != ASCII_SL && line[i] != ASCII_NL)
				dirname[j++] = ASCII_SL; // now it is an absolute path

			// Copy the directory name
			while (!isspace(line[i]) && line[i] != ASCII_NL)
			{
				if (line[i] == ASCII_AS)
				{
					// continue if we have consecutive ascii asterisk
					if (j > 0 && dirname[(j - 1)] == ASCII_AS)
					{
						i++;
						continue;
					}
				}
				else if (line[i] == ASCII_DO) // break if we have ascii dollar that can be only last character of regex
				{
					if (j > 1) // append 'dollar' only if we don't have a slash only
						dirname[j++] = line[i++];

					break;
				}

				dirname[j++] = line[i++];
			}

			// Remove last asterisks because not needed
			while (j > 0 && dirname[(j - 1)] == ASCII_AS) j--;

			dirname[j] = ASCII_NUL;

			// skip path '/robots.txt'
			if (j == 11 && strncasecmp(dirname, "/robots.txt", strlen("/robots.txt")) == 0)
				continue;

			// Save the disallow instruction only if:
			// - We match the useragent 
			if (j > 0 &&
				strstr(dirname, "://") == NULL &&
				strchr(dirname, ASCII_BS) == NULL)
			{
				if (useragent_match)
				{
					ua_banned_partial = true;

					if (space > 0)
					{
						int _written = written;
						written += snprintf(rules + written, space, "%c%s%c", ROBOTS_ALLOW, dirname, ASCII_NUL);
						space -= (written - _written);
					}

					inclusions++;
				}
			}
		}
	}

	if (ua_found == true) goto end;

	line[0] = ASCII_NUL;

	// Read for generic user agent
	for (off64_t inpos = 0; inpos < doc->raw_content_length; inpos++)
	{
		// Copy a single line
		off64_t linepos = 0;

		while (!IS_EOF() && !IS_NEWLINE())
		{
			// skip initial space or tabulators
			if (linepos == 0)
				while (IS_SPACE())
					inpos++;

			// Do not copy long lines
			if (linepos < MAX_STR_LEN - 10) line[linepos++] = inbuf[inpos];

			inpos++;
		}

		line[linepos++] = ASCII_NL;
		line[linepos]   = ASCII_NUL;

		// Skip the trailing newlines and spaces
		//while (!IS_EOF() && IS_NEWLINE()) inpos++;
		while (!IS_EOF() && IS_SPACE_EXTENDED()) inpos++;

		inpos--;

		// Skip comments (#)
		if (line[0] == ASCII_NU)
			continue;

		// Look for user-agent tags (space missing are permitted)
		if (((useragent_match == false && as_useragent_match == false) &&
			((strlen(line) > 11 && strncasecmp(line, "user-agent:", 11) == 0) ||
			(strlen(line) > 10 && strncasecmp(line, "useragent:", 10) == 0))) ||
			((ua_found_rules == true) &&
			((strlen(line) > 11 && strncasecmp(line, "user-agent:", 11) == 0) ||
			(strlen(line) > 10 && strncasecmp(line, "useragent:", 10) == 0))))
		{
			// break if our useragent was already found
			// ignorato perchèil nostro 'ua' potrebbe essere richiamato
			// piùvolte nel file (anche se si tratterebbe un uso improprio)
			//	if (useragent_match == true)
			//		break;

			ua_found_rules = false;

			char *pua = &line[11];

			while (*pua != ASCII_NUL && *pua != ASCII_AS && !(isdigit(*pua)) && !(isalpha(*pua))) pua++;

			// It only needs to have the name of this bot, or an asterisk.
			if (pua != NULL && pua[0] == ASCII_AS)
			{
				pua++;

				as_useragent_match = true;

				while (*pua != ASCII_NUL)
				{
					if (*pua != ASCII_NL && *pua != ASCII_SP)
					{
						as_useragent_match = false;
						break;
					}

					pua++;
				}

				if (as_useragent_match == true)
					useragent_match = false;
			}
			else
			{
				useragent_match = false;

				if (pua != NULL && spilen > 0)
				{
					unsigned short s = 0;

					size_t len = strlen(pua);

					for (s = 0; s < spilen && s < len; s++)
						if (tolower(pua[s]) != lower_spiname[s])
							break;

					if (s == spilen && (pua[s] == ASCII_NUL || pua[s] == ASCII_AS || !(isalpha(pua[s]))))
						useragent_match = true;
				}

				as_useragent_match = false;
			} 
		}
		else if (strlen(line) > 9 && strncasecmp(line, "disallow:", strlen("disallow:")) == 0) // Look for disallow tags
		{
			unsigned short i = 0;

			ua_found_rules = true;

			// Skip "disallow"
			while (line[i] != ':' && line[i] != ASCII_NL)
				i++;

			// Skip ' : '
			while ((line[i] == ':' || isspace(line[i])) && line[i] != ASCII_NL)
				i++;

			char dirname[MAX_STR_LEN];
			unsigned short j = 0;

			// dirname must begin with slash because path must be only absolute
			if (line[i] != ASCII_SL && line[i] != ASCII_NL)
				dirname[j++] = ASCII_SL; // now it is an absolute path

			// Copy the directory name
			while (!isspace(line[i]) && line[i] != ASCII_NL)
			{
				if (line[i] == ASCII_AS)
				{
					// continue if we have consecutive ascii asterisk
					if (j > 0 && dirname[(j - 1)] == ASCII_AS)
					{
						i++;
						continue;
					}
				}
				else if (line[i] == ASCII_DO) // break if we have ascii dollar that can be only last character of regex
				{
					if (j > 1) // append 'dollar' only if we don't have a slash only
						dirname[j++] = line[i++];

					break;
				}

				dirname[j++] = line[i++];
			}

			// Remove last asterisks because not needed
			while (j > 0 && dirname[(j - 1)] == ASCII_AS) j--;

			dirname[j] = ASCII_NUL;

			// skip path '/robots.txt'
			if (j == 11 && strncasecmp(dirname, "/robots.txt", strlen("/robots.txt")) == 0)
				continue;

			// Save the disallow instruction only if:
			// - We match the useragent '*'
			if (j > 0 &&
				strstr(dirname, "://") == NULL &&
				strchr(dirname, ASCII_BS) == NULL)
			{
				if (as_useragent_match)
				{
					if (j == 1) ua_banned = true;

					if (space > 0)
					{
						int _written = written;
						written += snprintf(rules + written, space, "%c%s%c", ROBOTS_DISALLOW, dirname, ASCII_NUL);
						space -= (written - _written);
					}

					exclusions++;
				}
			}
		}
		else if (strlen(line) > 6 && strncasecmp(line, "allow:", strlen("allow:")) == 0) // Look for disallow tags
		{
			unsigned short i = 0;

			ua_found_rules = true;

			// Skip "allow"
			while (line[i] != ':' && line[i] != ASCII_NL)
				i++;

			// Skip ' : '
			while ((line[i] == ':' || isspace(line[i])) && line[i] != ASCII_NL)
				i++;

			char dirname[MAX_STR_LEN];
			unsigned short j = 0;

			// dirname must begin with slash because path must be only absolute
			if (line[i] != ASCII_SL && line[i] != ASCII_NL)
				dirname[j++] = ASCII_SL;

			// Copy the directory name
			while (!isspace(line[i]) && line[i] != ASCII_NL)
			{
				if (line[i] == ASCII_AS)
				{
					// continue if we have consecutive ascii asterisk
					if (j > 0 && dirname[(j - 1)] == ASCII_AS)
					{
						i++;
						continue;
					}
				}
				else if (line[i] == ASCII_DO) // break if we have ascii dollar that can be only last character of regex
				{
					if (j > 1) // append 'dollar' only if we don't have a slash only
						dirname[j++] = line[i++];

					break;
				}

				dirname[j++] = line[i++];
			}

			// Remove last asterisks because not needed
			while (j > 0 && dirname[(j - 1)] == ASCII_AS) j--;

			dirname[j] = ASCII_NUL;

			// skip path '/robots.txt'
			if (j == 11 && strncasecmp(dirname, "/robots.txt", strlen("/robots.txt")) == 0)
				continue;

			// Save the allow instruction only if:
			// - We match the useragent '*'
			if (j > 0 &&
				strstr(dirname, "://") == NULL &&
				strchr(dirname, ASCII_BS) == NULL)
			{
				if (as_useragent_match)
				{
					ua_banned_partial = true;

					if (space > 0)
					{
						int _written = written;
						written += snprintf(rules + written, space, "%c%s%c", ROBOTS_ALLOW, dirname, ASCII_NUL);
						space -= (written - _written);
					}

					inclusions++;
				}
			}
		}
	}

	end:

	if (server->pages->bt_size == 0)
		server->pages->buffer_two = CBALLOC(char, MALLOC, (written + 1));
	else if (server->pages->bt_size < written)
	{
		free(server->pages->buffer_two);
		server->pages->buffer_two = CBALLOC(char, MALLOC, (written + 1));
		server->pages->bt_size = 0;
	}

	server->pages->bt_size = 0;

	// write in buffer skipping duplicated or needless rules
	// note that after function 'server->pages->bt_size' can be minor of real size of buffer but this check is not evaluated for robots.txt
	if (written > 0)
		robots_txt_syntax((const char *)rules, written, server->pages->buffer_two, (size_t &)server->pages->bt_size);

	free(rules);

	if (debugonly == true || starter->testing == true)
	{
		if (exclusions > 0 && ua_banned == true && ua_banned_partial == false)
			mcerr << endl << RED << "Warning: existing main rule 'Disallow: /' without 'allow rules' then, other 'disallow rules' are neglected by crawler because not needed." << NOR << mendl; 
	}
	else // Skip saving if we don't have Disallow rules, note that buffer must end with TWO ASCII_NUL and penultimate ASCII_NULL is saved as normal character
	{
		if (starter->testing == false && exclusions > 0)
		{
			if (exclusions > 0)
			{
				storage_status_t storage_status = STORAGE_ERROR;
				doc_hash_t hash_rule = CONF_HASH_DOC_MAX_DEFINITIVE;
				doc_hash_t hash_rules = CONF_HASH_DOC_MAX_DEFINITIVE;

				//siteid_t pos = (((server->site->siteid - 1) + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED);
				siteid_t pos = ((server->site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

				// pass a virtual_id (as docid) at storage because it work with docid_t type and,
				// must be major of 0 like valid docid
				docid_t virtual_id = (docid_t)(pos + 1);

				if (ua_banned == true && ua_banned_partial == false)
				{
					server->pages->bt_size = 3;
					robots_txt_rules_size[starter->inst][pos] = server->pages->bt_size;
					robots_txt_rules[starter->inst][pos] = CBALLOC(char, MALLOC, (server->pages->bt_size + 1));
					robots_txt_rules[starter->inst][pos][0] = ASCII_NUL;
					// load only main disallow rule for buffer reading
					strncpy(robots_txt_rules[starter->inst][pos], "d/", 2);
					robots_txt_rules[starter->inst][pos][(server->pages->bt_size - 1)] = ASCII_NUL;
					robots_txt_rules[starter->inst][pos][server->pages->bt_size] = ASCII_NUL;

					hash_rule = parser_hash(server->pages->bt_size, robots_txt_rules[starter->inst][pos]);

					if (server->pages->bt_size != server->pages->doc->content_length)
					{
						if (server->pages->doc->number_visits > 0 && server->pages->doc->content_length > 0)
						{
							storage_status = ridx->st_idx_delete(starter->inst, virtual_id);

							assert(storage_status == STORAGE_OK);
						}
						else
							storage_status = STORAGE_OK;

						assert(storage_status == STORAGE_OK);
					
						storage_status = ridx->st_idx_write(starter->inst, virtual_id, robots_txt_rules[starter->inst][pos], (off64_t)server->pages->bt_size);

						server->updated_robotstxt = true;

						assert(storage_status == STORAGE_OK);
					}
					else if (server->pages->doc->hash_value_links != hash_rule)
					{
						storage_status = ridx->st_idx_write(starter->inst, virtual_id, robots_txt_rules[starter->inst][pos], (off64_t)server->pages->bt_size);

						server->updated_robotstxt = true;

						assert(storage_status == STORAGE_OK);
					}
					else // document unchanged
						storage_status = STORAGE_OK;

					assert(storage_status == STORAGE_OK);
					
					server->pages->doc->content_length = (off64_t)server->pages->bt_size;

					if (server->pages->doc->hash_value_links != hash_rule)
						server->pages->doc->hash_value_links = hash_rule;
				}
				else if (server->pages->bt_size > 0 && server->pages->bt_size < MAX_DOC_LEN)
				{
					hash_rules = parser_hash(server->pages->bt_size, server->pages->buffer_two);

					if (server->pages->bt_size != server->pages->doc->content_length)
					{
						if (server->pages->doc->number_visits > 0 && server->pages->doc->content_length > 0)
						{
							storage_status = ridx->st_idx_delete(starter->inst, virtual_id);

							assert(storage_status == STORAGE_OK);
						}
						else
							storage_status = STORAGE_OK;

						assert(storage_status == STORAGE_OK);

						storage_status = ridx->st_idx_write(starter->inst, virtual_id, server->pages->buffer_two, (off64_t)server->pages->bt_size);

						server->updated_robotstxt = true;

						assert(storage_status == STORAGE_OK);
					}
					else if (server->pages->doc->hash_value_links != hash_rules)
					{
						storage_status = ridx->st_idx_write(starter->inst, virtual_id, server->pages->buffer_two, (off64_t)server->pages->bt_size);

						server->updated_robotstxt = true;

						assert(storage_status == STORAGE_OK);
					}
					else // document unchanged
						storage_status = STORAGE_OK;
					
					assert(storage_status == STORAGE_OK);
					
					server->pages->doc->content_length = (off64_t)server->pages->bt_size;

					if (server->pages->doc->hash_value_links != hash_rule)
						server->pages->doc->hash_value_links = hash_rule;

					// load for buffer reading
					robots_txt_rules_size[starter->inst][pos] = server->pages->bt_size;
					robots_txt_rules[starter->inst][pos] = server->pages->buffer_two;

					server->pages->bt_size = 0;
					server->pages->buffer_two = NULL;
				}
			}
		}
	}

	// Save sitemaps link only if we are not banned totally
	if (ua_banned == false || ua_banned_partial == true)
	{
		for (off64_t inpos = 0; inpos < doc->raw_content_length; inpos++)
		{
			// Copy a single line
			off64_t linepos = 0;

			while (!IS_EOF() && (inbuf[inpos] != ASCII_NL && inbuf[inpos] != ASCII_CR))
			{
				// skip initial space or tabulators
				if (linepos == 0)
					while (inbuf[inpos] == ASCII_SP || inbuf[inpos] == ASCII_TB)
						inpos++;

				// Do not copy long lines
				if (linepos < MAX_STR_LEN - 10) line[linepos++] = inbuf[inpos];

				inpos++;
			}

			line[linepos++] = ASCII_NL;
			line[linepos]   = ASCII_NUL;

			// Skip the trailing newlines
			while (!IS_EOF() && (inbuf[inpos] == ASCII_NL || inbuf[inpos] == ASCII_CR)) inpos++;

			inpos--;

			// Skip comments
			if (line[0] == '#') {
				continue;
			}

			if (strlen(line) > 8 && (strncasecmp(line,"sitemap:", 8) == 0))
			{ 
				if (starter->testing == true) 
				{
					const sitemap_xml_changefreq_t changefreq = NONE;
					const sitemap_xml_priority_t priority = -1;
					time_t last_modified = static_cast<time_t>(0); // Settato come valore di partenza a 'January 1st 1970 at midnight GMT' Unix Born Date

					parser_analyze_link_sitemap(starter, serverid, &line[9], false, last_modified, changefreq, priority);
				}
				else if (CONF_SEEDER_ADD_ROBOTSXML == true && starter->testing == false) 
				{
					const sitemap_xml_changefreq_t changefreq = NONE;
					const sitemap_xml_priority_t priority = -1;
					time_t last_modified = static_cast<time_t>(0); // Settato come valore di partenza a 'January 1st 1970 at midnight GMT' Unix Born Date

					parser_analyze_link_sitemap(starter, serverid, &line[9], false, last_modified, changefreq, priority);
				}
			}
		}
	}

	// Return the number of exclusions found (NOT the number of bytes, note that
	// the output buffer does not contain valid data)
	return exclusions;
}

//
// Name: parser_process_robotsrdf
//
// Description:
//   Process a sitemap.rdf file [experimental]
//
// Input:
//   doc - the document object
//   inbuf - the contents of the robots.txt file
//
// Return:
//

off64_t parser_process_robotsrdf(starter_t *starter, siteid_t serverid, char *inbuf, char *report, int &rwritten, size_t &rspace)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);

	doc_t *doc = server->pages->doc;

	assert(doc != NULL);

	string site = server->hostname;

	unsigned int nfiles = 0;
	unsigned int tot_nfiles = 0;
	xmlDocPtr xmldoc = NULL;
	xmlXPathContextPtr xmlcontext = NULL;
	xmlNodePtr node	= NULL;

	char href[MAX_STR_LEN] = "";
	const sitemap_xml_changefreq_t changefreq = NONE;
	const sitemap_xml_priority_t priority = -1;
	time_t last_modified = static_cast<time_t>(-1); // Settato come valore di partenza a 'January 1st 1970 at midnight GMT' Unix Born Date
	time_t max_recent_last_modified = static_cast<time_t>(-1); // Settato come valore di partenza a 'January 1st 1970 at midnight GMT' Unix Born Date
	time_t prev_last_modified = server->pages->doc->last_modified;

	// Advance possible whitespace
	inbuf[doc->raw_content_length]	= ASCII_NUL;
	while (isspace(*inbuf))
		inbuf++;

	// Parse the XML file
	xmldoc	= xmlReadMemory(inbuf, doc->raw_content_length, "file:///dev/null", CHARSET_STR(CHARSET_UTF_8),
			XML_PARSE_NOERROR | XML_PARSE_NOWARNING | XML_PARSE_NONET);
//			0);

	// Check if the document was parsed ok
	if (xmldoc == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid sitemap *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		metaddx_status_t status = meta->site_option_set(server->site->siteid, SITE_OPT_VSRDF, false);
		assert(status == METADDX_OK);

		xmlCleanupParser();

		return 0;
	}
	else
	{
		if (http_charset((char *)xmldoc->encoding) != doc->charset)
		{
			// Report
			if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with unreliable charset in sitemap *** ", RED, (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			metaddx_status_t status = meta->site_option_set(server->site->siteid, SITE_OPT_VSRDF, false);
			assert(status == METADDX_OK);

			xmlFreeDoc(xmldoc);
			xmlCleanupParser();

			return 0;
		}
	}

	// Create an XPATH context
	xmlcontext	= xmlXPathNewContext(xmldoc);

	if (xmlcontext == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid sitemap *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		metaddx_status_t status = meta->site_option_set(server->site->siteid, SITE_OPT_VSRDF, false);
		assert(status == METADDX_OK);

		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	#define NAMESPACE_RDF	"http://www.w3.org/1999/02/22-rdf-syntax-ns#"
	#define NAMESPACE_DC	"http://purl.org/dc/elements/1.1/"
	#define NAMESPACE_RSS	"http://purl.org/rss/1.0/"

	// Register namespaces
	xmlXPathRegisterNs(xmlcontext, (const xmlChar *)"rdf",	(const xmlChar *)NAMESPACE_RDF);
	xmlXPathRegisterNs(xmlcontext, (const xmlChar *)"dc",	(const xmlChar *)NAMESPACE_DC);
	xmlXPathRegisterNs(xmlcontext, (const xmlChar *)"rss",	(const xmlChar *)NAMESPACE_RSS);

	// Iterate
	xmlXPathObjectPtr path_obj = xmlXPathEvalExpression((const xmlChar *)"/rdf:RDF/rss:item" , xmlcontext);

	if (path_obj == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid sitemap *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		metaddx_status_t status = meta->site_option_set(server->site->siteid, SITE_OPT_VSRDF, false);
		assert(status == METADDX_OK);

		xmlXPathFreeContext(xmlcontext);
		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	if (path_obj->nodesetval == NULL || path_obj->nodesetval->nodeNr <= 0)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with unacceptable sitemap (wrong namespace) *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		metaddx_status_t status = meta->site_option_set(server->site->siteid, SITE_OPT_VSRDF, false);
		assert(status == METADDX_OK);

		xmlXPathFreeObject(path_obj);
		xmlXPathFreeContext(xmlcontext);
		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	xmlNodePtr ptr	= NULL;
	for(int i=0; i<path_obj->nodesetval->nodeNr; i++) {
		// Extract node
		node	= path_obj->nodesetval->nodeTab[i];

		// This <item> node needs to have children
		if (node->children == NULL) {
			continue;
		}

		strcpy(href, "");
		last_modified = static_cast<time_t>(0);

		// Check children of this <item> element
		ptr = node->children;
		while (ptr != NULL) {

			if (!xmlStrcmp(ptr->name, (const xmlChar *)"link")) {
				// We are on a <link> element, get its content
				if (ptr->children == NULL || (ptr->children->type != XML_TEXT_NODE && ptr->children->type != XML_CDATA_SECTION_NODE)) {
					continue;
				}

				size_t loclen = strlen((char *)(ptr->children->content));

				if (loclen == 0 || loclen >= MAX_STR_LEN)
					continue;

				strcpy(href, (char *)(ptr->children->content));
			}

			if (!xmlStrcmp(ptr->name, (const xmlChar *)"modified")) {
				// We are on a <modified> element, get its content
				if (ptr->children == NULL || ptr->children->type != XML_TEXT_NODE) {
					continue;
				}

				last_modified = get_time((char *)(ptr->children->content), "%Y-%m-%dT%H:%M:%S"); // imposta il timezone il relazione al locale
			}

			ptr = ptr->next;
		}

		// Print to output
		if (strlen(href) > 0)
		{
			if (last_modified > max_recent_last_modified && last_modified > doc->last_modified && last_modified <= time(NULL))
				max_recent_last_modified = last_modified;

			if (last_modified > prev_last_modified) // se l'url è stato modificato dopo l'ultima modifica del feed allora si salva
			{
				if (parser_analyze_link_sitemap(starter, serverid, href, true, last_modified, (sitemap_xml_changefreq_t)changefreq, (sitemap_xml_priority_t)priority) == true)
					nfiles++;
			}

			tot_nfiles++;
		}
	}

	// metodo euristico per stabilire la freschezza del file sitemap
	// si basa sulle date (ufficiose ma utili) dei link presenti nello stesso
	if (debugonly == false && nfiles > 0)
	{
		if (max_recent_last_modified > server->pages->doc->last_modified)
			server->pages->doc->last_modified = max_recent_last_modified;

		server->pages->doc->number_visits_changed++;
	}

	// Free the document
	xmlXPathFreeObject(path_obj);
	xmlXPathFreeContext(xmlcontext);
	xmlFreeDoc(xmldoc);
	xmlCleanupParser();
	
	return tot_nfiles;
}

//
// Name: parser_process_robotsxml
//
// Description:
//   Process a sitemap.xml file [experimental]
//
// Input:
//   doc - the document object
//   inbuf - the contents of the robots.txt file
//
// Return:
//

off64_t parser_process_robotsxml(starter_t *starter, siteid_t serverid, char *inbuf, char *report, int &rwritten, size_t &rspace)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);

	doc_t *doc = server->pages->doc;

	assert(doc != NULL);

	string site = server->hostname;

	unsigned int max_urls_counter = 0;
	unsigned int nfiles = 0;
	unsigned int tot_nfiles = 0;
	xmlDocPtr xmldoc = NULL;
	xmlXPathContextPtr xmlcontext = NULL;
	xmlNodePtr node	= NULL;

	char href[MAX_STR_LEN] = {ASCII_NUL};
	char *canonical_home_href = NULL;
	sitemap_xml_changefreq_t changefreq = NONE;
	sitemap_xml_priority_t priority = -1;
	sitemap_xml_changefreq_t max_changefreq = NEVER; // N.B. La maggiore frequenza di cambiamento corrisponde al numero più basso (0 escluso)
	time_t last_modified = static_cast<time_t>(-1); // Settato come valore di partenza a 'January 1st 1970 at midnight GMT' Unix Born Date
	time_t max_recent_last_modified = static_cast<time_t>(-1); // Settato come valore di partenza a 'January 1st 1970 at midnight GMT' Unix Born Date
	time_t prev_last_modified = server->pages->doc->last_modified;
	time_t canonical_home_last_modified = static_cast<time_t>(-1); // idem come sopra
	int canonical_home_node = INT_MAX; // indica il 'node' appartenete alla eventuale home canonica
	bool changefreq_none = false;

	// Advance possible whitespace
	inbuf[doc->raw_content_length]	= ASCII_NUL;
	while (isspace(*inbuf))
		inbuf++;

	// Parse the XML file
	xmldoc	= xmlReadMemory(inbuf, doc->raw_content_length, "file:///dev/null", CHARSET_STR(CHARSET_UTF_8),
			XML_PARSE_NOERROR | XML_PARSE_NOWARNING | XML_PARSE_NONET);
//			0);

	// Check if the document was parsed ok
	if (xmldoc == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid sitemap *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		xmlCleanupParser();
		// Signal of error condition
		return 0;
	}
	else
	{
		if (http_charset((char *)xmldoc->encoding) != doc->charset)
		{
			// Report
			if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with unreliable charset in sitemap *** ", RED, (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			xmlFreeDoc(xmldoc);
			xmlCleanupParser();

			return 0;
		}
	}

	// Create an XPATH context
	xmlcontext	= xmlXPathNewContext(xmldoc);

	if (xmlcontext == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid sitemap *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	// Register namespaces
	xmlXPathRegisterNs(xmlcontext, (const xmlChar *)"xmlns", (const xmlChar *)"http://www.sitemaps.org/schemas/sitemap/0.9");

	// Iterate
	xmlXPathObjectPtr path_obj = xmlXPathEvalExpression((const xmlChar*) "/xmlns:urlset/xmlns:url", xmlcontext);

	if (path_obj == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid sitemap *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		xmlXPathFreeContext(xmlcontext);
		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	bool sitemapindex = false;

	if (path_obj->nodesetval == NULL || path_obj->nodesetval->nodeNr <= 0) {
		xmlXPathFreeObject(path_obj);

		// First Failed.
		// Try to register another namespace
		path_obj = xmlXPathEvalExpression((const xmlChar*) "/xmlns:sitemapindex/xmlns:sitemap", xmlcontext);

		if (path_obj == NULL)
		{
			// Report
			if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid sitemap *** ", RED, (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			xmlXPathFreeContext(xmlcontext);
			xmlFreeDoc(xmldoc);
			xmlCleanupParser();

			return 0;
		}

		sitemapindex = true;

		if (path_obj->nodesetval == NULL || path_obj->nodesetval->nodeNr <= 0)
		{
			// Report
			if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with unacceptable sitemap (wrong namespace) *** ", RED, (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			xmlXPathFreeObject(path_obj);
			xmlXPathFreeContext(xmlcontext);
			xmlFreeDoc(xmldoc);
			xmlCleanupParser();

			return 0;
		}
	}

	xmlNodePtr ptr	= NULL;

	// Check for maximum urls as specified by 'sitemaps.org'
	for (int i = 0; i < path_obj->nodesetval->nodeNr; i++)
	{
		// Extract node
		node	= path_obj->nodesetval->nodeTab[i];

		// This <item> node needs to have children
		if (node->children == NULL) {
			continue;
		}

		// Check children of this <item> element
		ptr = node->children;

		while (ptr != NULL) {

			if (!xmlStrcmp(ptr->name, (const xmlChar *)"loc")) {
				// We are on a <link> element, get its content
				if (ptr->children == NULL || (ptr->children->type != XML_TEXT_NODE && ptr->children->type != XML_CDATA_SECTION_NODE)) {

					if (canonical_home_href != NULL)
					{
						free(canonical_home_href);
						canonical_home_href = NULL;
					}
	
					ptr = ptr->next;
					continue;
				}

				max_urls_counter++;
			}

			ptr = ptr->next;
		}
	}

	// if urls exceeded the limit imposed by 'sitemaps.org' then exit
	if (max_urls_counter > CONF_MAX_SITEMAP_URLS)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with too many urls *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		xmlXPathFreeObject(path_obj);
		xmlXPathFreeContext(xmlcontext);
		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}
	else
		ptr = NULL;

	// go ahead to find urls
	for (int i = 0; i < path_obj->nodesetval->nodeNr; i++)
	{
		// Extract node
		node	= path_obj->nodesetval->nodeTab[i];

		// This <item> node needs to have children
		if (node->children == NULL) {
			continue;
		}

		strcpy(href, "");
		last_modified = static_cast<time_t>(0);

		// Check children of this <item> element
		ptr = node->children;
		priority = 5; // priority di default equivale a '0.5' // viene usato un singolo numero (convertito in char) per esigenze di spazio
		changefreq = NONE;

		while (ptr != NULL) {

			if (!xmlStrcmp(ptr->name, (const xmlChar *)"loc")) {
				// We are on a <link> element, get its content
				if (ptr->children == NULL || (ptr->children->type != XML_TEXT_NODE && ptr->children->type != XML_CDATA_SECTION_NODE)) {

					if (canonical_home_href != NULL)
					{
						free(canonical_home_href);
						canonical_home_href = NULL;
					}
	
					ptr = ptr->next;
					continue;
				}

				size_t loclen = strlen((char *)(ptr->children->content));

				if (loclen == 0 || loclen >= MAX_STR_LEN) {

					if (canonical_home_href != NULL)
					{
						free(canonical_home_href);
						canonical_home_href = NULL;
					}
	
					ptr = ptr->next;
					continue;
				}

				char *p = NULL;
				char *pslash = NULL;

				// metodo euristico per inserire la home del sito nel caso non sia presente nel file sitemap.xml (eseguito una sola volta)
				p = strstr((char *)(ptr->children->content),"://");

				if (p != NULL)
				{
					p += 3;
					size_t len = strlen(p);

					pslash = strchr(p, ASCII_SL);

					if (pslash == NULL)
					{
						if (len == site.length()) // l'uguaglianza dei due siti viene verificata da 'parser_analyze_link_sitemap'
						{
							canonical_home_node = i;
							canonical_home_href = (char *) malloc ((loclen + 2) * sizeof(char)); // occorre comprendere lo slash finale
						}
					}
					else
					{
						if (len == (site.length() + 1) && p[len -1] == ASCII_SL) // l'uguaglianza dei due siti viene verificata da 'parser_analyze_link_sitemap'
						{
							canonical_home_node = i;
							canonical_home_href = (char *) malloc ((loclen + 1) * sizeof(char));
						}
					}
				}

				if (canonical_home_node == i)
				{
					strcpy(canonical_home_href, (char *)(ptr->children->content));

					if (pslash == NULL)
						strcat(canonical_home_href, "/"); // appendere lo slash finale alla home canonica
				}
				else
					strcpy(href, (char *)(ptr->children->content));
			}

			if (sitemapindex == false && !xmlStrcmp(ptr->name, (const xmlChar *)"changefreq")) {
				// We are on a <modified> element, get its content
				if (ptr->children == NULL || ptr->children->type != XML_TEXT_NODE) {

					if (canonical_home_href != NULL)
					{
						free(canonical_home_href);
						canonical_home_href = NULL;
					}
	
					ptr = ptr->next;
					continue;
				}

				char *p = (char *)(ptr->children->content);
				// pulisce da eventuali spazi iniziali
				unsigned short s = 0;
				while ((p[s] == ASCII_SP || p[s] == ASCII_NL || p[s] == ASCII_CR || p[s] == ASCII_TB) && s < USHRT_MAX) s++;

				changefreq = meta->sitemap_changefreq_encoding(&(p[s]));

				if (canonical_home_node == i && changefreq == NONE)
						changefreq_none = true;

				if (changefreq_none == false && changefreq < max_changefreq && changefreq > 0)
					max_changefreq = changefreq;
			}

			if (sitemapindex == false && !xmlStrcmp(ptr->name, (const xmlChar *)"priority")) {
				// We are on a <modified> element, get its content
				if (ptr->children == NULL || ptr->children->type != XML_TEXT_NODE) {

					if (canonical_home_href != NULL)
					{
						free(canonical_home_href);
						canonical_home_href = NULL;
					}
	
					ptr = ptr->next;
					continue;
				}
				priority = meta->sitemap_priority_encoding((char *)(ptr->children->content));

				if (priority == 9) // la massima 'priority' 9 ("1.0") può averla solo la home canonica
					priority = (sitemap_xml_priority_t)8;
			}

			if (!xmlStrcmp(ptr->name, (const xmlChar *)"lastmod")) {
				// We are on a <modified> element, get its content
				if (ptr->children == NULL || strlen((char *)(ptr->children->content)) > 25 || ptr->children->type != XML_TEXT_NODE) {

					if (canonical_home_href != NULL)
					{
						free(canonical_home_href);
						canonical_home_href = NULL;
					}
	
					ptr = ptr->next;
					continue;
				}

				if (canonical_home_node == i)
					canonical_home_last_modified = get_time((char *)(ptr->children->content), "%Y-%m-%dT%H:%M:%S"); // imposta il timezone il relazione al locale
				else
					last_modified = get_time((char *)(ptr->children->content), "%Y-%m-%dT%H:%M:%S"); // imposta il timezone il relazione al locale
			}

			ptr = ptr->next;
		}

		// Print to output
		if (strlen(href) > 0) {

			if (last_modified > max_recent_last_modified && last_modified > doc->last_modified && last_modified <= time(NULL))
				max_recent_last_modified = last_modified;

			if (last_modified > prev_last_modified) // se l'url è stato modificato dopo l'ultima modifica del feed allora si salva
			{
				if (sitemapindex == false)
				{
					if (canonical_home_node != i && parser_analyze_link_sitemap(starter, serverid, href, true, last_modified, changefreq, priority) == true)
						nfiles ++;
				}
				else
				{
					if (parser_analyze_link_sitemap(starter, serverid, href, false, last_modified, changefreq, priority) == true)
						nfiles ++;
				}
			}

			tot_nfiles++;
		}
	}

	// Salva l'fqdn nel caso non sia presente nel file sitemap
	if (sitemapindex == false)
	{
		if (changefreq_none == false && max_changefreq == NEVER)
			max_changefreq = WEEKLY; // Impostato amministrativamente

		// scrittura nome sito canonico (effettuata a fine processo)
		if (canonical_home_href == NULL)
		{	
			if (strlen(href) > 0)
			{

				char *p = NULL;

				// metodo euristico per inserire la home del sito nel caso non sia presente nel file sitemap.xml (eseguito una sola volta)
				p = strstr(href,"://");

				if (p != NULL)
				{
					p += 3;
					p[0] = ASCII_NUL; // ora si conosce la posizione in cui scrivere in href
					strcpy(p, site.c_str());
					strcat(p, "/");
				}
				// nfiles incrementa solo quando il link è accompagnato da una data aggiornata
				parser_analyze_link_sitemap(starter, serverid, href, true, -1, max_changefreq, meta->sitemap_priority_encoding((char *)("1.0")));
			}
		}
		else
		{
			if (canonical_home_last_modified > max_recent_last_modified && canonical_home_last_modified > doc->last_modified && canonical_home_last_modified <= time(NULL))
				max_recent_last_modified = canonical_home_last_modified;

			if (last_modified > prev_last_modified) // se l'url è stato modificato dopo l'ultima modifica del feed allora si salva
			{
				if (parser_analyze_link_sitemap(starter, serverid, canonical_home_href, true, canonical_home_last_modified, max_changefreq, meta->sitemap_priority_encoding((char*)("1.0"))) == true)
				nfiles++;
			}

			if (canonical_home_href != NULL)
			{
				free(canonical_home_href);
				canonical_home_href = NULL;
			}
		}
	}

	// metodo euristico per stabilire la freschezza del file sitemap
	// si basa sulle date (ufficiose ma utili) dei link presenti nello stesso
	if (debugonly == false && nfiles > 0)
	{
		if (max_recent_last_modified > server->pages->doc->last_modified)
			server->pages->doc->last_modified = max_recent_last_modified;

		server->pages->doc->number_visits_changed++;
	}

	// Free the document
	xmlXPathFreeObject(path_obj);
	xmlXPathFreeContext(xmlcontext);
	xmlFreeDoc(xmldoc);
	xmlCleanupParser();

	return tot_nfiles;
}

//
// Name: parser_process_atom_feedsxml
//
// Description:
//   Process a file of mimetype 'application/atom+xml' or 'application/rss+xml' [experimental]
//
// Input:
//   doc - the document object
//   inbuf - the contents of the feed file
//
// Return:
//

off64_t parser_process_atom_feedsxml(starter_t *starter, siteid_t serverid, char *inbuf, char *report, int &rwritten, size_t &rspace)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);

	doc_t *doc = server->pages->doc;

	assert(doc != NULL);

	string site = server->hostname;

	time_t now = time(NULL);
	unsigned int nfiles = 0;
	unsigned int tot_nfiles = 0;
	xmlDocPtr xmldoc = NULL;
	xmlXPathContextPtr xmlcontext = NULL;
	xmlNodePtr node	= NULL;

	char href[MAX_STR_LEN] = {ASCII_NUL};
	time_t atom_last_modified = static_cast<time_t>(-1); // Settato come valore di partenza a un secondo prima di 'January 1st 1970 at midnight GMT' Unix Born Date
	time_t last_modified = static_cast<time_t>(-1); // Settato come valore di partenza a un secondo prima di 'January 1st 1970 at midnight GMT' Unix Born Date
	time_t max_recent_last_modified = static_cast<time_t>(-1); // Settato come valore di partenza a un secondo prima 'January 1st 1970 at midnight GMT' Unix Born Date
	time_t prev_last_modified = server->pages->doc->last_modified;

	// Advance possible whitespace
	inbuf[doc->raw_content_length]	= ASCII_NUL;
	while (isspace(*inbuf))
		inbuf++;

	// Parse the XML file
	xmldoc	= xmlReadMemory(inbuf, doc->raw_content_length, "file:///dev/null", CHARSET_STR(CHARSET_UTF_8),
			XML_PARSE_NOERROR | XML_PARSE_NOWARNING | XML_PARSE_NONET);
//			0);

	// Check if the document was parsed ok
	if (xmldoc == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid feed *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		doc->has_valid_mimetype = false;
		xmlCleanupParser();
		// Signal of error condition
		return 0;
	}
	else
	{
		if (http_charset((char *)xmldoc->encoding) != doc->charset)
		{
			// Report
			if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with unreliable charset in feed *** ", RED, (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			xmlFreeDoc(xmldoc);
			xmlCleanupParser();

			return 0;
		}
	}

	// Create an XPATH context
	xmlcontext	= xmlXPathNewContext(xmldoc);

	if (xmlcontext == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid feed *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		doc->has_valid_mimetype = false;

		doc->has_valid_mimetype = false;
		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	#define NAMESPACE_ATOM "http://www.w3.org/2005/Atom"

	// Register namespaces
    xmlXPathRegisterNs(xmlcontext, (const xmlChar *)"xmlns",   (const xmlChar *)NAMESPACE_ATOM);

	// Iterate
	xmlXPathObjectPtr path_obj = xmlXPathEvalExpression((const xmlChar*) "/xmlns:feed", xmlcontext);

	if (path_obj == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid feed *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		doc->has_valid_mimetype = false;
		xmlXPathFreeContext(xmlcontext);
		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	if	(path_obj->nodesetval == NULL || path_obj->nodesetval->nodeNr <= 0)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with unacceptable atom feed xml (wrong namespace) *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		doc->has_valid_mimetype = false;
		xmlXPathFreeObject(path_obj);
		xmlXPathFreeContext(xmlcontext);
		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	xmlNodePtr ptr	= NULL;
	bool end_channel = false;
	bool channel_last_modified = false;

	getnodes:

	for(int i=0; i<path_obj->nodesetval->nodeNr; i++) {
		// Extract node
		node	= path_obj->nodesetval->nodeTab[i];

		// This <item> node needs to have children
		if (node->children == NULL) {
			continue;
		}

		strcpy(href, "");
		last_modified = static_cast<time_t>(-1);

		// Check children of this <item> element
		ptr = node->children;

		while (ptr != NULL)
		{

			if (end_channel == false && !xmlStrcmp(ptr->name, (const xmlChar *)"entry"))
			{
				path_obj = xmlXPathEvalExpression((const xmlChar*) "/xmlns:feed/xmlns:entry", xmlcontext);

				if (path_obj == NULL || path_obj->nodesetval == NULL || path_obj->nodesetval->nodeNr <= 0) {
					doc->has_valid_mimetype = false;
					xmlXPathFreeObject(path_obj);
					xmlXPathFreeContext(xmlcontext);
					xmlFreeDoc(xmldoc);
					xmlCleanupParser();

					return 0;
				}
			}

			if (!xmlStrcmp(ptr->name, (const xmlChar *)"link")) {

				xmlAttrPtr attr = xmlHasProp(ptr, (const xmlChar*)"href"); //  search for "href" attribute in the "link" node

				if (attr == NULL)
				{
					ptr = ptr->next;
					continue;
				}
				else
				{
					xmlChar *key = xmlGetProp(ptr, (const xmlChar*)"href");

					if (key == NULL) {
						ptr = ptr->next;
						continue;
					}

					size_t loclen = strlen((char *)(key));

					if (loclen == 0 || loclen >= MAX_STR_LEN) {
						xmlFree(key);
						ptr = ptr->next;
						continue;
					}

					strcpy(href, (char *)(key));

					xmlFree(key);
				}
			}

			if (!xmlStrcmp(ptr->name, (const xmlChar *)"updated")) {
				// We are on a <modified> element, get its content
				if (ptr->children == NULL || strlen((char *)(ptr->children->content)) > 25 || ptr->children->type != XML_TEXT_NODE) {
					ptr = ptr->next;
					continue;
				}

				// Get date
				// ATOM Time Format
				last_modified = get_time((char *)(ptr->children->content), "%Y-%m-%dT%H:%M:%S");
			}

			ptr = ptr->next;
		}

		// Print to output
		if (strlen(href) > 0) {

			if (last_modified > max_recent_last_modified && last_modified > doc->last_modified && last_modified <= now)
				max_recent_last_modified = last_modified;

			
			if (last_modified > prev_last_modified && last_modified <= now) // se l'url è stato modificato dopo l'ultima modifica del feed allora si salva
			{
				if (parser_analyze_link_feeds(starter, serverid, href, (char*)LINK_CAPTION_NEWS_LAST_MODIFIED, true, last_modified, NULL) == true)
					if (end_channel == true)
						nfiles++;
			}

			if (nfiles > 0)
				tot_nfiles++;

			if (end_channel == false) {

				if (last_modified > server->pages->doc->last_modified && last_modified <= now) {
					channel_last_modified = true;
					atom_last_modified = last_modified;
				}

				end_channel = true;
				goto getnodes; 
			}
		}
	}

	// metodo euristico per stabilire la freschezza del file dei feeds (nel caso la data di modifica non fosse presente in 'channel')
	// si basa sulle date (ufficiose ma utili) dei link presenti nello stesso
	if (debugonly == false && nfiles > 0)
	{
		if (channel_last_modified == false && max_recent_last_modified > doc->last_modified && max_recent_last_modified <= now)
		{
			server->pages->doc->last_modified = max_recent_last_modified;
			server->pages->doc->number_visits_changed++;
		}
		else if (channel_last_modified == true)
		{
			server->pages->doc->last_modified = atom_last_modified;
			server->pages->doc->number_visits_changed++;
		}
		else
		{
			xmlXPathFreeObject(path_obj);
			xmlXPathFreeContext(xmlcontext);
			xmlFreeDoc(xmldoc);
			xmlCleanupParser();

			return 0;
		}
	}

	// Free the document
	xmlXPathFreeObject(path_obj);
	xmlXPathFreeContext(xmlcontext);
	xmlFreeDoc(xmldoc);
	xmlCleanupParser();

	return tot_nfiles;
}

//
// Name: parser_process_rss_feedsxml
//
// Description:
//   Process a file of mimetype 'application/atom+xml' or 'application/rss+xml' [experimental]
//
// Input:
//   doc - the document object
//   inbuf - the contents of the feed file
//
// Return:
//

off64_t parser_process_rss_feedsxml(starter_t *starter, siteid_t serverid, char *inbuf, char *report, int &rwritten, size_t &rspace)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);

	doc_t *doc = server->pages->doc;

	assert(doc != NULL);

	string site = server->hostname;

	time_t now = time(NULL);
	unsigned int nfiles = 0;
	unsigned int tot_nfiles = 0;
	xmlDocPtr xmldoc = NULL;
	xmlXPathContextPtr xmlcontext = NULL;
	xmlNodePtr node	= NULL;

	char href[MAX_STR_LEN] = {ASCII_NUL};
	time_t rss_last_modified = static_cast<time_t>(-1); // Settato come valore di partenza a un secondo prima di 'January 1st 1970 at midnight GMT' Unix Born Date
	time_t last_modified = static_cast<time_t>(-1); // Settato come valore di partenza a un secondo prima di 'January 1st 1970 at midnight GMT' Unix Born Date
	time_t max_recent_last_modified = static_cast<time_t>(-1); // Settato come valore di partenza a un secondo prima 'January 1st 1970 at midnight GMT' Unix Born Date
	time_t prev_last_modified = server->pages->doc->last_modified;

	// Advance possible whitespace
	inbuf[doc->raw_content_length]	= ASCII_NUL;
	while (isspace(*inbuf))
		inbuf++;

	// Parse the XML file
	xmldoc	= xmlReadMemory(inbuf, doc->raw_content_length, "file:///dev/null", CHARSET_STR(CHARSET_UTF_8),
			XML_PARSE_NOERROR | XML_PARSE_NOWARNING | XML_PARSE_NONET);
//			0);

	// Check if the document was parsed ok
	if	(xmldoc == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid feed *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		doc->has_valid_mimetype = false;
		xmlCleanupParser();

		return 0;
	}
	else
	{
		if (http_charset((char *)xmldoc->encoding) != doc->charset)
		{
			// Report
			if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with unreliable charset in feed *** ", RED, (unsigned long long int)doc->siteid);
				rspace -= (rwritten - _rwritten);
			}

			xmlFreeDoc(xmldoc);
			xmlCleanupParser();

			return 0;
		}
	}

	// Create an XPATH context
	xmlcontext = xmlXPathNewContext(xmldoc);

	if (xmlcontext == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid feed *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		doc->has_valid_mimetype = false;
		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	#define NAMESPACE_RSS		"http://purl.org/rss/1.0/"
	#define NAMESPACE_RDF		"http://www.w3.org/1999/02/22-rdf-syntax-ns#"
	#define NAMESPACE_DC		"http://purl.org/dc/elements/1.1/"
	#define NAMESPACE_CONTENT	"http://purl.org/rss/1.0/modules/content/"

	// Register namespaces
    xmlXPathRegisterNs(xmlcontext, (const xmlChar *)"rss",   (const xmlChar *)NAMESPACE_RSS);
	xmlXPathRegisterNs(xmlcontext, (const xmlChar *)"rdf",  (const xmlChar *)NAMESPACE_RDF);
    xmlXPathRegisterNs(xmlcontext, (const xmlChar *)"dc",   (const xmlChar *)NAMESPACE_DC);
    xmlXPathRegisterNs(xmlcontext, (const xmlChar *)"content",   (const xmlChar *)NAMESPACE_CONTENT);

	// Iterate
	xmlXPathObjectPtr path_obj = xmlXPathEvalExpression((const xmlChar*) "/rss/channel", xmlcontext);

	if (path_obj == NULL)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with invalid feed *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		doc->has_valid_mimetype = false;
		xmlXPathFreeContext(xmlcontext);
		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	if (path_obj->nodesetval == NULL || path_obj->nodesetval->nodeNr <= 0)
	{
		// Report
		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s*** siteid %llu with unacceptable rss feed xml (wrong namespace) *** ", RED, (unsigned long long int)doc->siteid);
			rspace -= (rwritten - _rwritten);
		}

		doc->has_valid_mimetype = false;
		xmlXPathFreeObject(path_obj);
		xmlXPathFreeContext(xmlcontext);
		xmlFreeDoc(xmldoc);
		xmlCleanupParser();

		return 0;
	}

	xmlNodePtr ptr	= NULL;
	bool end_channel = false;
	bool channel_last_modified = false;

	getnodes:

	for(int i=0; i<path_obj->nodesetval->nodeNr; i++) {
		// Extract node
		node	= path_obj->nodesetval->nodeTab[i];

		// This <item> node needs to have children
		if (node->children == NULL) {
			continue;
		}

		strcpy(href, "");
		last_modified = static_cast<time_t>(-1);

		// Check children of this <item> element
		ptr = node->children;

		while (ptr != NULL)
		{

			if (ptr->children == NULL || (ptr->children->type != XML_ELEMENT_NODE && ptr->children->type != XML_TEXT_NODE && ptr->children->type != XML_CDATA_SECTION_NODE))
			{
				ptr = ptr->next;
				continue;
			}

			if (end_channel == false && !xmlStrcmp(ptr->name, (const xmlChar *)"item"))
			{
				path_obj = xmlXPathEvalExpression((const xmlChar*) "/rss/channel/item", xmlcontext);

				if (path_obj == NULL || path_obj->nodesetval == NULL || path_obj->nodesetval->nodeNr <= 0) {
					doc->has_valid_mimetype = false;
					xmlXPathFreeObject(path_obj);
					xmlXPathFreeContext(xmlcontext);
					xmlFreeDoc(xmldoc);
					xmlCleanupParser();

					return 0;
				}
			}

			if (!xmlStrcmp(ptr->name, (const xmlChar *)"link")) {
				// We are on a <link> element, get its content
				if (ptr->children == NULL || (ptr->children->type != XML_TEXT_NODE && ptr->children->type != XML_CDATA_SECTION_NODE)) {
					ptr = ptr->next;
					continue;
				}


				size_t loclen = strlen((char *)(ptr->children->content));

				if (loclen == 0 || loclen >= MAX_STR_LEN) {

					ptr = ptr->next;
					continue;
				}

				strcpy(href, (char *)(ptr->children->content));
			}

			if (!xmlStrcmp(ptr->name, (const xmlChar *)"pubDate") || !xmlStrcmp(ptr->name, (const xmlChar *)"lastBuildDate")) {
				// We are on a <modified> element, get its content
				if (ptr->children == NULL || ptr->children->type != XML_TEXT_NODE) {
					ptr = ptr->next;
					continue;
				}

				// Get date
				// RSS Time Format
				last_modified = get_time((char *)(ptr->children->content), "%a, %d %b %Y %H:%M:%S");

//				if (last_modified == -1) // opzionale
//					get_time((char *)(ptr->children->content), "%a, %d %b %Y");
			}

			ptr = ptr->next;
		}

		// Print to output
		if (strlen(href) > 0) {

			if (last_modified > max_recent_last_modified && last_modified > doc->last_modified && last_modified <= now)
				max_recent_last_modified = last_modified;

			if (last_modified > prev_last_modified && last_modified <= now) // se l'url è stato modificato dopo l'ultima modifica del feed allora si salva
			{
				if (parser_analyze_link_feeds(starter, serverid, href, (char*)LINK_CAPTION_NEWS_LAST_MODIFIED, true, last_modified, NULL) == true)
					if (end_channel == true)
						nfiles++;
			}

			if (nfiles > 0)
				tot_nfiles++;

			if (end_channel == false) {

				if (last_modified > doc->last_modified && last_modified <= now) {
					channel_last_modified = true;
					rss_last_modified = last_modified;
				}

				end_channel = true;
				goto getnodes; 
			}
		}
	}

	// metodo euristico per stabilire la freschezza del file dei feeds (nel caso la data di modifica non fosse presente in 'channel')
	// si basa sulle date (ufficiose ma utili) dei link presenti nello stesso
	if (debugonly == false && nfiles > 0)
	{
		if (channel_last_modified == false && max_recent_last_modified > doc->last_modified && max_recent_last_modified <= now)
		{
			server->pages->doc->last_modified = max_recent_last_modified;
			server->pages->doc->number_visits_changed++;
		}
		else if (channel_last_modified == true)
		{
			server->pages->doc->last_modified = rss_last_modified;
			server->pages->doc->number_visits_changed++;
		}
		else
		{
			xmlXPathFreeObject(path_obj);
			xmlXPathFreeContext(xmlcontext);
			xmlFreeDoc(xmldoc);
			xmlCleanupParser();

			return 0;
		}
	}

	// Free the document
	xmlXPathFreeObject(path_obj);
	xmlXPathFreeContext(xmlcontext);
	xmlFreeDoc(xmldoc);
	xmlCleanupParser();

	return tot_nfiles;
}

//
// Name: parser_hash
//
// Description:
//   Calculates a hash function for a url
//
// Input:
//   length - the url length
//   content - the url content
// 
// Return:
//   the hash funcion value, between 0 and CONF_HASH_DOC_MAX_DEFINITIVE
//

doc_hash_t parser_hash(off64_t length, char *href)
{
	doc_hash_t hash_value;
	size_t count = 0;

	for (hash_value = 0; count++ <= length; href++)
		hash_value = ((131 + count) * (hash_value == 0 ? 1 : hash_value) + (*href)) % CONF_HASH_DOC_MAX_DEFINITIVE; // MS patch

	return hash_value; 
}

//
// Name: parser_hash_adjacency_list
//
// Description:
//   Calculates a hash function for a structure (valgrind OK)
//
// Input:
//   adjacency_length - the length of structure
//   adjacency - the structure
// 
// Return:
//   the hash funcion value, between 0 and CONF_HASH_DOC_MAX_DEFINITIVE
//

doc_hash_t parser_hash_adjacency_list(unsigned int adjacency_length, out_link_t *adjacency)
{
	doc_hash_t hash_value;
	size_t count = 0;
	size_t size = (sizeof(out_link_t) * adjacency_length);

	// cast to single byte
	uint8_t *padjacency = (uint8_t *)adjacency;

	for (hash_value = 0; count++ < size; padjacency++)
		hash_value = ((131 + count) * (hash_value == 0 ? 1 : hash_value) + (*padjacency)) % CONF_HASH_DOC_MAX_DEFINITIVE; // MS patch

	return hash_value; 
}

//
// Name: eipm (External Indipendent Parser Module)
//
// Descrizione: Si occupa attraverso socket unix di inviare una stringa di dati ai relativi moduli esterni indipendenti
//
// Argomenti: il path assoluto del socket AF_UNIX, il timeout della connessione, il buffer in ingresso,
// la lunghezza del buffer in ingresso e il buffer vuoto che al termine della funzione conterrà i dati elaborati
//
// Restituisce: la lunghezza del buffer contenente i dati elaborati
//
off64_t eipm(const char *sock_path, const double timeout, char *inbuf, off64_t in_length, char *outbuf)
{
	struct sockaddr_un remote;

	int s = socket(AF_UNIX, SOCK_STREAM, 0);

	if (s  == -1)
	{
	//	perror("socket");
		close(s);		
		outbuf[0] = ASCII_NUL;
		return 0;
	}

	// cerr << "Trying to connect to unix socket " << sock_path << " ..." << endl;

	remote.sun_family = AF_UNIX;
	strcpy(remote.sun_path, sock_path);
	int len = strlen(remote.sun_path) + sizeof(remote.sun_family);

	if (connect(s, (struct sockaddr *)&remote, len) == -1)
	{
	//	perror("connect");
		close(s);		
		outbuf[0] = ASCII_NUL;
		return 0;
	}

	// cerr << "Connected." << endl;

	// setta il timeout delle connessioni verso i moduli
	struct timeval tv;
	tv.tv_sec = (int)timeout;
	tv.tv_usec = (int)((long long)(timeout * 1000 * 1000) % (1000 * 1000));

	bool ok = setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (char *) &tv, sizeof(tv)) == 0;

	if (!ok)
		mcerr << "unabled to set SO_RCVTIMEO" << mendl;

	ok = setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, (char *) &tv, sizeof(tv)) == 0;
	////////////////////////////////////////////////////

	if (!ok)
		mcerr << "unabled to set SO_SNDTIMEO" << mendl;

	char head[33];
	snprintf(head, sizeof(head), "%d", (int)in_length);
	char headrec[33];
	int check = 0;
	off64_t ret = -1; 

	if (send(s, head, strlen(head), MSG_NOSIGNAL) == -1)
	{
	//	perror("send");
		close(s);		
		outbuf[0] = ASCII_NUL;
		return 0;
	}

	if ((ret=recv(s, headrec, 33, MSG_NOSIGNAL)) > 0)
	{
		headrec[ret] = ASCII_NUL;

		if (ret > 0)
			check = atoi (headrec);
	}
	else
	{
	//	if (ret < 0)
	//		perror("recv");
	//	else
	//		cerr << "Server closed connection." << endl;

		close(s);		
		outbuf[0] = ASCII_NUL;
		return 0;
	}

	if (check == (int)in_length)
	{
		int done = 0;
		double recv_timeout = 2.00; // (in secondi) valido solo se la ricezione avviene con cicli multipli
		unsigned short cicles = 0;

       		if (send(s, inbuf, in_length, MSG_NOSIGNAL) == -1)	
		{
		//	perror("send");
			close(s);		
			outbuf[0] = ASCII_NUL;
			return 0;
		}

		inbuf = NULL;

		ret = -1; 

		time_t now = time(NULL);

		off64_t readed = 0;

		off64_t datasize = 0;
		bool sizeofdata = true;
		const size_t recvlen = (MAX_STR_LEN * 5);

		do
		{
			char read[recvlen];

			off64_t ret = recv(s, read, (recvlen), MSG_NOSIGNAL);

			if (difftime(time(NULL), now) > recv_timeout)
			{
			//	cerr << "Data receiving timeout." << endl;
				close(s);		
				outbuf[0] = ASCII_NUL;
				return 0;
			}

		        if (ret > 0)
			{
				if ((readed + ret) > (off64_t)CONF_GATHERER_MAXSTOREDSIZE || ret == 1)
				{
				//	cerr << "Document too long." << endl;
					close(s);		
					outbuf[0] = ASCII_NUL;
					return 0;
				}
				else
				{
					if (sizeofdata == true)
					{
						char size[33];

						size_t sl = strlen(read);

						if (sl < 33)
							strcpy(size,read);

						off64_t read_ofst = (sl + 1);


						datasize = atoi(size);

						if (ret > read_ofst)
						{
							off64_t i = 0;

							for (i = readed; i < datasize && read_ofst < ret; i++, read_ofst++)
								outbuf[i] = read[read_ofst];
	
							readed = i;
						}

						sizeofdata = false;
					}
					else
					{
						size_t read_ofst = 0;

						for (off64_t i = readed; i < datasize && (off64_t)read_ofst < ret; i++, read_ofst++)
							outbuf[i] = read[read_ofst];

						readed += ret;
					}
				}
			}
			else
			{
			//	if (ret < 0)
			//		perror("recv");
			//	else
			//		cerr << "Server closed connection." << endl;

				close(s);		
				outbuf[0] = ASCII_NUL;
				return 0;
			}

			cicles++;

			if (cicles > ((MAX_DOC_LEN / recvlen) + MAX_CICLES))
			{
			//	cerr << "Too many cicles in receiving." << endl;
				close(s);		
				outbuf[0] = ASCII_NUL;
				return 0;
			}

		        if (readed == datasize)
				done = 1;

		}
		while (!done);

		close(s);

		outbuf[readed] = ASCII_NUL;

		return readed;
	}

	close(s);

	outbuf[0] = ASCII_NUL;

	return 0;
}

// 
// Name: update_tag_stack
//
// Description:
//   Updates the tag stack to reflect current parser status
//
// Input:
//   tag_stack - the tag_stack
//   current_tag - the current tag
//   event - type of event (start tag/ end tag)
//

void update_tag_stack(int_stack_t *tag_stack, char *current_tag, event_t event){
	em_tag_t tag	= TAG_UNDEF;

	// TO-DO: this should be implemented with a perfhash to make it faster

	// Check if we are on any special tag
	if (strcmp(current_tag, "h1")==0) {
		tag	= TAG_H1;
	} else if (strcmp(current_tag, "h2")==0) {
		tag	= TAG_H2;
	} else if (strcmp(current_tag, "h3")==0) {
		tag	= TAG_H3;
	} else if (strcmp(current_tag, "h4")==0) {
		tag	= TAG_H4;
	} else if (strcmp(current_tag, "h5")==0) {
		tag	= TAG_H5;
	} else if (strcmp(current_tag, "h6")==0) {
		tag	= TAG_H6;
	} else if (strcmp(current_tag, "b")==0) {
		tag	= TAG_B;
	} else if (strcmp(current_tag, "font")==0) {
		tag = TAG_FONT;
	} else if (strcmp(current_tag, "strong")==0) {
		tag = TAG_STRONG;
	}

	// Only these tags may modify the tag stack
	if (tag != TAG_UNDEF) {
		if (event == EVENT_START_TAG) {
			int_stack_push(tag_stack, tag);
		} else {
			int_stack_pop(tag_stack);
		}
	}
}


// 
// Name: seeder_is_rejected_by_extension
//
// Description:
//   Lowercases a extension, then check against
//   extensions_ignore and extensions_log
//
// Input:
//   path - the path and filename to check
//
// Output:
//   extension - the extension, if any
//
// Return:
//   true iff the path must be rejected, based on its extension
//

extension_type_t parser_check_extension(char *path, char *extension)
{
	// Check if there is a path
	if (path == NULL)
		return EXTENSION_NORMAL;

	char pathaux[MAX_STR_LEN];

	strcpy(pathaux,path);

	// Check if it has extension at the tail of link
	url->get_lowercase_extension(pathaux, extension);

	if (strlen(extension) == 0)
		return EXTENSION_NORMAL;

	// Search
	if (perfhash_check(&(extensions_ignore), extension))
		return EXTENSION_IGNORE;
	else if (perfhash_check(&(extensions_stat), extension))
		return EXTENSION_STAT;
	else if (perfhash_check(&(extensions_log), extension))
		return EXTENSION_LOG;

	// Discard the dynamic part
	if (char *x = strchr(pathaux, '?'))
		(*x)	= ASCII_NUL;

	// Check if it has extension before dynamic part
	url->get_lowercase_extension(pathaux, extension);

	if (strlen(extension) == 0)
		return EXTENSION_NORMAL;

	// Search
	if (perfhash_check(&(extensions_ignore), extension))
		return EXTENSION_IGNORE;
	else if (perfhash_check(&(extensions_stat), extension))
		return EXTENSION_STAT;
	else if (perfhash_check(&(extensions_log), extension))
		return EXTENSION_LOG;

	return EXTENSION_NORMAL;
}

void parser_close()
{
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		free(adjacency_list[i]);

	free(adjacency_list);
	free(adjacency_list_length);

	free(adjacency_list_new_link);
	free(number_lines_log);
	free(number_lines_download);

	free(partial_path);

	if (CONF_GATHERER_DOMAIN_USEWHITELIST)
	{
		for (unsigned short i = 0; i < nrwl; i++)
			delete [] pwl[i];

		for (unsigned short i = 0; i < nrgw; i++)
			delete [] pgw[i];
	}

	if (CONF_GATHERER_DOMAIN_BLACKLIST != NULL)
		for (unsigned short i = 0; i < nrbl; i++)
			delete [] pbl[i];

	delete [] pgw;
	delete [] pbl;
	delete [] pwl;

	for(int i=0; i<sessionid_variables_count; i++)
		free(sessionid_variables[i]);

	free(sessionid_variables);

	perfhash_destroy(&(discard_content));
	perfhash_destroy(&(keep_tag));
	perfhash_destroy(&(keep_attribute));
	perfhash_destroy(&(accept_protocol));
	perfhash_destroy(&(keep_special));
	perfhash_destroy(&(extensions_ignore));
	perfhash_destroy(&(extensions_log));
	perfhash_destroy(&(extensions_stat));
	perfhash_destroy(&(extensions_dynamic));

	if (domain_suffixes != NULL)
		string_list_free(domain_suffixes);

	regfree(&sessionid_patterns);
	regfree(&reject_patterns);

	et.index_close ();
}

//
// Name: parser_check_robotstxt
//
// Descriprion: skip url if part of disallow rules of robots.txt
//
// Input:
//	- the rules
//	- the size of all rules for site
//	- the path to check
//
// Return: true if disallowed
//

bool parser_check_robotstxt(server_t *server)
{
	assert(server != NULL);
	assert(server->pages->path != NULL);

	// find where rules are founds
	instance_t rules_inst = ((server->site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t rules_pos = ((server->site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

	if (CONF_SEEDER_ADD_ROBOTSTXT == false)
		return false;

	// no rules of robots.txt for site
	if (robots_txt_rules[rules_inst][rules_pos] == NULL)
	{
		assert(robots_txt_rules_size[rules_inst][rules_pos] == 0);

		return false;
	}

	robots_txt_matched_t *winner = NULL;

	if (url->is_homepage(server->pages->doc->docid)) // is homepage
	{
		char root[2];
		root[0] = ASCII_SL;
		root[1] = ASCII_NUL;

		char *inbuf = robots_txt_rules[rules_inst][rules_pos];
		size_t size = (size_t)robots_txt_rules_size[rules_inst][rules_pos];

		winner = robots_txt_match(inbuf, size, root);

//		if (winner->vote > 0)
//			cout << endl << "Found match for " << root << " with: ";
	}
	else
	{
		char *inbuf = robots_txt_rules[rules_inst][rules_pos];
		size_t size = (size_t)robots_txt_rules_size[rules_inst][rules_pos];

		if (server->pages->path[0] == ASCII_SL)
			winner = robots_txt_match(inbuf, size, server->pages->path);
		else
		{
			// Create a complete path source
			char abs_path[MAX_STR_LEN + MAX_DOMAIN_LEN + URLDDX_PATH_LEN];
			abs_path[0] = ASCII_SL;
			abs_path[1] = ASCII_NUL;

			strcat(abs_path, server->pages->path);

			winner = robots_txt_match(inbuf, size, abs_path);

//			if (winner->vote > 0)
//				cout << endl << "Found match for " << abs_path << " with: ";
		}
	}

	assert(winner != NULL);

	if (winner->vote > 0)
	{
		switch (winner->rule)
		{
			case (ROBOTS_ALLOW):
//				cout << GRE << ROBOT_TXT_RULE_STR(winner->rule);

				free(winner);

				return false;
			case (ROBOTS_DISALLOW):
//				cout << RED << ROBOT_TXT_RULE_STR(winner->rule);

				free(winner);

				server->pages->doc->status = STATUS_DOC_FORBIDDEN;
				server->pages->doc->number_visits++;
				server->pages->doc->last_visit = time(NULL);

				return true;
			default:
//				cout << "Unknown";
				break;
		};

//		cout << ": (" << &winner->rulename[1] << ") (" << winner->vote << ')' << NOR << endl << endl;
	}

	assert(winner != NULL);

	free(winner);

	return false;
}

//
// Name: parser_check_robotstxt
//
// Descriprion: skip url if part of disallow rules of robots.txt of OTHER sites
//
// Input:
//	- the server struct
//	- the string to search
//
// Return: true is disallowed
//

bool parser_check_robotstxt(server_t *server, char *search)
{
	if (CONF_SEEDER_ADD_ROBOTSTXT == false)
		return false;

	assert(search != NULL);

	instance_t rules_inst = ((server->site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t rules_pos = ((server->site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

	// no rules of robots.txt for site
	if (robots_txt_rules[rules_inst][rules_pos] == NULL)
	{
		assert(robots_txt_rules_size[rules_inst][rules_pos] == 0);

		return false;
	}

	size_t size = 0;

	char *psearch = strstr(search, "://");

	if (psearch != NULL)
	{
		psearch += 3;

		if (psearch == NULL)
			return true;

		size_t fqdn_size = strlen(server->hostname);

		while (psearch[size] != ASCII_NUL && psearch[size] != ASCII_SL)
		{
			if (psearch[size] != server->hostname[size])
				return true;

			size++;
		}

		if (size == 0 || size != fqdn_size)
			return true;

		if (psearch[size] == ASCII_NUL ||
			(psearch[size] == ASCII_SL && psearch[(size + 1)] == ASCII_NUL))
			size = 1;
		else if (psearch[size] == ASCII_SL)
			size = strlen(&psearch[size]);
		else
			return true;
	}
	else
	{
		if (search[0] == ASCII_SL)
		{
			psearch = search;

			size = strlen(psearch);
		}
		else
			return true;
	}

	robots_txt_matched_t *winner = NULL;

	if (size == 1)
	{
		char root[2];
		root[0] = ASCII_SL;
		root[1] = ASCII_NUL;

		char *inbuf = robots_txt_rules[rules_inst][rules_pos];
		size_t size = (size_t)robots_txt_rules_size[rules_inst][rules_pos];

		winner = robots_txt_match(inbuf, size, root);

//		if (winner->vote > 0)
//			cout << endl << "Found match for " << root << " with: ";
	}
	else
	{
		char *inbuf = robots_txt_rules[rules_inst][rules_pos];
		size_t size = (size_t)robots_txt_rules_size[rules_inst][rules_pos];

		if (psearch[0] == ASCII_SL)
			winner = robots_txt_match(inbuf, size, psearch);
		else
		{
			// Create a complete path source
			char *abs_path = CBALLOC(char, MALLOC, (size + 2)); // la lunghezza 8 è relativa a 'https://'
			abs_path[0] = ASCII_SL;
			abs_path[1] = ASCII_NUL;

			strncat(abs_path, psearch, size);

			abs_path[(size + 1)] = ASCII_NUL;

			winner = robots_txt_match(inbuf, size, abs_path);

			free(abs_path);

		//	if (winner->vote > 0)
		//		cout << endl << "Found match for " << abs_path << " with: ";
		}
	}

	if (winner->vote > 0)
	{
		switch (winner->rule)
		{
			case (ROBOTS_ALLOW):
//				cout << GRE << ROBOT_TXT_RULE_STR(winner->rule);

				free(winner);

				return false;
			case (ROBOTS_DISALLOW):
//				cout << RED << ROBOT_TXT_RULE_STR(winner->rule);

				free(winner);

				return true;
			default:
//				cout << "Unknown";
				break;
		};

//			cout << ": (" << &winner->rulename[1] << ") (" << winner->vote << ')' << NOR << endl << endl;
	}

	assert(winner != NULL);

	free(winner);

	return false;
}

//
// Name: parser_check_robotstxt
//
// Descriprion: skip url if part of disallow rules of robots.txt of a site, or if must skipped by deny politics rule
//
// Input:
//	- the server struct
//	- the local value
//	- the size of written
//	- the size of partial written
//
// Output:
//  - written
//  - __written
//
// Return:
//

void parser_check_robotstxt(server_t *server, bool &local, int &written, int &__written, siteid_t &resolved_siteid)
{
	assert(server->pages->buffer_links_download != NULL);

	if (server->pages->bld_offset > 0)
		assert(server->pages->buffer_links_download[(server->pages->bld_offset - 1)] == ASCII_NL);

	char *pbuffer_links_download = &server->pages->buffer_links_download[server->pages->bld_offset];

	assert(pbuffer_links_download != NULL);

	urlddx_status_t url_status = URLDDX_NOT_FOUND;

	if (local == false)
	{
		char *p = strstr(&pbuffer_links_download[__written], "://");

		if (p != NULL)
		{
			int ___written = __written;

			___written += ((p - &pbuffer_links_download[___written]) + 3);

			int c = ___written;

			while (pbuffer_links_download[___written] != ASCII_NUL &&
				   pbuffer_links_download[___written] != ASCII_SL &&
				   pbuffer_links_download[___written] != ASCII_SP)
				___written++;

			char *sitename = CBALLOC(char, MALLOC, ((___written - c) + 1));

			strncpy(sitename, &pbuffer_links_download[c], (___written - c));

			sitename[(___written - c)] = ASCII_NUL;

			url_status = url->resolve_site(sitename, &resolved_siteid, NOT_DEFINED);

			///////////////////////////
			//author heitor@nic.br
			//compares the site with the domain list.
			//Modified to download pages targeted by  redirects.
			//it do not downlaod page from redirects of redirects
			if (HTTP_IS_REDIRECT(server->pages->doc->http_status))
			{	// if source TLD is already outside our list, any redirect to other outside TLD is denied
				if (string_list_suffix(domain_suffixes, server->hostname) == false && string_list_suffix(domain_suffixes, sitename) == false)
				{
					free(sitename);

					server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
		
					written = __written;
						
					return;
				}
			}
			else if (string_list_suffix(domain_suffixes, sitename) == false)
			{
				free(sitename);

				server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;
					
				written = __written;
				
				return;
			}

			free(sitename);
		}
	}
	else
		url_status = URLDDX_EXISTENT;

	// if new site we cannot know at prior whats urls are forbiddens
	// but only seeder can help us
	if (url_status == URLDDX_EXISTENT)
	{
		// section to preserve rules of robots.txt's files
		bool breaked = false;
		int c = 0;

		while (pbuffer_links_download[(__written + c)] != ASCII_NUL)
		{
			if (pbuffer_links_download[(__written + c)] == ASCII_SP)
			{
				pbuffer_links_download[(__written + c)] = ASCII_NUL;
				breaked = true;
				break;
			}

			c++;
		}

		assert(c > 0);

		instance_t rules_inst = 0;
		siteid_t rules_pos = 0;

		// find where rules are founds
		if (resolved_siteid > 0 && resolved_siteid != server->site->siteid)
		{
			rules_inst = ((resolved_siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			rules_pos = ((resolved_siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

			// If siteid is know but denied skip his link
			if (meta->site_option_get(resolved_siteid, SITE_OPT_DENY, true) == METADDX_OK)
			{
				server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;

				written = __written;

				return;
			}
		}
		else
		{
			rules_inst = ((server->site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			rules_pos = ((server->site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);
		}

		// no rules of robots.txt for site
		if (robots_txt_rules[rules_inst][rules_pos] == NULL)
		{
			assert(robots_txt_rules_size[rules_inst][rules_pos] == 0);

			if (breaked == true) // restore the 'space'
				pbuffer_links_download[(__written + c)] = ASCII_SP;

			return;
		}

		robots_txt_matched_t *winner = NULL;

		if (pbuffer_links_download[(__written + 1)] == ASCII_NUL && pbuffer_links_download[__written] == ASCII_SL)
		{
			char root[2];
			root[0] = ASCII_SL;
			root[1] = ASCII_NUL;

			char *inbuf = robots_txt_rules[rules_inst][rules_pos];
			size_t size = (size_t)robots_txt_rules_size[rules_inst][rules_pos];

			winner = robots_txt_match(inbuf, size, root);

//			if (winner->vote > 0)
//				cout << endl << "Found match for " << root << " with: ";
		}
		else
		{
			char *inbuf = robots_txt_rules[rules_inst][rules_pos];
			size_t size = (size_t)robots_txt_rules_size[rules_inst][rules_pos];

			if (pbuffer_links_download[__written] == ASCII_SL)
				winner = robots_txt_match(inbuf, size, &pbuffer_links_download[__written]);
			else
			{
				// Create a complete path source
				char abs_path[MAX_STR_LEN + MAX_DOMAIN_LEN + URLDDX_PATH_LEN]; // la lunghezza 8 è relativa a 'https://'
				abs_path[0] = ASCII_SL;
				abs_path[1] = ASCII_NUL;

				assert(server->pages->path != NULL);

				if (server->pages->src_path == NULL)
				{
					if (strlen(server->pages->path) > 0)
					{
						assert(server->pages->path[0] != ASCII_SL);

						strcat(abs_path, server->pages->path);
					}
				}
				else if (strlen(server->pages->src_path) > 0)
				{
					assert(server->pages->src_path[0] != ASCII_SL);

					strcat(abs_path, server->pages->src_path);
				}

				char *p_last_slash = strrchr(abs_path, ASCII_SL);

				assert(p_last_slash != NULL);

				p_last_slash++;

				strcpy(p_last_slash, &pbuffer_links_download[__written]);

				winner = robots_txt_match(inbuf, size, abs_path);

		//		if (winner->vote > 0)
		//			cout << endl << "Found match for " << abs_path << " with: ";
			}
		}

		if (winner->vote > 0)
		{
			switch (winner->rule)
			{
				case (ROBOTS_ALLOW):
//					cout << GRE << ROBOT_TXT_RULE_STR(winner->rule);

					if (breaked == true) // restore the previous removed 'space' on pbuffer_links_download
						pbuffer_links_download[(__written + c)] = ASCII_SP;

					break;;
				case (ROBOTS_DISALLOW):
//					cout << RED << ROBOT_TXT_RULE_STR(winner->rule);

					server->pages->buffer_links_download[server->pages->bld_offset] = ASCII_NUL;

					written = __written;

					break;
				default:
//					cout << "Unknown";
					break;
			};

//			cout << ": (" << &winner->rulename[1] << ") (" << winner->vote << ')' << NOR << endl << endl;
		}
		else if (breaked == true) // restore the previous removed 'space' on pbuffer_links_download
			pbuffer_links_download[(__written + c)] = ASCII_SP;

		assert(winner != NULL);

		free(winner);
	}
}

//
// Verifica se un dominio è possibile salvarlo perchè contiene un nome in whitelist o NON salvarlo perchè contiene un nome in blacklist
//
// Accetta come argomenti il nome del sito da verificare, la matrice delle goodwords, il numero di righe della matrice, la matrice della lista di domini da verificare,
// il numero di righe della matrice dei domini da verificare, un valore booleano che indica se occorre controllare la lista goodwords
//
// restituisce 1 se il dominio è contenuto in matrice
//
bool checkname(const char hrefsitename[], char **plist, unsigned int nrlist, bool ss)
{
	// se 1 indica dominio trovato al termine della ricerca nel puntatore di puntatori plist
	// se 0 indica dominio non trovato al termine della ricerca nel puntatore di puntatori plist
	// se 2 indica che il ciclo deve essere interrotto prematuramente senza effettuare una scansione totale di plist
	short fds = 0;
	short *rowindex = NULL;

	size_t hreflen = strlen(hrefsitename);

	if (ss == true) // verifica i nomi dominio se il dominio contiene goodword
	{
		for (unsigned int i = 0; i < nrgw; i++)
		{
			if (pgw[i][0] == '.') // se la goodword comincia con un punto, la coda di hrefsitename deve essere uguale alla goodword
			{
				size_t len = strlen(pgw[i]);

				if (len < hreflen && strstr(&(hrefsitename[(hreflen - len)]), pgw[i]) != NULL)
					return 1;
			}
			else
				if (strstr(hrefsitename,pgw[i]) != NULL)
					return 1;
		}
	}

	if (nrlist > 0)
	{
		rowindex = CBALLOC(short, CALLOC, nrlist);

		unsigned int n[4] = {0};

		// verifica i nomi dominio a partire dal CARATTERE 4 (perchè normalmente 'www.CARATTERE') e se fino alla fine tutto ok controlla anche i primi 4 caratteri
		for (unsigned short c = 4; c < (strlen(hrefsitename) + 1); c++)
		{
			fds = find_domain_extended(plist, nrlist, rowindex, hrefsitename[c], c, n);

			if (fds == 1)
				for (unsigned short c = 0; c < 4; c++)
				{
					fds = find_domain_extended(plist, nrlist, rowindex, hrefsitename[c], c, n);

					if (fds == 1)
					{
						free(rowindex);
						return 1;
					}
					else if (fds == 2)
					{
						free(rowindex);
						return 0;
					}
				}
			else if (fds == 2)
			{
				free(rowindex);
				return 0;
			}
		}

		free(rowindex);
	}

	return 0;
}

// Serve alla funzione checkname per interrompere prematuramente il processo di ricerca qualora non sia necessario proseguire
//
// Accetta come argomenti la matrice della lista di domini da verificare, il numero di righe della matrice dei domini da verificare, un carattere e la sua
// posizione nella parola da verificare
//
// Restituisce un numero compreso tra 0 e 2
//
short find_domain_extended(char **plist, unsigned int nrlist, short *rowindex, const char &character, unsigned short &pos, unsigned int n [])
{
//	numele -> n[0]
//	numele2 -> n[1]
//	nt -> n[2]  se tale contatore raggiunge il numero di righe in matrice occorre interrompere la funzione di ricerca
//	nto -> n[3]  serve per indicare staticamente il numero di righe della matrice dopo il primo confronto

	if (pos == 4)
	{
		n[0] = 0;
		for (unsigned int rowipos = 0; rowipos < nrlist; rowipos++)
			if (strlen(plist[rowipos]) > 4 && character == plist[rowipos][pos])
				rowindex[n[0]++] = rowipos;

		if (n[0] == 0)
			return 2;

		n[2] = 0;
		n[3] = n[0];
	}
	else
	{
		n[1] = 0;

		for (unsigned int rowipos = 0; rowipos < n[0]; rowipos++)
		{
			if ((plist[rowindex[rowipos]][pos] == ASCII_NUL && character == '\0') || (pos == 3 && plist[rowindex[rowipos]][pos] == character))
				return 1;
			else if (character == plist[rowindex[rowipos]][pos])
				rowindex[n[1]++] = rowindex[rowipos];
			else
			{
				n[2]++;

				if (n[2] == n[3])
				{
					n[2] = 0;
					n[0] = 0;
					return 2;
				}
			}
		}

		n[0] = n[1];
	}

	return 0;
}

// Verifica se un dominio è possibile salvarlo perchè contiene un nome goodwords
//
// restituisce: 1 se il dominio contiene una goodword
bool checkgword(char sitename[])
{
	for (unsigned int i = 0; i < nrgw; i++)
	{
		if (pgw[i][0] == '.')
		{
			if (strstr(&(sitename[strlen(sitename) - strlen(pgw[i])]), pgw[i]) != NULL)
				return 1;
		}
		else
		{
			if (strstr(sitename,pgw[i]) != NULL)
				return 1;
		}

	}

	return 0;
}

//
// Description: lock mutex
//
// Input: The instance of duplicates
//
// Return:
//
void parser_lock_linkidx(instance_t &inst)
{
	int rc = 0;

	if (parser_mutex != NULL)
		if ((rc = pthread_mutex_lock(&(parser_mutex[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

//
// Description: unlock mutex
//
// Input: The instance of duplicates
//
// Return:
//
void parser_unlock_linkidx(instance_t &inst)
{
	int rc = 0;

	if (parser_mutex != NULL)
		if ((rc = pthread_mutex_unlock(&(parser_mutex[inst]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
}

//
// Name: parser_compare_adjacency_list
//
// Description:
//   Compare adjacency list stored and new
//
// Input:
//   src_doc - source document
//   adjacency_list - new list of outgoing links
//   adjacency_list_length - new length of adjacency_list
//
// Return: true if equal
//

bool parser_compare_adjacency_list(instance_t inst, doc_t *src_doc, out_link_t adjacency_list[], unsigned int adjacency_list_length)
{
//	assert(src_doc->docid > 0 && src_doc->docid <= (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));

	// Get links
	out_link_t dest[LINK_MAX_OUTDEGREE];

//	instance_t inst = ((src_doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);

	unsigned int out_degree;

	linkidx_retrieve(lidx, inst, src_doc->docid, dest, &(out_degree));

	// Show
	if (out_degree > 0)
	{
		if (out_degree == adjacency_list_length)
		{
			if (memcmp(&dest, &adjacency_list, (sizeof(out_link_t) * out_degree)) == 0)
				return true;
		}
	}

	return false;
}

//
// Name: parser_save_links
//
// Description:
//   Saves all of the urls from a document
//
// Input:
//   src_doc - source document
//   adjacency_list - list of outgoing links
//   adjacency_list_length - length of adjacency_list
//   

void parser_save_links(doc_t *src_doc, out_link_t adjacency_list[], unsigned int adjacency_list_length)
{
//	assert(src_doc->docid > 0 && src_doc->docid <= (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));

	// Save
	linkidx_status_t rc = linkidx_store(lidx, src_doc->docid, adjacency_list, adjacency_list_length);

	if( rc != LINKIDX_OK )
		mcerr << "[Failed to store links from " << src_doc->docid << "]" << mendl;

	return;
}

//
// Name: parser_analyze_line
// 
// Description:
//   Check line from parser_analyze_link and if url exist and is ok adjust adjacency_list and is not checked by seeder
//
// Input: 
//   starter - starter structure
//   serverid - the serverid
//   resolved_sited - if path had protocol and remote sitename is differend from source sitename, if sitename is found this value must be a valid siteid
//
// Return:
// 	-1 - bad link
// 	 0 - link exists
// 	+1 - link is new or must be passed to seeder unconditionally
//
int parser_analyze_line(starter_t *starter, siteid_t serverid, siteid_t resolved_siteid)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL);
	instance_t inst = starter->inst;

	char *line = &server->pages->buffer_links_download[server->pages->bld_offset];

	int rc = 0;

	errno = 0; // errno is thread-local

	// Source document
	doc_t src_doc;
	memset(&src_doc, 0, sizeof(doc_t));
	char *src_path = NULL;

	// Protocol check
	bool url_had_protocol = false;

	// Readed _url
	size_t linelen = 0;
	char _url[MAX_STR_LEN];
	char caption[MAX_STR_LEN];
	char path_buffer[MAX_STR_LEN];

	//Readed link info
	int rel_pos;
	int tag;
	int caption_length;

	// Format of input lines: (docid link caption)

	if (server->pages->src_path != NULL)
		src_path = server->pages->src_path;
	else
		src_path = server->pages->path;

	_url[0] = ASCII_NUL;
	caption[0] = ASCII_NUL;

	if (!(
		(sscanf( line, "%llu %d %d %s %[^\n]", (unsigned long long int *)((docid_t *)&(src_doc.docid)), &rel_pos, &tag, _url, caption) == 7) ||
		(sscanf( line, "%llu %d %d %s %[^\n]", (unsigned long long int *)((docid_t *)&(src_doc.docid)), &rel_pos, &tag, _url, caption) == 5) || 
		(sscanf( line, "%llu %d %d %s", (unsigned long long int *)((docid_t *)&(src_doc.docid)), &rel_pos, &tag, _url) == 4) ||
		(sscanf( line, "%s %s", _url, caption) == 2) ||
		(sscanf( line, "%s", _url) == 1)))
		return -1; // Malformed

	assert(src_doc.docid == server->pages->doc->docid);

	src_doc.siteid = server->pages->doc->siteid;
	src_doc.depth = server->pages->doc->depth;

	caption_length = strlen(caption);

	// Check length of everything
	if (strlen(_url) >= MAX_STR_LEN || strlen(caption) >= MAX_STR_LEN)
		return -1; // Malformed

	// Check URL for strange characters, all the
	// URL at least has to be printable
	if (has_nonprintable_characters(_url))
		return -1; // Malformed

	// Check depth
	if((src_doc.docid > 0) && (src_doc.depth >= (src_doc.is_dynamic ? CONF_MANAGER_MAXDEPTH_DYNAMIC : CONF_MANAGER_MAXDEPTH_STATIC )))
		return -1; // depth

	// Check if it's not a duplicate
	if ((src_doc.docid > 0) && (src_doc.duplicate_of != (docid_t)0))
		return -1; // We don't include pages from duplicate documents

	// Resolve the link
	docid_t dest = 0;

	char path[MAX_STR_LEN];

	// Check if we have room for new documents
	if (url->pathcount() >= (docid_t)(CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED))
		rc = -1; // too Many Pages

	// Check if the _url includes the '%' character, _urls are stored unescaped
	if (strchr(_url, '%' )) normalize_percent_encoding(_url);

	// Delete newlines, these can be escaped using, e.g.: %0A,
	// so they won't be detected by the gatherer
	if (char *ptr = strchr(_url, '\n')) (*ptr) = ASCII_NUL;

	if (char *ptr = strchr(_url, '\r')) (*ptr) = ASCII_NUL;

	assert(! (strchr(_url, '\n') || strchr(_url, '\r')));

	url_encode(_url);

	// Check length of _url after encoding
	if (strlen(_url) >= MAX_STR_LEN)
		rc = -1; // Malformed

	// Check if the _url has protocol
	if (! url_has_protocol(_url))
	{
		if (src_doc.docid == 0)
		{
			// This can be more serious; abort here
			die("\n*** Url without protocol: '%s'\nThe parser is reading a line that has errors", _url);

			rc = -1;
		}

		// Check if the link starts with a '/'
		if (_url[0] == '/')
		{
			assert(strlen(_url) < MAX_STR_LEN);
			strcpy(path, _url); // It's an absolute _url, copy as-is
		}
		else
		{
			// Relative URL, this have to be converted
			url->relative_path_to_absolute( src_path, _url, path );
		}

		url_adjust_path(path);
	}
	else
	{
		// Remote _url
		// It's a _url that has protocol
		url_adjust_path(_url);

		// Parser variables
		char protocol[MAX_STR_LEN];
		char sitename[MAX_DOMAIN_LEN];
		char *src_sitename = server->hostname;

		// Parse the input _url to fetch protocol, sitename, path
		if (! url->parse_complete_url(_url, protocol, sitename, path))
			rc = -1; // Malformed

		// Convert the sitename to lowercase
		for (unsigned int i = 0; i < strlen(sitename); i++)
		{
			sitename[i] = tolower( sitename[i] );

			if (! isalnum(sitename[i]) && sitename[i] != ASCII_DT && sitename[i] != ASCII_HM && sitename[i] != ASCII_US)
				rc = -1; // Malformed - Site name not acceptable
		}

		url_had_protocol = true;
	}

	// Remove (potential) leading slash from path
	if( path[0] == '/' ) {

		// Copy to auxiliary var
		char pathcpy[MAX_STR_LEN];
		assert( strlen(path) < MAX_STR_LEN );
		strcpy( pathcpy, path );

		// Skip slashes
		uint last_slash = 0;
		while( last_slash < strlen(_url) &&
			_url[last_slash] == '/' ) {
			last_slash++;
		}

		// copy back
		assert( last_slash > 0 );
		assert( strlen(pathcpy + last_slash) < MAX_STR_LEN );
		strcpy( path, pathcpy + last_slash );
	}

	
	// Remove trailing slash from exclusion paths
	if (!strcmp(caption,LINK_CAPTION_FORBIDDEN) && strlen(path) > 0 && path[strlen(path)-1] == '/') 
			path[strlen(path)-1] = ASCII_NUL;

	// se il path èottenuto da un harvesting precedente, i controlli sottoposti da questa condizione NON vengono effettuati ma se ne occupa a monte il gathering
//	if (harvest_status == STATUS_HARVEST_EMPTY ) 
	{	// Reject certains paths
	 	if (regexec( &reject_patterns, path, 0, NULL, 0 ) == 0)
			rc = -1; // Pattern

		// Remove sessionids in URLs
		if (regexec(&sessionid_patterns, path, 0, NULL, 0) == 0)
		{
			for (int i = 0; i < sessionid_variables_count; i++)
				url->remove_variable(path, sessionid_variables[i]);
		}

		// Remove sessionids, heuristic
		url->remove_sessionids_heuristic( path );
	}

	// Sanitize the URL
	url->sanitize_url( path );

	// Resolve
	assert( path[0] != '/' );

	urlddx_status_t urc = URLDDX_NOT_FOUND;

	if (resolved_siteid == 0 && url_had_protocol == true)
	{
		adjacency_list_new_link[inst] = true;

		return 1; // New site. Passing it to seeder for insert in collection
	}
	else if (resolved_siteid > 0 && resolved_siteid != server->site->siteid)
		urc = url->resolve_path(resolved_siteid, path, &dest);
	else
		urc = url->resolve_path(server->pages->doc->siteid, path, &dest);

	if (thread_alarm != THREADS_OK) return -1;

	// New URL
	if (urc == URLDDX_EXISTENT)
	{
		/* Maybe this was an exclusion path for a URL we've already seen
		if (strcmp(caption,LINK_CAPTION_FORBIDDEN) == 0)
		{
			assert(src_doc.mime_type == MIME_ROBOTS_TXT);

			return 1; // document must be marked as forbidden. Passing it to seeder for marking.
		}
		else */
			rc = 0; // document was found, not forbidden and cannot be passed too seeder

		// Go to adjacency list
		if ((src_doc.docid > (docid_t)0) && (dest > (docid_t)0))
		{
			// Append to starter->adjacency list; we will check if the
			// link already exists, or if its a self-link
			if (adjacency_list_length[inst] < (LINK_MAX_OUTDEGREE - 1))
			{
				if( src_doc.docid != dest )
				{
					// This is not a self link
					// See if this is a repeated link
					bool is_repeated	= false;

					for( unsigned int i = 0; i < adjacency_list_length[inst]; i++ )
						if (adjacency_list[inst][i].dest == dest)
						{
							is_repeated	= true;
							break;
						}

					if (is_repeated == false)
					{
						unsigned int offset = adjacency_list_length[inst];

						// This is not a repeated link
						adjacency_list[inst][offset].dest = dest;
						adjacency_list[inst][offset].rel_pos = (char)rel_pos;
						adjacency_list[inst][offset].tag = (char)tag;
						adjacency_list[inst][offset].anchor_length = caption_length;
						adjacency_list_length[inst]++;
					}
				}
			}
		}
	}
	else if (urc == URLDDX_NOT_FOUND)
	{
		adjacency_list_new_link[inst] = true;

		return 1; // new document
	}

	return rc;
}
