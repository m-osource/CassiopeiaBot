/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _SERVER_H_INCLUDED_
#define _SERVER_H_INCLUDED_

#include <config.h>

// System libraries

#include <stdarg.h>
#include <fstream>
#include <netdb.h>
#include <ares.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/poll.h>
#include <zlib.h>
#include <mbedtls/net.h>
#include <mbedtls/ssl.h>
#include <mbedtls/entropy.h>
#include <mbedtls/ctr_drbg.h>
#include <mbedtls/certs.h>
#include <mbedtls/error.h>

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "utils.h"
#include "Meta.h"
#include "Storage.h"
#include "harvestidx.h"
#include "cleanup.h"
#include "linkidx.h"
#include "cmd5.h"
#include "irudiko.h"
#include "http_charset.h"
#include "perfect_hash.h"
#include "Languages.h" // classe delle lingue che identifica la lingua di un documento. N.B. è predisposta per lavorare in multithread attraverso instanze

// Constants

#define REQUEST_MAXSIZE	4096
#define BUFFER_SIZE	32768
#define SERVER_MAX_NAMESERVERS 100
#define SERVER_ROBOTSTXT_TIMEOUT 2 // must be >= CONF_HARVESTER_TIMEOUT_POLL (this is expressed in milliseconds), min 2
#define SERVER_MAX_PREFIX_PROTOCOL_SIZE 8 // https://
#define SERVER_MAX_PREFIX_HTTP_PROTOCOL_SIZE 7 // http://
#define SERVER_MAX_PREFIX_HTTPS_PROTOCOL_SIZE 8 // https://

#define SET_BINARY_MODE(input)

/* These are parameters to inflateInit2. See
 * *    http://zlib.net/manual.html for the exact meanings. */
#define windowBits 15
#define ENABLE_ZLIB_GZIP 32

enum conn_status_t {
	CONN_NONE = 0,
	CONN_ACTIVATING,
	CONN_RESOLVING_WAIT,
	CONN_RESOLVING,
	CONN_ROBOTSTXT_WAIT,
	CONN_CONNECTING,
	CONN_REQUESTING,
	CONN_RECEIVING,
	CONN_DEACTIVATING
};

enum poll_status_t {
	POLL_NOTHING = 0,
	POLL_READY,
	POLL_ERROR,
	POLL_DISCONNECT
};

enum chunked_status_t {
	CHUNCKED_READING_HEX_VALUE = 0,
	CHUNCKED_WAITING_LF,
	CHUNCKED_READING_DATA,
	CHUNCKED_FINISHED,
	CHUNCKED_INIT_HEADER
};

// Structs

typedef struct {
	bool check_lmod; // Last-Modified
	bool check_type; // Content-Type
	bool check_language; // Content-Language
	bool check_location; // Location
	bool check_length; // Content-Length
	bool check_encoding; // Content-Encoding
	bool check_connection; // Connection
} header_status_t;

// Linked list of docs
typedef struct page_ptr {
	doc_t 		*doc;
	char		path[MAX_STR_LEN];
	char		relocation[(SERVER_MAX_PREFIX_PROTOCOL_SIZE + MAX_DOMAIN_LEN + MAX_STR_LEN)];
	char		*src_path; // necessario nel caso si utilizzi il redirect immediato
	bool		redirect_with_invalid_path;
	bool		peer_close;

	mime_type_t mime_type;

	struct	timeval		timestamp_begin_connect;
	struct	timeval		timestamp_end_connect;
	struct	timeval		timestamp_first_read;
	struct	timeval		timestamp_last_read;
	off64_t				bytes_first_packet;
	off64_t				bytes_total;
	ssize_t				chunk_length;
	chunked_status_t 	decoding_state;
	ssize_t				end_chunk_pattern;

	time_t		last_modified;

	unsigned int	speed_measures;

	ssize_t headers_end;
	char *buffer_one;
	ssize_t bo_size;
	ssize_t bo_net_bodysize;
	char *buffer_two;
	ssize_t bt_size;
	char *buffer_links_download;
	ssize_t bld_size;
	ssize_t bld_offset;
	char *buffer_links_log;
	ssize_t bll_size;
	ssize_t bll_offset;

	z_stream *z_strm; // need for 'Zlib'
	ssize_t z_ofs;

	bool redirect_is_relative; // Indica se la nuova locazione del link è relativa o compresa di nome sito
	unsigned short attempts; // contatore tentativi di redirezione metodo HTTP_FOUND
	bool canon_sitemap_xml;

	bool is_fqdn_request; // se 'true' significa che la pagina richiesta è relativa solo al dominio FQDN e cioè del tipo: www.nomesito.it/
	// TUTTI (non viene neppure controllato se si tratta di un url con parametri) i redirect successivi vengono elaborati per un massimo numero di attempts.

	page_ptr	*next; // Linked List
} page_t;

// Server (site + pages + hostname + networkstate)
typedef struct {
	site_t	*site;
	char	*hostname;	// The sitename is in the 'site' structure

	struct sockaddr_storage	*addr; // Support each protocol ipv4, ipv6 ecc..

	siteid_t pool_slot;		// In the 'activepool_poll' list (can be -1)
	siteid_t serverid;		// In the 'servers' list

	// number of chances of dns request
	unsigned char dns_requests;

	// Sezione che oltre a supportare il protocollo HTTPS
	// contiene all'interno della struttura 'socket' il socket 'fd'
	// necessario anche per il protocollo HTTP (variazione del agosto 2015)
	mbedtls_entropy_context entropy;
	mbedtls_ctr_drbg_context ctr_drbg;
	mbedtls_net_context socket; // if socket.fd == -1 is not connected
	mbedtls_ssl_context *ssl;	// necessario per connessioni https
	mbedtls_ssl_config conf;
	mbedtls_x509_crt cacert;

#if defined(MBEDTLS_TIMING_C)
//	mbedtls_timing_delay_context timer;
#endif

	docid_t	ndocs_done;	// docs fetched
	docid_t	ndocs;		// docs in total
	page_t	*pages;		// pages (docs+)

	bool updated_robotstxt; // update robotstxt during harvesting

	unsigned short http_status;

	time_t wait;			// time to wait
	docid_t exclusions_in_this_harvest; // errors of this server in this harvest
	docid_t errors_in_this_harvest; // errors of this server in this harvest

	conn_status_t	conn_status;
	header_status_t header_status;

	struct	timeval		timestamp_resolver_start;
	struct	timeval		timestamp_resolver_lastchance_timeout;
	struct	timeval		timestamp_resolver_end;
} server_t;

#include "page.h"

// #include <parser.h>
extern off64_t parser_process( starter_t *, siteid_t, char *, char *, int &, size_t & );
extern void parser_save_extensions_stats( FILE * );
extern charset_t parser_charset_metadata( server_t *, char * );

// Global vars (from harvester.cc)

extern Storage *strg;
extern Storage *ridx;
extern Meta *meta;
extern Harvest *harv;
extern bool debugonly;
extern SemaphorePrint *sp;
extern bool showlanguages;
extern int CAlen;
extern char *CA;
extern char ***robots_txt_rules;
extern ssize_t **robots_txt_rules_size;
extern atomic<docid_t> robots_txt_ndocs_done;

// Vars

// Functions

// Query
bool server_has_ip( server_t * );
bool server_has_more_documents( server_t * );

// Init
bool server_init_languages();
void server_copy_site( server_t *server, starter_t *starter, site_t *site, const char *hostname, unsigned int serverid );

// Resolve
void server_resolver_prepare( void );
void server_resolver_set( starter_t *, instance_t, unsigned int );
void server_resolver_start( starter_t *, siteid_t & );
void server_resolver_wait ( ares_channel *, instance_t );
void server_resolver_done( server_t *, int &, struct hostent * );

// Connect
void server_connect_start( server_t *, short *, unsigned int *, char * );

// Request
void server_request_start( server_t *server, short *events, uint *timeout_seconds, char *useragent );
void server_request_afterpoll( server_t *server, short revents );
bool server_retry(server_t *server);

// Receive
bool server_receive( server_t *, short *, unsigned int *, char *, perfhash_t );
int server_write_buffer_into_file( ssize_t  readed, server_t *server, char *buffer, ssize_t headers_end, FILE *content_file);
int handle_http_chunked( server_t *server, char *in_buffer, ssize_t  buffer_size, FILE *content_file, ssize_t *current_position);

// Parse headers
ssize_t server_parse_headers( server_t *server, char *buffer, ssize_t bufsize );
uint server_parse_http_code( server_t *server, char *header, uint len );
void server_parse_http_header(server_t *server, char *header, uint len );
ssize_t parse_BOM(ssize_t bufsize, ssize_t pos, char *buffer, server_t *& server);

// Save documents
void server_skip_all( starter_t *, siteid_t, unsigned short );
void server_save_site( server_t *server );
void server_save_current_page( starter_t *, siteid_t );

// Gatherer documents
void server_gatherer( starter_t *, siteid_t, char *, int &, size_t & );
void server_gatherer_getsize(server_t *server, off64_t *raw_content_length);
char *server_gatherer_dataclean(server_t *server, char *inbuf, off64_t *raw_content_length, bool *valid_document, bool *d_check, off64_t *readed_bytes);
char *server_gatherer_detect_charset(server_t *server, char *inbuf, bool *valid_document, off64_t *readed_bytes);
char *server_inflate_partial(server_t *, int &, char *, ssize_t &);


// Close
void server_close( server_t *server );
void server_close_languages( bool close_all );

// Reset buffers
void server_reset_buffers( server_t *server );

#endif
