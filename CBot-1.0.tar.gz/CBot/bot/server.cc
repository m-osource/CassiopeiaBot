/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "server.h"

#define MBEDTLS_X509_CRT_PARSE_C

char SERVER_NAMESERVERS[SERVER_MAX_NAMESERVERS][MAX_STR_LEN];
siteid_t SERVER_COUNT_NAMESERVERS;

// definizione dell'oggetto della classe delle lingue
Languages la;
const size_t min_word_len = 1;

// mbedtls io cheching functions
static int mbedtls_recv_check(void *ctx, unsigned char *buf, size_t len);
static int mbedtls_send_check(void *ctx, const unsigned char *buf, size_t len);

//
// Name: server_init_languages
//
// Description:
//   Load index of language's stop words
//
// Input:
//
// Output:
// 
// Return:
//   true if success

bool server_init_languages()
{
	bool index_status = false;

	if (showlanguages == true && debugonly == true)
		index_status = la.index_setup ( (const size_t)1, true ); // min_word_len == 1
	else
		index_status = la.index_setup ( (const size_t)1, false ); // min_word_len == 1

	if (index_status == false)
		return false;

	return true;
}

//
// Name: a_callback
//
// Description:
//   C-ares: ares callback
//
// Input:
//   Invoked from functions 'ares_gethostbyname' or 'ares_process'
//
// Output:
//
static void a_callback(void *arg, int status, int timeouts, struct hostent *host)
{
	server_t *server = (server_t *)arg;
	assert(server != NULL);

	server_resolver_done(server, status, host);

	assert(server->conn_status == CONN_ACTIVATING || server->conn_status == CONN_RESOLVING);
}


//
// Name: server_resolver_prepare
//
// Description:
//   Prepares the name servers
//
// Input:
//   CONF_HARVESTER_RESOLVCONF
//
// Output:
//   Prepares SERVER_NAMERVERS
//
void server_resolver_prepare(void)
{
	cerr << "Preparing resolvconf ... " << endl;
	char buff[MAX_STR_LEN];
	cerr << "- Config  : " << CONF_HARVESTER_RESOLVCONF << endl;
	cerr << "- Maximum : " << SERVER_MAX_NAMESERVERS << endl;

	strcpy( buff, CONF_HARVESTER_RESOLVCONF );
	SERVER_COUNT_NAMESERVERS	= 0;

	// Tokenize
	char *s = strtok( buff, CONF_LIST_SEPARATOR );
	while (s != NULL)
	{
		if (!strcmp( s, "nameserver"))
		{
			s = strtok( NULL, CONF_LIST_SEPARATOR );

			if (s == NULL)
				die( "Problem while parsing resolvconf" );

			strcpy(SERVER_NAMESERVERS[SERVER_COUNT_NAMESERVERS], s);

			cerr << "- nameserver " << SERVER_NAMESERVERS[SERVER_COUNT_NAMESERVERS] << endl;

			SERVER_COUNT_NAMESERVERS++;

			assert( SERVER_COUNT_NAMESERVERS < SERVER_MAX_NAMESERVERS );

		}

		s = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	cerr << SERVER_COUNT_NAMESERVERS << " found." << endl;
	assert( SERVER_COUNT_NAMESERVERS > 0 );

	// Prepare seed for threadsafe random generator
	srand48((long int)time(NULL));
}

//
// Name: server_has_ip (obsolete)
//
// Description:
//   Checks if the server has a valid ip
//
// Input:
//   server - the server structure
//
// Return:
//   true if the server has a nonzero IP
//

bool server_has_ip(server_t *server)
{
	if (server->http_status == HTTP_ERROR_DNS)
		return false;
	if (server->dns_requests < 3)
		return false;

	return true;
}

//
// Name: server_resolver_wait
//
// Description:
//   C-ares wait on channel for closing filedescriptors
//
// Input:
//   channel - the ares channel
//
// Output:
//

void server_resolver_wait(ares_channel *channel, instance_t inst)
{
	int res = 0;
	struct timeval *tvp = NULL, tv;
	struct timespec *tsp = NULL;
	fd_set read_fds, write_fds;

	tsp = CBALLOC(struct timespec, CALLOC, 1);

	errno = 0; // errno is thread-local

	while (true)
	{
		FD_ZERO(&read_fds);
		FD_ZERO(&write_fds);
		int nfds = ares_fds(*channel, &read_fds, &write_fds);

		/*
		* Warning: This code can be used only for debugging
		//
		if (nfds == 0)
		{
			mcerr << "no more fds to check" << mendl;
			sleep(1);
			continue;
		}
		*/

		// end cicle with success
		if (nfds == 0)
		{
			if (debugonly == true)
				mcerr << "Server resolver wait: On instance " << (unsigned int)inst << " there are no more fds to check" << mendl;

			free(tsp);

			return;
		}

		usleep(500000);
		tv.tv_sec = 1; tv.tv_usec = 0;
		tvp = ares_timeout(*channel, NULL, &tv);

		#ifdef TIMEVAL_TO_TIMESPEC
			TIMEVAL_TO_TIMESPEC(tvp, tsp);
			res = pselect(nfds, &read_fds, &write_fds, NULL, tsp, &action.sa_mask);
		#else
			res = select(nfds, &read_fds, &write_fds, NULL, tvp);
		#endif

		if (res < 0)
       		die("Server resolver_wait: On instance %lu error select: %s", (unsigned long int)inst, cberr());
		else if (res == 0 && debugonly == true)
		{
			mcerr << "Server resolver_wait: On instance " << (unsigned int)inst << " timeout during select" << mendl;
		}

		ares_process(*channel, &read_fds, &write_fds);
	}
}

//
// Name: server_resolver_set
//
// Description:
//   Init resolver and set options
//
// Input:
//   starter - the starter structure
//
// Output:
//
void server_resolver_set(starter_t *starter, instance_t inst, unsigned int harvester_id)
{
    ares_channel *channel = (ares_channel *)starter->a_channel;
	assert(channel != NULL);
    const struct ares_options *options = (struct ares_options *)starter->a_options;
	assert(options != NULL);
    int *optmask = (int *)starter->a_optmask;
	assert(optmask != NULL);

	int status = ares_init_options(channel, (ares_options *)options, *optmask);

	if(status != ARES_SUCCESS)
		die("ares_init_options: %s", ares_strerror(status));

	struct ares_addr_node resolver;

	// Distribute request to all nameservers
	// Note: site will use same nameserver into the same harvest's cycle
	int nresolver = ((inst + harvester_id) % SERVER_COUNT_NAMESERVERS);

	if (CONF_HARVESTER_LOGLEVEL == LOGLEVEL_VERBOSE)
	{
		mcerr << "Resolver will use: " << SERVER_NAMESERVERS[nresolver] << mendl;
	}

	resolver.next = NULL;
	resolver.family = (strchr(SERVER_NAMESERVERS[nresolver], ':') == NULL) ? AF_INET : AF_INET6;

	errno = 0; // errno is thread-local

	if (resolver.family == AF_INET)
		status = inet_pton(resolver.family, SERVER_NAMESERVERS[nresolver], &resolver.addr.addr4);
	else if (resolver.family == AF_INET6)
		status = inet_pton(resolver.family, SERVER_NAMESERVERS[nresolver], &resolver.addr.addr6);

	if (status <= 0)
	{
		if (status == 0)
			die("Nameserver %s not in valid format", SERVER_NAMESERVERS[nresolver]);
		else
		{
			die("inet_pton %s", CBoterr(errno));
			exit(1);
		}

		die("Error generic setting domain name server");
	}
	else
	{
		status = ares_set_servers(*channel, &resolver);

		if (status != ARES_SUCCESS)
			die("ares_set_servers: ", ares_strerror(status));
	}
}

//
// Name: server_resolver_start
//
// Description:
//   Starts the DNS resolver
//
// Input:
//   starter - the starter structure
//   serverid - the serverid through which we can find the server structure inside starter
//
// Output:
//
void server_resolver_start(starter_t *starter, siteid_t &serverid)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &servers[serverid];
	assert( server != NULL );

    ares_channel *channel = (ares_channel *)starter->a_channel;
	assert(channel != NULL);

	// Check hostname
	assert(server->hostname != NULL);
	assert(strlen(server->hostname) > 0);

	// TODO
	// IP Family must be defined by CONF_COLLECTION_IPV6 value
	// It need to setup dir for ipv6 index...s

	// New conn_status
	server->conn_status = CONN_RESOLVING;

	// Submit query
	ares_gethostbyname(*channel, server->hostname, AF_INET, a_callback, server);
	
	// Increments number of dns requests
	server->dns_requests++;

	// Write the time stamp
	gettimeofday(&(server->timestamp_resolver_start), NULL);
}

//
// Name: server_resolver_done
//
// Description:
//   Reads the answer from ares callback 'a_callback'
//
// Input:
//   server - the server
//   status - the ares status
//   host - the hostent structure with basic connection informations
//

void server_resolver_done(server_t *server, int &status, struct hostent *host )
{
	assert(server != NULL);

	assert(server->conn_status == CONN_RESOLVING);

/*
ARES_SUCCESS
    The host lookup completed successfully. 
ARES_ENOTIMP
    The ares library does not know how to find addresses of type family. 
ARES_EBADNAME
    The hostname name is composed entirely of numbers and periods, but is not a valid representation of an Internet address. 
ARES_ENOTFOUND
    The address for name was not found. 
ARES_ENODATA
    The DNS lookup returned no data 
ARES_ENOMEM
    Memory was exhausted. 
ARES_EDESTRUCTION
    The name service channel channel is being destroyed; the query will not be completed.
*/

	// If bad domain is present inside collection this is VERY BAD and exit with assert! 
	if (status == ARES_EBADNAME || status == ARES_ENOTIMP)
	{
		die("%sIP lookup failed for %s %s (%s)", LRE, server->hostname, NOR, ares_strerror(status)); 

		// Keep the time stamp
		gettimeofday(&(server->timestamp_resolver_end), NULL);

		// Status is CONN_ACTIVATING because must be evaluated by activepool_process_nopoll
		server->conn_status = CONN_ACTIVATING;

		// We don't have a valid answer
		server->http_status	= HTTP_ERROR_DNS;

		// Force dns_request to max retries
		server->dns_requests = 2;

		return;
	}

//	assert(status != ARES_EBADNAME && status != ARES_ENOTIMP);

	if (status == ARES_ECANCELLED || status == ARES_EDESTRUCTION || status == ARES_ENOMEM)
	{
		mcerr << RED << "IP lookup failed for " << server->hostname << NOR << " (" << ares_strerror(status) << ')' << mendl;

		// Keep the time stamp
		gettimeofday(&(server->timestamp_resolver_end), NULL);

		// Status is CONN_ACTIVATING because must be evaluated by activepool_process_nopoll
		server->conn_status = CONN_ACTIVATING;

		// We don't have a valid answer
		server->http_status	= HTTP_ERROR_DNS;

		// Force dns_request to max retries
		server->dns_requests = 2;

		return;
	}
    else if (status != ARES_SUCCESS && status != ARES_ENOTFOUND)
    {
        mcerr << RED << "Warning: Resolving " << server->hostname << " c-ares get error: " << NOR << ares_strerror(status) << mendl;

		// Keep the time stamp
		gettimeofday(&(server->timestamp_resolver_end), NULL);

		// Status is CONN_ACTIVATING because must be evaluated by activepool_process_nopoll
		server->conn_status = CONN_ACTIVATING;

		// We don't have a valid answer
		server->http_status	= HTTP_ERROR_DNS;

		// Force dns_request to max retries
		server->dns_requests = 2;

		return;
	}

	if(host == NULL || status == ARES_ENOTFOUND)
	{
		// We have already a first 'HTTP_DNS_STATUS' no other chances
		if (server->http_status == HTTP_ERROR_DNS)
		{
			mcerr << RED << "IP lookup failed for " << server->hostname << NOR << " (" << ares_strerror(status) << ')' << mendl;

			// Keep the time stamp
			gettimeofday(&(server->timestamp_resolver_end), NULL);

			// Status is CONN_ACTIVATING because must be evaluated by activepool_process_nopoll
			server->conn_status = CONN_ACTIVATING;

			// Force dns_request to max retries
			server->dns_requests = 2;
		}
		else
		{
			assert(server->conn_status == CONN_RESOLVING);

			// Keep the time stamp for first resolving
			gettimeofday(&(server->timestamp_resolver_lastchance_timeout), NULL);

			// Get the interval to wait next request
			server->timestamp_resolver_lastchance_timeout.tv_sec += (time_t)((lrand48() % 10) + 1);
			server->timestamp_resolver_lastchance_timeout.tv_usec += ((lrand48() % 1000000));

			// We don't have a valid answer
			server->http_status	= HTTP_ERROR_DNS;

			// first chance failed but keeping 'CONN_RESOLVING' we give a last chance
			mcerr << RED << "first IP lookup failed for " << server->hostname << NOR << " (" << ares_strerror(status) << ')' << mendl;
		}

		return;
	}


	// Keep the time stamp
	gettimeofday(&(server->timestamp_resolver_end), NULL);

	struct in6_addr addr6_any = in6addr_any;
	struct in6_addr addr6_lb = in6addr_loopback;
			// 
	struct sockaddr_in *sai = (struct sockaddr_in *)server->addr;
	struct sockaddr_in6 *sai6 = (struct sockaddr_in6 *)server->addr;
	char *addr_buf = NULL;
	bool astat = false;

	// Keep the address family
	server->addr->ss_family = host->h_addrtype;

	switch (host->h_addrtype)
	{
		case AF_INET:
			// sai->sin_len = sizeof(sai); // ????
			addr_buf = CBALLOC(char, CALLOC, (INET_ADDRSTRLEN + 1));
			ares_inet_ntop(host->h_addrtype, host->h_addr, addr_buf, INET_ADDRSTRLEN);
			
			// The answer may be valid. We don't trust DNS servers,
			// in some cases 0.0.0.0 or 127.0.0.1 is the IP of a host.
			if ((inet_pton(host->h_addrtype, addr_buf, &(sai->sin_addr.s_addr)) <= 0) ||
				(sai->sin_addr.s_addr == htonl(INADDR_ANY)) ||
				(sai->sin_addr.s_addr == htonl(INADDR_LOOPBACK)))
			{
				// The IP is bad (0.0.0.0 or 127.0.0.1)
				mcerr << RED << "Answer seems ok, but the IP resolved for " << server->hostname << " is not valid:: " <<  addr_buf << NOR << mendl;

				// Keep the time stamp
				gettimeofday(&(server->timestamp_resolver_end), NULL);

				// Status is CONN_ACTIVATING because must be evaluated by activepool_process_nopoll
				server->conn_status = CONN_ACTIVATING;

				// We don't have a valid answer
				server->http_status	= HTTP_ERROR_DNS;

				// Force dns_request to max retries
				server->dns_requests = 2;

				return;
			}

			addr_buf[0] = ASCII_NUL;
			astat = get_addr(server->addr, addr_buf);
			assert(astat == true);

			// Finally we have a valid ip address
			mcerr << GRE << "IP for " << server->hostname << " is " << addr_buf << NOR << mendl;

			free(addr_buf);

			if (server->site->protocol == HTTP)
				sai->sin_port = htons(HTTP_PORT);
			else
				sai->sin_port = htons(HTTPS_PORT);
		break;
		case AF_INET6:
			// sai->sin_len = sizeof(sai); // ????
			addr_buf = CBALLOC(char, CALLOC, (INET6_ADDRSTRLEN + 1));
			ares_inet_ntop(host->h_addrtype, host->h_addr, addr_buf, INET6_ADDRSTRLEN);
			
			// The answer may be valid. We don't trust DNS servers,
			// in some cases ::0 ::1 is the IP of a host.
			if ((inet_pton(host->h_addrtype, addr_buf, &(sai6->sin6_addr)) <= 0) ||
				(memcmp(&(sai6->sin6_addr), &addr6_any, sizeof(struct in6_addr)) == 0) ||
				(memcmp(&(sai6->sin6_addr), &addr6_lb, sizeof(struct in6_addr)) == 0))
			{
				// The IP is bad
				mcerr << RED << "Answer seems ok, but the IP resolved for " << server->hostname << " is not valid: " << addr_buf << NOR << mendl;

				// Keep the time stamp
				gettimeofday(&(server->timestamp_resolver_end), NULL);

				// Status is CONN_ACTIVATING because must be evaluated by activepool_process_nopoll
				server->conn_status = CONN_ACTIVATING;

				// We don't have a valid answer
				server->http_status	= HTTP_ERROR_DNS;

				// Force dns_request to max retries
				server->dns_requests = 2;

				return;
			}

			addr_buf[0] = ASCII_NUL;
			astat = get_addr(server->addr, addr_buf);
			assert(astat == true);

			// Finally we have a valid ip address. Note that ipv6 address is always stored in abbreviated form -> 22:0:2:0:0::23 -> 22::2::23
			mcerr << GRE << "IP for " << server->hostname << " is " << addr_buf << NOR << mendl;

			free(addr_buf);

			if (server->site->protocol == HTTP)
				sai6->sin6_port = htons(HTTP_PORT);
			else
				sai6->sin6_port = htons(HTTPS_PORT);
		break;
		default:
			mcerr << RED << "Bad address family resolving hostname " << server->hostname << NOR << mendl;

			// Keep the time stamp
			gettimeofday(&(server->timestamp_resolver_end), NULL);

			// Status is CONN_ACTIVATING because must be evaluated by activepool_process_nopoll
			server->conn_status = CONN_ACTIVATING;

			// We don't have a valid answer
			server->http_status	= HTTP_ERROR_DNS;

			// Force dns_request to max retries
			server->dns_requests = 2;
		break;
	}

//	char client_host[NI_MAXHOST];
//	cout << NI_MAXHOST << endl;
//	cout << NI_MAXSERV << endl;

	// Save the last resolved date
	server->site->last_resolved = time(NULL);

	// Status is CONN_ACTIVATING because must be evaluated by activepool_process_nopoll
	server->conn_status = CONN_ACTIVATING;

	// We have a valid answer
	server->http_status	= HTTP_STATUS_RESOLVED;

	// Force dns_request to '3' that mean we have VALID dns response
	server->dns_requests = 3;
}

//
// Name: server_connect_start
//
// Description:
//   Starts connecting
//
// Input:
//   server - the server to connect
//   useragent - the useragent
//
// Output:
//   server->socket.fd - socket.fd
//   events - for polling
//   timeout - for polling
//

void server_connect_start( server_t *server, short *events, unsigned int *timeout_seconds, char *useragent) {
	assert( server != NULL );
	assert( server->conn_status == CONN_ACTIVATING );
	assert( server->socket.fd == -1 );
	assert( server_has_ip( server ) );
	assert( (*events) == 0 );
	assert( (*timeout_seconds) == 0 );

	errno = 0; // errno is thread-local

	/*
	 * Start the connection
	 */

	server->socket.fd = socket(server->addr->ss_family, SOCK_STREAM, 0);

	if (server->socket.fd < 0)
		die("Error when creating a socket: %s", CBoterr(errno));

	assert(server->socket.fd > 0);

	// Put socket in nonblocking mode
	int rc = fcntl(server->socket.fd, F_SETFL, O_RDWR|O_NONBLOCK);
	assert( rc == 0 );

	if (server->site->protocol == HTTP || server->site->protocol == HTTP_TEMPORARY)
	{

		// Connect (async)
		rc = connect(server->socket.fd, (struct sockaddr *)server->addr, server->addr->ss_family == AF_INET ? sizeof(struct sockaddr_in) : sizeof(struct sockaddr_in6));

		// Note time
		gettimeofday(&(server->pages->timestamp_begin_connect), NULL);

		// Check connect status
		if( errno == EINPROGRESS )
		{
			// Connection in progress
			server->conn_status = CONN_CONNECTING;
			assert(server->socket.fd >= 0);
			(*events)			= POLLOUT;
			(*timeout_seconds)	= CONF_CONNECTION_TIMEOUT;
		}
		else if( rc < 0 )
		{
			// Connect failed
			server->socket.fd = -1;
			server->conn_status = CONN_DEACTIVATING;
			server->http_status	= HTTP_ERROR_CONNECT;
		}
		else
			server_request_start(server, events, timeout_seconds, useragent);
	}
	else if (server->site->protocol == HTTPS || server->site->protocol == HTTPS_TEMPORARY)
	{ ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Prepara il contesto ssl
		assert(server->ssl == NULL);
		server->ssl = CBALLOC(mbedtls_ssl_context, CALLOC, 1);
		//mbedtls_net_init(&server->socket);
		mbedtls_ssl_init(server->ssl);
		mbedtls_ssl_config_init(&server->conf);
		mbedtls_ctr_drbg_init(&server->ctr_drbg);
		mbedtls_x509_crt_init(&server->cacert);
		mbedtls_entropy_init(&server->entropy);

		if (mbedtls_ctr_drbg_seed( &server->ctr_drbg, mbedtls_entropy_func, &server->entropy, (const unsigned char*)SPIDERNAME, strlen(SPIDERNAME)) != 0) goto ssl_exit;
		if (mbedtls_x509_crt_parse(&server->cacert, (const unsigned char*)CA, (CAlen + 1)) != 0) goto ssl_exit; // Load CA 

		// Connect (async)
		rc = connect(server->socket.fd, (struct sockaddr *)server->addr, server->addr->ss_family == AF_INET ? sizeof(struct sockaddr_in) : sizeof(struct sockaddr_in6));

		if (errno == EINPROGRESS)
		{
			int ret = 0;

			if (mbedtls_ssl_config_defaults(&server->conf, MBEDTLS_SSL_IS_CLIENT, MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT) == 0)
			{
			//	if (debugonly == true) mbedtls_ssl_conf_verify( &conf, my_verify, NULL );

				mbedtls_ssl_conf_authmode(&server->conf, MBEDTLS_SSL_VERIFY_OPTIONAL);
				mbedtls_ssl_conf_rng( &server->conf, mbedtls_ctr_drbg_random, &server->ctr_drbg);
				mbedtls_ssl_conf_read_timeout(&server->conf, 0);
				mbedtls_ssl_conf_ca_chain(&server->conf, &server->cacert, NULL);
   				//mbedtls_ssl_conf_dbg(&conf, my_debug, stdout);

				if (mbedtls_ssl_setup(server->ssl, &server->conf) != 0) goto ssl_exit;

				// hostname MUST be used for virtual domains on remote server (Server Name indication - SNI)
				if (mbedtls_ssl_set_hostname(server->ssl, server->hostname) == 0)
				{
					mbedtls_ssl_set_bio(server->ssl, &server->socket, mbedtls_send_check, mbedtls_recv_check, NULL);
				}
				else goto ssl_exit;

				while ((ret = mbedtls_ssl_handshake(server->ssl)) != 0)
					if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE) break;

				// Note time
				gettimeofday(&(server->pages->timestamp_begin_connect), NULL);

				// Connection in progress
				server->conn_status = CONN_CONNECTING;
				assert(server->socket.fd >= 0);
				(*events)			= POLLOUT;
				(*timeout_seconds)	= CONF_CONNECTION_TIMEOUT;
			}
			else
				goto ssl_exit;
		}
		else if (rc < 0)
		{
			ssl_exit:

			// Note time
			gettimeofday(&(server->pages->timestamp_begin_connect), NULL);

			// Connect failed
			server->socket.fd = -1;
			server->conn_status = CONN_DEACTIVATING;
			server->http_status	= HTTP_ERROR_CONNECT;
		}
		else // Connection ok, start request
		{
			// Note time
			gettimeofday(&(server->pages->timestamp_begin_connect), NULL);

			server_request_start( server, events, timeout_seconds, useragent );
		}
	}
}

//
// Name: server_request_start
//
// Description:
//   Start the request
//
// Input:
//   server - the server to start request
//   useragent - the identification of the robot
//  
// Output:
//   events - for polling
//   timeout_seconds - for polling
//

void server_request_start( server_t *server, short *events, uint *timeout_seconds, char *useragent )
{
	assert( server != NULL );
	assert( server->socket.fd >= 0 );
	assert( server->pages != NULL );
	assert( server->pages->doc != NULL );
	assert( (*events) == 0 );
	assert( (*timeout_seconds) == 0 );

	server->pages->canon_sitemap_xml = false;
	server->pages->last_modified = static_cast<time_t>(0);

	timerclear(&(server->pages->timestamp_first_read));
	timerclear(&(server->pages->timestamp_last_read));


	// Consente di gestire gli headers di dimensione maggiore al buffer ricevuto.
	// Ad ogni richiesta i valori devono essere settati a false per il nuovo header
	memset(&(server->header_status), 0, sizeof(server->header_status));
	server->pages->headers_end = 0;

	// before each connect set to null lzip stream
	server->pages->z_strm = NULL;

	// il file è in stato 'broken' da una precedente versione
	// occorre ripristinare il 'mime_type' di default
	switch( server->pages->doc->mime_type ) {

		case MIME_ROBOTS_RDF_BROKEN:
			server->pages->doc->mime_type = MIME_ROBOTS_RDF;
			break;
		case MIME_ROBOTS_XML_BROKEN:
			server->pages->doc->mime_type = MIME_ROBOTS_XML;
			break;
		case MIME_FEEDS_ATOM_XML_BROKEN:
			server->pages->doc->mime_type = MIME_FEEDS_ATOM_XML;
			break;
		case MIME_FEEDS_RSS_XML_BROKEN:
			server->pages->doc->mime_type = MIME_FEEDS_RSS_XML;
			break;
		default:
			break;
	}

	// verifica se si tratta del file sitemap canonico
	if (server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ)
	{
		size_t olen = strlen(FILENAME_ROBOTS_XML);
		size_t plen = strlen(server->pages->path);

		if (olen == plen && strncmp(FILENAME_ROBOTS_XML, server->pages->path, olen) == 0 )
		{
			if (server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ)
			{
				if (plen < (MAX_STR_LEN - 4))
					strcat(server->pages->path, ".gz");
				else
				{
					// Close
					server_reset_buffers( server );
					server_close( server );
					server->conn_status = CONN_DEACTIVATING;
					server->http_status = HTTP_ERROR_REQUESTING;
					return;
				}
			}
			else
					server->pages->canon_sitemap_xml = true;
		}
		else
		{
			// nel caso si tratti di file sitemap 'xml' NON canonico e compresso, l'estensione '.gz' viene sempre concatenata prima della richiesta
			if (server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ)
			{
				if (strlen(server->pages->path) < (MAX_STR_LEN -4))
					strcat(server->pages->path, ".gz");
				else
				{
					// Close
					server_reset_buffers( server );
					server_close( server );
					server->conn_status = CONN_DEACTIVATING;
					server->http_status = HTTP_ERROR_REQUESTING;
					return;
				}
			}
		}
	}

	// nel caso si tratti di file feed 'xml' compresso, l'estensione '.gz' viene sempre concatenata prima della richiesta
	if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ)
	{
		if (strlen(server->pages->path) < (MAX_STR_LEN -4))
			strcat(server->pages->path, ".gz");
		else
		{
			// Close
			server_reset_buffers( server );
			server_close( server );
			server->conn_status = CONN_DEACTIVATING;
			server->http_status = HTTP_ERROR_REQUESTING;
			return;
		}
	}

	// Note time
	gettimeofday(&(server->pages->timestamp_end_connect), NULL);

	// Get memory for request
	char *request		= CBALLOC(char, MALLOC, REQUEST_MAXSIZE);
	uint request_size	= 0;

	page_t *page		= server->pages;
	assert( page != NULL );

	// Create request
	page_create_request( server, page, useragent, REQUEST_MAXSIZE, request, &(request_size) );
	assert( request_size > 0 );

	// Write the request
	ssize_t written = 0;
	unsigned char write_failures = 0;

	errno = 0; // errno is thread-local

	// if (server->ssl == NULL)
	if (server->site->protocol == HTTP || server->site->protocol == HTTP_TEMPORARY)
	{
		int ret = 0;

		while (written < request_size && write_failures < 5)
        {
			ret	= write(server->socket.fd, (request + written), (request_size - written));

			if (ret > 0)
				written += ret;
			else
				write_failures++;
        }
	}
	else if (server->site->protocol == HTTPS || server->site->protocol == HTTPS_TEMPORARY)
	{
		assert(server->ssl != NULL);

		int ret = 0;

		while (written < request_size && write_failures < 5)
        {
            while ((ret = mbedtls_ssl_write(server->ssl, (const unsigned char*)request + written, request_size - written)) <= 0)
                if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE) goto _break;

			if (ret > 0)
				written += ret;
			else
				write_failures++;
        }
	}

	_break:

	// Check if we wrote all the bytes we intend to write
	// Notice that we are will discard this server if
	// we cannot write the request on a single packet
	if (written != (ssize_t)request_size)
	{ 
		// Failed while writing request
		mcerr << RED << "Writing request " << CBoterr(errno) << endl << "> Request for " << server->hostname << "/" << page->path << " failed " << NOR << mendl;

		// Close
		server_reset_buffers( server );
		server_close( server );

		server->conn_status = CONN_DEACTIVATING;
		server->http_status = HTTP_ERROR_REQUESTING;

	}
	else
	{
		harv->hv_incr_bytes_out(((server->site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED), written);
		server->site->bytes_out	+= written;
		// Request sent
		if (CONF_HARVESTER_LOGLEVEL == LOGLEVEL_VERBOSE)
		{
			mcerr << GRE << "> Wrote request for " << server->hostname << "/" << page->path << NOR << mendl;
		}

		// Continue
		server->conn_status	= CONN_REQUESTING;

		(*events)			= POLLIN;
		(*timeout_seconds)	= CONF_HARVESTER_TIMEOUT_READWRITE;
	}

	// Free the memory for the request
	free( request );
}

//
// Nome: server_retry
//
// Descrizione: resetta le variabili del documento affinchè il se possa interrogare nuovamente il server remoto nello stesso ciclo con un diverso url
//
// Accetta: il puntatore 'server'
//
// Restituisce: true (sempre)
//
bool server_retry(server_t *server)
{
	// Occorre reinizializzare i valori di default del documento
	server->pages->doc->raw_content_length = 0;
	server->pages->doc->http_status	= HTTP_STATUS_UNDEFINED;
	server->pages->doc->chunked = false;
	server->pages->doc->content_encoding = ENCODING_NONE;
	server->pages->redirect_is_relative = false;
	server->pages->redirect_with_invalid_path = false;
	server->pages->peer_close = false;

	server->conn_status = CONN_ACTIVATING; // necessario per permettere la rielaborazione

	server_reset_buffers( server );
	server_close( server );	// il socket.fd deve essere chiuso perchè successivamente se ne richiederà uno nuovo per interrogare il nuovo url
	return true;	// esce dalla funzione restituendo lo stato di redirect in modo che sia rielaborato il tutto da capo con il nuovo url	
}

//
// Name: chunk_error_ingore_line
//
// Description:
//   function that set an line with an error in chunked encoding to be written in the buffer.
//
// Input:
//   server - the server object
//   buffer_size - the size of the buffer
//   current_position - the position to start reading the buffer
//   in_buffer - the buffer with data
//
// Output:
//   server->pages->chunk_length is updated with the length of the next line
//
void chunk_error_ingore_line(server_t *server, ssize_t buffer_size, ssize_t current_position, char *in_buffer){
    server->pages->chunk_length = 0;
    for(int i = 0;i < buffer_size - (current_position);i++)
        if(in_buffer[current_position + i] == '\r'){
            server->pages->chunk_length = i;
            break;
        }


    if(server->pages->chunk_length == 0)
        server->pages->chunk_length = buffer_size - (current_position);

}


//
// Name: parse_chunked_header
//
// Description:
//   parses chunk headers
//
// Input:
//   in_buffer - the buffer with data
//   buffer_size - the size of the buffer
//   current_position - the position to start reading the buffer
//   server - the server object
//
// Output:
//   server->pages->chunk_length is updated with the length of the next chunk to be readed;
//   server->pages->decoding_state is updated acordingly with the state of the parser
//   current_position is updated
//
// Return
//   false if an error has occured in the parsing process
//
bool parse_chunked_header(char *in_buffer, ssize_t buffer_size, ssize_t *current_position, server_t *server){
	while (*current_position < buffer_size && server->pages->decoding_state != CHUNCKED_READING_DATA){
		if (server->pages->decoding_state == CHUNCKED_INIT_HEADER ){
			if (in_buffer[*current_position] == '\n'){
				server->pages->decoding_state = CHUNCKED_READING_HEX_VALUE;

			} else if (in_buffer[*current_position] != '\r'){

				chunk_error_ingore_line(server, buffer_size, *current_position, in_buffer);
				server->pages->decoding_state = CHUNCKED_READING_DATA;
				return false;
			}

		} else if (in_buffer[*current_position] == '\n'){
			server->pages->decoding_state = CHUNCKED_READING_DATA;

		} else if (server->pages->decoding_state == CHUNCKED_READING_HEX_VALUE &&
				parse_hex_char(in_buffer[*current_position]) >= 0){

				if (server->pages->chunk_length < 0)
					server->pages->chunk_length = 0;

				server->pages->chunk_length = 16*server->pages->chunk_length + parse_hex_char(in_buffer[*current_position]);


		} else if (server->pages->decoding_state == CHUNCKED_READING_HEX_VALUE) {
			if (server->pages->chunk_length >= 0) {
				server->pages->decoding_state = CHUNCKED_WAITING_LF;
				//cerr << server->hostname << "/" << server->pages->path << ": valor:" << server->pages->chunk_length << endl;
			} else {
				server->pages->decoding_state = CHUNCKED_READING_DATA;
				chunk_error_ingore_line(server, buffer_size, *current_position, in_buffer);

				//cerr << server->hostname << "/" << server->pages->path << ": erro ao analizar o cabeçalho do bloco. caractere: " << in_buffer[*current_position] <<". posição: "<< *current_position << " estado" << server->pages->decoding_state << endl;
				return false;
			}
		}
		(*current_position)++;
	}
	return true;
}


//
// Name: write_into_file
//
// Description:
//   write the specified bytes of the in_buffer into a file
//
// Input:
//   server - the server object
//   in_buffer - the buffer with data
//   current_position - the position to start reading the buffer
//   bytes_to_read - the amount of bytes to read from the in buffer and write into the content
//
// Output:
//   server->pages->doc->raw_content_length is updated with the amount of bytes read;
//   current_position is updated
//
int write_into_file(server_t *server, char *in_buffer, ssize_t *current_position, ssize_t bytes_to_read) {
	/* parse init BOM at the beging of the file
	* compito svolto 'a valle' dalla funzione 'server_gatherer' con l'ausilio
	* della libreria 'universalchardet', quando si èoramai 'sicuri' che il testo ricevuto èin chiaro'
	if (server->pages->doc->raw_content_length == 0)
		//cerr << "offset antes = " << headers_end << endl;
		ssize_t offset_BOM = parse_BOM(bytes_to_read, *current_position, in_buffer, server);
		//cerr << "offset bom= " << offset_BOM << endl;
		if (offset_BOM > 0){
			*current_position += offset_BOM;
			//cerr << "offset depois = " << headers_end << endl;
			bytes_to_read -= offset_BOM;
		}
	}
	*/

	// Check first if there is nothing to do because not enough memory
	if (server->pages->doc->content_encoding == ENCODING_NONE)
	{
		if ((server->pages->doc->mime_type == MIME_ROBOTS_XML &&
			(server->pages->doc->raw_content_length + bytes_to_read) > ((ssize_t)CONF_MAX_SITEMAP_FILE_SIZE + (ssize_t)MAX_STR_LEN)) || 
			((server->pages->doc->raw_content_length + bytes_to_read) > ((ssize_t)CONF_MAX_FILE_SIZE + (ssize_t)MAX_STR_LEN)))
		{
			// File to download is too large
			mcerr << BRO << "Content-Length: too large (docid " << server->pages->doc->docid << ") size "
			<< server->pages->bo_size << " reset to 0! "
			<< "Nothing to download!" << NOR << mendl;

			if( server->pages->doc->mime_type == MIME_ROBOTS_RDF )
				server->pages->doc->mime_type = MIME_ROBOTS_RDF_BROKEN;
			else if (server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ) // interrotto
				server->pages->doc->mime_type = MIME_ROBOTS_XML_BROKEN;
			else if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML || server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ) // interrotto
				server->pages->doc->mime_type = MIME_FEEDS_ATOM_XML_BROKEN;
			else if (server->pages->doc->mime_type == MIME_FEEDS_RSS_XML || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ) // interrotto
				server->pages->doc->mime_type = MIME_FEEDS_RSS_XML_BROKEN;
			else if (server->pages->doc->mime_type == MIME_APPLICATION_PDF) // pdf interrotto
				server->pages->doc->mime_type = MIME_APPLICATION_PDF_BROKEN;

			return Z_MEM_ERROR;
		}
	}
	else
	{
		if ((server->pages->doc->mime_type == MIME_ROBOTS_XML &&
			(server->pages->z_ofs + MAX_WBITS) > ((ssize_t)CONF_MAX_SITEMAP_FILE_SIZE + (ssize_t)MAX_STR_LEN)) || 
			((server->pages->z_ofs + MAX_WBITS) > ((ssize_t)CONF_MAX_FILE_SIZE + (ssize_t)MAX_STR_LEN)))
		{
			// File to download is too large
			mcerr << BRO << "Content-Length: too large (docid " << server->pages->doc->docid << ") size "
			<< server->pages->bo_size << " reset to 0! "
			<< "Nothing to download!" << NOR << mendl;

			if( server->pages->doc->mime_type == MIME_ROBOTS_RDF )
				server->pages->doc->mime_type = MIME_ROBOTS_RDF_BROKEN;
			else if (server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ) // interrotto
				server->pages->doc->mime_type = MIME_ROBOTS_XML_BROKEN;
			else if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML || server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ) // interrotto
				server->pages->doc->mime_type = MIME_FEEDS_ATOM_XML_BROKEN;
			else if (server->pages->doc->mime_type == MIME_FEEDS_RSS_XML || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ) // interrotto
				server->pages->doc->mime_type = MIME_FEEDS_RSS_XML_BROKEN;
			else if (server->pages->doc->mime_type == MIME_APPLICATION_PDF) // pdf interrotto
				server->pages->doc->mime_type = MIME_APPLICATION_PDF_BROKEN;

			return Z_MEM_ERROR;
		}
	}

	// Try to allocate memory if needed
	if (server->pages->doc->content_encoding == ENCODING_NONE)
	{
		while ((server->pages->doc->raw_content_length + bytes_to_read) > (server->pages->bo_size - 1))
		{
			auto min_required_size = server->pages->bo_size;

			// in caso di contenuti privi di compressione il Content-Length puòessere inaccurato e occorre considerare la lunghezza superiore del buffer
			// increase memory space whn needed
			while (min_required_size <= server->pages->bo_size)
			{
				if ((server->pages->bo_net_bodysize + MAX_STR_LEN) > min_required_size)
					min_required_size = (server->pages->bo_net_bodysize + MAX_STR_LEN);
				else
					min_required_size += (MAX_STR_LEN * 5);
			}

			if (server->pages->doc->mime_type == MIME_ROBOTS_XML && min_required_size > (ssize_t)CONF_MAX_SITEMAP_FILE_SIZE)
			{
				if (server->pages->bo_size > (ssize_t)CONF_MAX_SITEMAP_FILE_SIZE)
					min_required_size = ((ssize_t)CONF_MAX_SITEMAP_FILE_SIZE + (ssize_t)MAX_STR_LEN); // end of memory availabitity
			}
			else if (min_required_size > (ssize_t)CONF_MAX_FILE_SIZE)
			{
				if (server->pages->bo_size > (ssize_t)CONF_MAX_FILE_SIZE)
					min_required_size = ((ssize_t)CONF_MAX_FILE_SIZE + (ssize_t)MAX_STR_LEN); // end of memory availabitity
			}

			if ((server->pages->doc->mime_type == MIME_ROBOTS_XML &&
				(min_required_size > ((ssize_t)CONF_MAX_SITEMAP_FILE_SIZE + (ssize_t)MAX_STR_LEN))) ||
				(min_required_size > ((ssize_t)CONF_MAX_FILE_SIZE + (ssize_t)MAX_STR_LEN)))
			{
				// File to download is too large
				mcerr << BRO << "Content-Length: too large (docid " << server->pages->doc->docid << ") size "
				<< server->pages->bo_size << " reset to 0! "
				<< "Nothing to download!" << NOR << mendl;

				if( server->pages->doc->mime_type == MIME_ROBOTS_RDF )
					server->pages->doc->mime_type = MIME_ROBOTS_RDF_BROKEN;
				else if (server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ) // interrotto
					server->pages->doc->mime_type = MIME_ROBOTS_XML_BROKEN;
				else if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML || server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ) // interrotto
					server->pages->doc->mime_type = MIME_FEEDS_ATOM_XML_BROKEN;
				else if (server->pages->doc->mime_type == MIME_FEEDS_RSS_XML || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ) // interrotto
					server->pages->doc->mime_type = MIME_FEEDS_RSS_XML_BROKEN;
				else if (server->pages->doc->mime_type == MIME_APPLICATION_PDF) // pdf interrotto
					server->pages->doc->mime_type = MIME_APPLICATION_PDF_BROKEN;

				return Z_MEM_ERROR;
			}

			assert(min_required_size > server->pages->bo_size);

			const auto delta = (size_t)(BUFFER_SIZE * 2);

			char *p = CBREALLOC(char, ssize_t, server->pages->buffer_one, server->pages->bo_size, min_required_size, delta);

			if (p == NULL)
			{
				mcerr << BRO << "Internal error: memory allocation problem (docid " << server->pages->doc->docid << ") " << NOR << mendl;

				return Z_MEM_ERROR;
			}

			server->pages->buffer_one = p; // buffer now point to new memory area
		}
	}
	else
	{
		while ((server->pages->z_ofs + MAX_WBITS) > server->pages->bo_size)
		{
			auto min_required_size = (server->pages->bo_size + (MAX_WBITS * 5));

			// in caso di contenuti privi di compressione il Content-Length puòessere inaccurato e occorre considerare la lunghezza superiore del buffer
			// increase memory space whn needed
			while (min_required_size <= (server->pages->z_ofs + BUFFER_SIZE))
				if (server->pages->bo_net_bodysize > 0) min_required_size += (server->pages->bo_net_bodysize * 2);
				else min_required_size += (MAX_WBITS * 5); // Bytes */

			if (server->pages->doc->mime_type == MIME_ROBOTS_XML && min_required_size > (ssize_t)CONF_MAX_SITEMAP_FILE_SIZE)
			{
				if (server->pages->bo_size > (ssize_t)CONF_MAX_SITEMAP_FILE_SIZE)
					min_required_size = ((ssize_t)CONF_MAX_SITEMAP_FILE_SIZE + (ssize_t)MAX_STR_LEN); // end of memory availabitity
			}
			else if (min_required_size > (ssize_t)CONF_MAX_FILE_SIZE)
			{
				if (server->pages->bo_size > (ssize_t)CONF_MAX_FILE_SIZE)
					min_required_size = ((ssize_t)CONF_MAX_FILE_SIZE + (ssize_t)MAX_STR_LEN); // end of memory availabitity
			}

			if ((server->pages->doc->mime_type == MIME_ROBOTS_XML &&
				((min_required_size > ((ssize_t)CONF_MAX_SITEMAP_FILE_SIZE + (ssize_t)MAX_STR_LEN)) ||
				(server->pages->bo_size > ((ssize_t)CONF_MAX_SITEMAP_FILE_SIZE + (ssize_t)MAX_STR_LEN)))) ||
				((min_required_size > ((ssize_t)CONF_MAX_FILE_SIZE + (ssize_t)MAX_STR_LEN)) ||
				(server->pages->bo_size > ((ssize_t)CONF_MAX_FILE_SIZE + (ssize_t)MAX_STR_LEN))))
			{
				// File to download is too large
				mcerr << BRO << "Content-Length: too large (docid " << server->pages->doc->docid << ") size "
				<< server->pages->bo_size << " reset to 0! "
				<< "Nothing to download!" << NOR << mendl;

				if( server->pages->doc->mime_type == MIME_ROBOTS_RDF )
					server->pages->doc->mime_type = MIME_ROBOTS_RDF_BROKEN;
				else if (server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ) // interrotto
					server->pages->doc->mime_type = MIME_ROBOTS_XML_BROKEN;
				else if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML || server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ) // interrotto
					server->pages->doc->mime_type = MIME_FEEDS_ATOM_XML_BROKEN;
				else if (server->pages->doc->mime_type == MIME_FEEDS_RSS_XML || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ) // interrotto
					server->pages->doc->mime_type = MIME_FEEDS_RSS_XML_BROKEN;
				else if (server->pages->doc->mime_type == MIME_APPLICATION_PDF) // pdf interrotto
					server->pages->doc->mime_type = MIME_APPLICATION_PDF_BROKEN;

				return Z_MEM_ERROR;
			}

			assert(min_required_size > server->pages->bo_size);

			const auto delta = (size_t)(BUFFER_SIZE * 2);

			char *p = CBREALLOC(char, ssize_t, server->pages->buffer_one, server->pages->bo_size, min_required_size, delta);

			if (p == NULL)
			{
				mcerr << BRO << "Internal error: memory allocation problem (docid " << server->pages->doc->docid << ") " << NOR << mendl;

				return Z_MEM_ERROR;
			}

			server->pages->buffer_one = p; // buffer now point to new memory area
		}
	}

	//cerr << server->hostname << "/" << server->pages->path << ": saved bytes = " << number_of_bytes << endl;
	//cerr << server->hostname << "/" << server->pages->path << ": bytes to read now = " << bytes_to_read << endl;
	int z_ret = 0;

	// save to 'server->pages->buffer_one'
	if (debugonly == false)
	{
		if (server->pages->headers_end > 0 && server->pages->doc->content_encoding != ENCODING_NONE)
		{
			server->pages->buffer_one = server_inflate_partial(server, z_ret, &in_buffer[(*current_position)], bytes_to_read);

			if (z_ret == Z_MEM_ERROR) return z_ret;

			server->pages->doc->raw_content_length += bytes_to_read;
			*current_position += bytes_to_read;
		}
		else
		{
			if (server->pages->bo_size <= (server->pages->doc->raw_content_length + bytes_to_read))
			{
				mcerr << "For docid " << server->pages->doc->docid << ": buffer oversize." << endl; 
				cerr << "On path " << server->pages->path << ": buffer oversize." << mendl; 
				abort();
			}

			if ( server->pages->doc->mime_type == MIME_ROBOTS_XML )
			{
				if ((off64_t)(CONF_MAX_SITEMAP_FILE_SIZE + MAX_STR_LEN) <= (server->pages->doc->raw_content_length + bytes_to_read))
				{
					mcerr << "For docid " << server->pages->doc->docid << ": buffer oversize." << endl; 
					cerr << "On path " << server->pages->path << ": buffer oversize." << mendl; 
					abort();
				}
			}
			else
			{
				if ((off64_t)(CONF_MAX_FILE_SIZE + MAX_STR_LEN) <= (server->pages->doc->raw_content_length + bytes_to_read))
				{
					mcerr << "For docid " << server->pages->doc->docid << ": buffer oversize." << endl; 
					cerr << "On path " << server->pages->path << ": buffer oversize." << mendl; 
					abort();
				}
			}

			memcpy(server->pages->buffer_one + server->pages->doc->raw_content_length, &(in_buffer[(*current_position)]), bytes_to_read);
			server->pages->doc->raw_content_length += bytes_to_read;
			server->pages->buffer_one[server->pages->doc->raw_content_length] = ASCII_NUL;
			*current_position += bytes_to_read;
		}
	}

	return z_ret;
}

//
// Name: handle_http_chunked
//
// Description:
//   if a the content of a http response is transfered with chunked encoding, this method must be used
//
// Input:
//   server - the server object
//   in_buffer - the buffer with data
//   buffer_size - the size of the buffer
//   current_position - the position to start reading the buffer
//
// Output:
//   server->pages->decoding_state is updated
//   server->pages->doc->raw_content_length is updated with the amount of bytes read;
//   current_position is updated
//   server->pages->chunk_length is updated
//
int handle_http_chunked( server_t *server, char *in_buffer, ssize_t  buffer_size, ssize_t *current_position)
{
	int z_ret = Z_OK;

	while(*current_position < buffer_size && server->pages->decoding_state != CHUNCKED_FINISHED)
	{
		ssize_t bytes_to_read = 0;

		if (server->pages->decoding_state == CHUNCKED_READING_HEX_VALUE ||
			server->pages->decoding_state == CHUNCKED_WAITING_LF ||
			server->pages->decoding_state == CHUNCKED_INIT_HEADER)
		{
			parse_chunked_header(in_buffer, buffer_size, current_position, server);
			//cerr << server->hostname << "/" << server->pages->path << ": fim da leitura do cabeçalho. posição: "<< *current_position << " estado" << server->pages->decoding_state << endl;

			if(server->pages->decoding_state == CHUNCKED_READING_DATA && server->pages->chunk_length == 0)
				server->pages->decoding_state = CHUNCKED_FINISHED;
		}

		//cerr << server->hostname << "/" << server->pages->path << ": decoding state " << CHUNCKED_READING_DATA << " " << server->pages->decoding_state << endl;
		if (server->pages->decoding_state == CHUNCKED_READING_DATA)
		{
			//cerr << server->hostname << "/" << server->pages->path << ": calculo da quantidade a ser lida"<< endl;
			bytes_to_read = min(server->pages->chunk_length, buffer_size - *current_position);

			server->pages->chunk_length = server->pages->chunk_length - bytes_to_read;

			if (server->pages->chunk_length <= 0)
			{
				if (buffer_size > 7) // patch nel caso nel caso siano presenti siti con chunked "anomali" (valgrind ok)
				{
					ssize_t offset = *current_position;

					if (server->pages->end_chunk_pattern = 0)
					{
						while (offset < (buffer_size - 6))
						{
							if (in_buffer[offset] == ASCII_CR &&
								in_buffer[offset + 1] == ASCII_NL &&
								in_buffer[offset + 2] == '0' &&
								in_buffer[offset + 3] == ASCII_CR &&
								in_buffer[offset + 4] == ASCII_NL &&
								in_buffer[offset + 5] == ASCII_CR &&
								in_buffer[offset + 6] == ASCII_NL)
								{
									server->pages->end_chunk_pattern = offset;
									break;
								}

								offset++;
						}
					}

					// at moment is tested only with decompress raw contents
					//if (server->pages->doc->content_encoding == ENCODING_NONE && ((p = strstr(in_buffer, "\r\n0\r\n\r\n")) != NULL))
					if (server->pages->doc->content_encoding == ENCODING_NONE &&
						server->pages->end_chunk_pattern > 0 &&
						(*current_position + bytes_to_read) >= server->pages->end_chunk_pattern)
					{
						server->pages->chunk_length = 0;

						assert(bytes_to_read >= 0);

						z_ret = write_into_file(server, in_buffer, current_position, bytes_to_read);
						server->pages->decoding_state = CHUNCKED_FINISHED;

						return z_ret;
					}
				}

				server->pages->chunk_length = -1;
				server->pages->decoding_state = CHUNCKED_INIT_HEADER;
			}

			assert(bytes_to_read >= 0);
/*printf("%s", GRE);
for(int i = *current_position; i < bytes_to_read; i++)
	printf("%c", in_buffer[i]);
printf("%s", NOR);*/

//sleep(25);

			z_ret = write_into_file(server, in_buffer, current_position, bytes_to_read);

			if (z_ret == Z_MEM_ERROR)
			{
				return z_ret;
			}
		}
	}

	return z_ret;
}


//
// Name: server_write_buffer_into_file
//
// Description:
//   handles the content of a http response, saving it into a designed file.
//   if necessary it handles a chunked tranfer encoding
//
// Input:
//   readed - the size of the buffer
//   server - the server object
//   buffer - the buffer with data
//   headers_end - the position to start reading the buffer (note that the headers length can be relative to last buffer with headers)
//
int server_write_buffer_into_file(ssize_t  readed, server_t *server, char *buffer, ssize_t headers_end)
{
	int z_ret = Z_OK;

	if(server->pages->doc->chunked)
	{
		//cerr << server->hostname << "/" << server->pages->path << ": chegou na leitura do buffer"<< endl;
		z_ret = handle_http_chunked(server, buffer, readed, &headers_end);
	}
	else
	{
		assert(readed - headers_end >= 0);

		z_ret = write_into_file(server, buffer, &headers_end, readed - headers_end);
	}

	return z_ret;
}

//
// Name: server_receive
//
// Description:
//   Receives data from the server
//
// Input:
//   server - the server
//
// Return:
// 	false if normal termination, true if must be do another request for same resource
//
bool server_receive(server_t *server, short *events, uint *timeout_seconds, char *useragent, perfhash_t accept_protocol)
{
	assert( server != NULL );
	assert( server->socket.fd >= 0 );
	assert( server->pages != NULL );
	assert( server->pages->doc != NULL );
	char *buffer = CBALLOC(char, MALLOC, (BUFFER_SIZE));
	buffer[0] = ASCII_NUL;

	errno = 0; // errno is thread-local

	ssize_t readed = 0;

	if (server->ssl == NULL)
		readed = read(server->socket.fd, buffer, BUFFER_SIZE);
	else
	{
		int rc = 0;

		do rc = mbedtls_ssl_read(server->ssl, (unsigned char*)buffer, BUFFER_SIZE);
		while(rc == MBEDTLS_ERR_SSL_WANT_READ || rc == MBEDTLS_ERR_SSL_WANT_WRITE);

		// mbedtls_ssl_read end connection with 'MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY'
		// No error checking, the connection might be closed already
		// connection was closed gracefully
		if (rc == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY) // mbedtls_ssl_read end connection with 'MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY' negative numbera
		{
			do rc = mbedtls_ssl_close_notify(server->ssl);
    		while (rc == MBEDTLS_ERR_SSL_WANT_WRITE);

			rc = 0;
		}
		else if (rc < 0) rc = 0; // there may be other error that give us other 'rc < 0'

		

		readed = ssize_t(rc);
	}

	if (readed > BUFFER_SIZE)
	{
		readed = 0;
		buffer[0] = ASCII_NUL;
	}
	else if (readed < BUFFER_SIZE)
		buffer[readed] = ASCII_NUL;

	harv->hv_incr_bytes_in(((server->site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED), readed);
	server->site->bytes_in	+= readed;

	// Note time and size, for measuring speed
	gettimeofday(&(server->pages->timestamp_last_read), NULL);

	if (!timerisset( &(server->pages->timestamp_first_read)))
		memcpy( &(server->pages->timestamp_first_read), &(server->pages->timestamp_last_read), sizeof(struct timeval) );

	server->pages->bytes_total	+=	readed;

	if (server->pages->bytes_first_packet == 0) server->pages->bytes_first_packet = server->pages->bytes_total;

	// Check if we read something
	if (readed > 0 && readed <= BUFFER_SIZE)
	{
		if (server->conn_status == CONN_REQUESTING)
		{
			if (server->pages->buffer_one == NULL)
			{ // give a reasonable size to store headers (header 'Content-Length' yet unknow at moment)
				server->pages->bo_size = (BUFFER_SIZE * 2); // Bytes */
				server->pages->buffer_one = CBALLOC(char, CALLOC, server->pages->bo_size);
			}

			_retry_after_realloc:

			// Check for max size. We don't check for this on the
			// first packet, because we expect CONF_MAX_FILE_SIZE to
			// be substantially larget than the packet size.
			if ((server->pages->doc->raw_content_length + readed) <= server->pages->bo_size)
			{
				memcpy(server->pages->buffer_one + server->pages->doc->raw_content_length, buffer, readed);
				server->pages->doc->raw_content_length += readed;
			}
			else
			{
				const auto delta = (size_t)(BUFFER_SIZE * 2);

				const auto min_required_size = (const ssize_t)(server->pages->doc->raw_content_length + readed);

				char *p = CBREALLOC(char, ssize_t, server->pages->buffer_one, server->pages->bo_size, min_required_size, delta);

				if (p == NULL)
				{
					mcerr << BRO << "Internal error: memory allocation problem (docid " << server->pages->doc->docid << ") " << NOR << mendl;

					server->conn_status = CONN_DEACTIVATING;
					server_reset_buffers(server);
					server_close(server);
					free(buffer);

					return false;
				}

				server->pages->buffer_one = p;
				goto _retry_after_realloc;
			}

			bool found_headers_end = false;

			if (server->pages->headers_end == 0)
				for (ssize_t i = 0; i < (server->pages->doc->raw_content_length - 3); i++)
				{
					if (server->pages->buffer_one[i] == ASCII_CR &&
					server->pages->buffer_one[i + 1] == ASCII_NL &&
					server->pages->buffer_one[i + 2] == ASCII_CR &&
					server->pages->buffer_one[i + 3] == ASCII_NL)
					{
						found_headers_end = true;
						break;
					}
				}

			// if (server->pages->headers_end == 0 && (found_headers_end == true)) // Header Message tradizionale (non esteso)
			if (found_headers_end == true) // Header Message
			{
				// The packet contains headers
				server->pages->headers_end = server_parse_headers(server, server->pages->buffer_one, server->pages->doc->raw_content_length);

				// Nel caso si sitemap tipo 'xml' se si tratta del nome canonico 'sitemap.xml' nella directory principale del server
				// e il suo header non restituisce un mimetype compatibile (application/xml o text/xml), il sistema automaticamente prova a richiedere
				// la versione compressa richiedendo lo stesso file con estensione '.xml.gz'
				/* I sitemap con nome non canonico e in altre directory diverse dalla root vengono trattati normalmente come tutti gli altri link
				if (server->pages->canon_sitemap_xml == true && server->pages->doc->mime_type == MIME_ROBOTS_XML_BROKEN)
				{
					if (strncmp(FILENAME_ROBOTS_XML_GZ, server->pages->path, strlen(FILENAME_ROBOTS_XML_GZ)) != 0)
					{
						strcpy(server->pages->path, FILENAME_ROBOTS_XML_GZ);
						server->pages->doc->mime_type = MIME_ROBOTS_XML;
						free(buffer);
						return server_retry(server);
					}
				}
				*/

				// Check the status after parsing headers (first excludes bad compress encoding or not acceptable mimetype)
				if (server->pages->headers_end == -1)
				{
					if (server->pages->canon_sitemap_xml == true && strncmp(FILENAME_ROBOTS_XML_GZ, server->pages->path, strlen(FILENAME_ROBOTS_XML_GZ)) != 0)
					{
						strcpy(server->pages->path, FILENAME_ROBOTS_XML_GZ);
						free(buffer);
						return server_retry(server);
					}
 
					// A problem was found while parsing headers
					assert(server->http_status == HTTP_ERROR_PROTOCOL);

					mcerr << RED << "Problem while parsing headers" << NOR << mendl;

					server->conn_status = CONN_DEACTIVATING;
					server_reset_buffers( server );
					server_close( server );
					free(buffer);
	
					return false;
				}
				else if (server->pages->doc->content_encoding == ENCODING_UNKNOWN ||
						server->pages->doc->mime_type == MIME_APPLICATION_FLASH ||
						server->pages->doc->mime_type == MIME_APPLICATION ||
						server->pages->doc->mime_type == MIME_AUDIO ||
						server->pages->doc->mime_type == MIME_IMAGE ||
						server->pages->doc->mime_type == MIME_VIDEO ||
						server->pages->doc->mime_type == MIME_TEXT_WAP ||
						server->pages->doc->mime_type == MIME_TEXT_RTF ||
						server->pages->doc->mime_type == MIME_TEXT_XML ||
						server->pages->doc->mime_type == MIME_TEXT_TEX ||
						server->pages->doc->mime_type == MIME_TEXT_CHDR ||
						server->pages->doc->mime_type == MIME_TEXT ||
						server->pages->doc->mime_type == MIME_MESSAGE ||
						server->pages->doc->mime_type == MIME_MODEL ||
						server->pages->doc->mime_type == MIME_EXAMPLE )
				{
					server->pages->headers_end = -1;
					server->http_status = HTTP_NOT_ACCEPTABLE;
					server->conn_status = CONN_DEACTIVATING;
					server_reset_buffers( server );
					server_close( server );
					free(buffer);

					return false;
				}
			}

			if (server->pages->headers_end > 0)
			{
				bool is_robot = false;
				bool is_feed = false;

				if (server->pages->doc->mime_type == MIME_ROBOTS_TXT) is_robot = true;
				else if (server->pages->doc->mime_type == MIME_ROBOTS_RDF) is_robot = true;
				else if (server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ) is_feed = true;
				else if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML || server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ) is_feed = true;
				else if (server->pages->doc->mime_type == MIME_FEEDS_RSS_XML || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ) is_feed = true;

				if (server->http_status == HTTP_NOT_MODIFIED)
				{
					server->pages->doc->raw_content_length = 0;
					server->conn_status = CONN_DEACTIVATING;
	 		      	server_close(server);
					free(buffer);

					return false;
				}
				else if (HTTP_IS_REDIRECT(server->http_status))
				{
					free(buffer); // Se l'header contiene un redirect non ha senso salvare il contenuto del buffer

					// se la lunghezza è uguale a zero significa che si sta interrogando www.nomesito.it/
					if (server->pages->is_fqdn_request == false && strnlen(server->pages->path, 1) == 0)
							server->pages->is_fqdn_request = true;

					char *newpath = NULL;
					size_t newpath_len = 0;

					if (server->pages->relocation[0] != ASCII_NUL)
						newpath_len = strlen(server->pages->relocation);
					else
					{
						mcerr << RED << "Got http code " << server->http_status
						<< " but wrong Content-Location!" << NOR << mendl;

						server->conn_status = CONN_DEACTIVATING;
						server_reset_buffers( server );
						server_close( server );
	
						return false;
					}

					// TODO sperimentale
					if (server->pages->mime_type == MIME_ROBOTS_TXT)
					{
						if (server->pages->doc->mime_type != MIME_TEXT_PLAIN &&
							server->pages->doc->mime_type != server->pages->mime_type)
						{
							mcerr << RED << "Got http code " << server->http_status
							<< " with bad content-type for files robots.txt." << NOR << mendl;

							server->pages->doc->status = STATUS_DOC_IGNORED;
							server->pages->doc->content_encoding = ENCODING_NONE;
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );
	
							return false;
						}
					}
					else if (server->pages->mime_type == MIME_ROBOTS_RDF)
					{
						if (server->pages->doc->mime_type != MIME_APPLICATION_XML &&
							server->pages->doc->mime_type != server->pages->mime_type)
						{
							mcerr << RED << "Got http code " << server->http_status
							<< " with bad content-type for files robots.rdf." << NOR << mendl;

							server->pages->doc->status = STATUS_DOC_IGNORED;
							server->pages->doc->content_encoding = ENCODING_NONE;
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );
	
							return false;
						}
					}

					size_t path_len = strlen(server->pages->path);
					bool lsd = false; // (last slash difference) dovrà essere true nel caso i due url differiscono solo per lo slash finale
					server->pages->redirect_is_relative = false;

					// verifica che la nuova locazione (se url) faccia parte dello stesso sito
					newpath = strstr(server->pages->relocation, "://");
					size_t host_len = strlen(server->hostname);
					const size_t robots_len = 10; // 'robots.txt' or 'robots.rdf'
					size_t np_hostname_len = 0;

					if (newpath)
					{
						newpath += 3;

						if ((newpath - server->pages->relocation) > SERVER_MAX_PREFIX_PROTOCOL_SIZE)
						{
							mcerr << RED << "Got http code " << server->http_status
							<< " but new Content-Location have unsupported protocol!" << NOR << mendl;
	
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );
		
							return false;
						}
						else
						{
							char *pcolon = strchr(server->pages->relocation, ASCII_CO);

							// truncate TEMPORARILY the 'relocation' buffer
							// and leave only protocol name to pass at 'perfect_check'
							pcolon[0] = ASCII_NUL;

							if (perfhash_check(&(accept_protocol), server->pages->relocation) == false)
							{
								mcerr << RED << "Protocol " << server->pages->relocation << ", administratively denied or not supported" << NOR << mendl;
		
								pcolon[0] = ASCII_CO; // restore colon (:) of protocol prefix

								server->conn_status = CONN_DEACTIVATING;
								server_reset_buffers( server );
								server_close( server );
		
								return false;
							}

							pcolon[0] = ASCII_CO; // restore colon (:) of protocol prefix
						}


						newpath_len = strlen(newpath);
						char *slashinpath = NULL;

						if (newpath_len >= MAX_STR_LEN + MAX_DOMAIN_LEN)
						{
							mcerr << RED << "Got http code " << server->http_status
							<< " but new Content-Location is too long!" << NOR << mendl;
	
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );
		
							return false;
						}

						if (strstr(newpath, "://") != NULL)
						{
							mcerr << RED << "Got http code " << server->http_status
							<< " but new Content-Location " << newpath << " have another pattern (://) inside!" << NOR << mendl;
	
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );
		
							return false;
						}

						if ((slashinpath = strchr(newpath, ASCII_SL)) != NULL)
							np_hostname_len = (slashinpath - newpath);
						else
							np_hostname_len = newpath_len;

						if (np_hostname_len >= MAX_DOMAIN_LEN)
						{
							mcerr << RED << "Got http code " << server->http_status
							<< " but wrong domain name in Content-Location!" << NOR << mendl;

							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );

							return false;
						}

						// Other site. Passing other (only) protocol + hostname to parser. e.g. http://other.site.it/
						if (np_hostname_len != host_len || (np_hostname_len == host_len && strncmp(newpath, server->hostname, host_len) != 0))
						{
							if (is_robot == true || is_feed == true)
							{
								mcerr << RED << "Http moved permanently (301) for robots or feeds pages to other domains, administratively denied" << NOR << mendl;
	
								server->pages->doc->status = STATUS_DOC_IGNORED;
								server->pages->doc->content_encoding = ENCODING_NONE;
								server->conn_status = CONN_DEACTIVATING;
								server_reset_buffers( server );
								server_close( server );

								return false;
							}

							/* Note time and size, for measuring speed
							gettimeofday(&(server->pages->timestamp_last_read), NULL);

							if (timerisset(&(server->pages->timestamp_first_read)) == false)
								memcpy( &(server->pages->timestamp_first_read), &(server->pages->timestamp_last_read), sizeof(struct timeval) ); */

							// A special type, for documents containing the redirect address
							server->pages->doc->mime_type = MIME_REDIRECT;

							if (slashinpath != NULL)
							{
								unsigned short slash_count = 0;
								char *pslash=strchr(server->pages->relocation, '/');

								while (pslash != NULL && slash_count < 3)
								{
									server->pages->bo_size = (pslash - server->pages->relocation + 1);
    								pslash = strchr((pslash + 1), '/');
									slash_count++;
								}
							}
							else
								server->pages->bo_size = (strlen(server->pages->relocation) + 1);

							if (debugonly == false)
							{
								assert(server->pages->buffer_one != NULL);
								free(server->pages->buffer_one);
								server->pages->buffer_one = NULL;
								server->pages->buffer_one = CBALLOC(char, MALLOC, (server->pages->bo_size + 1));

								if (slashinpath != NULL)
									memcpy(server->pages->buffer_one, server->pages->relocation, server->pages->bo_size);
								else
								{
									memcpy(server->pages->buffer_one, server->pages->relocation, (server->pages->bo_size - 1));
									server->pages->buffer_one[(server->pages->bo_size - 1)] = '/';
								}

								server->pages->buffer_one[server->pages->bo_size] = ASCII_NUL;
							}

							server->pages->doc->raw_content_length = server->pages->bo_size;
							server->pages->doc->content_encoding = ENCODING_NONE; // url sempre riscritto in chiaro a prescindere ...
							server->conn_status = CONN_DEACTIVATING;
							server_close(server); // sarà eseguita la funzione 'server_gatherer' e i buffers verranno resettati subito dopo
	
							return false;
						}
						else
						{
							if (is_robot == true &&
								(((newpath_len - np_hostname_len - 1) != robots_len) ||
								(strncmp(&newpath[(np_hostname_len + 1)], server->pages->path, robots_len) != 0)))
							{
								mcerr << RED << "Http moved permanently (301) for robots pages to other path, denied" << NOR << mendl;
	
								server->pages->doc->status = STATUS_DOC_IGNORED;
								server->pages->doc->content_encoding = ENCODING_NONE;
								server->conn_status = CONN_DEACTIVATING;
								server_reset_buffers( server );
								server_close( server );

								return false;
							}
						}

						// If missing, append slash after hostname at the and of relocation
						if (slashinpath == NULL)
						{
								strcat(server->pages->relocation, "/");
								newpath_len++;

								assert(newpath != NULL);
						}

						// Redirect to same hostname
						newpath = strchr(newpath, '/');
					}
					else
						newpath = server->pages->relocation;

					// verifica le differenza tra slash finali
					if (newpath[0] == ASCII_SL)
					{
						if (newpath_len >= MAX_STR_LEN)
						{
							mcerr << RED << "Got http code " << server->http_status
							<< " but new Content-Location is too long!" << NOR << mendl;
	
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );
		
							return false;
						}

						newpath++; // skip first slash

						if (np_hostname_len > 0)
							newpath_len -= np_hostname_len;

						newpath_len--;

						if (is_robot == true &&
							(newpath_len != robots_len ||
							strncmp(newpath, server->pages->path, robots_len) != 0))
						{
							mcerr << RED << "Http moved permanently (301) for robots pages to other path, denied" << NOR << mendl;

							server->pages->doc->status = STATUS_DOC_IGNORED;
							server->pages->doc->content_encoding = ENCODING_NONE;
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );

							return false;
						}

						// check if path and newpath are identical except last slash
						if (newpath[(newpath_len - 1)] == '/' && path_len == (newpath_len - 1))
						{
							if (strncmp(newpath, server->pages->path, path_len) == 0)
								lsd = true;
						}
						else if (server->pages->path[(path_len - 1)] == '/' && newpath_len == (path_len - 1))
						{
							if (strncmp(server->pages->path, newpath, newpath_len) == 0)
								lsd = true;
						}
					}
					else
					{
						newpath_len = strlen(newpath);

						if (is_robot == true &&
							(newpath_len != robots_len ||
							strncmp(newpath, server->pages->path, robots_len) != 0))
						{
							mcerr << RED << "Http moved permanently (301) for robots pages to other path, denied" << NOR << mendl;

							server->pages->doc->status = STATUS_DOC_IGNORED;
							server->pages->doc->content_encoding = ENCODING_NONE;
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );

							return false;
						}

						if ((newpath_len - host_len - 1) >= MAX_STR_LEN)
						{
							mcerr << RED << "Got http code " << server->http_status
							<< " but new Content-Location is too long!" << NOR << mendl;
	
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );
		
							return false;
						}

						// check if path and newpath are identical except last slash
						if (newpath_len > 0 && newpath[(newpath_len - 1)] == '/' && path_len == (newpath_len - 1))
						{
							if (strncmp(newpath, server->pages->path, path_len) == 0)
								lsd = true;
						}
						else if (path_len > 0 && server->pages->path[(path_len - 1)] == '/' && newpath_len == (path_len - 1))
						{
							if (strncmp(server->pages->path, newpath, newpath_len) == 0)
								lsd = true;
						}

						server->pages->redirect_is_relative = true;
					}

					// Se il sito viene visitato la prima volta si verifica se esiste una forzatura dal protocollo http verso https
					if (strncmp(server->pages->relocation, "https://", SERVER_MAX_PREFIX_HTTPS_PROTOCOL_SIZE) == 0)
					{
						if (is_robot == true &&
							(server->site->protocol == HTTPS ||
							server->site->protocol == HTTPS_TEMPORARY))
						{ // skip loop redirect at first try
							mcerr << RED << "Http moved permanently (301) for robots pages to same url, denied" << NOR << mendl;

							server->pages->doc->status = STATUS_DOC_IGNORED;
							server->pages->doc->content_encoding = ENCODING_NONE;
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );

							return false;
						}

						if (server->site->protocol == NOT_DEFINED ||
							server->site->protocol == HTTP ||
							server->site->protocol == HTTP_TEMPORARY)
						{
							strcpy(server->pages->path, newpath);

							// Prepara il contesto ssl
							server->site->protocol = HTTPS_TEMPORARY;

							struct sockaddr_in *sai = (struct sockaddr_in *)server->addr;
							struct sockaddr_in6 *sai6 = (struct sockaddr_in6 *)server->addr;

							// Configura correttamente la porta su cui il socket dovrà connettersi
							switch (server->addr->ss_family)
							{
								case AF_INET:
									sai->sin_port = htons(HTTPS_PORT);
									break;
								case AF_INET6: // IPV6 Sperimentale
									sai6->sin6_port = htons(HTTPS_PORT);
									break;
								default:
									server->conn_status = CONN_DEACTIVATING;
									server_reset_buffers( server );
									server_close( server );

									return false;
							}

							return server_retry(server);
						}
					}
					else if (strncmp(server->pages->relocation, "http://", SERVER_MAX_PREFIX_HTTP_PROTOCOL_SIZE) == 0)
					{
						if (is_robot == true &&
							(server->site->protocol == HTTP ||
							server->site->protocol == HTTP_TEMPORARY))
						{ // skip loop redirect at first try
							mcerr << RED << "Http moved permanently (301) for robots pages to same url, denied" << NOR << mendl;

							server->pages->doc->status = STATUS_DOC_IGNORED;
							server->pages->doc->content_encoding = ENCODING_NONE;
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );

							return false;
						}

						if (server->site->protocol == NOT_DEFINED ||
							server->site->protocol == HTTPS ||
							server->site->protocol == HTTPS_TEMPORARY)
						{
							strcpy(server->pages->path, newpath);

							// Prepara il contesto ssl
							server->site->protocol = HTTP_TEMPORARY;

							struct sockaddr_in *sai = (struct sockaddr_in *)server->addr;
							struct sockaddr_in6 *sai6 = (struct sockaddr_in6 *)server->addr;

							// Configura correttamente la porta su cui il socket dovràconnettersi
							switch (server->addr->ss_family)
							{
								case AF_INET:
									sai->sin_port = htons(HTTP_PORT);
									break;
								case AF_INET6: // IPV6 Sperimentale
									sai6->sin6_port = htons(HTTP_PORT);
									break;
								default:
									server->conn_status = CONN_DEACTIVATING;
									server_reset_buffers( server );
									server_close( server );

									return false;
							}

							return server_retry(server);
						}
					}
					else
					{
						// No action taken for other protocols
					}

					if (newpath_len > 0 && is_robot == false && is_feed == false)
					{
						/*
						bool same_path = false;

						if ((strlen(server->pages->path) == newpath_len) && strncasecmp( server->pages->path, newpath, newpath_len) == 0)
							same_path = true;
						* in teoria path differenti SOLO tra maiuscole e minuscole potrebbero essere rediretti instantaneamente
						* es: path 'RSS/Gossip' e newpath 'rss/gossip'
						* il problema però si pone quando verrebbe interrogato direttamente il path rss/gossip perchè verrebbe creato
						* un documento duplicato e nel caso particolare di feed xml avere un duplicato dello stesso documento
						* creerebbe non pochi problemi.
						* Fino a quando non si pone rimedio al problema la soluzione è da scartare.
						*/

						if (lsd == true || server->pages->is_fqdn_request == true || (strchr(server->pages->relocation, '=') ||	strchr(server->pages->relocation, ';')))
						{
							// Patch server->pages->relocation
							// Gli url che vengono rediretti su altri url che contengono nomi e parametri
							// ora vengono interrogati sequenzialmente nello stesso ciclo di harvesting.
							// N.B. La pagina dove avviene la redirezione deve far parte dello stesso nome dominio
							//
							// L'eventuale redirezione vale anche per link del tipo www.nomesito.it/

							if (server->pages->attempts > CONF_HARVESTER_MAXATTEMPTS)
							{
								mcerr << RED << "Too many attempts in redirect for " << server->hostname << '/' << server->pages->path << NOR << mendl;
		
								server->conn_status = CONN_DEACTIVATING;
								server_reset_buffers( server );
								server_close( server );
		
								return false;
							}
							else if (server->pages->is_fqdn_request == true && server->pages->attempts == 0)
							{
								assert(server->pages->src_path == NULL);
								server->pages->src_path = CBALLOC(char, MALLOC, (strlen(server->pages->path) + 1));
								server->pages->src_path[0] = ASCII_NUL;
								strcpy(server->pages->src_path, server->pages->path);
							}

							server->pages->attempts++;
		
							// Ai Content-Location del 'path' se provvisti di slash '/' finale viene concatenato la stringa 'server->pages->relocation'
							if (server->pages->redirect_is_relative == true)
							{
								char *lastslash = strrchr(server->pages->path, '/');

								if (lastslash == NULL)
									strcpy(server->pages->path, server->pages->relocation);
								else
								{
									size_t len = (lastslash - server->pages->path + 1);

									if ((len + strlen(server->pages->relocation)) < MAX_STR_LEN)
										strcpy(server->pages->path + len, server->pages->relocation);
									else
									{
										mcerr << RED << "Got http code " << server->http_status
										<< " but new Content-Location is invalid!" << NOR << mendl;
		
										server->conn_status = CONN_DEACTIVATING;
										server_reset_buffers( server );
										server_close( server );
		
										return false;
									}
								}
							}
							else
							{
								if (lsd == false)
									strcpy(server->pages->path, newpath);
								else
								{
									if (server->pages->path[(path_len - 1)] == '/')
										server->pages->path[(path_len - 1)] = ASCII_NUL;
									else if (path_len < (MAX_STR_LEN - 1))
										strcat(server->pages->path, "/");
								}
									
							}

							return server_retry(server);
						}
						else
						{
							if (newpath_len > 0)
							{
								/* Note time and size, for measuring speed
								gettimeofday(&(server->pages->timestamp_last_read), NULL);

								if( !timerisset( &(server->pages->timestamp_first_read) ) )
									memcpy( &(server->pages->timestamp_first_read), &(server->pages->timestamp_last_read), sizeof(struct timeval) ); */

								// A special type, for documents containing the
								// redirect address
								server->pages->doc->mime_type = MIME_REDIRECT;

								int len = strlen(newpath);

								if (server->pages->buffer_one == NULL || server->pages->bo_size <= len)
								{
									server->pages->bo_size = len;
									assert(server->pages->buffer_one != NULL);
									free(server->pages->buffer_one);
									server->pages->buffer_one = NULL;
									server->pages->buffer_one = CBALLOC(char, MALLOC, (server->pages->bo_size + 1));
								}

								memcpy(server->pages->buffer_one, newpath, len);
								server->pages->doc->raw_content_length = len;
								server->pages->buffer_one[server->pages->doc->raw_content_length] = ASCII_NUL;
								server->pages->doc->content_encoding = ENCODING_NONE; // url sempre riscritto in chiaro a prescindere ...
								server->conn_status = CONN_DEACTIVATING;
								server_close( server ); // sarà eseguita la funzione 'server_gatherer' e i buffers verranno resettati subito dopo
		
								return false;
							}
							else
							{
								mcerr << RED << "Got http code " << server->http_status << " but no Location header" << NOR << mendl;

								server->conn_status = CONN_DEACTIVATING;
								server_reset_buffers( server );
								server_close( server );
		
								return false;
							}
						}
					}
					else
					{
						if (server->pages->doc->mime_type == MIME_ROBOTS_TXT)
						{
							mcerr << RED << "Got unacceptable http code " << server->http_status
							<< " with mime type MIME_ROBOTS_TXT" << NOR << mendl;
						}
						else if (server->pages->doc->mime_type == MIME_ROBOTS_RDF)
						{
							mcerr << RED << "Got unacceptable http code " << server->http_status
							<< " with mime type MIME_ROBOTS_RDF" << NOR << mendl;
						}
						else if (server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ)
						{
							mcerr << RED << "Got unacceptable http code " << server->http_status
							<< " with mime type MIME_ROBOTS_XML" << NOR << mendl;
						}
						else if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML || server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ)
						{
							mcerr << RED << "Got unacceptable http code " << server->http_status
							<< " with mime type MIME_FEEDS_ATOM_XML" << NOR << mendl;
						}
						else if (server->pages->doc->mime_type == MIME_FEEDS_RSS_XML || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ)
						{
							mcerr << RED << "Got unacceptable http code " << server->http_status
							<< " with mime type MIME_FEEDS_RSS_XML" << NOR << mendl;
						}
						else
						{
							mcerr << RED << "Got http code " << server->http_status << " but no Location header" << NOR << mendl;
						}

						server->conn_status = CONN_DEACTIVATING;
						server_reset_buffers( server );
						server_close( server );
		
						return false;
					}
					
				}
				else if( !HTTP_IS_OK(server->http_status) )
				{
					if (server->pages->canon_sitemap_xml == true && strncmp(FILENAME_ROBOTS_XML_GZ, server->pages->path, strlen(FILENAME_ROBOTS_XML_GZ)) != 0)
					{
						strcpy(server->pages->path, FILENAME_ROBOTS_XML_GZ); // prova a richiedere un sitemap con estensione '.xml.gz'
						free(buffer);

						return server_retry(server);
					}
					else
					{
						// There is no need to read the data
						if( CONF_HARVESTER_LOGLEVEL == LOGLEVEL_VERBOSE )
							mcerr << RED << "Status is not ok: " << HTTP_STR( server->http_status ) << NOR << mendl;

						server->conn_status = CONN_DEACTIVATING;
						server_reset_buffers( server );
						server_close( server );
						free(buffer);
		
						return false;
					}
				}
				else
				{
					/* Note time and size, for measuring speed
					gettimeofday(&(server->pages->timestamp_last_read),NULL);

					if( !timerisset( &(server->pages->timestamp_first_read) ) )
						memcpy( &(server->pages->timestamp_first_read), &(server->pages->timestamp_last_read), sizeof(struct timeval) ); */

					if (server->pages->headers_end <= (off64_t)(CONF_MAX_FILE_SIZE / 8)) // discard very long headers
					{
						assert(server->pages->z_strm == NULL);

						// If content_encoding is compressed 'Zlib' must be initialized
						if (server->pages->doc->content_encoding != ENCODING_NONE)
						{
							// we don't know at prior the size after decompress
							// then we allocate max size for buffer
							SET_BINARY_MODE(inbuf); // server->pages->buffer_one
							SET_BINARY_MODE(server->pages->buffer_one);

							/* allocate inflate state */
							server->pages->z_strm = CBALLOC(z_stream, CALLOC, 1);
							server->pages->z_strm->zalloc = Z_NULL;
							server->pages->z_strm->zfree = Z_NULL;
							server->pages->z_strm->opaque = Z_NULL;
							server->pages->z_strm->avail_in = 0;
							server->pages->z_strm->next_in = Z_NULL;

							if (inflateInit2(server->pages->z_strm, MAX_WBITS | ENABLE_ZLIB_GZIP) != Z_OK)
							{	// Error initializing 'Zlib
								server->pages->headers_end = -1;
								server->http_status = HTTP_NOT_ACCEPTABLE;
								server->conn_status = CONN_DEACTIVATING;
								server_close( server );
								free(buffer);

								return false;
							}
						}

						int z_ret = Z_OK;

						int buffer_offset = (server->pages->headers_end - (server->pages->doc->raw_content_length - readed));

						server->pages->doc->raw_content_length = 0;

						assert(buffer_offset <= readed);

						// Save the first block of data content (headers less)
						z_ret = server_write_buffer_into_file(readed, server, buffer, buffer_offset);

						if (z_ret == Z_MEM_ERROR)
						{
							server->http_status = HTTP_PARTIAL;
							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers(server);
							server_close(server);
							free(buffer);

							return false;
						}
					}
					else
					{
							mcerr << RED << "Exceeded header length (docid " << server->pages->doc->docid << ")" << NOR << mendl;

							server->conn_status = CONN_DEACTIVATING;
							server_reset_buffers( server );
							server_close( server );
							free(buffer);

							return false;
					}

					// Now we are receiving
					server->conn_status	= CONN_RECEIVING;
					free(buffer);

					return false;;
				}
			}
			else // gestione degli header message estesi (salvataggio buffer per successiva analisi)
			{
				server->conn_status = CONN_REQUESTING; // continue requesting because missing some headers
				free(buffer);

				return false;
			}
		}
		else
		{
			assert(server->conn_status == CONN_RECEIVING);

			/* Note time and size, for measuring speed
			gettimeofday(&(server->pages->timestamp_last_read), NULL);

			if (!timerisset( &(server->pages->timestamp_first_read)))
				memcpy( &(server->pages->timestamp_first_read), &(server->pages->timestamp_last_read), sizeof(struct timeval) ); */

			// Continue writing the data to buffer
			ssize_t init_pos = 0;
			int z_ret = server_write_buffer_into_file(readed, server, buffer, init_pos);

			if (z_ret == Z_MEM_ERROR)
			{
				server->http_status = HTTP_PARTIAL;
				server->conn_status = CONN_DEACTIVATING;
				server_reset_buffers(server);
				server_close(server);
				free(buffer);

				return false;
			}
		}

		if( CONF_HARVESTER_LOGLEVEL == LOGLEVEL_VERBOSE )
			mcerr << "< Received " << readed << " from " << server->hostname << mendl;
	}
	else
	{
		// Nothing readed, deactivating
		server->conn_status = CONN_DEACTIVATING;

		// Check if the status is unknown, then we haven't read
		// an appropiate response header, so there was a problem
		// with the protocol
		if( server->http_status == HTTP_STATUS_UNDEFINED ) server->http_status = HTTP_ERROR_PROTOCOL;

		//server_close( server ); // no server_reset_buffers

		if (server->ssl == NULL)
		{
			if (readed < 0)
			{
				mcerr << "Error in read: " << CBoterr(errno) << mendl;
				mcerr << RED << "Error while reading from " << server->hostname << NOR << mendl;
			}
		}
		else
		{
			if( readed < 0 )
            {
				char error_buf[100];
				mbedtls_strerror( (int)readed, error_buf, 100 );
				mcerr << "Error in read: " << error_buf << mendl;
				mcerr << RED << "Error while reading from " << server->hostname << NOR << mendl;
            }
		}

		server_close( server ); // no server_reset_buffers
		free(buffer);
	
		return false;
	}

	// If we have receive deflate document and reached rigth "Content-Length" size,
	// without receiving header 'Connection: close' (because server wan't sent to us) we can stop downloading.
	// See RFC 2616
	if (server->pages->headers_end > 0 &&
		server->pages->peer_close == false &&
		server->pages->doc->chunked == false &&
		server->pages->doc->content_encoding != ENCODING_NONE)
	{
		assert(server->pages->doc->raw_content_length <= server->pages->bo_net_bodysize);

		if (server->pages->doc->raw_content_length == server->pages->bo_net_bodysize)
		{
			server->http_status = HTTP_OK;
			server->conn_status = CONN_DEACTIVATING;
	       	server_close(server);
		}
		else if (server->pages->doc->raw_content_length > server->pages->bo_net_bodysize)
		{
			// Server don't respect standard
			server->http_status = HTTP_ERROR_PROTOCOL;

			mcerr << RED << "Server mismatch RFC 2616" << NOR << mendl;

			server->conn_status = CONN_DEACTIVATING;
			server_close(server);
		}
	}

	free( buffer );

	return false;
}

//
// Name: detect_BOM
//
// Description:
//   analyse the start bytes of the buffer trying to detect a charset BOM string
//
// Input:
//   aBuf - the buffer to be analysed
//   pos - point to the first char to be considered
//
charset_t detect_BOM(char* aBuf, ssize_t *pos){
	//If the data starts with BOM, we know it is UTF

	string detect;
	char *charset = NULL;

	switch (aBuf[*pos])
	{
	case '\xEF':
	  if (('\xBB' == aBuf[*pos + 1]) && ('\xBF' == aBuf[*pos + 2]))
		  *pos += 3;
		// EF BB BF  UTF-8 encoded BOM
		  detect.assign("UTF-8");
		  charset = (char *) malloc ((detect.size() + 1) * sizeof(char));
		  strcpy(charset, detect.c_str());
		  return http_charset(charset);
	break;
	case '\xFE':
	  if (('\xFF' == aBuf[*pos + 1]) && ('\x00' == aBuf[*pos + 2]) && ('\x00' == aBuf[*pos + 3])){
		// FE FF 00 00  UCS-4, unusual octet order BOM (3412)
		  *pos += 4;
		  detect.assign("X-ISO-10646-UCS-4-3412");
		  charset = (char *) malloc ((detect.size() + 1) * sizeof(char));
		  strcpy(charset, detect.c_str());
		  return http_charset(charset);
	  }
	  else if ('\xFF' == aBuf[*pos + 1]){
		// FE FF  UTF-16, big endian BOM
		  *pos += 2;
		  detect.assign("UTF-16BE");
		  charset = (char *) malloc ((detect.size() + 1) * sizeof(char));
		  strcpy(charset, detect.c_str());
		  return http_charset(charset);
	  }
	break;
	case '\x00':
	  if (('\x00' == aBuf[*pos + 1]) && ('\xFE' == aBuf[*pos + 2]) && ('\xFF' == aBuf[*pos + 3])){
		// 00 00 FE FF  UTF-32, big-endian BOM
		  *pos += 4;
		  detect.assign("UTF-32BE");
		  charset = (char *) malloc ((detect.size() + 1) * sizeof(char));
		  strcpy(charset, detect.c_str());
		  return http_charset(charset);
	  }
	  else if (('\x00' == aBuf[*pos + 1]) && ('\xFF' == aBuf[*pos + 2]) && ('\xFE' == aBuf[*pos + 3])){
		// 00 00 FF FE  UCS-4, unusual octet order BOM (2143)
		  *pos += 4;
		  detect.assign("X-ISO-10646-UCS-4-2143");
		  charset = (char *) malloc ((detect.size() + 1) * sizeof(char));
		  strcpy(charset, detect.c_str());
		  return http_charset(charset);
	  }
	break;
	case '\xFF':
	  if (('\xFE' == aBuf[*pos + 1]) && ('\x00' == aBuf[*pos + 2]) && ('\x00' == aBuf[*pos + 3])){
		// FF FE 00 00  UTF-32, little-endian BOM
		  *pos += 4;
		  detect.assign("UTF-32LE");
		  charset = (char *) malloc ((detect.size() + 1) * sizeof(char));
		  strcpy(charset, detect.c_str());
		  return http_charset(charset);
	  }
	  else if ('\xFE' == aBuf[*pos + 1]){
		// FF FE  UTF-16, little endian BOM
		  *pos += 2;
		  detect.assign("UTF-16LE");
		  charset = (char *) malloc ((detect.size() + 1) * sizeof(char));
		  strcpy(charset, detect.c_str());
		  return http_charset(charset);
	  }
	break;
	}  // switch


	return CHARSET_UNKNOWN;
}

//
// Name: parse_BOM
//
// Description:
//   parser the the buffer trying to detect a charset BOM string
//
// Input:
//   bufsize - the length of the buffer
//   pos - point to the first char to be considered
//	 buffer - the buffer that contains the data
//   server - server object
//
// Output:
//   server->pages->doc->charset - update the charset arcordingly to the BOM characters
//
// Return:
//   the offset length to be
//
ssize_t parse_BOM(ssize_t bufsize, ssize_t pos, char *buffer, server_t *& server)
{

  	ssize_t offset = pos;

	if ((bufsize - pos) > 3){

		charset_t detected = detect_BOM(buffer, &pos);

		if (detected != CHARSET_UNKNOWN){
			while (pos < bufsize && (buffer[pos] == '\n' || buffer[pos] == '\r'))
						pos++;

			if (server->pages->doc->charset == CHARSET_UNKNOWN || server->pages->doc->charset == http_charset(CONF_GATHERER_DEFAULTCHARSET))
				server->pages->doc->charset = detected;

		}
		cerr << "offset no parser= " << offset << endl;
	}
	offset = pos - offset;

	return offset;
}

//
// Name: server_parse_headers
//
// Description:
//   Parses an incoming buffer with headers
//
// Input:
//   server - the server object
//   buffer - the buffer with data
//   bufsize - the size of the buffer
//
// Output:
//   server->site is updated to reflect the headers
//   server->page->doc (the current page being fetched) is updated also
//
// Return:
//   the number of bytes parsed as headers
//   -1 on protocol error
//

ssize_t server_parse_headers(server_t *server, char *buffer, ssize_t bufsize) {
	assert( server != NULL );
//	assert( server->conn_status == CONN_REQUESTING );
	assert( server->socket.fd > 0 );
	assert( server->site != NULL );
	assert( server->pages != NULL );
	assert( server->pages->doc != NULL );

	// HTTP_status is undefined until informed by server
	server->http_status = HTTP_STATUS_UNDEFINED;

	// Flag when readed code
	bool readed_http_code = false;
	char line[MAX_STR_LEN];
	ssize_t pos		 = 0;
	uint hpos		 = 0;

	// Go through the line
	while (pos < bufsize)
	{
		register char c = buffer[pos];

		if (c == '\r'); // Ignore
		else if (c == '\n')
		{
			// Done with the line
			line[hpos]	= ASCII_NUL;

			if (hpos == 0)
			{
				// We received a blank line
				if (readed_http_code)
				{
					assert(server->http_status != HTTP_STATUS_UNDEFINED);

					while (pos < bufsize && (buffer[pos] == '\n' || buffer[pos] == '\r')) pos++;

					return pos;
				}
				else
				{

					// Blank line means protocol error,
					// no status code was received
					server->http_status = HTTP_ERROR_PROTOCOL;
					mcerr << RED << "No headers were received, blank line found before http code" << NOR << mendl;
					return -1;

				}

			}
			else
			{
				// Normal line: parse as http code or line
				if (readed_http_code) server_parse_http_header(server, line, hpos); // Normal http header
				else
				{
					// Http header with code
					server->http_status = server_parse_http_code( server, line, hpos );

					// Check code
					if (server->http_status == HTTP_ERROR_PROTOCOL)
					{
						// Protocol error (no code)
						mcerr << RED << "No http code received in this line " << line << NOR << mendl;
						return -1;

					} else {
						// Ok, continue with the other headers
						readed_http_code = true;
						if (CONF_HARVESTER_LOGLEVEL == LOGLEVEL_VERBOSE)
						{
							mcerr << GRE << "< http_status=" << server->http_status << NOR << mendl;
						}
					}
				}

				// Reset the line line
				hpos = 0;
			}
		} else {
			// Copy, honoring the maximum string length
			if( hpos < MAX_STR_LEN - 1 ) {
				line[hpos] = c;
				hpos++;
			} else {
				line[hpos] = ASCII_NUL;
				// cerr << RED << "Header line to wide: " << line << NOR;
				mcerr << RED << "Header line to wide: " << line << NOR << mendl;
				server->http_status = HTTP_ERROR_PROTOCOL;
				return -1;
			}
		}

		pos++;
	}

	// I exhausted the buffer but couldn't find a blank
	// line signaling the end of the headers
	if( server->http_status == HTTP_STATUS_UNDEFINED ) {
		server->http_status = HTTP_ERROR_PROTOCOL;
		return -1;
	} else if( HTTP_IS_OK( server->http_status ) ) {
		// Status ok, but no blank line at the end,
		// protocol error
		server->http_status = HTTP_ERROR_PROTOCOL;
		return -1;
	} else {
		// HTTP status is not ok, we are not
		// expecting data, so we are done with the headers,
		// even if there is no blank line at the end of them
		return pos;
	}
}

//
// Name: server_skip_all
//
// Description:
//   Skip the rest of the server; this just cleans the
//   server queue and assigns the http_code to all the
//   documents remaining in the queue.
//   Tipically it is used if DNS lookup fails.
//
// Input:
//   server - the server object
//   http_code - the http code for it
//

void server_skip_all(starter_t *starter, siteid_t serverid, unsigned short http_code)
{
	server_t *servers = (server_t *)starter->servers;
	server_t *server = &(servers[serverid]);

	assert( server != NULL );
	assert( http_code != 0 );
	assert( http_code == HTTP_ERROR_CONNECT
		 || http_code == HTTP_ERROR_TIMEOUT
		 || http_code == HTTP_ERROR_DISCONNECTED
		 || http_code == HTTP_ERROR_DNS
		 || http_code == HTTP_ERROR_SKIPPED
		 || http_code == HTTP_ERROR_BLOCKED_IP );

	// Check if this was a real error
	if( http_code == HTTP_ERROR_SKIPPED ) {
		// We are prematurely stopping this harvest because
		// there are too few sites available
		mcerr << RED << "Skipping all from " << server->hostname << NOR << mendl;
		// Error count must be zeroed
		server->site->count_error = 0;
	} else {
		// We are skiping because of an error
		server->site->count_error ++;
		mcerr << RED << "Web server had an error, now skipping all from " << server->hostname << ", server error count now is " << server->site->count_error << NOR << mendl;

		// We reset the error count in this harvest,
		// because we're not going to use it anymore,
		// except to check if a website had only errors when
		// saving site data; in that case, we don't want
		// to add a second error
		server->errors_in_this_harvest = 0;
	}

	// Go through the list of pages
	while (server->ndocs_done < server->ndocs)
	{
		server->pages->doc->http_status	= http_code;
		server->pages->doc->raw_content_length = 0;
		server_save_current_page(starter, serverid);
	}

	// Dont left the server with an undef status
	if( server->http_status == HTTP_STATUS_UNDEFINED ) {
		server->http_status = http_code;
	}

	assert(server->ndocs_done == server->ndocs);
}

//
// Name: server_has_more_documents
//
// Description:
//   Checks if the server has more documents that need
//   to be downloaded
//
// Input:
//   server - the server
//
// Return:
//   true if there are more documents in the queue
//   false otherwise
//

bool server_has_more_documents( server_t *server ) {
	assert( server != NULL );
	assert( server->ndocs > 0 );

	if (server->ndocs_done == server->ndocs )
	{
		assert( server->pages == NULL );
		return false;
	}
	else
	{
		assert( server->pages != NULL );
		return true;
	}
}

//
// Name: server_copy_site
//
// Description:
//   Copy the information from a site
//
// Input:
//   server - the server structure
//   starter - the starter structure
//   site - the site structure
//   hostname - the site hostname
//   serverid - the place in the servers list
//

void server_copy_site(server_t *server, starter_t *starter, site_t *site, const char *hostname, unsigned int serverid)
{
	assert( server != NULL );
	assert( site != NULL );
	assert( hostname != NULL );
	assert( serverid > 0 );

	/* effettua le verifiche necessarie per capire se utilizzare per il sito il protocollo https piuttosto che http
	if (starter->harvest_status == STATUS_HARVEST_ASSIGNED_NEW)
	{
		unsigned char doc_count = 0;

		if (CONF_SEEDER_ADD_ROBOTSTXT == true)
			doc_count++;
		if (CONF_SEEDER_ADD_ROBOTSRDF == true)
			doc_count++;
		if (CONF_SEEDER_ADD_ROBOTSXML == true)
			doc_count++;

		if (site->https_check == NOT_HARVESTED) 
			site->https_check = HARVESTED_FIRST_CICLE;
		else if (site->https_check == HARVESTED_FIRST_CICLE) 
			site->https_check = HARVESTED_SECOND_CICLE;
		else if (site->https_check == HARVESTED_SECOND_CICLE) 
			site->https_check = HARVESTED_THIRD_CICLE;
		else if (site->https_check == HARVESTED_THIRD_CICLE) 
			site->https_check = HARVESTED_FOURTH_CICLE;
		else if (site->https_check == HARVESTED_FOURTH_CICLE) // perfezionare nel caso si usino o meno i file robot
		{
			if (site->https_check == HARVESTED_FOURTH_CICLE && site->count_doc > doc_count) // perfezionare nel caso si usino o meno i file robot 
				site->https_check = GOOD_HARVESTED;
			else 
				site->https_check = POOR_HARVESTED; // ciclo harvest scarso perchè in base al numero di cicli di harvesting
								    // i documenti raccolti non sono sufficienti.
							  // Allora se il sito è in http e un url relativo si presentasse con il protocollo https
							  // questi verrebbe preso in considerazione ai fini di provare a raccogliere più documenti.
							  // Nel caso opposto per evitare loop, una volta migrato da https a http in ogni caso sarebbe messo
							  // in uno stato di GOOD_HARVESTED
		}

		if (site->https_check == POOR_HARVESTED)
		{
			if (site->count_doc > doc_count)
				site->https_check = GOOD_HARVESTED; // blocca ulteriori cicli di migrazioni lasciando invariato il protocollo
			if (site->protocol == HTTP)
				site->protocol = HTTPS; // migrazione ad https
			else if (site->protocol == HTTPS)
			{
				site->protocol = HTTP; // migrazione ad http
				site->https_check = GOOD_HARVESTED; // blocca ulteriori cicli di migrazioni ad https e resta definitivamente in http
			}
		}
	} */

	// Copy site
	server->site				= site;

	// Copy hostname
	server->hostname = CBALLOC(char, MALLOC, MAX_STR_LEN);

	if( strlen( hostname ) > 0 ) {
		assert( strlen( hostname ) <= MAX_STR_LEN );
		strcpy( server->hostname, hostname );
	} else {
		// Bug: something has no hostname
		strcpy( server->hostname, "null.null" );
	}

	// Prepare ipv4 ipv6 inet address support
	server->addr = CBALLOC(struct sockaddr_storage, CALLOC, 1);
	server->addr->ss_family = AF_UNSPEC;
	

	// Server
	server->pool_slot	= (siteid_t)(~0);
	server->serverid	= serverid;
	server->socket.fd		= -1;
	server->http_status	= HTTP_STATUS_UNDEFINED;

	// Set https status
	server->ssl		= NULL;

	server->updated_robotstxt = false;

	// Set number of documents
	server->ndocs_done	= 0;
	server->ndocs		= 0;
	server->pages		= NULL;

	// Set data to store speeds
	timerclear( &(server->timestamp_resolver_start) );
	memcpy(&(server->timestamp_resolver_end), &(server->timestamp_resolver_start), sizeof(struct timeval));

	// Waiting time
	server->wait		= CONF_HARVESTER_WAIT_NORMAL;

	if (site->count_doc >= CONF_HARVESTER_WAIT_COUNTBIG)
		server->wait	= CONF_HARVESTER_WAIT_BIG;

	// Dns requests for obtain address
	server->dns_requests = 0;

	// Consecutive exclusions
	server->exclusions_in_this_harvest	= 0;

	// Consecutive errors
	server->errors_in_this_harvest	= 0;

	// Connection status
	server->conn_status	= CONN_NONE;
}

//
// Name: server_parse_http_code
//
// Description:
//   Parses the first line of a response from the server
//
// Input:
//   server - the server object
//   header - The header line
//   len - the length of the line
//
// Return:
//   http_code or HTTP_ERROR_PROTOCOL
//   

uint server_parse_http_code( server_t *server, char *header, uint len ) {
	assert( header != NULL );
	assert( len > 0 );
	assert( header[len] == ASCII_NUL );
	assert( server != NULL );
	assert( server->http_status == HTTP_STATUS_UNDEFINED );

    // Skip the initial portion
    if( len < 9 ) { // "HTTP/x.x "
        return HTTP_ERROR_PROTOCOL;
    } else {
		uint code = strtol( (header)+9, (char **)NULL, 10 );
		if( code >= 100 ) {
			return code;
		} else {
			return HTTP_ERROR_PROTOCOL;
		}
    }
}

//
// Name: server_parse_http_header
//
// Description:
//   Parses a line of the header. Not the initial line, that
//   is parsed by server_parse_http_code.
//
// Input:
//   server - the server object
//   header - The header line
//   len - the length of the line
//   
// Output:
//   server->page

void server_parse_http_header(server_t *server, char *header, unsigned int len)
{
	assert( header != NULL );
	assert( len > 0 );
	assert( header[len] == ASCII_NUL );
	assert( server != NULL );
	assert( server->http_status != HTTP_STATUS_UNDEFINED );

	// Note that server->pages contains at this moment
	// the document that is being downloaded, as it is at
	// the beginning of the list
	assert( server->pages != NULL );
	assert( server->pages->doc != NULL );

	// Get the name of the header
	if (server->header_status.check_lmod == false &&
		server->pages->doc->abs_last_modified == false &&
		len>15 &&
		( header != NULL && strncasecmp(header,"Last-Modified: ", 15) == 0 ) ) {
		// Date
		header += 15;

		// Get date
		// Store, check for the condition of a wrong date
		// from the server
		server->pages->last_modified = get_time(header, "%a, %d %b %Y %H:%M:%S"); // da modificare la funzione get_time affinchè 'capisca' dove termina la stringa data
		// cout << ctime(&(server->pages->last_modified)) << endl;
		server->header_status.check_lmod = true;

	} else if (server->header_status.check_type == false && len>14 && (header != NULL && strncasecmp(header,"Content-Type: ", 14) == 0)) {
		char *charset;
		// Content-Type
		header += 14;

		// Skip leading spaces in content-type
		if (header != NULL) while (*header == ASCII_SP)	header++;

		// Di default meta->mime_type NON deve interpretare l'header per i path 'http://www.nomesito.it/robots.txt', 'http://www.nomesito.it/sitemap.rdf' ma
		// deve restituire il mime_type in funzione del path del tipo 'robots.txt' o 'sitemap.rdf'.
		// Per la nuova funzionalità che permette di lavorare con i file sitemap.xml (questi possono avere nomi diversi ma l'estensione deve essere sempre
		// xml/xml.gz) distribuiti nelle varie directory di un sito web, i mime_type vengono assegnati dal seeder e/o dalle funzioni che effettuano il parsing
		// dei file tipo sitemap.xml (standard sitemap.org), pena la mutua esclusione dei link che hanno nomefile ingannevoli.
		if (server->pages->doc->mime_type != MIME_ROBOTS_RDF_BROKEN
			&& server->pages->doc->mime_type != MIME_ROBOTS_XML_BROKEN
			&& server->pages->doc->mime_type != MIME_FEEDS_ATOM_XML_BROKEN
			&& server->pages->doc->mime_type != MIME_FEEDS_RSS_XML_BROKEN)
		{
			if (server->pages->doc->mime_type == MIME_ROBOTS_RDF)
			{
				if (meta->mime_type(server->pages->path, header) != MIME_TEXT_XML)
					server->pages->doc->mime_type = MIME_ROBOTS_RDF_BROKEN; // mimetype forced
			}
			else if (server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ)
			{
				if (meta->mime_type(server->pages->path, header) != MIME_APPLICATION_XML && meta->mime_type(server->pages->path, header) != MIME_TEXT_XML)
					server->pages->doc->mime_type = MIME_ROBOTS_XML_BROKEN; // mimetype forced
			}
			else if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML || server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ)
			{
				if (meta->mime_type(server->pages->path, header) != MIME_APPLICATION_ATOM_XML &&
					meta->mime_type(server->pages->path, header) != MIME_APPLICATION_XML &&
					meta->mime_type(server->pages->path, header) != MIME_TEXT_XML)
					server->pages->doc->mime_type = MIME_FEEDS_ATOM_XML_BROKEN; // mimetype forced
			}
			else if (server->pages->doc->mime_type == MIME_FEEDS_RSS_XML || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ)
			{
				if (meta->mime_type(server->pages->path, header) != MIME_APPLICATION_RSS_XML &&
					meta->mime_type(server->pages->path, header) != MIME_APPLICATION_XML &&
					meta->mime_type(server->pages->path, header) != MIME_TEXT_XML)
					server->pages->doc->mime_type = MIME_FEEDS_RSS_XML_BROKEN; // mimetype forced
			}
			else
				server->pages->doc->mime_type = meta->mime_type(server->pages->path, header);
		}
        
 	   		// Get Charset
		charset = strchr(header, ';');

	    if (charset == NULL)
	   	    charset = CONF_GATHERER_DEFAULTCHARSET;
	   	else
		{
			charset++;

			while (*charset == ' ' || *charset != '=') charset++;

			charset++;
		}
	    
	    server->pages->doc->charset = http_charset(charset);

		server->header_status.check_type = true;

	} else if ( server->header_status.check_language == false && len>18 && ( header != NULL && strncasecmp(header,"Content-Language: ", 18 ) == 0 ) ) {
		// Language
		header += 18;

		// Skip leading spaces in content-type
		if (header != NULL) while (*header == ASCII_SP)	header++;

		const size_t max_header_size = 2;

		// Relocation header
		size_t header_len = strnlen(header, (max_header_size + 1));

		if (header_len > 0 && header_len <= max_header_size)
		{
			Language metalanguage = http_language(header);

			// we assign language of document obtained with metatags, only if Language class cannot extrapolate stemming language
			// Stemming language must be extrapolate with much precision because words of text are needed for 'do you mean' process and
			// search engine can apply rigth stemming to documents
			if (metalanguage != Language::UNKNOWN && LANGUAGE_TO_STEMMING(metalanguage) == Stemming::UNKNOWN)
				server->pages->doc->language = metalanguage;
		}

		server->header_status.check_language = true;

	} else if ( server->header_status.check_location == false && len>10 && ( header != NULL && strncasecmp(header,"Location: ", 10 ) == 0 ) ) {
		// Location
		header += 10;

		// Skip leading spaces in content-type
		if (header != NULL) while (*header == ASCII_SP)	header++;

		const size_t max_header_size = (SERVER_MAX_PREFIX_PROTOCOL_SIZE + MAX_DOMAIN_LEN + MAX_STR_LEN);

		// Relocation header
		size_t header_len = strnlen(header, (max_header_size + 1));

		if (header_len > 0)
		{
			if (header_len <= max_header_size)
				strcpy(server->pages->relocation, header);
			else
				server->pages->relocation[0] = ASCII_NUL;
		}
		else
			server->pages->relocation[0] = ASCII_NUL;

		server->header_status.check_location = true;

	} else if ( server->header_status.check_length == false && len>16 && ( header != NULL && strncasecmp(header,"Content-Length: ", 16 ) == 0 ) ) {
		//Content-Length 
		header += 16;

		// Skip leading spaces in content-type
		if (header != NULL) while (*header == ASCII_SP)	header++;

		ssize_t length = (ssize_t)atoi(header);

		// Content-Length header, helpful with clear text receiving with inflate rata receiving
		if (length > 0)
			server->pages->bo_net_bodysize = length;

		server->header_status.check_length = true;

	} else if ( server->header_status.check_connection == false && len>12 && ( header != NULL && strncasecmp(header,"Connection: ", 12 ) == 0 ) ) {
		//Content-Encoding 
		header += 12;

		// Skip leading spaces in content-type
		if (header != NULL) while (*header == ASCII_SP)	header++;

		// Connection header
		if (header != NULL && strncasecmp(header, "close", 5) == 0) server->pages->peer_close = true;

		server->header_status.check_connection = true;

	} else if ( server->header_status.check_encoding == false && len>18 && ( header != NULL && strncasecmp(header,"Content-Encoding: ", 18 ) == 0 ) ) {
		//Content-Encoding 
		header += 18;

		// Skip leading spaces in content-type
		if (header != NULL) while (*header == ASCII_SP)	header++;

		// Content-Encoding header
		if (header != NULL) server->pages->doc->content_encoding = meta->content_encoding(header);

		server->header_status.check_encoding = true;

	} else if (server->pages->doc->chunked == false && len>19 && ( header != NULL && strncasecmp(header,"Transfer-Encoding: ", 19 ) == 0 )) {
		// Transfer-enconding
		header += 19;

        if (header != NULL) while (*header == ASCII_SP || *header == ASCII_TB) header++;

		if (header != NULL && strncasecmp(header, "chunked", 7) == 0)
		{
			server->pages->doc->chunked = true;
			server->pages->decoding_state = CHUNCKED_READING_HEX_VALUE;
			server->pages->end_chunk_pattern = 0;
			server->pages->chunk_length = -1;
		}

	} else {

		// We don't care about content-length
		// We don't care about anything else
	}
}

//
// Nome: server_reset_buffers
//
// Descrizione: resetta i buffers
//
// Accetta: il puntatore 'server'
//
void server_reset_buffers(server_t *server) {

	if (server->pages->buffer_one != NULL)
		free (server->pages->buffer_one);

	if (server->pages->buffer_two != NULL) // non sarebbe necessario ... ;-)
		free (server->pages->buffer_two);

	server->pages->buffer_one = NULL;
	server->pages->bo_size = 0;
	server->pages->bo_net_bodysize = 0;
	server->pages->peer_close = false;
    server->pages->buffer_two = NULL;
    server->pages->bt_size = 0;
}

//
// Name: server_close
//
// Description:
//   Closes the connection with the server
//
// Input:
//   server->socket.fd - the current socket.fd, must not be -1
//
// Output:
//   server->socket.fd - set to -1
//

void server_close(server_t *server)
{
	assert( server != NULL );

	if (server->ssl != NULL)
	{
//		mbedtls_net_free( &server->socket );
		mbedtls_x509_crt_free(&server->cacert);
		mbedtls_ssl_free(server->ssl);
		mbedtls_ssl_config_free(&server->conf);
		mbedtls_ctr_drbg_free(&server->ctr_drbg);
		mbedtls_entropy_free(&server->entropy);
		free (server->ssl); server->ssl = NULL;
	}

	/* clean up and return Zlib*/
	if (server->pages->doc->content_encoding != ENCODING_NONE)
	{
		(void)inflateEnd(server->pages->z_strm);
		free(server->pages->z_strm);
	}

	if (server->socket.fd == -1)
	{
		mcerr << RED << "Warning: attempt to close -1 socket.fd in " << server->hostname << NOR << mendl;
		return;
	}

	shutdown(server->socket.fd, 2);
	close(server->socket.fd);
	server->socket.fd = -1;
}

//
// Name: server_save_current_page
//
// Description:
//   Saves the current page (the first page in the document list).
//   Advances to the next page.
//   This is usually called after removing the server from
//   activepool_poll.
//
// Input:
//   server->pages - the list of pages
//
// Output:
//   server->ndocs_done - increases by one
//   server->pages - advances to the next page
//
void server_save_current_page(starter_t *starter, siteid_t serverid)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert( server != NULL );
	assert( server->site != NULL );
	assert( server->pages != NULL );
	assert( server->ndocs_done < server->ndocs );

	// Get the page and document
	site_t *site = server->site;
	page_t *page = server->pages;
	doc_t  *doc  = page->doc;

	// Copy the last http status observed with the server to
	// this document's http_status
	// Note: http undefined status is admitted only for excluded document
	// that are already saved from previous harvests (homepages are always saved)
	if (doc->http_status == HTTP_STATUS_UNDEFINED && doc->status != STATUS_DOC_EXCLUSION && doc->status != STATUS_DOC_FORBIDDEN)
	{
		if (server->http_status == HTTP_STATUS_UNDEFINED)
		{
			mcerr << "Doc has undefined status while trying to save: siteid=" << site->siteid << " docid=" << doc->docid << " path=" << page->path << mendl;
			die( "Server had undefined status" );
		}

		doc->http_status = server->http_status;
	}

	// Save some data about the request. Notice that we set last_visit=now
	// AFTER we made the request, because we need the actual last visit
	// to issue a 'If-Modified-Since' header.
	doc->last_visit = time(NULL);

	// We must be absolutely sure that the document last-modified
	// date is less or equal than the last-visit date or we may
	// end up in a loop
	if (doc->last_modified > doc->last_visit) doc->last_modified = doc->last_visit;

	server->pages->doc->abs_last_modified = false;

	if (doc->number_visits == 0) doc->first_visit = doc->last_visit;

	doc->number_visits++;

	// Calculate latency and speed
	// TODO da rendere precisi i tempi di latenza
	if (timerisset( &(page->timestamp_begin_connect)) &&
		timerisset( &(page->timestamp_end_connect)) &&
		timerisset( &(page->timestamp_last_read)) &&
		(page->bytes_total > 0))
	{
		doc->latency_connect	= timer_delta( &(page->timestamp_end_connect), &(page->timestamp_begin_connect) );

		// Check if we have more than one packet (in that case, the
		// calculation is more accurate)
		if (page->bytes_first_packet == page->bytes_total)
		{

			// We had only one packet, latency is latency of connect,
			// but we cannot measure the latency of writing and reading,
			// so we will (wrongly) asume it is zero
			doc->latency = 0;
			doc->effective_speed = (float)(page->bytes_total) / timer_delta( &(page->timestamp_last_read), &(page->timestamp_end_connect) );

		}
		else
		{
			// We had more than one packet, measure the speed using all packets
			// except the first one
			doc->effective_speed = (float)((page->bytes_total) - page->bytes_first_packet) / timer_delta(&(page->timestamp_last_read), &(page->timestamp_first_read));

			// Start with a latency that is all the time between the end
			// of the connect and the receiving of the first packet
			doc->latency = timer_delta(&(page->timestamp_first_read), &(page->timestamp_end_connect));
			
			// Correct this latency by discounting the time is took to
			// transfer the first packet.
			doc->latency -= (float)(page->bytes_first_packet) / (doc->effective_speed);

			// We can get a very low latency, correct to 0
			if (doc->latency < 0)
				doc->latency	= 0;
		}
	}


	// If the page was succesfully fetched, reset the error counter for the website
	if (HTTP_IS_OK(doc->http_status) || HTTP_IS_REDIRECT(doc->http_status)) site->count_error = 0;

	// Update data about the site
	site->last_visit = doc->last_visit;

	if (doc->raw_content_length > 0) site->raw_content_length += doc->raw_content_length;

	// Report this page
	int rwritten = 0;
	size_t rspace = MAX_STR_LEN;
	char *report = CBALLOC(char, MALLOC, rspace);
	report[0] = ASCII_NUL;

	if (doc->status == STATUS_DOC_EXCLUSION)
		rwritten = snprintf(report, rspace, "%s%s ", BRO, DOC_STATUS_STR(STATUS_DOC_EXCLUSION));
	else if (doc->status == STATUS_DOC_FORBIDDEN)
		rwritten = snprintf(report, rspace, "%s%s ", BRO, DOC_STATUS_STR(STATUS_DOC_FORBIDDEN));
	else if (HTTP_IS_ERROR(server->pages->doc->http_status)) // Error
	{
    	rwritten = snprintf(report, rspace, "%s%s ", RED, HTTP_STR(server->pages->doc->http_status));
		rspace -= rwritten;
	}
	else if (HTTP_IS_OK(server->pages->doc->http_status)) // Ok, downloaded
	{
		if (server->site->protocol == HTTP || server->site->protocol == HTTP_TEMPORARY)
    		rwritten = snprintf(report, rspace, "%s", GRE);
		else if (server->site->protocol == HTTPS || server->site->protocol == HTTPS_TEMPORARY)
    		rwritten = snprintf(report, rspace, "%s", LGR);

		rspace -= rwritten;

		if (rspace > 0)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, "%s %s%s", HTTP_STR(server->pages->doc->http_status), NOR, GRE);
			rspace -= (rwritten - _rwritten);
		}

		// home page was found with temporary protocol
		// now becomes the official protocol
		if (server->pages->is_fqdn_request == true)
		{
			if (server->site->protocol == HTTPS_TEMPORARY)
				server->site->protocol = HTTPS;
			else if (server->site->protocol == HTTP_TEMPORARY)
				server->site->protocol = HTTP;
		}
	}
	else // Ok, but no data
	{
    	rwritten = snprintf(report, rspace, "%s%s ", BRO, HTTP_STR(server->pages->doc->http_status));
		rspace -= rwritten;
	}

	if (rspace > 0)
	{
		int _rwritten = rwritten;
		rwritten += snprintf(report + rwritten, rspace, "%s/%s %lu", server->hostname, server->pages->path, (unsigned long int)doc->raw_content_length);
		rspace -= (rwritten - _rwritten);
	}

	if (server->pages->doc->mime_type == MIME_REDIRECT && server->pages->redirect_is_relative == false)
		server->pages->path[0] = ASCII_NUL; // il nuovo link rediretto è compreso di dominio, 'path' non serve

	struct sockaddr_in *sai = (struct sockaddr_in *)server->addr;
	struct sockaddr_in6 *sai6 = (struct sockaddr_in6 *)server->addr;

	// Temporary status cannot exist after the end of query
	// If first visit and page is robots.txt, leave protocol status needed to switch definitive
	// if homepage is forbidden and we want have protocol for rest of site
	if (CONF_SEEDER_ADD_ROBOTSTXT == true &&
		server->pages->mime_type == MIME_ROBOTS_TXT &&
		server->ndocs_done == 0)
	{
		switch (server->addr->ss_family)
		{
			case AF_INET:
				if (server->site->protocol == HTTPS_TEMPORARY)
					server->site->protocol = HTTPS;
				else if (server->site->protocol == HTTP_TEMPORARY)
					server->site->protocol = HTTP;

				break;
			case AF_INET6: // IPV6 Sperimentale
				if (server->site->protocol == HTTPS_TEMPORARY)
					server->site->protocol = HTTPS;
				else if (server->site->protocol == HTTP_TEMPORARY)
					server->site->protocol = HTTP;

				break;
			default:

				assert(server->site->protocol != NOT_DEFINED);

				break;
		}
	}
	else
	{
		switch (server->addr->ss_family)
		{
			case AF_INET:
				if (server->site->protocol == HTTPS_TEMPORARY)
				{
					server->site->protocol = HTTP;
					sai->sin_port = htons(HTTP_PORT);
				}
				else if (server->site->protocol == HTTP_TEMPORARY)
				{
					server->site->protocol = HTTPS;
					sai->sin_port = htons(HTTPS_PORT);
				}

				break;
			case AF_INET6: // IPV6 Sperimentale
				if (server->site->protocol == HTTPS_TEMPORARY)
				{
					server->site->protocol = HTTP;
					sai6->sin6_port = htons(HTTP_PORT);
				}
				else if (server->site->protocol == HTTP_TEMPORARY)
				{
					server->site->protocol = HTTPS;
					sai6->sin6_port = htons(HTTPS_PORT);
				}

				break;
			default:

				assert(server->site->protocol != NOT_DEFINED);

				break;
		}
	}

	// Gatherer/parser data
	server_gatherer(starter, serverid, report, rwritten, rspace);

	// loading of robotstxt's rules is done ignoring parser status
	// TODO check if old content is keep if parsing was without success
	if (CONF_SEEDER_ADD_ROBOTSTXT == true &&
		server->pages->mime_type == MIME_ROBOTS_TXT &&
		server->ndocs_done == 0)
		robots_txt_ndocs_done++;

	mcerr << report << NOR << mendl;

	free(report);

	server_reset_buffers(server);

	if (server->pages->src_path != NULL)
		free(server->pages->src_path);

	// Advance the pointer to the next page
	page_t *ptr = server->pages;
	server->pages = page->next;

	// old memory pointed by server->pages must be freed (Linked List)
	if (ptr != NULL)
		free(ptr);

	server->ndocs_done++;

	if (server->ndocs_done == server->ndocs)
		assert(server->pages == NULL);
}

//
// Name: server_save_site
//
// Description:
//   Saves the data about a site
//
// Input:
//   server->site - the site structure
//   site_file - the file that we must write to
//
void server_save_site( server_t *server ) {
	assert( server != NULL );
	assert( server->site != NULL );
	assert( server->site->last_visit > 0 );

	mcerr << "Saving site data for " << server->hostname << ": last http_status was " << HTTP_STR(server->http_status) << mendl;

	// Check if the site had only errors
	if (server->errors_in_this_harvest >= server->ndocs) server->site->count_error++;

	// Check if we have a latency for the resolver
	if (timerisset(&(server->timestamp_resolver_start))
	 && timerisset(&(server->timestamp_resolver_end)))
		server->site->resolver_latency	= timer_delta(&(server->timestamp_resolver_end), &(server->timestamp_resolver_start));

	// Mark site as unassigned
	server->site->harvest_id = 0;

	// Free hostname
	free(server->hostname);

	// Free addr
	free(server->addr);

	// Store
	if (meta->site_store(server->site) != METADDX_OK)
		die("metaddx site_store for siteid %llu", server->site->siteid);

	// Mark site as visited
	if (meta->site_option_set(server->site->siteid, SITE_OPT_NEW, false) != METADDX_OK)
		die("metaddx site_option_set for siteid %llu", server->site->siteid);
}

//
// Name: server_gatherer
//
// Description:
//   Gather pages from one fetcher
//
// Input:
//   server - the server structure
//
void server_gatherer(starter_t *starter, siteid_t serverid, char *report, int &rwritten, size_t &rspace)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	server_t *server = &(servers[serverid]);
	assert(server != NULL );
	assert(CONF_GATHERER_MAXSTOREDSIZE > 0 && CONF_GATHERER_MAXSTOREDSIZE < CONF_MAX_FILE_SIZE);
    assert(server->pages->doc->docid >= 0);

	off64_t old_content_length = server->pages->doc->content_length;

	if (rspace > 0)
	{
		if (debugonly == false)
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, " docid %llu ", (unsigned long long int)server->pages->doc->docid);
			rspace -= (rwritten - _rwritten);
		}
		else
		{
			int _rwritten = rwritten;
			rwritten += snprintf(report + rwritten, rspace, " docid %llu\n", (unsigned long long int)server->pages->doc->docid);
			rspace -= (rwritten - _rwritten);
		}
	}

	site_t *site = server->site;

	docid_t saved_docid = server->pages->doc->docid;

	bool d_check = true;
	bool valid_document = true;
	char *inbuf = NULL;

	if (server->pages->doc->status == STATUS_DOC_EXCLUSION || server->pages->doc->status == STATUS_DOC_FORBIDDEN)
		valid_document = false;

	if (server->pages->doc->mime_type == MIME_ROBOTS_RDF_BROKEN
		|| server->pages->doc->mime_type == MIME_ROBOTS_XML_BROKEN
		|| server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_BROKEN
		|| server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_BROKEN
		|| server->pages->doc->mime_type == MIME_APPLICATION_PDF_BROKEN)
	{
		valid_document = false;
	}
	else
		inbuf = server->pages->buffer_one;

	off64_t raw_content_length = 0;

	// Check special mime-types; we don't care if it was successfull
	if( server->pages->doc->docid == site->docid_robots_txt )
	{
		assert(server->pages->mime_type == MIME_ROBOTS_TXT);

		site->last_checked_robots_txt = server->pages->doc->last_visit;

		bool site_had_valid_robots_txt = ((meta->site_option_get(site->siteid, SITE_OPT_VRTXT, true) == METADDX_OK) ? true : false);

		metaddx_status_t status = meta->site_option_set(site->siteid, SITE_OPT_VRTXT, (HTTP_IS_OK(server->pages->doc->http_status) || server->pages->doc->http_status == HTTP_NOT_MODIFIED));
		assert(status == METADDX_OK);

		// check if document had a robots.txt's valid content to be deleted
		if (site_had_valid_robots_txt == true && meta->site_option_get(site->siteid, SITE_OPT_VRTXT, false) == METADDX_OK);
		{
			if (old_content_length > 0)
			{
				storage_status_t storage_status = STORAGE_ERROR;
				siteid_t pos = ((server->site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

				assert(robots_txt_rules[starter->inst][pos] == NULL);;

				// pass a virtual_id (as docid) at storage because it work with docid_t type and,
				// must be major of 0 like valid docid
				docid_t virtual_id = (docid_t)(pos + 1);

				// delete robots.txt content
				storage_status = ridx->st_idx_delete(starter->inst, virtual_id);

				server->updated_robotstxt = true;

				assert(storage_status == STORAGE_OK);

				server->pages->doc->content_length = 0;
			}
		}
	}
	else if( server->pages->doc->docid == site->docid_sitemap_rdf )
		site->last_checked_sitemap_rdf	= server->pages->doc->last_visit;

	if( server->pages->doc->mime_type == MIME_ROBOTS_RDF && server->pages->doc->docid != site->docid_sitemap_rdf)
		valid_document = false;

	// before 'server_gatherer_size' keep real amount of size of network packets received
	// in this session, because in the case of compressed data real size must be saved in Meta Data
	off64_t deflate_raw_content_length = server->pages->doc->raw_content_length;

	// Check if document is too long
	if (valid_document == true)
		server_gatherer_getsize(server, &(raw_content_length));

	if( valid_document == true && inbuf != NULL && raw_content_length > 0 )
	{
		off64_t readed_bytes;

		harv->hv_incr_raw_size(starter->inst, raw_content_length);

		inbuf = server_gatherer_dataclean(server, inbuf, &(raw_content_length), &(d_check), &(valid_document), &(readed_bytes));

		assert(server->pages->doc->raw_content_length > 0);

		if (d_check == true)
		{
			if (server->pages->doc->mime_type == MIME_TEXT_PLAIN && strlen(inbuf) == 0)
				valid_document = false;

			// See if it is necessary to search links
			// N.B. Da quì in poi tutti i documenti con speciale mime_type compresso (_GZ) sono in puro testo.
			if (valid_document == true && (HTTP_IS_OK(server->pages->doc->http_status) || HTTP_IS_REDIRECT(server->pages->doc->http_status)))
			{
				assert(server->pages->doc->raw_content_length > 0);

				inbuf = server_gatherer_detect_charset(server, inbuf, &(valid_document), &(readed_bytes));

				unsigned int robots_txt_exclusions = 0;

				if (valid_document == true)
				{
					// save_page(doc, harvest, hierarchy_depth, inbuf, site, path); // funzionante ma non necessario

					if (server->pages->doc->mime_type == MIME_ROBOTS_TXT)
						robots_txt_exclusions = parser_process(starter, serverid, inbuf, report, rwritten, rspace);
					else
					{
						server->pages->doc->content_length = parser_process(starter, serverid, inbuf, report, rwritten, rspace);

						if (old_content_length > 0 && server->pages->doc->content_length == 0)
						{
mcerr << LRE << "================================================== " << server->pages->doc->docid << " ===========================================" << NOR << mendl;
// assert(true == false);
		//					strg->delete_document(server->pages->doc); // TODO is really needed? (see header)

							server->pages->buffer_two[server->pages->doc->content_length] = ASCII_NUL;
						}
					}

					// if (server->pages->doc->content_length > 0)
					//	mcout << server->pages->buffer_two << mendl; // debug parsing html
						
				}
				else
				{
					server->pages->doc->content_length = 0;
					server->pages->buffer_two[server->pages->doc->content_length] = ASCII_NUL;
				}

				if (server->pages->doc->mime_type == MIME_ROBOTS_TXT)
				{
					// Content of robots is not stored, only links
					// The content_length tells if there are exclusions

					if (rspace > 0)
					{
						int _rwritten = rwritten;

						if (robots_txt_exclusions > 0)
							rwritten += snprintf(report + rwritten, rspace, "(robots.txt w/exclusions)");
						else
							rwritten += snprintf(report + rwritten, rspace, "(robots.txt)");

						rspace -= (rwritten - _rwritten);
					}
				} 
				else if (server->pages->doc->mime_type == MIME_ROBOTS_RDF)
				{
					// Content of robots is not stored, only links
					// The content_length tells if there are exclusions

					if (rspace > 0)
					{
						int _rwritten = rwritten;

						if (server->pages->doc->content_length > 0)
						{
							rwritten += snprintf(report + rwritten, rspace, "(sitemap.rdf w/information)");
							server->pages->doc->has_valid_mimetype = true;

							metaddx_status_t status = meta->site_option_set(site->siteid, SITE_OPT_VSRDF, true);

							assert(status == METADDX_OK);
						}
						else
							rwritten += snprintf(report + rwritten, rspace, "(sitemap.rdf)");

						rspace -= (rwritten - _rwritten);
					}
				} 
				else if (server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ)
				{
					// Content of robots is not stored, only links
					// The content_length tells if there are exclusions

					if (rspace > 0)
					{
						int _rwritten = rwritten;

						if (server->pages->doc->content_length > 0)
						{
							rwritten += snprintf(report + rwritten, rspace, "(sitemap.xml w/information)");
							server->pages->doc->has_valid_mimetype = true;
						}
						else
							rwritten += snprintf(report + rwritten, rspace, "(sitemap.xml)");

						rspace -= (rwritten - _rwritten);
					}
				}
				else if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML || server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ)
				{
					// Content of robots is not stored, only links
					// The content_length tells if there are exclusions

					if (rspace > 0)
					{
						int _rwritten = rwritten;

						if (server->pages->doc->content_length > 0)
						{
							rwritten += snprintf(report + rwritten, rspace, "(atom+xml feed w/information)");
							server->pages->doc->has_valid_mimetype = true;
						}
						else
							rwritten += snprintf(report + rwritten, rspace, "(atom+xml feed)");

						rspace -= (rwritten - _rwritten);
					}
				}
				else if (server->pages->doc->mime_type == MIME_FEEDS_RSS_XML || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ)
				{
					// Content of robots is not stored, only links
					// The content_length tells if there are exclusions

					if (rspace > 0)
					{
						int _rwritten = rwritten;

						if (server->pages->doc->content_length > 0)
						{
							rwritten += snprintf(report + rwritten, rspace, "(rss+xml feed w/information)");
							server->pages->doc->has_valid_mimetype = true;
						}
						else
							rwritten += snprintf(report + rwritten, rspace, "(rss+xml feed)");

						rspace -= (rwritten - _rwritten);
					}
				}
				else if (HTTP_IS_REDIRECT(server->pages->doc->http_status))
				{
					// Content of redirect is not stored, only links

					if (rspace > 0)
					{
						int _rwritten = rwritten;
						rwritten += snprintf(report + rwritten, rspace, "R");
						rspace -= (rwritten - _rwritten);
					}

					if (server->pages->buffer_links_download != NULL)
					{
						if (debugonly == false)
							fprintf(starter->links_download, "%s", server->pages->buffer_links_download);

						free (server->pages->buffer_links_download);
						server->pages->buffer_links_download = NULL;
					}

					if (server->pages->buffer_links_log != NULL)
					{
						if (debugonly == false)
							fprintf(starter->links_log, "%s", server->pages->buffer_links_log);

						free (server->pages->buffer_links_log);
						server->pages->buffer_links_log = NULL;
					}

				}
				else
				{
					if (server->pages->doc->content_length > 0)
					{
						// Check maximum stored size
						if( server->pages->doc->content_length >= (off64_t)CONF_GATHERER_MAXSTOREDSIZE )
						{

							off64_t c = (CONF_GATHERER_MAXSTOREDSIZE - 1);

							if (server->pages->buffer_two[c] != ' ')
							{
								while (c > 0 && server->pages->buffer_two[c] != ' ')
									c--;
					
								while (c > 0 && server->pages->buffer_two[c] == ' ') // si ferma all'ultimo spazio partendo dalla coda di server->pages->buffer_two
									c--;

								c++;
							}

							server->pages->buffer_two[c] = ASCII_NUL;
							server->pages->doc->content_length = c;
						}

						if ( debugonly == false && server->pages->doc->content_length < (off64_t)CONF_GATHERER_MAXSTOREDSIZE)
						{
							char *cmd5sum = NULL;

							// Update harvester
							harv->hv_incr_doc_count_ok(starter->inst);

							// If necessary, store only the hash function
							// Deprecated because not used by search engine
							if (CONF_GATHERER_SAVEHASHONLY)
							{
								// Make cmd5 of document content for future comparision (Attenzione: con valgrind alla prima chiamata della funzione
								// cmd5_string compare un errore)
								// char *cmd5sum = (char *) malloc (36 * sizeof(char)); // occorrerebbe verificare perchè valgrind
								// richiede uno spazio di 36 piuttosto che di 33
								// meglio usare new piuttosto che malloc
								char *cmd5sum = new char [(MD5LEN + 1)];

								// elaboro ogni keyword per controllare se contiene nomi tematici
								// resetto l'array per sicurezza
								memset(cmd5sum,ASCII_NUL, (MD5LEN + 1));

								if (server->pages->doc->mime_type == MIME_TEXT_PLAIN)
									cmd5_string(server->pages->buffer_two, server->pages->doc->content_length, cmd5sum);
								else if (server->pages->doc->mime_type == MIME_TEXT_HTML)
									cmd5_string(&server->pages->buffer_two[HTMLMETAPREFIXSIZE], (server->pages->doc->content_length - HTMLMETAPREFIXSIZE), cmd5sum);
								else if (server->pages->doc->mime_type == MIME_APPLICATION_PDF)
									cmd5_string(&server->pages->buffer_two[PDFMETAPREFIXSIZE], (server->pages->doc->content_length - PDFMETAPREFIXSIZE), cmd5sum);

								server->pages->doc->content_length = MD5LEN;
							}

							storage_status_t rcstorage;

							doc_t *doc = server->pages->doc;

							// Store content (deve avvenire prima della verifica degli sketch perchè Irudiko modifica il buffer)
							if (CONF_GATHERER_SAVEHASHONLY)
								rcstorage = strg->write_document(doc, cmd5sum);	
							else
								rcstorage = strg->write_document(doc, server->pages->buffer_two);

							// ricava la lingua del documento attraverso la classe Language, ignorando ciò che è stato rilevato attraverso i metatag
							if (rcstorage == STORAGE_OK)
							{ 
								size_t content_length = 0;

								if (doc->mime_type == MIME_TEXT_HTML)
								{
									pes_t *poutt = htmlSplit(server->pages->buffer_two); // Estrapolazione dei meta tags, contenuto ecc... dal buffer storage
								
									content_length = strlen(poutt->content);

									// preparo l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
									// utile alla classe delle lingue 
									la.make_analisys_index (starter->inst, min_word_len, poutt, content_length);

									// Ricava il ranking delle lingue
									language_out_t *langinfo = la.index_analisys_read(starter->inst);

									if (debugonly == true)
									{
										if (langinfo->ranking > 0)
										{
											char printout[50];
											sprintf (printout, "Language: %s for docid %lu", langinfo->language, (unsigned long int)doc->docid);
										}
									}
									else
									{
										if (langinfo->ranking > 0)
											doc->language = http_language(langinfo->language);
									}

									// libero l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
									la.free_analisys_index(starter->inst);

									poutt->title[0] = ASCII_NUL;
									poutt->headings[0] = ASCII_NUL;
									poutt->metadesc[0] = ASCII_NUL;
									poutt->metakeyw[0] = ASCII_NUL;
									poutt->metalmon = pes_t::NO_LOCAL_MONETARY;

									// libera l'area (dealloca) di memoria puntata dal puntatore content anche se di default avviene al termine del programma
									free(poutt->content);
									free(poutt);
								}
								else if (doc->mime_type == MIME_APPLICATION_PDF)
								{
									pes_t *poutt = pdfSplit(server->pages->buffer_two); // Estrapolazione dei meta informazioni, contenuto ecc... dal buffer storage
								
									content_length = strlen(poutt->content);

									// preparo l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
									// utile alla classe delle lingue 
									la.make_analisys_index (starter->inst, min_word_len, poutt, content_length);

									// Ricava il ranking delle lingue
									language_out_t *langinfo = la.index_analisys_read(starter->inst);

									if (debugonly == true)
									{
										if (langinfo->ranking > 0 && rspace > 0)
										{
											int _rwritten = rwritten;
											rwritten += snprintf(report + rwritten, rspace, "Language: %s for docid %lu\n", langinfo->language, (unsigned long int)doc->docid);
											rspace -= (rwritten - _rwritten);
										}
									}
									else
									{
										if (langinfo->ranking > 0)
											doc->language = http_language(langinfo->language);
									}

									// libero l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
									la.free_analisys_index(starter->inst);

									poutt->title[0] = ASCII_NUL;
									poutt->headings[0] = ASCII_NUL;
									poutt->metadesc[0] = ASCII_NUL;
									poutt->metakeyw[0] = ASCII_NUL;
									poutt->metalmon = pes_t::NO_LOCAL_MONETARY;

									// libera l'area (dealloca) di memoria puntata dal puntatore content anche se di default avviene al termine del programma
									free(poutt->content);
									free(poutt);
								}
								else if (doc->mime_type == MIME_TEXT_PLAIN)
								{
									pes_t *poutt = (pes_t*) malloc (sizeof(pes_t));
									poutt->content = (char*) malloc (sizeof(char) * MAX_DOC_LEN);
									poutt->content[0] = ASCII_NUL;
									strcpy(poutt->content, server->pages->buffer_two);

                                    content_length = strlen(server->pages->buffer_two);

									poutt->title[0] = ASCII_NUL;
									poutt->headings[0] = ASCII_NUL;
									poutt->metadesc[0] = ASCII_NUL;
									poutt->metakeyw[0] = ASCII_NUL;
									poutt->metalmon = pes_t::NO_LOCAL_MONETARY;

									// preparo l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
									// utile alla classe delle lingue 
									la.make_analisys_index (starter->inst, min_word_len, poutt, content_length);

									// Ricava il ranking delle lingue
									language_out_t *langinfo = la.index_analisys_read(starter->inst);

									if (debugonly == true)
									{
										if (langinfo->ranking > 0)
										{
											char printout[50];
											sprintf (printout, "Language: %s for docid %lu", langinfo->language, (unsigned long int)doc->docid);
										}
									}
									else
									{
										if (langinfo->ranking > 0)
											doc->language = http_language(langinfo->language);
									}

									// libero l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
									la.free_analisys_index(starter->inst);

									poutt->title[0] = ASCII_NUL;
									poutt->headings[0] = ASCII_NUL;
									poutt->metadesc[0] = ASCII_NUL;
									poutt->metakeyw[0] = ASCII_NUL;
									poutt->metalmon = pes_t::NO_LOCAL_MONETARY;

									// libera l'area (dealloca) di memoria puntata dal puntatore content anche se di default avviene al termine del programma
									free(poutt->content);
									free(poutt);
								}
							}

							unsigned char sketch_gap = 0;

							// Compute and store also LSH-sketch
							// if(CONF_MANAGER_SCORE_LIVERANK_WEIGHT && rcstorage == STORAGE_OK) // old solution
							// Warning: because irudiko library it assumes that can work only with
							// same languages of stemming (but without use stemming at moment)
							if (CONF_MANAGER_SCORE_LIVERANK_WEIGHT &&
								LANGUAGE_TO_STEMMING(doc->language) != Stemming::UNKNOWN &&
								rcstorage == STORAGE_OK)
							{
								unsigned long *oldsketch = NULL;

								// Legge precedente LSH-sketch (optional)
								if(server->pages->doc->number_visits_changed > 0)
								{
									IrudikoSimpleReader iread;
									irudiko_sketch_t ist;
									memset(&ist, 0, sizeof(irudiko_sketch_t));
									irudiko_t *sketch = ist.sketch;
									strg->read_sketch(server->pages->doc->docid, sketch);

									// This is to ensure only significant sketches are returned 
									bool is_empty_sketch = true;

									for(uint h = 0; h < IRUDIKO_SKETCHSIZE; ++h)
										if (sketch[h]!=0)
										{
											is_empty_sketch = false;
											break;
										}
	      
									if( is_empty_sketch == false)
									{
										oldsketch = (unsigned long *) malloc (IRUDIKO_SKETCHSIZE * sizeof(unsigned long));
										memcpy(oldsketch, sketch, (IRUDIKO_SKETCHSIZE * sizeof(unsigned long)));
									}
								}

								IrudikoSimpleReader iread;
								irudiko_sketch_t ist;
								memset(&ist, 0, sizeof(irudiko_sketch_t));

								// genera il nuovo sketch
								if( CONF_GATHERER_SAVEHASHONLY )
									iread.process_and_sketch(cmd5sum,server->pages->doc->content_length, ist.sketch, IRUDIKO_SKETCHSIZE, IRUDIKO_SELECTIONTYPE, IRUDIKO_SELECTIONPARAM);
								else
								{
									if (server->pages->doc->mime_type == MIME_TEXT_PLAIN)
										iread.process_and_sketch(server->pages->buffer_two, server->pages->doc->content_length, ist.sketch, IRUDIKO_SKETCHSIZE, IRUDIKO_SELECTIONTYPE, IRUDIKO_SELECTIONPARAM);
									else if (server->pages->doc->mime_type == MIME_TEXT_HTML)
										iread.process_and_sketch(&server->pages->buffer_two[HTMLMETAPREFIXSIZE], (server->pages->doc->content_length - HTMLMETAPREFIXSIZE), ist.sketch, IRUDIKO_SKETCHSIZE, IRUDIKO_SELECTIONTYPE, IRUDIKO_SELECTIONPARAM);
									else if (server->pages->doc->mime_type == MIME_APPLICATION_PDF)
										iread.process_and_sketch(&server->pages->buffer_two[PDFMETAPREFIXSIZE], (server->pages->doc->content_length - PDFMETAPREFIXSIZE), ist.sketch, IRUDIKO_SKETCHSIZE, IRUDIKO_SELECTIONTYPE, IRUDIKO_SELECTIONPARAM);
								} 

								// This is to ensure only significant sketches are returned 
								bool is_empty_sketch = true;

								for(uint h = 0; h < IRUDIKO_SKETCHSIZE; ++h)
									if (ist.sketch[h]!=0)
									{
										is_empty_sketch = false;
										break;
									}

								if( is_empty_sketch == false && oldsketch != NULL)
								{
									for(unsigned short h = 0; h < IRUDIKO_SKETCHSIZE; h++)
											if (ist.sketch[h] != oldsketch[h])
												sketch_gap++;

									// assegna crediti a variazioni sostanziali di pagina
									if (server->header_status.check_lmod == true)
									{
										if (server->pages->last_modified > server->pages->doc->last_modified)
										{
											if (sketch_gap > CONF_MANAGER_SCORE_LIVERANK_MIN_SKETCH)
											{
												if (server->pages->doc->last_modified_credits < CHAR_MAX)
													server->pages->doc->last_modified_credits++;
											}
										}
									}
								}

								irudiko_t *newsketch = ist.sketch;

								//storage_status_t rc2 = strg->write_sketch(server->pages->doc->docid,&ist);
								if (sketch_gap > 0)
								{
									strg->write_sketch(server->pages->doc->docid, newsketch);
									strg->write_sketch_gap(server->pages->doc->docid, &sketch_gap);
								}
								else if (oldsketch == NULL && is_empty_sketch == false) // nuovo
									strg->write_sketch(server->pages->doc->docid, newsketch);

								if (oldsketch != NULL)
									free (oldsketch);
							}

							if (cmd5sum != NULL)
								delete cmd5sum;

							switch (rcstorage)
							{

								case STORAGE_OK:
									// Update size of harvester
									// this includes only new bytes
									// downloaded and saved after parsing
									harv->hv_incr_size(starter->inst, server->pages->doc->content_length);
									server->pages->doc->number_visits_changed++;

									// nel caso il numero dei crediti è positivo significa che le modifiche
									// dei contenuti sono attendibili alla dichiarazione di un nuovo last-modified
									if (server->pages->doc->last_modified_credits > 0)
									{
										server->pages->doc->last_modified = server->pages->last_modified;

										if (server->pages->doc->abs_last_modified == false)
											server->pages->doc->from_feed = false;
									}

									if (rspace > 0)
									{
										int _rwritten = rwritten;
										rwritten += snprintf(report + rwritten, rspace, "S");
										rspace -= (rwritten - _rwritten);
									}

									break;

								case STORAGE_DUPLICATE:
									// It's a duplicate
									if (rspace > 0)
									{
										int _rwritten = rwritten;
										rwritten += snprintf(report + rwritten, rspace, "D");
										rspace -= (rwritten - _rwritten);
									}

									break;

								case STORAGE_UNCHANGED:
									// The server says it was modified, but
									// the content is the same.
									if (rspace > 0)
									{
										int _rwritten = rwritten;
										rwritten += snprintf(report + rwritten, rspace, "U");
										rspace -= (rwritten - _rwritten);
									}

									assert( server->pages->doc->number_visits_changed > 0 );

									// Se è stato ottenuto un Last-Modified maggiore del precedente mentre la pagina
									// è rimasta invariata allora decrementa il credito
									if (server->header_status.check_lmod == true)
									{
										if (server->pages->last_modified > server->pages->doc->last_modified)
										{
											if (server->pages->doc->last_modified_credits > CHAR_MIN)
												server->pages->doc->last_modified_credits--;
										}
									}

									break;

								default:
									die( "Inconsistency in return of storage_write" );
							}
						}
					}
					else
					{
						int _rwritten = rwritten;
						rwritten += snprintf(report + rwritten, rspace, "empty");
						rspace -= (rwritten - _rwritten);
					}

					if (server->pages->buffer_links_download != NULL)
					{
						if (debugonly == false && server->pages->doc->mime_type == MIME_TEXT_HTML)
							fprintf(starter->links_download, "%s", server->pages->buffer_links_download);

						free (server->pages->buffer_links_download);
						server->pages->buffer_links_download = NULL;
					}

					if (server->pages->buffer_links_log != NULL)
					{
						if (debugonly == false &&  server->pages->doc->mime_type == MIME_TEXT_HTML)
							fprintf(starter->links_log, "%s", server->pages->buffer_links_log);

						free (server->pages->buffer_links_log);
						server->pages->buffer_links_log = NULL;
					}
				}
			}
			else
			{
				// Neither OK nor redirect
				if (rspace > 0)
				{
					int _rwritten = rwritten;
					rwritten += snprintf(report + rwritten, rspace, "- not acceptable -");
					rspace -= (rwritten - _rwritten);
				}
			}
		}
		else
		{
			if (rspace > 0)
			{
				int _rwritten = rwritten;

				if (d_check == false)
					rwritten += snprintf(report + rwritten, rspace, "decompress( content ) failed ");
				else
					rwritten += snprintf(report + rwritten, rspace, "read( content ) %s ", cberr());

				rspace -= (rwritten - _rwritten);
			}

			if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "Failed in harvester %u, from docid %llu", starter->harvest_id, (unsigned long long int)server->pages->doc->docid);
				rspace -= (rwritten - _rwritten);
			}

			if (rspace > 0)
			{
				int _rwritten = rwritten;
				rwritten += snprintf(report + rwritten, rspace, "Expected %li Got %li", raw_content_length, readed_bytes);
				rspace -= (rwritten - _rwritten);
			}

			//die("Failed to read crawler content");
		}
	// Empty page
	}
	else if (rspace > 0)
	{
		int _rwritten = rwritten;
		rwritten += snprintf(report + rwritten, rspace, "empty");
		rspace -= (rwritten - _rwritten);
	}

	server_reset_buffers(server);

	if ( debugonly == false )
	{
		// if received deflated body save the rigth deflated size
		if (server->pages->doc->content_encoding != ENCODING_NONE)
			server->pages->doc->raw_content_length = deflate_raw_content_length;
		//

		// Store the corresponding document
		if (server->pages->doc->status == STATUS_DOC_EXCLUSION ||
			server->pages->doc->status == STATUS_DOC_FORBIDDEN)
			server->pages->doc->http_status = HTTP_STATUS_UNDEFINED;
		else
			server->pages->doc->status = STATUS_DOC_GATHERED;

		// If the document changes too often, mark as dynamic
		if( !server->pages->doc->is_dynamic && (server->pages->doc->number_visits == server->pages->doc->number_visits_changed)	&& (server->pages->doc->number_visits > CONF_GATHERER_CHANGETODYNAMIC) ) {
			server->pages->doc->is_dynamic = true;
		}

		assert(server->pages->doc->docid > 0);
		assert(server->pages->doc->docid == saved_docid);

		if (meta->doc_store( server->pages->doc) != METADDX_OK)
			die("server gatherer: error metaddx doc_store with docid %llu", saved_docid);
	}

	assert(rspace > 0); // at end we ensure we have other buffer where write
}

//
// Name: server_gatherer_getsize
//
// Description:
//   Calculate rigth output buffer size
//
// Input:
//   server - the server structure
//   raw_content_length - input buffer length
//
void server_gatherer_getsize(server_t *server, off64_t *raw_content_length)
{
	// Prepare next operations as inflate raw_content received
	if (server->pages->doc->content_encoding != ENCODING_NONE)
		server->pages->doc->raw_content_length = server->pages->z_ofs;

	// Check if document is too long
		if ( server->pages->doc->mime_type == MIME_ROBOTS_XML )
		{
			if ((off64_t)(CONF_MAX_SITEMAP_FILE_SIZE + MAX_STR_LEN) <= server->pages->doc->raw_content_length)
			{
				mcerr << "For docid " << server->pages->doc->docid << ": buffer oversize." << endl; 
				cerr << "On path " << server->pages->path << ": buffer oversize." << mendl; 
				abort();
			}

			server->pages->bt_size = server->pages->doc->raw_content_length;
		}
		else
		{
			if ((off64_t)(CONF_MAX_FILE_SIZE + MAX_STR_LEN) <= server->pages->doc->raw_content_length)
			{
				mcerr << "For docid " << server->pages->doc->docid << ": buffer oversize." << endl; 
				cerr << "On path " << server->pages->path << ": buffer oversize." << mendl; 
				abort();
			}

			if (server->pages->doc->mime_type == MIME_APPLICATION_PDF)
				server->pages->bt_size = (CONF_GATHERER_MAXSTOREDSIZE + MAX_STR_LEN + PDFMETAPREFIXSIZE);
			else if (server->pages->doc->mime_type == MIME_TEXT_HTML)
				server->pages->bt_size = (server->pages->doc->raw_content_length + HTMLMETAPREFIXSIZE);
			else
				server->pages->bt_size = server->pages->doc->raw_content_length;
		}

		// If there is data to parse
		server->pages->bo_size = server->pages->doc->raw_content_length;
		*raw_content_length = server->pages->doc->raw_content_length;
}

//
// Name: server_gatherer_dataclean
//
// Description:
//   Calculate rigth output buffer size
//
// Input:
//   server - the server structure
//   raw_content_length - input buffer length
//
char *server_gatherer_dataclean(server_t *server, char *inbuf, off64_t *raw_content_length, bool *d_check, bool *valid_document, off64_t *readed_bytes)
{
	assert(server->pages->doc->raw_content_length > 0);

	// Read
	*readed_bytes = server->pages->doc->raw_content_length;

	unsigned short v = 0;

	// Nel caso il contenuto non sia compresso, inbuf viene ripulito dagli spazi iniziali
	if (server->pages->doc->content_encoding == ENCODING_NONE)
	{
		inbuf[*raw_content_length] = ASCII_NUL;

		while ((inbuf[v] == ASCII_SP || inbuf[v] == ASCII_NL || inbuf[v] == ASCII_CR || inbuf[v] == ASCII_TB) && v < USHRT_MAX)
			v++;

		if (v > 0)
		{
			inbuf = &(inbuf[v]);
			server->pages->doc->raw_content_length = (*raw_content_length - v);
			*readed_bytes = server->pages->doc->raw_content_length;
		}
	}

	return inbuf;
}

//
// Name: server_gatherer_detect_charset
//
// Description:
//   Calculate rigth output buffer size
//
// Input:
//   server - the server structure
//   raw_content_length - input buffer length
//
char *server_gatherer_detect_charset(server_t *server, char *inbuf, bool *valid_document, off64_t *readed_bytes)
{
	//Create the detector
	cbotUniversalDetector *detector = new cbotUniversalDetector;
	
	charset_t detected_charset = CHARSET_UNKNOWN;

	// N.B.
	// Per i files robots o feed entrambi tipo xml, non viene accettata tolleranza nel rilevamento dei charset
	// in quanto questi file vengono valutati sopratutto per il loro link che contengono all'interno e:
	// NON DEVONO ESSERE INTERPRETATI MALE (scelta amministrativa)
	if( server->pages->doc->mime_type == MIME_TEXT_HTML ||
		server->pages->doc->mime_type == MIME_TEXT_PLAIN ||
		server->pages->doc->mime_type == MIME_ROBOTS_TXT ||
		server->pages->doc->mime_type == MIME_ROBOTS_RDF ||
		server->pages->doc->mime_type == MIME_ROBOTS_XML ||
		server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ ||
		server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML ||
		server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ ||
		server->pages->doc->mime_type == MIME_FEEDS_RSS_XML ||
		server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ )
	{
		//Try to detect the charset
		detected_charset = detector->GetCharset(inbuf, (PRUint32)*readed_bytes);

		if (detected_charset != CHARSET_UNKNOWN)
			server->pages->doc->charset = detected_charset;
		else
		{
			if (server->pages->doc->mime_type == MIME_TEXT_HTML)
				detected_charset = parser_charset_metadata(server, inbuf); // se pagina html si tenta di leggere il charset encoding nel meta tag 'Content-Type'
			else if (server->pages->doc->mime_type == MIME_ROBOTS_RDF ||
				server->pages->doc->mime_type == MIME_ROBOTS_XML ||
				server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ ||
				server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML ||
				server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ ||
				server->pages->doc->mime_type == MIME_FEEDS_RSS_XML ||
				server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ )
			{
				xmlCharEncoding xmlenc = xmlDetectCharEncoding((const xmlChar*)inbuf, *readed_bytes); // try to read charset encoding through libxml2 function library

				if (((xmlenc) == XML_CHAR_ENCODING_NONE) || ((xmlenc) == XML_CHAR_ENCODING_ERROR))
					detected_charset == CHARSET_UNKNOWN;
				else
					detected_charset = http_charset((char *)xmlGetCharEncodingName(xmlenc));
			}

			if (detected_charset != CHARSET_UNKNOWN)
				server->pages->doc->charset = detected_charset;
			else if (server->pages->doc->mime_type == MIME_TEXT_HTML ||
					server->pages->doc->mime_type == MIME_TEXT_PLAIN ||
					server->pages->doc->mime_type == MIME_ROBOTS_TXT)
				server->pages->doc->charset = http_charset(CONF_GATHERER_DEFAULTCHARSET);
		}

		//Change the CHARSET of the document to UTF-8, File May Grow
		if (CONF_GATHERER_CONVERTTOUTF8 && (server->pages->doc->charset != CHARSET_UTF_8 && server->pages->doc->charset != CHARSET_UNKNOWN) )
		{
			off64_t converted_length = (off64_t)0;
			ssize_t original_bt_size = server->pages->bt_size;

			if (server->pages->doc->mime_type == MIME_TEXT_HTML ||
				server->pages->doc->mime_type == MIME_TEXT_PLAIN ||
				server->pages->doc->mime_type == MIME_ROBOTS_TXT)
			{
				server->pages->bt_size = (server->pages->bo_size * 4); // incrementato per contenere eventuali conversioni di caratteri
				server->pages->buffer_two = CBALLOC(char, MALLOC, (server->pages->bt_size + 1));
				server->pages->buffer_two[0] = ASCII_NUL;

				off64_t converted_length = (off64_t)0;

				converted_length = http_charset_convert(server->pages->doc->charset, CHARSET_UTF_8, inbuf, server->pages->buffer_two, server->pages->bt_size);

				assert( converted_length < server->pages->bt_size ); // Die to avoid memory corruption
			}

			if (converted_length > 0)
			{
				server->pages->doc->raw_content_length = converted_length; // Update raw_content_length

				free (server->pages->buffer_one);

				// Esegue lo 'swap' della memoria:
				server->pages->buffer_one = server->pages->buffer_two;
				server->pages->bo_size = server->pages->bt_size;
				server->pages->buffer_two = NULL;

				if (server->pages->doc->mime_type != MIME_TEXT_HTML && server->pages->doc->mime_type != MIME_TEXT_PLAIN)
				{
					server->pages->buffer_two = CBALLOC(char, MALLOC, 1);
					server->pages->bt_size = 1;
					server->pages->buffer_two[0] = ASCII_NUL;
				}
				else
				{
					server->pages->buffer_two = CBALLOC(char, MALLOC, (server->pages->bt_size + 1));
					server->pages->buffer_two[0] = ASCII_NUL;
				}

				// swap
				inbuf = server->pages->buffer_one;
			}
			else
			{ // leave without convert to UTF-8
		/*		if (server->pages->doc->mime_type == MIME_ROBOTS_RDF)
				{
					server->pages->doc->mime_type = MIME_ROBOTS_RDF_BROKEN;
					free(server->pages->buffer_two);
					server->pages->buffer_two = NULL;
					server->pages->buffer_two = (char *) malloc (sizeof(char));
					assert (server->pages->buffer_two != NULL);
					server->pages->bt_size = 1;
					server->pages->buffer_two[0] = ASCII_NUL;
					*valid_document = false;
				}
				else if( server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ)
				{
					server->pages->doc->mime_type = MIME_ROBOTS_XML_BROKEN;
					free(server->pages->buffer_two);
					server->pages->buffer_two = NULL;
					server->pages->buffer_two = (char *) malloc (sizeof(char));
					assert (server->pages->buffer_two != NULL);
					server->pages->bt_size = 1;
					server->pages->buffer_two[0] = ASCII_NUL;
					*valid_document = false;
				}
				else if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML || server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ)
				{
					server->pages->doc->mime_type = MIME_FEEDS_ATOM_XML_BROKEN;
					free(server->pages->buffer_two);
					server->pages->buffer_two = NULL;
					server->pages->buffer_two = (char *) malloc (sizeof(char));
					assert (server->pages->buffer_two != NULL);
					server->pages->bt_size = 1;
					server->pages->buffer_two[0] = ASCII_NUL;
					*valid_document = false;
				}
				else if (server->pages->doc->mime_type == MIME_FEEDS_RSS_XML || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ) {
					server->pages->doc->mime_type = MIME_FEEDS_RSS_XML_BROKEN;
					free(server->pages->buffer_two);
					server->pages->buffer_two = NULL;
					server->pages->buffer_two = (char *) malloc (sizeof(char));
					assert (server->pages->buffer_two != NULL);
					server->pages->bt_size = 1;
					server->pages->buffer_two[0] = ASCII_NUL;
					*valid_document = false;
				}
				else */
				{
					server->pages->bt_size = original_bt_size;
					free(server->pages->buffer_two);
					server->pages->buffer_two = NULL;
					server->pages->buffer_two = CBALLOC(char, MALLOC, (server->pages->bt_size + 1));
					server->pages->buffer_two[0] = ASCII_NUL;
				}
			}
		}
		else
		{
			if (server->pages->doc->charset == CHARSET_UNKNOWN)
			{
				if( server->pages->doc->mime_type == MIME_ROBOTS_RDF )
				{
					server->pages->doc->mime_type = MIME_ROBOTS_RDF_BROKEN;
					*valid_document = false;
				}
				else if (server->pages->doc->mime_type == MIME_ROBOTS_XML || server->pages->doc->mime_type == MIME_ROBOTS_XML_GZ)
				{
					server->pages->doc->mime_type = MIME_ROBOTS_XML_BROKEN;
					*valid_document = false;
				}
				else if (server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML || server->pages->doc->mime_type == MIME_FEEDS_ATOM_XML_GZ)
				{
					server->pages->doc->mime_type = MIME_FEEDS_ATOM_XML_BROKEN;
					*valid_document = false;
				}
				else if (server->pages->doc->mime_type == MIME_FEEDS_RSS_XML || server->pages->doc->mime_type == MIME_FEEDS_RSS_XML_GZ)
				{
					server->pages->doc->mime_type = MIME_FEEDS_RSS_XML_BROKEN;
					*valid_document = false;
				}
			}

			server->pages->buffer_two = CBALLOC(char, MALLOC, (server->pages->bt_size + 1));
			server->pages->buffer_two[0] = ASCII_NUL;
		}

	}
	else if ( server->pages->doc->mime_type == MIME_REDIRECT )
	{
		server->pages->buffer_two = CBALLOC(char, MALLOC, 1);
		server->pages->bt_size = 1;
		server->pages->buffer_two[0] = ASCII_NUL;
	}
	else if ( server->pages->doc->mime_type == MIME_APPLICATION_PDF )
	{
		server->pages->buffer_two = CBALLOC(char, MALLOC, (server->pages->bt_size + 1));
		server->pages->buffer_two[0] = ASCII_NUL;
	}
	else
	{
		server->pages->buffer_two = CBALLOC(char, MALLOC, 1);
		server->pages->bt_size = 1;
		server->pages->buffer_two[0] = ASCII_NUL;
		*valid_document = false;
	}

	delete detector;

	return inbuf;
}

//
// Name: server_inflate_partial
//
// Description: inflate buffer (gzip or deflate) reallocating memory if needed
//
// Input:
//	server: the server_t structure
//	buffer: the input buffer
//	size: the size of input buffer
//	offset: the current offset in output buffer
//
// Return: Se la funzione va a buon fine il buffer ...
//
char *server_inflate_partial(server_t *server, int &ret, char *buffer, ssize_t &size)
{
	assert(server->pages->z_strm != NULL);
	assert(server->pages->buffer_one != NULL);

	const auto delta = (size_t)(MAX_WBITS * 1500);

	// decompress until deflate stream ends
	server->pages->z_strm->avail_in = size;

	// if no length, no input. Do nothing
	if (server->pages->z_strm->avail_in == 0 && server->pages->z_strm->avail_in < (server->pages->bo_size - MAX_WBITS))
		return server->pages->buffer_one;

	server->pages->z_strm->next_in = (unsigned char *)buffer;

	int c = 0;

	// run inflate() on input until output buffer not full for MAX_WBITS size
	do
	{
		c++;
		server->pages->z_strm->avail_out = MAX_WBITS;
		server->pages->z_strm->next_out = (unsigned char *)&server->pages->buffer_one[server->pages->z_ofs];

		ret = inflate(server->pages->z_strm, Z_NO_FLUSH); // buffer is sync out of 'do - while' cycle
		//ret = inflate(server->pages->z_strm, Z_SYNC_FLUSH); // less performances but buffer is always sync 

		assert(ret != Z_STREAM_ERROR);  // state not clobbered

		switch (ret)
		{
			case Z_NEED_DICT:
				ret = Z_DATA_ERROR;	 // and fall through
				break;
			case Z_DATA_ERROR:
				break;
			case Z_MEM_ERROR: // This is abnormal status because we use realloc
				return server->pages->buffer_one;
		}

		server->pages->z_ofs += MAX_WBITS - server->pages->z_strm->avail_out;

		// no memory left in destination buffer
		if (server->pages->doc->mime_type == MIME_ROBOTS_XML && server->pages->z_ofs > (ssize_t)(CONF_MAX_SITEMAP_FILE_SIZE + MAX_STR_LEN - MAX_WBITS))
		{
			ret = Z_MEM_ERROR;
			return server->pages->buffer_one;
		}
		else if ((server->pages->z_ofs + MAX_WBITS) > (ssize_t)(CONF_MAX_FILE_SIZE + MAX_STR_LEN - MAX_WBITS))
		{
			ret = Z_MEM_ERROR;
			return server->pages->buffer_one;
		}

		// increase memory left in destination buffer
		if (server->pages->z_ofs > (server->pages->bo_size - MAX_WBITS))
		{
			const auto min_required_size = (const ssize_t)(server->pages->z_ofs + MAX_WBITS);

			char *p = CBREALLOC(char, ssize_t, server->pages->buffer_one, server->pages->bo_size, min_required_size, delta);

			if (p == NULL)
			{
				ret = Z_MEM_ERROR;
				break;
            }

			server->pages->buffer_one = p;
		}
	} while (server->pages->z_strm->avail_out == 0);

	server->pages->buffer_one[server->pages->z_ofs] = ASCII_NUL;

	ret = ((Z_STREAM_END && server->pages->z_ofs <= (server->pages->bo_size - 1))) ? server->pages->z_ofs : 0;

	return server->pages->buffer_one;
}

/*
 * Test recv/send functions that make sure each try returns
 * WANT_READ/WANT_WRITE at least once before sucesseding
 */
static int mbedtls_recv_check(void *context, unsigned char *buf, size_t len)
{
    static int first_try = 1;
    int ret;

    if( first_try )
    {
        first_try = 0;
        return( MBEDTLS_ERR_SSL_WANT_READ );
    }

    ret = mbedtls_net_recv(context, buf, len);

    if (ret != MBEDTLS_ERR_SSL_WANT_READ) first_try = 1; // Next call will be a new operation

    return( ret );
}

static int mbedtls_send_check(void *context, const unsigned char *buf, size_t len)
{
    static int first_try = 1;
    int ret;

    if( first_try )
    {
        first_try = 0;
        return( MBEDTLS_ERR_SSL_WANT_WRITE );
    }

    ret = mbedtls_net_send(context, buf, len);

    if (ret != MBEDTLS_ERR_SSL_WANT_WRITE) first_try = 1; // Next call will be a new operation

    return( ret );
}

//
// Name: server_close_languages
//
// Description:
//   close index of language's stop words
//
// Input:
//
// Output:
// 

void server_close_languages(bool close_all)
{
    la.index_close (close_all);
}
