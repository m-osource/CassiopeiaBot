/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "pollvec.h"

//
// Name: pollvec_create
//
// Description:
//   Creates a polling vector structure
//
// Input:
//   max_nfds - maximum number of sockets being polled
//   file_log - logfile, or NULL for NO LOG
//
// Return:
//   the created object
//

pollvec_t *pollvec_create(siteid_t max_nfds, FILE *file_log)
{
	assert(max_nfds > 0);

	pollvec_t *pollvec = CBALLOC(pollvec_t, MALLOC, 1);

	// Log
	pollvec->file_log = file_log;

	if (pollvec->file_log != NULL)
		fprintf(pollvec->file_log, "Allocating ... ");

	// Current and maximum number of sockets
	pollvec->nfds = 0;
	pollvec->max_nfds = max_nfds;

	// sockets being polled
	pollvec->fds = CBALLOC(struct pollfd, MALLOC, max_nfds);

	// Servers in the sockets
	pollvec->serverids = CBALLOC(siteid_t, MALLOC, max_nfds);

	// Timeouts
	pollvec->timeouts = CBALLOC(time_t, MALLOC, max_nfds);

	// Clear the structures
	time_t now = time(NULL);
	for (siteid_t i = 0; i < max_nfds; i++)
	{
		pollvec->fds[i].fd		= -1;
		pollvec->fds[i].events	= 0;
		pollvec->serverids[i]	= 0;
		pollvec->timeouts[i]	= now;
	}

	if (pollvec->file_log != NULL)
		fprintf(pollvec->file_log, "done.\n");

	return pollvec;
}

//
// Name: pollvec_destroy
//
// Description:
//   Destroys a polling vector structure
//
// Input:
//   pollvec - the structure
//

void pollvec_destroy(pollvec_t *pollvec)
{
	assert(pollvec != NULL);
	assert(pollvec->nfds == 0);

	free(pollvec->fds);
	free(pollvec->serverids);
	free(pollvec->timeouts);

	if (pollvec->file_log != NULL)
	{
		fprintf(pollvec->file_log, "Destroying.\n");
		fclose(pollvec->file_log);
	}

	free(pollvec);
}

//
// Name: pollvec_insert
//
// Description:
//   Inserts a filedescriptor for polling
//
// Input:
//   server - the associated server
//   events - the events that will be polled
//   timeout - the timeout in seconds
//

void pollvec_insert(pollvec_t *pollvec, server_t *server, short events, time_t timeout_seconds)
{
	assert(pollvec != NULL);
	assert(pollvec->nfds < pollvec->max_nfds);
	assert(server != NULL);
	assert(events > 0);
//	assert((timeout_seconds * 1000) > CONF_HARVESTER_TIMEOUT_POLL);
	assert(server->conn_status == CONN_RESOLVING || server->conn_status == CONN_CONNECTING || server->conn_status == CONN_ROBOTSTXT_WAIT);

	if (server->conn_status == CONN_ROBOTSTXT_WAIT)
		assert((timeout_seconds * 1000) >= CONF_HARVESTER_TIMEOUT_POLL);
	else
	{
		assert((timeout_seconds * 1000) > CONF_HARVESTER_TIMEOUT_POLL);
		assert(server->socket.fd >= 0);
	}

	assert(server->pool_slot < (siteid_t)(~0));

	// Get a new slot
	siteid_t slot = pollvec->nfds++;

	// Copy information
	pollvec->fds[slot].fd		= server->socket.fd;
	pollvec->fds[slot].events	= events;
	pollvec->serverids[slot]	= server->serverid;
	pollvec->timeouts[slot]		= time(NULL) + timeout_seconds;

	// Report
	if (pollvec->file_log != NULL)
		fprintf(pollvec->file_log, "Server %s inserted in slot %llu of %llu (%llu max)\n", server->hostname, (unsigned long long int)slot, (unsigned long long int)pollvec->nfds, (unsigned long long int)pollvec->max_nfds);
}

//
// Name: pollvec_remove
//
// Description:
//   Removes a file descriptor from the polling
//
// Input:
//   server - the file descriptor to be removed
//

void pollvec_remove(pollvec_t *pollvec, server_t *server)
{
	assert(pollvec != NULL);
	assert(pollvec->nfds > 0);
	assert(server->socket.fd == -1);
	assert(server->serverid > 0);

	// Go through all slots
	for	(siteid_t slot=0; slot<pollvec->nfds; slot++)
	{
		// We cannot search for the fd, because it can be closed now
		if (pollvec->serverids[slot] == server->serverid)
		{
			siteid_t last_slot = pollvec->nfds - 1;

			// Reduce the number of nfds
			(pollvec->nfds)--;

			// Check if this is the last slot
			if (last_slot == slot)
				; // This is the last slot and do nothing
			else
			{
				// This is not the last slot, copy the last slot here
				pollvec->fds[slot].fd		= pollvec->fds[last_slot].fd;
				pollvec->fds[slot].events	= pollvec->fds[last_slot].events;
				pollvec->serverids[slot]	= pollvec->serverids[last_slot];
				pollvec->timeouts[slot]		= pollvec->timeouts[last_slot];
			}

			if (pollvec->file_log != NULL)
				fprintf(pollvec->file_log, "Server %s removed from slot %llu, now there are %llu free\n", server->hostname, (unsigned long long int)slot, (unsigned long long int)pollvec->nfds);

			return;
		}
	}

	if (pollvec->file_log != NULL)
		fprintf(pollvec->file_log, "Attempt to remove %s, it is not (there are %llu of %llu slots used)\n", server->hostname, (unsigned long long int)pollvec->nfds, (unsigned long long int)pollvec->max_nfds);
	
	die("Removed server->serverid does not exist");
}

//
// Name: pollvec_update
//
// Description:
//   Removes a file descriptor from the polling
//
// Input:
//   pollvec - the structure
//   server - the file descriptor to be removed
//   event - the new events
//   new_timeout - in seconds, now + time

void pollvec_update(pollvec_t *pollvec, server_t *server, short events, time_t timeout_seconds)
{
	assert(pollvec != NULL);
	assert(pollvec->nfds > 0);

	if (server->conn_status != CONN_ROBOTSTXT_WAIT) assert(server->socket.fd >= 0);

	assert(server->serverid > 0);

	// Go through all slots
	for (siteid_t slot=0; slot<pollvec->nfds; slot++)
	{
		// We cannot search for the fd, because it can be
		// closed now. We search for the serverid
		if (pollvec->serverids[slot] == server->serverid)
		{
			// Update
			assert(timeout_seconds > (uint)time(NULL));

			pollvec->fds[slot].events	= events;
			pollvec->timeouts[slot]		= timeout_seconds;

			if (pollvec->file_log != NULL)
				fprintf(pollvec->file_log, "Server %s updated in slot %llu, now events=%d, timeout=%ld\n", server->hostname, (unsigned long long int)slot, events, timeout_seconds);

			return;
		}
	}

	if (pollvec->file_log != NULL)
		fprintf(pollvec->file_log, "Attempt to update %s, it is not (there are %llu of %llu slots used)\n", server->hostname, (unsigned long long int)pollvec->nfds, (unsigned long long int)pollvec->max_nfds);
	
	die("Updated server->serverid %llu does not exist", (unsigned long long int)server->serverid);
}

//
// Name: pollvec_poll
//
// Description:
//   Calls poll()
//
// Input:
//   pollvec - the structure
//
// Output:
//   pollevents - the received events
//
// Return
//   the number of servers with events
//

siteid_t pollvec_poll(pollvec_t *pollvec, pollevent_t *pollevents, server_t *servers)
{
	assert(pollvec != NULL);
	assert(pollevents != NULL);

	if (pollvec->nfds == 0) {
		return 0;
	}

	// during ppoll call all signals are unblocked
//	sigset_t sigmask;
//	sigemptyset(&sigmask);

	// an event is being waited for 5s
	struct timespec timeout;
	timeout.tv_sec = (CONF_HARVESTER_TIMEOUT_POLL / 1000);
	timeout.tv_nsec = ((CONF_HARVESTER_TIMEOUT_POLL % 1000) * 1000000);

	errno = 0; // errno is thread-local

	// Check how many events are waiting
	// ppoll() allows an application to safely wait until either a file descriptor becomes ready or until a signal is caught. // see manpage poll(2)
	// int nevents_poll = ppoll(pollvec->fds, pollvec->nfds, &timeout, &sigmask);
	// during ppoll call all signals are unblocked
	int nevents_poll = ppoll(pollvec->fds, pollvec->nfds, &timeout, &action.sa_mask);

	if (nevents_poll < 0)
		die("Error Poll: %s", cberr());

	assert((nevents_poll == 0) || ((uint)nevents_poll <= pollvec->nfds));

	if (pollvec->file_log != NULL)
		fprintf(pollvec->file_log, "Poll() returned %d events in %llu sockets\n", nevents_poll, (unsigned long long int)pollvec->nfds);

	// Number of events checked
	uint nevents	= 0;
	time_t now		= time(NULL);

	for (siteid_t slot = 0; slot < pollvec->nfds; slot++)
	{
		short revents		= pollvec->fds[slot].revents;
		uint serverid		= pollvec->serverids[slot];

		if (revents != 0) {

			// Received a poll event
			pollevents[nevents].serverid	= serverid;
			pollevents[nevents].revents		= revents;

			if (pollvec->file_log != NULL) {
				fprintf(pollvec->file_log, "-> %s received event %d\n", servers[serverid].hostname, revents);
			}

			// Event ok
			nevents++;

		} else {

			// Check timeout
			if (now > pollvec->timeouts[slot]) {

				// Timedout
				pollevents[nevents].serverid	= serverid;
				pollevents[nevents].revents		= 0;

				if (pollvec->file_log != NULL) {
					fprintf(pollvec->file_log, "-> %s has a timeout\n", servers[serverid].hostname);
				}

				nevents++;

			}
		}
	}

	assert(nevents >= (uint)nevents_poll);
	assert(nevents <= pollvec->nfds);
	return nevents;
}

//
// Name: pollvec_empty
//
// Returns:
//   1 iff the polling vector is empty
//

bool pollvec_empty(pollvec_t *pollvec)
{
	assert(pollvec != NULL);
	assert(pollvec->nfds < pollvec->max_nfds);

	return (pollvec->nfds == 0) ? true : false;
}
