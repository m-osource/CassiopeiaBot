/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "page.h"

//
// Name: page_failed
//
// Description:
//   Sets the vars in page->doc, when the
//   http request failed
//    
// Input:
//   p - the page
//   http_code - the code
//

void page_failed( page_t *page, int http_code ) {
	assert( page != NULL );
	doc_t *doc = page->doc;
	assert( doc != NULL );

	// Now
	time_t now 			= time(NULL);

	doc->http_status	= http_code;
	doc->last_visit		= now;
	if( doc->number_visits == 0 ) {
		doc->first_visit = now;
	}
	doc->number_visits	++;
	doc->raw_content_length	= 0;
}

//
// Name: page_create_request
//
// Description:
//   Writes the request to server->socket.fd
//
// Input:
//   server - the server
//   page - this page
//   useragent - identification of this crawler
//   max_request_size - maximum size of the request
//
// Output:
//   request - must be of size max_request_size
//   request_size - the size of the created request
//

void page_create_request( server_t *server, page_t *page, char *useragent, uint max_request_size, char *request, uint *request_size ) {
	assert( server != NULL );
	assert( server->socket.fd >= 0 );
	assert( page != NULL );
	assert( page->path != NULL );
	assert( strlen(page->path) == 0 || page->path[0] != '/' );
	doc_t *doc = page->doc;
	assert( doc != NULL );
	assert( doc->docid > (docid_t)0 );
	
	// Create request
	request[0] = '\0';

	// Notice that the PATH could be exactly MAX_STR_LEN - 1,
	// So the request line must be rather large
	char req_line[MAX_STR_LEN * 2];
	sprintf( req_line, "GET /%s HTTP/1.1\r\n",	page->path );
	strcat( request, req_line );
	sprintf( req_line, "Host: %s\r\n",		server->hostname );
	strcat( request, req_line );

	if ( page->doc->mime_type == MIME_ROBOTS_XML )
		sprintf( req_line, "Range:bytes=0-%lu\r\n",	(unsigned long int)CONF_MAX_SITEMAP_FILE_SIZE );
	else
		sprintf( req_line, "Range:bytes=0-%lu\r\n",	CONF_MAX_FILE_SIZE );

	strcat( request, req_line );
	sprintf( req_line, "User-Agent: %s\r\n",	useragent );
	strcat( request, req_line );
	sprintf( req_line, "Accept-Language: %s\r\n",	CONF_HARVESTER_ACCEPTLANGUAGE );
	strcat( request, req_line );
	sprintf( req_line, "Accept-Encoding: %s\r\n",	CONF_HARVESTER_ACCEPTENCODING );
	strcat( request, req_line );
	sprintf( req_line, "Connection: close\r\n" );
	strcat( request, req_line );

	char optional[MAX_STR_LEN];
	
	if ( page->doc->mime_type == MIME_ROBOTS_RDF )
	{
		strcpy(optional, ",text/xml" );
		sprintf( req_line, "Accept: %s %s\r\n",		CONF_HARVESTER_ACCEPTMIME, optional );
	}
	else if ( page->doc->mime_type == MIME_ROBOTS_XML )
	{
		strcpy(optional, ",application/xml,text/xml" );
		sprintf( req_line, "Accept: %s %s\r\n",		CONF_HARVESTER_ACCEPTMIME, optional );
	}
	else if ( page->doc->mime_type == MIME_ROBOTS_XML_GZ )
	{
		strcpy(optional, ",application/xml,text/xml" );
		sprintf( req_line, "Accept: %s %s\r\n",		CONF_HARVESTER_ACCEPTMIME, optional );
	}
	else
		sprintf( req_line, "Accept: %s\r\n",		CONF_HARVESTER_ACCEPTMIME );

	strcat( request, req_line );
	sprintf( req_line, "TE:\r\n" );
	strcat( request, req_line );

	// Add If-Modified-Since if necessary
	if( doc->abs_last_modified == false )
	{
		if ( doc->last_modified > 0 )
		{
			char last_modified[MAX_STR_LEN];
			strftime( last_modified, MAX_STR_LEN, HTTP_TIME_FORMAT, gmtime( &(doc->last_modified) ) );
			sprintf(  req_line, "If-Modified-Since: %s\r\n", last_modified );
			strcat( request, req_line );
		}
		else if ( doc->last_visit > 0 )
		{
			char last_visited[MAX_STR_LEN];
			strftime( last_visited, MAX_STR_LEN, HTTP_TIME_FORMAT, gmtime( &(doc->last_visit) ) );
			sprintf(  req_line, "If-Modified-Since: %s\r\n", last_visited );
			strcat( request, req_line );
		}
	}

	// Blank line at the end of the request
	strcat( request, "\r\n" );
	(*request_size)	= strlen( request );
	assert( (*request_size) < max_request_size );
}
