/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
 
#include "seeder.h"

thread_local cpu_set_t system_cpus;

const size_t FILENAME_ROBOTS_TXT_LEN = strlen(FILENAME_ROBOTS_TXT);
const size_t FILENAME_ROBOTS_RDF_LEN = strlen(FILENAME_ROBOTS_RDF);
const size_t FILENAME_ROBOTS_XML_LEN = strlen(FILENAME_ROBOTS_XML);

//
// Name: main
//
// Description:
//   Main cycle for the seeder program
//
// Input:
//   argv[1] - filename to read; the file must have one url per line,
//             possibly prepended by a number to indicate its depth
//

char opt_start_urls[MAX_STR_LEN] = "";
unsigned int HARVESTER_ID = 0;
unsigned int ACT_HARVESTER_ID = 0;
internal_long_uint_t LINE_NUMBER = 0;
bool opt_force_start = false;

int main(int argc, char **argv)
{
try
{
	LINE_NUMBER = 0;

	// Init the program
	cbot_start("seeder");

	// Parse options
	harvest_status_t harvest_status = STATUS_HARVEST_EMPTY;
	
	while(1) {
		int option_index = 0;

		static struct option long_options[] = {
			{"help", 0, 0, 0},
			{"start", 1, 0, 0},
			{"force", 1, 0, 0},
			{0, 0, 0, 0}
		};

		char c = getopt_long (argc, argv, "hsf:",
				long_options, &option_index);
		
		if (c == -1)
			break;

		switch (c) {
			case 0:
				if (!strcmp(long_options[option_index].name, "start"))
				{
					opt_force_start = true;
					strcpy(opt_start_urls, optarg);
				}
				else if (!strcmp(long_options[option_index].name, "force"))
					HARVESTER_ID = atol(optarg);
				else if (!strcmp(long_options[option_index].name, "help")) seeder_usage();

				break;
			case 's':
				opt_force_start = true;
				break;
			case 'f':
				HARVESTER_ID = atol(optarg);
				break;
		}
	}

	// Initialize maps
	seeder_init_maps();

	// Open url index
	seeder_open_indexes();

	// Check if the metaddx is empty
	if (meta->doc_count() == 0 && (!opt_force_start))
		die ("Metaindex is empty, use --start to load starting urls");

	site_locked_list = CBALLOC(site_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

//	if (CONF_MANAGER_SCORE_SITERANK_WEIGHT == 1 || CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT == 1)
//		site_count_doc = CBALLOC(docid_t *, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	// Open harvester
	harv = new Harvest (COLLECTION_HARVEST, true);
	assert(harv);

	// Failed to open index
	if (thread_alarm != THREADS_OK) cbot_stop(1);

	if (opt_force_start)
	{
		int rc = 0;
		pthread_mutexattr_t attr;

		pthread_t *threads = NULL;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

			// setup mutex of storage
			//	strg->setmutex(&strglock);
			//
			// setup mutex of urlddx index before read/write in multithread
			url->setmutex(&urlslock, &urldlock, &urlplock);

			seeder_barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

			seeder_mutex = CBALLOC(pthread_mutex_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

			for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				seeder_mutex[i] = PTHREAD_MUTEX_INITIALIZER;

			seeder_site_mutex = CBALLOC(pthread_mutex_t, MALLOC, VIRTUAL_INSTANCES);
	
			for (instance_t v = 0; v < VIRTUAL_INSTANCES; v++)
				seeder_site_mutex[v] = PTHREAD_MUTEX_INITIALIZER;

			pthread_barrier_init(seeder_barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

			if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
				die("error setting mutex type %s", strerror(rc));

			if ((rc = pthread_mutexattr_init(&attr)) != 0)
				die("error creating mutex with attributes object %s", strerror(rc));
		}

		for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
		{
			seeder_thread_args_t *args = CBALLOC(seeder_thread_args_t, MALLOC, 1);
		    args->inst = inst;
		    args->force_start = true;
			args->status = harvest_status;

			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				if (pthread_create(&threads[inst], NULL, seeder_thread_function_process_harvest, (void *) args))
					die("error creating thread!");
			}
			else
				seeder_thread_function_process_harvest((void *) args); // only one distribution, function is call without thread 
		}

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

			free(threads);

			// destroy mutex of urlddx index
			url->destroymutex();

			// destroy mutex of storage
			//	strg->destroymutex();

			int rc = 0;

			if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
				die("error destroying mutex with attributes object %s", strerror(rc));

			for (siteid_t v = 0; v < VIRTUAL_INSTANCES; v++)
				pthread_mutex_destroy(&(seeder_site_mutex[v]));

			free(seeder_site_mutex); seeder_site_mutex = NULL;

			for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				pthread_mutex_destroy(&(seeder_mutex[i]));

			free(seeder_mutex); seeder_mutex = NULL;

			pthread_barrier_destroy(seeder_barrier);

			free(seeder_barrier); seeder_barrier = NULL;
		}

	//	seeder_process_harvest(NULL, keep_special);
		syslog(LOG_NOTICE, "seeder readed starting urls");
	}
	else
	{
		// Iterate through harvests
		for (unsigned int i = 1; harv->is_found(i) == true; i++)
		{
			LINE_NUMBER = 0;

			harvest_status = harv->hv_open(i, true);

			if (thread_alarm != THREADS_OK) cbot_stop(1);


			// Report
			cerr << "Checking harvester #" << harv->hv_id() << " ... " << HARVEST_STATUS_STR(harvest_status) << " ... ";

			// Check status
			if (harvest_status == STATUS_HARVEST_DONE || harv->hv_id() == HARVESTER_ID)
			{
				cerr << "ok" << (harv->hv_id() == HARVESTER_ID ? " [forced]" : "") << endl;

				ACT_HARVESTER_ID = harv->hv_id();

				cerr << "Reopening in write mode ... ";
				harv->hv_close();
				delete harv;
				harv = new Harvest (COLLECTION_HARVEST, true);
				assert(harv);

				if (thread_alarm != THREADS_OK) cbot_stop(1);

				harvest_status = harv->hv_open(i, false);

				if (thread_alarm != THREADS_OK) cbot_stop(1);

				int rc = 0;
				pthread_mutexattr_t attr;

				pthread_t *threads = NULL;

				if (CONF_COLLECTION_DISTRIBUTED > 1)
				{
					threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

					// setup mutex of storage
				//	strg->setmutex(&strglock);
				//
					// setup mutex of urlddx index before read/write in multithread
					url->setmutex(&urlslock, &urldlock, &urlplock);

					seeder_barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

					seeder_mutex = CBALLOC(pthread_mutex_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

					for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
						seeder_mutex[i] = PTHREAD_MUTEX_INITIALIZER;

					seeder_site_mutex = CBALLOC(pthread_mutex_t, MALLOC, VIRTUAL_INSTANCES);
	
					for (instance_t v = 0; v < VIRTUAL_INSTANCES; v++)
						seeder_site_mutex[v] = PTHREAD_MUTEX_INITIALIZER;

					pthread_barrier_init(seeder_barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

					if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
						die("error setting mutex type %s", strerror(rc));

					if ((rc = pthread_mutexattr_init(&attr)) != 0)
						die("error creating mutex with attributes object %s", strerror(rc));
				}

				for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
				{
					seeder_thread_args_t *args = CBALLOC(seeder_thread_args_t, MALLOC, 1);
				    args->inst = inst;
		    		args->force_start = false;
					args->status = harvest_status;

					if (CONF_COLLECTION_DISTRIBUTED > 1)
					{
						if (pthread_create(&threads[inst], NULL, seeder_thread_function_process_harvest, (void *) args))
							die("error creating thread!");
					}
					else
						seeder_thread_function_process_harvest((void *) args); // only one distribution, function is call without thread 
				}

				if (CONF_COLLECTION_DISTRIBUTED > 1)
				{
					CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

					free(threads);

					// destroy mutex of urlddx index
					url->destroymutex();

					// destroy mutex of storage
				//	strg->destroymutex();

					int rc = 0;

					if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
						die("error destroying mutex with attributes object %s", strerror(rc));

					for (siteid_t v = 0; v < VIRTUAL_INSTANCES; v++)
						pthread_mutex_destroy(&(seeder_site_mutex[v]));

					free(seeder_site_mutex); seeder_site_mutex = NULL;

					for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
						pthread_mutex_destroy(&(seeder_mutex[inst]));

					free(seeder_mutex); seeder_mutex = NULL;

					pthread_barrier_destroy(seeder_barrier);

					free(seeder_barrier); seeder_barrier = NULL;
				}

				harv->dump_status(false);

				if (thread_alarm != THREADS_OK) cbot_stop(1);

				// Log
				syslog(LOG_NOTICE, "seeder readed links from harvest %u", i);

				// Remove files if necessary. Do not use harvester->id here,
				// as it might be removed
				if (CONF_SEEDER_REMOVESOURCE != 0)
				{
					cerr << "Remove harvest " << i << endl;
					harv->hv_remove_files(i);

					if (thread_alarm != THREADS_OK) cbot_stop(1);
				}
			}

			harv->hv_close();

			if (thread_alarm != THREADS_OK) cbot_stop(1);
		}
	}

	meta->dump_status();

	if (site_locked_list)
	{
		free (site_locked_list);
		site_locked_list = NULL;
	}

	if (site_count_doc)
	{
		free (site_count_doc);
		site_count_doc = NULL;
	}

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}
}

// threads sync
void seeder_sync_threads(pthread_barrier_t *barrier)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc = pthread_barrier_wait(barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
        pthread_exit(NULL);
}

// Functions to lock/unlock mutexes

//
// Description: lock mutex
//
// Input: The instance of duplicates
//
// Return:
//
void seeder_lock_linkidx(instance_t &inst)
{
	int rc = 0;

	if (seeder_mutex)
		if ((rc = pthread_mutex_lock(&(seeder_mutex[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

//
// Description: unlock mutex
//
// Input: The instance of duplicates
//
// Return:
//
void seeder_unlock_linkidx(instance_t &inst)
{
	int rc = 0;

	if (seeder_mutex)
		if ((rc = pthread_mutex_unlock(&(seeder_mutex[inst]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
}

//
// Description: lock mutex
//
// Input: The siteid
//
// Return:
//
void seeder_lock_metaddx_site(siteid_t &siteid)
{
	int rc = 0;

	if (seeder_site_mutex)
		if ((rc = pthread_mutex_lock(&(seeder_site_mutex[((siteid - 1) % VIRTUAL_INSTANCES)]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

//
// Description: unlock mutex
//
// Input: The siteid
//
// Return:
//
void seeder_unlock_metaddx_site(siteid_t &siteid)
{
	int rc = 0;

	if (seeder_site_mutex)
		if ((rc = pthread_mutex_unlock(&(seeder_site_mutex[((siteid - 1) % VIRTUAL_INSTANCES)]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

//
// Name: seeder_thread_function_process_harvest
// 
// Description:
//   Extracts unseen urls from the links of a harvest
//
// Input: pointer to void
//
// Return:
//
void *seeder_thread_function_process_harvest(void *args)
{
try
{
	seeder_thread_args_t *arguments = (seeder_thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	bool force_start = arguments->force_start;
	harvest_status_t harvest_status = arguments->status;

	if (site_count_doc)
		site_count_doc[inst] = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_MAXSITE);

	int rc = 0;

	errno = 0; // errno is thread-local

	// Prepare SemaphorePrint for next outputs
	sp->reset(inst);

	// Files
	FILE *input_file = NULL;
	FILE *output_file = NULL;
	char input_filename[MAX_STR_LEN];
	char output_filename[MAX_STR_LEN];

	if (harvest_status != STATUS_HARVEST_EMPTY) assert(harvest_status == STATUS_HARVEST_DONE || harvest_status == STATUS_HARVEST_SEEDED);

	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_HARVEST, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);

	ccerr << "Opening input files ... " << endl;

	seeder_sync_threads(seeder_barrier);

	if (harvest_status == STATUS_HARVEST_EMPTY)
	{
		assert(strlen(opt_start_urls) > 0);
		sprintf(input_filename, "%s", opt_start_urls);
		input_file = fopen64(input_filename, "r");

		if (errno != 0)
			die("Seeder: error opening start file %s", cberr());

		if (input_file == NULL)
			die("Seeder: error opening start file");

		seeder_sync_threads(seeder_barrier);

		ccerr << "start_file ok. " << endl;

		sprintf(output_filename, "/dev/null");
		output_file = fopen64(output_filename, "w");

		if (errno != 0)
			die("Seeder: error opening null resolved file %s", cberr());

	//	if (output_file)
	//		die("Seeder: error opening null resolved file");

		seeder_sync_threads(seeder_barrier);
	}
	else
	{
		// Open output files for saving links
		sprintf(input_filename, "%s/%s/%d/%s", relative_rem_path, COLLECTION_LINK, ACT_HARVESTER_ID, FILENAME_LINKS_DOWNLOAD);
		input_file = fopen64(input_filename, "r");

		if (errno != 0)
			die("Seeder: error opening downloads file %s", cberr());

		if (input_file == NULL)
			die("Seeder: error opening downloads file");

		seeder_sync_threads(seeder_barrier);
    	    

		ccerr << "links_download ok. " << endl;

		sprintf(output_filename, "%s/%s/%d/%s", relative_rem_path, COLLECTION_LINK, ACT_HARVESTER_ID, FILENAME_RESOLVED_LINKS);
		output_file = fopen64(output_filename, "w");

		if (errno != 0)
			die("Seeder: error opening resolved file %s", cberr());

		seeder_sync_threads(seeder_barrier);
    	    
	}

	// Show legend
	if (sp->go_ahead(inst) == true)
	{
		cerr << "resolved_links ok." << endl;
		seeder_show_legend();
	}

	seeder_sync_threads(seeder_barrier);
   	    

	// Line counter, for reporting
	unsigned int line_number = 0;
	char *line = NULL; // memory allocation is done by getline function

	// Outlink_list
	unsigned int adjacency_list_length = 0;
	out_link_t *adjacency_list = CBALLOC(out_link_t, CALLOC, LINK_MAX_OUTDEGREE);

	// Source document
	doc_t	src_doc;
	src_doc.docid = (docid_t)0;
	src_doc.depth = 0;
	char src_path[MAX_STR_LEN];
	docid_t src_docid;

	// Siteid cache
	site_t site_cache;
	site_cache.siteid = 0;
	site_cache.domainid = 0;
	size_t linelen = 0;

	// Readed _url
	char _url[MAX_STR_LEN];
	char caption[MAX_STR_LEN];
	char path_buffer[MAX_STR_LEN];

	//Readed link info
	int rel_pos;
	int tag;
	int caption_length;

	// Read lines from input file
	while (getline(&line, &linelen, input_file) != -1 && thread_alarm == THREADS_OK)
	{
		// If start file must be readed, input_file is only one and each thread skip lines relative others threads
		if (force_start == true && (line_number % CONF_COLLECTION_DISTRIBUTED) != inst)
		{
			processed_lines++;
			line_number++;
			continue;
		}

		// Report
		processed_lines++;
		line_number++;

		// Note in harvest
		if (harvest_status != STATUS_HARVEST_EMPTY) harv->hv_incr_link_total(inst);

		// Format of input lines: (docid link caption)

		_url[0] = '\0';
		caption[0] = '\0';
		src_docid = 0;

		if (!(
			(sscanf(line, "%llu %d %d %s %[^\n]", (unsigned long long int *)((docid_t *)&(src_docid)), &rel_pos, &tag, _url, caption) == 7) ||
			(sscanf(line, "%llu %d %d %s %[^\n]", (unsigned long long int *)((docid_t *)&(src_docid)), &rel_pos, &tag, _url, caption) == 5) || 
			(sscanf(line, "%llu %d %d %s", (unsigned long long int *)((docid_t *)&(src_docid)), &rel_pos, &tag, _url) == 4) ||
			(sscanf(line, "%s %s", _url, caption) == 2) ||
			(sscanf(line, "%s", _url) == 1)))
		{
			pthread_mutex_lock(console_lock);

			processed_lines++;
			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0) // si può(e si forse si può...) migliorare...
				cerr << endl << LINE_NUMBER << RED << " !"; // Malformed
			else
				cerr << RED << '!'; // Malformed

			cerr << NOR;

			pthread_mutex_unlock(console_lock);
			
			continue;
		}
		caption_length = strlen(caption);

		// Check length of everything
		if (strlen(_url) >= MAX_STR_LEN || strlen(caption) >= MAX_STR_LEN)
		{
			pthread_mutex_lock(console_lock);

			processed_lines++;
			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0) // si può(e si forse si può...) migliorare...
				cerr << endl << LINE_NUMBER << RED << " !"; // Malformed
			else
				cerr << RED << '!'; // Malformed

			cerr << NOR;

			pthread_mutex_unlock(console_lock);
			
			continue;
		}

		// Check URL for strange characters, all the
		// URL at least has to be printable
		if (has_nonprintable_characters(_url))
		{
			pthread_mutex_lock(console_lock);

			processed_lines++;
			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0) // si può(e si forse si può...) migliorare...
				cerr << endl << LINE_NUMBER << RED << " !"; // Malformed
			else
				cerr << RED << '!'; // Malformed

			cerr << NOR;

			pthread_mutex_unlock(console_lock);
			
			continue;
		}

		// Check if the source docid changed
		if (src_docid != src_doc.docid) {

			// It's a different docid, save current adjacency list if the list has elements.
			instance_t linkidx_section = ((src_doc.docid - 1) % CONF_COLLECTION_DISTRIBUTED);

			if (adjacency_list_length > 0)
			{
				seeder_lock_linkidx(linkidx_section);

				// It has elements, save
				seeder_save_links(&(src_doc), adjacency_list, adjacency_list_length);

				// Clean adjacency list
				adjacency_list_length = 0;

				seeder_unlock_linkidx(linkidx_section);
			}

			// Retrieve the new src_doc
			src_doc.docid = src_docid;

			// Check if it's 0
			if (src_doc.docid != (docid_t)0)
			{

				// It's a real docid, not a 0
				metaddx_status_t rc = meta->doc_retrieve(&(src_doc));

				if (rc != METADDX_OK)
					die("DocID %llu not found!\nOffending line: %s\nSeeder: link from unknown document seen", src_docid, line);

				// Retrieve the new src_doc path
				// TODO path_by_docid dovrebbe essere OK ma dopo modifiche ad Urlddx.cpp meglio tenerlo a bada (19/06/2017)
				url->path_by_docid(src_doc.docid, src_path);

				assert(src_path); // solo per testing

				if (src_path == NULL)
					die("Seeder: 'path_by_docid' function returning null source path for docid %llu.", (unsigned long long int)src_doc.docid);

				// Sometimes there is an inconsistency
				// (can't find it yet) that puts a 
				// leading ASCII_SL on the path_file
				if (src_path[0] == ASCII_SL)
				{
					pthread_mutex_lock(console_lock);

					processed_lines++;
					LINE_NUMBER++;

					if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0) // si può(e si forse si può...) migliorare...
						cerr << endl << LINE_NUMBER << RED << " !"; // Malformed
					else
						cerr << RED << '!'; // Malformed

					cerr << NOR;

					pthread_mutex_unlock(console_lock);
			
					continue;
				}
			}
			else
			{
				// It's a 0 docid
				src_path[0] = '\0';
			}
		}

		// Check depth
		if ((src_doc.docid > 0) && (src_doc.depth >= (src_doc.is_dynamic ? CONF_MANAGER_MAXDEPTH_DYNAMIC : CONF_MANAGER_MAXDEPTH_STATIC)))
		{
			pthread_mutex_lock(console_lock);

			processed_lines++;
			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << " H";
			else
				cerr << "H";

			pthread_mutex_unlock(console_lock);
			
			continue;
		}

		// Check if it's not a duplicate
		if ((src_doc.docid > 0) && ( src_doc.duplicate_of != (docid_t)0)) 
		{
			pthread_mutex_lock(console_lock);

			processed_lines++;
			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << " C"; // We don't include pages from duplicate documents
			else
				cerr << "C"; // We don't include pages from duplicate documents

			pthread_mutex_unlock(console_lock);
			
			continue;
		}

		// Resolve the link
		docid_t dest = seeder_resolve_link(inst, &(src_doc), src_path, _url, caption, path_buffer, &site_cache, harvest_status);

		// Go to adjacency list
		if ((src_doc.docid > (docid_t)0) && (dest > (docid_t)0))
		{
			// Write result
			if (caption[0] != '\0')
				fprintf(output_file, "%lu %s\n", (unsigned long int)dest, caption);

			// Append to adjacency list; we will check if the
			// link already exists, or if its a self-link
			if (adjacency_list_length < (LINK_MAX_OUTDEGREE - 1))
			{
				if (src_doc.docid != dest)
				{
					// This is not a self link
					// See if this is a repeated link
					bool is_repeated	= false;

					for(unsigned int i = 0; i < adjacency_list_length; i++)
						if (adjacency_list[i].dest == dest)
						{
							is_repeated	= true;
							break;
						}

					if (is_repeated == false)
					{
						unsigned int offset = adjacency_list_length;

						// This is not a repeated link
						adjacency_list[offset].dest = dest;
						adjacency_list[offset].rel_pos = (char)rel_pos;
						adjacency_list[offset].tag = (char)tag;
						adjacency_list[offset].anchor_length = caption_length;
						adjacency_list_length++;
					}
				}
			}
		}
	} // Next line

	// If there are still elements to save, save them
	instance_t linkidx_section = ((src_doc.docid - 1) % CONF_COLLECTION_DISTRIBUTED);

	if (adjacency_list_length > 0)
	{
		seeder_lock_linkidx(linkidx_section);

		seeder_save_links(&(src_doc), adjacency_list, adjacency_list_length);

		seeder_unlock_linkidx(linkidx_section);

		// Clean adjacency list
		adjacency_list_length = 0;
	}

	// Lock last unlocked mutex 
	if (site_locked_list && site_locked_list[inst].siteid > 0)
	{
		if (site_count_doc == NULL) // store preview site
		{
			assert(site_cache.siteid == site_locked_list[inst].siteid);
			assert(site_cache.domainid == site_locked_list[inst].domainid);

			// store preview site structure if something is changed 
			if (memcmp(&site_locked_list[inst], &site_cache, sizeof(site_t)) != 0)
				meta->site_store(&site_cache);
		}

		seeder_unlock_metaddx_site(site_locked_list[inst].siteid);
		site_locked_list[inst].siteid = 0;
	}

	seeder_sync_threads(seeder_barrier);

	if (harvest_status == STATUS_HARVEST_EMPTY)
	{
		ccerr << " " << ((processed_lines / CONF_COLLECTION_DISTRIBUTED) + (processed_lines % CONF_COLLECTION_DISTRIBUTED)) << " done." << endl;
	}
	else
	{
		ccerr << " " <<  processed_lines << " done." << endl;
	}

	// Free memory
	if (site_count_doc && site_count_doc[inst])
	{
		free(site_count_doc[inst]);
		site_count_doc[inst] = NULL;
	}

	free(adjacency_list);

	free(line); // valgrind non 'vede' la liberazione...

	// Mark as seeded
	if (harvest_status != STATUS_HARVEST_EMPTY) harv->seeded(inst, seeder_barrier);

	// Close
	rc = fclose(input_file);

	if (errno != 0)
		die("Seeder: couldn't close start file %s", cberr());

	if (rc != 0)
		die("Seeder: couldn't close start file (%d)", rc);

	fclose(output_file);

	if (errno != 0)
		die("Seeder: couldn't close resolved file %s", cberr());

	if (rc != 0)
		die("Seeder: couldn't close resolved file (%d)", rc);

	// We could discard here 'input_filename' using unlink(), but we will need it for the analysis program :-(

	free(relative_rem_path);

	free(args);

	// need for syncronize exceptions without caller
	seeder_sync_threads(seeder_barrier);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(seeder_barrier);
}
}

//
// Name: seeder_init_maps
// 
// Description:
//   Initialize a series of maps used by the seeder parser
//   These maps are:
//    accept_protocol - Protocols accepted (ie: html)
//    extensions_ignores - Known non-text extensions (ie: jpg)
//

void seeder_init_maps() {
	cerr << "Initializing ... ";

	// create perfect hash for domainid

	cerr << "[keep_special] ";
	keep_special.check_matches = true;
	perfhash_create(&(keep_special), CONF_COLLECTION_IT_SPECIAL_DOMAINS);

	cerr << "[accept_protocol] ";
	accept_protocol.check_matches = true;
	perfhash_create(&(accept_protocol), CONF_SEEDER_LINK_ACCEPT_PROTOCOL);

	cerr << "[extensions_ignore] ";
	extensions_ignore.check_matches = true;
	perfhash_create(&(extensions_ignore), CONF_SEEDER_LINK_EXTENSIONS_IGNORE);

	cerr << "[dynamic extension] ";
	extensions_dynamic.check_matches = true;
	perfhash_create(&(extensions_dynamic), CONF_SEEDER_LINK_DYNAMIC_EXTENSION);

	cerr << "[domain suffixes] ";
	domain_suffixes = string_list_create(CONF_SEEDER_LINK_ACCEPT_DOMAIN_SUFFIXES);

	cerr << "[reject patterns] ";
	tokenizeToRegex(CONF_SEEDER_REJECTPATTERNS, &reject_patterns);

	cerr << "[sessionid variables] ";
	char sessionids_cpy[MAX_STR_LEN];
	assert(strlen(CONF_SEEDER_SESSIONIDS) < MAX_STR_LEN);
	strcpy(sessionids_cpy, CONF_SEEDER_SESSIONIDS);
	tokenizeToRegex(sessionids_cpy, &sessionid_patterns);
	sessionid_variables = tokenizeToTable(CONF_SEEDER_SESSIONIDS, &(sessionid_variables_count));

	cerr << "done." << endl;
}

//
// Name: seeder_show_legend
//
// Description:
//   Prints the legend of the seeder to stderr
//

void seeder_show_legend() {
	cerr << "-------------------- LEGEND ---------------------" << endl;
	cerr << "ACCEPT:   " << GRE << '.' << NOR << " new document     " << GRE << '+' << NOR << " new site          "	<< endl;
	cerr << "REJECT:   " << BRO << '_' << NOR << " seen             " << RED << '!' << NOR << " malformed         " << endl;
	cerr << "REJECT:   " << BRO << 'D' << NOR << " domain exception " << RED << 'D' << NOR << " out domain        " << endl;
	cerr << "REJECT:   " << BRO << 'N' << NOR << " adjourn for new site " << endl;
	cerr << "          P Pattern          M too Many pages    "	<< endl;
	cerr << "          E Extension        H protocol not Http "	<< endl;
	cerr << "          H Depth            C link from Copy    " << endl;
	cerr << "-------------------------------------------------" << endl;
}

//
// Name: seeder_resolve_link
//
// Description:
//   Resolves a link to a document id
//
// Input:
//   harvest - the harvester where the link appears
//   src_doc - source document
//   _url - string of the link
//   caption - description of the link
//   path - memory area to save the path
//
docid_t seeder_resolve_link(instance_t &inst, doc_t *src_doc, char *src_path, char *_url, char *caption, char *path, site_t *site, harvest_status_t &harvest_status)
{
	assert(path);

	// Check if we have room for new documents
	if (url->pathcount() >= (docid_t)(CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED))
	{
		pthread_mutex_lock(console_lock);

		LINE_NUMBER++;

		if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
			cerr << endl << LINE_NUMBER << LRE << " M";
		else
			cerr << LRE << "M";

		cerr << NOR;

		pthread_mutex_unlock(console_lock);
			
		return (docid_t)0;
	}

	// Urlindex variables
	urlddx_status_t rc;
	urlddx_status_t drc;

	// Doc, siteid and domainid
	// For the sites we use a cache of one element (the last site)
	docid_t docid;
	bool is_new_site = false;
	protocols_t protocol_type = HTTP;

	// IS_OUT_REDIRECT is ignored because for CBot, redirects are admitted only to know FQDN
	// bool is_out_redirect = false;

	siteid_t siteid = 0;
	siteid_t domainid = 0;

	// se nel file 'tipo start' il sito viene identificato con protocollo HTTPS questi verràdefinitivamente visitato in https
	if (strlen(opt_start_urls) > 0  && strncmp (_url,"https://",8) == 0) protocol_type = HTTPS;

	/* non necessario perchè i tag 'base' vengono gestiti dal gatherer
	* 
	if (!strncasecmp(caption, LINK_CAPTION_BASE_URL, 10)) {
		if (strstr(caption,LINK_CAPTION_BASE_URL))
				strcpy(src_path, strstr(caption,"<BASE-URL>"));
		strcpy(src_path, strstr(caption,LINK_CAPTION_BASE_URL) + 10);
		src_path = strtok (src_path, " ");
	}
	*/

	// Check if the _url includes the '%' character, _urls are stored unescaped
	if (strchr(_url, '%')) normalize_percent_encoding(_url);

	// Delete newlines, these can be escaped using, e.g.: %0A,
	// so they won't be detected by the gatherer
	if (char *ptr = strchr(_url, '\n')) (*ptr) = '\0';

	if (char *ptr = strchr(_url, '\r')) (*ptr) = '\0';

	assert(! (strchr(_url, '\n') || strchr(_url, '\r')));

	url_encode(_url);

	// Check length of _url after encoding
	if (strlen(_url) >= MAX_STR_LEN)
	{
		pthread_mutex_lock(console_lock);

		LINE_NUMBER++;

		if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
			cerr << endl << LINE_NUMBER << RED << " !"; // Malformed
		else
			cerr << RED << '!'; // Malformed

		cerr << NOR;

		pthread_mutex_unlock(console_lock);
			
		return (docid_t)0;
	}

	site_t newsite;

	// Check if the _url has protocol
	if (! url_has_protocol(_url))
	{
		if (src_doc->docid == 0)
		{
			// This can be more serious; abort here
			die("\n*** Url without protocol: '%s'\nThe seeder is reading a file that has errors", _url);

			return (docid_t)0;
		}

		// It doesn't have protocol, it's a local _url
		// from the same site and same second level domainid
		siteid = src_doc->siteid;
		domainid = src_doc->domainid;

		// Check if the link starts with a ASCII_SL
		if (_url[0] == ASCII_SL)
		{
			assert(strlen(_url) < MAX_STR_LEN);
			strcpy(path, _url); // It's an absolute _url, copy as-is
		}
		else
		{
			// Relative URL, this have to be converted
			url->relative_path_to_absolute(src_path, _url, path);
		}

		url_adjust_path(path);

		//********************
		//author heitor@nic.br
		//verify if the site belongs to the domain.
		//if the site isn't new and don't belongs to the domain, it means it was included by a redirect that only
		//the first page must be downloaded.
		char sitename[MAX_DOMAIN_LEN];
		url->site_by_siteid(siteid, sitename);

		assert(sitename);

		if (! string_list_suffix(domain_suffixes, sitename))
		{
			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << BRO << " D"; //this assure other pages from a site besides the redirect target aren't downloaded
			else
				cerr << BRO << "D"; //this assure other pages from a site besides the redirect target aren't downloaded

			cerr << NOR;

			pthread_mutex_unlock(console_lock);
			
			return (docid_t)0;
		}

		// In this point we have a path a domainid and siteid
		assert(siteid > 0);
		assert(siteid < (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));
		assert(domainid > 0);
		assert(domainid <= siteid);
		assert(path);
	}
	else
	{
		// Remote _url
		// It's a _url that has protocol
		url_adjust_path(_url);

		// Parser variables
		char protocol[MAX_STR_LEN];
		char sitename[MAX_DOMAIN_LEN];
		char src_sitename[MAX_DOMAIN_LEN];

		// Parse the input _url
		if (! url->parse_complete_url(_url, protocol, sitename, path))
		{
			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << RED << " !"; // Malformed
			else
				cerr << RED << '!'; // Malformed

			cerr << NOR;

			pthread_mutex_unlock(console_lock);
			
			return (docid_t)0;
		}

		// Check the protocol
		if (! perfhash_check(&(accept_protocol), protocol))
		{
			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << " P"; // Protocol not accepted
			else
				cerr << "P"; // Protocol not accepted

			pthread_mutex_unlock(console_lock);
			
			return (docid_t)0;
		}

		// Check for sitenames that are too short
		if (strlen(sitename) < 3)
		{
			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << RED << " !"; // Malformed
			else
				cerr << RED << '!'; // Malformed

			cerr << NOR;

			pthread_mutex_unlock(console_lock);
			
			return (docid_t)0;
		}

		// Convert the sitename to lowercase
		for (unsigned int i = 0; i < strlen(sitename); i++)
		{
			sitename[i] = tolower(sitename[i]);

			if (! isalnum(sitename[i]) && sitename[i] != '.' && sitename[i] != '-' && sitename[i] != '_')
			{
				pthread_mutex_lock(console_lock);

				LINE_NUMBER++;

				if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
					cerr << endl << LINE_NUMBER << RED << " !"; // Malformed - Site name not acceptable
				else
					cerr << RED << '!'; // Malformed - Site name not acceptable

				cerr << NOR;

				pthread_mutex_unlock(console_lock);

				return (docid_t)0;
			}
		}

		// Check if the site has a normal tld
		char top_level_domain[MAX_STR_LEN];

		url->get_lowercase_extension(sitename, top_level_domain);

		// Check if it has a TLD
		if (strlen(top_level_domain) == 0)
		{
			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << RED << " !"; // Skip: no TLD
			else
				cerr << RED << '!'; // Skip: no TLD

			cerr << NOR;

			pthread_mutex_unlock(console_lock);
			
			return (docid_t)0;
		}

		// Check if the site is not known
		rc = url->resolve_site(sitename, NULL, protocol_type);

		// Why don't we check for the TLD here?
		// Because the site may not match the tld (for instance, if .none
		// was given), but the linked site may be in the list of starting seeds!
		// And in that case we want to save the link anyways
		//********************
		//author heitor@nic.br
		//we check here so we can better evaluate the case of redirect
		//to pages outside the determined domain

		assert(strlen(sitename) > 0);

		if (harvest_status != STATUS_HARVEST_EMPTY)
		{
			// If harvest == NULL then we're reading the starting
			// URLs, in that case we don't look at the domain_suffixes,
			// we accept everything
			// In this case the harvest is not null, let's see if
			// the site has an acceptable pattern

			//********************
			//author heitor@nic.br
			//compares the site with the domain list.
			//Modified to download pages targeted by  redirects.
			//it do not downlaod page from redirects of redirects


			url->site_by_siteid(src_doc->siteid, src_sitename);
			assert(src_sitename);


			if ((! (HTTP_IS_REDIRECT(src_doc->http_status) && string_list_suffix(domain_suffixes, src_sitename))) && (! string_list_suffix(domain_suffixes, sitename)))
			{
				pthread_mutex_lock(console_lock);

				LINE_NUMBER++;

				if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
					cerr << endl << LINE_NUMBER << RED << " D"; // No, it's outside our domain suffixes
				else
					cerr << RED << "D"; // No, it's outside our domain suffixes

				cerr << NOR;

				pthread_mutex_unlock(console_lock);
			
				return (docid_t)0;
			}
//			else
//				is_out_redirect = true; // This option is ignored because for CBot, redirect is admitted only to know FQDN
			//********************
		}


		if (rc == URLDDX_NOT_FOUND)
		{	// It is a new site
			// Check if there are too many sites
			if (url->sitecount() >= (siteid_t)(CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED))
			{
				pthread_mutex_lock(console_lock);

				LINE_NUMBER++;

				if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
					cerr << endl << LINE_NUMBER << LPU << " M";
				else
					cerr << LPU << "M";

				cerr << NOR;

				pthread_mutex_unlock(console_lock);
			
				return (docid_t)0;
			}
			else if (url->pathcount() >= (docid_t)(CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED))
			{
				// A new site could require more documents
				// to be added, check this condition here
				pthread_mutex_lock(console_lock);

				LINE_NUMBER++;

				if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
					cerr << endl << LINE_NUMBER << LRE << " M";
				else
					cerr << LRE << "M";

				cerr << NOR;

				pthread_mutex_unlock(console_lock);
			
				return (docid_t)0;
			}
		}

		// Now in need check also for new special domain
		siteid_t sdomainid = 0;

		// Get the domainid, or create the domain 
		drc = url->resolve_domain(sitename, &(domainid), &(sdomainid), keep_special);

		assert(domainid > 0);

		// Get the siteid, or create the site
		rc = url->resolve_site(sitename, domainid, &(siteid), protocol_type);

		// the hash relative the instance where bucket should be inserted, is full
		if (rc == URLDDX_HASH_FULL)
		{
			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << PUR << " M";
			else
				cerr << PUR << "M";

			cerr << NOR;

			pthread_mutex_unlock(console_lock);
		
			return (docid_t)0;
		}
		else if (rc == URLDDX_FULL)
		{
			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << LPU << " M";
			else
				cerr << LPU << "M";

			cerr << NOR;

			pthread_mutex_unlock(console_lock);

			return (docid_t)0;
		}
		
		assert(drc == URLDDX_CREATED_DOMAIN || drc == URLDDX_EXISTENT);

		if (rc == URLDDX_CREATED_SITE)
		{
			// In this point we have a path a domainid and siteid
			assert(siteid > 0);
			assert(path);

			// It's a new site
			is_new_site = true;

			// Add metadata for this new site
		//	site_t newsite;
			newsite.siteid = siteid;
			meta->site_default(&(newsite));

			if (sdomainid > 0)
				newsite.domainid = sdomainid;
			else
				newsite.domainid = domainid;

			newsite.protocol = protocol_type;
			newsite.count_doc  = 0;

			bool is_guesticon_site = false;
			bool is_guest_site = false;

			if (harvest_status == STATUS_HARVEST_EMPTY)
			{
				size_t GUEST_LEN = strlen("GUEST");
				size_t GUESTICON_LEN = strlen("GUESTICON");

				if (strlen(caption) >= GUESTICON_LEN && caption[GUESTICON_LEN] == ASCII_NUL && strcmp(caption, "GUESTICON") == 0)
						is_guesticon_site = true;
				else if (strlen(caption) >= GUEST_LEN && caption[GUEST_LEN] == ASCII_NUL && strcmp(caption, "GUEST") == 0)
						is_guest_site = true;
			}


/*
			if (protocol_type == HTTPS)
				newsite.https_check = GOOD_HARVESTED; // non è permessa alcuna migrazione da https in http
			else
				newsite.https_check = NOT_HARVESTED; // serve per capire se si può eventualmente migrare su portocollo https

			// Add IP information if possible // TODO deve poter accettare anche indirizzi ipv6
			if (strlen(caption) > 10) // at least IP=1.1.1.1
			{
				if (caption[0] == 'I' && caption[1] == 'P' && caption[2] == '=')
				{
					int rc = inet_aton((char *)(caption+3), &(newsite.addr));

					if (rc == 0)
					{
						pthread_mutex_lock(console_lock);

						LINE_NUMBER++;

						if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
							cerr << endl << LINE_NUMBER << "(wrong IP)";
						else
							cerr << "(wrong IP)";

						pthread_mutex_unlock(console_lock);
					}
					else
					{
						time_t now = time(NULL);
						newsite.last_resolved = now;
					}
				}
			}
*/
		//	meta->site_store(&(newsite));

			// This is the first time this site is seen, check if it's
			// necessary to add other URLs.

			// Add robots.txt if path is different from 'robots.txt'
			if (CONF_SEEDER_ADD_ROBOTSTXT == true) // && strcmp(path, FILENAME_ROBOTS_TXT))
			{
				// Create new document
				doc_t doc;
				meta->doc_default(&(doc));

				// "/" was added, get docid
				rc = url->resolve_path(newsite.siteid, FILENAME_ROBOTS_TXT, &(doc.docid));

				// the path's hash relative the instance where bucket should be inserted, is full
				if (rc == URLDDX_HASH_FULL)
				{
					pthread_mutex_lock(console_lock);

					LINE_NUMBER++;

					if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
						cerr << endl << LINE_NUMBER << RED << " M";
					else
						cerr << RED << "M";

					cerr << NOR;

					pthread_mutex_unlock(console_lock);
	
					return (docid_t)0;
				}
				else if (rc == URLDDX_FULL)
				{
					pthread_mutex_lock(console_lock);

					LINE_NUMBER++;

					if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
						cerr << endl << LINE_NUMBER << LRE << " M";
					else
						cerr << LRE << "M";

					cerr << NOR;

					pthread_mutex_unlock(console_lock);
	
					return (docid_t)0;
				}

				assert(rc == URLDDX_CREATED_PATH);
				assert(doc.docid > src_doc->docid);

				// Save metadata
				doc.siteid = newsite.siteid;
				doc.domainid = newsite.domainid;
				doc.depth  = 1;

//				if (is_out_redirect == true)
//					doc.status = STATUS_DOC_EXCLUSION;

				if (is_guesticon_site == true || is_guest_site == true)
					doc.status = STATUS_DOC_EXCLUSION;

				doc.mime_type	= MIME_ROBOTS_TXT;
				meta->doc_store(&(doc));

				// Mark this document as the robots.txt file
				newsite.docid_robots_txt	= doc.docid;

				// Count this document
				newsite.count_doc++;
			}
		
			// Add sitemap.rdf if path is different from 'sitemap.rdf'
			if (CONF_SEEDER_ADD_ROBOTSRDF == true) // && strcmp(path, FILENAME_ROBOTS_RDF))
			{
				// Create new document
				doc_t doc;
				meta->doc_default(&(doc));

				// "/" was added, get docid
				rc = url->resolve_path(newsite.siteid, FILENAME_ROBOTS_RDF, &(doc.docid));

				// the path's hash relative the instance where bucket should be inserted, is full
				if (rc == URLDDX_HASH_FULL)
				{
					pthread_mutex_lock(console_lock);

					LINE_NUMBER++;

					if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
						cerr << endl << LINE_NUMBER << RED << " M";
					else
						cerr << RED << "M";

					cerr << NOR;

					pthread_mutex_unlock(console_lock);
	
					return (docid_t)0;
				}
				else if (rc == URLDDX_FULL)
				{
					pthread_mutex_lock(console_lock);

					LINE_NUMBER++;

					if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
						cerr << endl << LINE_NUMBER << LRE << " M";
					else
						cerr << LRE << "M";

					cerr << NOR;

					pthread_mutex_unlock(console_lock);
	
					return (docid_t)0;
				}

				assert(rc == URLDDX_CREATED_PATH);
				assert(doc.docid > src_doc->docid);

				// Save metadata
				doc.siteid		= newsite.siteid;
				doc.domainid	= newsite.domainid;
				doc.mime_type	= MIME_ROBOTS_RDF;
				doc.depth  = 1;

//				if (is_out_redirect == true)
//					doc.status = STATUS_DOC_EXCLUSION;

				if (is_guesticon_site == true || is_guest_site == true)
					doc.status = STATUS_DOC_EXCLUSION;

				meta->doc_store(&(doc));

				// Mark this document as the robots.txt file
				newsite.docid_sitemap_rdf	= doc.docid;

				// Count this document
				newsite.count_doc++;
			}
		
			// Add sitemap.xml if path is different from 'sitemap.xml'
			if (CONF_SEEDER_ADD_ROBOTSXML == true) // && strcmp(path, FILENAME_ROBOTS_XML))
			{
				// Create new document
				doc_t doc;
				meta->doc_default(&(doc));

				// "/" was added, get docid
				rc = url->resolve_path(newsite.siteid, FILENAME_ROBOTS_XML, &(doc.docid));

				// the path's hash relative the instance where bucket should be inserted, is full
				if (rc == URLDDX_HASH_FULL)
				{
					pthread_mutex_lock(console_lock);

					LINE_NUMBER++;

					if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
						cerr << endl << LINE_NUMBER << RED << " M";
					else
						cerr << RED << "M";

					cerr << NOR;

					pthread_mutex_unlock(console_lock);
	
					return (docid_t)0;
				}
				else if (rc == URLDDX_FULL)
				{
					pthread_mutex_lock(console_lock);

					LINE_NUMBER++;

					if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
						cerr << endl << LINE_NUMBER << LRE << " M";
					else
						cerr << LRE << "M";

					cerr << NOR;

					pthread_mutex_unlock(console_lock);
	
					return (docid_t)0;
				}

				assert(rc == URLDDX_CREATED_PATH);
				assert(doc.docid > src_doc->docid);

				// Save metadata
				doc.siteid		= newsite.siteid;
				doc.domainid	= newsite.domainid;
				doc.mime_type	= MIME_ROBOTS_XML;
				doc.depth  = 1;

//				if (is_out_redirect == true)
//					doc.status = STATUS_DOC_EXCLUSION;

				if (is_guesticon_site == true || is_guest_site == true)
					doc.status = STATUS_DOC_EXCLUSION;

				meta->doc_store(&(doc));

				// Count this document
				newsite.count_doc++;
			}

			// Add home page if path is different from rootdir
			if (CONF_SEEDER_ADDHOMEPAGE == 1) // && (harvest_status == STATUS_HARVEST_EMPTY || strnlen(path, 1) > 0))
			{
				// Create new document
				doc_t doc;
				meta->doc_default(&(doc));

				// "/" was added, get docid
				rc = url->resolve_path(newsite.siteid, "", &(doc.docid));

				// the path's hash relative the instance where bucket should be inserted, is full
				if (rc == URLDDX_HASH_FULL)
				{
					pthread_mutex_lock(console_lock);

					LINE_NUMBER++;

					if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
						cerr << endl << LINE_NUMBER << RED << " M";
					else
						cerr << RED << "M";

					cerr << NOR;

					pthread_mutex_unlock(console_lock);
	
					return (docid_t)0;
				}
				else if (rc == URLDDX_FULL)
				{
					pthread_mutex_lock(console_lock);

					LINE_NUMBER++;

					if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
						cerr << endl << LINE_NUMBER << LRE << " M";
					else
						cerr << LRE << "M";

					cerr << NOR;

					pthread_mutex_unlock(console_lock);
	
					return (docid_t)0;
				}

				assert(rc == URLDDX_CREATED_PATH);
				assert(doc.docid > src_doc->docid);

				// Save metadata
				doc.siteid = newsite.siteid;
				doc.domainid = newsite.domainid;
				doc.depth  = 1;

//				if (is_out_redirect == true)
//					doc.status = STATUS_DOC_EXCLUSION;

				if (is_guesticon_site == true || is_guest_site == true)
					doc.status = STATUS_DOC_EXCLUSION;

				meta->doc_store(&(doc));

				// Count this document
				newsite.count_doc++;
			}

			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << GRE << " +";
			else
				cerr << GRE << "+";

			cerr << NOR;

			pthread_mutex_unlock(console_lock);

			harv->hv_incr_link_new_sites(inst);

/*			if (is_out_redirect == true)
			{
				metaddx_status_t status = meta->site_option_set(site->siteid, SITE_OPT_GUEST, true);

				assert(status == METADDX_OK);
			} */

			if (is_guesticon_site == true)
			{
				metaddx_status_t status = meta->site_option_set(newsite.siteid, SITE_OPT_GUEST, true);

				assert(status == METADDX_OK);

				status = meta->site_option_set(newsite.siteid, SITE_OPT_GICON, true); // GICON can exist only for guest sites

				assert(status == METADDX_OK);
			}
			else if (is_guest_site)
			{
				metaddx_status_t status = meta->site_option_set(newsite.siteid, SITE_OPT_GUEST, true);

				assert(status == METADDX_OK);
			}

			metaddx_status_t status = meta->site_store(&(newsite));

			assert(status == METADDX_OK);
		}
		else
		{
			// In this point we have a path a domainid and siteid
			assert(siteid > 0);
			assert(path);

			// If marked new for this cicle skip rest of documents
			// because the next step is to read file 'robots.txt' if present
			if (meta->site_option_get(siteid, SITE_OPT_NEW, true) == METADDX_OK)
			{
				if (CONF_SEEDER_ADD_ROBOTSTXT == true)
				{
					pthread_mutex_lock(console_lock);

					LINE_NUMBER++;

					if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
						cerr << endl << LINE_NUMBER << BRO << " N"; // new document with new site, skip to next cicles of harvesting
					else
						cerr << BRO << "N"; // new document with new site, skip to next cicles of harvesting

					cerr << NOR;

					pthread_mutex_unlock(console_lock);
			
					return (docid_t)0;
				}
				else
				{
					// Wait for metaddx site retrieve checking, before site is saved
					while (meta->site_option_get(siteid, SITE_OPT_DENY, true) == METADDX_OK)
						usleep(5);
				}
			}
		}
	}

	// RETRIEVE THE SITE.
	// We have to do this here to
	// check if the website has too many _urls already;
	// because after we have called _urlddx resolve path,
	// we MUST store a document in the metaddx to be
	// consistent.
	metaddx_status_t rc_meta = METADDX_ERROR;

	if (siteid == site->siteid)
		rc_meta = METADDX_OK; // It is the same as the last one, we use the cache
	else
	{
		// It is a new one, but first, stored the prewious
		if (site_count_doc == NULL && site_locked_list[inst].siteid > 0)
		{
			assert(site->siteid == site_locked_list[inst].siteid);
			assert(site->domainid == site_locked_list[inst].domainid);

			// store preview site structure if something is changed 
			if (memcmp(&site_locked_list[inst], site, sizeof(site_t)) != 0)
				meta->site_store(site);
		}

		if (site_locked_list[inst].siteid > 0 && site_locked_list[inst].siteid != siteid)
			seeder_unlock_metaddx_site(site_locked_list[inst].siteid);

		// retrieve other site and if created new, copy the structure
		if (is_new_site == true)
		{
			assert(newsite.siteid > 0);
			assert(newsite.domainid > 0);
			assert(newsite.count_doc > 0);

			memcpy(site, &newsite, sizeof(site_t));
		
			seeder_lock_metaddx_site(site->siteid);

			memcpy(&site_locked_list[inst], site, sizeof(site_t));

			rc_meta = METADDX_OK;
		}
		else
		{
			site->siteid = siteid;
		
			seeder_lock_metaddx_site(site->siteid);

			rc_meta = meta->site_retrieve(site);
		
			memcpy(&site_locked_list[inst], site, sizeof(site_t));
		}

		if (site_count_doc)
		{
			instance_t sinst = ((site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t soffset = ((site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

			// locked only for copy data from site structure the first time 
			if (site_count_doc[sinst][soffset] == 0)
				site_count_doc[sinst][soffset] = site->count_doc;
		}

		assert(rc_meta == METADDX_OK);
	}

	// Check how many documents has this site
	// we do this before starting parsing the path to save time.
	if (site_count_doc)
	{	// On site_t structure, doc counters will be processed and stored by manager program.
		instance_t sinst = ((site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t soffset = ((site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		assert(site_count_doc[sinst][soffset] > 0);

		if (site_count_doc[sinst][soffset] >= CONF_SEEDER_MAX_URLS_PER_SITE)
		{
			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << BRO << " M";
			else
				cerr << BRO << "M";

			cerr << NOR;

			pthread_mutex_unlock(console_lock);
		
			return (docid_t)0;
		}
	}
	else
	{
		assert(site->count_doc > 0);

		if (site->count_doc >= CONF_SEEDER_MAX_URLS_PER_SITE)
		{
			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << BRO << " M";
			else
				cerr << BRO << "M";

			cerr << NOR;

			pthread_mutex_unlock(console_lock);
		
			return (docid_t)0;
		}
	}

	// Remove (potential) leading slash from path
	if (path[0] == ASCII_SL) {

		// Copy to auxiliary var
		char pathcpy[MAX_STR_LEN];
		assert(strlen(path) < MAX_STR_LEN);
		strcpy(pathcpy, path);

		// Skip slashes
		uint last_slash = 0;
		while(last_slash < strlen(_url) &&
			_url[last_slash] == ASCII_SL) {
			last_slash++;
		}

		// copy back
		assert(last_slash > 0);
		assert(strlen(pathcpy + last_slash) < MAX_STR_LEN);
		strcpy(path, pathcpy + last_slash);
	}

	
	// Remove trailing slash from exclusion paths
	if (harvest_status != STATUS_HARVEST_EMPTY && !strcmp(caption,LINK_CAPTION_FORBIDDEN))
	{
		size_t path_len = strlen(path);

		if (path_len > 0 &&	path[path_len - 1] == ASCII_SL)
			path[path_len - 1] = ASCII_NUL;
	}

	// se il path èottenuto da un harvesting precedente, i controlli sottoposti da questa condizione NON vengono effettuati ma se ne occupa a monte il gathering
	if (harvest_status == STATUS_HARVEST_EMPTY) 
	{	// Reject certains paths
	 	if (regexec(&reject_patterns, path, 0, NULL, 0) == 0)
		{	// If new site, set it ready for visits
			if (is_new_site == true)
			{
				metaddx_status_t status = meta->site_option_set(siteid, SITE_OPT_DENY, false);

				assert(status == METADDX_OK);
			}

			pthread_mutex_lock(console_lock);

			LINE_NUMBER++;

			if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
				cerr << endl << LINE_NUMBER << " P";
			else
				cerr << "P";

			pthread_mutex_unlock(console_lock);
		
			return (docid_t)0;
		}

		// Remove sessionids in URLs
		if (regexec(&sessionid_patterns, path, 0, NULL, 0) == 0)
		{
			for (int i = 0; i < sessionid_variables_count; i++)
				url->remove_variable(path, sessionid_variables[i]);
		}

		// Remove sessionids, heuristic
		url->remove_sessionids_heuristic(path);
	}

	// Sanitize the URL
	url->sanitize_url(path);

	// Resolve
	assert(path[0] != ASCII_SL);

	// Skip silently home page and other special pages because previous created during the creation of site on collection
	if (path[0] == ASCII_NUL ||
		(strnlen(path, (FILENAME_ROBOTS_TXT_LEN + 1)) == FILENAME_ROBOTS_TXT_LEN && strcasecmp(path, FILENAME_ROBOTS_TXT) == 0) ||
		(strnlen(path, (FILENAME_ROBOTS_RDF_LEN + 1)) == FILENAME_ROBOTS_RDF_LEN && strcasecmp(path, FILENAME_ROBOTS_RDF) == 0) ||
		(strnlen(path, (FILENAME_ROBOTS_XML_LEN + 1)) == FILENAME_ROBOTS_XML_LEN && strcasecmp(path, FILENAME_ROBOTS_XML) == 0))
	{	// If new site, set it ready for visits
		if (is_new_site == true)
		{
			metaddx_status_t status = meta->site_option_set(siteid, SITE_OPT_DENY, false);

			assert(status == METADDX_OK);
		}

		return (docid_t)0;
	}

	// If robots.txt are disabled accept all other pages
	if (CONF_SEEDER_ADD_ROBOTSTXT == false)
		rc = url->resolve_path(siteid, path, &docid);
	else if (meta->site_option_get(siteid, SITE_OPT_NEW, true) == METADDX_OK)
	{	// If robots.txt are enables and is first visit on site skip other pages but if new site, set it ready for visits
		if (is_new_site == true)
		{
			metaddx_status_t status = meta->site_option_set(siteid, SITE_OPT_DENY, false);

			assert(status == METADDX_OK);
		}

		pthread_mutex_lock(console_lock);

		LINE_NUMBER++;

		if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
			cerr << endl << LINE_NUMBER << BRO << " N"; // new document with new site, skip to next cicles of harvesting
		else
			cerr << BRO << "N"; // new document with new site, skip to next cicles of harvesting

		cerr << NOR;

		pthread_mutex_unlock(console_lock);

		return (docid_t)0;
	}
	else
		rc = url->resolve_path(siteid, path, &docid);

	// If new site, set it ready for visits
	if (is_new_site == true)
	{
		metaddx_status_t status = meta->site_option_set(siteid, SITE_OPT_DENY, false);

		assert(status == METADDX_OK);
	}

	// the path's hash relative the instance where bucket should be inserted, is full
	if (rc == URLDDX_HASH_FULL)
	{
		pthread_mutex_lock(console_lock);

		LINE_NUMBER++;

		if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
			cerr << endl << LINE_NUMBER << RED << " M";
		else
			cerr << RED << "M";

		cerr << NOR;

		pthread_mutex_unlock(console_lock);
	
		return (docid_t)0;
	}
	else if (rc == URLDDX_FULL)
	{
		pthread_mutex_lock(console_lock);

		LINE_NUMBER++;

		if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
			cerr << endl << LINE_NUMBER << LRE << " M";
		else
			cerr << LRE << "M";

		cerr << NOR;

		pthread_mutex_unlock(console_lock);

		return (docid_t)0;
	}

	bool store_doc = false;

	doc_t doc;

	// New URL
	if (rc == URLDDX_CREATED_PATH)
	{
		assert(docid > src_doc->docid);

		# ifdef DEBUG
		// TODO multithread testing remove after testing...
		docid_t my_docid = 0;
		rc = url->resolve_path(siteid, path, &(my_docid));
		assert (rc == URLDDX_EXISTENT);
		assert (my_docid == docid);
		// end
		#endif

		// Increase siteid

		if (site_count_doc)
		{
			instance_t sinst = ((site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t soffset = ((site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);
			site_count_doc[sinst][soffset]++; // volatile data, not stored
		}
		else
			site->count_doc++;

		// Store site
		assert(site->siteid > 0);
		assert(site->siteid < (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));

		// Create a new record
		meta->doc_default(&(doc));

		// Data
		doc.is_dynamic = url->is_dynamic(&(extensions_dynamic), path);
		doc.docid  = docid;		// Returned by _urlddx resolve_path
		doc.siteid = siteid;
		doc.domainid = domainid;
		doc.depth  = src_doc->depth + 1;

		// TODO path now are excluded during harvesting
		// THIS IS OBSOLETE and is commented
		/*
		// Check robots.txt information
		// Exclusion paths are reported by the gatherer
		// as a link with a special caption = LINK_CAPTION_FORBIDDEN
		// e.g.:
		//    cgi-bin/ <FORBIDDEN>
		// means that all the content of that directory must be
		// kept off-limits.

		if (!strcmp(caption,LINK_CAPTION_FORBIDDEN)) {

			assert(src_doc->mime_type == MIME_ROBOTS_TXT);

			// This is an exclusion path, that was
			// readed from a robots.txt file
			// Mark this document as excluded
			doc.status			= STATUS_DOC_EXCLUSION;

			metaddx_status_t status = meta->site_option_set(site->siteid, SITE_OPT_VRTXT, true);
			assert(status == METADDX_OK);

		} else if (site->has_valid_robots_txt && seeder_is_excluded(&(doc), path)) {
			// This document must be excluded, because
			// its a sub-directory of an exclusion path
			doc.status = STATUS_DOC_EXCLUSION;
		}
		*/

		// Store
		store_doc = true;

		pthread_mutex_lock(console_lock);

		LINE_NUMBER++;

		if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
			cerr << endl << LINE_NUMBER << GRE << " .";
		else
			cerr << GRE << ".";

		cerr << NOR;

		pthread_mutex_unlock(console_lock);

		harv->hv_incr_link_new_pages(inst);

		// Copy docid // a me sembra inutile
	//	docid = doc.docid;

	}
	else if (rc == URLDDX_EXISTENT)
	{
		// Suppose we have A->B, and B exists.
		// Here we could update the depth of B, if it have
		// become smaller (i.e. we had find a shortest route),
		// BUT in that case we should
		// also update the depth of the pages that are
		// pointed by B, so we prefer not to do this.

		// The analysis program has an option for fixing depths

		// Report as 'seen'
		pthread_mutex_lock(console_lock);

		LINE_NUMBER++;

		if ((LINE_NUMBER % SEEDER_PAGE_WIDTH) == 0)
			cerr << endl << LINE_NUMBER << BRO << " _";
		else
			cerr << BRO << "_";

		cerr << NOR;

		pthread_mutex_unlock(console_lock);
	
		// TODO path now are excluded during harvesting
		// THIS IS OBSOLETE and is commented
		/*
		// Maybe this was an exclusion path for a URL we've
		// already seen
		if (!strcmp(caption,LINK_CAPTION_FORBIDDEN)) {

			assert(src_doc->mime_type == MIME_ROBOTS_TXT);

			// This is an exclusion path, that was
			// readed from a robots.txt file, but the URL
			// has been seen before
			doc.docid	= docid;
			meta->doc_retrieve(&(doc));
			assert(doc.docid == docid);

			// Mark this document as excluded
			doc.status			= STATUS_DOC_EXCLUSION;

			metaddx_status_t status = meta->site_option_set(site->siteid, SITE_OPT_VRTXT, true);
			assert(status == METADDX_OK);

			// Store
			store_doc = true;
		}
		*/

		if (harvest_status != STATUS_HARVEST_EMPTY) harv->hv_incr_link_old_pages(inst);

		// TODO path now are excluded during harvesting
		// THIS IS OBSOLETE and is commented
		//meta->site_store(site);

		// Se il link ricevuto attraverso il file 'links_download.txt' appartiene ad un documento con questi 'mimetype',
		// viene escluso dalla messa in coda di harvesting. Tali documenti infatti sono gestiti differentemente dal crawler.
		// Nel caso un documento nuovo con nome sitemap.xml piuttosto che robots.txt fosse inserito in tale file,
		// questi verrebbe interpretato come un file normale.
		// I mimetype tipo 'robots' vengono riconosciuti dal crawler attraverso altre procedimenti e identificati
		// come tali una sola volta quando ancora non presenti in indice.
		if (store_doc == true &&
			(doc.mime_type == MIME_ROBOTS_TXT ||
			doc.mime_type == MIME_ROBOTS_RDF ||
			doc.mime_type == MIME_ROBOTS_XML ||
			doc.mime_type == MIME_ROBOTS_XML_GZ ||
			doc.mime_type == MIME_ROBOTS_RDF_BROKEN ||
			doc.mime_type == MIME_ROBOTS_XML_BROKEN))
		{
			meta->doc_store(&(doc));
			return docid;
		}
	}
	else
	{
		die("Unexpected response from urlddx resolver");

		return (docid_t)0;
	}

	if (CONF_SEEDER_ADD_FEEDSXML == true && strlen(caption) >= strlen(LINK_CAPTION_ATOM_FEED) && !strncmp(caption,LINK_CAPTION_ATOM_FEED,strlen(LINK_CAPTION_ATOM_FEED)))
	{
		// Check sitemap.xml/gz path of sitemap index or robots.txt, in this case, we use
		// a special caption for last modified date.
		// e.g.:
		//    http://www.site.com/news/list.xml.gz <ATOF> 0
		// In which the second number is the last modified date
		// informed in the robots.txt file

		if (store_doc == false)
		{
			doc.docid = docid;
			meta->doc_retrieve(&(doc));
			assert(doc.docid == docid);
		}

		if (doc.duplicate_of > 0) // una volta che un documento diventa duplicato di un altro, inutile assegnarli ulteriori 'changefreq', 'priority' ecc...
		{
			if (store_doc == true)
				meta->doc_store(&(doc));

			return docid;
		}

		// Advance special caption "<ATOF>"
		caption += strlen(LINK_CAPTION_ATOM_FEED);

		// Advance whitespace
		while (isspace(*caption)) 
			caption++;

		mime_type_t old_mimetype = doc.mime_type;

		if (caption[0] == '1')
			doc.mime_type = MIME_FEEDS_ATOM_XML_GZ;
		else
			doc.mime_type = MIME_FEEDS_ATOM_XML;

		if (doc.mime_type != old_mimetype)
			store_doc = true;
	}
	else if (CONF_SEEDER_ADD_FEEDSXML == true && strlen(caption) >= strlen(LINK_CAPTION_RSS_FEED) &&
			!strncmp(caption,LINK_CAPTION_RSS_FEED,strlen(LINK_CAPTION_RSS_FEED)))
	{
		// Check sitemap.xml/gz path of sitemap index or robots.txt, in this case, we use
		// a special caption for last modified date.
		// e.g.:
		//    http://www.site.com/news/list.xml.gz <ATOF> 0
		// In which the second number is the last modified date
		// informed in the robots.txt file

		if (store_doc == false)
		{
			doc.docid = docid;
			meta->doc_retrieve(&(doc));
			assert(doc.docid == docid);
		}

		if (doc.duplicate_of > 0) // una volta che un documento diventa duplicato di un altro, inutile assegnarli ulteriori 'changefreq', 'priority' ecc...
		{
			if (store_doc == true)
				meta->doc_store(&(doc));

			return docid;
		}

		// Advance special caption "<RSSF>"
		caption += strlen(LINK_CAPTION_RSS_FEED);

		// Advance whitespace
		while (isspace(*caption)) 
			caption++;

		mime_type_t old_mimetype = doc.mime_type;

		if (caption[0] == '1')
			doc.mime_type = MIME_FEEDS_RSS_XML_GZ;
		else
			doc.mime_type = MIME_FEEDS_RSS_XML;

		if (doc.mime_type != old_mimetype)
			store_doc = true;
	}
	else if (CONF_SEEDER_ADD_ROBOTSXML == true && strlen(caption) >= strlen(LINK_CAPTION_SITEMAP) &&
			!strncmp(caption,LINK_CAPTION_SITEMAP,strlen(LINK_CAPTION_SITEMAP)))
	{
		// Check sitemap.xml/gz path of sitemap index or robots.txt, in this case, we use
		// a special caption for last modified date.
		// e.g.:
		//    http://www.site.com/news/list.xml.gz <SMAP> 0 <LMOD> 133569636
		// In which the second number is the last modified date
		// informed in the robots.txt file

		if (store_doc == false)
		{
			doc.docid = docid;
			meta->doc_retrieve(&(doc));
			assert(doc.docid == docid);
		}

		if (doc.duplicate_of > 0) // una volta che un documento diventa duplicato di un altro, inutile assegnarli ulteriori 'changefreq', 'priority' ecc...
		{
			if (store_doc == true)
				meta->doc_store(&(doc));

			return docid;
		}

		// Advance special caption "<SMAP>"
		caption += strlen(LINK_CAPTION_SITEMAP);

		// Advance whitespace
		while (isspace(*caption)) 
			caption++;

		mime_type_t old_mimetype = doc.mime_type;

		if (caption[0] == '1')
			doc.mime_type = MIME_ROBOTS_XML_GZ;
		else
			doc.mime_type = MIME_ROBOTS_XML;

		if (doc.mime_type != old_mimetype)
			store_doc = true;

		// Advance from character readed
			caption++;

		// Advance whitespace
		while (isspace(*caption)) 
			caption++;
			
		if (strlen(caption) > strlen(LINK_CAPTION_LAST_MODIFIED) && !strncmp(caption,LINK_CAPTION_LAST_MODIFIED,strlen(LINK_CAPTION_LAST_MODIFIED))) {

			// Advance special caption "<LMOD>"
			caption += strlen(LINK_CAPTION_LAST_MODIFIED);

			// Advance whitespace
			while (isspace(*caption))
				caption++;

			// Copy date
			time_t now = time(NULL);
			time_t last_modified = atol(caption);

			if (last_modified > doc.last_modified && last_modified < now)
			{
				doc.last_modified = last_modified;
				doc.abs_last_modified = true;
				store_doc = true;
			}
		}
	}
	else if (strlen(caption) > strlen(LINK_CAPTION_LAST_MODIFIED) && !strncmp(caption,LINK_CAPTION_LAST_MODIFIED,strlen(LINK_CAPTION_LAST_MODIFIED)))
	{
		// Check sitemap.rdf information, in this case, we use
		// a special caption for last modified date.
		// e.g.:
		//    news/new_item.html <LMOD> 1079473183
		// In which the second number is the last modified date
		// informed in the robots.txt file

		if (store_doc == false)
		{
			doc.docid = docid;
			meta->doc_retrieve(&(doc));
			assert(doc.docid == docid);
		}

		if (doc.duplicate_of > 0) // una volta che un documento diventa duplicato di un altro inutile assegnarli ulteriori 'changefreq', 'priority' ecc...
		{
			if (store_doc == true)
				meta->doc_store(&(doc));

			return docid;
		}

		// Advance special caption "<LMOD>"
		caption += strlen(LINK_CAPTION_LAST_MODIFIED);

		// Advance whitespace
		while (isspace(*caption)) {
			caption++;
		}


		// Copy date
		time_t now = time(NULL);
		time_t last_modified = atol(caption);

		if (last_modified > doc.last_modified && last_modified < now)
		{
			doc.last_modified = last_modified;
			doc.abs_last_modified = true;

			if (doc.from_feed == true)
				doc.from_feed = false;

			store_doc = true;
		}
	}
	else if (strlen(caption) > strlen(LINK_CAPTION_NEWS_LAST_MODIFIED) && !strncmp(caption,LINK_CAPTION_NEWS_LAST_MODIFIED,strlen(LINK_CAPTION_NEWS_LAST_MODIFIED)))
	{
		// Check sitemap.rdf information, in this case, we use
		// a special caption for last modified date.
		// e.g.:
		//    section/new_item.html <LMOD> 1079473183
		// In which the second number is the last modified date
		// informed in the robots.txt file

		if (store_doc == false)
		{
			doc.docid = docid;
			meta->doc_retrieve(&(doc));
			assert(doc.docid == docid);
		}

		if (doc.duplicate_of > 0 ||
			doc.mime_type == MIME_FEEDS_ATOM_XML ||
			doc.mime_type == MIME_FEEDS_ATOM_XML_GZ ||
			doc.mime_type == MIME_FEEDS_ATOM_XML_BROKEN ||
			doc.mime_type == MIME_FEEDS_RSS_XML ||
			doc.mime_type == MIME_FEEDS_RSS_XML_GZ ||
			doc.mime_type == MIME_FEEDS_RSS_XML_BROKEN) // una volta che un documento diventa duplicato di un altro inutile proseguire
		{
			if (store_doc == true)
				meta->doc_store(&(doc));

			return docid;
		}

		// Advance special caption "<NLMOD>"
		caption += strlen(LINK_CAPTION_NEWS_LAST_MODIFIED);

		// Advance whitespace
		while (isspace(*caption)) {
			caption++;
		}


		// Copy date
		time_t now = time(NULL);
		time_t last_modified = atol(caption);

		if (last_modified > doc.last_modified && last_modified < now)
		{
			doc.last_modified = last_modified;
			doc.from_feed = true;
			doc.abs_last_modified = true;
			store_doc = true;
		}

		if (last_modified == doc.last_modified && doc.from_feed == false)
		{
			doc.from_feed = true;
			store_doc = true;
		}
	}
	else if (strlen(caption) > strlen(LINK_CAPTION_CHANGEFREQ) && !strncmp(caption,LINK_CAPTION_CHANGEFREQ,strlen(LINK_CAPTION_CHANGEFREQ)))
	{
		// Check sitemap.xml information, in this case, we use
		// a special caption for last modified date.
		// e.g.:
		//    news/new_item.html <CHANGEFREQ> 0 <PRIO> 3 <LMOD> 1079473183
		// In which the second number is the last modified date
		// informed in the robots.txt file

		if (store_doc == false)
		{
			doc.docid = docid;
			meta->doc_retrieve(&(doc));
			assert(doc.docid == docid);
		}

		if (doc.duplicate_of > 0) // una volta che un documento diventa duplicato di un altro inutile assegnarli ulteriori 'changefreq', 'priority' ecc...
		{
			if (store_doc == true)
				meta->doc_store(&(doc));

			return docid;
		}

		// Advance special caption "<CHANGEFREQ>"
		caption += strlen(LINK_CAPTION_CHANGEFREQ);

		// Advance whitespace
		while (isspace(*caption))
			caption++;

		sitemap_xml_changefreq_t old_sitemap_changefreq = doc.sitemap_changefreq;

		// Copy sitemap_changefreq
		switch (caption[0])
		{
			case '1':
				doc.sitemap_changefreq	= ALWAYS;
				break;
			case '2':
				doc.sitemap_changefreq	= HOURLY;
				break;
			case '3':
				doc.sitemap_changefreq	= DAILY;
				break;
			case '4':
				doc.sitemap_changefreq	= WEEKLY;
				break;
			case '5':
				doc.sitemap_changefreq	= MONTHLY;
				break;
			case '6':
				doc.sitemap_changefreq	= YEARLY;
				break;
			case '7':
				doc.sitemap_changefreq	= NEVER;
				break;
			default:
				doc.sitemap_changefreq	= NONE;
            break;
    	}

		if (doc.sitemap_changefreq != old_sitemap_changefreq)
			store_doc = true;

		// Advance from character readed
		caption++;

		// Advance whitespace
		while (isspace(*caption))
			caption++;

		sitemap_xml_priority_t old_sitemap_prio = doc.sitemap_prio;

		if (strlen(caption) > strlen(LINK_CAPTION_PRIORITY) && !strncmp(caption,LINK_CAPTION_PRIORITY,strlen(LINK_CAPTION_PRIORITY))) {

			// Advance special caption "<LAST-MODIFIED>"
			caption += strlen(LINK_CAPTION_PRIORITY);

			// Advance whitespace
			while (isspace(*caption))
				caption++;

			// Copy date
			doc.sitemap_prio = (sitemap_xml_priority_t)((int)caption[0] - 48);

			// Advance from character readed
			caption++;

			// Advance whitespace
			while (isspace(*caption))
				caption++;
		}

		if (doc.sitemap_prio != old_sitemap_prio)
			store_doc = true;

		if (strlen(caption) > strlen(LINK_CAPTION_LAST_MODIFIED) && !strncmp(caption,LINK_CAPTION_LAST_MODIFIED,strlen(LINK_CAPTION_LAST_MODIFIED))) {

			// Advance special caption "<LMOD>"
			caption += strlen(LINK_CAPTION_LAST_MODIFIED);

			// Advance whitespace
			while (isspace(*caption))
				caption++;


			// Copy date
			time_t now = time(NULL);
			time_t last_modified = atol(caption);

			if (last_modified > doc.last_modified && last_modified < now)
			{
				doc.last_modified = last_modified;
				doc.abs_last_modified = true;

				if (doc.from_feed == true)
					doc.from_feed = false;

				store_doc = true;
			}
		}
	}
	else if (strlen(caption) > strlen(LINK_CAPTION_PRIORITY) && !strncmp(caption,LINK_CAPTION_PRIORITY,strlen(LINK_CAPTION_PRIORITY)))
	{
		// Check sitemap.xml information, in this case, we use
		// a special caption for last modified date.
		// e.g.:
		//    news/new_item.html <PRIO> 3 <LMOD> 1079473183
		// In which the second number is the last modified date
		// informed in the robots.txt file

		if (store_doc == false)
		{
			doc.docid = docid;
			meta->doc_retrieve(&(doc));
			assert(doc.docid == docid);
		}

		if (doc.duplicate_of > 0) // una volta che un documento diventa duplicato di un altro inutile assegnarli ulteriori 'changefreq', 'priority' ecc...
		{
			if (store_doc == true)
				meta->doc_store(&(doc));

			return docid;
		}

		// Advance special caption "<PRIO>"
		caption += strlen(LINK_CAPTION_PRIORITY);

		// Advance whitespace
		while (isspace(*caption))
			caption++;

		sitemap_xml_priority_t old_sitemap_prio = doc.sitemap_prio;

		// Copy date
		doc.sitemap_prio = (sitemap_xml_priority_t)((int)caption[0] - 48);

		// Advance from character readed
		caption++;

		// Advance whitespace
		while (isspace(*caption))
			caption++;

		if (doc.sitemap_prio != old_sitemap_prio)
			store_doc = true;

		if (strlen(caption) > strlen(LINK_CAPTION_LAST_MODIFIED) && !strncmp(caption,LINK_CAPTION_LAST_MODIFIED,strlen(LINK_CAPTION_LAST_MODIFIED))) {

			// Advance special caption "<LMOD>"
			caption += strlen(LINK_CAPTION_LAST_MODIFIED);

			// Advance whitespace
			while (isspace(*caption))
				caption++;


			// Copy date
			time_t now = time(NULL);
			time_t last_modified = atol(caption);

			if (last_modified > doc.last_modified && last_modified < now)
			{
				doc.last_modified = last_modified;
				doc.abs_last_modified = true;

				if (doc.from_feed == true)
					doc.from_feed = false;

				store_doc = true;
			}
		}
	}

	// Se il documento è nuovo o ha subito modifiche dopo la ricezione OCCORRE salvarlo
	// e usando il booleano 'store_doc' la scrittura su disco avverrà SOLO se queste sono avvenute realmente
	if (rc == URLDDX_CREATED_PATH)
		meta->doc_store(&(doc));
	else if (store_doc == true)
		meta->doc_store(&(doc));

	return docid;
}

//
// Name: seeder_save_links
//
// Description:
//   Saves all of the urls from a document
//
// Input:
//   src_doc - source document
//   adjacency_list - list of outgoing links
//   adjacency_list_length - length of adjacency_list
//   

void seeder_save_links(doc_t *src_doc, out_link_t adjacency_list[], unsigned int adjacency_list_length)
{
//	assert(src_doc->docid > 0 && src_doc->docid <= (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));

	// Save
	linkidx_status_t rc = linkidx_store(lidx, src_doc->docid, adjacency_list, adjacency_list_length);

	if (rc != LINKIDX_OK)
		mcerr << "[Failed to store links from " << src_doc->docid << "]" << mendl;

	return;
} 

//
// Name: seeder_is_excluded
//
// Description:
//   Checks if a url is excluded, called only for sites
//   that have exclusion (via a robots.txt file)
//
// Input:
//   doc - the document object
//   path - the path on that site
// 
// Return:
//   true if the path must be rejected
//

bool seeder_is_excluded(doc_t *doc, char *path) {
	assert(doc->docid > 0);
	assert(path);
	assert(path[0] != ASCII_SL);

	// If this is a exclusion path mentioned in the 
	// robots.txt file, then it's certainly excluded
	if (doc->status == STATUS_DOC_EXCLUSION) {
		return true;
	}

	// We will copy the path
	char path_cpy[MAX_STR_LEN];
	bool first_try	= true;

	uint i = 0;
	while (i < strlen(path))
	{
		// Check if this is the first try
		if (first_try)
		{
			// If this is the first try, we will consider
			// the possibility of slash being an exclusion path
			strcpy(path_cpy, "");
			first_try	= false;
		}
		else
		{
			while (path[i] != ASCII_SL && i < strlen(path))
			{
				path_cpy[i] = path[i];
				i++;
			}

			if (i == strlen(path)) break;

			path_cpy[i] = '\0';
		}

		// Check the partial path
		doc_t partial_doc;
		docid_t partial_docid;
		urlddx_status_t rc = url->contains_path(doc->siteid, path_cpy, &(partial_docid));

		if (rc ==  URLDDX_NOT_FOUND);
		else if (rc == URLDDX_EXISTENT)
		{
			partial_doc.docid = partial_docid;
			meta->doc_retrieve(&(partial_doc));

			if (partial_doc.status == STATUS_DOC_EXCLUSION) return true;
		}
		else cerr << "Wrong answer from urlddx_resolve_url: " << (int)rc << endl;

		if (i > 0)
		{
			path_cpy[i] = ASCII_SL;
			i++;
		}
	}

	return false;
}

//
// Name: seeder_open_indexes
//
// Description:
//   Opens all the indexes needed
//   

void seeder_open_indexes() {
	cerr << "Open indexes ... ";

	cerr << "[metaddx] ";
	meta = new Meta (COLLECTION_METADATA, false);
	assert(meta);
	meta->ddx_open();

	// Failed to open index
	if (thread_alarm != THREADS_OK) cbot_stop(1);

	cerr << "[linkidx] ";
	lidx = linkidx_open(COLLECTION_LINK, false);
	assert(lidx);

	// Failed to open index
	if (thread_alarm != THREADS_OK) cbot_stop(1);

	cerr << "[urlddx] ";
	url = new Url (COLLECTION_URL, Url::RW);
	assert(url);
	url->ddx_open();

	// Failed to open index
	if (thread_alarm != THREADS_OK) cbot_stop(1);

	cerr << "done." << endl;
}

//
// Name: cleanup
//
// Description: 
//   Closes files and clean everything
//

void cleanup()
{
	if (meta)
	{
		meta->ddx_close();
		delete meta;
		cerr << "[metaddx] ";
	}

	if (url)
	{
		url->ddx_close();
		delete url;
		cerr << "[urlddx] ";
	}

	if (lidx)
	{
		lidx->st_close();
		delete lidx;
		cerr << "[linkidx] ";
	}

	if (harv)
	{
	//	harv->st_close(); // already closed
		delete harv;
		cerr << "[harvest] ";
	}

	if (sessionid_variables)
	{
		for(int i = 0; i < sessionid_variables_count; i++)
			free(sessionid_variables[i]);

		free(sessionid_variables);
	}

	regfree(&reject_patterns);
	regfree(&sessionid_patterns);

	if (domain_suffixes)
		free(domain_suffixes);

	perfhash_destroy(&(extensions_dynamic));
	perfhash_destroy(&(extensions_ignore));
	perfhash_destroy(&(accept_protocol));
	perfhash_destroy(&(keep_special));
}

//
// Name: seeder_usage
//
// Description:
//   Prints the usage notice
//

void seeder_usage() {
	cerr << "Usage: program [OPTION]" << endl;
	cerr << "Reads start urls or read urls found by the gatherer" << endl;
	cerr << endl;
	cerr << " -s, --start <filename>  read start urls from filename" << endl;
	cerr << " -f, --force id          force a harvest id, even if its already seeded" << endl;
	cerr << " --help                  this help message" << endl;
	cerr << endl;
	cbot_stop(0);
}

