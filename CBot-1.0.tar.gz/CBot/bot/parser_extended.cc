/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "parser_extended.h"

//
// Nome htmlParser
//
// Descrizione Esegue il parsing agginutivo a quello standard effettuato dal crawler
//
// Restituisce la struttura in cui sono presenti i testi contenuti nei:
// titolo (dentro campo head), metatags (keywords, description), headings, tag strong
// e converte il restante testo html dentro il corpo boby in puro testo.
//
off64_t htmlParser(server_t *server, char *inbuf, instance_t inst)
{
entity_status_t entityalarm = ENTITY_NOT_FOUND;
entity_status_t entityalarm_heading = ENTITY_NOT_FOUND;
bool continua = false;
bool body_tag = false; // se a uno (true) indica che è stato trovato il tag body
bool title_tag = false;
bool title_break = false; // se 'true' nessuna futura scrittura in 'inn.title' è permessa
bool noframes_tag = false; // il contenuto fra i tag noframes va scartato (anche se all'interno si trova il tag body)
bool heading_tag = false; // se 'false' si è raggiunto il limite massimo di memoria disponibile
bool heading_break = false; // se 'true' nessuna futura scrittura in 'inn.headings' è permessa
//unsigned short heading_number = 6; // di default il tag heading parte sempre con il meno importante (<H6>) (possibile futura implementazione)
bool strong_tag = false;
bool evaluate_tag = false; // viene verificato durante il processo di lettura dei titoli e dei tag heading
bool firstevaluation = false;
bool slash = false; // se a uno indica che si tratta di un tag di chiusura
bool smts = false;
int pos = 0;
int script_tag = 0;
int hyperlink_tag = 0;
unsigned int tin = 0; // contatore che serve a posizionarsi sul puntatore dei titoli
unsigned int hin = 0;
unsigned int counter = 0;
unsigned short row_dictionary_mtags = 0;
unsigned short row_dictionary_tags = 0;
unsigned short col_dictionary_mtags = 0;
unsigned short col_dictionary_tags = 0;
unsigned short pterowindex[PENUMROWS] = {0};
char test = '\0';
mbstate_t *mbs = CBALLOC(mbstate_t, CALLOC, 1);
off64_t length = server->pages->doc->raw_content_length;
pes_t inn;

assert(length == server->pages->doc->raw_content_length);

char **hibernate_tag = CBALLOC(char *, MALLOC, PENUMROWS);

	for (unsigned short i = 0; i < PENUMROWS; i++)
		hibernate_tag[i] = CBALLOC(char, MALLOC, PENUMCOLS);

	if ( !mbsinit(mbs) )
		memset (mbs,0,sizeof(&mbs));  // set to initial state

	//assert(inn != NULL);
	// Occorre inizializzare gli array della struttura di tipo pes_t nel caso non vengano scritti durante l'esecuzione del programma
	inn.metadesc[0] = ASCII_NUL;
	inn.metakeyw[0] = ASCII_NUL;
	inn.metalmon = pes_t::NO_LOCAL_MONETARY;
	inn.title[0] = ASCII_NUL;
	inn.headings[0] = ASCII_NUL;

	// determina in numero di righe occupate da lettere dell'array bidimensionale dictionary_mtags
	for (row_dictionary_mtags = 0; row_dictionary_mtags < PENUMROWS; row_dictionary_mtags++)
	{
		if (isalpha(dictionary_mtags[row_dictionary_mtags][0]) == 0) break;
	}
	
	// determina in numero di righe occupate da lettere dell'array bidimensionale dictionary_tags
	for (row_dictionary_tags = 0; row_dictionary_tags < PENUMROWS; row_dictionary_tags++)
	{
		if (isalpha(dictionary_tags[row_dictionary_tags][0]) == 0) break;
	}
	
	// determina in numero massimo di colonne occupate da lettere dell'array bidimensionale dictionary_mtags
	for (unsigned short row = 0; row < row_dictionary_mtags; row++)
	{
		for (unsigned short col = 0; col < PENUMCOLS; col++)
			if (isalpha(dictionary_mtags[row][col]) == 0)
				{
					if (col > col_dictionary_mtags)
						col_dictionary_mtags = col;

					break;
				}
	}
	
	// determina in numero massimo di colonne occupate da lettere dell'array bidimensionale dictionary_tags
	for (unsigned short row = 0; row < row_dictionary_tags; row++)
	{
		for (unsigned short col = 0; col < PENUMCOLS; col++)
			if (isalpha(dictionary_tags[row][col]) == 0)
				{
					if (col > col_dictionary_tags)
						col_dictionary_tags = col;
					break;
				}
	}
	
	// ad ogni nuovo ciclo di htmlParser occorre essere certi che il dizionario dei tags sia come desiderato
	//for (unsigned short r = 0; r < row_dictionary_tags; r++)
	//	for (unsigned short c = 0; c < col_dictionary_tags; c++)
	//		dictionary_tags[r][c] = matrix_tags[r][c];
	
	// dichiara un puntatore ad indirizzamento 1 byte (char) e estrae dalla memoria heap l'area necessaria per contenere uno spazio di 1 byte * length (lunghezza documento)
	
	inn.content = (char*) malloc (sizeof(char) * (length + MB_CUR_MAX + 1)); // alloca per il puntatore inn.content memoria sufficente a contenere indirizzi dati di tipo char X counter
	
	inn.content[0] = '\0';

	for (unsigned int i = 0; i < length; i++)
	{
		// per prima cosa occorre verificare che il puntatore sia puntato su un tipo di multibyte char
		char *pt = &(inbuf[i]);
		size_t mbclen = 0;
		wchar_t wc = L'\0';
		size_t wclen = 0;

		if ( !mbsinit(mbs) )
			memset (mbs,0,sizeof(&mbs));  /* set to initial state */

		mbclen = mbrlen(pt, MB_CUR_MAX, mbs);

		if (mbclen < 1 || mbclen > MB_CUR_MAX) // invalid multibyte char. Skip to next byte
			continue;

		if (mbclen > 1) // carattere multibyte. Va convertito in wide char per analisi successive
		{
			if ( !mbsinit(mbs) )
				memset (mbs,0,sizeof(&mbs));  // set to initial state 

			wclen = mbrtowc(&wc, pt, MB_CUR_MAX, mbs);

			// il carattere multibyte di lunghezza due byte 'non blocking space' è sostituito da due spazi (il ciclo 'for' riprende al primo spazio)
			// N.B. i caratteri ascii puri, esistono solo a byte singolo nonostante siano dichiarati attraverso 'Wide Character'.
			// Perciò in pratica il carattere speciale 'spazio' piuttosto che 'newline' ad esempio, seppur dichiarato attraverso il tipo dato wchar_t:
			// Sarà Sempre a Singolo Byte
			if (wclen == mbclen)
			{
				if (wc == (unsigned long long int)NBSP)
				{
					inbuf[i++] = ASCII_SP;
					inbuf[i--] = ASCII_SP;
					i--;
					continue;
				}
			}
			else
				wclen = 0;
		}
		else // ascii char
		{
			if (inbuf[i] == ASCII_NL ||
				inbuf[i] == ASCII_TB ||
				inbuf[i] == ASCII_CR ||
				inbuf[i] == ASCII_BS)
				inbuf[i] = ASCII_SP;
			
		}
		// verifica carattere multibyte terminata

		if (continua == true && body_tag == true && smts == false)
		{
			if (inbuf[i] != ASCII_SL) // inbuf[i] != / 
			{
				if (pos == 0)
					firstevaluation = false;

				// Condizione speciale. Se si desidera che tra le parentesi del tag, il tag non attaccato a '<' sia analizzato lo stesso
				// Utile sia disattivata tra il tag body per fare in modo che l'interpretazione sia il più statndard possibile
				//if (inbuf[i] != ASCII_SP)
				pos++;

				if (script_tag == 0 && hyperlink_tag == 0)
					test = scanTags(hibernate_tag,dictionary_tags,row_dictionary_tags,inbuf[i],pos,firstevaluation,pterowindex);
				else // note: hibernate_tag must have one valid row
					test = scanHibernate(hibernate_tag,inbuf[i],pos,firstevaluation,pterowindex); // con l'ibernazione i tag annidati dentro tag il cui contenuto deve essere escluso non vengono considerati

				switch (test)
				{
				case 'A':
					// controlla gli attributi 'style' dentro i tag che restituiscono A o P (vedi dictionary_tag)
					if (stylePropDisplayCheck(inbuf, length, i) == true)
					{
						if (slash == 0)
							script_tag++;

						hibernate_tag[0][0] = 'R';

						while (inbuf[i] != ASCII_MA && i < length)
							i++;

						evaluate_tag = false;
						continua = false;
					}
					else
					{
						if (counter > 0 && inn.content[counter - 1] != ASCII_SP) // ASCII_SP = spazio in ascii
						{
							if (slash == 1 && counter < length)
							{
								inn.content[counter++] = ASCII_SP;
								inn.content[counter] = '\0';
							}
						}

						if (hin > 0 && (heading_tag == true || strong_tag == true) && inn.headings[hin - 1] != ASCII_SP && hin < HEADINGSSIZE)
						{
							inn.headings[hin++] = ASCII_SP;
							inn.headings[hin] = '\0';
						}
					}

					slash = 0;
					test = '\0';
					break;
				case 'N':
					// controlla gli attributi 'style' dentro i tag che restituiscono A o P (vedi dictionary_tag)
					if (stylePropDisplayCheck(inbuf, length, i) == true)
					{
						if (slash == 0)
							script_tag++;

						hibernate_tag[0][0] = 'R';

						while (inbuf[i] != ASCII_MA && i < length)
							i++;

						evaluate_tag = false;
						continua = false;
					}

					slash = 0;
					test = '\0';
					break;
				case 'P':
					// controlla gli attributi 'style' dentro i tag che restituiscono A o P (vedi dictionary_tag)
					if (stylePropDisplayCheck(inbuf, length, i) == true)
					{
						if (slash == 0)
							script_tag++;

						hibernate_tag[0][0] = 'R';

						while (inbuf[i] != ASCII_MA && i < length)
							i++;

						evaluate_tag = false;
						continua = false;
					}
					else
					{
						if (counter > 0 && inn.content[counter - 1] != ASCII_SP) // ASCII_SP = spazio in ascii
						{
							if (counter < length)
							{
								inn.content[counter++] = ASCII_SP;
								inn.content[counter] = '\0';
							}
						}

						if (hin > 0 && (heading_tag == true || strong_tag == true) && inn.headings[hin - 1] != ASCII_SP && hin < HEADINGSSIZE)
						{
							inn.headings[hin++] = ASCII_SP;
							inn.headings[hin] = '\0';
						}
					}

					slash = 0;
					test = '\0';
					break;
				case 'H': // recupera il testo tra i tag heading.
					if (heading_break == false && heading_tag == false && slash == 0)
							heading_tag = true;
					else
					{
						heading_tag = false;

						if ((strong_tag == false) && hin < (HEADINGSSIZE - 1))
						{
							inn.headings[hin++] = ASCII_DT;
							inn.headings[hin++] = ASCII_SP;
							inn.headings[hin] = '\0';
						}
					}

					if (counter > 0 && inn.content[counter - 1] != ASCII_SP) // ASCII_SP = spazio in ascii
					{
						if (counter < length)
						{
							inn.content[counter++] = ASCII_SP;
							inn.content[counter] = '\0';
						}
					}

					test = '\0';
					break;
				case 'S': // recupera il testo tra i tag strong.
					if (heading_break == false && strong_tag == false && slash == 0)
						strong_tag = true;
					else
					{
						strong_tag = false;

						if ((heading_tag == false) && hin < (HEADINGSSIZE - 1))
						{
							inn.headings[hin++] = ASCII_DT;
							inn.headings[hin++] = ASCII_SP;
							inn.headings[hin] = '\0';
						}
					}

					if (counter > 0 && inn.content[counter - 1] != ASCII_SP) // ASCII_SP = spazio in ascii
					{
						if (counter < length)
						{
							inn.content[counter++] = ASCII_SP;
							inn.content[counter] = '\0';
						}
					}

					test = '\0';
					break;
				case 'L': // eliminina i tag degli script (anche annidati) con il loro contenuto interno
					if (slash == 0 && hyperlink_tag == 0)
						hyperlink_tag++; // hiperlink può solo aumentare fino ad uno
					else if (slash == 1 && hyperlink_tag > 0) // a volte se il sito è fatto male i tag non vengono chiusi correttamente (hyperlink_tag può decrementare
						hyperlink_tag--;		  // solo per diventare 0)

					if (hyperlink_tag == 0)
						memset(hibernate_tag[0],'\0',PENUMCOLS);

					slash = 0;
					test = '\0';
					break;
				case 'R': // eliminina i tag degli script (anche annidati) con il loro contenuto interno
					if (slash == 0)
						script_tag++;
					else if (slash == 1 && script_tag > 0) // a volte se il sito è fatto male i tag non vengono chiusi correttamente (script_tag può decrementare solo
						script_tag--;		       // se maggiore di zero

					if (script_tag == 0)
						memset(hibernate_tag[0],'\0',PENUMCOLS);

					slash = 0;
					test = '\0';
					break;
				case 'B': // Identificato il tag body di chiusura (anche se dentro tali tag non viene neanche estrapolato il contenuto fra i tags 'body')
					  // dentro gli obsoleti noframes tags
					if (noframes_tag == true)
						body_tag = false;

					test = '\0';
				case 'Z': // valore restituito nel caso la ricerca sia terminata senza aver trovato alcun parametro
					smts = true;
					test = '\0';
					break;
				default:
					test = '\0';
				}
			}
			else
				slash = 1;
		}
		//else if (continua == true && body_tag == false && pos < (col_dictionary_mtags + PENUASCII_MASCII_SPACES))
		else if (continua == true && body_tag == false)
		{
			if (inbuf[i] != ASCII_SL) // inbuf[i] != / 
			{

				if (inbuf[i] != ASCII_SP)
					pos++;

				switch (searchBodyTag(inbuf[i],pos))
				{
				case 'B':
					if (noframes_tag == 0)
						body_tag = true;

					slash = 0;
					break;
				}

				switch (searchTitleTag(inbuf[i],pos))
				{
				case 'T': // recupera il testo tra i tag title
					if (title_break == false && title_tag == false)
						title_tag = true;
					else
						title_tag = false;

					test = '\0';
					break;
				}

				// Supporto al tag obsoleto al tag 'noframes' che deve essere messo al di fuori dei tag body
				switch (searchNoFramesTag(inbuf[i],pos)) 
				{
				case 'F':
					if (noframes_tag == 0)
						noframes_tag = 1;
					else
						noframes_tag = 0;

					slash = 0;
					break;
				}
				if (smts == false)
				{

					test = searchMetaTags(inbuf,length,dictionary_mtags,row_dictionary_mtags,inbuf[i],pos,i,pterowindex);

					switch (test)
					{
					case 'D': // identifica il nome del meta tag
						pulloutMeta(inbuf, inn.metadesc, i, DESCSIZE);
						test = '\0';
						break;
					case 'K': // identifica il nome del meta tag
						pulloutMeta(inbuf, inn.metakeyw, i, KEYWSIZE);
						test = '\0';
						break;
					case 'M': // identifica il nome del meta tag
						pulloutLocalMonetary(inbuf, inn.metalmon, i, LMONSIZE);
						test = '\0';
						break;
					case 'Z': // valore restituito nel caso la ricerca sia terminata senza aver trovato alcun parametro
						smts = true;
						test = '\0';
						break;
					default:
						test = '\0';
					}
				}
			}
			else
				if (inbuf[i - 1] == ASCII_MI && i > 0)
					slash = 1;
		}

		// Stampa il titolo della pagina html subito dopo l'estrazione del tag title
		if (title_tag == true)
		{
			if (tin < TITLESIZE)
			{
				if (evaluate_tag == false) // i tag html dentro i titoli non vengono valutati ma sostituiti con uno spazio a prescindere
				{
					if (tin == 0 && inbuf[i] == ASCII_MI) // se il primo carattere da elaborare è '<' significa che si il tag title risulta vuoto
						goto title_reset;

					if (inbuf[i] == ASCII_MI && inn.title[(tin - 1)] != ASCII_SP)
					{
						inn.title[tin++] = ASCII_SP;
						inn.title[tin] = '\0';
					}

					if ((inbuf[i] != ASCII_MI) && (inbuf[i] != ASCII_MA)) // < > \n \r \t
					{
						//if (inbuf[i] == ASCII_AM && (tin + EBNUL) < TITLESIZE && (tin + EBHUL) < TITLESIZE && (tin + EBALL) < TITLESIZE)
						if (inbuf[i] == ASCII_AM)
							entityalarm = convEntity(inbuf, i, (off64_t)TITLESIZE, inn.title, tin);

						if (entityalarm == ENTITY_ERROR) // entity was in overflow zone
						{
							title_break = true;
							entityalarm = ENTITY_NOT_FOUND;
							continue;
						}
						else if (entityalarm == ENTITY_NOT_FOUND) // entità non trovata
						{
							if (wclen > 0)
							{
								if ((tin + mbclen) < TITLESIZE)
								{
									unsigned char o = 0;

									while (o < mbclen)
										inn.title[tin++] = inbuf[i + (o++)];

									inn.title[tin] = '\0';
								}
								else
								{
									title_break = true;
									title_tag = false;
									entityalarm = ENTITY_NOT_FOUND;
									continue;
								}
							}
							else // ascii characters or unknown wide character
							{
								if (tin > 0 && (inn.title[tin -1] == ASCII_SP) && (inbuf[i] == ASCII_SP))
									continue;
								else if (tin == 0 && (inbuf[i] == ASCII_SP))
									continue;
								else
								{ 
									if (inbuf[i] != ASCII_AM)
									{
										inn.title[tin++] = inbuf[i];
										inn.title[tin] = '\0';
									}
								}
							}
						}
						else if (entityalarm == ENTITY_IGNORED) // entità trovata ma che non deve essere convertita
						{
							if (tin > 0 && (inn.title[tin -1] == ASCII_SP) && (inbuf[i] == ASCII_SP))
								continue;
							else
							{
								inn.title[tin++] = inbuf[i];
								inn.title[tin] = '\0';
							}

							if (inbuf[i] == ASCII_SC)
								entityalarm = ENTITY_NOT_FOUND;
						}
						else
						{
							while (inbuf[i] != ASCII_SC)
								i++;

							if (entityalarm > 0 && inbuf[i] == ASCII_SC) // se il punto e virgola appartiene ad una entità entityalarm viene azzerato
								entityalarm = ENTITY_NOT_FOUND;
						}
					}
				}
			}
			else
			{
				while (inbuf[i] != ASCII_MI)
					i++;

				title_tag = false;
			}
		}

		title_reset:

		if (inbuf[i] == ASCII_MI) // inbuf[i] == <
		{
			evaluate_tag = true;
			smts = false;
			continua = true;
			pos = 0;
		}
		else if (inbuf[i] == ASCII_MA) //inbuf[i] == >
		{
			evaluate_tag = false;
			continua = false;
			slash = 0;
		}

		if (counter < length)
		{
//cout <<  inbuf[i] << '-' << continua << '-' << body_tag << '-' << script_tag << endl;
			if (continua == false && body_tag == true && script_tag == 0 && hyperlink_tag == 0 && (inbuf[i] != ASCII_MA)) // > 
			{
				if (heading_tag == true || strong_tag == true)
				{
					if (inbuf[i] == ASCII_AM)
						entityalarm_heading = convEntity(inbuf, i, (off64_t)HEADINGSSIZE, inn.headings, hin);

					if (entityalarm_heading == ENTITY_ERROR)
					{
						heading_break = true;
						heading_tag = false;
						strong_tag = false;
						entityalarm_heading = ENTITY_NOT_FOUND;
						goto headings_skipped;
					}

					if (hin < HEADINGSSIZE) // stampa il contenuto dei tag heading
					{
						if (entityalarm_heading == ENTITY_NOT_FOUND)
						{
							if (wclen > 0)
							{
								if ((hin + mbclen) < HEADINGSSIZE)
								{
									unsigned char o = 0;

									while (o < mbclen)
										inn.headings[hin++] = inbuf[i + (o++)];

									inn.headings[hin] = '\0';
								}
								else
								{
									heading_break = true;
									heading_tag = false;
									strong_tag = false;
									entityalarm_heading = ENTITY_NOT_FOUND;
									goto headings_skipped;
								}
							}
							else // ascii characters or unknown wide character
							{
								if (hin > 0 && (inn.headings[hin -1] == ASCII_SP) && (inbuf[i] == ASCII_SP))
										goto headings_skipped;
								else if (hin == 0 && (inbuf[i] == ASCII_SP))
										goto headings_skipped;
								else if (hin > 1 && i < (length - 1) && (isdigit(inbuf[i]) == false) && (inbuf[i] == ASCII_SP || inbuf[i + 1] == ASCII_SP) && ((inbuf[i] == inn.headings[hin - 2] && inbuf[i + 1] == inn.headings[hin - 1]) || (inbuf[i] == inn.headings[hin - 1] && inbuf[i + 1] == inn.headings[hin - 2]))) // scarta sequenza tipo '- - -'
										goto headings_skipped;
								else
								{
									if (inbuf[i] != ASCII_AM && checkChar(hin, ( hin > 0 ? inn.headings[hin - 1] : '\0' ), inbuf[i]))
									{
										inn.headings[hin++] = inbuf[i];
										inn.headings[hin] = '\0';
									}
								}
							}
						}
						else if (entityalarm_heading == ENTITY_FOUND) // entità trovata
						{
							if (hin > 4 && (isdigit(inn.headings[hin - 1]) == false) && (inn.headings[hin - 2] == ASCII_SP || inn.headings[hin - 1] == ASCII_SP) && (( inn.headings[hin - 2] == inn.headings[hin - 4] && inn.headings[hin - 1] == inn.headings[hin - 3]) || ( inn.headings[hin - 2] == inn.headings[hin - 3] && inn.headings[hin - 1] == inn.headings[hin - 4]))) // scarta sequenza tipo '- - -'
							{
								hin--;
								inn.headings[hin] = '\0';

								continue;
							}

							// se il punto e virgola appartiene ad una entità, entityalarm_heading viene azzerato
							if ((entityalarm_heading != ENTITY_NOT_FOUND && entityalarm_heading != ENTITY_ERROR) && inbuf[i] == ASCII_SC)
								entityalarm_heading = ENTITY_NOT_FOUND;
						}
						else if (entityalarm_heading == ENTITY_IGNORED) // entità trovata ma che non deve essere convertita
						{
							if (hin > 0 && (inn.headings[hin -1] == ASCII_SP) && (inbuf[i] == ASCII_SP))
									goto headings_skipped;
							if (hin == 0 && (inbuf[i] == ASCII_SP))
									goto headings_skipped;
							else if (checkChar(hin, ( hin > 0 ? inn.headings[hin - 1] : '\0' ), inbuf[i]))
							{
									inn.headings[hin++] = inbuf[i];
									inn.headings[hin] = '\0';
							}

							if (inbuf[i] == ASCII_SC)
								entityalarm_heading = ENTITY_NOT_FOUND;
						}
					}
				}

				headings_skipped:

				// L'utilizzo della variabile heading_tag serve nel caso si voglia evitare che il contenuto dei tag 'headings/strong'
				// siano inserito in content
				if (HEADINGSINCONTENT == true || (HEADINGSINCONTENT == false && (heading_tag == false && strong_tag == false)))
				{
					if (inbuf[i] == ASCII_AM)
						entityalarm = convEntity(inbuf, i, length, inn.content, counter);

					// 'ENTITY_ERROR' indica che non è possibile continuare a cenvertire le entitàhtml
					// Trattasi di un errore tipico in caso dimensioni del buffer 'inn.counter' insufficienti.
					if (entityalarm == ENTITY_ERROR)
						break;

					if (entityalarm == ENTITY_NOT_FOUND)
					{
						if (wclen > 0)
						{
							if (counter < (length - mbclen))
							{
								unsigned char o = 0;

								while (o < mbclen)
									inn.content[counter++] = inbuf[i + (o++)];

								inn.content[counter] = '\0';
							}
							else
								break;
						}
						else // ascii characters or unknown wide character
						{
							if (counter > 0 && (inn.content[counter -1] == ASCII_SP) && (inbuf[i] == ASCII_SP))
								continue;
							else if (counter == 0 && (inbuf[i] == ASCII_SP))
								continue;
							else if (counter > 1 && i < (length - 1) && (isdigit(inbuf[i]) == false) && (inbuf[i] == ASCII_SP || inbuf[i + 1] == ASCII_SP) && ((inbuf[i] == inn.content[counter - 2] && inbuf[i + 1] == inn.content[counter - 1]) || (inbuf[i] == inn.content[counter - 1] && inbuf[i + 1] == inn.content[counter - 2]))) // scarta sequenza tipo '- - -'
								continue;
							else
							{
								if (inbuf[i] != ASCII_AM && checkChar(counter, ( counter > 0 ? inn.content[counter -1] : '\0' ), inbuf[i]))
								{
									inn.content[counter++] = inbuf[i];
									inn.content[counter] = '\0';
								}
							}
						}
					}
					else if (entityalarm == ENTITY_FOUND) // entità trovata
					{
						if (counter > 4 && i < (length - 1) && (isdigit(inn.content[counter - 1]) == false) && (inn.content[counter - 2] == ASCII_SP || inn.content[counter - 1] == ASCII_SP) && (( inn.content[counter - 2] == inn.content[counter - 4] && inn.content[counter - 1] == inn.content[counter - 3]) || ( inn.content[counter - 2] == inn.content[counter - 3] && inn.content[counter - 1] == inn.content[counter - 4]))) // scarta sequenze ascii tipo '- - -'
						{
							counter--;
							inn.content[counter] = '\0';

							continue;
						}

						// se il punto e virgola appartiene ad una entità, entityalarm viene azzerato
						if ((entityalarm != ENTITY_NOT_FOUND && entityalarm != ENTITY_ERROR) && inbuf[i] == ASCII_SC)
							entityalarm = ENTITY_NOT_FOUND;
					}
					else if (entityalarm == ENTITY_IGNORED) // entità trovata ma che non deve essere convertita
					{
						if (counter > 0 && (inn.content[counter -1] == ASCII_SP) && (inbuf[i] == ASCII_SP))
							continue;
						if (counter == 0 && (inbuf[i] == ASCII_SP))
							continue;
						else if (checkChar(counter, ( counter > 0 ? inn.content[counter -1] : '\0' ), inbuf[i]))
						{
							inn.content[counter++] = inbuf[i];
							inn.content[counter] = '\0';
						}

						if (inbuf[i] == ASCII_SC)
							entityalarm = ENTITY_NOT_FOUND;
					}
				//	else
				//		if (entityalarm > 0 && inbuf[i] == ASCII_SC) // se il punto e virgola appartiene ad una entità, entityalarm viene azzerato
				//			entityalarm = ENTITY_NOT_FOUND;
				}
			}
			else
				continue;
		}
	}

	if (tin == TITLESIZE) // string is too long and it was truncated
	{
		size_t lastsep = 0; // variabile che indica sempre l'ultimo punto dove il contenuto si può interrompere senza spezzare le frasi
		size_t sepchar = 0;
		char *pt = inn.title;
		size_t mbslen = (size_t)tin;
		size_t offset = 0;
		size_t mbclen = 0;
		wchar_t wc = L'\0';
		mbstate_t *mbs = (mbstate_t *) calloc (1, sizeof(mbstate_t));

		if ( !mbsinit(mbs) )
			memset (mbs,0,sizeof(&mbs));  /* set to initial state */

		while (offset < mbslen)
		{
			mbclen = mbrlen(pt, MB_CUR_MAX, mbs);

		    if (mbclen < 1 || mbclen > MB_CUR_MAX) // invalid multibyte char. Skip to next byte
			{
				//if (offset < (mbslen - 1))
				//	cout << "invalid byte at offset " << offset << endl;

				offset++;
				pt++;
				continue;
			}

			if (mbclen > 1) // carattere multibyte. Va convertito in wide char per capire di che si tratta
			{
				if ( !mbsinit(mbs) )
					memset (mbs,0,sizeof(&mbs));  /* set to initial state */

				size_t s = mbrtowc(&wc, pt, MB_CUR_MAX, mbs);
       
				if (s == mbclen && (iswalpha(wc) == false))
				{
					if (offset < (TITLESIZE - 1))
						lastsep = offset;

					for (unsigned char i = 0; i < mbclen; i++)
					{
						// cout << pt[0];
						offset++;
						pt++;
					}

					// cout << " is non alpha multibyte char" << endl;
				}
				else // unknown wide character
				{
					pt += mbclen;
					offset += mbclen;
				}
			}
			else
			{
				if (isalpha(pt[0]) == false)
				{
					if (pt[0] != ASCII_SP &&
						pt[0] != ASCII_DQ &&
						pt[0] != ASCII_AM &&
						pt[0] != ASCII_QU &&
						pt[0] != ASCII_HM )
					{
						sepchar = offset;
						lastsep = offset;
					}
					else
					{
						if (offset < (TITLESIZE - 1))
							lastsep = offset;
					}

//					cout << '|' << pt[0] << "| is non alpha char (" << lastsep << ')' << endl;
				}

				offset++;
				pt++;
			}
		}

		free(mbs);

		if (lastsep == 0 && sepchar == 0)
			inn.title[0] = '\0';
		else if (lastsep > 0 && sepchar == 0)
			inn.title[lastsep] = '\0';
		else if (sepchar > 0)
			inn.title[sepchar] = '\0';
	}

	if (hin == HEADINGSSIZE)
	{
		size_t offset = HEADINGSSIZE;

		while (offset > 0 &&
		inn.headings[offset] != ASCII_SP &&
		inn.headings[offset] != ASCII_DQ &&
		inn.headings[offset] != ASCII_AM &&
		inn.headings[offset] != ASCII_QU &&
		inn.headings[offset] != ASCII_HM)
		{
			inn.headings[offset] = '\0';
			offset--;
		}
			
		inn.headings[offset] = '\0';
	}

	// Formattazione dei campi dentro unico buffer
	unsigned char TitleLen = strlen(inn.title);
	unsigned char DescriptionLen = strlen(inn.metadesc);
	unsigned char KeywordsLen = strlen(inn.metakeyw);
	//unsigned char LocmonLen = strlen(inn.metalmon); // TODO a seguito riutilizzo 'connector' occorre indicare se la pagina ha indicato l'uso del sardex
	unsigned char HeadingsLen = strlen(inn.headings);

	off64_t outpos = (HTMLMETAPREFIXSIZE + DescriptionLen + KeywordsLen + TitleLen + HeadingsLen);
	assert ((outpos + counter) < server->pages->bt_size);
	char *outbuf = server->pages->buffer_two;

	if (TitleLen > 0)
	{
		if (TitleLen > UCHAR_MAX)
			outbuf[0] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[0] = (char)(SCHAR_MAX - UCHAR_MAX + TitleLen + 1);
	}
	else
		outbuf[0] = (SCHAR_MIN + 1);

	if (DescriptionLen > 0)
	{
		if (DescriptionLen > UCHAR_MAX)
			outbuf[1] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[1] = (char)(SCHAR_MAX - UCHAR_MAX + DescriptionLen + 1);
	}
	else
		outbuf[1] = (SCHAR_MIN + 1);

	if (KeywordsLen > 0)
	{
		if (KeywordsLen > UCHAR_MAX)
			outbuf[2] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[2] = (char)(SCHAR_MAX - UCHAR_MAX + KeywordsLen + 1);
	}
	else
		outbuf[2] = (SCHAR_MIN + 1);

	if (HeadingsLen > 0)
	{
		if (HeadingsLen > UCHAR_MAX)
			outbuf[3] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[3] = (char)(SCHAR_MAX - UCHAR_MAX + HeadingsLen + 1);
	}
	else
		outbuf[3] = (SCHAR_MIN + 1);

	char *poutbuf = &(outbuf[HTMLMETAPREFIXSIZE]);

	if (TitleLen > UCHAR_MAX)
	{
		strncpy(poutbuf, inn.title, UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (TitleLen > 0)
	{
		strncpy(poutbuf, inn.title, TitleLen);
		poutbuf = &(poutbuf[TitleLen]);
	}

	if (DescriptionLen > UCHAR_MAX)
	{
		strncpy(poutbuf, inn.metadesc, UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (DescriptionLen > 0)
	{
		strncpy(poutbuf, inn.metadesc, DescriptionLen);
		poutbuf = &(poutbuf[DescriptionLen]);
	}

	if (KeywordsLen > UCHAR_MAX)
	{
		strncpy(poutbuf, inn.metakeyw, UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (KeywordsLen > 0)
	{
		strncpy(poutbuf, inn.metakeyw, KeywordsLen);
		poutbuf = &(poutbuf[KeywordsLen]);
	}

	if (HeadingsLen > UCHAR_MAX)
	{
		strncpy(poutbuf, inn.headings, UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (HeadingsLen > 0)
	{
		strncpy(poutbuf, inn.headings, HeadingsLen);
		poutbuf = &(poutbuf[HeadingsLen]);
	}

	outbuf[outpos] = '\0';
	strncat( outbuf + outpos, inn.content, counter);
	outpos = (outpos + counter);
	outbuf[outpos] = '\0';

	free (inn.content);

	for (unsigned short i = 0; i < PENUMROWS; i++)
		free(hibernate_tag[i]);

	free(hibernate_tag);

	free (mbs);
	return outpos;
}

//
// Nome searchTitleTag
//
// Descrizione Indica se il tag esaminato è un '<title>' tag
//
// Restituisce T se vero
//
char searchTitleTag(char &character, int &position)
{
	thread_local static short counter;

	if (position < 7)
	{
		if (tolower(character) == static_cast<int>(title_x_func[position]))
		{
			counter++;
		}
		else if (position == 5 && counter == 5 && character == ASCII_SP)
		{
			counter = 0;
			return title_x_func[0];
		}
		else if (position == 6 && counter == 5 && character == ASCII_MA)
		{
			counter = 0;
			return title_x_func[0];
		}
		else if (position > 1 && tolower(character) != static_cast<int>(title_x_func[position]))
		{
			counter = 0;
		}
	}

	return '0';
}

//
// Nome searchMetaTags
//
// Descrizione Serve per identificare il nome (description o keywords) di un eventuale meta tag
//
// Restituisce un carattere maiuscolo che indica se si tratta di un meta tag description, keywords, cbotlocmon
//
char searchMetaTags(char *buf, off64_t &length, const char matrix[PENUMROWS][PENUMCOLS], unsigned short &valid_rows, char &character, int &pos, unsigned int &cursor, unsigned short pterowindex[])
{
thread_local static short meta;
thread_local static short numele;
thread_local static short numele2;
thread_local static short nt = 0; // se tale contatore raggiunge il numero di righe in matrice occorre interrompere la funzione di ricerca
thread_local static short nto = 0; // serve per indicare staticamente il numero di righe della matrice dopo il primo confronto
thread_local static unsigned short spacecount = 0;
thread_local static bool isname = false;
thread_local static bool ismeta = false;
unsigned short myoffset = 0;
//thread_local static char char_delimiter; // non è importante lavorare con un apposito char_delimiter in quanto quello che serve alla funzione è verificare solo se dopo 'name='
// si trova la parola 'description' o 'keywords'


	if (pos == 1)
	{
		meta = 0;
		ismeta = false;
		isname = false;
		spacecount = 0;
	}

	if (pos < 5 && spacecount == 0)
	{
		if (pos == 1 && tolower(character) == static_cast<int>('m'))
			meta = 1;
		else if (pos == 2 && tolower(character) == static_cast<int>('e') && meta == 1)
			meta++;
		else if (pos == 3 && tolower(character) == static_cast<int>('t') && meta == 2)
			meta++;
		else if (pos == 4 && tolower(character) == static_cast<int>('a') && meta == 3)
			meta++;
		else if (character == ASCII_SP && meta == 4)
			spacecount++;
		else
		{
			meta = 0;
			return 'Z';
		}
    	}

	if (meta == 4 && spacecount == 1) // is meta tag
		ismeta = true;

	if (ismeta == true)
	{
	unsigned short offset = 0;

		while (buf[cursor + offset] != ASCII_MA && isname == false)
		{
			spacecount = 0;
			unsigned short mycursor = cursor + offset;
			myoffset = cursor + offset;

			do {
				if (myoffset == mycursor && tolower(buf[myoffset]) == static_cast<int>('n'))
					myoffset++;
				else if ((myoffset - mycursor) == 1 && tolower(buf[myoffset]) == static_cast<int>('a'))
					myoffset++;
				else if ((myoffset - mycursor) == 2 && tolower(buf[myoffset]) == static_cast<int>('m'))
					myoffset++;
				else if ((myoffset - mycursor) == 3 && tolower(buf[myoffset]) == static_cast<int>('e'))
					myoffset++;
				else if ((myoffset - mycursor) > 3 && buf[myoffset + spacecount] == ASCII_SP)
					spacecount++;
				else if ((myoffset - mycursor) == 4 && tolower(buf[myoffset + spacecount]) == static_cast<int>('='))
					myoffset++;
				else if ((myoffset - mycursor) == 5 && (buf[myoffset + spacecount] == ASCII_DQ || buf[myoffset + spacecount] == ASCII_QU))
					myoffset++;
				else
					break;
			}
			while ((myoffset - mycursor) < 6);

			if ((myoffset - mycursor) == 6 && buf[mycursor - 1] == ASCII_SP)
				isname = true;
			else
				offset++;

			while (buf[myoffset + spacecount] == ASCII_SP)
				spacecount++;
		}
		if (isname == false) //Se alla prima verifica del meta tag non riesce a trovare l'attributo 'name', le operazioni successive non verranno più eseguite.
			return 'Z';
	}

	if (ismeta == true && isname == true) // is meta tag
	{
		numele = 0;

		for (short rowipos = 0; rowipos < valid_rows; rowipos++)
			if (tolower(buf[myoffset + spacecount]) == static_cast<int>(matrix[rowipos][1])) // spazio
				pterowindex[numele++] = rowipos;

		if (numele == 0)
			return 'Z';

		nt = 0;
		nto = numele;
	}

	if (ismeta == true && isname == true && nto > 0) // is meta tag
	{
		unsigned short pos = 0;

		while (buf[myoffset + spacecount] != ASCII_MA)
		{
			numele2 = 0;

			for (short rowipos = 0; rowipos < numele; rowipos++)
			{
				if (isalpha(matrix[pterowindex[rowipos]][pos + 1]) == 0 && (buf[myoffset + spacecount + pos] == ASCII_DQ || buf[myoffset + spacecount + pos] == ASCII_QU || buf[myoffset + spacecount + pos] == ASCII_SP))
					return matrix[pterowindex[rowipos]][0];
				else if (tolower(buf[myoffset + spacecount + pos]) == static_cast<int>(matrix[pterowindex[rowipos]][pos + 1]))
					pterowindex[numele2++] = pterowindex[rowipos];
				else
				{
					nt++;
					if (nt == nto)
					{
						meta = 0;
						nt = 0;
						numele = 0;
						return 'Z';
					}
				}
    			}

			numele = numele2;
			pos++;
		}
	}

	return '0';
}

//
// Nome searchBodyTag
//
// Descrizione Indica se il tag esaminato è un '<body>' tag
//
// Restiruisce B se vero
//
char searchBodyTag(char &character, int &position)
{
thread_local static short counter = 0;

	if (position < 6)
	{
		if (tolower(character) == static_cast<int>(body_x_func[position]))
		{
			counter++;
		}
		else if (position == 4 && counter == 4 && character == ASCII_SP)
		{
			counter = 0;
			return body_x_func[0];
		}
		else if (position == 5 && counter == 4 && (character == ASCII_SP || character == ASCII_MA))
		{
			counter = 0;
			return body_x_func[0];
		}
		else if (position > 1 && tolower(character) != static_cast<int>(body_x_func[position]))
		{
			counter = 0;
		}
	}

	return '0';
}

//
// Nome searchNoFramesTag
//
// Descrizione Indica se il tag esaminato è un '<noframes>' tag
//
// Restiruisce F se vero
//
char searchNoFramesTag(char &character, int &position)
{
thread_local static short counter = 0;

	if (position < 10)
	{
		if (tolower(character) == static_cast<int>(noframes_x_func[position]))
		{
			counter++;
		}
		else if (position == 8 && counter == 8 && character == ASCII_SP)
		{
			counter = 0;
			return noframes_x_func[0];
		}
		else if (position == 9 && counter == 8 && (character == ASCII_SP || character == ASCII_MA))
		{
			counter = 0;
			return noframes_x_func[0];
		}
		else if (position > 1 && tolower(character) != static_cast<int>(noframes_x_func[position]))
		{
			counter = 0;
		}
	}
	
	return '0';
}

//
// Nome scanHibernate
//
// Descrizione Esamina un tag html contenuto nel corpo della pagina (body)
//
// Restiruisce:
//
char scanHibernate(char **hibernate_tag, char &character, int &pos, bool &firstevaluation, unsigned short pterowindex[PENUMROWS])
{
	thread_local static short numele;
	thread_local static short numele2;
	thread_local static short nt = 0; // se tale contatore raggiunge il numero di righe in matrice occorre interrompere la funzione di ricerca
	thread_local static short nto = 0; // serve per indicare staticamente il numero di righe della matrice dopo il primo confronto

	if (pos == 1 && firstevaluation == true) // condizione se il tag ha un solo carattere
	{
		for (short col = 0; col < numele; col++)
			if (isalpha(hibernate_tag[pterowindex[col]][pos + 1]) == 0 && character == ASCII_SP)
			{
				numele = 0;
				numele2 = 0;
				nt = 0;
				nto = 0;

				return hibernate_tag[pterowindex[col]][0];
			}

		if (numele == 0)
		{
			nt = 0;
			nto = 0;
			numele2 = 0;
			return 'Z';
		}

		nt = 0;
		nto = numele;
	}
	else if (pos == 1)
	{
		numele = 0;

		if (tolower(character) == static_cast<int>(hibernate_tag[0][pos]) && character != ASCII_SP) // spazio
		{
			pterowindex[numele++] = 0;
			firstevaluation = true; // indica che la valutazione all'interno del tag ha avuto inizio
		}

		if (numele == 0)
		{
			nt = 0;
			nto = 0;
			numele2 = 0;
			return 'Z';
		}

		nt = 0;
		nto = numele;
	}
	else
	{
		numele2 = 0;

		for (short rowipos = 0; rowipos < numele; rowipos++)
		{
			if (isalpha(hibernate_tag[pterowindex[rowipos]][pos + 1]) == 0 && character == ASCII_SP)
			{
				numele = 0;
				numele2 = 0;
				nt = 0;
				nto = 0;

				return hibernate_tag[pterowindex[rowipos]][0];
			}
			else if (isalpha(hibernate_tag[pterowindex[rowipos]][pos]) == 0 && (character == ASCII_SP || character == ASCII_MA))
			{
				numele = 0;
				numele2 = 0;
				nt = 0;
				nto = 0;

				return hibernate_tag[pterowindex[rowipos]][0];
			}
			else if (tolower(character) == (int)(hibernate_tag[pterowindex[rowipos]][pos])) // static_cast<char>(tolower(character)) non necessario
				pterowindex[numele2++] = pterowindex[rowipos];
			else
			{
				nt++;
				if (nt == nto)
				{
					nt = 0;
					numele = 0;
					numele2 = 0;
					return 'Z';
				}
			}
		}
		numele = numele2;
	}

	return '0';
}
//
// Nome scanTags
//
// Descrizione Esamina un tag html contenuto nel corpo della pagina (body)
//
// Restiruisce Un carattere che indica l'azione da intraprendere come ad esempio sostituire il tag con uno spazio.
//
char scanTags(char **hibernate_tag, const char matrix[PENUMROWS][PENUMCOLS], unsigned short &valid_rows, char &character, int &pos, bool &firstevaluation, unsigned short pterowindex[PENUMROWS])
{
	thread_local static short numele;
	thread_local static short numele2;
	thread_local static short nt = 0; // se tale contatore raggiunge il numero di righe in matrice occorre interrompere la funzione di ricerca
	thread_local static short nto = 0; // serve per indicare staticamente il numero di righe della matrice dopo il primo confronto

	if (pos == 1 && firstevaluation == true) // condizione se il tag ha un solo carattere
	{
		for (short col = 0; col < numele; col++)
		{
			if (isalpha(matrix[pterowindex[col]][pos + 1]) == 0 && character == ASCII_SP)
			{
				numele = 0;
				numele2 = 0;
				nt = 0;
				nto = 0;

				short c = 0;

				while (c <= pos)
				{
					hibernate_tag[0][c] = matrix[pterowindex[col]][c];
					c++;
				}

				hibernate_tag[0][c] = '\0';

				return matrix[pterowindex[col]][0];
			}
		}

		if (numele == 0)
		{
			nt = 0;
			nto = 0;
			numele2 = 0;
			return 'Z';
		}

		nt = 0;
		nto = numele;
	}
	else if (pos == 1)
	{
		numele = 0;

		for (short rowipos = 0; rowipos < valid_rows; rowipos++)
		{
			if (tolower(character) == static_cast<int>(matrix[rowipos][pos]) && character != ASCII_SP) // spazio
			{
				pterowindex[numele++] = rowipos;
				firstevaluation = true; // indica che la valutazione all'interno del tag ha avuto inizio
			}
		}

		if (numele == 0)
		{
			nt = 0;
			nto = 0;
			numele2 = 0;
			return 'Z';
		}

		nt = 0;
		nto = numele;
	}
	else
	{
		numele2 = 0;

		for (short rowipos = 0; rowipos < numele; rowipos++)
		{

			if (isalpha(matrix[pterowindex[rowipos]][pos + 1]) == 0 && character == ASCII_SP)
			{
				numele = 0;
				numele2 = 0;
				nt = 0;
				nto = 0;

				short c = 0;

				while (c <= pos)
				{
					hibernate_tag[0][c] = matrix[pterowindex[rowipos]][c];
					c++;
				}

				hibernate_tag[0][c] = '\0';

				return matrix[pterowindex[rowipos]][0];
			}
			else if (isalpha(matrix[pterowindex[rowipos]][pos]) == 0 && (character == ASCII_SP || character == ASCII_MA))
			{
				numele = 0;
				numele2 = 0;
				nt = 0;
				nto = 0;

				short c = 0;

				while (c <= pos)
				{
					hibernate_tag[0][c] = matrix[pterowindex[rowipos]][c];
					c++;
				}

				hibernate_tag[0][c] = '\0';

				return matrix[pterowindex[rowipos]][0];
			}
			else if (tolower(character) == static_cast<int>(matrix[pterowindex[rowipos]][pos])) // static_cast<char>(tolower(character)) non necessario
				pterowindex[numele2++] = pterowindex[rowipos];
			else
			{
				nt++;
				if (nt == nto)
				{
					nt = 0;
					numele = 0;
					numele2 = 0;
					return 'Z';
				}
			}
		}
		numele = numele2;
	}

	return '0';
}

//
// Nome convEntity
//
// Descrizione Sostituisce una entità html del tipo &agrave; con il carattere corrispondente (à), fa eccezione l'entita &amp;
//
// Restituisce un codice numerico che indica se l'entita è stata sostituita,ignorata o non trovata.
//
entity_status_t convEntity(char *buf, unsigned int &ipos, off64_t cont_left_size, char cont[], unsigned int &cursor)
{
// A differenza delle altre funzioni di ricerca questa non lavora carattere per carattere, bensì per verificare la correttezza della stringa sposta in avanti il
// cursore del inbuf fino al termine finale di ricerca (in questo caso ';')
entity_type_t entity_type = ENTITYIDX_ENTITY_INVALID;
unsigned short pos = 1; // parte da uno in quanto il carattere '&' relativo alla posizione attuale sul buf di default non viene confrontato
unsigned short zl = 0; // leading zero
unsigned int _cursor = cursor;
size_t mbclen = 0;
char *multibyte = (char *) calloc ((MB_CUR_MAX + 1), sizeof(char));

	// find entity type
	if (buf[ipos + pos] == '#')
	{
		if (buf[ipos + 2] == 'x' || buf[ipos + 2] == 'X')
			pos = 3; // nel caso il secondo carattere del buf sia '#' il confronto va fatto sulle entità a riferimento esadecimale e si va al carattere successivo
		else
			pos = 2; // nel caso il secondo carattere del buf sia '#' il confronto va fatto sulle entità a riferimento numerico e si va al carattere successivo

		while (buf[(ipos + pos + zl)] == '0' && cont_left_size > 0 ) // skip leadings zero
		{
			zl++;
			cont_left_size--;
		}
	}

    entityid_t entityid = 0;

	switch (pos)
    {
        case 1:
			entity_type = ENTITYIDX_ENTITY_ALPHANUM;
			break;
        case 2:
			entity_type = ENTITYIDX_ENTITY_DECIMAL;
			break;
        case 3:
			entity_type = ENTITYIDX_ENTITY_HEXDECIMAL;
			break;
		default:
			entity_type = ENTITYIDX_ENTITY_INVALID;
			break;
	}
    
    if (entity_type != ENTITYIDX_ENTITY_INVALID && et.checkEntity(&(buf[ipos + pos + zl]), &(entityid), &(entity_type)) == ENTITYIDX_EXISTENT)
	{
		wchar_t wc = (unsigned long int)entityid;

		mbstate_t *mbs = (mbstate_t *) calloc (1, sizeof(mbstate_t));

		if ( !mbsinit(mbs) )
			memset (mbs,0,sizeof(&mbs));  // set to initial state

		mbclen = wcrtomb(multibyte,wc,mbs);
		multibyte[mbclen] = '\0';

		free(mbs);
			
		goto risultato;
	}

	if ((cursor + 6) < cont_left_size)
	{
		cont[cursor++] = ASCII_AM;
		cont[cursor++] = 'a';
		cont[cursor++] = 'm';
		cont[cursor++] = 'p';
		cont[cursor++] = ASCII_SC;
		cont[cursor] = '\0';

		free(multibyte);

		return ENTITY_NOT_FOUND;
	}
	else
	{
		cursor = _cursor;
		cont[cursor] = '\0'; // nothing to write in buffer in order to not allow overflow writing

		free(multibyte);

		return ENTITY_ERROR;
	}

	risultato:

	{
		// entità trovate ma non convertite (caratteri ",&,<,>)
		if (mbclen == 1)
		{
			if (multibyte[0] == ASCII_DQ || multibyte[0] == ASCII_AM || multibyte[0] == ASCII_MI || multibyte[0] == ASCII_MA)
			{
				free(multibyte);

				return ENTITY_IGNORED;
			}

			if (multibyte[0] == ASCII_SP && cursor > 0 && (cont[cursor -1] == ASCII_SP))
			{
				free(multibyte);

				return ENTITY_FOUND;
			}

			if (checkChar(cursor, ( cursor > 0 ? cont[cursor -1] : '\0' ), multibyte[0]))
			{
				cont[cursor++] = multibyte[0];
				cont[cursor] = '\0';
			}
		}
		else
		{
			if ((off64_t)(cursor + mbclen) < cont_left_size)
			{
				memcpy(cont + cursor, multibyte, mbclen);
				cursor += mbclen;
				cont[cursor] = '\0';
			}
			else
			{
				cursor = _cursor;
				cont[cursor] = '\0'; // nothing to write in buffer in order to not allow overflow writing

				free(multibyte);

				return ENTITY_ERROR;
			}

			free(multibyte);

			return ENTITY_FOUND;
		}
	}

	free(multibyte);

	if ((cursor + 6) < cont_left_size)
	{
		cont[cursor++] = ASCII_AM;
		cont[cursor++] = 'a';
		cont[cursor++] = 'm';
		cont[cursor++] = 'p';
		cont[cursor++] = ASCII_SC;
		cont[cursor] = '\0';

		return ENTITY_NOT_FOUND;
	}

	cursor = _cursor;
	cont[cursor] = '\0'; // nothing to write in buffer in order to not allow overflow writing

	return ENTITY_ERROR;
}

//
// Nome pulloutMeta
//
// Descrizione Una volta avuto conferma della funzione searchMetaTags che si tratta di un meta tag di tipo 'cbot_loc_monetary' ne estrae il contenuto
//
// Restituisce Scrive la stringa trovata nell'array cont
//
void pulloutMeta (char *buf, char cont[], unsigned int &cursor, const unsigned short &len)
{
entity_status_t entityalarm = ENTITY_NOT_FOUND;
unsigned int in = 0;
thread_local static char char_delimiter;
unsigned short spacecount = 0;
bool iscontent = false;
unsigned short myoffset = 0;
unsigned short offset = 0;

	while (buf[cursor + offset] != ASCII_MA && iscontent == false)
	{
		spacecount = 0;
		unsigned short mycursor = cursor + offset;
		myoffset = cursor + offset;

		do {
			if (myoffset == mycursor && tolower(buf[myoffset]) == static_cast<int>('c'))
				myoffset++;
			else if ((myoffset - mycursor) == 1 && tolower(buf[myoffset]) == static_cast<int>('o'))
				myoffset++;
			else if ((myoffset - mycursor) == 2 && tolower(buf[myoffset]) == static_cast<int>('n'))
				myoffset++;
			else if ((myoffset - mycursor) == 3 && tolower(buf[myoffset]) == static_cast<int>('t'))
				myoffset++;
			else if ((myoffset - mycursor) == 4 && tolower(buf[myoffset]) == static_cast<int>('e'))
				myoffset++;
			else if ((myoffset - mycursor) == 5 && tolower(buf[myoffset]) == static_cast<int>('n'))
				myoffset++;
			else if ((myoffset - mycursor) == 6 && tolower(buf[myoffset]) == static_cast<int>('t'))
				myoffset++;
			else if ((myoffset - mycursor) > 6 && buf[myoffset + spacecount] == ASCII_SP)
				spacecount++;
			else if ((myoffset - mycursor) == 7 && tolower(buf[myoffset + spacecount]) == static_cast<int>('='))
				myoffset++;
			else if ((myoffset - mycursor) == 8 && (buf[myoffset + spacecount] == ASCII_DQ || buf[myoffset + spacecount] == ASCII_QU))
			{
				char_delimiter = buf[myoffset + spacecount];
				myoffset++;
			}
			else
				break;
		}
		while ((myoffset - mycursor) < 9);

		if ((myoffset - mycursor) == 9 && buf[mycursor - 1] == ASCII_SP)
			iscontent = true;
		else
			offset++;

		while (buf[myoffset + spacecount] == ASCII_SP)
			spacecount++;
	}

	unsigned short i = 0;

	if (iscontent == true)
	{
		while (buf[myoffset + spacecount + i] != char_delimiter && in < len)
		{
				unsigned int rc = (myoffset + spacecount + i);

				if (buf[rc] == '\0' || buf[rc] == char_delimiter) break;

				if (buf[rc] == ASCII_AM) entityalarm = convEntity(buf, rc, len, cont, in);

				if (entityalarm == ENTITY_ERROR)
					break;
				else if (entityalarm == ENTITY_NOT_FOUND) // entità non trovata
				{
					if (in > 0 && (cont[in -1] == ASCII_SP) && buf[rc] == ASCII_SP)
					{
						i++; // a differenza degli altri casi (in cui 'i' è gestito da un ciclo for), occorre incrementere 'i'
						continue;
					}
					else if (buf[rc] != ASCII_AM)
					{
						cont[in++] = buf[rc];
						cont[in] = '\0';
					}
				}
				else if (entityalarm == ENTITY_IGNORED) // entità trovata ma che non deve essere convertita
				{
					if (in > 0 && (cont[in -1] == ASCII_SP) && buf[rc] == ASCII_SP)
					{
						i++; // a differenza degli altri casi (in cui 'i' è gestito da un ciclo for), occorre incrementere 'i'
						continue; 
					}
					else
					{
						cont[in++] = buf[rc];
						cont[in] = '\0';
					}

					if (buf[rc] == ASCII_SC)
						entityalarm = ENTITY_NOT_FOUND;
				}
				else
					if (buf[rc] == ASCII_SC) // se il punto e virgola appartiene ad una entità, entityalarm viene azzerato
						entityalarm = ENTITY_NOT_FOUND;
			i++;
		}
	}

	if (in == len) // text too long end is was truncated. N.B. Anche in alcune lingue non sono necessari gli spazi è sempre probabile siano presenti nel documento
	{
		size_t lastsep = 0; // variabile che indica sempre l'ultimo punto dove il contenuto si può interrompere senza spezzare le frasi
		size_t sepchar = 0;
		char *pt = cont;
		size_t mbslen = (size_t)len;
		size_t offset = 0;
		size_t mbclen = 0;
		wchar_t wc = L'\0';
		mbstate_t *mbs = (mbstate_t *) calloc (1, sizeof(mbstate_t));

		if ( !mbsinit(mbs) )
			memset (mbs,0,sizeof(&mbs));  /* set to initial state */

		while (offset < mbslen)
		{
			mbclen = mbrlen(pt, MB_CUR_MAX, mbs);

		    if (mbclen < 1 || mbclen > MB_CUR_MAX) // invalid multibyte char. Skip to next byte
			{
				// if (offset < (mbslen - 1))
				//	cout << "invalid byte at offset " << offset << endl;

				offset++;
				pt++;
				continue;
			}

			if (mbclen > 1) // carattere multibyte. Va convertito in wide char per capire di che si tratta
			{
				if ( !mbsinit(mbs) )
					memset (mbs,0,sizeof(&mbs));  /* set to initial state */

				size_t s = mbrtowc(&wc, pt, MB_CUR_MAX, mbs);
       
				if (s == mbclen && (iswalpha(wc) == false))
				{
					if (offset < (TITLESIZE - 1))
						lastsep = offset;

					for (unsigned char i = 0; i < mbclen; i++)
					{
						// cout << pt[0];
						offset++;
						pt++;
					}
				}
				else // unknown wide character
				{
					pt += mbclen;
					offset += mbclen;
				}
			}
			else
			{
				if (isalpha(pt[0]) == false)
				{
					if (pt[0] != ASCII_SP &&
						pt[0] != ASCII_DQ &&
						pt[0] != ASCII_AM &&
						pt[0] != ASCII_QU &&
						pt[0] != ASCII_HM )
					{
						sepchar = offset;
						lastsep = offset;
					}
					else
					{
						if (offset < (TITLESIZE - 1))
							lastsep = offset;
					}

					// cout << '|' << pt[0] << "| is non alpha char (" << lastsep << ')' << endl;
				}

				offset++;
				pt++;
			}
		}

		free(mbs);

		if (lastsep == 0 && sepchar == 0)
			cont[0] = '\0';
		else if (lastsep > 0 && sepchar == 0)
			cont[lastsep] = '\0';
		else if (sepchar > 0)
			cont[sepchar] = '\0';
	}
	else
		cont[in] = '\0';
}

//
// Nome pulloutMeta
//
// Descrizione Una volta avuto conferma della funzione searchMetaTags che si tratta di un meta tag di tipo description o keyword ne estrae il contenuto
//
// Restituisce Scrive la stringa trovata nell'array cont
//
void pulloutLocalMonetary (char *buf, pes_t::lmon_t &lmon, unsigned int &cursor, const unsigned short &len)
{
entity_status_t entityalarm = ENTITY_NOT_FOUND;
unsigned int in = 0;
thread_local static char char_delimiter;
unsigned short spacecount = 0;
bool iscontent = false;
unsigned short myoffset = 0;
unsigned short offset = 0;

	while (buf[cursor + offset] != ASCII_MA && iscontent == false)
	{
		spacecount = 0;
		unsigned short mycursor = cursor + offset;
		myoffset = cursor + offset;

		do {
			if (myoffset == mycursor && tolower(buf[myoffset]) == static_cast<int>('c'))
				myoffset++;
			else if ((myoffset - mycursor) == 1 && tolower(buf[myoffset]) == static_cast<int>('o'))
				myoffset++;
			else if ((myoffset - mycursor) == 2 && tolower(buf[myoffset]) == static_cast<int>('n'))
				myoffset++;
			else if ((myoffset - mycursor) == 3 && tolower(buf[myoffset]) == static_cast<int>('t'))
				myoffset++;
			else if ((myoffset - mycursor) == 4 && tolower(buf[myoffset]) == static_cast<int>('e'))
				myoffset++;
			else if ((myoffset - mycursor) == 5 && tolower(buf[myoffset]) == static_cast<int>('n'))
				myoffset++;
			else if ((myoffset - mycursor) == 6 && tolower(buf[myoffset]) == static_cast<int>('t'))
				myoffset++;
			else if ((myoffset - mycursor) > 6 && buf[myoffset + spacecount] == ASCII_SP)
				spacecount++;
			else if ((myoffset - mycursor) == 7 && tolower(buf[myoffset + spacecount]) == static_cast<int>('='))
				myoffset++;
			else if ((myoffset - mycursor) == 8 && (buf[myoffset + spacecount] == ASCII_DQ || buf[myoffset + spacecount] == ASCII_QU))
			{
				char_delimiter = buf[myoffset + spacecount];
				myoffset++;
			}
			else
				break;
		}
		while ((myoffset - mycursor) < 9);

		if ((myoffset - mycursor) == 9 && buf[mycursor - 1] == ASCII_SP)
			iscontent = true;
		else
			offset++;

		while (buf[myoffset + spacecount] == ASCII_SP)
			spacecount++;
	}

	if (iscontent == true)
	{
				unsigned int rc = (myoffset + spacecount);

				if (buf[rc] == ASCII_SP || buf[rc] == char_delimiter)
					lmon = pes_t::NO_LOCAL_MONETARY;
				else
				{
					if (strncasecmp(&buf[rc],"sardex", 6) == 0)
					{
						const unsigned char l = 6;
						unsigned char i = l;
						unsigned char max_end_spaces = 20; // spaces before 'char_delimiter'

						assert((l + max_end_spaces) < UCHAR_MAX);

						while (buf[(rc + i)] != ASCII_NUL && buf[(rc + i)] != char_delimiter && i < (max_end_spaces + l + 1))
						{
							if (buf[(rc + i)] != ASCII_SP)
							{
								i = UCHAR_MAX;
								break;
							}
							else
								i++;
						}

						if ((i - l) <= max_end_spaces)
							lmon = pes_t::SARDEX;
					}
				}
	}
}

//
// Nome stylePropDisplayCheck
//
// Descrizione estrapola l'eventuale attributo style dal tag con relative proprietà:valori (Sono ammesse 'display:none; o visibility:hidden;')
// a differenza della funzione che estrapola i meta tags questa lavora in maniera 'non rigida', cioè i caratteri che compongono il termine da cercare non sono passati
// come costanti ma come normali caratteri di stringa e questo consente alla funzione di lavorare in maniera 'dinamica', nulla vieta ad esempio che in futuro
// passandole l'attributo (es: color) da cercare, possa trovare anche il colore del testo della pagina
//
// Restituisce vero se il tag contiene l'attributo style con parametri che indicano di non stampare il contenuto tra i tag
//
bool stylePropDisplayCheck(char *buf, off64_t &length, unsigned int &cursor)
{
	thread_local static char char_delimiter;
	unsigned int spacecount = 0;
	bool isstyle = false;
	bool isdisplay = false;
	bool isvisibility = false;
	unsigned int myoffset = 0;
	unsigned int offset = 0;

	string _string = "style";
	size_t _string_len = _string.length();

	// cerca se nel tag esiste eventuale attributo 'style'...'='
	while (buf[cursor + offset] != ASCII_MA && isstyle == false && (cursor + offset) < length )
	{
		spacecount = 0;
		unsigned short mycursor = cursor + offset;
		myoffset = cursor + offset;
		unsigned short diff = 0;
		unsigned short diffplus = 0;

		do {
			diff = myoffset - mycursor;
			diffplus = myoffset + spacecount;
			if ((diff == 0 || diff < _string_len) && tolower(buf[myoffset]) == static_cast<int>(_string[diff]))
				myoffset++;
			else if (diff > (_string_len - 1) && buf[diffplus] == ASCII_SP)
				spacecount++;
			else if (diff == _string_len && buf[diffplus] == ASCII_EQ)
				myoffset++;
			else if (diff == (_string_len + 1) && (buf[diffplus] == ASCII_DQ || buf[diffplus] == ASCII_QU))
			{
				char_delimiter = buf[diffplus];
				myoffset++;
			}
			else
				break;
		}
		while (diff < (_string_len + 2));

		if (diff == (_string_len + 2) && buf[mycursor - 1] == ASCII_SP)
			isstyle = true;
		else
			offset++;

		while (buf[myoffset + spacecount] == ASCII_SP)
			spacecount++;
	}

	if (isstyle == true)
	{
	_string = "display";
	_string_len = _string.length();
	cursor = myoffset + spacecount;
	offset = 0;

		// cerca se dentro l'attributo 'style' esiste la chiave 'display'
		while (buf[cursor + offset] != char_delimiter && isdisplay == false && (cursor + offset) < length)
		{
			spacecount = 0;
			unsigned short mycursor = cursor + offset;
			myoffset = cursor + offset;
			unsigned short diff = 0;
			unsigned short diffplus = 0;
	
			do {
				diff = myoffset - mycursor;
				diffplus = myoffset + spacecount;
				if ((diff == 0 || diff < _string_len) && tolower(buf[myoffset]) == static_cast<int>(_string[diff]))
					myoffset++;
				else if (diff > (_string_len - 1) && buf[diffplus] == ASCII_SP)
					spacecount++;
				else if (diff == _string_len && buf[diffplus] == ASCII_CO)
					myoffset++;
				else if (diff == (_string_len + 1) && buf[diffplus] == ASCII_SC)
					myoffset++;
				else
					break;
			}
			while (diff < (_string_len + 1));
	
	
			if (diff == (_string_len + 1) && (buf[mycursor - 1] == ASCII_SP || buf[mycursor - 1] == ASCII_SC || buf[mycursor - 1] == char_delimiter))
				isdisplay = true;
			else
				offset++;
	
			while (buf[myoffset + spacecount] == ASCII_SP)
				spacecount++;
		}
	
		if (isdisplay == true)
		{
		string display_value = "none";
		size_t i = 0;
		size_t t = 0;
	
			// cerca se alla chiave display è assegnato il valore 'none'
			while (isalpha(buf[myoffset + spacecount + i]) && i < display_value.length())
			{
				if (tolower(buf[myoffset + spacecount + i]) == static_cast<int>(display_value[i]))
					t++;
		
				i++;
			}
	
			if (t == display_value.length())
				return true;
		}

		// arrivati a questo punto significa che 'disply:none;' non è stato trovato
		// e si prova a cercare la chiave 'visibility'
		_string = "visibility";
		_string_len = _string.length();
		offset = 0;

		// cerca se dentro l'attributo 'style' esiste la chiave 'visibility'
		while (buf[cursor + offset] != char_delimiter && isvisibility == false && (cursor + offset) < length)
		{
			spacecount = 0;
			unsigned short mycursor = cursor + offset;
			myoffset = cursor + offset;
			unsigned short diff = 0;
			unsigned short diffplus = 0;
	
			do {
				diff = myoffset - mycursor;
				diffplus = myoffset + spacecount;
				if ((diff == 0 || diff < _string_len) && tolower(buf[myoffset]) == static_cast<int>(_string[diff]))
					myoffset++;
				else if (diff > (_string_len - 1) && buf[diffplus] == ASCII_SP)
					spacecount++;
				else if (diff == _string_len && buf[diffplus] == ASCII_CO)
					myoffset++;
				else if (diff == (_string_len + 1) && buf[diffplus] == ASCII_SC)
					myoffset++;
				else
					break;
			}
			while (diff < (_string_len + 1));
	
	
			if (diff == (_string_len + 1) && (buf[mycursor - 1] == ASCII_SP || buf[mycursor - 1] == ASCII_SC || buf[mycursor - 1] == char_delimiter))
				isvisibility = true;
			else
				offset++;
	
			while (buf[myoffset + spacecount] == ASCII_SP)
				spacecount++;
		}
	
		if (isvisibility == true)
		{
		string visibility_value = "hidden";
		size_t i = 0;
		size_t t = 0;
	
			// cerca se alla chiave 'visibility' è assegnato il valore 'hidden'
			while (isalpha(buf[myoffset + spacecount + i]) && i < visibility_value.length())
			{
				if (tolower(buf[myoffset + spacecount + i]) == static_cast<int>(visibility_value[i]))
					t++;
		
				i++;
			}
	
			if (t == visibility_value.length())
				return true;
		}
	}


return false;
}

// Verifica se un carattere è speciale è deve essere stampato una sola volta a prescindere
//
// Accetta in ingresso l'offest del puntatore di destinazione, l'ultimo carattere che è stato salvato sullo stesso e il carattere che dovrebbe essere salvato
//
// Restituisce vero se deve essere salvato
//
bool checkChar (unsigned int c, char d, char s)
{
	if (c == 0) // se la scrittura nel buffer non è ancora cominciata non si scrivono caratteri speciali ascii (o almeno quelli conosciuti)
	{
		if (s == ASCII_SP || s == ASCII_AM || s == ASCII_CM || s == ASCII_HM || s == ASCII_DT || s == ASCII_SL || s == ASCII_SC || s == ASCII_MI || s == ASCII_MA || s == ASCII_US || s == ASCII_PP || s == ASCII_ST)
			return false;
		else
			return true;
	}
	else
	{
		if (s != ASCII_HM && s != ASCII_US && s != ASCII_ST)
			return true;
		if (d != ASCII_HM && s == ASCII_HM)
			return true;
		else if (d != ASCII_US && s == ASCII_US)
			return true;
		else if (d != ASCII_ST && s == ASCII_ST)
			return true;
	}

	return false;
}
