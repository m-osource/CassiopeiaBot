/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _POLLVEC_H_INCLUDED_
#define _POLLVEC_H_INCLUDED_

#include <config.h>

// System libraries

#include <assert.h>
#include <sys/poll.h>
#include <stdlib.h>

// Local libraries

#include "xmlconf.h"

// Constants
#define POLLVEC_FILENAME_LOG "pollvec.log"

// Structs

// The polling vector
typedef struct {
	struct pollfd *fds;	// Poll structures {fd,events,revents}
	siteid_t nfds;			// Current number of fds
	siteid_t max_nfds;		// Max fds supported
	siteid_t *serverids;	// Serverids
	time_t *timeouts;	// Timeouts
	FILE *file_log;		// Logfile
} pollvec_t;

// An event received after poll()
typedef struct {
	siteid_t serverid;		// Server that received the event
	int revents;		// Received events
} pollevent_t;

// Local libraries

#include "die.h"
#include "server.h"

// Global vars (from server.c and harvester.c)

extern bool debugonly;

// Functions

// Constructor and destructor
pollvec_t *pollvec_create( siteid_t, FILE * );
void pollvec_destroy( pollvec_t * );

// Insert and remove servers from the pollvec
void pollvec_insert( pollvec_t *, server_t *, short, time_t );
void pollvec_remove( pollvec_t *, server_t * );
void pollvec_update( pollvec_t *, server_t *, short, time_t );


// Poll
siteid_t pollvec_poll( pollvec_t *, pollevent_t *, server_t * );

bool pollvec_empty( pollvec_t * );

#endif
