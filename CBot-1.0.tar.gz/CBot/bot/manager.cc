/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "manager.h"

thread_local cpu_set_t system_cpus;

//
// Name: main
//
// Description:
//   Manager program, creates the harvests
//
//

int main(int argc, char **argv)
{
try
{
	cbot_start("manager");

	// Parse options
	bool opt_dont_generate	= false;
	bool opt_cancel			= false;
	bool opt_exclude_site	= false;
	bool opt_exclude_docid	= false;
	bool opt_include_site	= false;
	bool opt_include_docid	= false;
	char opt_site[MAX_STR_LEN];
	docid_t opt_docid = (docid_t)0;
	bool opt_verify_only	= false;

	while(1) {
		int option_index = 0;

		static struct option long_options[] = {
			{"help", 0, 0, 0},
			{"dont-generate", 0, 0, 0},
			{"verify-only", 0, 0, 0},
			{"cancel", 0, 0, 0},
			{"exclude-site", 1, 0, 0},
			{"exclude-docid", 1, 0, 0},
			{0, 0, 0, 0}
		};

		char c = getopt_long (argc, argv, "hcv",
			long_options, &option_index);

		if (c == -1)
			break;

		switch (c) {
			case 0:
				if( !strcmp( long_options[option_index].name,
							"dont-generate" ) ) {
					opt_dont_generate = true;
				} else if( !strcmp( long_options[option_index].name,
							"cancel" ) ) {
					opt_cancel = true;
				} else if( !strcmp( long_options[option_index].name,
							"verify-only" ) ) {
					opt_verify_only = true;
				} else if( !strcmp( long_options[option_index].name,
							"exclude-site" ) ) {
					opt_exclude_site = true;
					opt_site[0] = ASCII_NUL;
					strcpy( opt_site, optarg );
				} else if( !strcmp( long_options[option_index].name,
							"exclude-docid" ) ) {
					opt_exclude_docid = true;
					opt_docid = atol(optarg);
				} else if( !strcmp( long_options[option_index].name,
							"includee-site" ) ) {
					opt_include_site = true;
					opt_site[0] = ASCII_NUL;
					strcpy( opt_site, optarg );
				} else if( !strcmp( long_options[option_index].name,
							"include-docid" ) ) {
					opt_include_docid = true;
					opt_docid = atol(optarg);
				} else if( !strcmp( long_options[option_index].name,
							"help" ) ) {
					manager_usage();
				}
				break;
			case 'c':
				opt_cancel = true;
				break;
			case 'v':
				opt_verify_only = true;
				break;
			case 'h':
				manager_usage();
				break;
			default:
				manager_usage();
		}
	}

	// Open all indexes
	cerr << "Open indexes ... ";
	manager_open_indexes();
	cerr << "done." << endl;

	// Get ndocs
	ndocs = meta->doc_count();

	if (ndocs == 0)
		die("Metaindex empty, execute seeder first");

	nsites = meta->site_count();
	assert( nsites > 0 );

	// Verify only
	if (opt_verify_only == true)
	{
		everything_ok = CBALLOC(bool, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		cerr << "Verifying documents only" << endl;
		bool _everything_ok = true;

		cerr << "Marking docs   |--------------------------------------------------|" << endl;
		cerr << "               ";

		int rc = 0;
		pthread_mutexattr_t attr;

		pthread_t *threads = NULL;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

			if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
				die("error setting mutex type %s", strerror(rc));

			if ((rc = pthread_mutexattr_init(&attr)) != 0)
				die("error creating mutex with attributes object %s", strerror(rc));
		}

		for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
		{
			manager_thread_args_t *args = CBALLOC(manager_thread_args_t, MALLOC, 1);
		    args->inst = inst;

			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				if (pthread_create( &threads[inst], NULL, manager_thread_function_verify_documents, (void *) args))
					die("error creating thread!");
			}
			else
				manager_thread_function_verify_documents ((void *) args); // only one distribution, function is call without thread 
		}

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

			free(threads);

			int rc = 0;

			if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
                die("error destroying mutex with attributes object %s", strerror(rc));
		}

		for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
			if (everything_ok[inst] == false)
				_everything_ok = false;

		free(everything_ok);

		cerr << endl;

		if (_everything_ok)
			cbot_stop(0);
		else
			die("There were errors found during the verification");
	}

	// Add exclusion
	if (opt_exclude_docid == true)
	{
		doc_t doc;
		doc.docid = opt_docid;

		// Read the document
		metaddx_status_t rc = meta->doc_retrieve(&(doc));

		if (rc != METADDX_OK)
			die("Error reading metaddx!");
			
		// If the document is from this Website, mark as excluded
		if (doc.docid == opt_docid)
		{
			if (doc.status == STATUS_DOC_EXCLUSION)
				cerr << "Docid " << opt_docid << " is already excluded!";
			else
			{
				doc.status = STATUS_DOC_EXCLUSION;

				if (meta->doc_store(&(doc)) != METADDX_OK)
					die("Error storing to metadata!");

				cerr << "Docid " << opt_docid << " excluded!";
			}
		}
		else
			die("Error reading metaddx (docid %llu discrepancy with %llu)!", opt_docid, doc.docid);;
		
		cerr << endl;

		cbot_stop(0);
	}

	// Add exclusion
	if (opt_exclude_site == true)
	{
		urlddx_status_t rc;
		siteid_t siteid;
		
		rc = url->resolve_site( opt_site, NULL, NOT_DEFINED );

		if( rc == URLDDX_NOT_FOUND )
			die ("Site named %s was not found", opt_site);

		rc = url->resolve_site( opt_site, &(siteid), NOT_DEFINED );

		metaddx_status_t status = meta->site_option_set(siteid, SITE_OPT_DENY, true);

		if (status == METADDX_OK)
			cerr << "Predisposes all URLs from Website " << opt_site << " (siteid " << siteid << ") to be excluded." << endl;
		else
			die("Error storing metadata!");

		cerr << endl;

		cbot_stop(0);
	}

	// Add exclusion
	if (opt_include_site == true)
	{
		urlddx_status_t rc;
		siteid_t siteid;
		
		rc = url->resolve_site( opt_site, NULL, NOT_DEFINED );

		if( rc == URLDDX_NOT_FOUND )
			die ("Site named %s was not found", opt_site);

		rc = url->resolve_site( opt_site, &(siteid), NOT_DEFINED );

		metaddx_status_t status = meta->site_option_set(siteid, SITE_OPT_DENY, false);

		if (status == METADDX_OK)
			cerr << "Predisposes all URLs from Website " << opt_site << " (siteid " << siteid << ") to be reincluded." << endl;
		else
			die("Error storing metadata!");

		cerr << endl;

		cbot_stop(0);
	}

	// Add exclusion
	if (opt_include_docid == true)
	{
		doc_t doc;
		doc.docid = opt_docid;

		// Read the document
		metaddx_status_t rc = meta->doc_retrieve(&(doc));

		if (rc != METADDX_OK)
			die("Error reading metaddx!");
			
		// If the document is from this Website, mark as excluded
		if (doc.docid == opt_docid)
		{
			if (doc.status == STATUS_DOC_EXCLUSION)
			{
				doc.status = STATUS_DOC_GATHERED;

				if (meta->doc_store(&(doc)) != METADDX_OK)
					die("Error storing to metadata!");

				cerr << "Docid " << opt_docid << " excluded!";
			}
			else
				cerr << "Docid " << opt_docid << " is already included!";
		}
		else
			die("Error reading metaddx (docid %llu discrepancy with %llu)!", opt_docid, doc.docid);;
		
		cerr << endl;

		cbot_stop(0);
	}

	harv = new Harvest ( COLLECTION_HARVEST, false );

	// Check if requested to cancel
	if (opt_cancel == true)
	{
//		harv->hv_create(); // NO create only for test
//		harv->hv_close(); // NO create only for test

		// Remove harvest ddx with no STATUS_HARVEST_SEEDED
		harv->cancel_unseeded();

		// Sites are marked with the harvesterid that has pages from
		// it, to avoid having two harvester in the same site.
		cerr << "Marking sites   |--------------------------------------------------|" << endl << "                ";

		pthread_t *threads = NULL;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

			manager_barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

			pthread_barrier_init(manager_barrier, NULL, CONF_COLLECTION_DISTRIBUTED);
		}

		for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
		{
			manager_thread_args_t *args = CBALLOC(manager_thread_args_t, MALLOC, 1);
		    args->inst = inst;

			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				if ( pthread_create( &threads[inst], NULL, manager_thread_function_marking, (void *) args ) )
					die("error creating thread!");
			}
			else
				manager_thread_function_marking ((void *) args); // only one distribution, function is call without thread 
		}

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

			free(threads);

			pthread_barrier_destroy(manager_barrier);

			free(manager_barrier); manager_barrier = NULL;
		}

		cerr << " ok" << endl;

		cbot_stop(0); // OK
	}

	if (CONF_MANAGER_MINPERIOD_FEEDS_FORBIDDEN <= 0 ||
		CONF_MANAGER_MINPERIOD_FEEDS_UNSUCCESSFUL <= 0 ||
		CONF_MANAGER_MINPERIOD_FEEDS_SUCCESSFUL_BUT_NOT_OK <= 0 ||
		CONF_MANAGER_MINPERIOD_FEEDS_SUCCESSFUL_AND_OK <= 0 ||
		CONF_MANAGER_MINPERIOD_FORBIDDEN <= 0 ||
		CONF_MANAGER_MINPERIOD_UNSUCCESSFUL <= 0 ||
		CONF_MANAGER_MINPERIOD_SUCCESSFUL_BUT_NOT_OK <= 0 ||
		CONF_MANAGER_MINPERIOD_SUCCESSFUL_AND_OK <= 0)
		die("Wrong minperiod configuration in main file. EXIT!");
	else if (CONF_MANAGER_SCORE_LIVERANK_WEIGHT && (CONF_MANAGER_MINPERIOD_SUCCESSFUL_AND_OK <= CONF_MANAGER_MINPERIOD_EXTREME_SUCCESSFUL_AND_OK))
		die("Wrong extreme minperiod configuration in main file. EXIT!");

	bool run_ranking = true;

	// Check if time is arrived for next score ranking
	if (CONF_MANAGER_SCORE_PERIODIC_ENABLED)
		run_ranking = cbot_stats(false);

	TALARM;

	if (run_ranking == true)
	{
		bool fix_depths = false; // Invoked indirectly from 'cbot-info-analysis'
		bool mark_dynamic = false; // Invoked indirectly from 'cbot-info-analysis'
		bool mark_ignored = false; // Invoked indirectly from 'cbot-info-analysis'

		if (monitor->command_get(MON_COM_FIX_DEPTHS, true) == MONITOR_OK)
		{
			fix_depths = true;

			// restore the bit for the next time
			monitor_status_t status = monitor->command_set(MON_COM_FIX_DEPTHS, false); 

			assert(status == MONITOR_OK);
		}

		// This marks static/dynamic URLs
		// this is done automatically by the seeder program, but the recognized
		// extensions may change
		if (monitor->command_get(MON_COM_MARK_DYNAMIC, true) == MONITOR_OK)
		{
			mark_dynamic = true;

			// restore the bit for the next time
			monitor_status_t status = monitor->command_set(MON_COM_MARK_DYNAMIC, false); 

			assert(status == MONITOR_OK);
		}

		if (monitor->command_get(MON_COM_MARK_IGNORED, true) == MONITOR_OK)
		{
			mark_ignored = true;

			// restore the bit for the next time
			monitor_status_t status = monitor->command_set(MON_COM_MARK_IGNORED, false); 

			assert(status == MONITOR_OK);
		}

		// Calculate link scores only if needed
		if (CONF_MANAGER_SCORE_PAGERANK_WEIGHT > 0 ||
			CONF_MANAGER_SCORE_WLSCORE_WEIGHT > 0 ||
			CONF_MANAGER_SCORE_HITS_HUB_WEIGHT > 0 ||
			CONF_MANAGER_SCORE_HITS_AUTHORITY_WEIGHT > 0 ||
			CONF_MANAGER_SCORE_LIVERANK_WEIGHT > 0 ||
			fix_depths == true ||
			mark_dynamic == true ||
			mark_ignored == true)
		{
			bool calc_pagerank	= false;
			bool calc_wlrank	= false;
			bool calc_hits		= false;
			bool calc_liverank	= false;

			if (CONF_MANAGER_SCORE_PAGERANK_WEIGHT > 0)
				calc_pagerank	= true;

			if (CONF_MANAGER_SCORE_WLSCORE_WEIGHT > 0)
				calc_wlrank		= true;

			// Il calcolo delle hits diventa attivo solo dopo avere avviato il primo processo harvesting
			if ((CONF_MANAGER_SCORE_HITS_HUB_WEIGHT > 0 || CONF_MANAGER_SCORE_HITS_AUTHORITY_WEIGHT > 0))
				calc_hits		= true;

			//if( harvest_exists( COLLECTION_HARVEST, 1 ) && ( CONF_MANAGER_SCORE_LIVERANK_WEIGHT > 0 ))
			if (CONF_MANAGER_SCORE_LIVERANK_WEIGHT > 0)
				calc_liverank = true;

			cerr << "* Performing link analysis on documents" << endl;

			bool calc_linearize = true;

			Doclink *docl = new Doclink (NULL, false);
			docl->idx_connect(lidx); // passing index of in_degree and out_degree doc links to class
			docl->analysis_docrank(meta, url, strg, lidx, calc_pagerank, calc_wlrank, calc_hits, calc_liverank, calc_linearize, fix_depths, mark_dynamic, mark_ignored);
			delete docl;

			TALARM;
		}
	}

	// Calculate link site scores if needed
	if( CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0 || CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0 )
	{
		cerr << "* Generating statistics about sites" << endl;

		Analysis *analysis = NULL;

		analysis = new Analysis ( meta );

		analysis->site_statistics();

		delete analysis;
	}

	if( CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0 )
	{
		Sitelink *slink = NULL;

		slink = new Sitelink ( COLLECTION_SITELINK, false );

		if( slink != NULL )
		{
			cerr << "* Generating site links structure" << endl;
			slink->sl_create( lidx, meta );
			slink->sl_load( lidx, meta );

			cerr << "* Calculating linearized siterank" << endl;
			slink->analysis_siterank( meta, true, true, true ); // linearizzazione DEVE essere true

			delete slink;
		}
		else
			die("Cannot create Sitelink class");
	}

	// Priority and order
	// Note that in this case the indices start from 0, because
	// we will use the qsort function.
	priority = CBALLOC(priority_t, CALLOC, (ndocs + 1));
	priority[0] = (priority_t)0; // unused
	order = CBALLOC(docid_t, CALLOC, (ndocs + 1));
	order[0] = (docid_t)0; // unused
//	_order = CBALLOC(docid_t, CALLOC, (ndocs + 1));
//	_order[0] = (docid_t)0; // unused
	docid_to_siteid = CBALLOC(siteid_t, CALLOC, (ndocs + 1));

	// Calculate scores and sorting order of priorities
	AnalysisManager *calculate = new AnalysisManager (meta, priority, order, docid_to_siteid, opt_dont_generate);
	calculate->calculate_scores();
	delete calculate;

	// Check if scores_only
	if (opt_dont_generate == true)
	{
		cerr << "Future and current scores calculated. Stop." << endl;

		cbot_stop(0);
	}

	cerr << "done." << endl;
	free( priority ); priority = NULL;

	// Show number of batches and document in each batch
	cerr << "Batch size: " << CONF_MANAGER_BATCH_SIZE << endl;
	cerr << "Creating " << CONF_MANAGER_BATCH_COUNT << " batchs" << endl;

	// Create the batches
	for( uint harvest_count = 1; harvest_count <= CONF_MANAGER_BATCH_COUNT; harvest_count++) 
	{
		// Create harvester
		harv->hv_create(); TALARM;

		// Create the harvest list
		docid_t harvest_doc_count = manager_create_harvest_list(NULL);

		if (harvest_doc_count == 0)
		{
			cerr << "Failed while creating harvest list ... ";
			unsigned int failed_id = harv->hv_id();

			harv->hv_close(); TALARM;
			harv->hv_remove(failed_id); TALARM;

			cerr << "removed." << endl;
			break;
		}
		else if (harvest_doc_count > CONF_MANAGER_BATCH_SIZE)
		{
			cerr << "Error!: too many documents" << endl;
			unsigned int failed_id = harv->hv_id();

			harv->hv_close(); TALARM;
			harv->hv_remove(failed_id); TALARM;

			cerr << "removed." << endl;
			break;
		}

		// Dump basic status of created harvest
		harv->dump_status(false); // force 'false' because is beginning

		// Log
		syslog( LOG_NOTICE, "manager created harvest #%d", harv->hv_id()); 

		// Close
		harv->hv_close();
	}

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}
}

// threads sync
void manager_sync_threads(pthread_barrier_t *barrier)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc = pthread_barrier_wait(barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
        pthread_exit(NULL);
}

// lock a mutex
void manager_lock_a(instance_t &inst)
{
	int rc = 0;

	if (manager_locks_a != NULL && (rc = pthread_mutex_lock(&manager_locks_a[inst])) != 0)
		die ( "error locking mutex %s", CBoterr(rc));
}

// lock a mutex
void manager_lock_b(instance_t &inst)
{
	int rc = 0;

	if (manager_locks_b != NULL && (rc = pthread_mutex_lock(&manager_locks_b[inst])) != 0)
		die ( "error locking mutex %s", CBoterr(rc));
}

// lock a mutex
void manager_rwlock_b(instance_t &inst, bool ro)
{
	int rc = 0;

	if (ro == true)
	{
		if (manager_rwlocks_b != NULL && (rc = pthread_rwlock_rdlock(&manager_rwlocks_b[inst])) != 0)
			die ( "error locking mutex %s", CBoterr(rc));
	}
	else
	{
		if (manager_rwlocks_b != NULL && (rc = pthread_rwlock_wrlock(&manager_rwlocks_b[inst])) != 0)
			die ( "error locking mutex %s", CBoterr(rc));
	}
}

// lock a mutex
void manager_unlock_a(instance_t &inst)
{
	int rc = 0;

	if (manager_locks_a != NULL && (rc = pthread_mutex_unlock(&manager_locks_a[inst])) != 0)
		die ( "error locking mutex %s", CBoterr(rc));
}

// lock a mutex
void manager_unlock_b(instance_t &inst)
{
	int rc = 0;

	if (manager_locks_b != NULL && (rc = pthread_mutex_unlock(&manager_locks_b[inst])) != 0)
		die ( "error locking mutex %s", CBoterr(rc));
}

// lock a mutex
void manager_rwunlock_b(instance_t &inst)
{
	int rc = 0;

	if (manager_rwlocks_b != NULL && (rc = pthread_rwlock_unlock(&manager_rwlocks_b[inst])) != 0)
		die ( "error locking mutex %s", CBoterr(rc));
}

//
// Name: manager_create_harvest_list
//
// Description:
//   Creates a list of documents to be harvested, and assign
//   that list to the harvester
//
// Input:
//   harvest - Harvester to assign documents
//

docid_t manager_create_harvest_list( harvest_t *harvest )
{
	manager_harvest_doc_count = 0;
	manager_site_status_t *manager_site_status = CBALLOC(manager_site_status_t, CALLOC, (nsites + 1));

	// I want to be sure this is reasonably sized and also completely sure
	// that it fits in a uint. 100 million pages in the same batch from the
	// same site would be completely wrong
	assert( CONF_MANAGER_BATCH_SAMESITE < 100000000 );
	atomic<siteid_t> *site_count = CBALLOC(atomic<siteid_t>, MALLOC, (nsites + 1));

	depth_t max_depth = CONF_MANAGER_MAXDEPTH_DYNAMIC > CONF_MANAGER_MAXDEPTH_STATIC ? CONF_MANAGER_MAXDEPTH_DYNAMIC + 1 : CONF_MANAGER_MAXDEPTH_STATIC + 1;
	atomic<docid_t> *depth_count = CBALLOC(atomic<docid_t>, CALLOC, (max_depth + 1));

	siteid_t *saturated_sites = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	siteid_t *count_sites	= CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	siteid_t *count_erroneous_sites = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	// Iterate through sites to check for robots.txt, sitemap.rdf
	cerr << "Scheduling special files such as robots.txt" << endl;
	cerr << "Checking sites  |--------------------------------------------------|" << endl << "                ";

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		// setup mutex of urlddx index before reading in multithread
		// url->setmutex(&urlslock, &urldlock, &urlplock);

		// setup stdout mutexes
		manager_locks_a = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		manager_locks_b = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		manager_rwlocks_b = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
		{
			manager_locks_a[i] = PTHREAD_MUTEX_INITIALIZER;
			manager_locks_b[i] = PTHREAD_MUTEX_INITIALIZER;
			manager_rwlocks_b[i] = PTHREAD_RWLOCK_INITIALIZER;
		}

		manager_barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(manager_barrier, NULL, CONF_COLLECTION_DISTRIBUTED);
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		manager_thread_args_t *args = CBALLOC(manager_thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->manager_site_status = manager_site_status;
		args->site_count = site_count;
		args->depth_count = depth_count;
		args->saturated_sites = saturated_sites;
		args->count_sites = count_sites;
		args->count_erroneous_sites = count_erroneous_sites;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if ( pthread_create( &threads[inst], NULL, manager_thread_function_check_special, (void *) args ) )
				die("error creating thread!");
		}
		else
			manager_thread_function_check_special((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		// destroy mutex of ifxddx index
	//	url->destroymutex(); // commentato fino a quando non si elimina il vecchio codice

		int rc;

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
		{
            if ((rc = pthread_mutex_destroy(&(manager_locks_a[i]))) != 0)
                die ( "error destroying manager mutexes a %s", CBoterr(rc));

            if ((rc = pthread_mutex_destroy(&(manager_locks_b[i]))) != 0)
                die ( "error destroying manager mutexes a %s", CBoterr(rc));

            if ((rc = pthread_rwlock_destroy(&(manager_rwlocks_b[i]))) != 0)
                die ( "error destroying manager mutexes a %s", CBoterr(rc));
		}

		pthread_barrier_destroy(manager_barrier);

		free(manager_locks_a); manager_locks_a = NULL;
		free(manager_locks_b); manager_locks_b = NULL;
		free(manager_rwlocks_b); manager_rwlocks_b = NULL;
		free(manager_barrier); manager_barrier = NULL;
	}

	cerr << " " << manager_harvest_doc_count << " done." << endl;

	// Report
	cerr << endl;
	cerr << "Documents excluded from sites with too many errors : " << count_erroneous_sites << endl;
	cerr << endl;
	cerr << "   Number of sites assigned           : " << count_sites << endl;
	cerr << "   Sites assigned with maximum docs   : " << saturated_sites << " with " << CONF_MANAGER_BATCH_SAMESITE << " docs each " << endl;

	cerr << endl << "   Number of assigned documents per depth:" << endl;

	for (depth_t depth = 0; depth <= max_depth; depth++)
		if (depth_count[depth] > 0)
			cerr << "      " << depth << " " << depth_count[depth] << endl;

	free(count_erroneous_sites);
	free(count_sites);
	free(saturated_sites);
	free( manager_site_status );
	free( site_count );
	free( depth_count );

	return manager_harvest_doc_count;
}

//
// Name: manager_thread_function_check_special
// 
// Description: scheduling special files such as robots.txt or sitemap.rdf
//
// Input: pointer to void
//
// Return:
//
void *manager_thread_function_check_special(void *args)
{
try
{
	manager_thread_args_t *arguments = (manager_thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	manager_site_status_t *manager_site_status = arguments->manager_site_status;
	atomic<siteid_t> *site_count = arguments->site_count;
	atomic<docid_t> *depth_count = arguments->depth_count;
	siteid_t *saturated_sites = arguments->saturated_sites;
	siteid_t *count_sites = arguments->count_sites;
	siteid_t *count_erroneous_sites = arguments->count_erroneous_sites;

	// Clear variables
	for (siteid_t siteid = (inst + 1); siteid <= nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		site_count[siteid] = 0;
		manager_site_status[siteid] = MANAGER_SITE_STATUS_AVAILABLE;
	}

	manager_sync_threads(manager_barrier);

	docid_t nsites_div_50 = nsites / 50;

	doc_t doc;
	site_t site;
	char sitename[MAX_STR_LEN];
	metaddx_status_t metaddx_status;
	time_t period_robots_txt;
	time_t period_sitemap_rdf;
	time_t	now	= time(NULL);
	char path[MAX_STR_LEN];

	for (siteid_t siteid = (inst + 1); siteid <= nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		// Report
		if (nsites_div_50 > 0 && siteid % nsites_div_50 == 0)
			cerr << ".";

		site.siteid	= siteid;

		// Check if too many, maybe even checking special files
		// we already have enough pages for a batch
		if (manager_harvest_doc_count >= CONF_MANAGER_BATCH_SIZE)
			break;

		// Retrieve the site
		metaddx_status = meta->site_retrieve( &(site) );
		assert( metaddx_status == METADDX_OK );

		// Get period length
		period_robots_txt = (meta->site_option_get(siteid, SITE_OPT_VRTXT, true) == METADDX_OK)
			?	CONF_MANAGER_MINPERIOD_ROBOTS_TXT_VALID 
			:	CONF_MANAGER_MINPERIOD_ROBOTS_TXT_NOT_VALID;

		period_sitemap_rdf = (meta->site_option_get(siteid, SITE_OPT_VSRDF, true) == METADDX_OK)
			?	CONF_MANAGER_MINPERIOD_ROBOTS_RDF_VALID 
			:	CONF_MANAGER_MINPERIOD_ROBOTS_RDF_NOT_VALID;

		// Check if period has passed for robots.txt
		// Warning: robots.txt have priority to all documents
		if (site.docid_robots_txt > 0 && (now - site.last_checked_robots_txt) > period_robots_txt)
		{
			// Get document for robots.txt
			doc.docid		= site.docid_robots_txt;

			// mutex are needed because docid are casual and metaddx
			// can write on same time on same instance
			// instance_t ilock = ((doc.docid - 1) % CONF_COLLECTION_DISTRIBUTED);
			// manager_lock_a(ilock);
			metaddx_status	= meta->doc_retrieve(&(doc));
			assert(metaddx_status == METADDX_OK);
			assert(doc.docid == site.docid_robots_txt);
			assert(doc.siteid == site.siteid);

			// Check if it has been assigned
			if (doc.status != STATUS_DOC_ASSIGNED)
			{
				// Retrieve the url
				url->path_by_docid(doc.docid, path);
				assert( path != NULL );

				// Add to the queue
				doc.status = STATUS_DOC_ASSIGNED;
				meta->doc_store(&(doc));

				// Assign the document 
				// harv->append_doc(&(doc), path);

				// manager_unlock_a(ilock);

				// manager_harvest_doc_count++;

				// Count
				site_count[site.siteid]++;
				depth_count[doc.depth]++;

				assert(manager_site_status[site.siteid] != MANAGER_SITE_STATUS_CHECK_SPECIAL);

				manager_site_status[site.siteid] = MANAGER_SITE_STATUS_CHECK_SPECIAL;
			}
//			else
//				manager_unlock_a(ilock);
		}

		if (manager_site_status[site.siteid] == MANAGER_SITE_STATUS_CHECK_SPECIAL)
		{
			// Mark as assigned to this harvester, (testing)
			// obviously the site must be unassigned first
			assert(site.harvest_id == 0);
			site.harvest_id = harv->hv_id();
			meta->site_store(&(site));

			// Count
			count_sites[inst]++;

			// Read the sitename
			url->site_by_siteid(site.siteid, sitename);

			// Give information to the harvest
			harv->append_site(&(site), sitename);

			// Mark as normal site because we don't want skip other old documents
			manager_site_status[site.siteid] = MANAGER_SITE_STATUS_STORED;

			// mutex are needed because docid are casual and metaddx
			// can write on same time on same instance
			instance_t ilock = ((doc.docid - 1) % CONF_COLLECTION_DISTRIBUTED);
			manager_lock_a(ilock);

			// Assign the document 
			harv->append_doc(&(doc), path);

			manager_unlock_a(ilock);

			manager_harvest_doc_count++;
		}

		// Check if period has passed for sitemap.rdf but give precedence on 'robots.txt'
		if (site.docid_sitemap_rdf > 0 && (now - site.last_checked_sitemap_rdf) > period_sitemap_rdf )
		{ // Check if period has passed for sitemap.rdf
			// Get document for sitemap.rdf
			doc.docid		= site.docid_sitemap_rdf;

			// mutex are needed because docid are casual and metaddx
			// can write on same time on same instance
			// instance_t ilock = ((doc.docid - 1) % CONF_COLLECTION_DISTRIBUTED);
			// manager_lock_a(ilock);
			metaddx_status	= meta->doc_retrieve(&(doc));
			assert(metaddx_status == METADDX_OK);
			assert(doc.docid == site.docid_sitemap_rdf);
			assert(doc.siteid == site.siteid);

			// Check if it has been assigned
			if (doc.status != STATUS_DOC_ASSIGNED)
			{
				// Retrieve the url
				url->path_by_docid(doc.docid, path);
				assert( path != NULL );

				// Add to the queue
				doc.status = STATUS_DOC_ASSIGNED;
				meta->doc_store(&(doc));

				// Assign the document
				// harv->append_doc(&(doc), path);
				// manager_unlock_a(ilock);

				// manager_harvest_doc_count++;

				// Count
				site_count[site.siteid]++;
				depth_count[doc.depth]++;

				if (manager_site_status[site.siteid] == MANAGER_SITE_STATUS_CHECK_SPECIAL)
				{
					// mutex are needed because docid are casual and metaddx
					// can write on same time on same instance
					instance_t ilock = ((doc.docid - 1) % CONF_COLLECTION_DISTRIBUTED);
					manager_lock_a(ilock);

					// Assign the document 
					harv->append_doc(&(doc), path);

					manager_unlock_a(ilock);

					manager_harvest_doc_count++;
				}
				else
				{
					// Mark as assigned to this harvester, (testing)
					// obviously the site must be unassigned first
					assert(site.harvest_id == 0);
					site.harvest_id = harv->hv_id();
					meta->site_store(&(site));

					// Count
					count_sites[inst]++;

					// Read the sitename
					url->site_by_siteid(site.siteid, sitename);

					// Give information to the harvest
					harv->append_site(&(site), sitename);

					// Mark as normal site because we don't want skip other old documents
					manager_site_status[site.siteid] = MANAGER_SITE_STATUS_STORED;

					// mutex are needed because docid are casual and metaddx
					// can write on same time on same instance
					instance_t ilock = ((doc.docid - 1) % CONF_COLLECTION_DISTRIBUTED);
					manager_lock_a(ilock);

					// Assign the document 
					harv->append_doc(&(doc), path);

					manager_unlock_a(ilock);

					manager_harvest_doc_count++;
				}
			}
		//	else
		//		manager_unlock_a(ilock);
		}
	}

	manager_sync_threads(manager_barrier);
        

	unsigned int batchsize_div_50 = CONF_MANAGER_BATCH_SIZE / 50;

	if (sp->go_ahead(inst) == true)
	{
		cerr << " ok" << endl;
		cerr << "Adding documents until we have " << CONF_MANAGER_BATCH_SIZE << endl;
		cerr << "Documents |--------------------------------------------------|" << endl;
		cerr << "          ";
	}

	manager_sync_threads(manager_barrier);
        

	// Iterate until the batch have been assigned
	// Warning: because docid and siteid are readed in random mode we need to use mutexes in massive mode :-(!
	for (docid_t i = (inst + 1); i <= ndocs; i += CONF_COLLECTION_DISTRIBUTED)
	{
		bool skip_meta_doc_retr = false;

		doc.docid = order[i];

		// Skip documents with 'nil' priority
		// Note that invalid values on order was setting to relative "unsigned max value"
		// and if on "unsigned 'max value'" we sum '1' it return '0'
		if (doc.docid == 0)
			continue;

		// Recover siteid from cache
		doc.siteid = docid_to_siteid[doc.docid];

		// Set relative instance
		instance_t silock = ((doc.siteid - 1) % CONF_COLLECTION_DISTRIBUTED);

		// Lock rw mutex in read-only mode for reading 'site_count' or 'manager_site_status'
		manager_rwlock_b(silock, true);

		retry:

		// Check if too many from the same site
		if (site_count[doc.siteid] >= CONF_MANAGER_BATCH_SAMESITE)
		// if (site_count[doc.siteid] >= 2)
		{
			manager_rwunlock_b(silock);
			continue; // Skip, too many from the same site
		}

		// Check if too many errors, or we are checking special files, or we already
		// know the site belongs to other harvester
		if (manager_site_status[doc.siteid]	== MANAGER_SITE_STATUS_TOO_MANY_ERRORS
//			|| manager_site_status[doc.siteid] == MANAGER_SITE_STATUS_CHECK_SPECIAL
			|| manager_site_status[doc.siteid] == MANAGER_SITE_STATUS_ASSIGNED_TO_OTHER_HARVEST)
		{
			order[i] = 0; // skip for possible next query
			manager_rwunlock_b(silock);
			continue; // Skip, site is busy
		}

		// Retrieve the actual metadata from the document
		if (skip_meta_doc_retr == false)
		{
			metaddx_status	= meta->doc_retrieve(&(doc));

			assert(metaddx_status == METADDX_OK);
			assert(doc.docid > 0 );
		}

		// Skip documents with special mimetypes (gestiti a monte)
		if (doc.mime_type == MIME_ROBOTS_TXT || doc.mime_type == MIME_ROBOTS_RDF || doc.mime_type == MIME_ROBOTS_RDF_BROKEN)
		{
			order[i] = 0; // skip for possible next query
			manager_rwunlock_b(silock);
			continue; // Skip, site is busy
		}

		// Check if already assigned
		if (doc.status == STATUS_DOC_ASSIGNED)
		{
			manager_rwunlock_b(silock);
			continue; // Skip, site is busy
		}

		bool new_site = false;
		bool retrieved_site = false;

		// Set site for eventual retrieving
		site.siteid = doc.siteid;

		// Check if this is the first doc of this site
		if (site_count[doc.siteid] == 0)
		{
			// change mutex type from rw (locked as read only) to another generic
			manager_lock_b(silock);

			if (site_count[doc.siteid] > 0)
			{
				manager_unlock_b(silock);
				skip_meta_doc_retr = true;
				goto retry;
			}

			manager_rwunlock_b(silock);

			// Retrieve the site
			metaddx_status = meta->site_retrieve(&(site));
			assert(metaddx_status == METADDX_OK);
			assert(site.siteid == doc.siteid);

			retrieved_site = true;

			// If it is assigned to other site
			if (site.harvest_id > 0 && site.harvest_id != harv->hv_id())
			{
				// Skip: assigned to other harvester
				manager_site_status[doc.siteid] = MANAGER_SITE_STATUS_ASSIGNED_TO_OTHER_HARVEST;
				order[i] = 0; // skip for possible next query
				manager_unlock_b(silock);
				continue;
			}
			else if (site.count_error > CONF_MAX_ERRORS_DIFFERENT_BATCH)
			{

				// Skip: too many errors
				count_erroneous_sites[inst]++;

				// Mark as erroneous site
				manager_site_status[doc.siteid]	= MANAGER_SITE_STATUS_TOO_MANY_ERRORS;
				order[i] = 0; // skip for possible next query
				manager_unlock_b(silock);
				continue;

//			}
//			else if (site.docid_robots_txt == doc.docid || site.docid_sitemap_rdf == doc.docid)
//			{
//			TODO
//				// Do not assign special docs here
//				order[i] = 0; // skip for possible next query
//				manager_unlock_b(silock);
//				continue;
// // verificare l'assenza di questo codice crea problemi (dovrebbe essere sostituito dal codice poco sopra in cui si menzionano i mime type)
			}
			else
			{
				// Mark as assigned to this harvester,
				// obviously the site must be unassigned first
				assert(site.harvest_id == 0);
				site.harvest_id = harv->hv_id();
				meta->site_store(&(site));
				site_count[doc.siteid]++;
				new_site = true;
			}

			manager_unlock_b(silock);
		}
		else
			manager_rwunlock_b(silock);

		manager_rwlock_b(silock, true);

		// Check if its necessary to store the site also for the harvester
		// Because is plausible that this condition is true for a number inferior or equal nsites
		// it's helpful use first a read-only mutex to improve performances
		if (manager_site_status[doc.siteid] != MANAGER_SITE_STATUS_STORED)
		{
			manager_lock_b(silock);
			manager_rwunlock_b(silock);

			if (manager_site_status[doc.siteid] != MANAGER_SITE_STATUS_STORED)
			{
				// Read the sitename
				url->site_by_siteid( site.siteid, sitename );

				// Retrieve the site
				if (retrieved_site == false)
				{
					metaddx_status = meta->site_retrieve(&(site));
					assert(metaddx_status == METADDX_OK);
					assert(site.siteid == doc.siteid);
				}

				// Give information to the harvest
				harv->append_site(&(site), sitename);

				// Mark as stored
				manager_site_status[doc.siteid]	= MANAGER_SITE_STATUS_STORED;

				// Count
				count_sites[silock]++;
			}
			
			manager_unlock_b(silock);
		}
		else
			manager_rwunlock_b(silock);

		path[0] = ASCII_NUL;

		// Retrieve the url
		url->path_by_docid(doc.docid, path);
		assert(path != NULL);

		// Mark the document as assigned
		order[i] = 0;
		doc.status = STATUS_DOC_ASSIGNED;

		meta->doc_store(&(doc));

		// Count
		depth_count[doc.depth]++;
		manager_harvest_doc_count++;

		manager_rwlock_b(silock, false);

		// Assign the document
		harv->append_doc(&(doc), path);

		if (new_site == false)
			site_count[doc.siteid]++;

		if (site_count[doc.siteid] == CONF_MANAGER_BATCH_SAMESITE)
			saturated_sites[silock]++;

		manager_rwunlock_b(silock);

		// Check if done
		if (manager_harvest_doc_count >= CONF_MANAGER_BATCH_SIZE)
			break;

		// Report
		if (batchsize_div_50 > 0 && manager_harvest_doc_count % batchsize_div_50 == 0)
			cerr << ".";
	}

	free(args);

	// need for syncronize exceptions without caller
	manager_sync_threads(manager_barrier);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(manager_barrier);
}
}

	
//
// Name: cleanup
//
// Description: 
//   Closes files and clean everything
//

void cleanup()
{
	if( harv != NULL ) {
		delete harv;
		cerr << "[harvest] ";
	}
	if( monitor != NULL ) {
		monitor->close();
		delete monitor;
		cerr << "[monitor] ";
	}
	if( meta != NULL ) {
		meta->ddx_close();
		delete meta;
		cerr << "[metaddx] ";
	}
	if( url != NULL ) {
		url->ddx_close();
		delete url;
		cerr << "[urlddx] ";
	}
	if( lidx != NULL ) {
		lidx->st_close();
		delete lidx;
		cerr << "[linkidx] ";
	}
	if( strg != NULL ) {
		strg->st_close();
		delete strg;
		cerr << "[storage] ";
	}
	if( priority != NULL ) {
		free(priority);
	}
	if( order != NULL ) {
		free(order);
	}
	if( docid_to_siteid != NULL ) {
		free(docid_to_siteid);
	}
}

//
// Name: manager_compare_by_priority
//
// Description:
//   Compare by priority function for stl
//
// Input:
//   a,b - docids
// 
// Output:
//   true if priority[a]<=priority[b]
//   

int manager_compare_by_priority( const void *a, const void *b ) {
	assert( priority != NULL );
	return( priority[(*((const docid_t *)a))-1] <= priority[(*((const docid_t *)b))-1] );
}

//
// Name: manager_open_indexes
//
// Description: 
//   Opens all indexes
//

void manager_open_indexes()
{
    cerr << "[metaddx] ";
	monitor = new Monitor (false);
	monitor->open();

	TALARM;

    cerr << "[metaddx] ";
	meta = new Meta ( COLLECTION_METADATA, false );
	meta->ddx_open();

	TALARM;

	cerr << "[linkidx] ";
	lidx = new Storage ( COLLECTION_LINK, true );
	lidx->st_open();

	TALARM;

	cerr << "[storage] ";
	strg = new Storage ( COLLECTION_TEXT, true );
	strg->st_open();

	TALARM;

	cerr << "[urlddx] ";
	url = new Url ( COLLECTION_URL, Url::RO );
	url->ddx_open();

	TALARM;
}

// Verify only

//
// Name: manager_verify_documents
//
// Description:
//   Check if indexes are consistent data
//
void *manager_thread_function_verify_documents(void *args)
{
try
{
	manager_thread_args_t *arguments = (manager_thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	everything_ok[inst] = true;

	docid_t ndocs_div_50 = ndocs / 50;

	docid_t docid;
	doc_t doc;

	for (docid = (inst + 1); docid <= ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
	{
		if( ndocs_div_50 > 0 && doc.docid % ndocs_div_50 == 0 )
			cerr << ".";

		doc.docid = docid;

		// Read the document
		meta->doc_retrieve(&(doc));

		if (doc.docid != docid)
		{
			mcerr << "DocID " << docid << " is damaged, appears as " << doc.docid << mendl;

			everything_ok[inst] = false;

			free(args);

			return NULL;
		}
	}

	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(NULL);
}
}

//
// Name: manager_thread_function_marking
//
// Description:
//   Check if indexes are consistent data
//
void *manager_thread_function_marking(void *args)
{
try
{
	manager_thread_args_t *arguments = (manager_thread_args_t *)args;

    instance_t inst = arguments->inst;
//	bool mark_dynamic = arguments->mark_dynamic;
//	bool mark_ignored = arguments->mark_ignored;

	CPU_OPTIMIZE;

	siteid_t nsites_div_50 = nsites / 50;
	site_t site;

#ifndef META_MAX_BUFFERING_SIZE
	for (site.siteid = (inst + 1); site.siteid <= nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		internal_long_uint_t expected = (site.siteid / 10) * 10;
		internal_long_uint_t next = expected + 10;

		// Report
		if (nsites_div_50 > 0 && (site.siteid % nsites_div_50 == 0) && print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
			cerr << ".";

		meta->site_retrieve(&(site));
		site.harvest_id = 0;
		meta->site_store(&(site));
	}
#else
	size_t size = (META_MAX_BUFFERING_SIZE > sizeof(site_t)) ? (META_MAX_BUFFERING_SIZE / sizeof(site_t)) : META_MIN_BUFFERING_SIZE;

	site_t *sites = CBALLOC(site_t, MALLOC, size);

	size_t o = 0;

	for (siteid_t siteid = (inst + 1); siteid <= nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		internal_long_uint_t expected = (siteid / 10) * 10;
		internal_long_uint_t next = expected + 10;

		// Report
		if (nsites_div_50 > 0 && (siteid % nsites_div_50 == 0) && print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
			cerr << ".";

		sites[o].siteid = siteid;
		o++;

		if (o == size)
		{
			if (o > 1)
				assert(meta->site_retrieve_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_retrieve(&sites[0]) == METADDX_OK);

			for (size_t i = 0; i < o; i++)
			{
				assert(sites[i].siteid > 0);
				assert(sites[i].siteid <= nsites);
		
				// set the data	
				sites[i].harvest_id		= 0;
			}

			// store full buffer
			if (o > 1)
				assert(meta->site_store_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_store(&sites[0]) == METADDX_OK);

			o = 0;
		}
		else if ((siteid + CONF_COLLECTION_DISTRIBUTED) > nsites)
		{
			if (o > 1)
				assert(meta->site_retrieve_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_retrieve(&sites[0]) == METADDX_OK);

			for (size_t i = 0; i < o; i++)
			{
				assert(sites[i].siteid > 0);
				assert(sites[i].siteid <= nsites);

				// set the data	
				sites[i].harvest_id		= 0;
			}

			// store full buffer or last chunck
			if (o > 1)
				assert(meta->site_store_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_store(&sites[0]) == METADDX_OK);

			o = 0;
		}

	}

	free(sites);
#endif

	manager_sync_threads(manager_barrier);

	// set for next reuse
	print_winner2.exchange(0);
	assert(print_winner2 == 0);

	ccerr << " ok" << endl << "Marking docs    |--------------------------------------------------|" << endl << "                ";

	manager_sync_threads(manager_barrier);

	docid_t ndocs_div_50 = ndocs / 50;

	doc_t doc;

	char path[MAX_STR_LEN];

	for (doc.docid = (inst + 1); doc.docid <= ndocs; doc.docid += CONF_COLLECTION_DISTRIBUTED)
	{
		if (ndocs_div_50 > 0 && doc.docid % ndocs_div_50 == 0)
			cerr << ".";

		meta->doc_retrieve(&(doc));
		assert(doc.docid > 0);

		if (doc.status == STATUS_DOC_ASSIGNED)
		{
			// I am marking the document as new
			// It might have been already crawled and it was here because it was going
			// to be re-crawled, but we don't know it.
			doc.status = STATUS_DOC_NEW;
			meta->doc_store(&(doc));
		}
	}

	free(args);

	// need for syncronize exceptions without caller
	manager_sync_threads(manager_barrier);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(manager_barrier);
}
}

//
// Name: manager_order_documents
//
// Description:
//   Sort the documents based on priority
//
void manager_order_documents() {

	// Generate default order; the default order will be the
	// newest URLs first; this does not means depth-first as
	// anyways the crawler respects the priority of pages
	for( docid_t i=1; i<=ndocs; i++ ) {
		order[i-1] = i;
	}

	// Quick Sort
	cerr << "[quicksort] ";
	qsort( order, ndocs, sizeof(docid_t), manager_compare_by_priority );
}

//
// Name: manager_usage
//
// Description:
//   Prints an usage message, then stops
//

void manager_usage() {
	cerr << "Usage: program [OPTION]" << endl;
	cerr << "Calculates scores and creates batches of documents"<< endl;
	cerr << "for the harvester" << endl;
	cerr << endl;
	cerr << " --dont-generate     only calculate, don't generate batch" << endl;
	cerr << " --verify-only       verify status of metaddx" << endl;
	cerr << " -c, --cancel        cancel all remaining harvests" << endl;
	cerr << " --exclude-site SITENAME predisposes all URLs from a Website to be excluded from collection" << endl;
	cerr << " --exclude-docid DOCID exclude single page from a Website from collection" << endl;
	cerr << " --include-site SITENAME predisposes all URLs from a Website to be REincluded inside collection" << endl;
	cerr << " --include-docid DOCID exclude single page from a Website inside collection" << endl;
	cerr << " --help              this help message" << endl;
	cerr << endl;
	cbot_stop(0);
}

