/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "harvester.h"
#include "xmlconf-main.h"

// need to debugging only one instance (activating only for hacking)
// #define DEBINST 3

thread_local cpu_set_t system_cpus;

char useragent[MAX_STR_LEN];
server_t **servers = NULL; // Notice that *servers[0] is always EMPTY
unsigned int HARVESTER_ID = 0;
bool languages_index_status = false;

//
// Name: main()
//
// Description:
//
int main(int argc, char **argv)
{
try
{
	cbot_start("harvester");

	// Scan for a harvester
	HARVESTER_ID = 0;
	harvest_status_t harvest_status = STATUS_HARVEST_EMPTY;

	// Parse options
	while(1) {
		int option_index = 0;
		static struct option long_options[] = {
			{"force", 1, 0, 0},
			{"debugonly", 0, 0, 0},
			{"showlanguages", 0, 0, 0},
			{"help", 0, 0, 0}
		};

		char c = getopt_long(argc, argv, "hdf:", long_options, &option_index);

		if (c == -1)
			break;

		switch(c) {
			case 0:
				if (!strcmp(long_options[option_index].name, "force"))
					HARVESTER_ID = atol(optarg);
				else if (!strcmp(long_options[option_index].name, "debugonly"))
					debugonly = true;
				else if (!strcmp(long_options[option_index].name, "showlanguages"))
					showlanguages = true;
				else if (!strcmp(long_options[option_index].name, "help"))
					harvester_usage();
			break;
			case 'f':
				HARVESTER_ID = atol(optarg);
			break;
			case 'd':
				debugonly = true;
			break;
			case 's':
				showlanguages = true;
			break;
			case 'h':
				harvester_usage();
			break;
			default:
				harvester_usage();
			break;
		}
	}

	// Reading configuration files of languages
	if (! (showlanguages == true && debugonly == true))
		cerr << "Prepare index of languages ... ";

	// Initialize languages index
	languages_index_status = server_init_languages();

	if (languages_index_status == false)
		die("Failed to prepare languages!");
	else
	{
		if (showlanguages == true && debugonly == true)
			cbot_stop(0);
		else
			cerr << "done." << endl;
	}

	// Open harvester
	harv = new Harvest (COLLECTION_HARVEST, true);
	assert(harv != NULL);

	// Check if a HARVESTER_ID was passed
	if (HARVESTER_ID == 0)
		HARVESTER_ID = harv->assigned_id();
	else // If the harvest exists, and we were forced to do it,
	{	// we should first remove temporary files from the harvest
		if (debugonly == false && harv->is_found(HARVESTER_ID) == true)
			harv->hv_remove_files(HARVESTER_ID);
	}

	if (thread_alarm != THREADS_OK)
	{
		delete harv;
		harv = NULL;
		die("Failed to checking harvestid %u!", HARVESTER_ID);
	}

//	HARVESTER_ID = 3; // TODO forzato a 0 provvisorio

	// Open harvester and change the read-only mode
	if (debugonly == true)
		harvest_status = harv->hv_open(HARVESTER_ID, true);
	else
		harvest_status = harv->hv_open(HARVESTER_ID, false);

	if (harvest_status == STATUS_HARVEST_ABORTED || thread_alarm != THREADS_OK)
	{
		delete harv;
		harv = NULL;
		die("Failed to open harvest (%u)!", HARVESTER_ID);
	}	

	if (HARVESTER_ID == 0 || harvest_status == STATUS_HARVEST_DONE)
	{
		syslog(LOG_NOTICE, "harvester has no tasks to do. You may force a task with --force harvest_id");
		delete harv;
		harv = NULL;
		cbot_stop(1);
	}

	// Initialize parser
	parser_init();

	// Init useragent
	struct utsname myname;
	uname(&(myname));

	sprintf(useragent, "%s/%s (%s; %s%s; %s)",
		"Mozilla",
		"5.0",
		"compatible",
		SPIDERNAME,		
		"/2.0",
		CONF_HARVESTER_USER_AGENT_COMMENT);

	cerr << "User-Agent is " << useragent << endl;

	// assert(MAX_DOC_LEN > CONF_MAX_FILE_SIZE);

	// Init forbidden IPs
	perfhash_t blocked_ip;
	blocked_ip.check_matches = true;
	perfhash_create(&(blocked_ip), CONF_HARVESTER_BLOCKED_IP);
	cerr << "- Blocked IP: " << CONF_HARVESTER_BLOCKED_IP << endl;

	perfhash_t accept_protocol;
	accept_protocol.check_matches = true;
	perfhash_create(&(accept_protocol), CONF_SEEDER_LINK_ACCEPT_PROTOCOL);
	cerr << "- Accepted protocols: " << CONF_SEEDER_LINK_ACCEPT_PROTOCOL << endl;

	if (perfhash_check(&(accept_protocol), (char *)"https") == true)
	{
		cerr << "Loading file of Certification Authority ... ";

		ifstream inFile;  //input file stream variable

		inFile.open(CONF_HARVESTER_CA); //open the Certification Authority file 'pem' format

		if (inFile)
		{
			// posiziona in cursore alla fine del file per rilevarne la lunghezza per poi riposizionarlo all'inizio:
			inFile.seekg (0, ios::end);
			CAlen = inFile.tellg();
			inFile.seekg (0, ios::beg);

			// alloca la memoria del wlinbuf:
			CA = CBALLOC(char, NEW, (CAlen + 1));

			// legge i dati in un unico blocco:
			inFile.read (CA,CAlen);
			CA[CAlen] = '\0';

			if (CAlen <= 0)
			{
				inFile.close();
				die("Missing Certification Authority file!");
			}
		}

		cerr << "done" << endl;
	}

	if (debugonly == false)
	{
		cerr << "Opening indexes ... ";

		// We don't need open urlddx index, but we have the need to use only functions inside Url class.
		cerr << "[url] ";
		url = new Url (COLLECTION_URL, Url::RO_MEMORY);
		url->ddx_open();

		TALARM;

		cerr << "[storage] ";
		strg = new Storage (COLLECTION_TEXT, false);
		strg->st_open();

		TALARM;

		cerr << "[roboidx] ";
		ridx = roboidx_open(COLLECTION_ROBOTS, false);

		TALARM;

		cerr << "[metadata] ";
		meta = new Meta (COLLECTION_METADATA, false);
		meta->ddx_open();

		TALARM;

		cerr << "[linkidx] ";
		lidx = linkidx_open(COLLECTION_LINK, false);

		TALARM;
	}

	// Prepare harvester
	harv->prepare(HARVESTER_ID, debugonly);

	if (thread_alarm != THREADS_OK)
		die("Failed to prepare harvest!");

	// Prepare for robots.txt
	if (CONF_SEEDER_ADD_ROBOTSTXT == true)
	{
		robots_txt_rules = CBALLOC(char **, MALLOC, CONF_COLLECTION_DISTRIBUTED);
		robots_txt_rules_size = CBALLOC(ssize_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	}
	else
	{
		robots_txt_rules = NULL;
		robots_txt_rules_size = NULL;
	}

	robots_txt_ndocs_done = 0;

	// prepare c-ares async resolver
	ares_channel *a_channel = CBALLOC(ares_channel, NEW, CONF_COLLECTION_DISTRIBUTED);
	struct ares_options *a_options = CBALLOC(ares_options, CALLOC, 1);
	int a_optmask = 0;
	//	only for knowing ares options ...
	//	ARES_OPT_FLAGS ARES_OPT_TRIES ARES_OPT_NDOTS ARES_OPT_UDP_PORT
	//	ARES_OPT_TCP_PORT ARES_OPT_SOCK_STATE_CB ARES_OPT_SERVERS
	//	ARES_OPT_DOMAINS ARES_OPT_LOOKUPS ARES_OPT_SORTLIST ARES_OPT_TIMEOUTMS

	int a_status;

	a_status = ares_library_init(ARES_LIB_INIT_ALL);

	if (a_status == ARES_SUCCESS)
	{
		links_download = CBALLOC(FILE *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
		links_log = CBALLOC(FILE *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
		links_stat = CBALLOC(FILE *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
		servers = CBALLOC(server_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		// Init resolver
		server_resolver_prepare();

//		a_options->flags = ARES_FLAG_NOCHECKRESP; // experimental
		//options.sock_state_cb = state_cb;
		a_optmask |= ARES_OPT_SERVERS; // we want use our nameserver list assigned with function 'ares_set_servers'
		a_options->servers = NULL;
		a_options->nservers = 0;

		a_optmask |= ARES_OPT_SOCK_STATE_CB;
		a_options->sock_state_cb = NULL;
		a_optmask |= ARES_OPT_TIMEOUTMS;
		a_options->timeout = (CONF_HARVESTER_DNSTIMEOUT * 1000); // in milliseconds
		a_optmask |= ARES_OPT_TRIES;
		a_options->tries = 5; // before ares give request ares try 5 times each with timeout of options
		// Not only after normal tries we give a last chance for retry a new operation

		int rc = 0;
		pthread_mutexattr_t attr;

		pthread_t *threads = NULL;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

			// setup mutex of storage
			strg->setmutex(&strglock);

			harvester_barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

			pthread_barrier_init(harvester_barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

			parser_mutex = CBALLOC(pthread_mutex_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

			for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++) parser_mutex[inst] = PTHREAD_MUTEX_INITIALIZER;

			if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
				die("error setting mutex type %s", strerror(rc));

			if ((rc = pthread_mutexattr_init(&attr)) != 0)
				die("error creating mutex with attributes object %s", strerror(rc));
		}

		for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
		{
			harvester_thread_args_t *args = CBALLOC(harvester_thread_args_t, MALLOC, 1);
		    args->inst = inst;
			args->status = harvest_status;
			args->a_channel = &a_channel[inst];
			args->a_options = a_options;
			args->a_optmask = &a_optmask;
			args->blocked_ip = &blocked_ip;
			args->accept_protocol = &accept_protocol;

			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				if (pthread_create(&threads[inst], NULL, harvester_thread_function_main_setup, (void *) args))
					die("error creating thread!");
			}
			else
				harvester_thread_function_main_setup((void *) args); // only one distribution, function is call without thread 
		}

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

			free(threads);

			for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++) pthread_mutex_destroy(&(parser_mutex[inst]));

			free(parser_mutex); parser_mutex = NULL;

			pthread_barrier_destroy(harvester_barrier);

			free(harvester_barrier); harvester_barrier = NULL;

			int rc = 0;

			if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
				die("error destroying mutex with attributes object %s", strerror(rc));

			// destroy mutex of storage
			strg->destroymutex();
		}
	}
	else
		die("ares_library_init: %s", ares_strerror(a_status));

	if (CONF_SEEDER_ADD_ROBOTSTXT == true)
	{
		free(robots_txt_rules);
		free(robots_txt_rules_size);
	}

	free(servers);

	if (perfhash_check(&(accept_protocol), (char *)"https") == true)
		delete [] CA;

	free(a_options);
	delete [] a_channel;
	ares_library_cleanup();

	// Reset counters
	off64_t bytes_in = 0;
	off64_t bytes_out = 0;

	// Give the sums of all instance of bytes_in and bytes_out
	harv->hv_bytes_sum(bytes_in, bytes_out);

	if (thread_alarm == THREADS_OK && downloads_ok == false)
		die("Zero documents downloaded! Please check network and the 'resolvconf' variable in the configuration file");

	// Number of bytes
	cerr << "Total network usage:" << endl;
	cerr << "BYTES_IN  : " << bytes_in << endl;
	cerr << "BYTES_OUT : " << bytes_out << endl;

	time_t endtime = time(NULL);
	cerr << ctime(&endtime);

	parser_close();

	perfhash_destroy(&(accept_protocol)); // si cancella il riferimento creato dentro main
	perfhash_destroy(&(blocked_ip));

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}
}

// threads sync
void harvester_sync_threads(pthread_barrier_t *barrier)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc = pthread_barrier_wait(barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
        pthread_exit(NULL);
}

//
// Name: harvester_thread_function_main_setup
// 
// Description: scheduling special files such as robots.txt or sitemap.rdf
//
// Input: pointer to void
//
// Return:
//
void *harvester_thread_function_main_setup(void *args)
{
try
{
	harvester_thread_args_t *arguments = (harvester_thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	harvest_status_t harvest_status = arguments->status;
	ares_channel *a_channel = arguments->a_channel;
	const struct ares_options *a_options = arguments->a_options;
	const int *a_optmask = arguments->a_optmask;
	perfhash_t *blocked_ip = arguments->blocked_ip;
	perfhash_t *accept_protocol = arguments->accept_protocol;

	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_HARVEST, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);

	ccerr << "Opening links output files ... " << endl;

	harvester_sync_threads(harvester_barrier);

	errno = 0; // errno is thread-local

	if (debugonly == false)
	{
		// Open output files for saving links
		char links_download_filename[MAX_STR_LEN];
		sprintf(links_download_filename, "%s/%s/%d/%s", relative_rem_path, COLLECTION_LINK, HARVESTER_ID, FILENAME_LINKS_DOWNLOAD);
		links_download[inst] = fopen64(links_download_filename, "w");
		assert(links_download[inst] != 0);

		harvester_sync_threads(harvester_barrier);
    	    

		ccerr << "links_download ok. " << endl;

		char links_log_filename[MAX_STR_LEN];
		sprintf(links_log_filename, "%s/%s/%d/%s", relative_rem_path, COLLECTION_LINK, HARVESTER_ID, FILENAME_LINKS_LOG);
		links_log[inst] = fopen64(links_log_filename, "w");
		assert(links_log[inst] != 0);

		harvester_sync_threads(harvester_barrier);
    	    

		ccerr << "links_log ok." << endl;

		char links_stat_filename[MAX_STR_LEN];
		sprintf(links_stat_filename, "%s/%s/%d/%s", relative_rem_path, COLLECTION_LINK, HARVESTER_ID, FILENAME_LINKS_STAT);
		links_stat[inst] = fopen64(links_stat_filename, "w");
		assert(links_stat[inst] != 0);

		harvester_sync_threads(harvester_barrier);
    	    

		ccerr << "links_stats ok." << endl;
	}

	// get nserver on instance
	// Notice that servers[0] is EMPTY, servers start at position 1.
	docid_t NDOCS = harv->hv_doc_count(inst);

	harvester_sync_threads(harvester_barrier);
        

	// Get memory for the servers structure
	// the servers start at 1.
	if (NDOCS == 0)
	{
		mcerr << BRO << "Warning:" << NOR << " On instance " << (unsigned int)inst << " process is terminated prematurely because don't have documents." << mendl;

		#ifndef DEBINST
			robots_txt_ndocs_done += meta->instance_site_count(inst);
		#endif

		for (unsigned char s = 0; s <= 10; s++)
			harvester_sync_threads(harvester_barrier);

		// set the status on harvest to done
		if (debugonly == false)
			harv->done(inst);

		// set the end time on harvest to done
		harv->set_end(inst);

		if (debugonly == false)
		{
			int rc = 0;

			rc = fclose(links_download[inst]);

			if (errno != 0)
				die("Harvester: error closing downloads file %s", cberr());

			assert(rc == 0);

			rc = fclose(links_log[inst]);

			if (errno != 0)
				die("Harvester: error closing log file %s", cberr());

			assert(rc == 0);

			rc = fclose(links_stat[inst]);

			if (errno != 0)
				die("Harvester: error closing stat file %s", cberr());

			assert(rc == 0);
		}

		free(args);

		return NULL;
	}

	harvester_sync_threads(harvester_barrier);
        

	// get nserver on instance
	// Notice that servers[0] is EMPTY, servers start at position 1.
	siteid_t NSERVERS = harv->hv_site_count(inst);

	assert(NSERVERS > 0);

	ccerr << "                   |--------------------------------------------------|" << endl << "Reading sites:     ";

	harv->read_list(inst);

	servers[inst] = CBALLOC(server_t, CALLOC, (NSERVERS + 1));

	// Add servers to the servers queue
	// Notice that servers[0] is EMPTY, servers start at position 1.
	// atomic<docid_t> progress (0); // non dovrebbe essere necessario tipo atomico
	docid_t progress = 0;

	// prepare main struture to pass at functions
	starter_t *starter = CBALLOC(starter_t, NEW, 1);
	starter->inst = inst;
	starter->harvest_id = HARVESTER_ID;
	starter->harvest_status = harvest_status;
	starter->links_download = links_download[inst];
	starter->links_log = links_log[inst];
	starter->links_stat = links_stat[inst];
	starter->servers = servers[inst];
	starter->a_channel = a_channel;
	starter->a_options = a_options;
	starter->a_optmask = a_optmask;
	starter->testing = false;
	starter->m_cookie = magic_open(MAGIC_ERROR|MAGIC_MIME_TYPE);

	// Load magic database to detect a file type
	if (starter->m_cookie == NULL)
		die("Harvester: unable to initialize magic library\n");
	else if (magic_load(starter->m_cookie, NULL) != 0)
	{
		const char *magic_err_str = magic_error(starter->m_cookie);
		magic_close(starter->m_cookie);

		if (magic_err_str)
			die("Harvest: cannot load magic database - %s\n", magic_err_str);
	}

	// setup c-ares channel
	server_resolver_set(starter, inst, HARVESTER_ID);

	// map siteid - serverid
	map <siteid_t,unsigned int> map_servers;

	// prepare sequential reading for robots.txt rules on instance
	ridx->prepare_sequential_read(inst);

	harvester_sync_threads(harvester_barrier);
        

	for (siteid_t serverid = 1; serverid <= NSERVERS; serverid++)
	{
		// Report progress
		progress++;

		if (progress == (NSERVERS / 50))
		{
			progress = 0;
			cerr << ".";
		}

		site_t *site = harv->hv_site_list(inst, serverid);
		const char *hostname = harv->hv_hostname_map(inst, site->siteid);

		if (hostname == NULL || strlen(hostname) == 0)
		{
			mcerr << "Warning! Site " << site->siteid << " has empty hostname, default to null.localdomain" << mendl;
		}

		// Copy to map
		assert(site != NULL);
		assert(site->siteid > (siteid_t)0);
		map_servers[site->siteid] = serverid;

		// Copy to site
		server_copy_site(&(servers[inst][serverid]), starter, site, hostname, serverid);
	}

	harvester_sync_threads(harvester_barrier);
        

	ccerr << " ok" << endl << "Reading documents: ";

	// Add documents
	progress = 0;
 
	for (docid_t i = 0; i < NDOCS; i++)
	{
		doc_t *doc = harv->hv_doc_list(inst, i);
		assert(doc->docid > 0);
		assert(doc->siteid > 0);

		progress++;

		if (progress == (NDOCS / 50))
		{
			progress = 0;
			cerr << ".";
		}

		// Locate the server
		server_t *server = &(servers[inst][map_servers[doc->siteid]]);

		// Locate the path
		const char *path = harv->hv_path_map(inst, doc->docid);
		assert(path != NULL);

		// This document is from this server
		assert(doc->siteid == server->site->siteid);

		page_t *page = CBALLOC(page_t, MALLOC, 1);
		page->next	= NULL;
		page->doc	= doc;

		// Insert at the end of the Linked List
		if (server->pages == NULL)
			server->pages = page;
		else
		{
			page_t *ptr = server->pages;

			while(ptr->next != NULL)
			{
				ptr = ptr->next;
			}

			ptr->next	= page;
		}

		// Copy path 
		assert(strlen(path) < MAX_STR_LEN);
		strcpy(page->path, path);

		// Keep original mime_type
		page->mime_type = doc->mime_type;

		// Prepare variables
		page->src_path = NULL; // needed for 'instant' relocation, keeping original 'page->path'
		page->buffer_one = NULL;
		page->bo_size = 0;
		page->bo_net_bodysize = 0;
		page->buffer_two = NULL;
		page->bt_size = 0;
		page->buffer_links_download = NULL;
		page->bld_size = 0;
		page->buffer_links_log = NULL;
		page->bll_size = 0;
		page->redirect_is_relative = false;
		page->relocation[0]	= '\0';
		page->attempts = 0;
		page->is_fqdn_request = false;
		page->redirect_with_invalid_path = false;
		page->peer_close = false;
		page->z_strm = NULL;
		page->z_ofs = 0;

		server->ndocs++;

		// If the page was not ok, don't use
		// last_visited information
		if ((HTTP_IS_OK(doc->http_status) == false || doc->http_status == HTTP_NOT_MODIFIED))
			doc->last_visit	= 0;

		// Set initial parameters for this request
		doc->raw_content_length = 0;
		doc->http_status	= HTTP_STATUS_UNDEFINED;
		doc->chunked		= false;
		doc->content_encoding	= ENCODING_NONE;

		// Blank values for measuring times
		timerclear(&(page->timestamp_begin_connect));
		timerclear(&(page->timestamp_end_connect));
		timerclear(&(page->timestamp_first_read));
		timerclear(&(page->timestamp_last_read));

		page->bytes_first_packet	= 0;
		page->bytes_total			= 0;

	}

	harvester_sync_threads(harvester_barrier);
        

	if (CONF_SEEDER_ADD_ROBOTSTXT == true)
	{
		ccerr << " ok" << endl << "Loading robots.txt rules: ";

		// Load robots.txt rules on buffer
		robots_txt_rules[inst] = CBALLOC(char *, MALLOC, meta->instance_site_count(inst));
		robots_txt_rules_size[inst] = CBALLOC(ssize_t, CALLOC, meta->instance_site_count(inst));

		progress = 0;
 
		siteid_t skip = 0;

		// prepare robots_txt buffers
		for (siteid_t site_offset = 0; site_offset < meta->instance_site_count(inst); site_offset++)
		{
			// Report progress
			progress++;

			if (progress == (meta->instance_site_count(inst) / 50))
			{
				progress = 0;
				cerr << ".";
			}

			siteid_t siteid = ((site_offset * CONF_COLLECTION_DISTRIBUTED) + inst + 1);

			auto search = map_servers.find(siteid);

			// site not loaded on harvest and we are
			// sure, this site is already visited at least one time
			if (search == map_servers.end())
			{
				site_t site;
				site.siteid = siteid;

				metaddx_status_t rc = meta->site_retrieve(&site);

				assert(rc == METADDX_OK);

				if (meta->site_option_get(site.siteid, SITE_OPT_VRTXT, true) == METADDX_OK)
				{
					// Because robots.txt must be ALWAYS the first document of the list,
					// if present there is not need of loading it on buffer now
					/* It will loaded after download the page
					if (servers[inst][search->second].pages->mime_type == MIME_ROBOTS_TXT)
					{
						robots_txt_rules[inst][site_offset] = NULL;
						skip++;
						continue;
					} */

					doc_t doc;
					doc.docid = site.docid_robots_txt;

					metaddx_status_t rc = meta->doc_retrieve(&doc);

					assert(rc == METADDX_OK);

					if (doc.content_length > 0)
					{
						assert(doc.mime_type == MIME_ROBOTS_TXT);

						robots_txt_rules[inst][site_offset] = CBALLOC(char, MALLOC, (doc.content_length + 1));

						storage_record_t rec;

						if (skip > 0)
						{
							ridx->sequential_skip(inst, skip);
							skip = 0;
						}

						// store robots_txt rules inside buffer
						storage_status_t rc = ridx->sequential_read(inst, &(rec), robots_txt_rules[inst][site_offset]);

						assert(rc == STORAGE_OK);
						assert(rec.size == doc.content_length);

						robots_txt_rules_size[inst][site_offset] = (ssize_t)doc.content_length;
					}
					else
					{
						robots_txt_rules[inst][site_offset] = NULL;
						skip++;
					}
				}
				else
				{
					robots_txt_rules[inst][site_offset] = NULL;
					skip++;
				}

				#ifndef DEBINST
					robots_txt_ndocs_done++;
				#endif
			}
			else
			{
				// Because robots.txt must be ALWAYS the first document of the list,
				// if present there is not need of loading it on buffer now
				// It will loaded after download the page
				if (servers[inst][search->second].pages->mime_type == MIME_ROBOTS_TXT)
				{
					robots_txt_rules[inst][site_offset] = NULL;
					skip++;
					continue;
				}

				docid_t docid_robots_txt = servers[inst][search->second].site->docid_robots_txt;

				if (docid_robots_txt > 0)
				{
					doc_t doc;
					doc.docid = docid_robots_txt;

					metaddx_status_t rc = meta->doc_retrieve(&doc);

					assert(rc == METADDX_OK);

					if (doc.content_length > 0)
					{
						assert(doc.mime_type == MIME_ROBOTS_TXT);

						robots_txt_rules[inst][site_offset] = CBALLOC(char, MALLOC, (doc.content_length + 1));

						storage_record_t rec;

						if (skip > 0)
						{
							ridx->sequential_skip(inst, skip);
							skip = 0;
						}

						// store robots_txt rules inside buffer
						storage_status_t rc = ridx->sequential_read(inst, &(rec), robots_txt_rules[inst][site_offset]);

						assert(rc == STORAGE_OK);
						assert(rec.size == doc.content_length);

						robots_txt_rules_size[inst][site_offset] = (ssize_t)doc.content_length;
					}
					else
					{
						robots_txt_rules[inst][site_offset] = NULL;
						skip++;
					}
				}
				else
				{
					robots_txt_rules[inst][site_offset] = NULL;
					skip++;
				}

				#ifndef DEBINST
					robots_txt_ndocs_done++;
				#endif
			}
		}

		harvester_sync_threads(harvester_barrier);


		ccerr << " ok" << endl << "Find document to exclude following the robots.txt's rules inside storage or our politics rules: ";

		progress = 0;
 
		// check local path for excluding if present in robots.txt of the SAME site
		// the hrefs present in web document are checked during parsing of pages
		for (siteid_t site_offset = 0; site_offset < meta->instance_site_count(inst); site_offset++)
		{
			// Report progress
			progress++;

			if (progress == (meta->instance_site_count(inst) / 50))
			{
				progress = 0;
				cerr << ".";
			}

			siteid_t siteid = ((site_offset * CONF_COLLECTION_DISTRIBUTED) + inst + 1);

			auto search = map_servers.find(siteid);

			if (search == map_servers.end()); // Ignore
			else if (meta->site_option_get(servers[inst][search->second].site->siteid, SITE_OPT_VRTXT, true) == METADDX_OK)
			{
				server_t *server = &(servers[inst][search->second]);

				// Check if there are docs in all harvest collection
				// that are to be excluded and if site is excluded
				// mark excluded ALL his document
				if (meta->site_option_get(server->site->siteid, SITE_OPT_DENY, true) == METADDX_OK)
				{
					page_t *start_page = server->pages;

					while (server->pages != NULL)
					{
						// mark document for function 'activepool_process_nopoll'
						server->pages->doc->status = STATUS_DOC_EXCLUSION;

						server->pages = server->pages->next;
					}

					server->pages = start_page;
				}
				else
				{
					time_t now = time(NULL);

					// If server have to read his file robots.txt, then ignore.
					if (server->pages->mime_type == MIME_ROBOTS_TXT) continue;

					page_t *start_page = server->pages;

					while (server->pages != NULL)
					{
						bool disallow = parser_check_robotstxt(server);

						// mark document for function 'activepool_process_nopoll'
						if (disallow == true)
						{
							server->pages->doc->status = STATUS_DOC_FORBIDDEN;
							server->pages->doc->number_visits++;
							server->pages->doc->last_visit = now;
						}

						server->pages = server->pages->next;
					}

					server->pages = start_page;
				}
			}
		}

		harvester_sync_threads(harvester_barrier);
        

		ccerr << " ok" << endl; // end of 'init servers'
	}
	else
	{
		#ifndef DEBINST
			robots_txt_ndocs_done += meta->instance_site_count(inst);
		#endif

		ccerr << " ok" << endl << "Find document to exclude following our politics rules: ";

		progress = 0;
 
		// check local path for excluding if present in robots.txt of the SAME site
		// the hrefs present in web document are checked during parsing of pages
		for (siteid_t site_offset = 0; site_offset < meta->instance_site_count(inst); site_offset++)
		{
			// Report progress
			progress++;

			if (progress == (meta->instance_site_count(inst) / 50))
			{
				progress = 0;
				cerr << ".";
			}

			siteid_t siteid = ((site_offset * CONF_COLLECTION_DISTRIBUTED) + inst + 1);

			auto search = map_servers.find(siteid);

			if (search == map_servers.end()); // Ignore
			else if (meta->site_option_get(servers[inst][search->second].site->siteid, SITE_OPT_VRTXT, true) == METADDX_OK)
			{
				server_t *server = &(servers[inst][search->second]);

				// check if there are docs in all harvest collection
				// that are to be excluded
				if (meta->site_option_get(server->site->siteid, SITE_OPT_DENY, true) == METADDX_OK)
				{
					page_t *start_page = server->pages;

					while (server->pages != NULL)
					{
						// mark document for function 'activepool_process_nopoll'
						server->pages->doc->status = STATUS_DOC_EXCLUSION;

						server->pages = server->pages->next;
					}

					server->pages = start_page;
				}
			}
		}

		harvester_sync_threads(harvester_barrier);
        

		ccerr << " ok" << endl; // end of 'init servers'
	}

	harvester_sync_threads(harvester_barrier);
        

	// Init the auxiliary structures
	siteid_t POOLSIZE = CONF_HARVESTER_NTHREADS_START < NSERVERS ? CONF_HARVESTER_NTHREADS_START : (NSERVERS + 1);

	// Create the waiting queue
	waitq_t *waitq = waitq_create(NSERVERS);
	assert(waitq != NULL);

	// Directory name
	char filename[MAX_STR_LEN];
	sprintf(filename, "%s/%s/%s", CONF_COLLECTION_BASE, relative_rem_path, POLLVEC_FILENAME_LOG);

	// Open polling vector
	FILE *pollvec_log;

	// Check verbosity level
	if (CONF_HARVESTER_LOGLEVEL == LOGLEVEL_VERBOSE)
	{
		if (debugonly == false)
		{
				pollvec_log = fopen64(filename, "w");

				if (pollvec_log == NULL)
					perror(filename);

				assert(pollvec_log != NULL);
				setbuf(pollvec_log, NULL);
		}
		else
			pollvec_log = NULL;

	} else 
		pollvec_log = NULL;

	// creating active pool ...
	pollvec_t *pollvec = pollvec_create((POOLSIZE * 2) + 1, pollvec_log);
	assert(pollvec != NULL);

	activepool_t *activepool	= activepool_create(POOLSIZE, pollvec, useragent, blocked_ip, relative_rem_path);
	assert(activepool != NULL);

	// Set timing for waiting queue
	time_t now = time(NULL);

	// Preparing waiting queue, giving precedence to server that have
	// robots.txt to download first (this special setups happens only here)
	for (siteid_t serverid = 1; serverid <= NSERVERS; serverid++)
	{
		if (servers[inst][serverid].pages->mime_type == MIME_ROBOTS_TXT)
		{
			waitq_push(waitq, serverid, (now - 1));
		  	assert(server_has_more_documents(&(servers[inst][serverid])));
		}
		else
		{
			waitq_push(waitq, serverid, now);
		  	assert(server_has_more_documents(&(servers[inst][serverid])));
		}
	}

	mcerr << "On instance " << (unsigned int)inst << " created active pool of size " << POOLSIZE << " and created waiting queue for " << NSERVERS << " servers." << mendl;

	time_t last_minidump	= time(NULL);

	#ifdef DEBINST
		if (DEBINST < CONF_COLLECTION_DISTRIBUTED && inst != DEBINST)
		{
			if (CONF_SEEDER_ADD_ROBOTSTXT == true)
				robots_txt_ndocs_done += meta->instance_site_count(inst);

			harvester_sync_threads(harvester_barrier);


			return NULL;
		}
		else
		{
			if (CONF_SEEDER_ADD_ROBOTSTXT == true)
			{
				for (siteid_t serverid = 1; serverid <= NSERVERS; serverid++) // TODO testing
				{
					if (servers[inst][serverid].pages->mime_type != MIME_ROBOTS_TXT)
						robots_txt_ndocs_done++;
				}
			}

			harvester_sync_threads(harvester_barrier);

		}
	#endif

	// Main loop
	do
	{
		time_t now = time(NULL);

		assert(robots_txt_ndocs_done <= meta->site_count());

		// Show a minidump, but every 10 seconds at most
		if (now - last_minidump > 10)
		{
			activepool_minidump(activepool, waitq, inst);
			last_minidump	= now;
		}

		if (activepool_empty(activepool) && !waitq_empty(waitq) && !waitq_available(waitq,now))
			sleep(CONF_HARVESTER_TIMEOUT_POLL/1000); // in seconds

//		waitq_dump(waitq);

		while (activepool_has_free_slots(activepool) && waitq_available(waitq, now))
			activepool_fill(activepool, waitq, servers[inst]);

//		activepool_dump(activepool, servers[inst]);

		// Process the activepool
		if	(!activepool_empty(activepool))
			activepool_process(activepool, waitq, *accept_protocol, starter);

		// If we have things in the waitq, but we have
		// too few threads running, cancel the rest of the waitq
		if (!waitq_empty(waitq))
		{
			siteid_t current_threads = waitq->nservers + activepool->nactive_poll + activepool->nactive_nopoll;

			if ((((unsigned int)(now - harv->begin()) > CONF_HARVESTER_NTHREADS_SOFTMINTIME) && (current_threads < CONF_HARVESTER_NTHREADS_SOFTMIN)) ||
				(current_threads < CONF_HARVESTER_NTHREADS_HARDMIN))
			{
				// There are too few servers available, cancel the rest
				if (current_threads < CONF_HARVESTER_NTHREADS_HARDMIN)
				{
					mcerr << "On instance " << (unsigned int)inst << " Hard minimum of servers reached" << mendl;
				}
				else
				{
					mcerr << "On instance " << (unsigned int)inst << " Soft minimum of servers reached" << mendl;
				}

				mcerr << "On instance " << (unsigned int)inst << " Too few servers available (" << current_threads << "), canceling the rest" << mendl;

				// Empty the waitq by skipping all documents
				while (!waitq_empty(waitq))
				{
					siteid_t serverid;
					time_t nextvisit;
					waitq_pop(waitq, &(serverid), &(nextvisit));

					server_t *server;
					server = &(servers[inst][serverid]);
					cerr << "Cancelling " << server->hostname << " with " << server->ndocs_done << " of " << server->ndocs << " pages retrieved." << endl;
					server_skip_all(starter, serverid, HTTP_ERROR_SKIPPED);
				}
			}
		}
	}
	while (!(waitq_empty(waitq) && activepool_empty(activepool)) && thread_alarm == THREADS_OK);

	harvester_sync_threads(harvester_barrier);

	// Close magic database to detect a file type
	magic_close(starter->m_cookie);


	if (CONF_SEEDER_ADD_ROBOTSTXT == true)
	{
		for (siteid_t site_offset = 0; site_offset < meta->instance_site_count(inst); site_offset++)
		{
			if (robots_txt_rules[inst][site_offset] != NULL)
			free(robots_txt_rules[inst][site_offset]);
		}

		harvester_sync_threads(harvester_barrier);

		free(robots_txt_rules[inst]);
		robots_txt_rules[inst] = NULL;
		free(robots_txt_rules_size[inst]);
	}

	delete [] starter;

	// this is not good
	if (thread_alarm != THREADS_OK)
	{
		free(relative_rem_path);

		free(args);

		return NULL;
	}
	
	// Check if nothing could be downloaded
	if (activepool->ok == 0)
	{
		mcerr << BRO << "Warning:" << NOR << " On instance " << (unsigned int)inst << " Zero documents downloaded!" << mendl;
	}
	else downloads_ok = true;

	harvester_sync_threads(harvester_barrier);

	// Save sites
	if (debugonly == false)
		activepool_save_sites(activepool, servers[inst], NSERVERS);

	// Done
	activepool_destroy(activepool);

	free(servers[inst]);
	servers[inst] = NULL;

	// set the status on harvest to done
	if (debugonly == false)
		harv->done(inst);

	// set the end time on harvest to done
	harv->set_end(inst);

	if (CONF_HARVESTER_LOGLEVEL == LOGLEVEL_VERBOSE  && debugonly == false)
			fclose(pollvec_log);

	pollvec_destroy(pollvec);
	waitq_destroy(waitq);

	if (debugonly == false)
	{
		int rc = 0;

		errno = 0; // errno is thread-local

		rc = fclose(links_download[inst]);

		if (errno != 0)
			die("Harvester: error closing downloads file %s", cberr());

		assert(rc == 0);

		rc = fclose(links_log[inst]);

		if (errno != 0)
			die("Harvester: error closing log file %s", cberr());

		assert(rc == 0);

		rc = fclose(links_stat[inst]);

		if (errno != 0)
			die("Harvester: error closing stat file %s", cberr());

		assert(rc == 0);
	}

	free(relative_rem_path);

	free(args);

	// need for syncronize exceptions without caller
	harvester_sync_threads(harvester_barrier);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(harvester_barrier);
}
}

//
// Name: cleanup()
//
// Description: Cleans
//
// Input:
//
// Return:
//
void cleanup()
{
	if (languages_index_status == true)
	{
		if (showlanguages == true && debugonly == true)
		{
			cerr << endl;
    		server_close_languages(false); // dovrebbe essere false - non ricordo -
			cerr << "done" << endl;
		}
		else
		{
			cerr << endl;
    		server_close_languages(true);
			cerr << "done" << endl;
		}
	}
	chdir(CONF_COLLECTION_BASE);

	if (harv != NULL)
	{
		harv->hv_close();
		delete harv;
		cerr << "[harvest] ";
	}

	if (strg != NULL)
	{
		strg->st_close();
		delete strg;
		cerr << "[storage] ";
	}

	if (ridx != NULL)
	{
		ridx->st_close();
		delete ridx;
		cerr << "[roboidx] ";
	}

	if (meta != NULL)
	{
		meta->ddx_close();
		delete meta;
		cerr << "[metaddx] ";
	}

	if (lidx != NULL)
	{
		lidx->st_close();
		delete lidx;
		cerr << "[linkidx] ";
	}

	if (url != NULL)
	{
		url->ddx_close();
		delete url;
		cerr << "[urlddx] ";
	}

	if (links_download != NULL)
	{
		free(links_download);
		links_download = NULL;
		cerr << "[newurls] ";
	}

	if (links_log != NULL)
	{
		free(links_log);
		links_log = NULL;
		cerr << "[links_log] ";
	}

	if (links_stat != NULL)
	{
		free(links_stat);
		links_stat = NULL;
		cerr << "[links_stat] ";
	}
}

//
// Name: harvester_usage
//
// Description:
//   Prints a usage message
//

void harvester_usage() {
	cerr << "Usage: program [OPTION]" << endl;
	cerr << "Fetchs the list of pages defined for a harvest" << endl;
	cerr << endl;
	cerr << " -f, --force id       forces it to a fixed harvest_id" << endl;
	cerr << " -d, --debugonly      DO NOT save any type of data to disk." << endl;
	cerr << " -h, --help           this help message" << endl;
	cerr << endl;
	cbot_stop(0);
}
