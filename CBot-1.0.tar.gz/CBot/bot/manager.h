/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _MANAGER_H_INCLUDED_
#define _MANAGER_H_INCLUDED_

#include <config.h>

// System libraries

#include <features.h>
#include <getopt.h>
#include <fstream>
#include <assert.h>
#include <string.h>
#include <signal.h>
#include <time.h>

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "xmlconf-main.h"
#include "harvestidx.h"
#include "Meta.h"
#include "Monitor.h"
#include "metaddx_analysis.h"
#include "cleanup.h"
#include "linkidx.h"
#include "sitelink.h"
#include "Url.h"
#include "utils.h"

// Types

enum manager_site_status_t {
	MANAGER_SITE_STATUS_AVAILABLE	= 0,
	MANAGER_SITE_STATUS_STORED,
	MANAGER_SITE_STATUS_CHECK_SPECIAL,
	MANAGER_SITE_STATUS_TOO_MANY_ERRORS,
	MANAGER_SITE_STATUS_ASSIGNED_TO_OTHER_HARVEST
};

// need to passing arguments to threads functions
typedef struct {
	instance_t inst;
	siteid_t siteid;
	manager_site_status_t *manager_site_status;
	atomic<siteid_t> *site_count;
	atomic<docid_t> *depth_count;
	siteid_t *saturated_sites;
	siteid_t *count_sites;
	siteid_t *count_erroneous_sites;
} manager_thread_args_t;

// Globals

Monitor *monitor		= NULL;
Meta *meta				= NULL;
Url *url				= NULL;
Storage *strg			= NULL;
Storage *lidx			= NULL;
Harvest *harv			= NULL;

bool *everything_ok = NULL;
crawler_stats_t crawler_stats;
int crawler_stats_fd = 0;
atomic<docid_t> manager_harvest_doc_count;
pthread_barrier_t *manager_barrier = NULL;
// more mutex less slow
pthread_mutex_t *manager_locks_a;
pthread_mutex_t *manager_locks_b;
pthread_rwlock_t *manager_rwlocks_b;
urlmutex_t      *urlslock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
urlmutex_t      *urldlock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
urlmutex_t      *urlplock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL; // see const.h
pthread_mutex_t *console_lock = NULL; // see const.h

atomic<internal_long_uint_t> print_winner;
atomic<internal_long_uint_t> print_winner2;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

priority_t	*priority = NULL;
docid_t     *order = NULL;
//docid_t		*_order = NULL; // only for temporary testing use
siteid_t	*docid_to_siteid = NULL;

docid_t     ndocs;
siteid_t	nsites;

//const short NUMCOLS = 256; // short = intero che varia da -32768 a 32767 (ogni colonna contiene il singolo carattere di ogni nome dominio)
const int NUMROWS = 20000; // (ogni riga contiene il nome dominio top, max 20000 per la sardegna)
short rowindex[NUMROWS] = {0};

// Functions
void manager_sync_threads( pthread_barrier_t * );
void manager_lock_a( instance_t & );
void manager_lock_b( instance_t & );
void manager_rwlock_b( instance_t &, bool );
void manager_unlock_a( instance_t & );
void manager_unlock_b( instance_t & );
void manager_rwunlock_b( instance_t & );
void *manager_thread_function_verify_documents( void * );
void *manager_thread_function_marking( void * );
void *manager_thread_function_check_special( void * );
docid_t manager_create_harvest_list( harvest_t *harvest );
int manager_compare_by_priority( const void *a, const void *b );
void manager_open_indexes();
// void manager_calculate_scores();
void manager_order_documents();
void manager_usage();

#endif
