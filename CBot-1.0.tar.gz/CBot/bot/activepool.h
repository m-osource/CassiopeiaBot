/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/


#ifndef _ACTIVEPOOL_H_INCLUDED_
#define _ACTIVEPOOL_H_INCLUDED_

#include <config.h>

// System libraries

#include <assert.h>

// Local libraries

#include "xmlconf.h"
#include "die.h"
#include "server.h"
#include "waitq.h"
#include "pollvec.h"
#include "perfect_hash.h"

// External

extern bool parser_check_robotstxt( server_t * );


// Constants

#define ACTIVEPOOL_FILENAME_LOG		"activepool.log"
#define ACTIVEPOOL_ARES_CHANCES		2 // number of chances to run function 'server_resolver_start' for same domain. MUST BE 2 (TWO)
#define ACTIVEPOOL_ARES_FACTOR		10 // max number of cycles of pool admitted inside 'ACTIVE_POOL_ARESTIMEOUT'. MUST BE 10 (TEN) to grant operation

// Structs

// This is the main active pool, it consists
// of two lists of servers: poll and nopoll.
// - poll contains servers that will be polled
// - nopoll contains server entering or leaving the active pool
//
typedef struct {
	siteid_t					maxactive;			// Maximum number of slots
										// nactive_poll + nactive_nopoll

	siteid_t					nactive_poll;		// Num servers for polling
	siteid_t					*serverids_poll;	// Servers for polling
	bool						*poll_slot_free;	// Free slots

	siteid_t					nactive_nopoll;		// Num server w/o polling
	siteid_t					*serverids_nopoll;	// Servers w/o polling

	pollevent_t					*pollevents;		// For receiving poll events
	pollvec_t					*pollvec;			// Polling vector

	bool						ares_is_finish;

	siteid_t					err_dns;
	docid_t						err_connect;
	docid_t						err_other;
	siteid_t					dns_queries; 		// number of max simultaneous dns queries
	docid_t						ok;

	char						*useragent;			// Identification for crawler
	perfhash_t					*blocked_ip;        // Blocked IP addresses
	char						*dirname;			// Directory
	FILE						*file_log;			// Logfile

	// Output files
	FILE						**content_files;
	FILE						**doc_files;
} activepool_t;

// Global vars (from harvester.cc)

extern bool debugonly;
extern SemaphorePrint *sp;

// Vars

// Functions

// Create and destroy
activepool_t *activepool_create( siteid_t, pollvec_t *, char *, perfhash_t *, char * );
void activepool_destroy( activepool_t * );
void activepool_save_sites( activepool_t *, server_t *, siteid_t );

// Insert and remove servers
void activepool_insert_poll( activepool_t *, siteid_t, short, time_t, server_t * );
void activepool_remove_poll( activepool_t *, siteid_t, server_t * );
void activepool_insert_nopoll( activepool_t *, siteid_t, server_t * );
void activepool_remove_nopoll( activepool_t *, siteid_t, server_t * );

// Process, for each tick
void activepool_process( activepool_t *, waitq_t *, perfhash_t, starter_t * );
void activepool_process_poll( activepool_t *, waitq_t *, pollevent_t *, perfhash_t, starter_t *  );
bool activepool_process_nopoll( activepool_t *, waitq_t *, starter_t *, siteid_t );

// Fill
void activepool_fill( activepool_t *, waitq_t *, server_t * );

// Query 
int activepool_has_free_slots( activepool_t * );
int activepool_empty( activepool_t * );
void activepool_dump( activepool_t *, server_t *servers );
void activepool_minidump( activepool_t *, waitq_t *, instance_t & );
void activepool_minidump( activepool_t *, waitq_t * );

#endif
