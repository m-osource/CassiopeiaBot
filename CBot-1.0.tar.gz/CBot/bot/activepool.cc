/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "activepool.h"

// TODO check here for probable silent loop... (BUG ?)
void silent_loop_debug (time_t &tstart, int line, server_t server) 
{
	time_t now = time(NULL);

	if (now > (tstart + 60))
	{
		mcout << BRO << ". " << NOR << ' ' << line << mendl;
	}
	else if (now > (tstart + 600))
	{
		mcout << RED << ". " << NOR << ' ' << line << mendl;
	}
	else if (now > (tstart + 3600))
	{
		mcout << RED << ". " << NOR << ' ' << line << ' ' << server.hostname << ' ' << server.pages->path << mendl;

		assert(now <= (tstart + 3600 + 1));
	}

	usleep(5000);
}

//
// Name: activepool_create
//
// Description:
//   Creates an active pool
//
// Input:
//    maxactive - the maximum number of servers in the pool
//    pollvec - the polling vector
//    useragent - to identify with servers
//    dirname - the directory for logfile & output
//
// Return:
//    the created structure
//

activepool_t *activepool_create(siteid_t maxactive, pollvec_t *pollvec, char *useragent, perfhash_t *blocked_ip, char *dirname)
{
	assert(maxactive > 0);

	// Create the pool
	activepool_t *activepool = CBALLOC(activepool_t, MALLOC, 1);

	// Dirname
	assert(dirname != NULL);
	assert(strlen(dirname) > 0);
	activepool->dirname			= dirname;

	// Logfile
	char filename[MAX_STR_LEN];
	sprintf(filename, "%s/%s", dirname, ACTIVEPOOL_FILENAME_LOG);

	if (CONF_HARVESTER_LOGLEVEL == LOGLEVEL_VERBOSE)
	{
		if (debugonly == false)
		{
			activepool->file_log		= fopen64(filename, "w");
			assert(activepool->file_log != NULL);
			setbuf(activepool->file_log, NULL);
		}
		else 
			activepool->file_log = NULL;
	}
	else
		activepool->file_log		= NULL;

	if (activepool->file_log != NULL) {
		fprintf(activepool->file_log, "Allocating ... ");
	}

	// Useragent
	assert(useragent != NULL);
	assert(strlen(useragent) > 0);
	activepool->useragent			= useragent;

	// Blocked IPs
	activepool->blocked_ip			= blocked_ip;

	activepool->serverids_poll		= CBALLOC(siteid_t, MALLOC, maxactive);
	activepool->poll_slot_free		= CBALLOC(bool, MALLOC, maxactive);
	activepool->serverids_nopoll	= CBALLOC(siteid_t, MALLOC, maxactive);
    activepool->ares_is_finish		= false;
	activepool->pollevents			= CBALLOC(pollevent_t, MALLOC, maxactive);

	// Mark all pool slots as free
	for(siteid_t i = 0; i < maxactive; i++)
		activepool->poll_slot_free[i] = true;

	// Set max number of servers
	activepool->maxactive			= maxactive;
	activepool->nactive_poll		= 0;
	activepool->nactive_nopoll		= 0;

	activepool->err_dns				= 0;
	activepool->err_connect			= 0;
	activepool->err_other			= 0;
	activepool->dns_queries			= 0;
	activepool->ok					= 0;

	// Pollvec
	assert(pollvec != NULL);
	assert(pollvec_empty(pollvec));

	if (activepool->file_log != NULL)
		fprintf(activepool->file_log, " pollvec has %llu slots, activepool has %llu ", (unsigned long long int)pollvec->max_nfds, (unsigned long long int)activepool->maxactive); 

	assert(pollvec->max_nfds >= activepool->maxactive);
	activepool->pollvec			= pollvec;

	// Return the pool
	if (activepool->file_log != NULL)
		fprintf(activepool->file_log, "done.\n");

	return activepool;
}

//
// Name: activepool_insert_nopoll
//
// Description:
//   Inserts an element in the pool
//
// Input:
//   activepool - the structure
//   serverid - the server to insert
// 

void activepool_insert_nopoll(activepool_t *activepool, siteid_t serverid, server_t *servers)
{
	assert(activepool != NULL);
	assert(activepool->nactive_poll + activepool->nactive_nopoll < activepool->maxactive);
	assert(servers[serverid].conn_status == CONN_ACTIVATING || servers[serverid].conn_status == CONN_DEACTIVATING);
	assert(servers[serverid].socket.fd == -1);

	// Get a free slot
	uint slot = activepool->nactive_nopoll;
	activepool->nactive_nopoll++;

	// Insert
	activepool->serverids_nopoll[slot] = serverid;

	if (activepool->file_log != NULL)
		fprintf(activepool->file_log, "Inserted %s in active nopoll, slot %d.\n", servers[serverid].hostname, slot);
}

//
// Name: activepool_insert_poll
//
// Description:
//   Inserts an element in the pool, polling
//
// Input:
//   activepool - the structure
//   serverid - the server to insert
//   events - the events we are interested in
//   timeout - the timeout, in seconds
// 

void activepool_insert_poll(activepool_t *activepool, siteid_t serverid, short events, time_t timeout_seconds, server_t *servers)
{
	assert(activepool != NULL);
	assert(activepool->nactive_poll + activepool->nactive_nopoll < activepool->maxactive);

	conn_status_t conn_status = servers[serverid].conn_status;

	assert(conn_status == CONN_RESOLVING
		||	conn_status == CONN_CONNECTING
		||	conn_status == CONN_REQUESTING
		||	conn_status == CONN_RECEIVING
		||	conn_status == CONN_ROBOTSTXT_WAIT);

	if (conn_status != CONN_ROBOTSTXT_WAIT)	assert(servers[serverid].socket.fd >= 0);

	// Locate a free slot
	uint slot = 0;

	while(! activepool->poll_slot_free[slot])
	{
		slot++;
		assert(slot < activepool->maxactive);
	}

	// Mark the slot as not free, and assign it to the serverid
	activepool->serverids_poll[slot]	= serverid;
	activepool->poll_slot_free[slot]	= false;
	servers[serverid].pool_slot	 = slot;

	// Increase the number of used slots
	activepool->nactive_poll++;

	// Insert into pollvec
	pollvec_insert(activepool->pollvec, &(servers[serverid]), events, timeout_seconds);
	assert(activepool->nactive_poll == activepool->pollvec->nfds);

	// Report
	if	(activepool->file_log != NULL)
		fprintf(activepool->file_log, "Inserted %s in active poll, slot %d.\n", servers[serverid].hostname, slot);
}

//
// Name: activepool_remove_poll
//
// Description:
//   Removes an element from the pool: the element must
//   be in the CONN_ACTIVATING or CONN_DEACTIVATING state
//
// Input:
//   activepool - the structure
//   serverid - the server to remove
//

void activepool_remove_poll(activepool_t *activepool, siteid_t serverid, server_t *servers) {
	assert(activepool != NULL);
	assert(activepool->nactive_poll > 0);

	conn_status_t conn_status = servers[serverid].conn_status;
	assert(conn_status == CONN_DEACTIVATING
		||	conn_status	== CONN_ACTIVATING);
	assert(servers[serverid].socket.fd == -1);

	// Remove from pollvec first
	pollvec_remove(activepool->pollvec, &(servers[serverid]));

	// Search in the poll
	for (siteid_t slot = 0; slot < activepool->maxactive; slot++)
	{
		if (activepool->poll_slot_free[slot] == false &&
			serverid == activepool->serverids_poll[slot]) {

			// Mark slot as free
			activepool->poll_slot_free[slot] = true;

			activepool->nactive_poll --;

			// Mark server
			servers[serverid].pool_slot = (siteid_t)(~0);

			// Report
			if (activepool->file_log != NULL)
			{
				fprintf(activepool->file_log, "Removed %s from active poll, slot %llu (now nactive_poll=%llu).\n", servers[serverid].hostname, (unsigned long long int)slot, (unsigned long long int)activepool->nactive_poll);
			}

			assert(activepool->nactive_poll == activepool->pollvec->nfds);

			return;
		}
	}

	cerr << "Couldn't find element with serverid=" << serverid << endl;
	die("Element not found in activepool_remove_poll");
}

//
// Name: activepool_remove_nopoll
//
// Description:
//   Removes an element from the pool: the element must
//   be in the CONN_DEACTIVATING state
//
// Input:
//   activepool - the structure
//   serverid - the server to insert
//   servers - the list of server where check serverid
//

void activepool_remove_nopoll(activepool_t *activepool, siteid_t serverid, server_t *servers)
{
	assert(activepool != NULL);
	assert(activepool->nactive_nopoll > 0);

	conn_status_t conn_status = servers[serverid].conn_status;
	assert(conn_status == CONN_DEACTIVATING || conn_status == CONN_RESOLVING || conn_status == CONN_CONNECTING || conn_status == CONN_ROBOTSTXT_WAIT);

	// Search in the nopoll
	for (siteid_t slot = 0; slot < activepool->nactive_nopoll; slot++)
	{
		if (serverid == activepool->serverids_nopoll[slot])
		{
			// Check if this is the last server
			if (activepool->nactive_nopoll == 1) // Last server
				activepool->nactive_nopoll = 0;
			else // There are more servers
			{
				activepool->serverids_nopoll[slot] = activepool->serverids_nopoll[activepool->nactive_nopoll - 1];
				activepool->nactive_nopoll--;
			}

			if (activepool->file_log != NULL)
				fprintf(activepool->file_log, "Removed %s from active nopoll, slot %llu (now nactive_nopoll=%llu).\n", servers[serverid].hostname, (unsigned long long int)slot, (unsigned long long int)activepool->nactive_nopoll);

			return;
		}
	}

	die("Element not found in activepool_remove_nopoll");
}

//
// Name: activepool_fill
//
// Description:
//   Tries to fill the active pool with items in the 
//   waiting queue. One item for each call.
//
// Input:
//   activepool - the structure
//   waitq - the waiting queue
//

void activepool_fill(activepool_t *activepool, waitq_t *waitq, server_t *servers) {
	assert(activepool != NULL);

	// Check that it has free slots
	if (!activepool_has_free_slots(activepool))
		die("No free slots in active pool");

	if (waitq_empty(waitq))
		die("Waiting queue is empty");

	// Locate a free server
	time_t now = time(NULL);
	assert(waitq_available(waitq, now));
	siteid_t serverid = 0;
	time_t timestamp;

	waitq_pop(waitq, &(serverid), &(timestamp));

	assert(serverid > 0);
	assert(timestamp <= now);

	// Report
	if (activepool->file_log != NULL)
		fprintf(activepool->file_log, "Adding %s (activepool_fill)\n", servers[serverid].hostname);

	// Insert
	servers[serverid].conn_status = CONN_ACTIVATING;
	activepool_insert_nopoll(activepool, serverid, servers);
}

//
// Name: activepool_has_free_slots
//
// Description:
//   Tells if it is necessary to activepool_fill
//
// Input:
//   activepool - the structure
//
// Return:
//    1 if has free slots
//    0 if it is full
//

int activepool_has_free_slots(activepool_t *activepool)
{
	if ((activepool->nactive_poll + activepool->nactive_nopoll) < activepool->maxactive)
		return 1;
	else
		return 0;
}

//
// Name: activepool_empty
//
// Description:
//   Tells if it has both queues empty (the poll and nopoll)
//
// Input:
//   activepool - the structure
//
// Return:
//   1 if both are empty
//   0 if any of them is not empty
//

int activepool_empty(activepool_t *activepool) {
	assert(activepool != NULL);
	assert(activepool->nactive_poll >= 0);
	assert(activepool->nactive_nopoll >= 0);

	if (activepool->nactive_poll + activepool->nactive_nopoll == 0) {
		return 1;
	} else {
		return 0;
	}
}

//
// Name: activepool_process
//
// Description:
//   Process items in the active queue
// 
// Input:
//   activepool - the structure
//   waitq - the waiting queue (to put servers when needed)
//   accept_protocol - the perfect hash where check if protocol is found
//   starter - the structure where main variables, mutex and filehandles are found
//

void activepool_process(activepool_t *activepool, waitq_t *waitq, perfhash_t accept_protocol, starter_t *starter)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	assert(activepool != NULL);
	ares_channel *channel = ((ares_channel *)starter->a_channel);
	assert(channel != NULL);
	const struct ares_options *options = ((const struct ares_options *)starter->a_options);
	assert(options != NULL);

	if (activepool->file_log != NULL)
		fprintf(activepool->file_log, "Processing activepool (nopoll)\n");

	if	(activepool->file_log == NULL) // without Report
	{
		siteid_t slot = 0;

		time_t tstart = time(NULL);

		// If harvesting don't have loaded or downloaded
		// all robots.txt rules, and there are
		// sites with robots.txt to download and not,
		// the firsts must have precedence for the queries.
		if (CONF_SEEDER_ADD_ROBOTSTXT == true &&
			robots_txt_ndocs_done < meta->site_count())
		{
			bool *slots = NULL;

			// assign memory before decrement 'activepool->nactive_nopoll'
			if (activepool->nactive_nopoll > 0)
				slots = CBALLOC(bool, CALLOC, activepool->nactive_nopoll);

			while (slot < activepool->nactive_nopoll)
			{
				// Get serverid 
				siteid_t serverid = activepool->serverids_nopoll[slot];
				assert(serverid > 0);
				assert(strlen(servers[serverid].hostname) > 0);

				if (servers[serverid].pages->mime_type == MIME_ROBOTS_TXT || slots[slot] == true)
				{
					// marked
					slots[slot] = true;

					if (servers[serverid].conn_status == CONN_RESOLVING)
					{
						if (servers[serverid].http_status == HTTP_ERROR_DNS && // give last chance
							servers[serverid].dns_requests < 2)
						{
							struct timeval now;
							gettimeofday(&now, NULL);

							if (timercmp(&now, &(servers[serverid].timestamp_resolver_lastchance_timeout), >) > 0)
								server_resolver_start(starter, serverid);
						}

						slot++;
					}
					else
					{
						bool was_removed = activepool_process_nopoll(activepool, waitq, starter, serverid);

						if (! was_removed) slot++;
						else silent_loop_debug (tstart, __LINE__, servers[serverid]);
					}
				}
				else // skip because not robots.txt
					slot++;
			}

			slot = 0;

			usleep(500000);

			tstart = time(NULL);

			while (slot < activepool->nactive_nopoll)
			{
				// Get serverid 
				siteid_t serverid = activepool->serverids_nopoll[slot];
				assert(serverid > 0);
				assert(strlen(servers[serverid].hostname) > 0);

				if (slots[slot] == true) // visited in previous cicle
					slot++;
				else
				{   
					if (servers[serverid].conn_status == CONN_RESOLVING)
					{
						if (servers[serverid].http_status == HTTP_ERROR_DNS && // give last chance
							servers[serverid].dns_requests < 2)
						{
							struct timeval now;
							gettimeofday(&now, NULL);

							if (timercmp(&now, &(servers[serverid].timestamp_resolver_lastchance_timeout), >) > 0)
								server_resolver_start(starter, serverid);
						}

						slot++;
					}
					else
					{
						bool was_removed = activepool_process_nopoll(activepool, waitq, starter, serverid);

						if (! was_removed) slot++;
						else silent_loop_debug(tstart, __LINE__, servers[serverid]);
					}
				}
			}

			if (slots != NULL)
				free(slots);
		}
		else
		{
			while (slot < activepool->nactive_nopoll)
			{
				// Get serverid 
				siteid_t serverid = activepool->serverids_nopoll[slot];
				assert(serverid > 0);
				assert(strlen(servers[serverid].hostname) > 0);

				if (servers[serverid].conn_status == CONN_RESOLVING)
				{
					if (servers[serverid].http_status == HTTP_ERROR_DNS &&// give last chance
						servers[serverid].dns_requests < 2)
					{
							struct timeval now;
							gettimeofday(&now, NULL);

							if (timercmp(&now, &(servers[serverid].timestamp_resolver_lastchance_timeout), >) > 0)
								server_resolver_start(starter, serverid);
					}

					slot++;
				}
				else
				{
					bool was_removed = activepool_process_nopoll(activepool, waitq, starter, serverid);

					if (! was_removed) slot++;
					else silent_loop_debug(tstart, __LINE__, servers[serverid]);
				}
			}
		}

		// Check if ares is finish
		if (activepool->ares_is_finish == false)
		{
			for (siteid_t s = 1; s < activepool->maxactive; s++)
				if (servers[s].dns_requests < 2)
				{
					activepool->ares_is_finish = true;
					break;
				}
		
			if (activepool->ares_is_finish == true)
				server_resolver_wait(channel, starter->inst);

			// Once all dns request are ended destroy ares channel
			if (activepool->ares_is_finish == false)
			{
				activepool->ares_is_finish = true;
				ares_cancel(*channel); // Clear all pending queries
				ares_destroy(*channel); // No dns search anymore
			}
			else
				activepool->ares_is_finish = false;
		}

		if	(activepool->nactive_poll == 0)
		{
			assert(pollvec_empty(activepool->pollvec));

			return;
		}

		//
		// Poll
		//
		uint nevents = pollvec_poll(activepool->pollvec, activepool->pollevents, servers);

		assert((nevents == 0) || (nevents > 0 && nevents <= activepool->nactive_poll));

		// Handle polled events
		for (unsigned int evnum=0; evnum<nevents; evnum++)
		{
			// Get serverid of server that received events
			pollevent_t *pollevent = &(activepool->pollevents[evnum]);

			// Process
			activepool_process_poll(activepool, waitq, pollevent, accept_protocol, starter);
		}
	}
	else // with Report
	{
		siteid_t slot = 0;

		// If harvesting don't have loaded or downloaded
		// all robots.txt rules, and there are
		// sites with robots.txt to download and not,
		// the firsts must have precedence for the queries.
		if (CONF_SEEDER_ADD_ROBOTSTXT == true &&
			robots_txt_ndocs_done < meta->site_count())
		{
			bool *slots = NULL;

			// assign memory before decrement 'activepool->nactive_nopoll'
			if (activepool->nactive_nopoll > 0)
				slots = CBALLOC(bool, CALLOC, activepool->nactive_nopoll);

			while (slot < activepool->nactive_nopoll)
			{
				// Get serverid 
				siteid_t serverid = activepool->serverids_nopoll[slot];
				assert(serverid > 0);
				assert(strlen(servers[serverid].hostname) > 0);

				if (servers[serverid].pages->mime_type == MIME_ROBOTS_TXT || slots[slot] == true)
				{
					// marked
					slots[slot] = true;

					// Process
					if (servers[serverid].conn_status == CONN_RESOLVING)
					{
						if (servers[serverid].http_status == HTTP_ERROR_DNS && // give last chance and retry new query
							servers[serverid].dns_requests < 2)
						{
							struct timeval now;
							gettimeofday(&now, NULL);

							if (timercmp(&now, &(servers[serverid].timestamp_resolver_lastchance_timeout), >) > 0)
								server_resolver_start(starter, serverid);
						}

						slot++;
					}
					else
					{
						fprintf(activepool->file_log, "- nopoll %s (slot %llu of %llu) ", servers[serverid].hostname, (unsigned long long int)slot, (unsigned long long int)activepool->nactive_nopoll);

						bool was_removed = activepool_process_nopoll(activepool, waitq, starter, serverid);

						if (!was_removed)
						{
							slot++;

							fprintf(activepool->file_log, "!was_removed\n");
						}
						else
							fprintf(activepool->file_log, "was_removed\n");
					}
				}
				else // skip because not robots.txt
					slot++;
			}

			slot = 0;

			usleep(500000);

			while (slot < activepool->nactive_nopoll)
			{
				// Get serverid 
				siteid_t serverid = activepool->serverids_nopoll[slot];
				assert(serverid > 0);
				assert(strlen(servers[serverid].hostname) > 0);

				if (slots[slot] == true) // visited in previous cicle
					slot++;
				else
				{   
					// Process
					if (servers[serverid].conn_status == CONN_RESOLVING)
					{
						if (servers[serverid].http_status == HTTP_ERROR_DNS && // give last chance and retry new query
							servers[serverid].dns_requests < 2)
						{
							struct timeval now;
							gettimeofday(&now, NULL);

							if (timercmp(&now, &(servers[serverid].timestamp_resolver_lastchance_timeout), >) > 0)
								server_resolver_start(starter, serverid);
						}

						slot++;
					}
					else
					{
						fprintf(activepool->file_log, "- nopoll %s (slot %llu of %llu) ", servers[serverid].hostname, (unsigned long long int)slot, (unsigned long long int)activepool->nactive_nopoll);

						bool was_removed = activepool_process_nopoll(activepool, waitq, starter, serverid);

						if (!was_removed)
						{
							slot++;

							fprintf(activepool->file_log, "!was_removed\n");
						}
						else
							fprintf(activepool->file_log, "was_removed\n");
					}
				}
			}

			if (slots != NULL)
				free(slots);
		}
		else
		{
			while (slot < activepool->nactive_nopoll)
			{
				// Get serverid 
				siteid_t serverid = activepool->serverids_nopoll[slot];
				assert(serverid > 0);
				assert(strlen(servers[serverid].hostname) > 0);

				// Process
				if (servers[serverid].conn_status == CONN_RESOLVING)
				{
					if (servers[serverid].http_status == HTTP_ERROR_DNS && // give last chance
						servers[serverid].dns_requests < 2)
					{
							struct timeval now;
							gettimeofday(&now, NULL);

							if (timercmp(&now, &(servers[serverid].timestamp_resolver_lastchance_timeout), >) > 0)
								server_resolver_start(starter, serverid);
					}

					slot++;
				}
				else
				{
					fprintf(activepool->file_log, "- nopoll %s (slot %llu of %llu) ", servers[serverid].hostname, (unsigned long long int)slot, (unsigned long long int)activepool->nactive_nopoll);

					bool was_removed = activepool_process_nopoll(activepool, waitq, starter, serverid);

					if (!was_removed)
					{
						slot++;

						fprintf(activepool->file_log, "!was_removed\n");
					}
					else
						fprintf(activepool->file_log, "was_removed\n");
				}
			}
		}


		// Check if ares is finish
		if (activepool->ares_is_finish == false)
		{
			for (siteid_t s = 1; s < activepool->maxactive; s++)
				if (servers[s].dns_requests < 2)
				{
					activepool->ares_is_finish = true;
					break;
				}
		
			if (activepool->ares_is_finish == true)
				server_resolver_wait(channel, starter->inst);

			// Once all dns request are ended destroy ares channel
			if (activepool->ares_is_finish == false)
			{
				activepool->ares_is_finish = true;
				ares_cancel(*channel); // Clear all pending queries
				ares_destroy(*channel); // No dns search anymore
			}
			else
				activepool->ares_is_finish = false;
		}

		if	(activepool->nactive_poll == 0)
		{
			assert(pollvec_empty(activepool->pollvec));

			fprintf(activepool->file_log, "Nothing to poll()\n");

			return;
		}

		//
		// Poll
		//

		fprintf(activepool->file_log, "Processing activepool (poll)\n");

		uint nevents = pollvec_poll(activepool->pollvec, activepool->pollevents, servers);

		assert((nevents == 0) || (nevents > 0 && nevents <= activepool->nactive_poll));

		fprintf(activepool->file_log, "- received %d events of %llu items\n", nevents, (unsigned long long int)activepool->nactive_poll);

		// Handle polled events
		for (unsigned int evnum=0; evnum<nevents; evnum++)
		{
			// Get serverid of server that received events
			pollevent_t *pollevent = &(activepool->pollevents[evnum]);

			// Report
			fprintf(activepool->file_log, "- poll event for %s\n", servers[pollevent->serverid].hostname);

			// Process
			activepool_process_poll(activepool, waitq, pollevent, accept_protocol, starter);
		}

		fprintf(activepool->file_log, "Done processing activepool\n");
	}
}

//
// Name: activepool_process_nopoll
//
// Description:
//   Process a server in the nopoll list
//
// Input:
//   activepool - the structure
//   waitq - the waiting queue
//   starter - the structure where main variables, mutex and filehandles are found
//   serverid - the number of the server
//

bool activepool_process_nopoll(activepool_t *activepool, waitq_t *waitq, starter_t *starter, siteid_t serverid)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	assert(servers[serverid].conn_status == CONN_RESOLVING_WAIT || servers[serverid].conn_status == CONN_ACTIVATING);

	server_t *server = &(servers[serverid]);

	bool was_removed = false;

	// We need to check if the server has a valid IP
	if (server_has_ip(server))
	{
		if (activepool->file_log != NULL)
			fprintf(activepool->file_log, " has_ip ");

		// decrement count of dns requests for put other dns requests
		if (server->http_status == HTTP_STATUS_RESOLVED)
		{
			server->http_status = HTTP_STATUS_UNDEFINED;
			activepool->dns_queries--;
		}

		// Check if the server has more pages to be downloaded
		if (server_has_more_documents(server))
		{
			if (activepool->file_log != NULL)
				fprintf(activepool->file_log, " has_more_documents ");

			char *addr_buf = NULL;
			bool astat = false;
			bool ip_is_blocked = false;
			bool disallow_path = false;

			if (server->addr->ss_family == AF_INET6)
			{
				addr_buf = CBALLOC(char, CALLOC, (INET6_ADDRSTRLEN + 1));
				astat = get_addr(server->addr, addr_buf);
			}
			else
			{
				addr_buf = CBALLOC(char, CALLOC, (INET_ADDRSTRLEN + 1));
				astat = get_addr(server->addr, addr_buf);
			}

			if (astat == false)
				die("Error: invalid af for hostname %s\n", server->hostname);
			else
			{
				// Check if the IP address is blocked
				// We compare the IPs as strings (e.g.: "11.11.11.11" or "22:22::22")
				if (perfhash_check(activepool->blocked_ip, addr_buf))
				{
					mcerr << RED << "IP " << addr_buf << " is blocked" << NOR << mendl;
					ip_is_blocked = true;
				}
			}

			free(addr_buf);

			// prepare for wait for downloading all robots.txt files or reading them from storage
			// go to loop until we have all robotstxt rules loaded
			if (CONF_SEEDER_ADD_ROBOTSTXT == true)
			{
				if (server->ndocs_done == 0)
				{
					if (server->pages->mime_type != MIME_ROBOTS_TXT && robots_txt_ndocs_done < meta->site_count())
						server->conn_status = CONN_ROBOTSTXT_WAIT;
				}
				else if (server->ndocs_done == 1)
				{
					if (robots_txt_ndocs_done < meta->site_count())
						server->conn_status = CONN_ROBOTSTXT_WAIT;
				}
			}

			// Start to connect
			short events	= 0;
			uint timeout	= 0;

			if	(ip_is_blocked)
				server->conn_status = CONN_DEACTIVATING;
			else if (server->conn_status == CONN_ROBOTSTXT_WAIT)
			{
				events = POLLOUT;
				timeout = SERVER_ROBOTSTXT_TIMEOUT;
			}
			else if (server->pages->doc->status == STATUS_DOC_EXCLUSION)
			{
				disallow_path = true;
				server->conn_status = CONN_DEACTIVATING;
			}
			else if (server->pages->doc->status == STATUS_DOC_FORBIDDEN)
			{
				disallow_path = true;
				server->conn_status = CONN_DEACTIVATING;
			}
			else
			{
				if (server->updated_robotstxt == true && parser_check_robotstxt(server) == true)
				{
					disallow_path = true;
					server->conn_status = CONN_DEACTIVATING;
				}
				else
					server_connect_start(server, &(events), &(timeout), activepool->useragent);
			}

			switch (server->conn_status)
			{
				// Waiting for loading all robotstxt's rules
				case CONN_ROBOTSTXT_WAIT:

					usleep(5);

					activepool_remove_nopoll(activepool, serverid, servers);

					// disable assert check with waiting loop condition
					if (server->conn_status != CONN_ROBOTSTXT_WAIT) assert(server->socket.fd >= 0);

					assert(events > 0);
					assert(timeout > 0);

					activepool_insert_poll(activepool, serverid, events, timeout, servers);
					was_removed = true;
					break;

				// Is connecting
				case CONN_CONNECTING:
					activepool_remove_nopoll(activepool, serverid, servers);
					assert(server->socket.fd >= 0);
					assert(events > 0);
					assert(timeout > 0);
					activepool_insert_poll(activepool, serverid, events, timeout, servers);
					was_removed = true;
					break;

				// Is not connecting (failed)
				case CONN_DEACTIVATING:
					assert(server->socket.fd == -1);
					assert(events == 0);
					assert(timeout == 0);
					activepool_remove_nopoll(activepool, serverid, servers);
					servers[serverid].conn_status = CONN_NONE;
					was_removed = true;

					if (disallow_path == true)
					{	// Save page as excluded documents marked before start harvest
						servers[serverid].exclusions_in_this_harvest++;
						server_save_current_page(starter, serverid);
					}
					else
					{	// Add 1 error
						servers[serverid].errors_in_this_harvest++;
						activepool->err_connect++;
					}

					// If the IP was blocked, skip all
					if (ip_is_blocked) 
						server_skip_all(starter, serverid, HTTP_ERROR_BLOCKED_IP);
					else if(servers[serverid].errors_in_this_harvest <= CONF_MANAGER_MAX_ERRORS_SAME_BATCH) // If we can retry, insert again
						waitq_push(waitq, serverid, time(NULL) + servers[serverid].wait); 
					else server_skip_all(starter, serverid, HTTP_ERROR_CONNECT);

					break;

				default:
					die("Inconsistency after server_connect_start");
			}

		} else {

			if (activepool->file_log != NULL) {
				fprintf(activepool->file_log, " !has_more_documents ");
			}

			// No more documents
			servers[serverid].conn_status = CONN_DEACTIVATING;
			activepool_remove_nopoll(activepool, serverid, servers);
			servers[serverid].conn_status = CONN_NONE;
			was_removed = true;
		}

	}
	else // Domain must be resolved
	{
		// Resolv
		if	(activepool->file_log != NULL)
			fprintf(activepool->file_log, " !has_ip ");

		if (server->dns_requests == 0)
		{
			if (activepool->dns_queries < CONF_HARVESTER_DNSMAX)
			{
				server_resolver_start(starter, serverid);

				activepool->dns_queries++;

				// Check server status
				switch(server->conn_status)
				{
					case CONN_ACTIVATING:
						if (server->http_status == HTTP_STATUS_RESOLVED)
						{
							if (activepool->file_log != NULL)
								fprintf(activepool->file_log, " now has_ip ");

							mcerr << server->hostname << '/' << server->pages->path << " now has_ip" << mendl;

							was_removed = false;
						}
						else
						{// The dns resolver failed
							if (activepool->file_log != NULL)
								fprintf(activepool->file_log, " failed !has_ip ");

							mcerr << server->hostname << '/' << server->pages->path << " failed !has_ip" << mendl;

							// Remove
							activepool_remove_nopoll(activepool, serverid, servers);

							// Skip the rest for this server
							server_skip_all(starter, serverid, HTTP_ERROR_DNS);
							activepool->err_dns++;
							activepool->dns_queries--;

							// Status is CONN_NONE
							servers[serverid].conn_status = CONN_NONE;
							was_removed = true;
						}
						break;

					case CONN_RESOLVING:
						// The server is DNS resolving,
						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, " resolving ");

						was_removed = false;

						break;

					default:
						die("Inconsistency after server_resolver_start");
				}
			}
			else
			{
					// The server is DNS resolving,
					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, " resolving ");

					was_removed = false;

					server->conn_status = CONN_RESOLVING_WAIT;
			}
		}
		else
		{
			// Check server status
			switch(server->conn_status)
			{
				case CONN_ACTIVATING:
					if (server->http_status == HTTP_STATUS_RESOLVED)
					{
						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, " now has_ip ");

						mcerr << server->hostname << '/' << server->pages->path << " now has_ip" << mendl;

						was_removed = false;
					}
					else
					{// The dns resolver failed
						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, " failed !has_ip ");

						server->conn_status = CONN_DEACTIVATING;

						// Remove
						activepool_remove_nopoll(activepool, serverid, servers);

						// Skip the rest for this server
						server_skip_all(starter, serverid, HTTP_ERROR_DNS);
						activepool->err_dns++;
						activepool->dns_queries--;

						// Status is CONN_NONE
						servers[serverid].conn_status = CONN_NONE;
						was_removed = true;
					}
					break;

				default:
					die("Inconsistency after server_resolver_start");
			}
		}
	}

	if (activepool->file_log != NULL)
		fprintf(activepool->file_log, " done ");

	return was_removed;
}

//
// Name: activepool_process_poll
//
// Description:
//   Process a server in the poll list
//
// Input:
//   activepool - the structure
//   waitq - the queue
//   pollevent - the recived event
//   accept_protocol - the perfect hash where check if protocol is found
//   starter - the structure where main variables, mutex and filehandles are found
//

void activepool_process_poll(activepool_t *activepool, waitq_t *waitq, pollevent_t *pollevent, perfhash_t accept_protocol, starter_t *starter)
{
	server_t *servers = (server_t *)starter->servers;
	assert(servers != NULL);
	assert(activepool != NULL);
	assert(pollevent != NULL);
	assert(pollevent->serverid > 0);

	siteid_t serverid = pollevent->serverid;
	server_t *server = &(servers[serverid]);
	int revents = pollevent->revents;
	siteid_t pool_slot = server->pool_slot;
	assert(pool_slot < (siteid_t)(~0));

	if	(activepool->file_log != NULL)
		fprintf(activepool->file_log, " event in pool_slot=%d revent=%d ", pool_slot, revents);
	
	// Check server status
	assert(server->conn_status == CONN_RESOLVING_WAIT ||
			server->conn_status == CONN_RESOLVING ||
			server->conn_status == CONN_ROBOTSTXT_WAIT ||
			server->conn_status == CONN_CONNECTING ||
			server->conn_status == CONN_REQUESTING ||
			server->conn_status == CONN_RECEIVING);

	// Depending on the connection status
	short events				= 0;
	unsigned int timeout		= 0;
//	int rc						= 0;
	
	switch (server->conn_status)
	{
		// We got a poll event because server is waiting for all robotstxt rules done
		case CONN_ROBOTSTXT_WAIT:

			assert(robots_txt_ndocs_done <= meta->site_count());

			events = POLLIN;
			timeout  = SERVER_ROBOTSTXT_TIMEOUT;

			if (activepool->file_log != NULL)
				fprintf(activepool->file_log, " robotstxt waiting ");

			// Update parameters
			pollvec_update(activepool->pollvec, &(servers[serverid]), events, time(NULL) + timeout);

			// if all robotstxt's rules for WHOLE collection are loaded
			// then set for connect
			// else
			// continue loop
			if (robots_txt_ndocs_done == meta->site_count())
			{
				server->conn_status = CONN_ACTIVATING;

				activepool_remove_poll(activepool, serverid, servers);
				activepool_insert_nopoll(activepool, serverid, servers);
				bool was_removed = activepool_process_nopoll(activepool, waitq, starter, serverid);

				if (!was_removed)
				{
					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, "!was_removed");
				}
				else
				{
					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, "was_removed");
				}

				if (activepool->file_log != NULL) 
					fprintf(activepool->file_log, "\n");

				if (activepool->nactive_poll == 0)
				{
					assert(pollvec_empty(activepool->pollvec));

					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, "Nothing to poll()\n");

					if (activepool->file_log != NULL) 
						fprintf(activepool->file_log, "Processing activepool (poll)\n");

					uint nevents = pollvec_poll(activepool->pollvec, activepool->pollevents, servers);
					assert((nevents == 0) || (nevents > 0 && nevents <= activepool->nactive_poll));

					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, "- received %d events of %llu items\n", nevents, (unsigned long long int)activepool->nactive_poll);


					// Handle polled events
					for (uint evnum=0; evnum<nevents; evnum++)
					{
						// Get serverid of server that received events
						pollevent_t *pollevent = &(activepool->pollevents[serverid]);

						// Report
						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "- poll event for %s\n", servers[pollevent->serverid].hostname);

						// Process
						activepool_process_poll(activepool, waitq, pollevent, accept_protocol, starter);
					}

					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, "Done processing activepool\n");
				}

				return;
			}

			break;

		// The server was waiting for resolving ip address
		case CONN_RESOLVING_WAIT:
				if	(activepool->file_log != NULL)
					fprintf(activepool->file_log, " answer not ready yet because waiting ");
			break;

		// The server was resolving ip address
		case CONN_RESOLVING:
				if	(activepool->file_log != NULL)
					fprintf(activepool->file_log, " answer not ready yet ");
			break;

		// We got a poll event while connecting, probably
		// the connection is ready for the request
		case CONN_CONNECTING:

			if (revents & POLLOUT)
				server_request_start(server, &(events), &(timeout), activepool->useragent);
			else
			{
				server->conn_status = CONN_DEACTIVATING;
				server_reset_buffers(server);
				server_close(server);
			}

			switch(server->conn_status)
			{
				// The connection failed, we will NOT try again
				case CONN_DEACTIVATING:
					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, " connection failed ");

					// Remove
					activepool_remove_poll(activepool, serverid, servers);

					// Skip the other pages
					// We never retry a connect error in the same harvest
					// (other errors e.g.: NOT_FOUND, etc, can be retried)
					server_skip_all(starter, serverid, HTTP_ERROR_CONNECT);

					// Status is CONN_NONE
					servers[serverid].conn_status = CONN_NONE;

					// Add 1 error 
					servers[serverid].errors_in_this_harvest ++;
					activepool->err_connect ++;

					break;

				// The connection was sucesful, and the request
				// was sucesfully sent. Notice that we don't consider
				// blocking requests: we must be able to write the request
				// on a single packet
				case CONN_REQUESTING:
					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, " requested ");

					// Update parameters
					pollvec_update(activepool->pollvec, &(servers[serverid]), events, time(NULL) + timeout);

					break;

				default:
					die("Inconsistency after server_request_start");
			}

			break;

		// We got a poll event after requesting, or
		// while requesting (for long headers)
		case CONN_REQUESTING:

			assert(server->pages->headers_end == 0);

			if (revents & (POLLIN|POLLPRI))
			{
				bool is_special_redirect = server_receive(server, &(events), &(timeout), activepool->useragent, accept_protocol);
				// Se la funzione server_receive restituisce is_special_redirect uguale a true occorre rielaborare immediatamente l'url
				// di destinazione riattivando un nuovo ciclo di polling. In questo modo la richiesta del nuovo url avviene in maniera non bloccante!
				if (is_special_redirect == true)
				{
					activepool_remove_poll(activepool, serverid, servers);
					activepool_insert_nopoll(activepool, serverid, servers);
					bool was_removed = activepool_process_nopoll(activepool, waitq, starter, serverid);

					if (!was_removed)
					{
						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "!was_removed");
					}
					else
					{
						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "was_removed");
					}

					if (activepool->file_log != NULL) 
						fprintf(activepool->file_log, "\n");

					if (activepool->nactive_poll == 0)
					{
						assert(pollvec_empty(activepool->pollvec));

						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "Nothing to poll()\n");

						if (activepool->file_log != NULL) 
							fprintf(activepool->file_log, "Processing activepool (poll)\n");

						uint nevents = pollvec_poll(activepool->pollvec, activepool->pollevents, servers);
						assert((nevents == 0) || (nevents > 0 && nevents <= activepool->nactive_poll));

						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "- received %d events of %llu items\n", nevents, (unsigned long long int)activepool->nactive_poll);


						// Handle polled events
						for (uint evnum=0; evnum<nevents; evnum++)
						{
							// Get serverid of server that received events
							pollevent_t *pollevent = &(activepool->pollevents[serverid]);

							// Report
							if (activepool->file_log != NULL)
								fprintf(activepool->file_log, "- poll event for %s\n", servers[pollevent->serverid].hostname);

							// Process
							activepool_process_poll(activepool, waitq, pollevent, accept_protocol, starter);
						}

						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "Done processing activepool\n");
					}

					return;
				}
			}
			else
			{
				if (revents & POLLERR)
				{
					mcerr << RED << "POLLERR in " << server->hostname << NOR << mendl;
				}
				else if (revents & POLLHUP)
				{
					mcerr << RED << "POLLHUP in " << server->hostname << NOR << mendl;
				}
				else if (revents == 0)
				{
					mcerr << RED << "POLL TIMEOUT in " << server->hostname << NOR << mendl;	
					server->http_status	= HTTP_ERROR_TIMEOUT;
				}
				else
				{
					mcerr << RED << "Unexpected poll event received: " << revents << " " << server->hostname << NOR << mendl;
				}

				server->conn_status = CONN_DEACTIVATING;
				server_reset_buffers(server);
				server_close(server);

				// Check for undefined status
				if (server->http_status == HTTP_STATUS_UNDEFINED)
				{

					// We have readed packets but we still
					// have no http code, the server is misbehaving
					mcerr << RED << "Server " << server->hostname << " misbehaving: readed packets but got no header data" << NOR << mendl;
					server->http_status				= HTTP_ERROR_DISCONNECTED;
				} 
			}

/*
			if (revents & (POLLIN|POLLPRI))
				server_receive(server, &(events), &(timeout), activepool->useragent, accept_protocol);
			else
			{
				if (revents & POLLERR)
				{
					mcerr << RED << "POLLERR in " << server->hostname << NOR << mendl;
				}
				else if (revents & POLLHUP)
				{
					mcerr << RED << "POLLHUP in " << server->hostname << NOR << mendl;
				}
				else if (revents == 0)
				{
					mcerr << RED << "POLL TIMEOUT in " << server->hostname << NOR << mendl;	
					server->http_status	= HTTP_ERROR_TIMEOUT;
				}
				else
				{
					mcerr << RED << "Unexpected poll event received: " << revents << " " << server->hostname << NOR << mendl;
				}

				server->conn_status = CONN_DEACTIVATING;
				server_reset_buffers(server);
				server_close(server);

				// Check for undefined status
				if (server->http_status == HTTP_STATUS_UNDEFINED)
				{

					// We have readed packets but we still
					// have no http code, the server is misbehaving
					mcerr << RED << "Server " << server->hostname << " misbehaving: readed packets but got no header data" << NOR << mendl;
					server->http_status				= HTTP_ERROR_DISCONNECTED;
				} 
			} */

			switch(server->conn_status)
			{
				case CONN_DEACTIVATING:
					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, " deactivating ");

					// Remove
					activepool_remove_poll(activepool, serverid, servers);
					
					// Page done. Notice that this is the only
					// case in which we want to save the doc status
					// in the corresponding file, to be consistent
					// with saved content data. In all other cases,
					// we just pick the first file.
					server_save_current_page(starter, serverid); 
					//server_save_current_page_nic(server, activepool->doc_files[pool_slot]);

					// Check for error conditions
					if (! HTTP_IS_ERROR(server->http_status))
					{
						activepool->ok++;

						// Check if site done
						if (server_has_more_documents(server))
							// Not done yet, push it in the waiting queue
							waitq_push(waitq, serverid, time(NULL) + servers[serverid].wait);
					}
					else
					{
						// Add 1 error 
						servers[serverid].errors_in_this_harvest ++;
						activepool->err_connect++;

						// Check if there are more documents
						if (server_has_more_documents(server))
						{
							// Check if we have had too many errors
							if (servers[serverid].errors_in_this_harvest <= CONF_MANAGER_MAX_ERRORS_SAME_BATCH)
								// We haven't had too many errors
								waitq_push(waitq, serverid, time(NULL) + servers[serverid].wait);
							else
							{
								// Skip the rest for this server, we have had
								// too many errors with it
								if (server->http_status == HTTP_ERROR_TIMEOUT
								 || server->http_status == HTTP_ERROR_DISCONNECTED)
									server_skip_all(starter, serverid, server->http_status);
								else
									server_skip_all(starter, serverid, HTTP_ERROR_DISCONNECTED);
							}
						}
					}


					// Status is CONN_NONE
					servers[serverid].conn_status = CONN_NONE;

					break;

				case CONN_REQUESTING:

					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, " continue requesting ");

					assert(server->pages->headers_end == 0);

					break;

				case CONN_RECEIVING:

					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, " continue receiving ");

					break;

				default:
					die("Inconsistency after server_receive (conn_status %d) for docid %llu end path: %s", (int)server->conn_status, (unsigned long long int)server->pages->doc->docid, server->pages->path);

			}

			break;

		case CONN_RECEIVING:

			if (revents & (POLLIN|POLLPRI))
			{
				bool is_special_redirect = server_receive(server, &(events), &(timeout), activepool->useragent, accept_protocol);
				// Se la funzione server_receive restituisce is_special_redirect uguale a true occorre rielaborare immediatamente l'url
				// di destinazione riattivando un nuovo ciclo di polling. In questo modo la richiesta del nuovo url avviene in maniera non bloccante!
				if (is_special_redirect == true)
				{
					activepool_remove_poll(activepool, serverid, servers);
					activepool_insert_nopoll(activepool, serverid, servers);
					bool was_removed = activepool_process_nopoll(activepool, waitq, starter, serverid);

					if (!was_removed)
					{
						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "!was_removed\n");
					}
					else
					{
						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "was_removed\n");
					}

					if (activepool->nactive_poll == 0)
					{
						assert(pollvec_empty(activepool->pollvec));

						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "Nothing to poll()\n");

						if (activepool->file_log != NULL) 
							fprintf(activepool->file_log, "Processing activepool (poll)\n");

						uint nevents = pollvec_poll(activepool->pollvec, activepool->pollevents, servers);
						assert((nevents == 0) || (nevents > 0 && nevents <= activepool->nactive_poll));

						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "- received %d events of %llu items\n", nevents, (unsigned long long int)activepool->nactive_poll);


						// Handle polled events
						for (uint evnum=0; evnum<nevents; evnum++)
						{
							// Get serverid of server that received events
							pollevent_t *pollevent = &(activepool->pollevents[serverid]);

							// Report
							if (activepool->file_log != NULL)
								fprintf(activepool->file_log, "- poll event for %s\n", servers[pollevent->serverid].hostname);

							// Process
							activepool_process_poll(activepool, waitq, pollevent, accept_protocol, starter);
						}

						if (activepool->file_log != NULL)
							fprintf(activepool->file_log, "Done processing activepool\n");
					}

					return;
				}
			}
			else
			{
				if (revents & POLLERR)
				{
					mcerr << RED << "POLLERR in " << server->hostname << NOR << mendl;
				}
				else if (revents & POLLHUP)
				{
					mcerr << RED << "POLLHUP in " << server->hostname << NOR << mendl;
				}
				else if (revents == 0)
				{
					mcerr << RED << "POLL TIMEOUT in " << server->hostname << NOR << mendl;	
					server->http_status	= HTTP_ERROR_TIMEOUT;
				}
				else
				{
					mcerr << RED << "Unexpected poll event received: " << revents << " " << server->hostname << NOR << mendl;
				}

				server->conn_status = CONN_DEACTIVATING;
				server_reset_buffers(server);
				server_close(server);

				// Check for undefined status
				if (server->http_status == HTTP_STATUS_UNDEFINED)
				{

					// We have readed packets but we still
					// have no http code, the server is misbehaving
					mcerr << RED << "Server " << server->hostname << " misbehaving: readed packets but got no header data" << NOR << mendl;
					server->http_status				= HTTP_ERROR_DISCONNECTED;
				} 
			}

			switch(server->conn_status)
			{
				case CONN_DEACTIVATING:
					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, " deactivating ");

					// Remove
					activepool_remove_poll(activepool, serverid, servers);
					
					// Page done. Notice that this is the only
					// case in which we want to save the doc status
					// in the corresponding file, to be consistent
					// with saved content data. In all other cases,
					// we just pick the first file.
					server_save_current_page(starter, serverid); 
					//server_save_current_page_nic(server, activepool->doc_files[pool_slot]);

					// Check for error conditions
					if (! HTTP_IS_ERROR(server->http_status))
					{
						activepool->ok++;

						// Check if site done
						if (server_has_more_documents(server))
							// Not done yet, push it in the waiting queue
							waitq_push(waitq, serverid, time(NULL) + servers[serverid].wait);
					}
					else
					{
						// Add 1 error 
						servers[serverid].errors_in_this_harvest ++;
						activepool->err_connect++;

						// Check if there are more documents
						if (server_has_more_documents(server))
						{
							// Check if we have had too many errors
							if (servers[serverid].errors_in_this_harvest <= CONF_MANAGER_MAX_ERRORS_SAME_BATCH)
								// We haven't had too many errors
								waitq_push(waitq, serverid, time(NULL) + servers[serverid].wait);
							else
							{
								// Skip the rest for this server, we have had
								// too many errors with it
								if (server->http_status == HTTP_ERROR_TIMEOUT
								 || server->http_status == HTTP_ERROR_DISCONNECTED)
									server_skip_all(starter, serverid, server->http_status);
								else
									server_skip_all(starter, serverid, HTTP_ERROR_DISCONNECTED);
							}
						}
					}


					// Status is CONN_NONE
					servers[serverid].conn_status = CONN_NONE;

					break;

				case CONN_RECEIVING:

					if (activepool->file_log != NULL)
						fprintf(activepool->file_log, " continue receiving ");

					break;

				default:
					die("Inconsistency after server_receive");

			}
			break;

		default:
			die("Inconsistency after receiving poll event for docid: %llu", (unsigned long long int)server->pages->doc->docid);

	}
}

//
// Name: activepool_save_sites
//
// Description:
//   Saves all sites
//

void activepool_save_sites(activepool_t *activepool, server_t *servers, siteid_t total_servers)
{
	assert(activepool != NULL);

	// Go through the list of servers
	map <uint, siteid_t> map_http_status;

	for (siteid_t serverid = 1; serverid <= total_servers; serverid++)
	{
		server_t *server = &(servers[serverid]);
		assert(server != NULL);
		assert(server->site != NULL);

		// Save this server's site data
		server_save_site(server);

		map_http_status[server->http_status]++;
	}
}

//
// Name: activepool_destroy
//
// Description:
//   Destroys the active pool
//

void activepool_destroy(activepool_t *activepool) {
	assert(activepool != NULL);
	assert(activepool->nactive_poll == 0);
	assert(activepool->nactive_nopoll == 0);

	free(activepool->serverids_poll); // TODO free problem
	free(activepool->poll_slot_free);
	free(activepool->serverids_nopoll);
	free(activepool->pollevents);

	// Close files
	if (activepool->file_log != NULL) {
		fprintf(activepool->file_log, "Done.\n");
		fclose(activepool->file_log);
	}
	
	free(activepool);
}

//
// Name: activepool_dump
//
// Description:
//   Shows the active pool
//

void activepool_dump(activepool_t *activepool, server_t *servers)
{

	mcerr << BLU << "BEGIN activepool dump" << endl << "maxactive      " << activepool->maxactive << endl << "nactive_nopoll   " << activepool->nactive_nopoll << endl;

	for (siteid_t slot=0; slot<activepool->nactive_nopoll; slot++)
	{
		cerr << " slot " << slot << " serverid " << activepool->serverids_nopoll[slot] << ' ' << servers[activepool->serverids_nopoll[slot]].hostname << endl;
	}

	cerr << "nactive_poll   " << activepool->nactive_poll << endl;

	for (siteid_t slot=0; slot < activepool->nactive_poll; slot++)
	{
		cerr << " slot " << slot << " " << servers[activepool->serverids_poll[slot]].hostname << endl;
//		assert((servers[activepool->serverids_poll[slot]].pool_slot) == slot); // this assert seem wrong ??? (year 2017)
	}

	cerr << "END activepool dump" << NOR << mendl;
}

//
// Name: activepool_minidump
//
// Description:
//   Shows some info about the active pool, in one line
//   acts like a 'tick' of the clock
//

void activepool_minidump(activepool_t *activepool, waitq_t *waitq, instance_t &instance)
{
	assert(activepool != NULL);
	mcerr << BLU;
	cerr << "   ";
	cerr << "On instance " << (unsigned long int)instance;
	cerr << ": SERVERS ";
	cerr << "NoPoll=" << activepool->nactive_nopoll << ", ";
	cerr << "Poll=" << activepool->nactive_poll << ", ";
	cerr << "Wait="	<< waitq->nservers;
	cerr << " ";
	cerr << "PAGES ";
	cerr << "ok="       << activepool->ok << ", ";


	if (CONF_SEEDER_ADD_ROBOTSTXT == true)
	{
		if (robots_txt_ndocs_done < meta->site_count())
		{
			cerr << "rtxtRulesDone="  << robots_txt_ndocs_done << ", ";
			cerr << "rtxtRules="  << meta->site_count() << ", ";
		}
	}

	cerr << "connErr="  << activepool->err_connect << ", ";
	cerr << "dnsErr="   << activepool->err_dns;
   	cerr << NOR << mendl;
}

void activepool_minidump(activepool_t *activepool, waitq_t *waitq) {
	assert(activepool != NULL);
/*	cerr << BLU;
	cerr << "   ";
	cerr << "SERVERS ";
	cerr << "Poll=" << activepool->nactive_poll << ", ";
	cerr << "Wait="	<< waitq->nservers;
	cerr << " ";
	cerr << "PAGES ";
	cerr << "ok="       << activepool->ok << ", ";
	cerr << "connErr="  << activepool->err_connect << ", ";
	cerr << "dnsErr="   << activepool->err_dns;
   	cerr << NOR << endl; */
	char report[MAX_STR_LEN];
	sprintf(report, "%s   SERVERS Poll=%llu, Wait=%llu PAGES ok=%u connErr=%u dnsErr=%llu", BLU, (unsigned long long int)activepool->nactive_poll, (unsigned long long int)waitq->nservers, activepool->ok, activepool->err_connect, (unsigned long long int)activepool->err_dns);
   	mcerr << report << NOR << mendl;
}
