/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _WAITQ_H_INCLUDED_
#define _WAITQ_H_INCLUDED_

#include <config.h>

// System libraries

#include <assert.h>
#include <stdlib.h>

// Local libraries

#include "die.h"
#include "xmlconf.h"
#include "cleanup.h"

// Structs

typedef struct waitq_item_ptr {
	siteid_t serverid;
	time_t nextvisit;
} waitq_item_t;

typedef struct {
	waitq_item_t *queue;
	siteid_t nservers;
	siteid_t maxservers; 
} waitq_t;

// Global vars (from harvester.cc)

// Vars

// Functions

waitq_t *waitq_create( siteid_t );
void waitq_swap( waitq_t *, siteid_t, siteid_t );
void waitq_push( waitq_t *, siteid_t, time_t );
void waitq_pop( waitq_t *, siteid_t *, time_t * );
int waitq_empty( waitq_t * );
bool waitq_available( waitq_t *, time_t );
void waitq_destroy( waitq_t * );
void waitq_dump( waitq_t * );

#endif
