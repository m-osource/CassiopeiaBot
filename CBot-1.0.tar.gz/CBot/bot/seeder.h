/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _SEEDER_H_INCLUDED_
#define _SEEDER_H_INCLUDED_

#include <config.h>

// System libraries

#include <features.h>
#include <fstream>
#include <string>
#include <assert.h>
#include <getopt.h>
#include <map>
#include <iostream>
#include <errno.h>

using namespace std;

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "xmlconf-main.h"
#include "perfect_hash.h"
#include "utils.h"
#include "Url.h"
#include "Meta.h"
#include "cleanup.h"
#include "Storage.h"
#include "linkidx.h"
#include "harvestidx.h"
#include "string_list.h"

// Constants

const int SEEDER_PAGE_WIDTH = 50;

// Globals

string_list_t *domain_suffixes;
perfhash_t keep_special;
perfhash_t accept_protocol;
perfhash_t extensions_ignore;
perfhash_t extensions_dynamic;

regex_t reject_patterns;

regex_t sessionid_patterns;
char **sessionid_variables		= NULL;
int sessionid_variables_count	= 0;
atomic<internal_long_uint_t> processed_lines (0);


// need to passing arguments to threads functions
typedef struct {
	instance_t inst;
	bool force_start;
	harvest_status_t status;
} seeder_thread_args_t;

Meta *meta			= NULL;
Url	*url			= NULL;
Storage *lidx		= NULL;
Harvest *harv		= NULL;


// Note: site_locked_list, seeder_site_mutex are needed because site->count (or site_count_doc) must be updated in thread-safe mode
// site_count_doc is used as alternative method if some features on manager are enabled
//

#define VIRTUAL_INSTANCES (CONF_COLLECTION_DISTRIBUTED * CONF_COLLECTION_DISTRIBUTED)

site_t				*site_locked_list = NULL;
docid_t				**site_count_doc = NULL;

pthread_barrier_t	*seeder_barrier = NULL;
pthread_mutex_t		*seeder_mutex = NULL;
pthread_mutex_t 	*seeder_site_mutex = NULL; // needed for updating in thread-safe mode count_doc element of site_t structure


// more mutex less slow
urlmutex_t			*urlslock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
urlmutex_t			*urldlock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
urlmutex_t			*urlplock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
strgmutex_t			*strglock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

// Functions

void seeder_lock_linkidx( instance_t & );
void seeder_unlock_linkidx( instance_t & );
void seeder_lock_metaddx_site( siteid_t & );
void seeder_unlock_metaddx_site( siteid_t & );
void seeder_sync_threads( pthread_barrier_t * );
void *seeder_thread_function_process_harvest( void * );
void seeder_init_maps();
void seeder_show_legend();
docid_t seeder_resolve_link( instance_t &, doc_t *, char *, char *, char *, char *, site_t *, harvest_status_t & );
void seeder_save_links( doc_t *, out_link_t [], unsigned int );
void seeder_open_indexes();
bool seeder_is_excluded( doc_t *doc, char *path );
void seeder_usage();

#endif
