/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "infixddx.h"

/* This basic class must be only used inside ifxddx.cc
// This is the reason because is declared inside!
class IfxLock {

	int rc;

public:

	// ctor
	IfxLock(void)
		:rc	(0)
	{
	}

	//
	// Name: locka_key
	//
	// Description: lock mutex
	//
	// Input:
	//   ifxddx - the url index structure
	//   id_instance - id instance
	//
	// Return:
	//
	void c_key(ifxddx_t *u, instance_t &id_instance)
	{
		if (u->klock != NULL && (rc = pthread_mutex_lock(&(u->klock->lockc[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
} lock;
*/

// This basic class must be only used inside ifxddx.cc
// This is the reason because is declared inside!
class IfxWLock {

public:

	// ctor
	IfxWLock(void)
	{
	}

	//
	// Name: locka_key
	//
	// Description: lock write/read mutex on write mutex
	//
	// Input:
	//   ifxddx - the url index structure
	//   id_instance - id instance
	//
	// Return:
	//
	void a_key(ifxddx_t *u, instance_t &id_instance)
	{
		int rc = 0;

		if (u->klock != NULL && (rc = pthread_rwlock_wrlock(&(u->klock->rwlocka[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}

	void b_key(ifxddx_t *u, instance_t &instance)
	{
		int rc = 0;

		if (u->klock != NULL && (rc = pthread_rwlock_wrlock(&(u->klock->rwlockb[instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}

	void c_key(ifxddx_t *u, instance_t &id_instance)
	{
		int rc = 0;

		if (u->klock != NULL && (rc = pthread_rwlock_wrlock(&(u->klock->rwlockc[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
} wrlock;

// This basic class must be only used inside ifxddx.cc
// This is the reason because is declared inside!
class IfxRLock {

public:

	// ctor
	IfxRLock(void)
	{
	}

	//
	// Name: locka_key
	//
	// Description: lock write/read mutex on write mutex
	//
	// Input:
	//   ifxddx - the url index structure
	//   id_instance - id instance
	//
	// Return:
	//
	void a_key(ifxddx_t *u, instance_t &id_instance)
	{
		int rc = 0;

		if (u->klock != NULL && (rc = pthread_rwlock_rdlock(&(u->klock->rwlocka[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}

	void b_key(ifxddx_t *u, instance_t &instance)
	{
		int rc = 0;

		if (u->klock != NULL && (rc = pthread_rwlock_rdlock(&(u->klock->rwlockb[instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}

	void c_key(ifxddx_t *u, instance_t &id_instance)
	{
		int rc = 0;

		if (u->klock != NULL && (rc = pthread_rwlock_rdlock(&(u->klock->rwlockc[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
} rdlock;

// This basic class must be only used inside ifxddx.cc
// This is the reason because is declared inside!
class IfxUnlock {

public:

	// ctor
	IfxUnlock(void)
	{
	}

	//
	// Name: unlocka_key
	//
	// Description: Allocate memory and create mutex
	//
	// Input:
	//   ifxddx - the url index structure
	//   id_instance - id instance
	//
	// Return:
	//
	                                            
	void a_key(ifxddx_t *u, instance_t &id_instance)
	{
		int rc = 0;

		if (u->klock != NULL && (rc = pthread_rwlock_unlock(&(u->klock->rwlocka[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}

	void b_key(ifxddx_t *u, instance_t &instance)
	{
		int rc = 0;

		if (u->klock != NULL && (rc = pthread_rwlock_unlock(&(u->klock->rwlockb[instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
	void c_key(ifxddx_t *u, instance_t &id_instance)
	{
		int rc = 0;

		if (u->klock != NULL && (rc = pthread_rwlock_unlock(&(u->klock->rwlockc[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}

} unlock;

off64_t IFXDDX_KEY_SIZE;

using namespace std;

// cannot be passed as thread_local inside this code!
// thread_local cpu_set_t system_cpus;

//
// Name: ifxddx_new
//
// Description:
//   Creates a new url index in the given directory
//
// Input:
//   dirname - directory to create url index
//
// Return:
//   urlindex structure
//
ifxddx_t *ifxddx_new(const char *dirname)
{
	// Allocate memory
	ifxddx_t *u = CBALLOC(ifxddx_t, MALLOC, 1);

	assert(CONF_OK);

	u->threads_key_count = 0;
	u->key_count = 0;
	u->klock = NULL;

	// Set readonlymode false
	u->readonly	= false;

	// Allocate memory
	u->distributed = CBALLOC(iddx_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		ifxddx_thread_function_args_t *args = CBALLOC(ifxddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->u = u;
		args->d = (char *)dirname;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create( &threads[i], NULL, ifxddx_thread_function_new, (void *) args) )
				die("error creating thread!");
		}
		else
			ifxddx_thread_function_new((void *) args); // only one distribution, function is call without thread
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}

	// Return
	return u;	
} 

//
// Name: ifxddx_thread_function_new
//
// Description: invoked by 'ifxddx_new' as thread
//
// Arguments: a void pointer to ifxddx_thread_function_args_t type structure that contain instance and char* directory 
//
// Return: NULL
//
void *ifxddx_thread_function_new(void *args)
{
try
{
	cpu_set_t system_cpus;

	ifxddx_thread_function_args_t *arguments = (ifxddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	ifxddx_t *u = arguments->u;
	char *dirname = arguments->d;

	u->distributed[inst].key_hash = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXSITE);

	// Set default values
	u->distributed[inst].key_count = 0;
	u->distributed[inst].key_next_char = 1; // start in 1

	// Work dir
	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
	strcpy(u->distributed[inst].dirname, relative_rem_path);
	free(relative_rem_path);

	// Open files
	char filename[MAX_STR_LEN];

	// key_list
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_KEY_LIST);
	u->distributed[inst].key_list = fopen64(filename, "w+");

	if(u->distributed[inst].key_list == NULL)
		die("Failed to open keys index %s on %s", cberr(), dirname);

	// Create memory area for key names
	IFXDDX_KEY_SIZE = IFXDDX_EXPECTED_KEY_SIZE * CONF_COLLECTION_MAXSITE;
	u->distributed[inst].key = CBALLOC(char, MALLOC, IFXDDX_KEY_SIZE);
	u->distributed[inst].key[0] = '\0';

	// Clean values buffer
	// cerr << "create array of key infix ranking and setting it to default values..." << endl;
	u->distributed[inst].key_irank = CBALLOC(iq_t, CALLOC, CONF_COLLECTION_MAXSITE);

	// Clean values_start_sector tables
	// cerr << "create array of values offset and setting it to default values..." << endl;
	u->distributed[inst].values_start_sector = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXSITE);

	// Clean values_geo tables
	// cerr << "create array of values sectors location and setting it to default values..." << endl;
	u->distributed[inst].values_geo = CBALLOC(off64_t, CALLOC, (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTORS));

	// Clean values buffer
	// cerr << "create array of values and setting it to default values..." << endl;
	u->distributed[inst].values = CBALLOC(char, CALLOC, (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTOR_SIZE * IFXDDX_EXPECTED_SECTORS));

	// Set default values
	u->distributed[inst].values_next_sector = 0;

	arguments->d = NULL;
	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(NULL);
}
}

//
// Name: ifxddx_open
//
// Description:
//   Opens a url index in the given directory, or
//   create a new one if necessary.
//
// Input:
//   dirname - directory in which the infix index is located
//   readonly - flag for readonly mode
//
// Return:
//   infix index structure
//
ifxddx_t *ifxddx_open(const char *dirname, bool readonly)
{
	assert(CONF_COLLECTION_DISTRIBUTED < UCHAR_MAX); // if not, change type

	// The configuration file has to be open
	//assert(CONF_OK);

	bool mainmissing = false;

	for (instance_t instance = 0; instance < CONF_COLLECTION_DISTRIBUTED; instance++)
	{
		// Open the main file
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, instance);
		assert(strlen(relative_rem_path) < MAX_STR_LEN);
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, IFXDDX_FILENAME_ALL);
		free(relative_rem_path);
		FILE *file_all = fopen64(filename, "r");

		// Check if main file is found
		if(file_all == NULL)
		{
			mainmissing = true;
			break;
		}
		else
			fclose(file_all);
	}

	if(mainmissing == true)
	{
		if (readonly == true)
			die("Opening keys index, one or more main files are missing\nFailed to open keys index %s on %s", cberr(), dirname);
		else
		{
			cerr << "Removing old keys indexes ... " << endl;
			ifxddx_remove(dirname);
			return ifxddx_new(dirname);
		}
	}

	// Allocate memory
	ifxddx_t *u = CBALLOC(ifxddx_t, MALLOC, 1);

	u->key_count = 0;
	u->klock = NULL;
	u->readonly	= readonly;

	// Allocate memory
	u->distributed = CBALLOC(iddx_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		ifxddx_thread_function_args_t *args = CBALLOC(ifxddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->u = u;
		args->d = (char *)dirname;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create( &threads[i], NULL, ifxddx_thread_function_open, (void *) args) )
				die("error creating thread!");
		}
		else
			ifxddx_thread_function_open((void *) args); // only one distribution, function is call without thread
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

	// Update keys master counter
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		u->key_count += u->distributed[i].key_count;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		unsigned long long int count = u->key_count; // atomic cannot copy to atomic 
		u->threads_key_count = (keyid_t)count; // and in open/new function mutex is not needed
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		free(threads);

	// Return
	return u;
}

//
// Name: ifxddx_thread_function_open
//
// Description: invoked by 'ifxddx_open' as thread
//
// Arguments: a void pointer to ifxddx_thread_function_args_t type structure 
//
// Return: NULL
//
void *ifxddx_thread_function_open(void *args)
{
try
{
	cpu_set_t system_cpus;

	ifxddx_thread_function_args_t *arguments = (ifxddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	ifxddx_t *u = arguments->u;
	char *dirname = arguments->d;

	// Make directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);

	// Open the main file
	char filename[MAX_STR_LEN];
	sprintf(filename, "%s/%s", relative_rem_path, IFXDDX_FILENAME_ALL);
	FILE *file_all = fopen64(filename, "r");

	errno = 0; // errno is thread local

	// Read the main file
	size_t count = fread(&(u->distributed[inst]), sizeof(iddx_t), 1, file_all);

	assert(count == 1);
	fclose(file_all);

	// Copy dir
	strcpy(u->distributed[inst].dirname, relative_rem_path);
	free(relative_rem_path);

	// Open the other files
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_KEY_LIST);

	if(u->readonly)
		u->distributed[inst].key_list = fopen64(filename, "r");
	else
		u->distributed[inst].key_list = fopen64(filename, "a+");

	if(u->distributed[inst].key_list == NULL)
		die("Failed to open keys index %s on %s", cberr(), filename );

	// Read key names
	IFXDDX_KEY_SIZE = IFXDDX_EXPECTED_KEY_SIZE * CONF_COLLECTION_MAXSITE;

	// Open key's file
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_KEY);
	FILE *key_file = fopen64(filename, "r");

	// Get key's file size
	off64_t file_key_length;
	fseeko(key_file, 0, SEEK_END);
	file_key_length = ftello(key_file);
	assert(file_key_length > 0);
	fseeko(key_file, 0, SEEK_SET);

	if(file_key_length >= IFXDDX_KEY_SIZE)
		die("The IFXDDX_KEY_SIZE is too small, increase CONF_COLLECTION_MAXSITE or EXPECTED_KEY_SIZE\nFailed to open keys index %s", cberr());

	// Allocate memory
	u->distributed[inst].key = CBALLOC(char, MALLOC, IFXDDX_KEY_SIZE);

	// Read
	count = fread(u->distributed[inst].key, file_key_length, 1, key_file);
	assert(count == 1);

	// Close
	fclose(key_file);

	// Read KEY hash table
	u->distributed[inst].key_hash = CBALLOC(off64_t, MALLOC, CONF_COLLECTION_MAXSITE);

	sprintf(filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_KEY_HASH);

	// Open
	FILE *file_key_hash = fopen64(filename, "r");
	assert(file_key_hash != NULL);

	// Read
	keyid_t keys_readed = fread(u->distributed[inst].key_hash, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_key_hash);
	assert(keys_readed == CONF_COLLECTION_MAXSITE);

	// Close
	fclose(file_key_hash);

	// Read infix ranking from table
	u->distributed[inst].key_irank = CBALLOC(iq_t, MALLOC , CONF_COLLECTION_MAXSITE);
	sprintf( filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_KEY_IRANK );

	// Open
	FILE *file_key_irank = fopen64( filename, "r" );
	assert( file_key_irank != NULL );

	// Read
	keyid_t irank_readed = fread( u->distributed[inst].key_irank, sizeof(iq_t), CONF_COLLECTION_MAXSITE, file_key_irank );
	assert( irank_readed == CONF_COLLECTION_MAXSITE );

	// Close
	fclose( file_key_irank );

	// Read values_start_sector table
	u->distributed[inst].values_start_sector = CBALLOC(off64_t, MALLOC , CONF_COLLECTION_MAXSITE);
	sprintf( filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_VALUES_OFFSET );

	// Open
	FILE *file_values_start_sector = fopen64( filename, "r" );
	assert( file_values_start_sector != NULL );

	// Read
	keyid_t values_start_sector_readed = fread( u->distributed[inst].values_start_sector, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_values_start_sector );
	assert( values_start_sector_readed == CONF_COLLECTION_MAXSITE );

	// Close
	fclose( file_values_start_sector );

	// Read values_geo table
	u->distributed[inst].values_geo = CBALLOC(off64_t, MALLOC, (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTORS));
	sprintf( filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_VALUES_GEO );

	// Open
	FILE *file_values_geo = fopen64( filename, "r" );
	assert( file_values_geo != NULL );

	// Read
	keyid_t values_geo_readed = fread( u->distributed[inst].values_geo, sizeof(off64_t), (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTORS), file_values_geo );
	assert( values_geo_readed == (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTORS) );

	// Close
	fclose( file_values_geo );

	// Read total sectors in values table
	u->distributed[inst].values = CBALLOC(char, MALLOC, (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTOR_SIZE * IFXDDX_EXPECTED_SECTORS));
	sprintf( filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_VALUES );

	// Open
	FILE *file_values = fopen64( filename, "r" );
	assert( file_values != NULL );

	// Read
	keyid_t values_readed = fread( u->distributed[inst].values, sizeof(char), (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTOR_SIZE * IFXDDX_EXPECTED_SECTORS), file_values );
	assert( values_readed == (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTOR_SIZE * IFXDDX_EXPECTED_SECTORS));

	// Close
	fclose( file_values );

	arguments->d = NULL;
	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(NULL);
}
}
                                            
//
// Name: ifxddx_setmutex
//
// Description: Allocate memory and create mutex
//
// Input:
//   ifxddx - the url index structure
//   ifxmutex_t structure pointer to klock
//
// Return:
//
void ifxddx_setmutex(ifxddx_t *u, ifxmutex_t **klock)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1 && u->readonly == false)
	{
		*klock = CBALLOC(ifxmutex_t, MALLOC, 1);
		(*klock)->rwlocka = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		(*klock)->rwlockb = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		(*klock)->rwlockc = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
		{
			(*klock)->rwlocka[i] = PTHREAD_RWLOCK_INITIALIZER;
			(*klock)->rwlockb[i] = PTHREAD_RWLOCK_INITIALIZER;
			(*klock)->rwlockc[i] = PTHREAD_RWLOCK_INITIALIZER;
		}

		u->klock = *klock;
	}
}
                                            
//
// Name: ifxddx_resolve_key
//
// Description:
//   Verify a keyming name and add it if necessary (basic version of algorithm but multithread)
//
// Input:
//   ifxddx - the url index structure
//   key - the keyming to check
//   keyid - the key id to return
//   readonly - do not write anything if function (even in the case algorithm has been to write to disk)
//
// Output:
//   keyid - keyid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   IFXDDX_EXISTENT - the key existed
//   IFXDDX_CREATED_KEY - the key was added
//   IFXDDX_NOT_FOUND - the key is not known and was not created
//
ifxddx_status_t ifxddx_resolve_key(ifxddx_t *u, const char *key, keyid_t *keyid, bool readonly)
{
	assert(u != NULL);
//	assert((u->readonly == false && u->klock != NULL) || (u->readonly == true && u->klock == NULL));

	if (u->readonly == true)
		readonly = true;

	size_t slen = strlen(key);
	assert(slen > 0);

	keyid_t bucket = 0;
	keyid_t keyid_check = 0;

	// Check if the key exists
	keyid_check = ifxddx_check_key(u, key, &(bucket), readonly);

	instance_t instance = (bucket % CONF_COLLECTION_DISTRIBUTED);

	if(keyid_check > 0)
	{
		if(keyid != NULL)
			*keyid	= keyid_check;

		unlock.b_key(u, instance);
		return IFXDDX_EXISTENT;
	}

	if (readonly == true || keyid == NULL)
	{
		unlock.b_key(u, instance);
		return IFXDDX_NOT_FOUND;
	}
	else // new id to insert
	{
		instance_t CCD = CONF_COLLECTION_DISTRIBUTED;
		// We need to change lock type of rwlockb mutex
		wrlock.b_key(u, CCD);
		unlock.b_key(u, instance);
		wrlock.b_key(u, instance);
		unlock.b_key(u, CCD);

		// We calculate id_instance and get the next keyid
		if (u->klock != NULL)
			*keyid = (++u->threads_key_count);
		else
			*keyid = (u->key_count + 1);

		instance_t id_instance = ((*keyid - 1) % CONF_COLLECTION_DISTRIBUTED);

		// Locking needed mutex
		wrlock.a_key(u, id_instance);

		if((u->distributed[id_instance].key_count + 1) > CONF_COLLECTION_MAXSITE)
		{
			unlock.a_key(u, id_instance);
			unlock.b_key(u, instance);
			cerr << "Distributed Index is small. Increase CONF_COLLECTION_MAXSITE!" << endl;
			return(IFXDDX_ERROR);
		}

		// Get position in key_hash
		keyid_t hash_pos = (bucket / CONF_COLLECTION_DISTRIBUTED);

		// Increment local key count
		++(u->distributed[id_instance].key_count);

		// FIRST: Store string
		memcpy(u->distributed[instance].key + u->distributed[instance].key_next_char, key, slen + 1);

		// Store keyid
		memcpy(u->distributed[instance].key + u->distributed[instance].key_next_char + slen + 1, keyid, sizeof(keyid_t));

		// Put in bucket
		u->distributed[instance].key_hash[hash_pos] = u->distributed[instance].key_next_char;

		// Save in list of keys
		ifxlist_key_t *position = CBALLOC(ifxlist_key_t, CALLOC, 1);
		position->hash_pos = hash_pos;
		position->bucket_instance = instance;
		fwrite(position, sizeof(ifxlist_key_t), 1, u->distributed[id_instance].key_list);
		free(position);

		// Unlocking unneeded mutex
		unlock.a_key(u, id_instance);

		// Move char pointer
		u->distributed[instance].key_next_char = u->distributed[instance].key_next_char + slen + 1 + sizeof(keyid_t);

		if(u->distributed[instance].key_next_char > IFXDDX_KEY_SIZE)
		{
			unlock.b_key(u, instance);
			cerr << "Stemmings memory area full on index " << instance << " !" << endl;
			cerr << "Increase CONF_COLLECTION_MAXSITE or EXPECTED_KEY_SIZE" << endl;
			return(IFXDDX_ERROR);
		}

		// Increase counter
		u->key_count++;

		unlock.b_key(u, instance);
	}

	// Return
	return IFXDDX_CREATED_KEY;
}

//
// Name: ifxddx_check_key
//
// Description:
//   Check if a keyming exists
//
// Input:
//   ifxddx - the keyming index structure
//   key - the keyming name to check
//   bucket - the bucket in which this was found
//   offset - offset where bucket was found in hash file
//
// Return
//   a keyid if resolved
//   0 if not found
//
keyid_t ifxddx_check_key(ifxddx_t *u, const char *key, keyid_t *bucket, bool readonly)
{
	#define MAXKEYS (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED)
	assert(u != NULL);
	assert(key != NULL);
	assert(strlen( key) > 0 );

	// First attempt to find bucket (debug purpose)
	//keyid_t test = ifxddx_hashing_key(key);
	//cout << "DOMAIN " << key << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = ifxddx_hashing_key(key);

	instance_t instance = (*bucket % CONF_COLLECTION_DISTRIBUTED);
	keyid_t pos = (*bucket / CONF_COLLECTION_DISTRIBUTED);

	if (readonly == true)
		rdlock.b_key(u, instance);
	else
		wrlock.b_key(u, instance);

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while(u->distributed[instance].key_hash[pos] > 0)
	{
		char *pddx = u->distributed[instance].key + u->distributed[instance].key_hash[pos]; // puntatore all'offset indicato dall'hash

		const char *input = key;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pddx) != '\0' && *(input) != '\0' && *(pddx) == *(input) && *(pddx++) && *(input++));

		if (*pddx++ == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
			return *((keyid_t *)pddx); // restituisce l'id

		(*bucket) = (((*bucket) + CONF_COLLECTION_DISTRIBUTED) % MAXKEYS);
		pos = ((pos + 1) % MAXKEYS);
	}

	return (keyid_t)0;
}

// Hashing Functions for keymings
keyid_t ifxddx_hashing_key(const char *text)
{
	#define MAXKEYS (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED)
	keyid_t val;
	for(val=0; *text; text++)
		val = ((131 * (val == 0 ? 1 : val) + *text) % MAXKEYS);

	return val;
}

//
// Name: ifxddx_key_by_keyid
//
// Description:
//   Get the name of a key based on its id
//
// Return:
//
void ifxddx_key_by_keyid(ifxddx_t *u, keyid_t &keyid, char *name)
{
	// Check if 'id' is in overflow
	if (keyid > u->key_count)
	{
		name[0] = '\0';
		return;
	}

	// Obtain id instance
	instance_t id_instance = ((keyid - 1) % CONF_COLLECTION_DISTRIBUTED);

	// Locking needed mutex
	rdlock.a_key(u, id_instance);

	// Seek
	fseeko(u->distributed[id_instance].key_list, ((keyid - 1) / CONF_COLLECTION_DISTRIBUTED) * sizeof(ifxlist_key_t), SEEK_SET);

	// Read offset
	ifxlist_key_t *position = CBALLOC(ifxlist_key_t, CALLOC, 1);
	fread(position, sizeof(ifxlist_key_t), 1, u->distributed[id_instance].key_list);

	// Put at end
	fseeko(u->distributed[id_instance].key_list, 0, SEEK_END);

	// Unlocking unneeded mutex
	unlock.a_key(u, id_instance);

	// Locking needed mutex
	rdlock.b_key(u, position->bucket_instance);

	// Check if 'id' is not valid
	if (u->distributed[position->bucket_instance].key_hash[position->hash_pos] == 0)
		name[0] = '\0';
	else
	{	// Copy to 'name'
		assert(strlen( (u->distributed[position->bucket_instance].key) + u->distributed[position->bucket_instance].key_hash[position->hash_pos]) < MAX_STR_LEN );
		strcpy(name, (u->distributed[position->bucket_instance].key) + u->distributed[position->bucket_instance].key_hash[position->hash_pos]);
	}

	// Unlocking unneeded mutex
	unlock.b_key(u, position->bucket_instance);
	free(position);
}

//
// Name: ifxddx_close
//
// Description:
//   Closes the url index, saving data to disk. Work with threads only if we have more the one distribution
//
// Input:
//   ifxddx - the url index structure
//
void ifxddx_close(ifxddx_t *u)
{
	assert(CONF_OK);

	// Check what i'm going to close
	assert(u != NULL);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		assert(u->threads_key_count == u->key_count);
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		ifxddx_thread_function_args_t *args = CBALLOC(ifxddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->u = u;
		args->d = NULL;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create( &threads[i], NULL, ifxddx_thread_function_close, (void *) args))
				die("error creating thread!");
		}
		else
			ifxddx_thread_function_close((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		free(threads);

	// Nullify to avoid re-closing
	free(u->distributed);

	// Nullify to avoid re-closing
	free(u);
}

//
// Name: ifxddx_thread_function_close
//
// Description: invoked by 'ifxddx_close' as thread
//
// Arguments: a void pointer to ifxddx_thread_function_args_t type structure that contain instance and ifxddx_t type structure 
//
// Return: NULL
//
void *ifxddx_thread_function_close(void *args)
{
try
{
	cpu_set_t system_cpus;

	ifxddx_thread_function_args_t *arguments = (ifxddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	ifxddx_t *u = arguments->u;

	char filename[MAX_STR_LEN];

	size_t count;

	// Close and nullify all the filehandlers
	fclose(u->distributed[inst].key_list); u->distributed[inst].key_list = NULL;

	// If readonly mode, bail out, do not write anything
	if(u->readonly == true)
	{
		free(u->distributed[inst].key); u->distributed[inst].key = NULL;
		free(u->distributed[inst].key_hash); u->distributed[inst].key_hash = NULL;
		free(u->distributed[inst].key_irank); u->distributed[inst].key_irank = NULL;
		free(u->distributed[inst].values_start_sector); u->distributed[inst].values_start_sector = NULL;
		free(u->distributed[inst].values_geo); u->distributed[inst].values_geo = NULL;
		free(u->distributed[inst].values); u->distributed[inst].values = NULL;
		free(args);
		return NULL;
	}

	// Save the key names 
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_KEY);

	// Open
	FILE *key_file = fopen64(filename, "w");
	assert(key_file != NULL);

	// Write
	count = fwrite(u->distributed[inst].key, u->distributed[inst].key_next_char, 1, key_file);
	assert(count == 1);

	// Close
	fclose(key_file);
	free(u->distributed[inst].key);
	u->distributed[inst].key = NULL;

	// Save the KEY hash tables
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_KEY_HASH);

	// Open
	FILE *file_key_hash = fopen64(filename, "w");
	assert(file_key_hash != NULL);

	// Write
	keyid_t keys_writed = fwrite(u->distributed[inst].key_hash, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_key_hash);
	assert(keys_writed == CONF_COLLECTION_MAXSITE);

	// Close
	fclose(file_key_hash);
	free(u->distributed[inst].key_hash);
	u->distributed[inst].key_hash = NULL;

	// Save the irank tables
	sprintf( filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_KEY_IRANK );

	// Open
	FILE *file_key_irank = fopen64( filename, "w" );
	assert( file_key_irank != NULL );

	// Write
	keyid_t irank_writed = fwrite( u->distributed[inst].key_irank, sizeof(iq_t), CONF_COLLECTION_MAXSITE, file_key_irank );
	assert( irank_writed == CONF_COLLECTION_MAXSITE );

	// Close
	fclose( file_key_irank );
	free( u->distributed[inst].key_irank );
	u->distributed[inst].key_irank = NULL;

	// Save the values_start_sector tables
	sprintf( filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_VALUES_OFFSET );

	// Open
	FILE *file_key_values_start_sector = fopen64( filename, "w" );
	assert( file_key_values_start_sector != NULL );

	// Write
	keyid_t values_start_sector_writed = fwrite( u->distributed[inst].values_start_sector, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_key_values_start_sector );
	assert( values_start_sector_writed == CONF_COLLECTION_MAXSITE );

	// Close
	fclose( file_key_values_start_sector );
	free( u->distributed[inst].values_start_sector );
	u->distributed[inst].values_start_sector = NULL;

	// Save the values_geo tables
	sprintf( filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_VALUES_GEO );

	// Open
	FILE *file_key_values_geo = fopen64( filename, "w" );
	assert( file_key_values_geo != NULL );

	// Write
	keyid_t values_geo_writed = fwrite( u->distributed[inst].values_geo, sizeof(off64_t), (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTORS), file_key_values_geo );
	assert( values_geo_writed == (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTORS) );

	// Close
	fclose( file_key_values_geo );
	free( u->distributed[inst].values_geo );
	u->distributed[inst].values_geo = NULL;

	// Save the values buffer
	sprintf( filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_VALUES );

	// Open
	FILE *file_values = fopen64( filename, "w" );
	assert( file_values != NULL );

	// Write
	keyid_t values_writed = fwrite( u->distributed[inst].values, sizeof(char), (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTOR_SIZE * IFXDDX_EXPECTED_SECTORS), file_values );
	assert( values_writed == (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTOR_SIZE * IFXDDX_EXPECTED_SECTORS) );

	// Close
	fclose( file_values );
	free( u->distributed[inst].values );
	u->distributed[inst].values = NULL;

	// Write the whole structure to disk
	sprintf( filename, "%s/%s", u->distributed[inst].dirname, IFXDDX_FILENAME_ALL );

	// Open
	FILE *file_all = fopen64( filename, "w" );
	assert( file_all != NULL );

	// Write
	count = fwrite( &(u->distributed[inst]), sizeof(iddx_t), 1, file_all ); // falso positivo in valgrind
	assert( count == 1 );

	// Close
	fclose(file_all);

	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(NULL);
}
}
                                            
//
// Name: ifxddx_destroymutex
//
// Description: Free memory and destroy mutex
//
// Input:
//   ifxddx - the infix index structure
//
// Return:
//
void ifxddx_destroymutex( ifxddx_t *u )
{
	if (CONF_COLLECTION_DISTRIBUTED > 1 && u->readonly == false)
	{
		// now, we ensure that all mutex are unused and destroyed
		int rc = 0;

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
		{
			if ((rc = pthread_rwlock_destroy(&(u->klock->rwlocka[i]))) != 0)
				die("error destroying mutex %s", strerror(rc));

			if ((rc = pthread_rwlock_destroy(&(u->klock->rwlockb[i]))) != 0)
				die("error destroying mutex %s", strerror(rc));

			if ((rc = pthread_rwlock_destroy(&(u->klock->rwlockc[i]))) != 0)
				die("error destroying mutex %s", strerror(rc));
		}

		free(u->klock->rwlocka); u->klock->rwlocka = NULL;
		free(u->klock->rwlockb); u->klock->rwlockb = NULL;
		free(u->klock->rwlockc); u->klock->rwlockc = NULL;
		free(u->klock);
	}
}

//
// Name: ifxddx_remove
//
// Description:
//   Deletes all files for an ifxddx
//
// Input:
//   dirname - the directory to clean
//
void ifxddx_remove(const char *dirname)
{
	struct stat64 statbuf;

	pthread_t *threads = NULL;

	instance_t max_instances = 0;

	// check how many directory contain data to delete
	for (unsigned int i = 0; i < UINT_MAX; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, i);

		if (stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
			max_instances++;
		else
		{
			free(relative_rem_path);
			break;
		}

		free(relative_rem_path);
	}

	if (max_instances > 1)
		threads = CBALLOC(pthread_t, MALLOC, max_instances);

	for (instance_t i = 0; i < max_instances; i++)
	{
		ifxddx_thread_function_args_t *args = CBALLOC(ifxddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->u = NULL;
		args->d = (char *)dirname;

		if (max_instances > 1)
		{
			if (pthread_create( &threads[i], NULL, ifxddx_thread_function_remove, (void *) args) )
				die("error creating thread!");
		}
		else
			ifxddx_thread_function_remove((void *) args); // only one distribution, function is call without thread 
	}

	if (max_instances > 1)
	{
		CBotjoin(threads, max_instances);

		free(threads);
	}
}

//
// Name: ifxddx_thread_function_remove
//
// Description: invoked by 'ifxddx_remove' as thread
//
// Arguments: a void pointer to ifxddx_thread_function_args_t type structure 
//
// Return: NULL
//
void *ifxddx_thread_function_remove(void *args)
{
try
{
	cpu_set_t system_cpus;

	ifxddx_thread_function_args_t *arguments = (ifxddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	char *dirname = arguments->d;
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);

	errno = 0; // errno is thread local

	queue<string> files;

	// Push files
	files.push(IFXDDX_FILENAME_KEY_LIST);
	files.push(IFXDDX_FILENAME_KEY);
	files.push(IFXDDX_FILENAME_KEY_HASH);
	files.push(IFXDDX_FILENAME_VALUES_OFFSET);
	files.push(IFXDDX_FILENAME_VALUES);
	files.push(IFXDDX_FILENAME_ALL);

	// Delete
	while(! files.empty())
	{
		// Create filename
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, files.front().c_str());

		// Delete file
		int rc = unlink(filename);

		if(rc != 0 && errno != ENOENT)
			die("Couldn't unlink file %s on %s", cberr(), files.front().c_str());

		// Remove file from queue
		files.pop();
	}

	if (inst >= CONF_COLLECTION_DISTRIBUTED)
	{
		// Delete dir (rimuove la directory ifx ...)
		int rc = remove(relative_rem_path);

		if(rc != 0 && errno != ENOENT)
			die("Couldn't remove directory %s on %s", cberr(), relative_rem_path);
	}

	free(relative_rem_path);

	arguments->d = NULL;

	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(NULL);
}
}

//
//
// Name: ifxddx_read_infix
//
// Description:
//   Legge sequenzialmente i settori del buffer che compongono la stringa 'valore'
//
// Input:
//   ifxddx - the infix index structure
//   keyid - chiave univoca del nome dominio
//
// Return:
//   La struttura contente valore e lunghezza relativi alla chiave immessa
//
char *ifxddx_read_infix(ifxddx_t *u, keyid_t &keyid, bool cleaned)
{
	instance_t instance = ((keyid - 1) % CONF_COLLECTION_DISTRIBUTED);
	keyid_t pos = (((keyid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);
	size_t size = 0;

	rdlock.c_key(u, instance);

	off64_t next = u->distributed[instance].values_start_sector[pos];

	for(;;)
	{
		if (u->distributed[instance].values_geo[next] > 0)
		{
			next = u->distributed[instance].values_geo[next];
			size += IFXDDX_EXPECTED_SECTOR_SIZE;
		}
		else
			break;
	}

	size_t chunk_size = 0;

	// Si misura la lunghezza stringa dati contenuta nell'ultimo settore
	for (unsigned short i = 0; i < IFXDDX_EXPECTED_SECTOR_SIZE; i++)
				if (u->distributed[instance].values[((next * IFXDDX_EXPECTED_SECTOR_SIZE) + i)] != '\0')
					chunk_size++;

	if (size > 0) // se i dati da leggere occupano più settori
		size = (size + chunk_size);
	else
		size = chunk_size;

	char *infixed = CBALLOC(char, MALLOC, (size + 1));

	if (infixed != NULL)
	{
		infixed[0] = '\0';

		next = u->distributed[instance].values_start_sector[pos];

		off64_t dest_offset = 0;

		while (u->distributed[instance].values_geo[next] > 0)
		{
			memcpy(infixed + dest_offset, &(u->distributed[instance].values[(next * IFXDDX_EXPECTED_SECTOR_SIZE)]), IFXDDX_EXPECTED_SECTOR_SIZE);

			dest_offset += IFXDDX_EXPECTED_SECTOR_SIZE;

			next = u->distributed[instance].values_geo[next];
		}

		memcpy(infixed + dest_offset, &(u->distributed[instance].values[(next * IFXDDX_EXPECTED_SECTOR_SIZE)]), chunk_size);
		infixed[size] = '\0';
	}

	unlock.c_key(u, instance);

	if (cleaned == true)
	{
		char *pch = strchr(infixed, ':');

		if (pch != NULL)
			pch[0] = ' '; // delete sensitive words separator
	}

	return infixed;
}

//
// Name: ifxddx_write_infix
//
// Description:
//   Scrive sequenzialmente i nuovi settori in coda al buffer
//
// Input:
//   ifxddx - the url index structure
//   key - la stringa chiave
//   newvalue - il nuovo valore da immagazzinare
//   lvalue - la lunghezza della nuova chiave
//
// Return:
//  Vero se l'operazione è andata a buon fine
//
bool ifxddx_write_infix(ifxddx_t *u, keyid_t &keyid, char *infixed, iq_t &iq)
{
	instance_t instance = ((keyid - 1) % CONF_COLLECTION_DISTRIBUTED);
	keyid_t pos = (((keyid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);
	size_t len = strlen(infixed);

	wrlock.c_key(u, instance);

	if (u->distributed[instance].values_next_sector + (len / IFXDDX_EXPECTED_SECTOR_SIZE) > (CONF_COLLECTION_MAXSITE - 1))
	{
		cerr << "Error: Database is full! Increase IFXDDX_EXPECTED_SECTORS per keyid or IFXDDX_EXPECTED_SECTOR_SIZE!" << endl;
		return false;
	}

	u->distributed[instance].key_irank[keyid] = iq;

	u->distributed[instance].values_start_sector[pos] = u->distributed[instance].values_next_sector;

	memcpy( u->distributed[instance].values + (u->distributed[instance].values_next_sector * IFXDDX_EXPECTED_SECTOR_SIZE), infixed, len );

	unsigned int v = u->distributed[instance].values_next_sector;

	unsigned int count = 0;

	// update map of sectors buffer
	for ( ; v < (CONF_COLLECTION_MAXSITE * IFXDDX_EXPECTED_SECTORS); v++ )
	{
		if ((count * IFXDDX_EXPECTED_SECTOR_SIZE) > len)
			break;

		if (count > 0)
			u->distributed[instance].values_geo[(u->distributed[instance].values_next_sector - 1)] = u->distributed[instance].values_next_sector;

		u->distributed[instance].values_next_sector++;
		count++;
	}

	unlock.c_key(u, instance);

	return true;
}

//
// Name: ifxddx_update_infix
//
// Description:
//   Scrive sequenzialmente i settori del buffer già appartenenti ad una chiave e una volta occupati scrive i successivi
//
// Input:
//   ifxddx - the url index structure
//   key - la stringa chiave
//   infixed - il nuovo valore da immagazzinare
//   lvalue - la lunghezza della nuova chiave
//
// Return:
//  Vero se l'operazione è andata a buon fine
//
bool ifxddx_update_infix(ifxddx_t *u, keyid_t &keyid, char *infixed, iq_t &iq)
{
	instance_t instance = ((keyid - 1) % CONF_COLLECTION_DISTRIBUTED);
	keyid_t pos = (((keyid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	size_t bufferneed = strlen(infixed);
	size_t bufferbusy = 0;
	size_t bufferfree = 0;
	size_t src_offset = 0;

	wrlock.c_key(u, instance);

	if (u->distributed[instance].key_irank[keyid] >= iq || infixed == NULL)
	{
		unlock.c_key(u, instance);
		return false;
	}

	u->distributed[instance].key_irank[keyid] = USHRT_MAX; // stop increment infix quality

	off64_t next = u->distributed[instance].values_start_sector[pos];

	for(;;)
	{
		if (u->distributed[instance].values_geo[next] > 0)
		{
			next = u->distributed[instance].values_geo[next];
			bufferfree += IFXDDX_EXPECTED_SECTOR_SIZE;
		}
		else
			break;
	}

	size_t old_value_chunk_size = 0;

	// Si misura la lunghezza stringa dati contenuta nell'ultimo settore
	for (unsigned short i = 0; i < IFXDDX_EXPECTED_SECTOR_SIZE; i++)
		if (u->distributed[instance].values[((next * IFXDDX_EXPECTED_SECTOR_SIZE) + i)] != '\0')
			old_value_chunk_size++;

	bufferbusy = (bufferfree + old_value_chunk_size);

	if (bufferneed < bufferbusy)
	{
		unlock.c_key(u, instance);
		return false;
	}

	next = u->distributed[instance].values_start_sector[pos];

	// rewrite busy sector from old infixed terms
	while (u->distributed[instance].values_geo[next] > 0)
	{
		memcpy(u->distributed[instance].values + (next * IFXDDX_EXPECTED_SECTOR_SIZE), infixed + src_offset, IFXDDX_EXPECTED_SECTOR_SIZE);

		next = u->distributed[instance].values_geo[next];

		src_offset += IFXDDX_EXPECTED_SECTOR_SIZE;
	}



	// write into new sectors
	while ((bufferneed - src_offset) > IFXDDX_EXPECTED_SECTOR_SIZE)
	{
		memcpy(u->distributed[instance].values + (next * IFXDDX_EXPECTED_SECTOR_SIZE), infixed + src_offset, IFXDDX_EXPECTED_SECTOR_SIZE);
		u->distributed[instance].values_geo[next] = u->distributed[instance].values_next_sector;
		next = u->distributed[instance].values_next_sector++;
		u->distributed[instance].values_geo[(u->distributed[instance].values_next_sector - 1)] = u->distributed[instance].values_next_sector;

		src_offset += IFXDDX_EXPECTED_SECTOR_SIZE;
	}

	if ((bufferneed - src_offset) > 0)
	{
		memcpy( u->distributed[instance].values + (next * IFXDDX_EXPECTED_SECTOR_SIZE), (infixed + src_offset), (bufferneed - src_offset) );

//		u->distributed[instance].values_geo[(u->distributed[instance].values_next_sector - 1)] = u->distributed[instance].values_next_sector;

		u->distributed[instance].values_next_sector++;
	}

	unlock.c_key(u, instance);

	return true;
}

//
// Name: istidx_open
//
// Description:
//   Allocate memory for temporary word index
//
// Input:
//   istidx - the istance temporary index structure
//
// Return:
//
void istidx_open( istidx_t **t )
{
	for (instance_t instance = 0; instance < CONF_COLLECTION_DISTRIBUTED; instance++)
	{
		t[instance] = CBALLOC(istidx_t, MALLOC, 1);

		// creazione indici con durata limitata all'esecuzione della funzione
		// Alloc and clean hash tables
		t[instance]->term_hash = CBALLOC(off64_t, CALLOC, ISTIDX_MAXTERMS);

		// Set default values
		t[instance]->term_count = 0;
		t[instance]->term_next_char = 1; // start in 1

		// term_list
		t[instance]->term_list = CBALLOC(off64_t, MALLOC, (ISTIDX_MAXTERMS + 1));

		// Create memory area for word names
		t[instance]->term = CBALLOC(char, MALLOC, ISTIDX_TERM_SIZE);
		t[instance]->term[0] = '\0';
		// fine creazione
	}
}
//
// Name: istidx_resolve_word
//
// Description:
//   Verify a term name and add it if necessary
//
// Input:
//   istidx - the istance temporary index structure
//   term - the term to check
//
// Output:
//   termid - termid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   ISTIDX_EXISTENT - the term word existed
//   ISTIDX_CREATED_DUPL - the term word was added
//   ISTIDX_NOT_FOUND - the term word is not known and was not created
//
istidx_status_t istidx_resolve_word( istidx_t **t, instance_t *instance, const char *term, termid_t *termid, bool readonly ) {
	assert( t != NULL );
	assert( term != NULL );

	size_t tlen = strlen(term);

	assert ( tlen > 0 );

	termid_t bucket;
	termid_t termid_check;

	// Check if the term exists
	termid_check = istidx_check_word( t, instance, term, &(bucket) );

	if( termid_check > 0 ) {
		if( termid != NULL ) {
			*termid	= termid_check;
		}
		return ISTIDX_EXISTENT;
	}

	if( readonly == true )
		return ISTIDX_NOT_FOUND;
	else {
		// Get the next termid

		// Save in list of terms
		*termid = ++(t[*instance]->term_count);

		//cout << "Result 0 o 2, Sito:   " << term << "       Recupero il primo termid disponibile " << t[*instance]->term_count << '-' << bucket << endl;
		if( t[*instance]->term_count > ISTIDX_MAXTERMS ) {
			die( "Maximum number of termicates exceeded, increase in configuration file"  );
		}

		// Save in list of terms
		// Put in bucket
		(t[*instance]->term_hash)[bucket] = (t[*instance]->term_next_char);
//		cout << "Inserisco " << (t[*instance]->term_next_char) << " in (t[*instance]->term_hash)[" << bucket << "]" << " conferma " << (t[*instance]->term_hash)[bucket] << endl;

		// Save in list of term words
		t[*instance]->term_list[*termid - 1] = t[*instance]->term_next_char;

		// Store string
		memcpy( t[*instance]->term + t[*instance]->term_next_char, term, tlen + 1 );

		// Store termid
		memcpy( t[*instance]->term + t[*instance]->term_next_char + tlen + 1, termid, sizeof(termid_t) );

		// Move char pointer
		t[*instance]->term_next_char = t[*instance]->term_next_char + tlen + 1 + sizeof(termid_t);
		if( t[*instance]->term_next_char > ISTIDX_TERM_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase ISTIDX_MAXTERMS or EXPECTED_TERM_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(ISTIDX_ERROR);
		}
	}

	// Return
	return ISTIDX_CREATED_TERM;
}

//
// Name: ifxidx_check_word
//
// Description:
//   Check if a word exist
//
// Input:
//   istidx - the istance temporary index structure
//   word - the word name to check
//   bucket - the bucket in which this was found
//
// Return
//   a termid if resolved
//   0 if not found
//
termid_t istidx_check_word( istidx_t **t, instance_t *instance, const char *term, termid_t *bucket ) {
	assert( t != NULL );
	assert( term != NULL );
	assert( strlen( term ) > 0 );


	// First attempt to find bucket (debug purpose)
	//termid_t test = Url.hashing_infx( term );
	//cout << "DOMAIN " << term << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = istidx_hashing_word( term );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( t[*instance]->term_hash[(*bucket)] > 0 ) {

		char *pidx = t[*instance]->term + t[*instance]->term_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = term;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != '\0' && *(input) != '\0' && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
				return *((termid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % ISTIDX_MAXTERMS;
	}

	return (termid_t)0;
}

// Hashing Functions for term words
termid_t istidx_hashing_word( const char *text ) {
	termid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % ISTIDX_MAXTERMS );
	}
	return val;
}

// Name: istidx_word_by_wordid
//
// Description:
//   Get the name of a term word in a page based on its id
//
//	TODO: This function must fail in an error condition.
//
void istidx_word_by_wordid( istidx_t **t, instance_t *instance, termid_t &termid, char *termname ) {
	assert( t != NULL );

	if ( termid > 0 && termid <= t[*instance]->term_count)
	{
		// Read offset
		off64_t offset;
		offset = t[*instance]->term_list[(termid - 1)];

		// Copy
		assert( strlen( (t[*instance]->term) + offset ) < ISTIDX_MAX_WORD_LEN );
		strcpy( termname, (t[*instance]->term) + offset );
	}
	else
		termname[0] = '\0';
}

//
// Name: istidx_close
//
// Description:
//   Closes the url index, saving data to disk. Work with threads only if we have more the one distribution
//
// Input:
//   istidx - the istance temporary index structure
//
void istidx_close(istidx_t **t)
{
	for (instance_t instance = 0; instance < CONF_COLLECTION_DISTRIBUTED; instance++)
	{
		free( t[instance]->term_list ); t[instance]->term_list = NULL;
		free( t[instance]->term_hash ); t[instance]->term_hash = NULL;
		free( t[instance]->term ); t[instance]->term = NULL;
		free( t[instance] ); t[instance] = NULL;
	}

	free( t ); t = NULL;
}


//
// Name: cleanup
//
// Description: 
//   Closes files, indexes
//

// IMPORTANTE altrimenti non si compila
// non utilizzato dal programma ma necessario perchè sarà importato nella libreria 'utils.h' attraverso extern
//void cleanup() {
//}

