/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
// Local libraries

// Local variables
typedef unsigned short langid_t;
// typedef unsigned long int wordid_t;
typedef unsigned short duplid_t;
typedef unsigned short metaid_t;

const off64_t EXPECTED_LANG_SIZE = 2; // in bytes
const off64_t LANGIDX_EXPECTED_LANG_SIZE = (EXPECTED_LANG_SIZE + 1 + sizeof(langid_t));

const off64_t EXPECTED_WORD_SIZE = 10; // in bytes
const off64_t LANGIDX_EXPECTED_WORD_SIZE = (EXPECTED_WORD_SIZE + 1 + sizeof(wordid_t));

const off64_t EXPECTED_DUPL_SIZE = 10; // in bytes
const off64_t LANGIDX_EXPECTED_DUPL_SIZE = (EXPECTED_DUPL_SIZE + 1 + sizeof(duplid_t));

const off64_t EXPECTED_META_SIZE = 10; // in bytes
const off64_t LANGIDX_EXPECTED_META_SIZE = (EXPECTED_META_SIZE + 1 + sizeof(metaid_t));

// Status
enum langidx_status_t { 
	LANGIDX_ERROR 			= 0,
	LANGIDX_CREATED_LANG	= 1,
	LANGIDX_CREATED_WORD	= 2,
	LANGIDX_CREATED_DUPL	= 3,
	LANGIDX_CREATED_META	= 4,
	LANGIDX_EXISTENT		= 5,
	LANGIDX_NOT_FOUND		= 6
};

// struttura che comprende le elaborazioni ottenute dalla clesse delle tematiche
typedef struct {
	char *language;
	duplid_t duplicates_split_offset[2];
	metaid_t metawords_split_offset;
	unsigned short count_terms;
	unsigned int ranking;
	langid_t ranked_rules;
	langid_t ranked_languages;
} language_out_t;

// Classe Tematiche
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Languages {

	// Attenzione: TUTTE le dichiarazioni in questa sezione sono valide per tutte le funzioni all'interno della classe.
	// Motivo per cui NON occorre passarle come argomenti alle stesse.
	//
	// Attenzione: Quando un metodo ha il solo compito di riportare informazioni su un oggetto, senza modificarne il contenuto, si può, per evitare errori,
	// imporre tale condizione a priori, inserendo lo specificatore 'const' dopo la lista degli argomenti della funzione
	// (sia nella dichiarazione che nella definizione). Esistono comunque delle particolari eccezioni...

	// Le funzioni che indicizzano i termini sono state migliorate e in alcune di queste anche l'algoritmo di cui fanno uso è stato modificato ed è 
	// contrassegnato da '**'

	// Tutto ciò che è coinvolto da 'instance' o 'CONF_COLLECTION_DISTRIBUTED' è utilizzato durante la fase di analisi della lingua e la classe funziona
	// con richieste attraverso POSIX Threads

	// Constants
	#define MAXLANGUAGES 256
	#define MAXWORDS 40000
	#define MAXDUPLICATES 10000 // in una pagina lunga al max 50000 caratteri possono starci al max circa 8000 (80% di 10000) parole diverse tra loro
	#define MAXMETA 6000 // Quì devono starci tutti i termini dei metatags

	#define RBSIZE 128 // quantità di strutture in ranking_buffer (in pratica permette di controllare contemporanemente 128 regole)
	#define FM 2.20 // costante che consente di assegnare maggiore precisione alla valutazione del ranking
	#define heading_award 30 // valore percentuale aggiunto al ranking nel caso il termine sia tra tag strong, headings ecc..
	#define SR_CONST 1.9 // il ranking finale deve essere grande almento SR_CONST volte il second_rank

	#define LANGIDX_MAX_OCCUPANCY 			((float)0.8)

	#define LANGTHRESHOLD 300000000 // valore assoluto massimo ipotizzabile del ranking della tematica (al momento il ranking non si è visto superare la soglia di 250000000 ogni tanto occorre verificare la soglia)
	#define LANGRANK_MAX 30000000 // definizione che serve per far comprendere i valori di pagerank da '0' a LANGRANK_MAX (normalizzazione). In questo caso se il pagerank può arrivare al massimo a '100000000' sommando LANGRANK_MAX può influire per il 30% del pagerank

	// Variables
	wordid_t first_word_uid;
	wordid_t src_word_uid;
	wordid_t dst_word_uid;
	unsigned int mcline;
	unsigned short mcrule;
	unsigned short msline;
	
	unsigned long int terms_count; // indica il numero totale di parametri (numerici o no) nel principale file di configurazione 'contexts.txt'.
	unsigned long int terms_counter; // contatore di parametri (numerici o no) del principale file di configurazione 'contexts.txt'.
	unsigned int languages_counter; // indica il numero totale dei termini numerici (sinonimi) presenti nel main_buffer
	unsigned int words_counter; // indica il numero totale dei termini (parole) presenti nel main_buffer
	// Wordidx structure
	// Note that this is saved "as-is" to disk, so if you change it,
	// it will misbehave.
	
	typedef struct {
		// Languages
		char *lang;								// Strings    [memory]
		off64_t *lang_hash;                       // Hash table [memory]
		langid_t lang_count;					// Count      [memory]
		off64_t lang_next_char;					// String Pos [memory]
		off64_t *lang_list;                        // List       [disk]
	
		// Words
		char *word;								// Strings    [memory]
		off64_t *word_hash;                       // Hash table [memory]
		wordid_t word_count;					// Count      [memory]
		off64_t word_next_char;					// String Pos [memory]
		off64_t *word_list;                        // List       [memory]
	} langidx_t;

	typedef struct {
		// Duplicated (words of headings and content, without duplicated)
		char *dupl;								// Strings    [memory]
		off64_t *dupl_hash;                       // Hash table [memory]
		duplid_t dupl_count;					// Count      [memory]
		off64_t dupl_next_char;					// String Pos [memory]
		off64_t *dupl_list;                        // List       [memory]
	
		// Duplicated (words of metatags and url's words, without duplicated)
		char *meta;								// Strings    [memory]
		off64_t *meta_hash;                       // Hash table [memory]
		duplid_t meta_count;					// Count      [memory]
		off64_t meta_next_char;					// String Pos [memory]
		off64_t *meta_list;                        // List       [memory]
	} langidx_instance_t;

	// struttura che può contenere un id identificativo di termine (parola)
//	// la discriminazione viene effettuata dal valore booleano 'is_context'
	// In pratica questa è la copia del principale file di configurazione 'contexts.txt' in forma numerica con le regole con i termini dei contesti
	// (inseriti nell'indice delle parole) convertiti in formato numerico
	// L'offset indica la posizione nel buffer 'sy_dist' delle regole dei contesti che contengono determinate linee di sinonimi o
	// alternativamente dei contesti.
	typedef struct {
		unsigned short rule; // ogni regola (su unica linea) valida di configurazione è numerata
		bool is_language;
		wordid_t generic_id;
	} context_t;

	// struttura puntata dalla regola che localizza la stessa
	// attraverso 'rule_offset'
	typedef struct {
		size_t rule_offset; // offset nel buffer delle configurazioni principale (main_buffer)
		langid_t language;
		unsigned short terms;
	} main_t;

	// struttura che associa ogni identificativo univoco di tematica con l'offset di st_dist.
	// Leggendo in th_dist partendo da tale offset si reperiscono tutte le regole (rules) in cui è presente tale identificativo di tematica.
	typedef struct {
		unsigned int th_dist_offset;
	} language_vs_main_rules_t;

	// struttura che associa ogni identificativo univoco di termine (parola) con l'offset di st_dist.
	// Leggendo in wdist partendo da tale offset si reperiscono tutte le regole (rules) in cui è presente tale identificativo di parola.
	typedef struct {
		unsigned int wdist_offset; 
	} word_vs_main_rules_t;

	// struttura che contiene:
	// la regola dove è presente la parola nel main_buffer
	// Coefficente di divisione calcolato in funzione della distribuzione dell'identificativo tra le tematiche e tra le regole all'interno delle stesse.
	typedef struct {
		unsigned short rule; 
		unsigned int location_coefficient; 
	} idx_id_vs_rules_t;

	// struttura che immagazzina il punteggio nel ranking_buffer
	typedef struct {
		unsigned short rule;
		unsigned int ranking;
		unsigned int lang_ranking;
	} ranking_t;

	langidx_t *openidx;
	langidx_instance_t **instidx;

	main_t *main_structs;

	context_t *main_buffer; // contiene i parametri di configurazione (convertiti in relativi id numerici) del file principale dei contesti

	language_vs_main_rules_t *th_dist_st;
 
	word_vs_main_rules_t *wdist_st;
 
	unsigned short *th_dist; // contiene una mappa della distribuzione delle tematiche nelle regole (rules) del main_buffer
			      // ogni insieme di regole è rintracciabile attraverso l'offset indicato nella struttura tipo 'synonyms_vs_main_rules_t'
	idx_id_vs_rules_t *wdist; // contiene una mappa della distribuzione degli identificativi di termini (parole) nelle regole (rules) del main_buffer
			      // ogni insieme di regole è rintracciabile attraverso l'offset indicato nella struttura tipo 'words_vs_main_rules_t'
	ranking_t **ranking_buffer; // ogni puntatore puntato contiene coppie di regole->punteggio. Per leggere tutte le regole occorre incrementare il puntatore di 2.

	unsigned long int **language_ranking;

	public:

	bool index_setup (const size_t, bool);

	void make_analisys_index (unsigned int instance, const size_t min_word_len, pes_t *poutt, size_t content_len) const;

	language_out_t *index_analisys_read (unsigned int instance) const;

	void free_analisys_index (unsigned int instance) const;

	void index_open(void);

	void index_close(bool close_all);

	void makeContexts(char *, const size_t, bool, bool);

	// New URL index
	void langidx_new(void);
	
	// Close an URL index
	void langidx_close(void);

	// Search word in text to elaborate
	unsigned short checkLanguageWord(unsigned int instance, char *, const size_t, bool, bool, bool) const;

	// assign local ranking at contexts rules
	void rankingAllocation(unsigned int instance, wordid_t, bool, bool) const;

	// Get the langid for a language
	langidx_status_t langidx_resolve_lang( const char *lang, langid_t *langid, bool readonly ) const; // * performance **
	
	// Get the wordid for a word
	langidx_status_t langidx_resolve_word( const char *word, wordid_t *wordid, bool readonly ) const; // * migliorate grazie **
	
	// Get the duplid for a duplicate
	langidx_status_t langidx_resolve_dupl( unsigned int instance, const char *dupl, duplid_t *duplid, bool readonly ) const; // * in fase di verifica **
	
	// Get the metaid for a meta word
	langidx_status_t langidx_resolve_meta( unsigned int instance, const char *meta, metaid_t *metaid, bool readonly ) const; // * di identificativo
	
	// Get a language from a langid
	void langidx_lang_by_langid( langid_t langid, char *name ) const;
	
	// Get a word from a wordid
	void langidx_word_by_wordid( wordid_t wordid, char *name ) const;
	
	// Get a duplicate from a duplid
	void langidx_dupl_by_duplid( unsigned int instance, duplid_t duplid, char *name ) const;
	
	// Get a meta word from a metaid
	void langidx_meta_by_metaid( unsigned int instance, metaid_t metaid, char *name ) const;
	
	// Get the langid bucket for a language
	langid_t langidx_check_lang( const char *lang, langid_t *bucket ) const; // **
	
	// Get the wordid bucket for a word
	wordid_t langidx_check_word( const char *word, wordid_t *bucket ) const; // **
	
	// Get the duplid bucket for a duplicate
	duplid_t langidx_check_dupl( unsigned int instance, const char *dupl, duplid_t *bucket ) const;
	
	// Get the metaid bucket for a meta word
	metaid_t langidx_check_meta( unsigned int instance, const char *meta, metaid_t *bucket ) const;
	
	// Hash functions
	langid_t langidx_hashing_lang( const char *text ) const;
	
	// Hash functions
	wordid_t langidx_hashing_word( const char *text ) const;
	
	// Hash functions
	duplid_t langidx_hashing_dupl( const char *text ) const;
	
	// Hash functions
	metaid_t langidx_hashing_meta( const char *text ) const;
};
