/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _COMMONS_H_INCLUDED_
#define _COMMONS_H_INCLUDED_

#include <config.h>

// System libraries

#include <features.h>
#include <getopt.h>
#include <iostream>
#include <assert.h>
#include <string> 
#include <stdlib.h>
#include <mysql++.h>
#include <db_cxx.h>

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "utils.h"
#include "Url.h"
#include "Meta.h"
#include "harvestidx.h"
#include "Storage.h"
#include "cleanup.h"
#include "linkidx.h"
#include "include/libstemmer.h"

#define MAX_IVC_ROWS 22
#define MAX_WORD_LEN 32 // la lunghezza massima di caratteri UTF8 della parola è uno in meno di quello dichiarato nel define
#define MAX_BYTES_WORD_LEN (MAX_WORD_LEN * sizeof(wchar_t)) // lunghezza massima in byte di una parola 'multibyte char'
#define TEXTCHUNK 50 // in merito ai ranking, è buona norma analizzare solo la prima parte (la definizione indica in che percentuale rispetto a tutto il testo) di un testo in quanto è li che si trovano le parole più indicative sul contenuto della pagina specie se questo è molto lungo...

#define MIN_WORD_LEN 2

#define PRATICAL_WORD_SIZE 6 // definisce la lunghezza media delle parole in un testo (italiano) (considerando duplicati di parole molto comuni). nomeindice_EXPECTED_WORD_SIZE è utile solo per assegnare memoria sufficiente

struct charactersconversion
{
	unsigned int specialch[4]; //all'interno risiede il cast di 4 wchar_t (utf-16) (4 interi unsigned cioè 16 byte)
	char clearchar;
	string accentedchar;
};

const static charactersconversion it_valid_conversion [MAX_IVC_ROWS] =
{
{{4294967235U,4294967168U,0U,0U},'A',{"À"}},
{{4294967235U,4294967169U,0U,0U},'A',{"Á"}},
{{4294967235U,4294967175U,0U,0U},'C',{"Ç"}},
{{4294967235U,4294967176U,0U,0U},'E',{"È"}},
{{4294967235U,4294967177U,0U,0U},'E',{"É"}},
{{4294967235U,4294967180U,0U,0U},'I',{"Ì"}},
{{4294967235U,4294967181U,0U,0U},'I',{"Í"}},
{{4294967235U,4294967186U,0U,0U},'O',{"Ò"}},
{{4294967235U,4294967187U,0U,0U},'O',{"Ó"}},
{{4294967235U,4294967193U,0U,0U},'U',{"Ù"}},
{{4294967235U,4294967194U,0U,0U},'U',{"Ú"}},
{{4294967235U,4294967200U,0U,0U},'a',{"à"}},
{{4294967235U,4294967201U,0U,0U},'a',{"á"}},
{{4294967235U,4294967207U,0U,0U},'c',{"ç"}},
{{4294967235U,4294967208U,0U,0U},'e',{"è"}},
{{4294967235U,4294967209U,0U,0U},'e',{"é"}},
{{4294967235U,4294967212U,0U,0U},'i',{"ì"}},
{{4294967235U,4294967213U,0U,0U},'i',{"í"}},
{{4294967235U,4294967218U,0U,0U},'o',{"ò"}},
{{4294967235U,4294967219U,0U,0U},'o',{"ó"}},
{{4294967235U,4294967225U,0U,0U},'u',{"ù"}},
{{4294967235U,4294967226U,0U,0U},'u',{"ú"}}
};

const short NUMCOLS = 20; // short = intero che varia da -32768 a 32767
const short NUMROWS = 25; // short = intero che varia da -32768 a 32767
const unsigned short NUMUCOLS = 20; // short = intero che varia da -32768 a 32767
const unsigned short NUMUROWS = 30;

const static char dictionary_url [NUMUROWS] [NUMUCOLS] =
{{'c','g','i'},
{'h','t','m','*'},
{'h','o','m','e','*'},
{'s','i','t','o'},
{'i','m','s','i','t','e','*'},
{'c','o','n','t','*'},
{'p','a','g','e','*'},
{'i','n','d','e','x','*'},
{'e','x','p','o','r','t','*'},
{'d','e','f','a','u','l','t','*'},
{'l','e','f','t','*'},
{'p','a','g','e','*'},
{'p','a','g','i','n','*'},
{'p','h','p'},
{'a','s','p'},
{'s','i','n','i','s','t','r','a'},
{'s','e','r','v','l','e','t','*'},
{'s','i','t','e','*'},
{'d','o','w','n'},
{'r','i','g','h','t','*'},
{'d','e','s','t','r','a'}};

// in seguito potrebbe non essere più necessario
// N.B. la stringa '&amp;' viene inserita nei testi in sostituzione del segno di codifica '&' perciò deve essere esclusa dallo stemming in quanto non si tratta di una parola appartenente al dizionario italiano
const static char excluded_stemm[] = "il la lo li di da gli dei coi con dalla dalle delle della degli del una più nella nelle nei amp roma romeo servizio servizi";

// Functions
// // static void usage(int n);
//void die( const string line );

char convSpecialChar(char *wordlist, size_t wordlistlen, size_t offset);
char *printWord(string arg, size_t startpos, size_t stoppos, bool strict);
bool isInCharString(char *wordslist, char *search, bool isstemm);
bool checkpwu( char urlword[], const char matrix[NUMROWS][NUMCOLS], unsigned int row_dictionary_url, short rowuindex[NUMUROWS] );
short find_urlword_extended( const char matrix[NUMROWS][NUMCOLS], unsigned int row_dictionary_url, short rowuindex[NUMUROWS], char character, unsigned short &pos );
#endif
