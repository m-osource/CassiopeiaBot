/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "commons.h"

//
// Name: convSpecialChar
//
// Description: verifica se due 'unsigned int' corrispondono ad un carattere speciale
//
// Restituisce in carattere 'char' sostitutivo al carattere speciale (i nomi di dominio infatti non usano caratteri speciali)
//
char convSpecialChar(char *wordlist, size_t wordlistlen, size_t offset)
{
	if (offset < (wordlistlen - 1)) // per evitare letture in buffer overflow
	{
		size_t c = 0;
		while (c < MAX_IVC_ROWS)
		{
			if (static_cast<unsigned int>(wordlist[offset]) == it_valid_conversion[c].specialch[0] &&
				static_cast<unsigned int>(wordlist[offset + 1]) == it_valid_conversion[c].specialch[1])
					return it_valid_conversion[c].clearchar;
			c++;
		}
	}

	return ASCII_SP;
}

//
// Name: printWord
//
// Description: restituisce la parola compresa tra la posizione starpos e stoppos del puntatore a caratteri arg, il valore booleano strict su true
// indica che converte le lettere accentate in caratteri normali come indicato nella tabella di conversione 'it_valid_conversion' relativa a caratteri idonei
// per le lettere del dizionario italiano
//
// Restituisce la parola
//
char *printWord(string arg, size_t startpos, size_t stoppos, bool strict)
{
char *pw = (char *) malloc (((stoppos - startpos) + 1) * sizeof(char));
size_t arglen = 0;
char *parg = NULL;

	if (strict == true)
	{
		arglen = arg.length();
		parg = (char *) malloc ((arglen + 1) * sizeof(char));
		parg[0] = '\0';
		strcpy(parg, arg.c_str());
	}
	
	unsigned short counter = 0;

	for (size_t i = startpos; i < stoppos; i++)
		if (strict == false)
			pw[counter++] = tolower(arg[i]);
		else
		{
			if (isalpha(arg[i]))
				pw[counter++] = tolower(arg[i]);
			else
			{
				pw[counter++] = convSpecialChar(parg, arglen, i);
				i++;
			}
		}
			
	
	pw[counter] = '\0';
	
	if (strict == true)
		free (parg);
	
return pw;
}

//
// Name: isInCharString
//
// Description: verifica se una parola (o lo stemming di essa ma bisogna indicarlo al terzo argomento) si trova all'interno di una stringa di caratteri
//
// Restituisce vero se la corrispondenza viene trovata
//
bool isInCharString(char *wordslist, char *search, bool isstemm)
{
unsigned short c = 0;
unsigned short p = 0;
size_t wordslistlen = 0;
size_t templen = strlen(wordslist);
size_t searchlen = strlen(search);

	if (templen == 0 || searchlen == 0)
		return false;

	if (templen < USHRT_MAX && searchlen <= templen && searchlen > 0 )
	{
		wordslistlen = templen;

		for (size_t i = 0; i < wordslistlen; ++i)
		{
			// se il termine in wordlist è un carattere separatore si ricomincia il confronto
			if (wordslist[i] == ASCII_CM ||
				wordslist[i] == ASCII_SP ||
				wordslist[i] == ASCII_QU ||
				wordslist[i] == ASCII_AM ||
				wordslist[i] == ASCII_HM ||
				wordslist[i] == ASCII_SC ||
				wordslist[i] == ASCII_MI ||
				wordslist[i] == ASCII_MA ||
				wordslist[i] == ASCII_US ||
				wordslist[i] == ASCII_ST ||
				wordslist[i] == ASCII_SL ||
				wordslist[i] == ASCII_BS)
			{
				p = 0;
				c = 0;
				continue;
			}

			if (i < (wordslistlen - 2) && wordslist[i + 1] == ASCII_DT && wordslist[i + 2] == ASCII_DT) // potrebbe essere una parola spezzata da '..' o '...' ecc.
				while (i < wordslistlen &&
				! (	wordslist[i] == ASCII_CM ||
					wordslist[i] == ASCII_SP ||
					wordslist[i] == ASCII_QU ||
					wordslist[i] == ASCII_AM ||
					wordslist[i] == ASCII_HM ||
					wordslist[i] == ASCII_SC ||
					wordslist[i] == ASCII_MI ||
					wordslist[i] == ASCII_MA ||
					wordslist[i] == ASCII_US ||
					wordslist[i] == ASCII_ST ||
					wordslist[i] == ASCII_SL ||
					wordslist[i] == ASCII_BS))
                    i++;

			if (tolower(search[c]) == tolower(wordslist[i]))
				p++;
			else if (wordslist[i] != ASCII_SP && (tolower(search[c]) == convSpecialChar(wordslist, templen, i))) // N.B. convSpecialChar non può gestire spazi
			{
				p++;
				i++;
			}
			else // esclude il resto della parola da confrontare in wordslist e cerca il primo carattere separatore da cui ripartire
				while (i < wordslistlen &&
				! (	wordslist[i] == ASCII_CM ||
					wordslist[i] == ASCII_SP ||
					wordslist[i] == ASCII_QU ||
					wordslist[i] == ASCII_AM ||
					wordslist[i] == ASCII_HM ||
					wordslist[i] == ASCII_SC ||
					wordslist[i] == ASCII_MI ||
					wordslist[i] == ASCII_MA ||
					wordslist[i] == ASCII_US ||
					wordslist[i] == ASCII_ST ||
					wordslist[i] == ASCII_SL ||
					wordslist[i] == ASCII_BS))
                    i++;

			//cout << p << '-' << c << '-' << (char)tolower(search[c]) << '-' << (char)tolower(wordslist[i]) << endl; // @ serve per escludere i confronti con le caselle mail
			if (isstemm == false)
			{
				if (p > 0  && p == strlen(search) && p == (c + 1) && (i > (wordslistlen - 1) || isalpha(wordslist[i + 1]) == false) && wordslist[i + 1] != ASCII_AT)
					return true;
			}
			else // se si verifica un termine 'stemm' non viene controllato il termine stringa (es: per la parola 'agenzia' basta 'agenz' (i° step))
			{
				if (p > 0  && p == strlen(search) && p == (c + 1))
					return true;
			}

			if (c > (strlen(search) - 1))	
				p = 0;
			else
				c++;
	
			if (isalpha(wordslist[i]) == false) // la condizione va verificata dopo che si è certi che non si tratta di un carattere speciale
			{
				p = 0;
				c = 0;
			}
		
		}
	}
	else
		return false;

return false;
}

//
// Name: checkpwu
//
// Description: Verifica se il termine è inserito nel file lista delle tematiche
//
// Restituisce vero o falso
//
bool checkpwu( char urlword[], const char matrix[NUMROWS][NUMCOLS], unsigned int row_dictionary_url, short rowuindex[NUMUROWS] )
{
short fds = 0;
// verifica i nomi dominio a partire dal CARATTERE 4 (perchè normalmente 'www.CARATTERE') e se fino alla fine tutto ok controlla i primi 4 caratteri
	for (unsigned short c = 0; c < (strlen(urlword) + 1); c++)
	{
		fds = find_urlword_extended(matrix, row_dictionary_url, rowuindex, tolower(urlword[c]), c );
		if ( fds == 1 )
			return 1;
		else if ( fds == 2 )
			return 0;
	}
return 0;
}

//
// Name: find_urlword_extended
//
// Descriprion: Serve a checkpwu per interrompere il processo di ricerca prematuramente qualora non si trovino termini
//
short find_urlword_extended( const char matrix[NUMROWS][NUMCOLS], unsigned int row_dictionary_url, short rowuindex[NUMUROWS], char character, unsigned short &pos )
{
static int numele;
static int numele2;
static short nt = 0; // se tale contatore raggiunge il numero di righe in matrice occorre interrompere la funzione di ricerca
static short nto = 0; // serve per indicare staticamente il numero di righe della matrice dopo il primo confronto


	if (pos == 0)
	{
	numele = 0;
	//for (int rowipos = 0; pwu[rowipos][pos] != '\0'; rowipos++)
	for (unsigned int rowipos = 0; rowipos < row_dictionary_url; rowipos++)
		if (character == matrix[rowipos][pos])
			rowuindex[numele++] = rowipos;

	if (numele == 0)
                return 2;

        nt = 0;
        nto = numele;
	}
	else
	{
	numele2 = 0;
	for (int rowipos = 0; rowipos < numele; rowipos++)
	{
		if ((matrix[rowuindex[rowipos]][pos] == '\0') && character == '\0')
			return 1;
		else if (character == matrix[rowuindex[rowipos]][pos])
			rowuindex[numele2++] = rowuindex[rowipos];
		else if (matrix[rowuindex[rowipos]][pos] == ASCII_AS)
			return 1;
                else
                {
                        nt++;
                        if (nt == nto)
                        {
                                nt = 0;
                                numele = 0;
                                return 2;
                        }
                }

    	}
	numele = numele2;
	}

	return 0;
}
