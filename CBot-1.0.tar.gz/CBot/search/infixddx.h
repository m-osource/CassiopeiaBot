/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _IFXDDX_H_
#define _IFXDDX_H_

#include <config.h>

// System libraries

#include <sys/socket.h>
#include <sys/un.h> // for structure 'sockaddr_un'
#include <queue>
#include <fcntl.h> /* Added for the nonblocking socket */
#include <atomic>

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "utils.h"
#include "cleanup.h"

// Filenames
#define IFXDDX_FILENAME_KEY_LIST		"ifxddx.keylist"
#define IFXDDX_FILENAME_KEY				"ifxddx.key"
#define IFXDDX_FILENAME_KEY_HASH		"ifxddx.keyhash"
#define IFXDDX_FILENAME_KEY_IRANK		"ifxddx.keyirank"
#define IFXDDX_FILENAME_VALUES_OFFSET	"ifxddx.valuesoffset"
#define IFXDDX_FILENAME_VALUES_GEO		"ifxddx.valuesgeo"
#define IFXDDX_FILENAME_VALUES			"ifxddx.values"
#define IFXDDX_FILENAME_ALL         	"ifxddx.main"


// Status
enum ifxddx_status_t { 
	IFXDDX_ERROR 			= 0,
	IFXDDX_CREATED_KEY		= 2,
	IFXDDX_EXISTENT			= 3,
	IFXDDX_NOT_FOUND		= 4
};

// Constants
#define IFXDDX_MAX_OCCUPANCY 		((float)0.8)
#define MAX_KEY_LEN 256 // la lunghezza massima REALE della parola è uno in meno di quello dichiarato nel define
#define IFXDDX_EXPECTED_SECTOR_SIZE 8
#define IFXDDX_EXPECTED_SECTORS 4 // indica il numero medio di settori per ogni valore

typedef unsigned int keyid_t;
const off64_t EXPECTED_KEY_SIZE = 10; // in bytes
const off64_t IFXDDX_EXPECTED_KEY_SIZE = (EXPECTED_KEY_SIZE + 1 + sizeof(keyid_t));

// ifxlist_key_t structures
// needed from 'by_keyid' function
typedef struct {
	keyid_t hash_pos;
	instance_t bucket_instance;
//	ifxrank_t rank;
} ifxlist_key_t;

typedef struct {
	pthread_rwlock_t *rwlocka; // bucket instance read/write locks
	pthread_rwlock_t *rwlockb; // bucket instance read/write locks
	pthread_rwlock_t *rwlockc; // bucket instance read/write locks
} ifxmutex_t;

//bool database_is_full;

// Wordidx structure
// Note that this is saved "as-is" to disk, so if you change it,
// it will misbehave.
typedef unsigned short iq_t;

typedef struct {
	// Domains
	char *key;					// Strings    [memory]
	std::atomic<off64_t *> key_hash;			// Hash table [memory] (share data)
	std::atomic<keyid_t> key_count;		// Count      [memory] (share data)
	off64_t key_next_char;		// String Pos [memory]
	FILE *key_list;			// List       [disk]
	iq_t *key_irank;			// si scrive nell'indice solo se il key infix rank di provenienza è superiore al valore precedentemente inserito
	off64_t *values_start_sector;			// contiene l'offset del buffer in cui si trova il valore corrispondente alla chiave
	off64_t *values_geo;			// segue la sequenza dei settori a partire da values_start_sector
	char *values;				// contiene il buffer dei valori
	off64_t values_next_sector;		// indica la posizione del prossimo settore libero

	// Info
	char dirname[MAX_STR_LEN];
	//bool readonly;
} iddx_t;

// ifxddx_t infixed terms container ddx work
typedef struct {
	iddx_t *distributed;
	ifxmutex_t *klock; // mutex must be declared inside function that create threads
	std::atomic<keyid_t> threads_key_count; // *
	std::atomic<keyid_t> key_count; // (share data) in caso di multithread questi contatori devo essere poter letti durante la fase di scrittura di nuovi id
	bool readonly;
} ifxddx_t;

// need to passing arguments to threads functions
typedef struct {
    instance_t i;
    ifxddx_t *u;
    char *d;
} ifxddx_thread_function_args_t;

//using namespace std;
#define ISTIDX_MAXTERMS 16000 // Deve poter contenere tutti i termini univoci presenti in un documento web
#define ISTIDX_MAX_WORD_LEN 32
typedef unsigned short termid_t;

const off64_t EXPECTED_TERM_SIZE = 10; // in bytes
//const off64_t ISTIDX_EXPECTED_TERM_SIZE = (EXPECTED_TERM_SIZE + 1 + sizeof(termid_t));
const off64_t ISTIDX_TERM_SIZE = ((EXPECTED_TERM_SIZE + 1 + sizeof(termid_t)) * ISTIDX_MAXTERMS);

// Status
enum istidx_status_t { 
	ISTIDX_ERROR 		= 0,
	ISTIDX_CREATED_TERM	= 1,
	ISTIDX_EXISTENT		= 2,
	ISTIDX_NOT_FOUND	= 3
};

typedef struct {
	char *term;								// Strings    [memory]
	off64_t *term_hash;                       // Hash table [memory]
	termid_t term_count;					// Count      [memory]
	off64_t term_next_char;					// String Pos [memory]
	off64_t *term_list;                        // List       [memory]
} istidx_t;


// Filenames

// Functions

// Create a new index
ifxddx_t *ifxddx_new( const char * );

// Function required by ifxddx_new (pthread use)
void *ifxddx_thread_function_new( void * );

// Open a infix index
ifxddx_t *ifxddx_open( const char *dirname, bool readonly );

// Function for allocate memory and create mutex
void ifxddx_setmutex( ifxddx_t *, ifxmutex_t ** );

// Function required by ifxddx_open (pthread use)
void *ifxddx_thread_function_open( void * );

// Removes a URL index
void ifxddx_remove( const char *dirname );

// Function required by ifxddx_remove (pthread use)
void *ifxddx_thread_function_remove( void * );

// Dumps the URL index status
//void ifxddx_dump_status(ifxddx_t *u);

// Read an infix term from existant domain
char *ifxddx_read_infix(ifxddx_t *, keyid_t &, bool);

// Save an infix term for new domain
bool ifxddx_write_infix(ifxddx_t *, keyid_t &, char *, iq_t &iq);

// Update an infix term for existant domain
bool ifxddx_update_infix(ifxddx_t *, keyid_t &, char *, iq_t &iq);

// Close an URL index
void ifxddx_close(ifxddx_t *u);

// Function required by ifxddx_close (pthread use)
void *ifxddx_thread_function_close( void * );

// Function for free memory and destroy mutex
void ifxddx_destroymutex( ifxddx_t * );

// Get the keyid for a key
ifxddx_status_t ifxddx_resolve_key( ifxddx_t *, const char *, keyid_t *, bool );

// Get the keyid for a key
keyid_t ifxddx_check_key( ifxddx_t *, const char *, keyid_t *, bool );

// Get a key from a keyid
void ifxddx_key_by_keyid( ifxddx_t *, keyid_t &, char * );

// Hash functions
keyid_t ifxddx_hashing_key( const char * );

// Open a instance index
void istidx_open( istidx_t ** );

// Get the wordid for a word
istidx_status_t istidx_resolve_word( istidx_t **, instance_t *, const char *, termid_t *, bool  );

// Get a word by wordid
void istidx_word_by_wordid( istidx_t **, instance_t *, termid_t &, char * );

// Get a bucket from word
termid_t istidx_check_word( istidx_t **, instance_t *, const char *, termid_t * );

// Hash functions
termid_t istidx_hashing_word( const char * );

// Close a temporary infix index
void istidx_close(istidx_t **t);

#endif
