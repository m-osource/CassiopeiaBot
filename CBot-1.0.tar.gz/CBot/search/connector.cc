/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

// N.B. Il check della variabile http_status servirà (se necessario) come implementazione futura ad indicare al motore di ricerca i docid da cancellare o ripristinare
// al cambiare di tale stato
//if(HTTP_IS_OK(doc.http_status))

#include "connector.h"

using namespace std;

thread_local cpu_set_t system_cpus;

// 
// Name: main
//
// Description:
//   Main program for the feeder
//
int main(int argc, char **argv)
{
try
{
	int rc = 0;
	pthread_mutexattr_t attr;
	indexupdate = true;
	bdbcorrupted = false;

	cbot_start("connector"); // imposta le constanti

	while(1) {
		int option_index = 0;

		static struct option long_options[] = {
			{"help", 0, 0, 0},
			{"reset", 0, 0, 0},
			{"updatescores", 0, 0, 0},
			{"debugonly", 0, 0, 0},
			{"showinfixes", 0, 0, 0},
			{"showthematics", 0, 0, 0},
			{"from", 1, 0, 0},
			{"to", 1, 0, 0},
			{0, 0, 0, 0}
		};

		char c = getopt_long (argc, argv, "h", long_options, &option_index);

		if (c == -1)
			break;

		switch (c) {
			case 0:
				if( !strcmp( long_options[option_index].name, "from" ) ) {
					opt_from = atol( optarg );
					if( opt_from == 0 ) {
						connector_usage();
					}
				} else if( !strcmp( long_options[option_index].name, "to" ) ) {
					opt_to = atol( optarg );
					if( opt_to == 0 ) {
						connector_usage();
					}
				} else if( !strcmp( long_options[option_index].name, "reset" ) ) {

					cerr << RED << "Warning:" << endl;
					cerr << "Before reset all nvc data you must restart engine with new \"sql\" index and confirm!"<< endl << endl;
					cerr << "If you are sure you are doing press the C character to continue" << endl;

					signal(SIGINT, SIG_IGN); // Ignore Ctrl-C

					char c = getchar();

					cerr << NOR << endl;

					if (c != 'C')
						exit(0);

					connddx_remove( COLLECTION_CONNDATA );

					cerr << endl <<  "Proceding with connddx rebuild ... ";
					connddx = connddx_open( COLLECTION_CONNDATA, false );
					assert( connddx != NULL );
					connddx_close( connddx );
					cerr << "done." << endl;

					cerr << endl <<  "Deleting Berkeley databases ... ";
					if (CONF_COLLECTION_DISTRIBUTED > 1)
					{
						pthread_t *threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);
						instance_t *args = CBALLOC(instance_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

						for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
						{
							args[i] = i;

							if ((rc = pthread_create( &(threads[i]), NULL, thread_function_dropdb_conn, (void *)&args[i] )) != 0)
								die("error creating threads %s", strerror(rc));
						}

						CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

						free(args);
						free(threads); 
					}
					else
					{
						instance_t i = 0;
						thread_function_dropdb_conn((void *)&i);
					}

					cerr << "Done." << endl;

					reset = true;
					indexupdate = false;
				} else if( !strcmp( long_options[option_index].name, "updatescores" ) ) {
					updatescores = true;
				} else if( !strcmp( long_options[option_index].name, "debugonly" ) ) {
					debugonly = true;
				} else if( !strcmp( long_options[option_index].name, "showinfixes" ) ) {
					showinfixes = true;
				} else if( !strcmp( long_options[option_index].name, "showthematics" ) ) {
					showthematics = true;
				} else if( !strcmp( long_options[option_index].name, "help" ) ) {
					connector_usage();
				}
				break;
			case 'h':
				connector_usage();
				break;
			default:
				connector_usage();
		}
	}

	// Reading all infixes from database
	if (showinfixes == true && debugonly == true)
	{
		cerr << endl << "Opening index of infixes ... ";
		ifxddx = ifxddx_open( COLLECTION_INFIXDATA, true );
		assert( ifxddx != NULL );
		cerr << "done." << endl;

		const unsigned short spaces = 40;

		for (keyid_t keyid = 1; keyid <= ifxddx->key_count; keyid++)
		{
			char site[MAX_STR_LEN];
			site[0] = ASCII_NUL;

			ifxddx_key_by_keyid( ifxddx, keyid, site );

			char *infixed = ifxddx_read_infix(ifxddx, keyid, true);

			if (strlen(infixed) > 0)
				cout << keyid << "\t" << site << setw(spaces - strlen(site)) << ' ' << infixed << endl;

			free(infixed);
		}

		// cerr << "Close key indexes." << endl;
		cerr << endl << "Closing index of infixes ... ";
		ifxddx_close( ifxddx);
		cerr << "done." << endl;
		return 0;
	}

	// Reading configuration files of thematics
	if (! (showthematics == true && debugonly == true))
		cerr << "Prepare index of thematics ... ";

	Language lang = Language::IT; // italian

	bool index_status = false;

	if (showthematics == true && debugonly == true)
		index_status = th.index_setup ( lang, NULL, (const size_t)1, true ); // min_word_len == 1
	else
		index_status = th.index_setup ( lang, NULL, (const size_t)1, false ); // min_word_len == 1

	if (index_status == false)
		return 0;

	if (showthematics == true && debugonly == true)
	{
		cerr << endl << "Closing index of thematics ... ";
		th.index_close (true);
		cerr << "done" << endl;
		return 0;
	}
	else
		cerr << "done." << endl;

	// Open url index
	cerr << "Opening urlindex ... ";
	url = new Url (COLLECTION_URL , Url::RO);
	url->ddx_open();

	// Open metaindex
	cerr << "metaindex ...";
	meta = new Meta ( COLLECTION_METADATA, true );
	meta->ddx_open();

	// Open storage
	cerr << "storage ... ";
	strg = new Storage ( COLLECTION_TEXT, true );
	strg->st_open();

	// Open connindex
	cerr << "connindex ... ";
	connddx = connddx_open( COLLECTION_CONNDATA, false );
	assert( connddx != NULL );

	// Open infixed index (handled only inside cbot-connector)
	cerr << "infixdata ... " << endl;
	ifxddx = ifxddx_open( COLLECTION_INFIXDATA, false );
	assert( ifxddx != NULL );

	cerr << "done." << endl;

	// determina in numero di righe occupate da lettere dell'array bidimensionale dictionary_url
	for (row_dictionary_url = 0; row_dictionary_url < NUMUROWS; row_dictionary_url++)
		if (isalpha(dictionary_url[row_dictionary_url][0]) == 0) break;

	// determina in numero massimo di colonne occupate da lettere dell'array bidimensionale dictionary_url
	for (unsigned int row = 0; row < row_dictionary_url; row++)
		for (unsigned int col = 0; col < NUMUCOLS; col++)
			if (isalpha(dictionary_url[row][col]) == 0)
				{
					if (col > col_dictionary_url)
						col_dictionary_url = col;
					break;
				}

	// crea la classifica del sito più importante tra quelli con lo stesso dominio di secondo livello
	cerr << "Making list of best site for any domain ... " << endl;
	bestsite_for_domain = CBALLOC(best_site_t, MALLOC, (url->domaincount() + 1));

	keep_special.check_matches = true;

	perfhash_create( &(keep_special), CONF_COLLECTION_IT_SPECIAL_DOMAINS );

	for (siteid_t d = 0; d <= url->domaincount(); d++)
	{
		bestsite_for_domain[d].read_only = (bool *) malloc (sizeof(bool));
		bestsite_for_domain[d].read_only[0] = false;

		bestsite_for_domain[d].both_verified = (bool *) malloc (sizeof(bool));
		bestsite_for_domain[d].both_verified[0] = false;

		bestsite_for_domain[d].siteid = 0;

		bestsite_for_domain[d].siterank = (siterank_t *) malloc (sizeof(siterank_t));
		bestsite_for_domain[d].siterank[0] = 0;
	}

	for (siteid_t b = 1; b <= url->sitecount(); b++)
	{
		site_t siteinfo;

		siteinfo.siteid = b;

		meta->site_retrieve( &(siteinfo) );

		char *sitename = (char *) malloc ((MAX_STR_LEN + 1) * sizeof(char));

		url->site_by_siteid( b, sitename );

		char *domainstring = siteToDomain(keep_special, sitename);

		size_t sitenamelen = strlen(sitename);

		// se si tratta di un nome sito equivalente al nome dominio restituito dalla funzione 'siteToDomain(...)' con preposta ls string 'www.'
		// oppure se si tratta di un nome sito equivalente al nome dominio restituito dalla funzione 'siteToDomain(...)'
		// allora assegna il massimo punteggio di siterank tra i due e blocca i risultati affinchè non vengano modificati
		// da altri nomi dominio
		// Se invece tra i nomi dominio fqdn con lo stesso domainid non ne esiste uno che comincia con il prefisso con 'www.' o che sia equivalente
		// al nome dominio restituito dalla funzione 'siteToDomain(...)' allora viene effettuata la classifica esclusivamente
		// in base ai siterank
		if ((sitenamelen == (strlen(domainstring) + 4) && strncmp (sitename, "www.", 4) == 0) || strcmp(sitename, domainstring) == 0)
		{
			if (bestsite_for_domain[siteinfo.domainid].both_verified[0] == false)
			{
				if (bestsite_for_domain[siteinfo.domainid].read_only[0] == false)
				{
					bestsite_for_domain[siteinfo.domainid].siteid = siteinfo.siteid;
					bestsite_for_domain[siteinfo.domainid].siterank[0] = siteinfo.siterank;
				}
				else
				{
					if (&siteinfo.siterank > bestsite_for_domain[siteinfo.domainid].siterank)
					{
						bestsite_for_domain[siteinfo.domainid].siteid = siteinfo.siteid;
						bestsite_for_domain[siteinfo.domainid].siterank[0] = siteinfo.siterank;
					}

					bestsite_for_domain[siteinfo.domainid].both_verified[0] = true;
				}
			}

			if (bestsite_for_domain[siteinfo.domainid].read_only[0] == false)
				bestsite_for_domain[siteinfo.domainid].read_only[0] = true;
		}
		else if (bestsite_for_domain[siteinfo.domainid].read_only[0] == false && siteinfo.siterank > bestsite_for_domain[siteinfo.domainid].siterank[0])
		{
			bestsite_for_domain[siteinfo.domainid].siteid = siteinfo.siteid;
			bestsite_for_domain[siteinfo.domainid].siterank[0] = siteinfo.siterank;
		}

		free (domainstring);
		free (sitename);
	}

/*/// uso debug visualizzazione classifica	
	for (siteid_t d = 0; d <= url->domaincount(); d++)
	{
		if (bestsite_for_domain[d].siteid > 0)
		{
			char sitename[MAX_STR_LEN];
			cout << d << '-' << bestsite_for_domain[d].siteid << endl;
			url->site_by_siteid( bestsite_for_domain[d].siteid, sitename );
			assert( sitename != NULL );
			cout << sitename << endl;
		}
	}
*///

	// ora è possibile liberare la memoria inutile per i controlli nella struttura 'best_for_domain'
	for (siteid_t d = 0; d <= url->domaincount(); d++)
	{
		free (bestsite_for_domain[d].read_only);
		free (bestsite_for_domain[d].both_verified);
		free (bestsite_for_domain[d].siterank);
	}
	// fine creazione classifica del sito più importante tra quelli con lo stesso dominio di secondo livello

	// salvataggio del timestamp di avvio processo nel file 'endtimesearch.txt'.
	// Con tale timestamp i dati dal motore verranno letti solo con timestamp precedente a questo.
	starttime = time(NULL);
	char starttimepath[MAX_STR_LEN];
	FILE *pendtimesearch = NULL;
	int rcheck = 3; // valore non valido impostato di default

	if (debugonly == false)
	{
		char *pstarttime = numtostring<time_t>(starttime);

		sprintf(starttimepath, "%s/%s", CONF_COLLECTION_BASE, "endtimesearch.txt");

		pendtimesearch = fopen ((const char *)starttimepath, "wb");
		fwrite (pstarttime , sizeof(char), strlen(pstarttime), pendtimesearch);
		rcheck = fseeko(pendtimesearch, strlen(pstarttime), SEEK_SET );
		assert( rcheck == 0 );
		rcheck = fwrite( "\n", sizeof(char), 1, pendtimesearch );
		assert( rcheck == 1 );
		fclose (pendtimesearch);
		free (pstarttime);
	}
	// fine salvataggio timestamp nel file //

	// Allocate memory
	info = CBALLOC(info_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	tempidx = CBALLOC(istidx_t *, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	//assert(CONF_OK);

	// creazione indici volatili per sessione (uno per instanza) con popolamento parziale dei dati 'statici' che non dovranno più essere aggiunti
	cerr << endl <<  "Creating temporary index ... ";
	makeInstanceIndexes();
	cerr << "done." << endl;

	terms_split_offset = CBALLOC(termid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	// inizializzazione librerie mysqlpp
	mysql_library_init(0, NULL, NULL);

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		glock = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		pthread_t *threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		// setup mutex of ...ddx index
		url->setmutex(&urlslock, &urldlock, &urlplock);
		ifxddx_setmutex(ifxddx, &klock);

		// setup generic mutexes
		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
            glock[i] = PTHREAD_MUTEX_INITIALIZER;

		connector_barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(connector_barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", strerror(rc));
		
		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", strerror(rc));

		instance_t *args = CBALLOC(instance_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			args[i] = i;

			if ((rc = pthread_create( &(threads[i]), NULL, thread_function_create_conn, &args[i] )) != 0)
				die("error creating threads %s", strerror(rc));
//sleep(1);
		}

		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(args);
		free(threads); 

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", strerror(rc));

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			if ((rc = pthread_mutex_destroy(&(glock[i]))) != 0)
				die("error destroying generic mutexes %s", strerror(rc));

		// destroy mutex of ifxddx index
		url->destroymutex();
		ifxddx_destroymutex(ifxddx);

		pthread_barrier_destroy(connector_barrier);

		free(glock); glock = NULL;
		free(connector_barrier); connector_barrier = NULL;
	}
	else
	{
		instance_t args = 0;
			
		klock = NULL;

		thread_function_create_conn((void *)&args);
	}

	mysql_library_end();

	// salvataggio del timestamp di fine processo nel file 'endtimesearch.txt'.
	// Con tale timestamp i dati dal motore verranno letti solo con timestamp precedente a questo.
	// starttime in effetti ora dovrebbe chiamarsi stoptime ma per comodità resta con il nome originale
	if (debugonly == false)
	{
		char *pstoptime = numtostring<time_t>(time(NULL));

		pendtimesearch = fopen ((const char *)starttimepath, "wb");
		fwrite (pstoptime , sizeof(char), strlen(pstoptime), pendtimesearch);
		rcheck = fseeko(pendtimesearch, strlen(pstoptime), SEEK_SET );
		assert( rcheck == 0 );
		rcheck = fwrite( "\n", sizeof(char), 1, pendtimesearch );
		assert( rcheck == 1 );
		fclose (pendtimesearch);
		free (pstoptime);
	}

	perfhash_destroy(&(keep_special));

	// End
	if (thread_alarm != THREADS_OK)
		cbot_stop(1);
	else
		cbot_stop(0);
} // catch exception in the main function
catch (CBotExitException eex)
{
	delete eex.Exception();
    
	cbot_stop(1);
}
}

// threads sync
void connector_sync_threads(pthread_barrier_t *barrier)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc = pthread_barrier_wait(barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
        pthread_exit(NULL);
}

void *thread_function_dropdb_conn(void *args)
{
try
{
	instance_t *instance = (instance_t *) args;

	instance_t inst = *instance;

	CPU_OPTIMIZE;

	// Avvio procedura salvataggio su indice/i del motore
	unsigned short relative_rem_path_prefix_len = strlen(relative_rem_path_prefix);
	char instance_suffix[8];

    snprintf(instance_suffix, sizeof(instance_suffix), "%u", *instance);
	char *relative_rem_path = CBALLOC(char, MALLOC, (relative_rem_path_prefix_len + 8 + 1));
	strcpy(relative_rem_path, relative_rem_path_prefix);
	memcpy(relative_rem_path + relative_rem_path_prefix_len, instance_suffix, (strlen(instance_suffix) + 1)); // copia anche ASCII_NUL di 'instance_suffix'

	char *work_directory = CBALLOC(char, MALLOC, (strlen(CONF_INDEX_CONNECTOR_BASEPATH) + strlen(relative_rem_path) + 2));
	strcpy(work_directory, CONF_INDEX_CONNECTOR_BASEPATH);
	strcat(work_directory, "/");
	strcat(work_directory, relative_rem_path);

	errno = 0; // errno is thread-local

	if (mkdir(work_directory, S_IRWXU|S_IRGRP|S_IXGRP) != 0)
		die("connector: work_directory ... mkdir() info %s", cberr());

	// Initialize the path to the database files
	string databaseHome((string)work_directory);
	free(work_directory); work_directory = NULL;
	free(relative_rem_path); relative_rem_path = NULL;

	string dDbName(BDBLINKS_FILENAME_DB); // doc db
	char *filetodel = CBALLOC(char, MALLOC, MAX_STR_LEN);
	sprintf( filetodel, "%s/%s", databaseHome.c_str(), dDbName.c_str() );
	remove(filetodel);
	free (filetodel);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(NULL);
}
}

void *thread_function_create_conn(void *args)
{
try
{
	instance_t *instance = (instance_t *)args;

	instance_t inst = *instance;

	CPU_OPTIMIZE;

	// Avvio procedura salvataggio su indice/i del motore
	string sphinx_address((string)CONF_INDEX_CONNECTOR_NMASK);
	unsigned short relative_rem_path_prefix_len = strlen(relative_rem_path_prefix);
	char instance_suffix[8];

    snprintf(instance_suffix, sizeof(instance_suffix), "%u", *instance);
	char *relative_rem_path = CBALLOC(char, MALLOC, (relative_rem_path_prefix_len + 8 + 1));
	strcpy(relative_rem_path, relative_rem_path_prefix);
	memcpy(relative_rem_path + relative_rem_path_prefix_len, instance_suffix, (strlen(instance_suffix) + 1)); // copia anche ASCII_NUL di 'instance_suffix'

	char *work_directory = CBALLOC(char, MALLOC, (strlen(CONF_INDEX_CONNECTOR_BASEPATH) + strlen(relative_rem_path) + 2));
	strcpy(work_directory, CONF_INDEX_CONNECTOR_BASEPATH);
	strcat(work_directory, "/");
	strcat(work_directory, relative_rem_path);

	// connessione verso il motore
	mysqlpp::TCPConnection conn;

	unsigned int found = sphinx_address.find_last_of(".");
	char iphost[8];
	iphost[0] = ASCII_NUL;
	snprintf(iphost, sizeof(iphost), "%u", (*instance + 1));if (strlen(iphost) > (sphinx_address.size() - found))
	sphinx_address.resize(sphinx_address.size() + (strlen(iphost) - (sphinx_address.size() - found)), ASCII_NUL);
	sphinx_address.replace((found + 1), strlen(iphost), iphost);
	sphinx_address.append(":");
	sphinx_address.append(sphinx_port);
	conn.set_option(new mysqlpp::ReconnectOption(true));
	conn.set_option(new mysqlpp::ConnectTimeoutOption(5));
	conn.connect(sphinx_address.c_str(), sphinx_db.c_str(), sphinx_username.c_str(), sphinx_password.c_str());

	if (conn.ping() == false)
	{
		mcerr << "Instance " << *instance << " engine lost connection!" << mendl;
		free (work_directory);
		free (relative_rem_path);
		conn.disconnect();
		conn.thread_end();
		return NULL;
	}

	// Initialize the path to the database files
	string databaseHome((string)work_directory);
	string connddxHome((string)work_directory);
	free(work_directory); work_directory = NULL;
	free(relative_rem_path); relative_rem_path = NULL;

/*
	if (debugonly == true)
	{
		databaseHome.resize(4);
		databaseHome = "/tmp";
		connddxHome.resize(4);
		connddxHome = "/tmp";
	}
*/

	string dDbName(BDBLINKS_FILENAME_DB); // doc db

	ifstream dfile(databaseHome + "/" + dDbName); // Verifica l'esistenza del file BerkeleyDB

	if ( connddx->count_nvc > 0 && !dfile.is_open()) {
		dfile.close();

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_mutex_trylock(&(glock[CONF_COLLECTION_DISTRIBUTED])) == 0)
			{
				if (bdbcorrupted == false)
				{
					mcerr << RED << *instance << "Warning: Berkeley database " << databaseHome + "/" + dDbName;
					cerr << " do not exist, please restart connector and engine with new \"sql\" index." << endl;
					cerr << NOR << mendl;
				}

				bdbcorrupted = true;

				pthread_mutex_unlock(&(glock[CONF_COLLECTION_DISTRIBUTED]));

				return NULL;

			}
		}
		else
		{
			mcerr << RED << *instance << "Warning: Berkeley database " << databaseHome + "/" + dDbName;
			cerr << " do not exist, please restart engine with new \"sql\" index and confirm." << endl;
			cerr << NOR << mendl;

			bdbcorrupted = true;
			free (work_directory);
			free (relative_rem_path);
			conn.disconnect();
			conn.thread_end();
			return NULL;
		}
	}

	// wait all other threads to arrive at this point
	if (CONF_COLLECTION_DISTRIBUTED > 1)
		connector_sync_threads(connector_barrier);

	if (bdbcorrupted == true)
	{
		free (work_directory);
		free (relative_rem_path);
		conn.disconnect();
		conn.thread_end();
		return NULL;
	}

	/* Insert here your code if you want exclude instances */

	DbEnv env(0);
	Db *Bdb = NULL;

	try
	{
		mysqlpp::Query query=conn.query();
		//mysqlpp::Transaction trans(conn); // COMMIT disabilitato in quanto attualmente sphinx non esegue correttamente il DELETE all'interno della transazione BEGIN/COMMIT
		// Open Berkeley database.
		env.set_error_stream(&cerr);
		env.open(databaseHome.c_str(), DB_CREATE | DB_INIT_MPOOL, 0);
		Bdb = new Db(&env, 0);
		Bdb->open(NULL, dDbName.c_str(), NULL, DB_BTREE, DB_CREATE | DB_TRUNCATE, 0);

		// Default options
		docid_t start		= (docid_t)(*instance + 1);
		docid_t finish		= meta->doc_count();

		// Lower docid limit
		if (opt_from > 1 && opt_from <= finish)
			start = ((*instance < ((opt_from - 1)% CONF_COLLECTION_DISTRIBUTED)) ? (*instance + CONF_COLLECTION_DISTRIBUTED + opt_from - ((opt_from - 1)% CONF_COLLECTION_DISTRIBUTED)) : (opt_from + *instance - ((opt_from - 1)% CONF_COLLECTION_DISTRIBUTED)));

		// Upper docid limit
		if ((opt_to > 0 && opt_to >= opt_from) && opt_to <= finish)
			finish = ((*instance > ((opt_to - 1)% CONF_COLLECTION_DISTRIBUTED)) ? (opt_to - ((opt_to - 1)% CONF_COLLECTION_DISTRIBUTED) - CONF_COLLECTION_DISTRIBUTED + *instance) : (opt_to + *instance -((opt_to - 1)% CONF_COLLECTION_DISTRIBUTED)));

		// exit from thread because have invalid limits
		if (start > opt_to && finish < opt_from )
		{
			free (work_directory);
			free (relative_rem_path);
			Bdb->close(0);
			delete Bdb;
			conn.disconnect();
			conn.thread_end();
			return NULL;
		}

		docid_t ndocs_ok	= 0;

		// in connddx il docid = 1 occorre crearlo a prescindere (se inesistente), 
		// perchè la funzione connddx_close per accertarsi che il file connddx.doc non sia
		// corrotto, in seguito se necessario verifica l'esistenza del primo documento.
		if (indexupdate == false)
		{
			connddx_status_t rc;
		    nvc_t doc;

			doc.docid = (docid_t)(*instance + 1);
			doc.siterank = (siterank_t)0;
			doc.pagerank = (pagerank_t)0;
			doc.wlrank = (wlrank_t)0;
			doc.liverank = (liverank_t)0;
			doc.cscore = (priority_t)0;
			doc.uscore = (priority_t)0;
			doc.number_visits_changed = 0;
			doc.http_status = HTTP_STATUS_UNDEFINED;

			rc = connddx_nvc_store( connddx, &(doc) );

			assert( rc == CONNDDX_OK );
		}

		//for(static docid_t docnum = start; docnum <= finish; docnum += CONF_COLLECTION_DISTRIBUTED)
		for(docid_t docnum = start; docnum <= finish; docnum += CONF_COLLECTION_DISTRIBUTED)
		{
			// salva nel connddx relativo all'istanza, secondo il seguente schema
			// es. su tre instanze e dunque tre indici connddx
			// (docid - 1) / CONF_COLLECTION_DISTRIBUTED + 1
			// 0 / 3 = 0	1 / 3 = 0	2 / 3 = 0	-->	+ 1	docid 1 in connddx relativo
			// 3 / 3 = 1	4 / 3 = 1	5 / 3 = 1	-->	+ 1	docid 2	in connddx relativo
			// 6 / 3 = 2	7 / 3 = 2	8 / 3 = 2	-->	+ 1	docid 3 in connddx relativo
			// 9 / 3 = 3	10/ 3 = 3	11/ 3 = 3	-->	+ 1	docid 4	in connddx relativo
			// 12/ 3 = 4	13/ 3 = 4	14/ 3 = 4	-->	+ 1	docid 5	in connddx relativo
			// 15/ 3 = 5	16/ 3 = 5	17/ 3 = 5	-->	+ 1	docid 6	in connddx relativo
			// ...
//			docid_t connddx_nvcid = (((docnum - 1)/ CONF_COLLECTION_DISTRIBUTED) + 1);
			docid_t connddx_nvcid = docnum;

			if(connddx_nvcid % INTERVAL_PRINT == 0)
				mcerr << "Check if good for search engine " << docnum << "/" << finish <<" (" << ndocs_ok << " ok)" << mendl;

			metaddx_status_t rc;
			doc_t ddoc;
			ddoc.docid = docnum;

			rc = meta->doc_retrieve( &(ddoc) );
			assert( ddoc.docid == docnum );

		   	if( rc == METADDX_OK ) {

				// P.S. I documenti duplicati non vengono elaborati!
				if ((ddoc.mime_type == MIME_TEXT_HTML || ddoc.mime_type == MIME_APPLICATION_PDF || ddoc.mime_type == MIME_TEXT_PLAIN) && ddoc.duplicate_of == 0)
				{
					bool have_rank = false;

					if (CONF_MANAGER_SCORE_PAGERANK_WEIGHT > 0 && ddoc.pagerank > 0)
						have_rank = true;

					if (have_rank == false && CONF_MANAGER_SCORE_WLSCORE_WEIGHT > 0 && ddoc.wlrank > 0)
						have_rank = true;

					if (have_rank == false && CONF_MANAGER_SCORE_WLSCORE_WEIGHT > 0 && ddoc.hubrank > 0)
						have_rank = true;

					if (have_rank == false && CONF_MANAGER_SCORE_WLSCORE_WEIGHT > 0 && ddoc.authrank > 0)
						have_rank = true;

					if (have_rank == false) // before insert new document, cbot-connector ensure that it have a valid ranking 
						continue;

					nvc_t doc;
					doc.docid = docnum;

					site_t siteinfo;
					siteinfo.siteid = ddoc.siteid;
					meta->site_retrieve( &(siteinfo) );

					if (indexupdate == true && updatescores == true)
					{
						connddx_status_t rc;

						// prima di eseguire gli update, verifico che i docid siano presenti nel file connddx.doc
						rc = connddx_nvc_retrieve( connddx, &(doc) );
		
						if( rc == CONNDDX_OK ) {
							if (siteinfo.siterank > (doc.siterank + doc.siterank / 5) || siteinfo.siterank < (doc.siterank - doc.siterank / 5) || ddoc.pagerank != doc.pagerank || ddoc.wlrank != doc.wlrank || ddoc.liverank != doc.liverank) {
							// allo stato attuale eseguo UPDATE solo se verifico un cambiamento del 5% di siterank (non sta in doc_t) pagerank,wlrank o liverank
								if (feeder(instance, &(ddoc), &(siteinfo), Bdb, query, false)) {
									ndocs_ok++;
									doc.siterank = siteinfo.siterank;
									doc.pagerank = ddoc.pagerank;
									doc.wlrank = ddoc.wlrank;
									doc.liverank = ddoc.liverank;
									doc.cscore = (priority_t)(ddoc.future_score >=0? ddoc.future_score : 0);
									doc.uscore = (priority_t)0;
									connddx_nvc_store( connddx, &(doc) );
								}
							}
						}
					}
					else if (indexupdate == true)
					{
						connddx_status_t rc;

						rc = connddx_nvc_retrieve( connddx, &(doc) ); // se non esiste il documento resituisce il doc.docid uguale a zero
		
						if( rc == CONNDDX_OK)
						{
							if (HTTP_IS_OK(ddoc.http_status) && ddoc.number_visits_changed > doc.number_visits_changed)
							{
								if (feeder(instance, &(ddoc), &(siteinfo), Bdb, query, false))
								{
									ndocs_ok++;
									doc.siterank = siteinfo.siterank;
									doc.pagerank = ddoc.pagerank;
									doc.wlrank = ddoc.wlrank;
									doc.liverank = ddoc.liverank;
									doc.cscore = (priority_t)(ddoc.future_score >=0? ddoc.future_score : 0);
									doc.uscore = (priority_t)0;
									doc.number_visits_changed = ddoc.number_visits_changed;
									doc.http_status = ddoc.http_status;
									connddx_nvc_store( connddx, &(doc) );
								}
							}
						}
						else
						{
							doc.docid = (((docnum - 1)/ CONF_COLLECTION_DISTRIBUTED) + 1); // connddx_nvc_retrieve l'ha settato a zero. Occorre ripristinarlo!
		
							if (feeder(instance, &(ddoc), &(siteinfo), Bdb, query, true))
							{
								ndocs_ok++;
								doc.siterank = siteinfo.siterank;
								doc.pagerank = ddoc.pagerank;
								doc.wlrank = ddoc.wlrank;
								doc.liverank = ddoc.liverank;
								doc.cscore = (priority_t)(ddoc.future_score >=0? ddoc.future_score : 0);
								doc.uscore = (priority_t)0;
								doc.number_visits_changed = ddoc.number_visits_changed;
								doc.http_status = ddoc.http_status;
								connddx_nvc_store( connddx, &(doc) );
							}
						}
					}
					else
					{
						if (feeder(instance, &(ddoc), &(siteinfo), Bdb, query, true)) {
							ndocs_ok++;
							doc.siterank = siteinfo.siterank;
							doc.pagerank = ddoc.pagerank;
							doc.wlrank = ddoc.wlrank;
							doc.liverank = ddoc.liverank;
							doc.cscore = (priority_t)(ddoc.future_score >=0? ddoc.future_score : 0);
							doc.uscore = (priority_t)0;
							doc.number_visits_changed = ddoc.number_visits_changed;
							doc.http_status = ddoc.http_status;
							connddx_nvc_store( connddx, &(doc) );
						}
					}
				}
			}
			else
			{
				conlock;
				cerr << '_';
				cunlock;
			}
		}

	} catch(const mysqlpp::BadQuery &e) {

		mcerr << "EXCEPTION: " << e.what() << mendl;

		while(!conn.ping())
		{
			sleep(1);
			mcerr << "Waiting for DB to come back" << mendl;
		}

		if(!conn.select_db(sphinx_db))
			mcerr << "Failed to change DB" << mendl;

	} catch(DbException &e) {
		mcerr << "Error loading databases. " << e.what() << mendl;
		//return(e.get_errno());
		return NULL;
	} catch(exception &e) {
		mcerr << "Error loading databases. " << e.what() << mendl;
        	//return(-1);
       	return NULL;
	}

	if (Bdb != NULL) {
		Bdb->close(0);
		delete Bdb;
	}
	
	// disconnect mysql
	conn.disconnect();
	conn.thread_end();

	// need for syncronize exceptions without caller
	connector_sync_threads(connector_barrier);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(connector_barrier);
}
}

// Nome: feeder
//
// Descrizione: Funzione in cui vengono elaborati definitivamente i documenti prima di essere salvati dalla stessa funzione nell'indice/i
// del motore di ricerca con database 'tipo sql'.
//
// Argomenti: struttura doc_t, struttura site_t, input buffer, oggetto della classe Berkeley Database, oggetti della classe mysql,
// booleano che indica se il documento da salvare è nuovo
//
// Restituisce: booleano che indica 'vero' se la funzione ha eseguito con successo
//
//bool feeder(unsigned int &instance, doc_t *doc, site_t *siteinfo, char *buf, Bdb &datalinksDB, mysqlpp::Query query, bool &insert)
bool feeder(instance_t *instance, doc_t *doc, site_t *siteinfo, Db *Bdb, mysqlpp::Query query, bool insert)
{
	assert(doc->docid > 0);

	if (HTTP_IS_CLIENT_ERROR(doc->http_status)) { // se codice errore tipo '404 Not Found'
		// ottengo il nome dell'indice realtime in cui cancellare il documento
		ostringstream inum;
		inum << (((((doc->docid - 1) - *instance) + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED) % CHUNKS);
		string rtindex = ("rtchunk" + inum.str());
		query << "DELETE FROM " << rtindex << " WHERE id = " << doc->docid;
		query.execute();

		return true;
	}
		
	score_t siterank = (RANK_MAX * siteinfo->siterank);
	score_t pagerank = (RANK_MAX * doc->pagerank);
	score_t wlrank = (RANK_MAX * doc->wlrank);
	score_t liverank = (RANK_MAX * doc->liverank);
	score_t cscore = (doc->future_score >=0 ? doc->future_score : 0);

	if (indexupdate == true && updatescores == true) { // aggiorna i ranking gestiti dal crawler
		// ottengo il nome dell'indice realtime dove occorre scrivere i dati
		ostringstream inum;
		inum << (((((doc->docid - 1) - *instance) + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED) % CHUNKS);
		string rtindex = ("rtchunk" + inum.str());

		query << "UPDATE " << rtindex << " SET siterank = " << siterank << ", pagerank = " << pagerank << ", wlrank = " << wlrank
		<< ", liverank = " << liverank << ", cscore = " << cscore << ", uscore = 0, lastmtime = " << doc->last_modified
		<< ", depth = "	<< doc->depth << " WHERE id = " << doc->docid;
		query.execute();

		return true;
	}

	if (doc->duplicate_of > 0)
		return true; // do nothing, but analyse in updatescores sessions

	storage_status_t rc;
	char _url[MAX_STR_LEN] = {ASCII_NUL};

	off64_t size;
	char *buf = CBALLOC(char, MALLOC, MAX_DOC_LEN);
	rc = strg->read_document( doc, buf );

	if(rc != STORAGE_OK)
	{
		conlock;
		cerr << 'x';
		cunlock;
		free(buf);
		return false;
	}

	url->url_by_docid( doc->docid, _url );

	// Check length of _url
	size_t urlsize = strlen(_url);
	if( urlsize >= MAX_STR_LEN ) {
		cerr << "!";
		free(buf);
		return false;
	}

	size_t length = 0;
	pes_t *poutt;
 
	if (doc->mime_type == MIME_TEXT_HTML)
	{
		poutt = htmlSplit(buf); // Estrapolazione dei meta tags, contenuto ecc... dal buffer storage
	
		length = strlen(poutt->content);
	}
	else if (doc->mime_type == MIME_APPLICATION_PDF)
	{
		poutt = pdfSplit(buf); // Estrapolazione dei meta informazioni, contenuto ecc... dal buffer storage
	
		length = strlen(poutt->content);
	}
	else if (doc->mime_type == MIME_TEXT_PLAIN)
	{
		poutt = (pes_t*) malloc (sizeof(pes_t));
		poutt->content = (char*) malloc (sizeof(char) * MAX_DOC_LEN);
		poutt->content[0] = ASCII_NUL;
		strcpy(poutt->content,buf);
	
		length = strlen(buf);
	
		poutt->title[0] = ASCII_NUL;
		poutt->headings[0] = ASCII_NUL;
		poutt->metadesc[0] = ASCII_NUL;
		poutt->metakeyw[0] = ASCII_NUL;
		poutt->metalmon = pes_t::NO_LOCAL_MONETARY;
	}
	else
	{
		free(buf);
		return false;
	}

	char site[MAX_DOMAIN_LEN];

        // Copy the site name
	// Nome dominio ad esclusione del prefisso 'www.'
    	unsigned short sitelen = 0;
	if (_url[0] == 'w' && _url[1] == 'w' && _url[2] == 'w'  && _url[3] == '.')
	{
    		for( sitelen=4; ((sitelen - 4) < MAX_DOMAIN_LEN - 1) && _url[sitelen] != ASCII_SL && _url[sitelen] != ASCII_NUL; sitelen++ )
			site[sitelen - 4] = _url[sitelen];

		site[sitelen - 4] = ASCII_NUL;
	}
	else
	{
    		for( sitelen=0; _url[sitelen] != ASCII_SL && _url[sitelen] != ASCII_NUL; sitelen++ )
			site[sitelen] = _url[sitelen];

		site[sitelen] = ASCII_NUL;
	}

	// Verifico a quale profondità del path si trova il documento.
	depth_t slashes = 1; // di defalut valore 1
	char *pch = strchr(_url, ASCII_SL); // trova la posizione del primo slash dentro l'url
	while (pch != NULL && slashes < 4)
	{
		slashes++;
		pch=strchr((pch + 1), ASCII_SL);
	}
	pch = NULL; // altrimenti a ciclo interrotto potrebbe puntare ancora dentro un _url!

	// legenda:
	// se www.nomesito.it/ allora slashes resta 2 (valore ottimale per home page)
	// se www.nomesito.it/index.pl viene indicato homepage da urlddx_is_homepage slashes diventa 3;
	// se www.nomesito.it/abiti.pl non viene indicato homepage da urlddx_is_homepage slashes diventa 4;
	// se www.nomesito.it/perl/index.pl viene indicato homepage da urlddx_is_homepage slashes resta 3;
	// in pratica: una homepage assoluta prende voto 2, una presunta homepage prende voto 3, le altre da 4 in su!
	if(slashes == 2) // potrebbe essere una homepage
	{
		if (_url[urlsize - 1] != ASCII_SL)
		{
			if (url->is_homepage(doc->docid) == true)
				slashes++;
			else if (url->is_homepage(doc->docid) == false)
				slashes += 2;
		}
	}
	else
	{		
		// Se trovo tre al valore slashes perferisco 'certificare' che l'url sia una homepage!
		if(slashes == 3 && url->is_homepage(doc->docid) == false)
		{
			if (doc->depth > slashes)
				slashes = doc->depth;
			else
				slashes++;
		}
		else if (slashes > 3 && doc->depth > slashes)
			slashes = doc->depth;
	}
	
	// Puntatore ad array che contiene le parole chiave in un url
	char *purlwords = urlWords(instance, _url, slashes);

	if (purlwords == NULL)
		purlwords = CBALLOC(char, CALLOC, 1);

	// Ha poco senzo indicizzare documenti che poi quando il visitatore va a leggere contengono pochissime parole.
	// N.B. Escludendo alcuni documenti per lunghezza inconsistente di conseguenza alcuni doc->docid non verranno inseriti nel motore di ricerca
	// Per le homepage (o quello che sembrano) l'elaborazione viene effettuata sempre, quando vengono trovate.
	if ((((doc->mime_type == MIME_TEXT_HTML || doc->mime_type == MIME_APPLICATION_PDF || doc->mime_type == MIME_TEXT_PLAIN) && (slashes == 2 || info[*instance].isvirtualhomepage == true))) || length > MIN_TEXT_LEN)
	{
		Language lang = Language::IT;
		// preparo l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
		// utile alla classe delle tematiche e alla ricerca dei termini infissi in map_abbreviated
		thematic_out_t *theminfo = th.make_dupl_index (lang, NULL, min_word_len, poutt, length);

        // Load the datalinks database
		char *idsito = numtostring<siteid_t>(doc->siteid);
		char *chiave = numtostring<docid_t>(doc->docid);

		if (insert == true)
		{ // condizione in cui la chiave non esiste nel file connddx.doc e di conseguenza ne in berkeleyDB ne nel database del search engine

			//mcout << doc->docid << '-' << _url << mendl;
			domainscleared_t *domainscleared = domainCleared(instance, theminfo, poutt, length, doc, site, slashes, insert);

			// Ricava il ranking delle tematiche e le parole sensibili, cioè presenti contemporaneamente in più campi della pagina html
			th.index_read(theminfo, dictionary_url, row_dictionary_url, min_word_len, poutt, length, purlwords, domainscleared->clevel_domain, domainscleared->olevels_domain);

			// Ricavo il titolo che valido per l'elaborazione ai fini di ranking, questi sarà anche quello che verrà visualizzato su Cassiopeia
			// Al termine della funzione otteniamo anche la lunghezza di mytitle
			string mytitle = static_cast<string>(selectmytitle(poutt->title, poutt->metadesc, site));

			// nel caso si tratti di un portale con tanti sotto domini,
			// viene valorizzato il dominio di secondo livello SOLO per l'FQDN con siterank più alto
			// Sono esclusi i domini italiani speciali
			char *clevel_domain = NULL;
			char *lowlevel_domain = NULL;

			if (domainscleared->geo_domain[0] != ASCII_NUL || siteinfo->siteid == bestsite_for_domain[siteinfo->domainid].siteid)
			{
				clevel_domain = domainscleared->clevel_domain;
				lowlevel_domain = (char *) malloc (sizeof(char));
				lowlevel_domain[0] = ASCII_NUL;
			}
			else
			{
				lowlevel_domain = domainscleared->clevel_domain;
				clevel_domain = (char *) malloc (sizeof(char));
				clevel_domain[0] = ASCII_NUL;
			}
			// fine valorizzazione
		
			// Se la tematica NON ha un numero sufficiente di termini che la confermano, NON viene indicizzata
			if (theminfo->ranking > 0 && theminfo->count_terms < 2)
				theminfo->thematic[0] = ASCII_NUL;

			// ottengo il nome dell'indice realtime dove occorre scrivere i dati
			ostringstream inum;
			inum << (((((doc->docid - 1) - *instance) + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED) % CHUNKS);
			string rtindex = ("rtchunk" + inum.str());

			// debug purpose
			if (debugonly == true && theminfo->ranking > 0)
				mcout << doc->docid << " SITENAME " << _url << " P LIV - " << domainscleared->geo_domain <<  " S LIV - " << clevel_domain << " O LIV - " << domainscleared->olevels_domain << " L LIV - " << lowlevel_domain << " - DESCRIPTION " << poutt->metadesc << " KEYWORDS " << poutt->metakeyw << " THEMATIC " << theminfo->thematic <<  " TOP WORDS " << theminfo->top_words << " GOOD WORDS " << theminfo->good_words << " SENSITIVE WORDS " << theminfo->sensitive_words << " THEMATIC RANKING "<< theminfo->ranking << " terms " << theminfo->count_terms << mendl;

			char documenttype = '0'; 

			if (doc->mime_type == MIME_TEXT_HTML)
				documenttype = '1';
			else if (doc->mime_type == MIME_APPLICATION_PDF)
				documenttype = '2';
			else if (doc->mime_type == MIME_TEXT_PLAIN)
				documenttype = '3';

			if (debugonly == false)
			{
				// uscore uso futuro
				query << "INSERT INTO " << rtindex << " (id,docid,siteid,domainid,from_feed,geo_domain,clevel_domain,olevels_domain,lowlevel_domain,mytitle,title,description,keywords,headings,content,thematic,top_words,good_words,sensitive_words,nullfield,size,documenttype,siterank,pagerank,wlrank,liverank,cscore,uscore,themrank,lastmtime,goodtime,depth,slashes) VALUES ("
				<< doc->docid << "," << doc->docid << "," << doc->siteid << "," << doc->domainid << "," << doc->from_feed
				<< ",\'" << mysqlpp::escape << domainscleared->geo_domain << "\'"
				<< ",\'" << mysqlpp::escape << clevel_domain << "\'"
				<< ",\'" << mysqlpp::escape << domainscleared->olevels_domain << "\'"
				<< ",\'" << mysqlpp::escape << lowlevel_domain << "\'"
				<< ",\'" << mysqlpp::escape << mytitle << "\'"
				<< ",\'" << mysqlpp::escape << poutt->title << "\'"
				<< ",\'" << mysqlpp::escape << poutt->metadesc << "\'"
				<< ",\'" << mysqlpp::escape << poutt->metakeyw << "\'"
				<< ",\'" << mysqlpp::escape << poutt->headings << "\'"
				<< ",\'" << mysqlpp::escape << poutt->content << "\'"
				<< ",\'" << mysqlpp::escape << theminfo->thematic << "\'"
				<< ",\'" << mysqlpp::escape << theminfo->top_words << "\'"
				<< ",\'" << mysqlpp::escape << theminfo->good_words << "\'"
				<< ",\'" << mysqlpp::escape << theminfo->sensitive_words << "\'"
				<< ",\'z\'" << ","
				<< size << "," << documenttype << ","
				<< siterank << "," << pagerank << "," << wlrank << "," << liverank << "," << cscore << "," << "0" << "," << theminfo->ranking << ","
				<< doc->last_modified << "," << starttime << "," << doc->depth << "," << slashes << ")";
				query.execute();
			}

			if (domainscleared->geo_domain[0] != ASCII_NUL || siteinfo->siteid == bestsite_for_domain[siteinfo->domainid].siteid)
				free(lowlevel_domain);
			else
				free(clevel_domain);

			delete [] domainscleared->geo_domain;
			domainscleared->geo_domain = NULL;

			delete [] domainscleared->clevel_domain;
			domainscleared->clevel_domain = NULL;

			delete [] domainscleared->olevels_domain;
			domainscleared->olevels_domain = NULL;

			free(domainscleared);

			// Load the datalinks database
			string pagepath = strg->find_path(doc->docid);

			// Se la tematica NON ha un numero sufficiente di termini che la confermano NON viene pubblicata
			if (theminfo->thematic[0] == ASCII_NUL || (theminfo->ranking > 0 && theminfo->count_terms < 3))
			{
				char null_thematic[] = "null";

				strncpy(theminfo->thematic, null_thematic, 4);

				theminfo->thematic[4] = ASCII_NUL;
			}

			char protocol = '0';
			char opt_desc = '0';

			if (siteinfo->protocol == HTTPS)
				protocol = '1';

			size_t desclen = strlen(poutt->metadesc);

			if ((slashes == 2 || info[*instance].isvirtualhomepage == true) && desclen > 0 && desclen != mytitle.length())
					opt_desc = '1';

			string dato = idsito + static_cast<string>(" ") + pagepath + static_cast<string>(" ") + documenttype + static_cast<string>(" ") + protocol + static_cast<string>(" ") + opt_desc + static_cast<string>(" ") + _url + static_cast<string>(" ") + theminfo->thematic + static_cast<string>(" ") + mytitle;
			
	//		free(theminfo->thematic);

			Dbt key(const_cast<char*>(chiave), strlen(chiave));
			Dbt data(const_cast<char*>(dato.data()), (dato.size() + 1));
			Bdb->put(NULL, &key, &data, 0);
		}
		else
		{
			domainscleared_t *domainscleared = domainCleared(instance, theminfo, poutt, length, doc, site, slashes, insert);

			// Ricava il ranking delle tematiche e le parole sensibili, cioè presenti contemporaneamente in più campi della pagina html
			th.index_read(theminfo, dictionary_url, row_dictionary_url, min_word_len, poutt, length, purlwords, domainscleared->clevel_domain, domainscleared->olevels_domain);

			// Ricavo il titolo che valido per l'elaborazione ai fini di ranking, questi sarà anche quello che verrà visualizzato su Cassiopeia
			// Al termine della funzione otteniamo anche la lunghezza di mytitle
			string mytitle = static_cast<string>(selectmytitle(poutt->title, poutt->metadesc, site));

			// nel caso si tratti di un portale con tanti sotto domini,
			// viene valorizzato il dominio di secondo livello SOLO per l'FQDN con siterank più alto
			// Sono esclusi i domini italiani speciali
			char *clevel_domain = NULL;
			char *lowlevel_domain = NULL;

			if (domainscleared->geo_domain[0] != ASCII_NUL || siteinfo->siteid == bestsite_for_domain[siteinfo->domainid].siteid)
			{
				clevel_domain = domainscleared->clevel_domain;
				lowlevel_domain = (char *) malloc (sizeof(char));
				lowlevel_domain[0] = ASCII_NUL;
			}
			else
			{
				lowlevel_domain = domainscleared->clevel_domain;
				clevel_domain = (char *) malloc (sizeof(char));
				clevel_domain[0] = ASCII_NUL;
			}
			// fine valorizzazione

			// Se la tematica NON ha un numero sufficiente di termini che la confermano, NON viene indicizzata
			if (theminfo->ranking > 0 && theminfo->count_terms < 2)
				theminfo->thematic[0] = ASCII_NUL;

			// ottengo il nome dell'indice realtime dove occorre scrivere i dati
			ostringstream inum;
			inum << (((((doc->docid - 1) - *instance) + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED) % CHUNKS);
			string rtindex = ("rtchunk" + inum.str());

			char documenttype = '0'; 

			if (doc->mime_type == MIME_TEXT_HTML)
				documenttype = '1';
			else if (doc->mime_type == MIME_APPLICATION_PDF)
				documenttype = '2';
			else if (doc->mime_type == MIME_TEXT_PLAIN)
				documenttype = '3';

			if (debugonly == false)
			{
				// uscore uso futuro
				query << "REPLACE INTO " << rtindex << " (id,docid,siteid,domainid,from_feed,geo_domain,clevel_domain,olevels_domain,lowlevel_domain,mytitle,title,description,keywords,headings,content,thematic,top_words,good_words,sensitive_words,nullfield,size,documenttype,siterank,pagerank,wlrank,liverank,cscore,uscore,themrank,lastmtime,goodtime,depth,slashes) VALUES ("
				<< doc->docid << "," << doc->docid << "," << doc->siteid << "," << doc->domainid << "," << doc->from_feed
				<< ",\'" << mysqlpp::escape << domainscleared->geo_domain << "\'"
				<< ",\'" << mysqlpp::escape << clevel_domain << "\'"
				<< ",\'" << mysqlpp::escape << domainscleared->olevels_domain << "\'"
				<< ",\'" << mysqlpp::escape << lowlevel_domain << "\'"
				<< ",\'" << mysqlpp::escape << mytitle << "\'"
				<< ",\'" << mysqlpp::escape << poutt->title << "\'"
				<< ",\'" << mysqlpp::escape << poutt->metadesc << "\'"
				<< ",\'" << mysqlpp::escape << poutt->metakeyw << "\'"
				<< ",\'" << mysqlpp::escape << poutt->headings << "\'"
				<< ",\'" << mysqlpp::escape << poutt->content << "\'"
				<< ",\'" << mysqlpp::escape << theminfo->thematic << "\'"
				<< ",\'" << mysqlpp::escape << theminfo->top_words << "\'"
				<< ",\'" << mysqlpp::escape << theminfo->good_words << "\'"
				<< ",\'" << mysqlpp::escape << theminfo->sensitive_words << "\'"
				<< ",\'z\'" << ","
				<< size << "," << documenttype << ","
				<< siterank << "," << pagerank << "," << wlrank << "," << liverank << "," << cscore << "," << "0" << "," << theminfo->ranking << ","
				<< doc->last_modified << "," << starttime << "," << doc->depth << "," << slashes << ")";
				query.execute();
			}

			if (domainscleared->geo_domain[0] != ASCII_NUL || siteinfo->siteid == bestsite_for_domain[siteinfo->domainid].siteid)
				free(lowlevel_domain);
			else
				free(clevel_domain);

			delete [] domainscleared->geo_domain;
			domainscleared->geo_domain = NULL;

			delete [] domainscleared->clevel_domain;
			domainscleared->clevel_domain = NULL;

			delete [] domainscleared->olevels_domain;
			domainscleared->olevels_domain = NULL;

			free(domainscleared);

			// Load the datalinks database
			string pagepath = strg->find_path(doc->docid);

			// Se la tematica NON ha un numero sufficiente di termini che la confermano NON viene pubblicata
			if (theminfo->thematic[0] == ASCII_NUL || (theminfo->ranking > 0 && theminfo->count_terms < 3))
			{
				char null_thematic[] = "null";

				strncpy(theminfo->thematic, null_thematic, 4);

				theminfo->thematic[4] = ASCII_NUL;
			}

			char protocol = '0'; 
			char opt_desc = '0'; 

			if (siteinfo->protocol == HTTPS)
				protocol = '1';

			size_t desclen = strlen(poutt->metadesc);

			if ((slashes == 2 || info[*instance].isvirtualhomepage == true) && desclen > 0 && desclen != mytitle.length())
					opt_desc = '1';

			string dato = idsito + static_cast<string>(" ") + pagepath + static_cast<string>(" ") + documenttype + static_cast<string>(" ") + protocol + static_cast<string>(" ") + opt_desc + static_cast<string>(" ") + _url + static_cast<string>(" ") + theminfo->thematic + static_cast<string>(" ") + mytitle;

			Dbt key(const_cast<char*>(chiave), strlen(chiave));
			Dbt data(const_cast<char*>(dato.data()), (dato.size() + 1));
			Bdb->put(NULL, &key, &data, 0);
		}

		free(idsito);
		free(chiave);

		// libero l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
		th.free_dupl_index(theminfo);
	}

	if (purlwords != NULL)
		free(purlwords);

	poutt->title[0] = ASCII_NUL;
	poutt->headings[0] = ASCII_NUL;
	poutt->metadesc[0] = ASCII_NUL;
	poutt->metakeyw[0] = ASCII_NUL;
	poutt->metalmon = pes_t::NO_LOCAL_MONETARY;

	// libera l'area (dealloca) di memoria puntata dal puntatore content anche se di default avviene al termine del programma
	free(poutt->content);
	free(poutt);
	free(buf);

	return true;
}

//
// Name: cleanup
//
// Description: 
//   Closes files, indexes
//
void cleanup() {
	if( meta != NULL ) {
		meta->ddx_close();
		delete meta;
		cerr << "[metaddx] ";
	}
	if( url != NULL ) {
		url->ddx_close();
		delete url;
		cerr << "[urlddx] ";
	}
	if( strg != NULL ) {
		strg->st_close();
		delete strg;
		cerr << "[storage] ";
	}
	if( ifxddx != NULL ) {
		ifxddx_close( ifxddx );
		cerr << "[ifxddx] ";
	}
	if( connddx != NULL ) {
		connddx_close( connddx );
		cerr << "[storage] ";
	}
	if( tempidx != NULL )
	{
		istidx_close(tempidx);
		cerr << "[istance] ";
	}
	
	th.index_close (true);
	cerr << "[thematics] ";

	free(info); info = NULL;
	free(tempidx_term_hash); tempidx_term_hash = NULL;
	free(terms_split_offset); terms_split_offset = NULL;
	free(bestsite_for_domain); bestsite_for_domain = NULL;
}

//
// Name: selectmytitle
//
// Description: seleziona un titolo valido per le ricerche
//
// Argomenti in ingresso: puntatori ad titolo, descrizione, nome dominio
//
char *selectmytitle(char *a, char *b, char c[])
{
char *mytitle;

	if (a[0] != ASCII_NUL && strlen(a) < MAX_STR_LEN && isalpha(a[0]) != 0)
		mytitle = a;
	else if (b[0] != ASCII_NUL && strlen(b) < MAX_STR_LEN && isalpha(b[0]) != 0)
		mytitle = b;
	else
		mytitle = c;

	return mytitle;
}

//
// Name: urlWords
//
// Description: Estrapola se possibile dalla fine dell'url le parole sensibili che permettono di migliorare la ricerca
//
// Restiusce un puntatore con le parole sensibili che si trovavano nell'url
//
char *urlWords(instance_t *instance, string url, depth_t slashes)
{
size_t pos = 0;
size_t oldpos = 0;
bool firststep = false;
bool checkif_virtualhomepage = false; // cerca di capire se l'url porta verso una POSSIBILE homepage tipo 'home' o 'index' con qualsiasi estensione
info[*instance].isvirtualhomepage = false;
size_t origurllength = url.length();
size_t urllength = origurllength;
char *oldtemparr = NULL;
char *oldoldtemparr = NULL;
size_t sitelen = 0;

	// determina la lunghezza del nome dominio fqdn
	while (url[sitelen] != ASCII_SL && url[sitelen] != ASCII_NUL)
		sitelen++;

	// esce se il nome dominio fqdn è lungo quanto l'url
	if (sitelen == (urllength - 1))
		return NULL;

	assert(sitelen > 0);

	// la lunghezza fittizia dell'url viene ridotta fino a quando i caratteri consecutivi finali tipo numeri o slash non terminano
	while (urllength >= sitelen && (url[(urllength - 1)] == ASCII_SL || isdigit(url[(urllength - 1)]) == true))
		urllength--;

	// se non si può determinare con i 'metodi tradizionali' se si tratta di una homepage, il seguente sistema tenta di determinare con un metodo euristico
	// se si tratta di una 'potenziale' homepage verificando che l'url non presenti troppi slashes e termini con nomi file del tipo:
	// index.html, index.php, index.cgi, home.cgi ecc...
	// La ricerca di queste potenziali homepage serve a strInfixed per avere a disposizione un maggior numero di contenuti dove cercare i termini infissi.
	// Esempio: l'url www.uniss.it/php/home.php non verrebbe identificata come homepage con gli altri metodi e
	// strInfixed potrebbe fallire nella ricerca di termini infissi
	// Inoltre limitando il numero di slashes la ricerca viene comunque circoscritta a quelle che dovrebbero essere le pagine principali
	if (origurllength == urllength && slashes > 2 && slashes < 5)
	{
		short count_points = 0;
		short count_alpha = 0;
		size_t offset = urllength;
	
		while (url[(offset - 1)] != ASCII_SL)
		{
			if (url[offset] == '.')
				count_points++;
			else if (isalpha(url[offset]))
				count_alpha++;
	
			offset--;
		}
	
		// se dall'ultimo slashes si trova al massimo un carattere 'punto' e per il resto caratteri alfabetici allora si può procedere alla verifica di una
		// homepage virtuale
		if (offset == (urllength - count_alpha - count_points - 1) && count_points == 1)
			checkif_virtualhomepage = true;
	}
	
	if (checkif_virtualhomepage == true)
	{
		oldtemparr = CBALLOC(char, CALLOC, MAX_STR_LEN);
		oldoldtemparr = CBALLOC(char, CALLOC, MAX_STR_LEN);
	}
	
	char *temparr = CBALLOC(char, CALLOC, MAX_STR_LEN);
	char *urlkeywords = CBALLOC(char, MALLOC, MAX_STR_LEN);
	memset(urlkeywords, '|', MAX_STR_LEN);
	urlkeywords[0] = ASCII_NUL;
	
	//for (size_t c = o; c <= urllength; c++)
	for (size_t c = sitelen; c <= urllength; c++)
	{
		if (c > sitelen)
		{
			if (isalpha(url[c]) == false || c == urllength)
			{
				if ((pos - oldpos) <= MIN_WORD_LEN)
					temparr[oldpos] = ASCII_NUL;
		
				if (strlen(temparr) > MIN_WORD_LEN)
					if (checkpwu(temparr, dictionary_url, row_dictionary_url, rowuindex ) == false)
					{
						if (firststep == false)
						{
							strcpy(urlkeywords, temparr);
							firststep = true;
						}
						else
							strcat(urlkeywords, temparr);
	
						if (c < urllength)
							strcat(urlkeywords, " ");
					}
	
				if (checkif_virtualhomepage == true)
				{
					strcpy(oldoldtemparr, oldtemparr);	
					strcpy(oldtemparr, temparr);
				}
	
				memset (temparr,ASCII_NUL,MAX_STR_LEN);
				pos = 0;
				oldpos = 0;
			}
			else
			{
				if (pos > 0 && (isupper(url[c]) && islower(url[c - 1])))
				{
					if (oldpos == 0 || (pos - oldpos) > MIN_WORD_LEN)
					{
						oldpos = pos;
						temparr[pos++] = ' ';
						temparr[pos++] = tolower(url[c]);
					}
					else
						pos = (oldpos);
		
				}
				else
					temparr[pos++] = tolower(url[c]);
			}
		}
	}
	
	// l'url termina con '/nomefile.estensione' e si procede per la verifica di una homepage virtuale
	if (checkif_virtualhomepage == true)
	{
		if (strlen(oldoldtemparr) == 5 && strncmp (oldoldtemparr,"index",5) == 0)
			info[*instance].isvirtualhomepage = true;
	
		if (strlen(oldoldtemparr) == 4 && strncmp (oldoldtemparr,"home",4) == 0)
			info[*instance].isvirtualhomepage = true;
	}
		
	free (temparr);
	free (oldtemparr);
	free (oldoldtemparr);
///////////////////////////////////////////////////////////// TODO
// a causa di una segnalazione di valgrind (a dire il vero mi sembra un falso positivo...) mi serve verificare per un po' di tempo se urlkeywords
// viene gestito correttamente, motivo per cui a monte viene riempito con il carattere '|'
	unsigned int bo = 0;
	for (bo = 0; bo < MAX_STR_LEN; bo++)
		if (urlkeywords[bo] == ASCII_NUL)
			break;

	assert(bo < MAX_STR_LEN);

	for (unsigned int i = 0; i < strlen(urlkeywords); i++)
		if (urlkeywords[i] == '|')
			die ("urlkeywords invalid at pos %d", i);

	for (unsigned int i = strlen(urlkeywords) + 1; i < MAX_STR_LEN; i++)
		if (urlkeywords[i] != '|')
			die ("urlkeywords invalid at pos %d", i);

	memset(urlkeywords + strlen(urlkeywords), ASCII_NUL, (MAX_STR_LEN - strlen(urlkeywords)));
///////////////////////////////////////////////////////////////////////////////////////////////////
	return urlkeywords;
}

//
// Name: splitSite
//
// Description: recupero le parole che compogono il nome dominio ad esclusione del prefisso 'www.' e del dominio di primo livello
// es: info.domainname.net -> info domainname
// i domini italiani di secondo livello speciali e geografici non vengono esaminati
// es: comune.santagiusta.or.it -> comune.santagiusta
//
// Restituisce le parole che compongono il nome sito
//
char *splitSite(instance_t *instance, char *site)
{
	unsigned short dcount = 0;
	unsigned short scount = 0;

	bool ipv4_ipv6_address = true;

	bool is_italian_domain = false;

	size_t sitelen = strlen(site);

	char *_domain = (char *) malloc (MAX_DOMAIN_LEN * sizeof(char));
	assert(_domain != NULL);

	info[*instance].is_geo_domain = false;

	while (site[scount] != ASCII_NUL && scount < MAX_DOMAIN_LEN)
	{
		if (ipv4_ipv6_address == true && isdigit(site[scount]) == false && site[scount] != ASCII_DT && site[scount] != ASCII_CO)
			ipv4_ipv6_address = false;

		if (site[scount] == ASCII_DT)
		{
			_domain[dcount] = ASCII_DT;
			dcount++;

			if (sitelen - (scount + 1) > 4 && strncmp(&(site[scount + 1]),"xn--",4) == 0)
			{
				while (site[scount + 1] != ASCII_DT)
					scount++;

				scount++;

				_domain[dcount] = ASCII_DT;
				dcount++;
				info[*instance].domain_dotcount++;
			}

			info[*instance].domain_dotcount++;
		}
		else
		{
			if (scount == 0 && sitelen > 4 && strncmp(&(site[scount]),"xn--",4) == 0)
			{
				while (site[scount] != ASCII_DT)
					scount++;

//				_domain[dcount] = ASCII_DT;
//				dcount++;
				scount--;
			}
			else
			{
				if (isdigit(site[scount]) == true)
				{
					_domain[dcount] = site[scount];
					dcount++;

					scount++;
					continue;
				}
				else if (isalpha(site[scount]) == false)
				{
					_domain[dcount] = ASCII_SP;
					dcount++;
				}
				else
				{
					_domain[dcount] = site[scount];
					dcount++;
				}
			}
		}

		scount++;
	}

	_domain[dcount] = ASCII_NUL;

	if (ipv4_ipv6_address == true)
	{
		_domain[0] = ASCII_NUL;
		return _domain;
	}

	// ricava la posizione dove comincia il dominio di primo livello
	while (dcount > 0 && _domain[--dcount] != ASCII_DT);

	// verifico se si tratta di un dominio di primo livello italiano
	if (strcmp(&(_domain[dcount + 1]),"it") == 0)
	{
		is_italian_domain = true;
	}

	// ora si può escludere il primo livello
	_domain[dcount] = ASCII_NUL;
	info[*instance].domain_dotcount--;

	// ricavo la posizione dell'eventuale punto che separa il dominio di secondo livello dai superiori
	unsigned short dot_pos = 0;
	for (unsigned short t = dcount; t > 0; t--)
		if (_domain[t] == ASCII_DT)
		{
			dot_pos = t;
			break;
		}

	if (dot_pos > 0 && is_italian_domain == true && ((dcount - dot_pos - 1) == 2 || perfhash_check(&(keep_special), &(_domain[(dot_pos + 1)]))))
	{
		/* N.B. I domini di secondo livello di due caratteri associati a domini di primo livello italiani (.it)
		 * possono essere solo speciali, per la precisione geografici.
		 * Altri domini di secondo livello associati a domini di primo livello italiani (.it) possono essere speciali a seconda
		 * della corrispondenza del nome es: servizi.gov.it (gov è un dominio speciale)
		 */

		_domain[dot_pos] = ASCII_US; // sostituisce punto separatore dominio speciali con carattere non ammesso nei nomi dominio
		dcount = dot_pos;

		info[*instance].is_geo_domain = true;

		// essendo un dominio geografico sostituisce tutti i punti prima del punto separatore del terzo livello
		if (info[*instance].domain_dotcount > 2)
		{
			unsigned short cdot = 0;

			for (size_t i = 0; i < dot_pos && cdot < (info[*instance].domain_dotcount - 2); i++)
				if (_domain[i] == ASCII_DT)
				{
					_domain[i] = ASCII_SP;
					cdot++;
					info[*instance].domain_dotcount--;
				}
		}
	}
	else
	{
		// sostituisce tutti i punti prima del punto separatore del secondo livello
		if (info[*instance].domain_dotcount > 1)
		{
			unsigned short cdot = 0;

			for (size_t i = 0; i < dot_pos && cdot < info[*instance].domain_dotcount; i++)
				if (_domain[i] == ASCII_DT)
				{
					_domain[i] = ASCII_SP;
					cdot++;
					info[*instance].domain_dotcount--;
				}
		}
	}

	dcount = 0;
	scount = 0;
	char *domaincleared = CBALLOC(char, MALLOC, MAX_DOMAIN_LEN);

	// separo eventuali numeri dalle parole
	while (_domain[scount] != ASCII_NUL && scount < MAX_DOMAIN_LEN)
	{
		if (scount > 0 && ((isalpha(_domain[scount]) && isdigit(_domain[scount - 1])) || (isdigit(_domain[scount]) && isalpha(_domain[scount - 1]))))
		{
			domaincleared[dcount] = ASCII_SP;
			dcount++;
			domaincleared[dcount] = _domain[scount];
		}
		else
			domaincleared[dcount] = _domain[scount];

		scount++;

		dcount++;
	}

	domaincleared[dcount] = ASCII_NUL;

	free(_domain);

	return domaincleared;
}

/*
// Name: splitSite
//
// Description: recupero le parole che compogono il nome dominio ad esclusione del prefisso 'www.' e del dominio di primo livello
// es: info.domainname.net -> info domainname
// i domini italiani di secondo livello speciali e geografici non vengono esaminati
// es: comune.santagiusta.or.it -> comune.santagiusta
//
// Restituisce le parole che compongono il nome sito
//
char *splitSite(char *site)
{
unsigned short dcount = 0;
unsigned short scount = 0;
bool is_italian_domain = false;
char *_domain = (char *) malloc (MAX_DOMAIN_LEN * sizeof(char));

while (site[scount] != ASCII_NUL && scount < MAX_DOMAIN_LEN)
{
	if (site[scount] == ASCII_DT)
		_domain[dcount] = ASCII_DT;
	else
	{
		if (isdigit(site[scount]) == true)
		{
			_domain[dcount] = site[scount];

			scount++;
			dcount++;
			continue;
		}
		else if (isalpha(site[scount]) == false)
			_domain[dcount] = ASCII_SP;
		else
			_domain[dcount] = site[scount];
	}

	scount++;
	dcount++;
}

_domain[dcount] = ASCII_NUL;

// ricava la posizione dove comincia il dominio di primo livello
while (dcount > 0 && _domain[--dcount] != ASCII_DT);

// verifico se si tratta di un dominio di primo livello italiano
if (strcmp(&(_domain[dcount + 1]),"it") == 0)
{
	is_italian_domain = true;
}

// ora si può escludere il primo livello
_domain[dcount] = ASCII_NUL;

// ricavo la posizione dell'eventuale punto che separa il dominio di secondo livello dai superiori
unsigned short dot_pos = 0;
for (unsigned short t = dcount; t > 0; t--)
	if (_domain[t] == ASCII_DT)
	{
		dot_pos = t;
		break;
	}


if (is_italian_domain == true && dot_pos > 0 && ((dcount - dot_pos - 1) == 2 || (perfhash_check( &(keep_special), &(_domain[(dot_pos + 1)]) ))))
{
// non è possibile registrare domini italiani di solo due caratteri in quanto speciali ad esempio geografici
	_domain[dot_pos] = ASCII_US; // sostituisce punto separatore dominio speciali con carattere non ammesso nei nomi dominio
	dcount = dot_pos;

	bool separe_other_levels = false;

	// si tratta di un dominio geografico perciò allo stato attuale non mi interessa elaborare il 'secondo livello' ma lo escludo
	if (separe_other_levels == true)
	{
	// e ricavo la posizione dell'eventuale punto che separa il dominio di terzo livello dai superiori
	dot_pos = 0;

		for (unsigned short t = dcount; t > 0; t--)
			if (_domain[t] == ASCII_DT)
			{
				dot_pos = t;
				break;
			}
	}
	else // i domini di livello superiore al secondo vengono visti come se si trattasse di uno solo superiore al secondo
		dot_pos = dcount;
}

// sostituisce tutti i punti ad esclusione del punto separatore del secondo livello
for (size_t i = 0; i < dot_pos; i++)
	if (_domain[i] == ASCII_DT)
		_domain[i] = ASCII_SP;

dcount = 0;
scount = 0;
char *domaincleared = (char *) malloc (MAX_DOMAIN_LEN * sizeof(char));


// separo eventuali numeri dalle parole
while (_domain[scount] != ASCII_NUL && scount < MAX_DOMAIN_LEN)
{
	if (scount > 0 && ((isalpha(_domain[scount]) && isdigit(_domain[scount - 1])) || (isdigit(_domain[scount]) && isalpha(_domain[scount - 1]))))
	{
		domaincleared[dcount] = ASCII_SP;
		dcount++;
		domaincleared[dcount] = _domain[scount];
	}
	else
		domaincleared[dcount] = _domain[scount];

	scount++;

	dcount++;
}

domaincleared[dcount] = ASCII_NUL;

free(_domain);
// P.S. in domaincleared ci deve stare un solo punto separatore!
return domaincleared;
}
*/

//
// Name: joinText 
//
// Description: da una stringa composta da tante parole ne estrae tante composte da coppie di parole

//
// Argomenti: stringa con parole da unire, limite minimo lunghezza parola per essere coinvolta nello join, valore che indica se invertire i termini.
//
// Restituisce la stringa con le parole originali e quelle unite
//
char *joinText(string text, const size_t min_join_len, const bool inversion)
{

	size_t textlen = text.length();

	// rimuove eventuali spazi in coda
	while (text[textlen - 1] == ' ' && textlen > 0)
		textlen--;

	size_t preoldspaceoffset = 0;
	size_t oldspaceoffset = 0;
	size_t spaceoffset = 0;
	size_t count = 0;
	bool firststep = false;
	bool inversion_valid_arg = true;
	bool inversion_invalid_first_arg = false;
	size_t spacecount = 0;
	bool invalid_first_arg = false;
	bool invalid_second_arg = false;
	bool valid_pre_arg = false;
	size_t pretempoffset = 0;
	size_t oldtempoffset = 0;
	size_t joinsize = 0;

	// Una volta ottenuta la dimensione (joinsize), lo stesso algoritmo viene adoperato per scrivere nell'area puntata dal puntatore a caratteri joinedtext.
	while (count < textlen)
	{
		if (text[count] == ' ' || count == (textlen - 1))
		{
			spacecount++;

			if (spacecount == 1 && count < (textlen - 1) && count > (min_join_len + 1))
			{
				oldspaceoffset = size_t(0);
				spaceoffset = count;
			}
			else if (spacecount == 1 && count < (textlen - 1))
			{
				oldspaceoffset = size_t(0);
				spaceoffset = count;
			}

			if (spacecount > 1 && count < (textlen - 1))
			{
				preoldspaceoffset = oldspaceoffset;
				oldspaceoffset = spaceoffset;
				spaceoffset = count;

				if ((spaceoffset - (oldspaceoffset + 1)) < (min_join_len + 1))
					invalid_second_arg = true;

				size_t tempoffset = (preoldspaceoffset > 0) ? (preoldspaceoffset + 1): 0;

				if ((oldspaceoffset - tempoffset) < (min_join_len + 1))
				{
					invalid_first_arg = true;

					if (preoldspaceoffset == 0)
						invalid_second_arg = true;
				}

				firststep = true;
			}

			if (spacecount > 1 && count == (textlen - 1))
			{
				preoldspaceoffset = oldspaceoffset;
				oldspaceoffset = spaceoffset;
				spaceoffset = (count + 1);

				if ((spaceoffset - (oldspaceoffset + 1)) < (min_join_len + 1))
				{
					invalid_first_arg = true;
					invalid_second_arg = true;
				}

				size_t tempoffset = (preoldspaceoffset > 0) ? (preoldspaceoffset + 1): 0;

				if ((oldspaceoffset - tempoffset) < (min_join_len + 1))
					invalid_first_arg = true;

				firststep = true;
			}

			if (firststep == true)
			{
				if (invalid_first_arg == false && invalid_second_arg == false)
				{
					size_t tempoffset = (joinsize > 0 || (joinsize == 0 && spacecount == 2)) ? preoldspaceoffset : (preoldspaceoffset + 1);

					if (inversion == false)
					{
					for (unsigned i = tempoffset; i < oldspaceoffset; i++)
							joinsize++;

					for (unsigned i = (oldspaceoffset + 1); i < spaceoffset; i++)
							joinsize++;
					}
					else // effettua l'inversione dei termini
					{

						//if (inversion_valid_arg == false)
						if (joinsize > 0)
							joinsize++;

						for (unsigned i = (oldspaceoffset + 1); i < spaceoffset; i++)
							joinsize++;

						if (tempoffset == 0)
							for (unsigned i = tempoffset; i < oldspaceoffset; i++)
								joinsize++;
						else
							if (tempoffset == preoldspaceoffset)
								for (unsigned i = (tempoffset + 1); i < oldspaceoffset; i++)
									joinsize++;
							else
								for (unsigned i = tempoffset; i < oldspaceoffset; i++)
									joinsize++;

						inversion_valid_arg = false;
					}
				}
				else if (invalid_first_arg == true && invalid_second_arg == true)
				{
					invalid_first_arg = false;
					invalid_second_arg = false;
				}
				else if (invalid_first_arg == true)
				{
					if (inversion == false)
					{
					if (valid_pre_arg == true)
					{
						for (unsigned i = pretempoffset; i < oldtempoffset; i++)
							joinsize++;

						valid_pre_arg = false;
					}

					if (joinsize > 0)
						for (unsigned i = (oldspaceoffset + 1); i < spaceoffset; i++)
							joinsize++;
					}
					else // effettua l'inversione dei termini
					{
                                        	invalid_second_arg = false;

						if (joinsize > 0)
							joinsize++;

						if (joinsize > 0 || valid_pre_arg == true)
							for (unsigned i = (oldspaceoffset + 1); i < spaceoffset; i++)
								joinsize++;

						if (inversion_valid_arg == true && inversion_invalid_first_arg == false)
							for (unsigned i = pretempoffset; i < oldtempoffset; i++)
							{
								joinsize++;
								inversion_invalid_first_arg = true;
							}
						else
							for (unsigned i = (pretempoffset + 1); i < oldtempoffset; i++)
								joinsize++;

						valid_pre_arg = false;
					}
					invalid_first_arg = false;
				}
				else if (invalid_second_arg == true && count > 0)
				{
					pretempoffset = (joinsize > 0 || (joinsize == 0 && spacecount == 2)) ? preoldspaceoffset : (preoldspaceoffset + 1);
					oldtempoffset = oldspaceoffset;
					valid_pre_arg = true;
					invalid_second_arg = false;
				}
			}
		}
		count++;
	}

	char *joinedtext = (char *) malloc ((++joinsize) * sizeof(char)); // Problema calcolo allocazione memoria

	preoldspaceoffset = 0;
	oldspaceoffset = 0;
	spaceoffset = 0;
	count = 0;
	firststep = false;
	spacecount = 0;
	size_t suicount = 0;
	invalid_first_arg = false;
	invalid_second_arg = false;
	valid_pre_arg = false;
	inversion_valid_arg = true;
	inversion_invalid_first_arg = false;
	pretempoffset = 0;
	oldtempoffset = 0;

	// Una volta ottenuta la dimensione (joinsize), lo stesso algoritmo viene adoperato per scrivere nell'area puntata dal puntatore a caratteri joinedtext.
	while (count < textlen)
	{
		if (text[count] == ' ' || count == (textlen - 1))
		{
			spacecount++;

			if (spacecount == 1 && count < (textlen - 1) && count > (min_join_len + 1))
			{
				oldspaceoffset = size_t(0);
				spaceoffset = count;
			}
			else if (spacecount == 1 && count < (textlen - 1))
			{
				oldspaceoffset = size_t(0);
				spaceoffset = count;
			}

			if (spacecount > 1 && count < (textlen - 1))
			{
				preoldspaceoffset = oldspaceoffset;
				oldspaceoffset = spaceoffset;
				spaceoffset = count;

				if ((spaceoffset - (oldspaceoffset + 1)) < (min_join_len + 1))
					invalid_second_arg = true;

				size_t tempoffset = (preoldspaceoffset > 0) ? (preoldspaceoffset + 1): 0;

				if ((oldspaceoffset - tempoffset) < (min_join_len + 1))
				{
					invalid_first_arg = true;

					if (preoldspaceoffset == 0)
						invalid_second_arg = true;
				}

				firststep = true;
			}

			if (spacecount > 1 && count == (textlen - 1))
			{
				preoldspaceoffset = oldspaceoffset;
				oldspaceoffset = spaceoffset;
				spaceoffset = (count + 1);

				if ((spaceoffset - (oldspaceoffset + 1)) < (min_join_len + 1))
				{
					invalid_first_arg = true;
					invalid_second_arg = true;
				}

				size_t tempoffset = (preoldspaceoffset > 0) ? (preoldspaceoffset + 1): 0;

				if ((oldspaceoffset - tempoffset) < (min_join_len + 1))
					invalid_first_arg = true;

				firststep = true;
			}

			if (firststep == true)
			{
				if (invalid_first_arg == false && invalid_second_arg == false)
				{
					size_t tempoffset = (suicount > 0 || (suicount == 0 && spacecount == 2)) ? preoldspaceoffset : (preoldspaceoffset + 1);

					if (inversion == false)
					{
					for (unsigned i = tempoffset; i < oldspaceoffset; i++)
							joinedtext[suicount++] = text[i];

					for (unsigned i = (oldspaceoffset + 1); i < spaceoffset; i++)
							joinedtext[suicount++] = text[i];
					}
					else // effettua l'inversione dei termini
					{

						//if (inversion_valid_arg == false)
						if (suicount > 0)
						joinedtext[suicount++] = ' ';

						for (unsigned i = (oldspaceoffset + 1); i < spaceoffset; i++)
							joinedtext[suicount++] = text[i];

						if (tempoffset == 0)
							for (unsigned i = tempoffset; i < oldspaceoffset; i++)
								joinedtext[suicount++] = text[i];
						else
							if (tempoffset == preoldspaceoffset)
								for (unsigned i = (tempoffset + 1); i < oldspaceoffset; i++)
									joinedtext[suicount++] = text[i];
							else
								for (unsigned i = tempoffset; i < oldspaceoffset; i++)
									joinedtext[suicount++] = text[i];

						inversion_valid_arg = false;
					}
				}
				else if (invalid_first_arg == true && invalid_second_arg == true)
				{
					invalid_first_arg = false;
					invalid_second_arg = false;
				}
				else if (invalid_first_arg == true)
				{
					if (inversion == false)
					{
					if (valid_pre_arg == true)
					{
						for (unsigned i = pretempoffset; i < oldtempoffset; i++)
							joinedtext[suicount++] = text[i];

						valid_pre_arg = false;
					}

					if (suicount > 0)
						for (unsigned i = (oldspaceoffset + 1); i < spaceoffset; i++)
							joinedtext[suicount++] = text[i];
					}
					else // effettua l'inversione dei termini
					{
                                        	invalid_second_arg = false;

						if (suicount > 0)
							joinedtext[suicount++] = ' ';

						if (suicount > 0 || valid_pre_arg == true)
							for (unsigned i = (oldspaceoffset + 1); i < spaceoffset; i++)
								joinedtext[suicount++] = text[i];

						if (inversion_valid_arg == true && inversion_invalid_first_arg == false)
							for (unsigned i = pretempoffset; i < oldtempoffset; i++)
							{
								joinedtext[suicount++] = text[i];
								inversion_invalid_first_arg = true;
							}
						else
							for (unsigned i = (pretempoffset + 1); i < oldtempoffset; i++)
								joinedtext[suicount++] = text[i];

						valid_pre_arg = false;
					}
					invalid_first_arg = false;
				}
				else if (invalid_second_arg == true && count > 0)
				{
					pretempoffset = (suicount > 0 || (suicount == 0 && spacecount == 2)) ? preoldspaceoffset : (preoldspaceoffset + 1);
					oldtempoffset = oldspaceoffset;
					valid_pre_arg = true;
					invalid_second_arg = false;
				}
			}
		}
		count++;
	}
	joinedtext[suicount] = ASCII_NUL;

return joinedtext;
}

//
// Name: strInfixed
//
// Description: Algoritmo che estrae i termini infissi da una stringa (parola singola) verificando che il termine sia anche presente in pagetext

//
// Restituisce i termini infissi (non viene restituita la parola originale)
//
char *strInfixed(instance_t *instance, thematic_out_t *theminfo, string arg, char *_sensitives, const size_t &arglen, const size_t &min_infix_len, bool &reworkstruct_infitext)
{
size_t alen = 0;
size_t offset = 0;
size_t maxpos = 0;
size_t infix_len = (arglen - 1);
size_t infix_size = 0;
bool firstcheck = false;
size_t arraysize = 0;
size_t numwords = 0;
bool have_magic_words = false;

// Ottengo la massima dimensione idonea a contenere il massimo numero di termini infissi
// e ottengo anche la massima dimensione teorica dell'array che gestisce l'algoritmo della funzione
do
{
	infix_size += (arglen - infix_len + 1) * (infix_len + 1);
	arraysize++; 
}
while (infix_len-- > min_infix_len);

// Esce se non è possibile creare almeno due parole infisse.
if (arraysize < 2)
	return NULL;

// Struttura principale su cui lavora l'algoritmo
struct main_offsets
{
	bool to_join;
	size_t offstart; // contiene gli offset relativi alla posizione del primo carattere di ogni parola infixed ESISTENTE che si trova nella stringa da elaborare
	size_t offstop; // contiene gli offset relativi alla posizione dell'ultimo carattere di ogni parola infixed ESISTENTE che si trova nella stringa da elaborare
	size_t ma_length; // lunghezza del relativo termine completo nel caso si tratti di termine abbreviato
	char *sensitive_words;
} *o_struct = CBALLOC(main_offsets, MALLOC, (arraysize + 1));

for (unsigned short u = 0; u <= arraysize; u++)
{
 	o_struct[u].offstart = 0;
 	o_struct[u].offstop = 0;
 	o_struct[u].to_join = true;
 	o_struct[u].ma_length = true;
 	o_struct[u].sensitive_words = NULL;
}

infix_len = (arglen - 1);

// ciclo in cui è racchiuso l'algoritmo
do
{
	for (unsigned short i = 0; i < arglen; i++) // scansiona la parola fornita come argomento
	{
		size_t endinfix = (i + infix_len);

		bool go_ahead = true;

		// tag: se si desidera ridurre il numero dei cicli occorre lasciare abilitate le righe sottostanti (SOLO SE NON SI INTENDE UTILIZZARE to_join false)
		for (unsigned short u = 0; u < numwords; u++)
		{
		 	if ( i >= o_struct[u].offstart && i < o_struct[u].offstop )
				go_ahead = false;

		 	if ( endinfix > o_struct[u].offstart && endinfix <= o_struct[u].offstop )
				go_ahead = false;
		}
		// endtag
		//

		if (go_ahead == false || endinfix > arglen)
			continue;

		char *tempp = CBALLOC(char, CALLOC, arglen);

		for (unsigned short u = 0; u < infix_len; u++) // scansiona il termine infisso in modo da essere compiato sulla memoria puntata da tempp
		{
			// posizione della parola nella stringa arg
			if (u == 0)
				offset = (u + i);

			assert(alen < (arglen - 1));

			tempp[alen++] = arg[(u + i)];

			if (u == (infix_len - 1))
			{
				tempp[alen] = ASCII_NUL;

				termid_t termid = 0;

				istidx_status_t irc = istidx_resolve_word( tempidx, instance, tempp, &(termid), true );

				bool offset_found = false;
				bool to_join = true;
				size_t ma_length = 0;
				char *magicwords = NULL;

				// attenzione 'reworkstruct_infitext == true' confina ulteriormente il valore termid su determinati valori soglia (vedi readTerms)
				if (irc == ISTIDX_EXISTENT && (reworkstruct_infitext == false || (reworkstruct_infitext == true && termid >= terms_eohs_offset && termid < terms_split_offset[*instance])))
				{
//mcout << arg << " temp " << reworkstruct_infitext << ' '<< tempp << mendl;

					auto search = map_abbreviated.find(tempp);

					if (search != map_abbreviated.end())
					{
						size_t min_stemword_len = 3;

						if (_sensitives == NULL)
						{
							magicwords = saveSensitiveInfixed(theminfo, min_stemword_len, (char *)search->second.c_str());
	
							ma_length = strlen(magicwords);

							if (ma_length > 0)
								have_magic_words = true;
						}
						else
						{
							char *newsensitives = CBALLOC(char, MALLOC, ((search->second.size() * 2) + 1));
							char *str = CBALLOC(char, MALLOC, (search->second.size() + 1));
							char *pch = NULL;
							newsensitives[0] = ASCII_NUL;
							str[0] = ASCII_NUL;
							strcpy(str, (char *)search->second.c_str());
							pch = strtok (str," ");
							bool firststep = true;

							while (pch != NULL)
							{
								if (isInCharString(_sensitives, pch, false) == false)
								{
									if (firststep == true)
									{
										strcpy(newsensitives, pch);
										firststep = false;
									}
									else
										strcat(newsensitives, pch);
							
									strcat(newsensitives, " ");
								}
							
							    pch = strtok (NULL, " ");
							}

							if (strlen(newsensitives) > 0)
							{
								magicwords = saveSensitiveInfixed(theminfo, min_stemword_len, newsensitives);

								ma_length = strlen(magicwords);

								if (ma_length > 0)
									have_magic_words = true;
							}

							free(str);
							free(newsensitives);
						}
					}
				}

				for (unsigned short x = 0; x < numwords; x++)
				{
						if (offset == o_struct[x].offstart || (offset + alen) == o_struct[x].offstop)
							offset_found = true;

						if (offset > o_struct[x].offstart && (offset + alen) < o_struct[x].offstop)
							offset_found = true;

						for (unsigned short x = 0; x < numwords; x++)
						{
						//	if (offset > o_struct[x].offstart && offset < o_struct[x].offstop)
						//		to_join = false;
							if ((offset + alen) > o_struct[x].offstart && (offset + alen) < o_struct[x].offstop)
								to_join = false;
						}
				}

				if ((irc == ISTIDX_EXISTENT && offset_found == false) && (reworkstruct_infitext == false || (reworkstruct_infitext == true && termid >= terms_eohs_offset && termid < terms_split_offset[*instance])))
				{
//mcout << arg << " Temp " << reworkstruct_infitext << ' '<< tempp << '-' << termid << '-' << tempidx->term_count << mendl;

					// se si tratta di un termine *CENTRALE di lunghezza uguale o inferiore ai due caratteri
					// questi viene trattato come non joinabile
					//
					// * intendo dire che il termine non deve partire dal primo carattere o finire con l'ultimo della
					// stringa argomenti
					if (offset > 0 && alen < MIN_INFIX_LEN && (offset + alen) != arglen)
						to_join = false;

					if (offset > maxpos || (offset == (size_t)0 && maxpos == (size_t)0) )
					{
						//maxalen = offset + alen;
						maxpos = offset;
					}

					if (firstcheck == false)
					{
						firstcheck = true;
						//reallength += alen;

						if (offset != string::npos)
						{
							o_struct[0].offstart = offset;
							o_struct[0].offstop = (offset + alen);
							o_struct[0].ma_length = ma_length;

							if (ma_length > 0)
							{
								o_struct[0].sensitive_words = CBALLOC(char, MALLOC, (ma_length + 1));
								strcpy(o_struct[0].sensitive_words, magicwords);
							}
							else
								o_struct[0].sensitive_words = NULL;
							
						}

						numwords++;
					}
					else
					{
						//reallength += alen;

						if (offset != string::npos)
						{
							for (unsigned short z = numwords; z > 0; z--) // confronta ogni elemento di o_struct.offstart
							{
								if (z == 1)
								{
									if (offset > o_struct[(z - 1)].offstart)
									{
										o_struct[z].offstart = offset;
										o_struct[z].offstop = (offset + alen);
						 				o_struct[z].to_join = to_join;
										o_struct[z].ma_length = ma_length;

										if (ma_length > 0)
										{
											o_struct[z].sensitive_words = CBALLOC(char, MALLOC, (ma_length + 1));
											strcpy(o_struct[z].sensitive_words, magicwords);
										}
										else
											o_struct[z].sensitive_words = NULL;

										break;
									}

									if (offset < o_struct[(z - 1)].offstart)
									{
										o_struct[z].offstart = o_struct[(z - 1)].offstart;
										o_struct[z].offstop = o_struct[(z - 1)].offstop;
										o_struct[z].to_join = o_struct[(z - 1)].to_join;
										o_struct[z].ma_length = o_struct[(z - 1)].ma_length;
										o_struct[z].sensitive_words = o_struct[(z - 1)].sensitive_words;

										o_struct[0].offstart  = offset;
										o_struct[0].offstop = (offset + alen);
						 				o_struct[0].to_join = to_join;
										o_struct[0].ma_length = ma_length;

										if (ma_length > 0)
										{
											o_struct[0].sensitive_words = CBALLOC(char, MALLOC, (ma_length + 1));
											strcpy(o_struct[0].sensitive_words, magicwords);
										}
										else
											o_struct[0].sensitive_words = NULL;

										break;
									}
								}

								if (z > 1)
								{
									if (offset > o_struct[(z - 1)].offstart)
									{
										o_struct[z].offstart = offset;
										o_struct[z].offstop = (offset + alen);
						 				o_struct[z].to_join = to_join;
										o_struct[z].ma_length = ma_length;

										if (ma_length > 0)
										{
											o_struct[z].sensitive_words = CBALLOC(char, MALLOC, (ma_length + 1));
											strcpy(o_struct[z].sensitive_words, magicwords);
										}
										else
											o_struct[z].sensitive_words = NULL;

										break;
									}

									size_t tz = z;

									bool replaced = false;

									// libero la posizione dove collocare il valore di offset
									while (tz > 1 && offset < o_struct[(tz - 1)].offstart)
									{
										/*
										 * Debug purpose
										 *
										for (unszgned short u = 0; u < numwords; u++)
										 	cout << '-' << o_struct[u].offstart ;

										cout << endl << '-' << numwords << endl;
										*/
										o_struct[tz].offstart = o_struct[(tz - 1)].offstart;
										o_struct[tz].offstop = o_struct[(tz - 1)].offstop;
										o_struct[tz].to_join = o_struct[(tz - 1)].to_join;
										o_struct[tz].ma_length = o_struct[(tz - 1)].ma_length;
										o_struct[tz].sensitive_words = o_struct[(tz - 1)].sensitive_words;

										if (offset > o_struct[(tz - 2)].offstart)
										{
											o_struct[(tz - 1)].offstart = offset;
											o_struct[(tz - 1)].offstop = (offset + alen);
											o_struct[(tz - 1)].to_join = to_join;
											o_struct[(tz - 1)].ma_length = ma_length;

											if (ma_length > 0)
											{
												o_struct[(tz - 1)].sensitive_words = CBALLOC(char, MALLOC, (ma_length + 1));
												strcpy(o_struct[(tz - 1)].sensitive_words, magicwords);
											}
											else
												o_struct[(tz - 1)].sensitive_words = NULL;

											replaced = true;
										}
										
										tz--;
									}

									if (replaced == true)
										break;
								}
							}
						}

						numwords++;
					}
				}
				alen = 0;
				free (magicwords);
			}
		}
		free (tempp);
	}
}
while (infix_len-- > min_infix_len);

assert(numwords <= arraysize);

if (numwords == 0)
{
	free (o_struct);

	return NULL;
}

/*
 * debug purpose
 *
for (unsigned short u = 0; u < numwords; u++)
 	cout << '+' << o_struct[u].offstart ;
cout << endl;

for (unsigned short u = 0; u < numwords; u++)
 	cout << '+' << o_struct[u].offstop ;
cout << endl;

for (unsigned short u = 0; u < numwords; u++)
 	cout << '+' << o_struct[u].to_join ;
cout << endl;

for (unsigned short u = 0; u < numwords; u++)
 	cout << '+' << o_struct[u].ma_length ;
cout << endl;
*/

/*
// Essendo maggiore di MIN_INFIX_LEN il primo valore dell'o_struct[0].offstart significa che la funzione non è riuscita ad identificare una prima parola
// Viene creata euristicamente
// al termine dell'algoritmo possiamo cercare termini (a sinistra) più brevi del limite (ecco perchè (MIN_INFIX_LEN - 1))
if (o_struct[0].offstart > 1)
{
	// libero la posizione dove collocare il valore di offset
	for (unsigned short i = numwords; i > 0; i--)
	{
		o_struct[i].offstart = o_struct[(i - 1)].offstart;
		o_struct[i].offstop = o_struct[(i - 1)].offstop;
		o_struct[i].to_join = o_struct[(i - 1)].to_join;
	}

	o_struct[0].offstart = (size_t)0;
	o_struct[0].offstop = (o_struct[1].offstart);
	o_struct[0].to_join = true; // si può fare il join con altre parole

	numwords++;
}
// ... funzionalità opzionale
*/

/*
 * debug purpose
 *
o_struct[0].offstart = 0; o_struct[0].offstop = 4; o_struct[0].to_join = true;
o_struct[1].offstart = 2; o_struct[1].offstop = 15; o_struct[1].to_join = false;
o_struct[2].offstart = 9; o_struct[2].offstop = 22; o_struct[2].to_join = true;
o_struct[3].offstart = 15; o_struct[3].offstop = 20; o_struct[3].to_join = false;
o_struct[4].offstart = 30; o_struct[4].offstop = 35; o_struct[4].to_join = true;
o_struct[5].offstart = 35; o_struct[5].offstop = 40; o_struct[5].to_join = true;
o_struct[6].offstart = 40; o_struct[6].offstop = 45; o_struct[6].to_join = true;

numwords = 7;
*/

// Avendo riscontrato aree non identificate (ma che teoricamente possono comporre altre parole) in centro alla stringa significa che la funzione non è riuscita ad
// identificarle.
// Verranno identificate le aree 'joinabili' attraverso un calcolo euristico con attenzione tra 'incroci' parole joinabili e non.
// Una situazione di questo tipo capita quando una parola è teoricamente joinabile ma a causa della sua brave lunghezza o significato (vedi l'array excluded_terms)
// non viene indicata in o_struct[-].to_join come tale.
// 
// Di seguito una breve spiegazione su come il sistema funziona.
/*
 * Avendo un array di strutture del tipo o_struct come sotto:
 * 0--4--9--15-30-35-40 -> o_struct[-].offstart
 * 4--15-22-20-35-40-45 -> o_struct[-].offstop
 * 1--0--1--0--1--1--1  -> o_struct[-].to_join
 *
 * ne restituisce
 * 0--4--7--9--15-22-30-35-40 -> o_struct[-].offstart
 * 4--7--9--22-20-30-35-40-45 -> o_struct[-].offstop
 * 1--0--1--1--0--1--1--1--1  -> o_struct[-].to_join
 *       ? nota: dovrebbe partire da 4 per arrivare a 9 ma essendoci un 'incrocio' con un termine non joinabile parte dal termine di esso
 */

bool xfound = false;

//for (unsigned short i = (numwords - 1); i > 0; i--)
for (unsigned short i = (numwords - 1); i > 0; i--)
{
size_t x = 0;

unsigned short z;
xfound = false;

// Restituisce gli offset dove l'area non è stata definifita dalla funzione, in pratica restituisce le posizioni dove o_struct[-].offstart (z) non è uguale
// all'o_struct[x].offstart (x) successivo.
// N.B. I confronti vanno fatti solo tra confini 'joinabili' e cioè tutti gli offset devono avere o_struct[-].to_join 'true'.
	for (z = i; z > 0; z--)
	{
		if (o_struct[z].to_join == true)
		{
			for (x = (z - 1); x >= 0; x--)
			{
				if (o_struct[x].to_join == true)
				{
					if (o_struct[x].offstop == o_struct[z].offstart)
					{
						if (((o_struct[x].offstop - o_struct[x].offstart) < 2 && (o_struct[z].offstop - o_struct[z].offstart) < 3) || ((o_struct[z].offstop - o_struct[z].offstart) < 2 && (o_struct[x].offstop - o_struct[x].offstart) < 3)) // non vengono validati pattern del tipo: 'a b' oppure 'a bb' oppure 'b aa'
						{
							xfound = true;
							break;
						}
						else
							break;
					}
					else
					{
						xfound = true;
						break;
					}
				}
			}
			if (xfound == true)
				break;
		}
	}

	if (xfound == true)
		break;
/*
	// Verifica 'incroci' tra parole joinabili e non, del tipo: (sopra c'è l'esempio opposto)
	//
 	// * 0--7--12 -> o_struct[-].offstart
	// * 4--12-22 -> o_struct[-].offstop
	// * 1--0--1  -> o_struct[-].to_join
	// 
	// e le elabora in o_struct nel modo seguente:
 	// * 0--4--7--12 -> o_struct[-].offstart
	// * 4--7--12-22 -> o_struct[-].offstop
	// * 1--1--0--1  -> o_struct[-].to_join
	//
	size_t start = o_struct[x].offstop;
	size_t stop = o_struct[z].offstart;
	for (unsigned short p = (numwords - 1); p > 0; p--)
	{
		if (o_struct[p].offstart == o_struct[x].offstop && o_struct[p].offstop > o_struct[x].offstop && o_struct[p].offstop < o_struct[z].offstart)
			start = o_struct[p].offstop;

		if (o_struct[p].offstop == o_struct[z].offstart && o_struct[p].offstart < o_struct[z].offstart && o_struct[p].offstart > o_struct[x].offstop)
			stop = o_struct[p].offstart;
	}

	char temparr[MAX_INFIX_LEN];
	size_t tempoffset = 0;
	if (xfound == true)
		for (size_t os = start; os < o_struct[z].offstart; os++)
			temparr[tempoffset++] = arg[os];

	temparr[tempoffset] = ASCII_NUL;

	// se la parola si trova nell'array excluded_terms non viene elaborata
	if (isInCharString(pexcluded, temparr, false) == true)
		xfound = false;
	// fine verifica incroci.

	if (xfound == true && x < numwords && o_struct[i].to_join == true && (o_struct[x].offstop + min_infix_len) < o_struct[z].offstart)
	{
		size_t offset = 0;
		size_t value = stop;

		for (unsigned short c = (numwords - 1); c > 0; c--)
		{
			if (o_struct[x].offstop < o_struct[c].offstart)
			{
				o_struct[(c + 1)].offstart = o_struct[c].offstart;
				o_struct[(c + 1)].offstop = o_struct[c].offstop;
				o_struct[(c + 1)].to_join = o_struct[c].to_join;
				offset = c;
			}
		}

		numwords++;

		//o_struct[offset].offstart = o_struct[x].offstop;
		o_struct[offset].offstart = start;
		o_struct[offset].offstop = value;
		o_struct[offset].to_join = true; // si può fare il join con altre parole

	}
*/
}
// ... funzionalità opzionale

/*
// Avendo identificato l'ultimo offset di termine parola inferiore di MIN_INFIX_LEN la lunghezza della stringa, significa che la funzione
// non è riuscita ad identificare una ultima parola
// Viene creata euristicamente
unsigned short tpos = 0;
for (unsigned short u = 0; u < numwords; u++)
	if (o_struct[u].to_join == true)
		tpos = u;

if (o_struct[tpos].offstop < (arglen - 1))
{
	for (unsigned short i = numwords; i > tpos; i--) // confronta ogni elemento di o_struct.offstart
	{
		size_t ti = i;
		// libero la posizione dove collocare il valore di offset
		while (ti > tpos)
		{
*/			/*
			 * Debug purpose
			 *
			for (unsigned short u = 0; u < numwords; u++)
			 	cout << '-' << o_struct[u].offstart ;
	
			cout << endl << '-' << numwords << endl;
			*/
/*			o_struct[ti].offstart = o_struct[(ti - 1)].offstart;
			o_struct[ti].offstop = o_struct[(ti - 1)].offstop;
			o_struct[ti].to_join = o_struct[(ti - 1)].to_join;
	
			if (ti == (tpos + 1))
			{
				o_struct[(ti)].offstart = o_struct[tpos].offstop;
				o_struct[(ti)].offstop = arglen;
				o_struct[(ti - 1)].to_join = true;
			}

			ti--;
		}
	}
	numwords++;
}
// ... funzionalità opzionale
*/
// determina la qualità dei termini infissi

// se i termini infissi sono consecutivi, occupano tutta la stringa arg e l'ultimo termine infisso non è un solo carattere e il rapporto lunghezza stringa/numero termini infissi è superiore o uguale a ICONSTANT
if (xfound == false && numwords > 1 && o_struct[0].offstart == 0 &&  o_struct[(numwords - 1)].offstop == arg.length() && (o_struct[(numwords - 1)].offstop - o_struct[(numwords - 1)].offstart > 1) && ((double)(arg.length()) / (double)numwords) >= ICONSTANT)
	info[*instance].iq = numwords;
else
{
	info[*instance].iq = 0;

	//liberiamo o_struct e i puntatori interni...
	for (unsigned short u = 0; u <= numwords; u++)
		if (o_struct[u].sensitive_words != NULL)
	 		free (o_struct[u].sensitive_words);

	free (o_struct);

	return NULL;
}

/*
 * debug purpose
 *
for (unsigned short u = 0; u < numwords; u++)
 	cout << '-' << o_struct[u].offstart ;
cout << endl;

for (unsigned short u = 0; u < numwords; u++)
 	cout << '-' << o_struct[u].offstop ;
cout << endl;

for (unsigned short u = 0; u < numwords; u++)
 	cout << '-' << o_struct[u].to_join ;
cout << endl;
*/

size_t infixcountsize = 0;
size_t sensitivecountsize = 0;
char *infixed = NULL;
char *sensitives = NULL;

// Calcolo dello spazio di memoria necessario le parole infixed 'joinabili'.
for (unsigned short i = 0; i <= numwords; i++)
{
	if (o_struct[i].to_join == true)
			infixcountsize += ((o_struct[i].offstop - o_struct[i].offstart) + 1);
	if (o_struct[i].to_join == true && o_struct[i].ma_length > 0)
			infixcountsize += (((o_struct[i].offstop - o_struct[i].offstart) + 1) + (o_struct[i].ma_length + 1));
}

// Calcolo dello spazio di memoria necessario le parole sensibili (magicwords)
// da aggiungere in seguito (separati da un punto) al alla stringa degli infissi
if (have_magic_words == true)
	for (unsigned short i = 0; i <= numwords; i++)
		if (o_struct[i].to_join == true && o_struct[i].ma_length > 0)
			sensitivecountsize += ((o_struct[i].ma_length + 1));

infixed = CBALLOC(char, MALLOC, ((_sensitives == NULL ? infixcountsize : (infixcountsize + strlen(_sensitives + 1))) + 1));

if (have_magic_words == true)
{
	sensitives = CBALLOC(char, MALLOC, (sensitivecountsize + 1));
	sensitives[0] = ASCII_NUL;
}

infixed[0] = ASCII_NUL;

bool ifirststep = true;
bool sfirststep = true;

for (unsigned short i = 0; i < numwords; i++)
{
	if (o_struct[i].to_join == true)
	{
		char *pword = printWord(arg, o_struct[i].offstart, o_struct[i].offstop, false);

		if (ifirststep == true)
		{
			strcpy(infixed, pword);
			ifirststep = false;
		}
		else
		{
			strcat(infixed, " ");
			strcat(infixed, pword);	
		}
	
		free (pword);
	}

	if (o_struct[i].to_join == true && o_struct[i].ma_length > 0)
	{
		if (sfirststep == true)
		{
			strcpy(sensitives, ":");
			strcat(sensitives, o_struct[i].sensitive_words);	
			sfirststep = false;
		}
		else
		{
			strcat(sensitives, " ");
			strcat(sensitives, o_struct[i].sensitive_words);	
		}
	}
}

//liberiamo o_struct e i puntatori interni...
for (unsigned short u = 0; u <= numwords; u++)
	if (o_struct[u].sensitive_words != NULL)
 		free (o_struct[u].sensitive_words);

free (o_struct);

if (have_magic_words == false)
{
	if (_sensitives != NULL)
	{
		strcat(infixed, ":");
		strcat(infixed, _sensitives);
	}
}
else
{
	strcat(infixed, sensitives);

	if (_sensitives != NULL)
	{
		strcat(infixed, " ");
		strcat(infixed, _sensitives);
//mcout << '|' << infixed << '|' << endl;
//sleep(5);
//cout << mendl;
	}
//mcout << '|' << infixed << '|' << sensitives << '|' << endl;
//sleep(5);
//cout << mendl;
}

// normalmente iq è uguale a numwords ma SE si riscontrano termini in 'map_abbreviated' per avere un iq REALE contiamo i termini infissi
if (have_magic_words == true)
{
	info[*instance].iq = wordCounter(infixed, 1);
	free(sensitives);
}

return infixed;
}

//
// Name: totalInfixed
//
// Description: estrae i termini infissi da una stringa composta da tante parole
//
// Restituisce i termini infissi da ogni parola della stringa (non vengono restituite dal processo le parole originali)
//
char *totalInfixed(instance_t *instance, thematic_out_t *theminfo, string str, bool &is_master_domain, pes_t *poutt, size_t &content_length, doc_t *doc, char sitename[MAX_DOMAIN_LEN], depth_t &slashes, bool &insert)
{
// Gestione avanzata termini infissi dei domini.
// Nel berkeleyDB viene salvato come chiave il nome di dominio, altrimenti il nome di dominio viene preceduto da un punto!
// N.B. se il nome di dominio ad esempio è 'cittalibera.oristano.it' e essendo 'oristano' (.it) un dominio geografico in berkeleyDB i termini infissi verrebbero
// salvati nel seguente modo:
// Chiave: .cittalibera.oristano.it	Valore: 2 citta libera
// oppure:
// N.B. se il nome di dominio ad esempio è 'cittalibera.pertutti.oristanodavivere.it' i termini infissi verrebbero salvati nel seguente modo:
// Chiave: cittalibera.pertutti.oristanodavivere.it	Valore: 3 oristano da vivere
// Chiave: .cittalibera.pertutti.oristanodavivere.it	Valore: 4 citta libera per tutti
// Il database risulta avere più chiavi (e dunque essere più grande) ma quanti sono i domini con più livelli superiore al secondo dove si riesce a ricavare
// termini infissi in entrambi??? :-)
//
	char site[MAX_DOMAIN_LEN + 1];

	if (is_master_domain == false)
	{
		site[0] = ASCII_DT;
		site[1] = ASCII_NUL;
		strcat(site, sitename);
	}
	else
		strcpy(site,sitename);

	// in caso di update i termini infissi vengono esclusivamente prelevati dal server cbot-infix-d
	if (insert == false)
	{
		unsigned short iq = 0;
		return ifxResolver(iq, site, NULL);
	}

	char *infitext = (char *) malloc (MAX_STR_LEN * sizeof(char));

	char *more_infitext = NULL;
	size_t infitextsize = 0;
	bool infix_found = false;
	bool firstcheck = true;
	bool reworkstruct_infitext = false; // scompone ulteriormente (nel caso sia possibile) i termini infissi
	iq_t force_iq = 0; // è il valore di iq che viene assegnato alla fine dell'analisi di tutti i nomi che compongono un dominio

	char *temppointer = (char *) malloc ((MAX_INFIX_LEN + 1) * sizeof(char));

	temppointer[0] = ASCII_NUL;
	infitext[0] = ASCII_NUL;

	const size_t min_word_len = 3;

	if (slashes == 2 || info[*instance].isvirtualhomepage == true) // potrebbe trattarsi di una homepage reale o virtuale (rilevata da urlWords)
	{
		size_t fulltextsize = (KEYWSIZE + 1 + TITLESIZE + 1 + DESCSIZE + 1 + content_length); // esaminare poutt->content oltre ad occupare
		// molte risorse di sistema può generare un maggior numero di falsi positivi.
		char *fulltext = (char *) malloc ((fulltextsize + 1) * sizeof(char));
		fulltext[0] = ASCII_NUL;
		strcpy (fulltext, poutt->metakeyw);
		strcat (fulltext, " ");
		strcat (fulltext, poutt->title);
		strcat (fulltext, " ");
		strcat (fulltext, poutt->metadesc);

		// Inizio popolamento parole, indice temporaneo
		readTerms (instance, min_word_len, fulltext, poutt->content);
		free (fulltext);
	}
	else
	{
		size_t fulltextsize = (KEYWSIZE + 1 + TITLESIZE + 1 + DESCSIZE);
		char *fulltext = (char *) malloc ((fulltextsize + 1) * sizeof(char));
		fulltext[0] = ASCII_NUL;
		strcpy (fulltext, poutt->metakeyw);
		strcat (fulltext, " ");
		strcat (fulltext, poutt->title);
		strcat (fulltext, " ");
		strcat (fulltext, poutt->metadesc);

		// Inizio popolamento parole, indice temporaneo
		readTerms (instance, min_word_len, fulltext, NULL);
		free (fulltext);
	}

	keyid_t keyid = 0;

	ifxddx_status_t krc = ifxddx_resolve_key( ifxddx, site, &(keyid), true );

	char *sensitives = NULL;

	if (krc == IFXDDX_EXISTENT)
	{
		char *infixed = ifxddx_read_infix(ifxddx, keyid, false);
		char *pch = strchr(infixed, ':');

		if (pch != NULL)
		{
			sensitives = CBALLOC(char, MALLOC, strlen(pch));
			pch++;

			strcpy(sensitives, pch);
		}

		free(infixed);
	}

	reworkstruct_infitext:

	unsigned short pos = 0;
	if (str.length() > (MIN_INFIX_LEN * 2)) // la lunghezza minima deve poter contenere almeno 2 termini infissi
	{
		for (unsigned short i = 0; i < str.length(); i++)
		{
			if (isalpha(str[i]) && pos < MAX_INFIX_LEN)
				temppointer[pos++] = str[i];
			else if (isalpha(str[i]) || i == (str.length() - 1))
			{
				temppointer[0] = ASCII_NUL; // nel caso la parola abbia caratteri oltre il 32esimo il contenuto puntato viene annullato, dunque non elaborato.
				pos = 0;
			}
			else
			{
				temppointer[pos] = ASCII_NUL;

				if (pos > MIN_INFIX_LEN)
				{
					char *out = strInfixed(instance, theminfo, temppointer, sensitives, pos, MIN_INFIX_LEN, reworkstruct_infitext);

					//cout << "IQ " << iq << endl;

					if (out != NULL)
					{
						if (info[*instance].iq > 0 && force_iq != USHRT_MAX)
							force_iq += info[*instance].iq;
						else
							force_iq = USHRT_MAX;

						infitextsize += strlen(out);
						infitextsize++; // occorre considerare spazio aggiuntivo eventuali altri termini infissi

						if (infitextsize > MAX_STR_LEN)
						{
						// Inizio processo assegnazione memoria al puntatore 'infitext' ...
						unsigned short err_count = 0;
						unsigned short max_realloc = 5;

							do
							{
								err_count++;
								assert(infitextsize > 0);
								more_infitext = (char*) realloc (infitext, (infitextsize + 1) * sizeof(char));

								if (more_infitext == NULL && err_count > max_realloc)
								{
									free (out);
									free (infitext);
									free (temppointer);
									mcerr << "Error (re)allocating memory for " << err_count << " times." << mendl;
									return NULL;
								}
							}
							while (more_infitext == NULL);
							// ... fine processo assegnazione memoria puntatore 'infitext'

							infitext=more_infitext;
						}

						if (firstcheck == true && reworkstruct_infitext == false)
						{
							strcpy(infitext, out);
							firstcheck = false;
						}
						else
							strcat(infitext, out);

						infix_found = true;
						free (out);
					}
				}

				// resetto i dati puntati da temppointer per sicurezza
				memset(temppointer,ASCII_NUL,(MAX_INFIX_LEN));
				pos = 0;
			}

			if (str[i] == ' ' && infix_found == true)
			{
				infix_found = false;
				strcat(infitext, " ");
			}
		}
	}
	else
	{
		free (infitext);
		free (temppointer);
		return NULL;
	}

	temppointer[pos] = ASCII_NUL;
	
	if (pos > MIN_INFIX_LEN && pos < (MAX_INFIX_LEN + 1))
	{
		char *out = strInfixed(instance, theminfo, temppointer, sensitives, pos, MIN_INFIX_LEN, reworkstruct_infitext);

		if (out != NULL)
		{
			if (info[*instance].iq > 0 && force_iq != USHRT_MAX)
				force_iq += info[*instance].iq;
			else
				force_iq = USHRT_MAX;

			size_t checksize = infitextsize;
			infitextsize += strlen(out);
			infitextsize++;

			if (infitextsize > MAX_STR_LEN)
			{
			// Inizio processo assegnazione memoria al puntatore 'infitext' ...
			unsigned short err_count = 0;
			unsigned short max_realloc = 5;

				do
				{
					err_count++;
					assert(infitextsize > 0);
					more_infitext = (char*) realloc (infitext, (infitextsize + 1) * sizeof(char));

					if (more_infitext == NULL && err_count > max_realloc)
					{
						free (out);
						free (infitext);
						free (temppointer);
						mcerr << "Error (re)allocating memory for " << err_count << " times." << mendl;
						return NULL;
					}
				}
				while (more_infitext == NULL);
				// ... fine processo assegnazione memoria puntatore 'infitext'

				infitext=more_infitext;
			}

			if (checksize == 0 && reworkstruct_infitext == false)
				strcpy(infitext, out);
			else
				strcat(infitext, out);

			free (out);
		}
	}

	// Si controlla se ci sono termini infissi che possono esse scomposti ulteriolmente
	if (reworkstruct_infitext == false && infitextsize > (MIN_INFIX_LEN * 2) && (infitextsize + MIN_INFIX_LEN + 1) < MAX_STR_LEN)
	{
		reworkstruct_infitext = true;
		str.assign(infitext,(infitextsize - 1));
		infitextsize++;
		strcat(infitext," ");
		goto reworkstruct_infitext;
	}

	if (sensitives != NULL)
		free(sensitives);

	if (more_infitext == NULL)
		free (more_infitext);
	free (temppointer);

	info[*instance].iq = 0; // di default la qualità del termine infisso deve essere nulla

	if (force_iq == USHRT_MAX)
		info[*instance].iq = 0;
	else
		info[*instance].iq = force_iq;

	return ifxResolver(info[*instance].iq, site, infitext);
}

//
// Name: wordCounter 
//
// Description: conta il numero di parole 'utili' nella stringa fornita come argomento, queste possono essere discriminate per lunghezza o per significato
//
// Argomenti: stringa con parole da esaminare, limite minimo lunghezza parola da elaborare.
//
// Restituisce il numero di parole 'importanti nella stringa fornita come argomento'
//
short wordCounter(char *ptext, const size_t min_word_len)
{

	short wc = 0;

	// Struttura principale su cui lavora l'algoritmo
	struct words_offsets
	{
		size_t offstart; // contiene gli offset relativi alla posizione del primo carattere di ogni parola
		size_t offstop; // contiene gli offset relativi alla posizione dell'ultimo carattere di ogni parola
	} *o_struct;

	//size_t ptextlen = ptext.length();
	size_t ptextlen = strlen(ptext);


//	char *ptext = (char *) malloc ((ptextlen + 1)* sizeof(char));
//	strcpy(ptext, ptext.c_str());

	// rimuove eventuali spazi in coda
	while (ptext[ptextlen - 1] == ' ' && ptextlen > 0)
		ptextlen--;

	size_t pos = 0;
	size_t toffstart = 0;
	size_t toffstop = 0;
	bool found = false;
	bool single_char = false;

	if (! (((int)ptextlen - (int)min_word_len) >= 0))
		return 0;

	// Calcolo lo spazio massimo teorico necessario per la struttura degli offset (o_struct)
	do
	{
		while ((isalpha(ptext[pos]) || convSpecialChar(ptext, ptextlen, pos) != ' ') && pos < ptextlen)
		{

			if (convSpecialChar(ptext, ptextlen, pos) != ' ')
				pos += 2;
			else
				pos++;

			found = true;
		}
	
		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(ptext[pos]) == false) && isalpha(ptext[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(ptext[pos]) == false) && convSpecialChar(ptext, ptextlen, pos) == ' '))
					toffstop = (pos - 1);
				else if (pos == (ptextlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			char *pword = printWord(ptext, toffstart, (toffstop + 1), true);

			size_t reallength = strlen(pword); // nel caso il termine originale contiene lettere 'conosciute' accentate la lunghezza di pword è minore

			if (reallength > min_word_len && reallength < MAX_WORD_LEN)
				wc++;

			free (pword);
		}

		bool testspecial = false;

		while ((isalpha(ptext[pos]) == false) && pos < (ptextlen - min_word_len))
			if (ptext[pos] != ' ' && (convSpecialChar(ptext, ptextlen, pos) != ' '))
			{
				testspecial = true;
				pos--;
				break;
			}
			else
				pos++;

		if (testspecial == true)
			toffstart = pos + 1;
		else
			toffstart = pos;

		found = false;
		single_char = false;

	}
	while (pos++ < (ptextlen - min_word_len));

	// Alloca la memoria per la struttura degli offset in questo caso utili per riscontrare parole duplicate
	o_struct = (words_offsets *) malloc (wc * sizeof(words_offsets));

	wc = 0;
	pos = 0;
	toffstart = 0;
	toffstop = 0;
	found = false;
	single_char = false;

	do
	{
		while ((isalpha(ptext[pos]) || convSpecialChar(ptext, ptextlen, pos) != ' ') && pos < ptextlen)
		{
			if (convSpecialChar(ptext, ptextlen, pos) != ' ')
				pos += 2;
			else
				pos++;

			found = true;
		}

		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(ptext[pos]) == false) && isalpha(ptext[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(ptext[pos]) == false) && convSpecialChar(ptext, ptextlen, pos) == ' '))
					toffstop = (pos - 1);
				else if (pos == (ptextlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			char *pword = printWord(ptext, toffstart, (toffstop + 1), true);

			size_t reallength = strlen(pword); // nel caso il termine originale contiene lettere 'conosciute' accentate la lunghezza di pword è minore

			// controlla che la parola da inserire non sia già presente nella struttura degli offset (o_struct)
			if (wc > 0 && reallength == ((toffstop + 1) - toffstart))
			for (unsigned short i = 0; i < wc; i++)
				{
					char *ptempword = printWord(ptext, o_struct[i].offstart, (o_struct[i].offstop + 1), true);

					if (reallength == strlen(ptempword) && strstr(pword,ptempword) != NULL && reallength < ((o_struct[i].offstop + 1) - o_struct[i].offstart))
					{
						o_struct[i].offstart = toffstart;
						o_struct[i].offstop  = toffstop;
						found = false;
					}
					else if (reallength == strlen(ptempword) && strstr(pword,ptempword) != NULL)
						found = false;

					free (ptempword);
				}

			if (found == true)
				if (reallength > min_word_len && reallength < MAX_WORD_LEN)
				{
					for (unsigned short i = 0; i < wc; i++)
					{
						char *ptempword = printWord(ptext, o_struct[i].offstart, (o_struct[i].offstop + 1), true);

						if (reallength == strlen(ptempword) && strstr(pword,ptempword) != NULL)
							found = false;

						free (ptempword);
					}
					
					if (found == true)
					{
						o_struct[wc].offstart = toffstart;
						o_struct[wc].offstop  = toffstop;
						wc++;
					}
				}

			free (pword);
		}

		bool testspecial = false;

		while ((isalpha(ptext[pos]) == false) && pos < (ptextlen - min_word_len))
			if (ptext[pos] != ' ' && (convSpecialChar(ptext, ptextlen, pos) != ' '))
			{
				testspecial = true;
				pos--;
				break;
			}
			else
				pos++;

		if (testspecial == true)
			toffstart = pos + 1;
		else
			toffstart = pos;

		found = false;
		single_char = false;
	}
	while (pos++ < (ptextlen - min_word_len));

	free (o_struct);

return wc;
}

//
// Name: saveSensitiveInfixed 
//
// Description: Analizza i termini abbreviati prende in considerazione le parole corrispondenti (normalword) solo se presenti
// nel testo principale della pagina (pagetext)

//
// Argomenti: lunghezza minima parola da elaborare con gli argomenti successivi che sono il testo da elaborare
//
// Restituisce il puntatore relativo alle parole sensibili
//
char *saveSensitiveInfixed(thematic_out_t *theminfo, const size_t min_word_len, char *normalword)
{
	char *sensitive = CBALLOC(char, MALLOC, ((KEYWSIZE/2) + 1));

	sensitive[0] = ASCII_NUL;

	size_t sensitivesize = 0;

	bool firstcheck = true;

	size_t textlen = strlen(normalword);

	if (textlen == 0)
		return sensitive;

	// rimuove eventuali spazi in coda
	while (normalword[textlen - 1] == ' ' && textlen > 0)
		textlen--;

	size_t pos = 0;
	size_t toffstart = 0;
	size_t toffstop = 0;
	bool found = false;
	bool single_char = false;

	if (((int)textlen - (int)min_word_len) >= 0)
	do
	{
		while ((isalpha(normalword[pos]) || convSpecialChar(normalword, textlen, pos) != ' ') && pos < textlen)
		{
			if (convSpecialChar(normalword, textlen, pos) != ' ')
				pos += 2;
			else
				pos++;

			found = true;
		}

		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(normalword[pos]) == false) && isalpha(normalword[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(normalword[pos]) == false) && convSpecialChar(normalword, textlen, pos) == ' '))
					toffstop = (pos - 1);
				else if (pos == (textlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			char *pword = printWord(normalword, toffstart, (toffstop + 1), true);

			size_t reallength = strlen(pword); // nel caso il termine originale contiene lettere 'conosciute' accentate la lunghezza di pword è minore

			// se le condizioni lo permettono estraiamo lo stemming dalla parola
			if (reallength > min_word_len && reallength < MAX_WORD_LEN && checkpwu(pword, dictionary_url, row_dictionary_url, rowuindex ) == false)
			{
				char *stemming = th.doStemming(theminfo, pword, reallength, (reallength + 1));

				duplid_t duplid = 0;

				// salva le parole le keywords sensibili...
				if (((sensitivesize + 1 + reallength) < (KEYWSIZE/2)) && isInCharString((char *)excluded_stemm, pword, false) == false)
				{
					if (th.themidx_resolve_dupl(theminfo, NULL, (char *)stemming, &(duplid), true ) == THEMIDX_EXISTENT && isInCharString(sensitive, pword, false) == false)
					{
						char *original = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));

						th.themidx_dupl_by_duplid(theminfo, duplid, original);

						size_t olen = strlen(original);

						if (firstcheck == true)
						{
							strcpy(sensitive, original);
							sensitivesize = olen;
							firstcheck = false;
						}
						else
						{
							if (isInCharString(sensitive, original, false) == false)
							{
								strcat(sensitive, " ");
								sensitivesize += ((size_t)1 + olen);
								strcat(sensitive, original);
							}
						}

						//cout << '-' << (char *)stemmed << '-' << pword << '-' << sb_stemmer_length(stemmer) << endl;
						free (original);
					}
				}

				free (stemming);
			}

			free (pword);
		}

		bool testspecial = false;

		while ((isalpha(normalword[pos]) == false) && pos < (textlen - min_word_len))
			if (normalword[pos] != ' ' && (convSpecialChar(normalword, textlen, pos) != ' '))
			{
				testspecial = true;
				pos--;
				break;
			}
			else
				pos++;

		if (testspecial == true)
			toffstart = pos + 1;
		else
			toffstart = pos;

		found = false;
		single_char = false;

	}
	while (pos++ < (textlen - min_word_len));

	return sensitive;
}

//
// Descrizione: Si occupa salvare eventuali termini infissi di un dominio, aggiornare eventualmente quelli già esistenti
// relativi allo stesso dominio o ricercare i relativi termini infissi di dominio
//
// Argomenti:
// 	- il quozionte iq (infix quality)
// 	- il nome dominio
// 	- i termini infissi (puntatore a NULL in caso di ricerca)
//
// Restituisce: puntatore a termini infissi
//
char *ifxResolver(iq_t &iq, char *site, char *suggested_infix)
{
	keyid_t keyid = 0;

	ifxddx_status_t krc = IFXDDX_ERROR;

	if (iq == (iq_t)0)
	{
		krc = ifxddx_resolve_key( ifxddx, site, &(keyid), true );

		if (krc == IFXDDX_NOT_FOUND)
		{
			free(suggested_infix);
			return NULL;
		}
	}
	else
		krc = ifxddx_resolve_key( ifxddx, site, &(keyid), false );

	if (krc == IFXDDX_ERROR)
	{
		free(suggested_infix);
		return NULL;
	}

	if (iq == 0 || suggested_infix == NULL)
	{
		free(suggested_infix);
		return ifxddx_read_infix(ifxddx, keyid, true);
	}

	if (krc == IFXDDX_CREATED_KEY)
	{
		if (ifxddx_write_infix(ifxddx, keyid, suggested_infix, iq))
			return suggested_infix;
		else
			die("Error: bad write infixed for site %s (keyid %lu) and infixed %s", site, keyid, suggested_infix);
	}
	else if (krc == IFXDDX_EXISTENT)
	{
		if (ifxddx_update_infix(ifxddx, keyid, suggested_infix, iq))
		{
			free(suggested_infix);
			return NULL;
		}
		else
		{
			if (suggested_infix == NULL)
				die("Error: bad update infixed for site %s (keyid %lu) and infixed %s", site, keyid, suggested_infix);
				
			free(suggested_infix);
			return ifxddx_read_infix(ifxddx, keyid, true);
		}
	}

	free(suggested_infix);

	return NULL;
}

//
// Name: domainCleared
//
// Description: Separa il dominio in due stringhe comprensive di termini infissi. domainscleared->clevel_domain è il dominio di priorità più alta

//
// Argomenti: puntatore a struttura tipo sb_stemmer, lunghezza minima parola da elaborare con gli argomenti successivi che sono il testo da elaborare (o escludere)
//
// Restituisce una struttura di tipo ... con domainscleared->clevel_domain che è il dominio di secondo livello con importanza più alta e
// domainscleared->olevels_domain che sono i livelli di livello superiore ma con importanza più bassa
domainscleared_t *domainCleared(instance_t *instance, thematic_out_t *theminfo, pes_t *poutt, size_t &content_length, doc_t *doc, char site[MAX_DOMAIN_LEN], depth_t &slashes, bool &insert)
{
	bool is_master_domain = true;

	domainscleared_t *domainscleared = (domainscleared_t *) malloc (sizeof(domainscleared_t));

	domainscleared->geo_domain = NULL;
	domainscleared->clevel_domain = NULL;
	domainscleared->olevels_domain = NULL;

	info[*instance].domain_dotcount = 0;

	//const char *test = "xn--tot-ena.xn--tot-ena.it"; ////////////////////////////////////////////////////
	//const char *test = "xn--tot-ena.xn--tot-ena.or.it"; ////////////////////////////////////////////////////
	//const char *test = "xn--tot-ena.allai.or.it"; ////////////////////////////////////////////////////
	//const char *test = "prova.xn--tot-ena.or.it"; ////////////////////////////////////////////////////
	//const char *test = "prova.xn--tot-ena.or.it"; ////////////////////////////////////////////////////
	//const char *test = "prova.itisothoca.gov.it";
	//const char *test = "292.it";
	//const char *test = "2.92.it"; // questo è interpretato geo domain perchè la lunghezza di 92 è uguale a 2 (anche se come dominio geografico non è valido) 

	// rendo il nome del sito pulito da dominio di primo livello, eventuale 'www.' ecc.. (vedere funzione splitSite)
	char *domainclearedtotal = splitSite(instance, site);

	if(strlen(domainclearedtotal) == 0) // Niente da elaborare
	{
		domainscleared->clevel_domain = new char [1];
		assert(domainscleared->clevel_domain != NULL);
		domainscleared->clevel_domain[0] = ASCII_NUL;
		domainscleared->olevels_domain = new char [1];
		assert(domainscleared->olevels_domain != NULL);
		domainscleared->olevels_domain[0] = ASCII_NUL;
		domainscleared->geo_domain = new char [1];
		assert(domainscleared->geo_domain != NULL);
		domainscleared->geo_domain[0] = ASCII_NUL;
		free(domainclearedtotal);
		return domainscleared;
	}

	char *domaincleared = NULL;
	char *domaincleared_olevels = NULL;
	char *domaincleared_geo = NULL;

//	size_t dctlen = strlen(domainclearedtotal);

	if (info[*instance].domain_dotcount == 2) // trattasi sicuramente di dominio geografico italiano
	{			  // più complesso da elaborare
		char *pus = NULL;
		char *pdot = NULL;
		size_t len = 0;

		if (domainclearedtotal[0] == ASCII_DT)
		{
			pus = strchr(domainclearedtotal, ASCII_US);

			len = (pus - domainclearedtotal - 1);
			domaincleared = new char [(len + 1)];
			assert(domaincleared != NULL);
			memcpy(domaincleared, &(domainclearedtotal[1]), len);
			domaincleared[len] = ASCII_NUL;

			if (len == 0)
			{
				domainscleared->clevel_domain = new char [1];
				assert(domainscleared->clevel_domain != NULL);
				domainscleared->clevel_domain[0] = ASCII_NUL;
			}

			len = strlen(&(pus[1]));
			domaincleared_geo = new char [(len + 1)];
			assert(domaincleared_geo != NULL);
			memcpy(domaincleared_geo, &(pus[1]), len);
			domaincleared_geo[len] = ASCII_NUL;

			domaincleared_olevels = new char [1];
			assert(domaincleared_olevels != NULL);
			domaincleared_olevels[0] = ASCII_NUL;

			domainscleared->olevels_domain = new char [1];
			assert(domainscleared->olevels_domain != NULL);
			domainscleared->olevels_domain[0] = ASCII_NUL;
		}
		else
		{
			pdot = strchr(domainclearedtotal, ASCII_DT);
			len = (pdot - domainclearedtotal);

			domaincleared_olevels = new char [(len + 1)];
			assert(domaincleared_olevels != NULL);
			memcpy(domaincleared_olevels, domainclearedtotal, len);
			domaincleared_olevels[len] = ASCII_NUL;

			pus = strchr(domainclearedtotal, ASCII_US);

			len = (pus - domainclearedtotal - len - 1);
			domaincleared = new char [(len + 1)];
			assert(domaincleared != NULL);
			memcpy(domaincleared, &(pdot[1]), len);
			domaincleared[len] = ASCII_NUL;

			len = (strlen(&(pdot[1])) - 1);
			domaincleared_geo = new char [(len + 1)];
			assert(domaincleared_geo != NULL);
			memcpy(domaincleared_geo, &(pus[1]), len);
			domaincleared_geo[len] = ASCII_NUL;
		}
	}
	else if (info[*instance].domain_dotcount == 1)
	{
		size_t len = 0;

		if (domainclearedtotal[0] == ASCII_DT || domainclearedtotal[0] == ASCII_US)
		{
			len = strlen(&(domainclearedtotal[1]));

			if (info[*instance].is_geo_domain == true)
			{
				domaincleared_geo = new char [(len + 1)];
				assert(domaincleared_geo != NULL);
				memcpy(domaincleared_geo, &(domainclearedtotal[1]), len);
				domaincleared_geo[len] = ASCII_NUL;
			}
			else
			{
				domaincleared = new char [(len + 1)];
				assert(domaincleared != NULL);
				memcpy(domaincleared, &(domainclearedtotal[1]), len);
				domaincleared[len] = ASCII_NUL;

				if (len == 0)
				{
					domainscleared->clevel_domain = new char [1];
					assert(domainscleared->clevel_domain != NULL);
					domainscleared->clevel_domain[0] = ASCII_NUL;
				}

				domaincleared_olevels = new char [1];
				assert(domaincleared_olevels != NULL);
				domaincleared_olevels[0] = ASCII_NUL;

				domainscleared->olevels_domain = new char [1];
				assert(domainscleared->olevels_domain != NULL);
				domainscleared->olevels_domain[0] = ASCII_NUL;
			}
		}
		else
		{
			char *pch = NULL;

			if (info[*instance].is_geo_domain == true)
				pch = strchr(domainclearedtotal, ASCII_US);
			else
				pch = strchr(domainclearedtotal, ASCII_DT);

			if (info[*instance].is_geo_domain == true)
			{
				len = (pch - domainclearedtotal);

				domaincleared = new char [(len + 1)];
				assert(domaincleared != NULL);
				memcpy(domaincleared, domainclearedtotal, len);
				domaincleared[len] = ASCII_NUL;

				if (len == 0)
				{
					domainscleared->clevel_domain = new char [1];
					assert(domainscleared->clevel_domain != NULL);
					domainscleared->clevel_domain[0] = ASCII_NUL;
				}

				len = strlen(&(pch[1]));

				domaincleared_geo = new char [(len + 1)];
				assert(domaincleared_geo != NULL);
				memcpy(domaincleared_geo, &(pch[1]), len);
				domaincleared_geo[len] = ASCII_NUL;

				domaincleared_olevels = new char [1];
				assert(domaincleared_olevels != NULL);
				domaincleared_olevels[0] = ASCII_NUL;

				domainscleared->olevels_domain = new char [1];
				assert(domainscleared->olevels_domain != NULL);
				domainscleared->olevels_domain[0] = ASCII_NUL;
			}
			else
			{
				len = (pch - domainclearedtotal);

				domaincleared_olevels = new char [(len + 1)];
				assert(domaincleared_olevels != NULL);
				memcpy(domaincleared_olevels, domainclearedtotal, len);
				domaincleared_olevels[len] = ASCII_NUL;

				if (len == 0)
				{
					domainscleared->olevels_domain = new char [1];
					assert(domainscleared->olevels_domain != NULL);
					domainscleared->olevels_domain[0] = ASCII_NUL;
				}

				len = strlen(&(pch[1]));

				domaincleared = new char [(len + 1)];
				assert(domaincleared != NULL);
				memcpy(domaincleared, &(pch[1]), len);
				domaincleared[len] = ASCII_NUL;

				if (len == 0)
				{
					domainscleared->clevel_domain = new char [1];
					assert(domainscleared->clevel_domain != NULL);
					domainscleared->clevel_domain[0] = ASCII_NUL;
				}
			}
		}
	}
	else
	{
		if (domainclearedtotal[0] != ASCII_NUL)
		{
			domaincleared = new char [(strlen(domainclearedtotal) + 1)];
			assert(domaincleared != NULL);
			strcpy(domaincleared, domainclearedtotal);
		}

		domainscleared->olevels_domain = new char [1];
		assert(domainscleared->olevels_domain != NULL);
		domainscleared->olevels_domain[0] = ASCII_NUL;
	}

	if (domaincleared_geo != NULL && domaincleared_geo[0] != ASCII_NUL) // sui domini geografici non vengono elaborati i termini infissi
	{
		domainscleared->geo_domain = new char [(strlen(domaincleared_geo) + 1)];
		assert(domainscleared->geo_domain != NULL);
		strcpy(domainscleared->geo_domain, domaincleared_geo);
	}
	else
	{
		domainscleared->geo_domain = new char [1];
		assert(domainscleared->geo_domain != NULL);
		domainscleared->geo_domain[0] = ASCII_NUL;
	}

	char *more_domaincleared = NULL;

	char *infixedtext = NULL;
	
	if (domaincleared != NULL && domaincleared[0] != ASCII_NUL)
	{
		if (doc->mime_type == MIME_TEXT_HTML) // i termini infissi possono essere riscontrati solo se si tratta di pagine html
			infixedtext = totalInfixed(instance, theminfo, domaincleared, is_master_domain, poutt, content_length, doc, site, slashes, insert);

		if (strlen(domaincleared) > 3 && strstr(domaincleared, " "))
		{
			size_t domainclearedsize = strlen(domaincleared);
			size_t olddomainclearedsize = domainclearedsize;

			char *jt = joinText(domaincleared, 3, false);
			char *jtinv = joinText(domaincleared, 1, true);

			size_t jtlen = strlen(jt);
			size_t jtinvlen = strlen(jtinv);

			unsigned short err_count = 0;
			unsigned short max_realloc = 5;
			bool alarm = false;

			if (jtlen > 0 && jtinvlen > 0)
				domainclearedsize = (domainclearedsize + 1 + jtlen + 1 + jtinvlen);
			else if (jtlen == 0 && jtinvlen > 0)
				domainclearedsize = (domainclearedsize + 1 + jtinvlen);
			else if (jtlen > 0 && jtinvlen == 0)
				domainclearedsize = (domainclearedsize + 1 + jtlen);

			do
			{
				err_count++;
				assert(domainclearedsize > 0);
				more_domaincleared = new char [(domainclearedsize + 1)];
		
				if (more_domaincleared == NULL && err_count > max_realloc)
				{
					delete [] more_domaincleared;
					more_domaincleared = NULL;
					cerr << "Error (re)allocating domaincleared's memory for " << err_count << " times." << endl;
					alarm = true;
				}
			}
			while (more_domaincleared == NULL);
			// ... fine processo assegnazione memoria puntatore 'infixed'

			if (alarm == false)
			{
				memcpy(more_domaincleared,domaincleared,(olddomainclearedsize + 1));
				delete[] domaincleared;
				domaincleared = more_domaincleared;

				if (jtlen > 0)
				{	
					strcat(domaincleared, " ");
					strcat(domaincleared, jt);
				}

				if (jtinvlen > 0)
				{	
					strcat(domaincleared, " ");
					strcat(domaincleared, jtinv);
				}
			}
		
			free (jt);
			free (jtinv);
		}

		size_t dc_size = strlen(domaincleared);

		if (domaincleared != NULL)
		{
			if (infixedtext == NULL || infixedtext[0] == ASCII_NUL)
			{
				if (infixedtext == NULL)
				{
					infixedtext = (char *) malloc (sizeof(char));
					infixedtext[0] = ASCII_NUL;
				}
				domainscleared->clevel_domain = new char [(dc_size + 1)];
				strncpy(domainscleared->clevel_domain, domaincleared, dc_size);
				domainscleared->clevel_domain[dc_size] = ASCII_NUL;
			}
			else
			{
				size_t total_size = (dc_size + 1 + strlen(infixedtext));
				domainscleared->clevel_domain = new char [(total_size + 1)];
				strncpy(domainscleared->clevel_domain, domaincleared, dc_size);
				domainscleared->clevel_domain[dc_size] = ASCII_NUL;
				strncat(domainscleared->clevel_domain, " ", 1);
				domainscleared->clevel_domain[dc_size + 1] = ASCII_NUL;
				strncat(domainscleared->clevel_domain, infixedtext, strlen(infixedtext));
				domainscleared->clevel_domain[total_size] = ASCII_NUL;
			}
		}
	}

	free(infixedtext);

	if (domaincleared_olevels != NULL && domaincleared_olevels[0] != ASCII_NUL)
	{
		is_master_domain = false;

		char *more_domaincleared_olevels = NULL;
	
		char *infixedtext = NULL;
	
		if (doc->mime_type == MIME_TEXT_HTML) // i termini infissi possono essere riscontrati solo se si tratta di pagine html
			infixedtext = totalInfixed(instance, theminfo, domaincleared_olevels, is_master_domain, poutt, content_length, doc, site, slashes, insert);

		if (strlen(domaincleared_olevels) > 3 && strstr(domaincleared_olevels, " "))
		{
			size_t domaincleared_olevelssize = strlen(domaincleared_olevels);
			size_t olddomaincleared_olevelssize = domaincleared_olevelssize;

			char *jt = joinText(domaincleared_olevels, 3, false);
			char *jtinv = joinText(domaincleared_olevels, 1, true);
	
			unsigned short err_count = 0;
			unsigned short max_realloc = 5;
			bool alarm = false;
	
			domaincleared_olevelssize = (domaincleared_olevelssize + 1 + strlen(jt) + 1 + strlen(jtinv));
	
			do
			{
				err_count++;
				assert(domaincleared_olevelssize > 0);
				more_domaincleared_olevels = new char [(domaincleared_olevelssize + 1)];
		
				if (more_domaincleared_olevels == NULL && err_count > max_realloc)
				{
					delete [] more_domaincleared_olevels;
					more_domaincleared_olevels = NULL;
					cerr << "Error (re)allocating domaincleared_olevels's memory for " << err_count << " times." << endl;
					alarm = true;
				}
			}
			while (more_domaincleared_olevels == NULL);
			// ... fine processo assegnazione memoria puntatore 'infixed'
	
			if (alarm == false)
			{	
				memcpy(more_domaincleared_olevels,domaincleared_olevels,(olddomaincleared_olevelssize + 1));
				delete[] domaincleared_olevels;
				domaincleared_olevels = more_domaincleared_olevels;
		
				strcat(domaincleared_olevels, " ");
				strcat(domaincleared_olevels, jt);
				strcat(domaincleared_olevels, " ");
				strcat(domaincleared_olevels, jtinv);
			}
		
			free (jt);
			free (jtinv);
		}
	
		size_t dc_ol_size = strlen(domaincleared_olevels);
	
		if (domaincleared_olevels[0] != ASCII_NUL)
		{
			if (infixedtext == NULL || infixedtext[0] == ASCII_NUL)
			{
				if (infixedtext == NULL)
				{
					infixedtext = (char *) malloc (sizeof(char));
					infixedtext[0] = ASCII_NUL;
				}
				domainscleared->olevels_domain = new char [(dc_ol_size + 1)];
				strncpy(domainscleared->olevels_domain, domaincleared_olevels, dc_ol_size);
				domainscleared->olevels_domain[dc_ol_size] = ASCII_NUL;
			}
			else
			{
				size_t total_size = (dc_ol_size + 1 + strlen(infixedtext));
				domainscleared->olevels_domain = new char [(total_size + 1)];
				strncpy(domainscleared->olevels_domain, domaincleared_olevels, dc_ol_size);
				domainscleared->olevels_domain[dc_ol_size] = ASCII_NUL;
				strncat(domainscleared->olevels_domain, " ", 1);
				domainscleared->olevels_domain[dc_ol_size + 1] = ASCII_NUL;
				strncat(domainscleared->olevels_domain, infixedtext, strlen(infixedtext));
				domainscleared->olevels_domain[total_size] = ASCII_NUL;
			}
		}

		if (domainscleared->clevel_domain == NULL)
		{
			domainscleared->clevel_domain = new char [1];
			domainscleared->clevel_domain[0] = ASCII_NUL;
		}

		free(infixedtext);
	}

	free (domainclearedtotal);

	delete [] domaincleared;
	domaincleared = NULL;

	delete [] domaincleared_olevels;
	domaincleared_olevels = NULL;

	delete [] domaincleared_geo;
	domaincleared_geo = NULL;

	return domainscleared;
}

//
// Name: temporaryIndexPopulation
//
// Description: Popola l'indice temporaneo 
//
// Argomenti: puntatore a parola da elaborare, limite minimo lunghezza parola.
//
void temporaryIndexPopulation(instance_t *instance, char *ptext, const size_t &min_word_len)
{
	size_t textlen = strlen(ptext);

	// rimuove eventuali spazi in coda
	while (ptext[textlen - 1] == ' ' && textlen > 0)
		textlen--;

	size_t pos = 0;
	size_t toffstart = 0;
	size_t toffstop = 0;
	bool found = false;
	bool single_char = false;

	if (((int)textlen - (int)min_word_len) >= 0)
	do
	{
		while ((isalpha(ptext[pos]) || convSpecialChar(ptext, textlen, pos) != ' ') && pos < textlen)
		{
			if (convSpecialChar(ptext, textlen, pos) != ' ')
				pos += 2;
			else
				pos++;

			found = true;
		}

		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(ptext[pos]) == false) && isalpha(ptext[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(ptext[pos]) == false) && convSpecialChar(ptext, textlen, pos) == ' '))
					toffstop = (pos - 1);
				else if (pos == (textlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			bool eccezione_carattere = false; // quasi tutte le vocali e consonanti seguite da apostrofo

			char *pword = printWord(ptext, toffstart, (toffstop + 1), true);

			size_t reallength = strlen(pword); // nel caso il termine originale contiene lettere 'conosciute' accentate la lunghezza di pword è minore

			termid_t termid = 0;

			if (((toffstop + 1) - toffstart) <= MIN_WORD_LEN)
			{
				// quì va salvato tutto
				// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
				// in quanto non si tratta di una parola
				if ((reallength == 1 && (pword[0] == 'a' || pword[0] == 'e' || pword[0] == 'i' || pword[0] == 'o' || pword[0] == 'd' || pword[0] == 'l')))
				{
					eccezione_carattere = true;

					istidx_resolve_word( tempidx, instance, pword, &(termid), false );
				}
				else if (reallength == 1)
				{
					eccezione_carattere = true;
				}
			}

			if (((toffstop + 1) - toffstart) < MAX_WORD_LEN && ((toffstop + 1) - toffstart) > min_word_len && eccezione_carattere == false)
			{
				// quì va salvato tutto
				// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
				// in quanto non si tratta di una parola
				if ( ! (reallength == 3 && strcmp(pword, "amp") == 0)) // equivale ad unless in perl
				if (reallength > min_word_len && reallength < MAX_WORD_LEN)
				{
					istidx_resolve_word( tempidx, instance, pword, &(termid), false );
				}
			}
			free (pword);
		}

		bool testspecial = false;

		while ((isalpha(ptext[pos]) == false) && pos < (textlen - min_word_len))
			if (ptext[pos] != ' ' && (convSpecialChar(ptext, textlen, pos) != ' '))
			{
				testspecial = true;
				pos--;
				break;
			}
			else
				pos++;

		if (testspecial == true)
			toffstart = pos + 1;
		else
			toffstart = pos;

		found = false;
		single_char = false;
	}
	while (pos++ < (textlen - min_word_len));

	return;
}

// Name makeInstanceIndexes
//
// Description: Crea un undice per istanza valido per tutta la durata della sessione, la prima parte di questi indice è clonata
//
// Input:
//
// Return:
// 
void makeInstanceIndexes (void)
{
	istidx_open(tempidx);

	// popolazione dello stesso con i dati che durante l'esecuzione del programma non andranno mai modificati
	instance_t instance = 0;
	char *elaborate = (char *) malloc (MAX_WORD_LEN * sizeof(char));
	elaborate[0] = ASCII_NUL;
	size_t elaborate_offset = 0;
	size_t offset = 0;

	char *buffer = (char *)helpstring.c_str();

	if (buffer != NULL && buffer[0] != ASCII_NUL) // versione migliorata del ciclo dentro la condizione 'if' perchè deve gestire i buffer overflow 
	{
		while(buffer[offset] != ASCII_NUL)
		{
			if (buffer[offset] != ASCII_SP)
			{
				if (elaborate_offset >= MAX_WORD_LEN) // skip whole string to next space
				{
					elaborate_offset = 0;
					elaborate[elaborate_offset] = ASCII_NUL;

					while (buffer[offset] != ASCII_SP)
						offset++;

					continue;
				}
				else
				{
					elaborate[elaborate_offset++] = buffer[offset];
					elaborate[elaborate_offset] = ASCII_NUL;
				}

			}
			else
			{
				if (elaborate_offset > 1)
				{
					if (elaborate_offset <= MAX_WORD_LEN)
					{
						temporaryIndexPopulation(&instance, elaborate, 0);
						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
					}
				}
				else
				{
						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
				}
			}

			offset++;
		}

		if (elaborate_offset > min_word_len && elaborate_offset <= MAX_WORD_LEN)
			temporaryIndexPopulation(&instance, elaborate, min_word_len);
	}

	free (elaborate);

	// i caratteri verranno appesi alla string tempidx[instance]->term sempre dopo tempidx_term_next_char;
	terms_eohs_offset = tempidx[instance]->term_count;
	tempidx_term_next_char = tempidx[instance]->term_next_char;

	// istidx_term_hash conterrà l'hash di base con i termini statici precaricati ad inizio programma ('helpstring')
	// Clean hash tables
	tempidx_term_hash = CBALLOC(off64_t, CALLOC, ISTIDX_MAXTERMS);
	memcpy ( tempidx_term_hash, tempidx[instance]->term_hash, (ISTIDX_MAXTERMS * sizeof(off64_t)));

	// creating clones of DocIndex (one for instance)
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		for (instance_t instance = 1; instance < CONF_COLLECTION_DISTRIBUTED; instance++)
		{
			memcpy ( tempidx[instance]->term_hash, tempidx_term_hash, (ISTIDX_MAXTERMS * sizeof(off64_t)));
			memcpy ( tempidx[instance]->term_list, tempidx[0]->term_list, ((ISTIDX_MAXTERMS + 1) * sizeof(off64_t))); // not used
			memcpy ( tempidx[instance]->term, tempidx[0]->term, (ISTIDX_TERM_SIZE * sizeof(char)));
			tempidx[instance]->term_count = terms_eohs_offset;
			tempidx[instance]->term_next_char = tempidx_term_next_char;
		}
	}
}

// Name readTerms
//
// Description 
void readTerms (instance_t *instance, const size_t &min_word_len, char *ptext, char *content)
{
	// reimposta l'indice temporaneo ai solo dati di default impostati dalla funzione 'readStaticTerms'
	if (tempidx[*instance]->term_count > terms_eohs_offset)
	{
		tempidx[*instance]->term_count = terms_eohs_offset;
		tempidx[*instance]->term_next_char = tempidx_term_next_char;
		memcpy ( tempidx[*instance]->term_hash, tempidx_term_hash, (ISTIDX_MAXTERMS * sizeof(off64_t)));
	}

	// reimposta il numero di documenti presenti di default
	terms_split_offset[*instance] = terms_eohs_offset;
	
	// Inizio lettura stdin
	bool content_readed = false;
	char *elaborate = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));
	elaborate[0] = ASCII_NUL;
	size_t elaborate_offset = 0;
	size_t offset = 0;

	char *buffer = ptext;

	run_again:

	if (buffer != NULL && buffer[0] != ASCII_NUL) // versione migliorata del ciclo dentro la condizione 'if' perchè deve gestire i buffer overflow 
	{
		while(buffer[offset] != ASCII_NUL)
		{
			if (buffer[offset] != ASCII_SP && buffer[offset] != ASCII_CM)
			{
				if (elaborate_offset >= MAX_WORD_LEN) // skip whole string to next space
				{
					elaborate_offset = 0;
					elaborate[elaborate_offset] = ASCII_NUL;

					while (buffer[offset] != ASCII_NUL && buffer[offset] != ASCII_SP && buffer[offset] != ASCII_CM)
						offset++;

					continue;
				}
				else
				{
					elaborate[elaborate_offset++] = buffer[offset];
					elaborate[elaborate_offset] = ASCII_NUL;
				}

			}
			else
			{
				char *newstr = NULL;

				if (elaborate_offset > 1 && elaborate_offset <= MAX_WORD_LEN && (newstr = removeUnAscii(elaborate, 1, elaborate_offset)) != NULL)
						temporaryIndexPopulation(instance, newstr, 0);

				elaborate_offset = 0;
				elaborate[elaborate_offset] = ASCII_NUL;
			}

			offset++;
		}

		char *newstr = NULL;

		if (elaborate_offset > min_word_len && elaborate_offset <= MAX_WORD_LEN && (newstr = removeUnAscii(elaborate, min_word_len, elaborate_offset)) != NULL)
			temporaryIndexPopulation(instance, newstr, min_word_len);
	}

	if (content != NULL && strlen(content) > 0 && content_readed == false) 
	{
		elaborate[0] = ASCII_NUL;
		elaborate_offset = 0;
		offset = 0;
		buffer = content;
		content_readed = true;
		terms_split_offset[*instance] = tempidx[*instance]->term_count;
		goto run_again;
	}

	free (elaborate);
}

//
// Name: removeUnAscii
//
// Description: Remove unacceptable ascii char from start string and and of string
//
// Accept: the pointer to char array, admitted min size of array, admitted max length of string
//
// Return: new pointer to string
//
char *removeUnAscii(char *str, size_t min_len, size_t len)
{
			size_t c = 0;

			while (str[c] != ASCII_NUL
				&& ((str[c] > 0 && str[c] < 48)
				|| (str[c] > 57 && str[c] < 65)
				|| (str[c] > 90 && str[c] < 97)
				|| (str[c] > 122 && str[c] < 128)
				|| (str[c] > 144 && str[c] < 147)
				|| (str[c] > 154 && str[c] < 255)))
					c++;

			char *mystr = &(str[(c)]);

			len -= c;

			while (len > min_len
				&& ((mystr[(len - 1)] > 0 && mystr[(len - 1)] < 48)
				|| (mystr[(len - 1)] > 57 && mystr[(len - 1)] < 65)
				|| (mystr[(len - 1)] > 90 && mystr[(len - 1)] < 97)
				|| (mystr[(len - 1)] > 122 && mystr[(len - 1)] < 128)
				|| (mystr[(len - 1)] > 144 && mystr[(len - 1)] < 147)
				|| (mystr[(len - 1)] > 154 && mystr[(len - 1)] < 255)))
					len--;

			if (len > min_len)
			{
				mystr[len] = ASCII_NUL;
				return mystr;
			}

	return NULL;
}

//
// Name: connector_usage
//
// Description:
//   Prints an usage message, then stops
//
void connector_usage() {
	cerr << "Usage: program --filethematic filename [OPTION]" << endl;
	cerr << "Extract documents to be indexed, this is invoked by" << endl;
	cerr << "the indexer program, you should not run it directly." << endl;
	cerr << endl;
	cerr << " --from [arg]          First docid to index, default 1" << endl;
	cerr << " --to [arg]            Last docid to index, default ndocs" << endl;
	cerr << " --reset               Reset nvc data. BEFORE THIS YOU MUST RESTORE INDEX ENGINE!" << endl;
	cerr << " --updatescores        ACCURATE update scores and ranking in search engine" << endl;
	cerr << " --debugonly           DO NOT save site's content to disk or index data. It use /tmp partition for all operation." << endl;
	cerr << "                       Check if /tmp is mounted as tmpfs in /etc/fstab and if it have a large size!!!" << endl;
	cerr << " --showinfixes         If the option 'debugonly' has been selected, print only the infixes word and exit." << endl;
	cerr << " --showthematics       If the option 'debugonly' has been selected, print only the thematics rules and exit." << endl;
	cerr << " --help                This help message" << endl;
	cerr << endl;
	exit (0);
}
