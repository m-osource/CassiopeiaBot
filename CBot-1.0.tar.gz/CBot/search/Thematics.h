/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _THEMATICS_H_INCLUDED_
#define _THEMATICS_H_INCLUDED_

// Local libraries
#include "commons.h"
//#include "xmlconf.h"

#define BUFFERSIZE 1
#define RBSIZE 128 // quantità di strutture in ranking_buffer (in pratica permette di controllare contemporanemente 128 regole)

//using namespace std;

typedef unsigned short themid_t;
//typedef unsigned int stemid_t;
// typedef unsigned long int wordid_t;
typedef unsigned short duplid_t;
typedef unsigned short metaid_t;

const off64_t EXPECTED_THEM_SIZE = 10; // in bytes
const off64_t THEMIDX_EXPECTED_THEM_SIZE = (EXPECTED_THEM_SIZE + 1 + sizeof(themid_t));

const off64_t EXPECTED_STEM_SIZE = 9; // in bytes, in teoria per i termini stemmed potrebbe essere anche inferiore di uno o due
const off64_t THEMIDX_EXPECTED_STEM_SIZE = (EXPECTED_STEM_SIZE + 1 + sizeof(stemid_t));

const off64_t EXPECTED_WORD_SIZE = 10; // in bytes, la lunghezza media delle parole (italiane è 6), dovrebbe bastare
const off64_t THEMIDX_EXPECTED_WORD_SIZE = (EXPECTED_WORD_SIZE + 1 + sizeof(wordid_t));

const off64_t EXPECTED_DUPL_SIZE = 10; // in bytes
const off64_t THEMIDX_EXPECTED_DUPL_SIZE = (EXPECTED_DUPL_SIZE + 1 + sizeof(duplid_t));

const off64_t EXPECTED_META_SIZE = 10; // in bytes (oltre allo stemming dei termini potrei decidere di mettere anche il termine intero (utile ai termini infissi))
const off64_t THEMIDX_EXPECTED_META_SIZE = (EXPECTED_META_SIZE + 1 + sizeof(metaid_t));

// Status
enum themidx_status_t { 
	THEMIDX_ERROR 			= 0,
	THEMIDX_CREATED_THEM		= 1,
	THEMIDX_CREATED_STEM		= 2,
	THEMIDX_CREATED_WORD		= 3,
	THEMIDX_CREATED_DUPL		= 4,
	THEMIDX_CREATED_META		= 5,
	THEMIDX_EXISTENT		= 6,
	THEMIDX_NOT_FOUND		= 7
};

// struttura che comprende le elaborazioni ottenute della classe delle tematiche
typedef struct {
	Language language; // uso futuro

	struct sb_stemmer *stemmer;

	struct {	
		// Duplicated (stemming of words of headings and content, without duplicated)
		char *dupl;								// Strings    [memory]
		off64_t *dupl_hash;                       // Hash table [memory]
		duplid_t dupl_count;					// Count      [memory]
		off64_t dupl_next_char;					// String Pos [memory]
		off64_t *dupl_list;                        // List       [memory]
	
		// Duplicated (stemming words of metatags and url's words, without duplicated)
		char *meta;								// Strings    [memory]
		off64_t *meta_hash;                       // Hash table [memory]
		duplid_t meta_count;					// Count      [memory]
		off64_t meta_next_char;					// String Pos [memory]
		off64_t *meta_list;                        // List       [memory]
	} tempidx;

	// struttura che immagazzina i punteggi nel ranking_buffer, racchiudendo 'regole e relativi ranking' posizionati in coppie affiancate
	struct {
		unsigned short rule;
		unsigned int ranking;
		unsigned int them_ranking;
	} ranking_buffer[RBSIZE];

	unsigned long int *thematic_ranking;

	char thematic[(MAX_WORD_LEN + 1)];
	char sensitive_words[(MAX_STR_LEN + 1)];
	size_t swlen;
	char top_words[(MAX_STR_LEN + 1)];
	size_t twlen;
	char good_words[(MAX_STR_LEN + 1)];
	size_t gwlen;
	duplid_t duplicates_split_offset[2];
	metaid_t metawords_split_offset;
	unsigned short *synonyms_found;
	unsigned short count_terms;
	unsigned int ranking;
	themid_t ranked_rules;
	themid_t ranked_thematics;
} thematic_out_t;

// Classe Tematiche
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Thematics {

	// Attenzione: TUTTE le dichiarazioni in questa sezione sono valide per tutte le funzioni all'interno della classe.
	// Motivo per cui NON occorre passarle come argomenti alle stesse.
	//
	// Attenzione: Quando un metodo ha il solo compito di riportare informazioni su un oggetto, senza modificarne il contenuto, si può, per evitare errori,
	// imporre tale condizione a priori, inserendo lo specificatore 'const' dopo la lista degli argomenti della funzione
	// (sia nella dichiarazione che nella definizione). Esistono comunque delle particolari eccezioni...

	// Le funzioni che indicizzano i termini sono state miglirate e in alcune di queste anche l'algoritmo di cui fanno uso è stato modificato ed è 
	// contrassegnato da '**'

	// Constants
	#define MAXTHEMATICS 200
	#define MAXSTEMMING 4000
	#define MAXWORDS 40000
	#define MAXDUPLICATES 10000 // in una pagina lunga al max 50000 caratteri possono starci al max circa 8000 (80% di 10000) parole diverse tra loro
	#define MAXMETA 6000 // Quì devono starci tutti i termini dei metatags

	#define FM 2.20 // costante che consente di assegnare maggiore precisione alla valutazione del ranking
	#define heading_award 30 // valore percentuale aggiunto al ranking nel caso il termine sia tra tag strong, headings ecc..
	#define SR_CONST 1.9 // il ranking finale deve essere grande almento SR_CONST volte il second_rank

	#define THEMIDX_MAX_OCCUPANCY 			((float)0.8)

	#define THEMTHRESHOLD 300000000 // valore assoluto massimo ipotizzabile del ranking della tematica (al momento il ranking non si è visto superare la soglia di 250000000 ogni tanto occorre verificare la soglia)
	#define THEMRANK_MAX 30000000 // definizione che serve per far comprendere i valori di pagerank da '0' a THEMRANK_MAX (normalizzazione). In questo caso se il pagerank può arrivare al massimo a '100000000' sommando THEMRANK_MAX può influire per il 30% del pagerank

	// Variables
	Language language; // uso futuro
	stemid_t first_stem_uid;
	stemid_t src_stem_uid;
	stemid_t dst_stem_uid;
	bool are_synonyms;
	wordid_t left_wordform_uid;
	unsigned int wordformsmax;
	unsigned int mcline;
	unsigned short mcrule;
	unsigned short msline;
	
	bool master_wordform; // termine master che sta a destra nella colonna dei wordforms

	// struttura idonea a contenere i valori in map_synonyms
	typedef struct
	{
		bool only_synonyms; // indica se la linea di sinonimi è solo nel file dei sinonimi
		unsigned short line; // linea di sinonimi
	} map_synonyms_value_t;

	map<wordid_t, map_synonyms_value_t> map_synonyms; 	// (master wordform id oppure wordid del relativo stemming del sinonimo)  -> numero linea nel file.
							// N.B. Contiene solo le linee di sinonimi presenti nel main file
							// Si è optato per l'array associativo piuttosto che l'hash lineare
						 	// perchè l'ordine di wordid può non essere sequenziale
	map<wordid_t, map_synonyms_value_t>::iterator iter_map_syn; // per leggere un array associativo di tipo non const occorre usare 'iterator'
	char *synonyms_buffer; // contiene i sinonimi scritti per intero come nel file dei sinonimi ma pulito da eventuali spazi in eccesso
	unsigned long int terms_count; // indica il numero totale di parametri (numerici o no) nel principale file di configurazione 'contexts.txt'.
	unsigned long int terms_counter; // contatore di parametri (numerici o no) del principale file di configurazione 'contexts.txt'.
	unsigned int thematics_counter; // indica il numero totale dei termini numerici (sinonimi) presenti nel main_buffer
	unsigned int synonyms_counter; // indica il numero totale dei termini numerici (sinonimi) presenti nel main_buffer
	unsigned int stemming_counter; // indica il numero totale dei termini contesti (di seguito chiamati stemming) in forma di stemming presenti nel main_buffer
	// Wordidx structure
	// Note that this is saved "as-is" to disk, so if you change it,
	// it will misbehave.
	
	typedef struct {
		// Thematics
		char *them;								// Strings    [memory]
		off64_t *them_hash;                       // Hash table [memory]
		themid_t them_count;					// Count      [memory]
		off64_t them_next_char;					// String Pos [memory]
		off64_t *them_list;                        // List       [disk]
	
		// Stem
		char *stem;								// Strings    [memory]
		off64_t *stem_hash;                       // Hash table [memory]
		stemid_t stem_count;					// Count      [memory]
		off64_t stem_next_char;					// String Pos [memory]
		off64_t *stem_list;                        // List       [memory]
	
		// Words
		char *word;								// Strings    [memory]
		off64_t *word_hash;                       // Hash table [memory]
		wordid_t word_count;					// Count      [memory]
		off64_t word_next_char;					// String Pos [memory]
		off64_t *word_list;                        // List       [memory]
	} themidx_t;

	// struttura che può contenere un id identificativo di stem (dunque di una parola contesto) o un numero di riga (unsigned short) di sinonimi
	// la discriminazione viene effettuata dal valore booleano 'is_context'
	// In pratica questa è la copia del principale file di configurazione 'contexts.txt' in forma numerica con le regole con i termini dei contesti
	// (inseriti nell'indice delle parole stemming) convertiti in formato numerico
	// L'offset indica la posizione nel buffer 'sy_dist' delle regole dei contesti che contengono determinate linee di sinonimi o
	// alternativamente dei contesti.
	typedef struct {
		unsigned short rule; // ogni regola (su unica linea) valida di configurazione è numerata
		bool is_synonyms;
		bool is_thematic;
		stemid_t generic_id;
	} context_t;

	// struttura che definisce i wordforms
	typedef struct {
		wordid_t master_wordform_uid; // indica l'uid dei termini della colonna destra del file dei termini wordform
	} wordforms_t;

	// struttura che localizza i sinonimi
	// in pratica la struttura definisce dove trovare i sinonimi relativi ad ogni riga del file dei sinonimi
	// es: la seconda struttura puntata dal relativo puntatore contiene l'offset dove trovare i sinonimi della riga 1 del file dei sinonimi
	// (si conta partendo da '0').
	// L'offset indica la posizione nel buffer 'synonyms_buffer' dove ricavare i sinonimi scritti in formato testo;
	typedef struct {
		size_t line_offset; // offset nel buffer del file in lettura
	} line_synonyms_t;

	// struttura puntata dalla regola che localizza la stessa
	// attraverso 'rule_offset'
	typedef struct {
		size_t rule_offset; // offset nel buffer delle configurazioni principale (main_buffer)
		themid_t thematic;
		unsigned short terms;
	} main_t;

	// struttura che associa ogni identificativo univoco di tematica con l'offset di st_dist.
	// Leggendo in th_dist partendo da tale offset si reperiscono tutte le regole (rules) in cui è presente tale identificativo di tematica.
	typedef struct {
		unsigned int th_dist_offset;
	} thematic_vs_main_rules_t;

	// struttura che associa ogni linea dei sinonimi con l'offset di sy_dist.
	// Leggendo in sy_dist partendo da tale offset si reperiscono tutte le regole (rules) in cui è presente tale riga di sinonimi.
	// amount_rules indica la quantità di regole interessate dalla stessa linea di sinonimi, questa variabile è necessaria rendere la ricerca più efficace.
	// In questo caso infatti potrebbero esserci linee di sinonimi (anche consecutive) non esistenti, la 'funzione' che esegue la ricerca perciò
	// senza 'amount_rules' potrebbe risentire di rallentamenti.
	typedef struct {
		unsigned int sy_dist_offset;
		unsigned char amount_rules; 
	} synonyms_vs_main_rules_t;

	// struttura che associa ogni identificativo univoco di stemming con l'offset di st_dist.
	// Leggendo in st_dist partendo da tale offset si reperiscono tutte le regole (rules) in cui è presente tale identificativo di stemming.
	typedef struct {
		unsigned int st_dist_offset; 
	} stemming_vs_main_rules_t;

	// struttura che contiene:
	// la regola dove è presente lo stemming nel main_buffer
	// Coefficente di divisione calcolato in funzione della distribuzione dell'identificativo tra le tematiche e tra le regole all'interno delle stesse.
	typedef struct {
		unsigned short rule; 
		unsigned int location_coefficient; 
	} idx_id_vs_rules_t;

	struct sb_stemmer *stemmer;

	themidx_t *openidx;

	wordforms_t *wordform_struct;

	line_synonyms_t *line_synonyms_structs;

	main_t *main_structs;

	context_t *main_buffer; // contiene i parametri di configurazione (convertiti in relativi id numerici) del file principale dei contesti

	thematic_vs_main_rules_t *th_dist_st;
 
	synonyms_vs_main_rules_t *sy_dist_st;
 
	stemming_vs_main_rules_t *st_dist_st;
 
	unsigned short *th_dist; // contiene una mappa della distribuzione delle tematiche nelle regole (rules) del main_buffer
			      // ogni insieme di regole è rintracciabile attraverso l'offset indicato nella struttura tipo 'synonyms_vs_main_rules_t'
	idx_id_vs_rules_t *sy_dist; // contiene una mappa della distribuzione dei sinonimi nelle regole (rules) del main_buffer
			      // ogni insieme di regole è rintracciabile attraverso l'offset indicato nella struttura tipo 'synonyms_vs_main_rules_t'
	idx_id_vs_rules_t *st_dist; // contiene una mappa della distribuzione degli identificativi di stemming nelle regole (rules) del main_buffer
			      // ogni insieme di regole è rintracciabile attraverso l'offset indicato nella struttura tipo 'stemming_vs_main_rules_t'

	void makeWordforms(char *, const size_t);

	void makeSynonyms(char *, char *, const size_t, unsigned short);

	void makeContexts(char *, const size_t, bool, bool);

	// esegue lo stemming di base di una parola (solo in fase di inizializzazione della classe della tematica)
	char *doBaseStemming(char *, size_t, size_t) const;

	// esegue lo stemming di una parola esaminando prima se esistono eventuali wordform (solo in fase di inizializzazione della classe della tematica)
	char *doStemming(char *, size_t, size_t) const;

	// New URL index
	void themidx_new(void);
	
	// Close an URL index
	void themidx_close(void);

	// Search word in text to elaborate
	unsigned short checkThematicWord(thematic_out_t *, char *, const size_t, bool, bool, bool) const;

	// Search word in text to elaborate
	unsigned short *checkSensitiveWord(thematic_out_t *, char *, const size_t, unsigned short *) const;

	// assign local ranking at contexts rules
	void rankingAllocation(thematic_out_t *, stemid_t, bool, bool, bool, bool) const;

	// Get the themid for a thematic
	themidx_status_t themidx_resolve_them( const char *, const char *, themid_t *, bool ) const; // * performance **
	
	// Get the stemid for a stemming
	themidx_status_t themidx_resolve_stem( const char *, const char *, stemid_t *, bool ) const; // * migliorate grazie **
	
	// Get the wordid for a word
	themidx_status_t themidx_resolve_word( const char *, wordid_t *, bool ) const; // * al booleano readonly che permette di ridurre le query
	
	// Get a thematic from a themid
	void themidx_them_by_themid( themid_t, char * ) const;
	
	// Get a stemming from a stemid
	void themidx_stem_by_stemid( stemid_t, char * ) const;
	
	// Get a word from a wordid
	void themidx_word_by_wordid( wordid_t, char * ) const;
	
	// Get the themid bucket for a thematic
	themid_t themidx_check_them( const char *, themid_t * ) const; // **
	
	// Get the stemid bucket for a stemming
	stemid_t themidx_check_stem( const char *, stemid_t * ) const; // **
	
	// Get the wordid bucket for a word
	wordid_t themidx_check_word( const char *, wordid_t * ) const;
	
	// Hash functions
	themid_t themidx_hashing_them( const char * ) const;
	
	// Hash functions
	stemid_t themidx_hashing_stem( const char * ) const;
	
	// Hash functions
	wordid_t themidx_hashing_word( const char * ) const;

	// Convert upper string language to lower
	char *lower_lang( void ) const;

	public:

	Thematics (void); // ctor

	bool index_setup ( Language &, char *, const size_t, bool );

	thematic_out_t *make_dupl_index ( Language &, char *, const size_t , pes_t *, size_t ) const;

	void index_read ( thematic_out_t *, const char [NUMROWS][NUMCOLS], unsigned int &, const size_t &, pes_t *, size_t &, char *, char *, char * ) const;
	//void index_read (thematic_out_t *, const char matrix[NUMROWS][NUMCOLS], unsigned int &, const size_t &, pes_t *, size_t &, char *, char *, char *) const;
	//thematic_out_t *index_read (thematic_out_t *tro, const char matrix[NUMROWS][NUMCOLS], unsigned int row_dictionary_url, const size_t min_word_len, pes_t *poutt, size_t content_len, char *purlwords, char *clevel_domain, char *olevels_domain) const;

	void free_dupl_index ( thematic_out_t * ) const;

	void index_open( void );

	void index_close( bool );

	// esegue lo stemming di base di una parola
	char *doBaseStemming( thematic_out_t *, char *, size_t, size_t ) const;

	// esegue lo stemming di una parola esaminando prima se esistono eventuali wordform
	char *doStemming( thematic_out_t *, char *, size_t, size_t ) const;

	// Get the themid for a thematic
	themidx_status_t themidx_resolve_them( thematic_out_t *, const char *, const char *, themid_t *, bool ) const; // * performance **
	
	// Get the stemid for a stemming
	themidx_status_t themidx_resolve_stem( thematic_out_t *, const char *, const char *, stemid_t *, bool ) const; // * migliorate grazie **
	
	// Get the duplid for a duplicate
	themidx_status_t themidx_resolve_dupl( thematic_out_t *, const char *, const char *, duplid_t *, bool ) const; // * di ridurre le query in fase di **
	
	// Get the metaid for a meta word
	themidx_status_t themidx_resolve_meta( thematic_out_t *, const char *, metaid_t *, bool ) const; // * verifica di identificativo
	
	// Get a duplicate from a duplid
	void themidx_dupl_by_duplid( thematic_out_t *, duplid_t, char * ) const;
	
	// Get a meta word from a metaid
	void themidx_meta_by_metaid( thematic_out_t *, metaid_t, char * ) const;
	
	// Get the themid bucket for a thematic
	themid_t themidx_check_them( thematic_out_t *, const char *, themid_t * ) const; // **
	
	// Get the stemid bucket for a stemming
	stemid_t themidx_check_stem( thematic_out_t *, const char *, stemid_t * ) const; // **
	
	// Get the duplid bucket for a duplicate
	duplid_t themidx_check_dupl( thematic_out_t *, const char *, duplid_t * ) const;
	
	// Get the metaid bucket for a meta word
	metaid_t themidx_check_meta( thematic_out_t *, const char *, metaid_t * ) const;
	
	// Hash functions
	duplid_t themidx_hashing_dupl( const char * ) const;
	
	// Hash functions
	metaid_t themidx_hashing_meta( const char * ) const;
};
#endif
