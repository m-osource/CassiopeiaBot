/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include <signal.h>

#include "commons.h"
#include "atomic"
#include "infixddx.h"
#include "connddx.h"
#include "Thematics.h" // classe delle tematiche, trova tematiche e analizza gli argomenti trattati da un documento.
#include "xmlconf.h"
#include "xmlconf-main.h"

// Types

// Data formats 

// Globals

typedef long score_t;

// la struttura domainscleared_t introduce il concetto di domini geografici (di 2 livello) all'interno di un dominio .it
// in pratica un dominio tipo www.comuni-sardi.blogspot.com assegna 'comuni sardi' a olevels_domain e 'blogspot' clevel_domain
// un dominio tipo www.comune.oristano.it (essendo geografico al secondo livello) assegna 'comune' a clevel_domain e oristano a 'geo_domain'
// come si evince se si riscontra un dominio geografico di secondo livello, il nome dominio in generale assume un punteggio più alto rispetto ad un dominio
// con un secondo livello tradizionale
typedef struct {
	char *geo_domain; // al momento valido con domini italiani che nel motore deve avere un punteggio alto
	char *clevel_domain; // dominio normalmente di secondo livello che nel motore deve avere un punteggio medio
	char *olevels_domain; // altri livelli superiori di dominio ma che nel motore devono avere punteggio minore
} domainscleared_t;

// la struttura top_site_t indica (per ogni identificativo di secondo livello puntato), l'identificativo numerico del dominio di livello superiore relativo, 
// che ha il siterank più alto
typedef struct {
	bool *read_only;
	bool *both_verified;
	siteid_t siteid;
	siterank_t *siterank;
} best_site_t;

typedef struct {
	siteid_t siteid;
	char *handled_infitext;
} session_infixed_t; // contiene gli identificativi dei siti salvati e i termini infissi  per ogni sessione di cbot-connector

// termini passati tra le funzioni
// N.B. devono essere relativi ad ogni indice
typedef struct {
	bool isvirtualhomepage;
	unsigned short domain_dotcount; // conta i punti 'utili nel nome dominio
	bool is_geo_domain;
	iq_t iq; // iq indica la qualità della risoluzione dei termini infissi per i nomi di dominio, se 0 indica che il termine infisso NON si può salvare definitivamente
} info_t;

const map<string, string> map_abbreviated = {// 'hash' contente le abbreviazioni utili agli infixed es: uni => universita
{"uni","universita ateneo atenei"}, // l'elemento valore può contenere più parole
{"ist","istituto istituti"},
{"csa","usp usr scuola scuole"},
{"usr","csa usp scuola scuole"}, // ufficio scolastico regionale
{"usp","csa usr scuola scuole"}, // ufficio scolastico provinciale
{"ic","scuola scuole"}, // istituto comprensivo
{"asd","associazione associazioni sportiva sportive dilettantistica dilettantistiche"},
{"coop","cooperativa cooperative"},
{"ca","cagliari cagliaritano cagliaritana cagliaritani cagliaritane"},
{"nu","nuoro nuorese nuoresi"},
{"or","oristano oristanese oristanesi"},
{"ss","sassari sassarese sassaresi"}
};

const string helpstring = "dottore dottori dottoressa dottoresse sardegna sardinia sardo sardi sarda sarde uni ist csa usr usp ic asd coop ca or nu ss tv"; // Aggiungo di default parole 'importanti' in questo modo aiuto l'algoritmo dentro la funzione strInfixed a trovare parole non menzionate in fulltext


//static map<string, string> map_abbreviated; // 'hash' contente le abbreviazioni utili agli infixed es: uni => universita
//N.B. I valori dentro map_abbreviated vanno assegnati all'interno della funzione main

char buff[MAX_STR_LEN]; // uso provvisorio

#define RELATIVE_WORK_DIRECTORY "datainfixd" // PROVVISORIO

#define CHUNKS 4 // numero che definisce in quanti pezzi suddividere un indice realtime

//#define MAXTERMS 16000 // Deve poter contenere tutti i termini univoci presenti in un documento web
#define BDBLINKS_FILENAME_DB "datalinks.db"
#define INTERVAL_PRINT 50 // Indica quanti documenti elaborare prima che compaia un punto
#define MIN_TEXT_LEN 50 // Indica la lunghezza minima di un testo affinchè sia salvato nei files BuildExcerpts
#define MIN_INFIX_LEN 1 // Il valore MIN_INFIX_LEN non può essere inferiore a 2 (due). 
#define MAX_INFIX_LEN 32 // Lunghezza massima della parola su cui è possibile effettuare il processo di 'infixing'.
#define ICONSTANT 2.5 // indica il rapporto che deve esistere tra la lunghezza della stringa e il numero dei termini infissi estrapolati
#define ISTIDX_MAX_OCCUPANCY ((float)0.8)
#define RANK_MAX 100000000 // definizione che serve per far comprendere i valori del ranking da '0' a RANK_MAX

Meta *meta			= NULL;
Url *url			= NULL;
Storage *strg		= NULL;
ifxddx_t *ifxddx	= NULL;
connddx_t *connddx	= NULL;
perfhash_t		keep_special;
pthread_barrier_t *connector_barrier = NULL;
pthread_mutex_t	*glock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
urlmutex_t		*urlslock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
urlmutex_t		*urldlock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
urlmutex_t		*urlplock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
ifxmutex_t		*klock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
Thematics		th; // definizione dell'oggetto della classe delle tematiche al momento lingua IT
std::atomic 	<bool>			bdbcorrupted; // true se manca anche un solo BerkeleyDB per istanza
std::atomic 	<instance_t>	bdbstatus; // conta i thread che hanno verificato lo stato del loro relativo BerkeleyDB
bool			reset; // restart program from begin
bool			indexupdate = false;
bool			updatescores = false;
bool			debugonly = false;
bool			showthematics = false;
bool			showinfixes = false;
const string 	sphinx_db = "sphinx"; // nome fittizio
const string 	sphinx_port = "9306";
const string 	sphinx_username = "prova"; // nome fittizio
const string 	sphinx_password = "password"; // nome fittizio
docid_t			opt_from = 0;
docid_t			opt_to = 0;
const char		*relative_rem_path_prefix = "dataconnector";
time_t			starttime = 0; // timestamp di avvio processo
info_t			*info;
best_site_t		*bestsite_for_domain = NULL;
istidx_t		**tempidx; // N.B. Indici 'ibrido' (uno per istanza) con i primi termid relativi a 'helpstring' popolati 'staticamente'...

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

// indica l'identificativo del termine da cui parte un determinato tipo di dato memorizzato
// N.B. da l'offset 0 a l'offset (meno uno) 'terms_eohs_offset' sono indicizzati i termini in 'helpstring'
// terms_eohs_offset -> (offset counter inizio poutt->metakeyw + poutt->title + poutt->metadesc)
// terms_split_offset[0] -> (offset counter inizio poutt->content)
static termid_t terms_eohs_offset; // terms_ end of help string _offset
static termid_t *terms_split_offset;
//  fine dati indice temporaneo***

short rowuindex[NUMUROWS] = {0}; // N.B. Essendo dihiarato al di fuori di main, va passato come argomento solo alle funzioni (che ne devono fare uso)
// non dichiarate in connector.cc. P.S. Potrebbero esistere altri casi analoghi...
unsigned int row_dictionary_url, col_dictionary_url = 0;

const size_t min_word_len = 2;

// permette di reinizializzare l'indice temporaneo ai soli dati di default
static off64_t *tempidx_term_hash = NULL; // una volta popolato sarà read only
static off64_t tempidx_term_next_char = 0;

// Functions

//
// Name: numtostring
//
// Description:
//	Like snprintf, convert number into ascii string, but number can be any numeric data type
//
// Input:
//   n - n
//   c - empty string
//
// Return:
//   char pointer to string number
//
template <typename T> char *numtostring (T n)
{
const static char ascii_ch[] = {48,49,50,51,52,53,54,55,56,57};
char *s = CBALLOC(char, CALLOC, 22);
char invert[22] = {'\0'};
unsigned short a = 0;
T t = n;

	do
	{
		invert[a++] = ascii_ch[t % 10]; // ogni cifra viene convertita nel suo compatibile carattere ascii (praticamente il numero cambia da 9 a '9')
		t = t / 10; // nessun resto 
	}
	while (t > 0);

	t = a;

	assert(a < 22);

	for (unsigned short v = 0; v < a; v++)
		s[v] = invert[--t]; // chiave ora contiene un array di cifre che compongono il numero contenuto in w

	return s;
}

void connector_sync_threads( pthread_barrier_t * );
void *thread_function_dropdb_conn( void * );
void *thread_function_create_conn( void * );
void makeInstanceIndexes ( void );
void temporaryIndexPopulation( instance_t *, char *, const size_t & );
void readTerms ( instance_t *, const size_t &, char *, char * );
void connector_usage(void);
bool feeder( instance_t *, doc_t *, site_t *, Db *, mysqlpp::Query, bool );
char *selectmytitle( char *, char *, char * );
char *urlWords( instance_t *, string, depth_t );
char *splitSite( instance_t *, char * );
char *strInfixed( instance_t *, thematic_out_t *, string, char*, const size_t &, const size_t &, termid_t *, bool & );
char *totalInfixed( instance_t *, thematic_out_t *, string, bool &, pes_t *, size_t &, doc_t, char *, depth_t &, bool & );
char *joinText( string, const size_t, const bool );
short wordCounter( char *, const size_t );
char *saveSensitiveInfixed( thematic_out_t *, size_t, char * );
char *ifxResolver( iq_t &, char *, char * );
domainscleared_t *domainCleared( instance_t *, thematic_out_t *, pes_t *, size_t &, doc_t *, char *, depth_t &, bool & );
char *removeUnAscii( char *, size_t, size_t );
