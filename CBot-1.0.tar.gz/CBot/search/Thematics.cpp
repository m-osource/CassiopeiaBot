#include "Thematics.h"


off64_t THEMIDX_THEM_SIZE;
off64_t THEMIDX_STEM_SIZE;
off64_t THEMIDX_WORD_SIZE;
off64_t THEMIDX_DUPL_SIZE;
off64_t THEMIDX_META_SIZE;

Thematics::Thematics(void)
	: synonyms_buffer		(NULL)
	, stemmer				(NULL)
	, openidx				(NULL)
	, wordform_struct		(NULL)
	, line_synonyms_structs	(NULL)
	, main_structs			(NULL)
	, main_buffer			(NULL)
	, th_dist_st			(NULL)
	, sy_dist_st			(NULL)
	, st_dist_st			(NULL)
	, th_dist				(NULL)
	, sy_dist				(NULL)
	, st_dist				(NULL)
{
}
     
bool Thematics::index_setup (Language &_lang, char *charenc, const size_t min_word_len, bool showthematics)
{
	string confpath(CONF_COLLECTION_BASE);

	// inizializzo i valori dichiarati staticamente dentro la classe
	language = _lang;
	first_stem_uid = 0;
	src_stem_uid = 0;
	dst_stem_uid = 0;
	are_synonyms = 0;
	left_wordform_uid = 0;
	wordformsmax = 0;
	mcline = 0;
	mcrule = 0;
	msline = 0;

	// apertura degli indici
	index_open();

	string null_string = "null";
	themid_t themid = 0;
	// inserimento stringa tematica fittizia, utile nel caso non si usi la tematica
	themidx_resolve_them( null_string.c_str(), null_string.c_str(), &(themid), false );

	cerr << "Make thematics index ..." << endl;

	// struttura che contiene l'associazione tra i termini wordforms nella colonna a sinistra e quelli della colonna di destra
	wordform_struct = CBALLOC(wordforms_t, MALLOC, MAXWORDS);

	for (stemid_t i = 1; i < MAXWORDS; i++)
	{
		wordform_struct[i].master_wordform_uid = 0;
	}

	char *la = lower_lang();

	/* prepare stemming process: */
	stemmer = sb_stemmer_new(la, charenc);

	if (stemmer == NULL)
		die("unknown stemmer libstemmer_%s", la);

	free(la);

	string wordforms_filename = (confpath + "/" + "wordforms.txt");

	master_wordform = false;

	if (wordforms_filename.length() > 0)
	{
		unsigned int length;
		char *inbuf = NULL;
	
		ifstream inFile;  //input file stream variable
		inFile.open(wordforms_filename); //open the input file
	
	 	if (inFile)
		{	
		// posiziona in cursore alla fine del file per rilevarne la lunghezza per poi riposizionarlo all'inizio:
			inFile.seekg (0, ios::end);
			length = inFile.tellg();
			inFile.seekg (0, ios::beg);
		
			// alloca la memoria del inbuf:
			inbuf = CBALLOC(char, MALLOC, (length + 1));
		
			// legge i dati in un unico blocco:
			inFile.read (inbuf,length);
			inbuf[length] = ASCII_NUL;
	
			//cout.write (inbuf,length);
			unsigned short nc = 0;

			//copio i dati del file ad il puntatore di puntatori pwt
			for (size_t i = 0; i < length; i++)
			{
				if (inbuf[i] == '>')
				{
						i++;

					master_wordform = true;
				}

				static char temparray[MAX_STR_LEN] = {ASCII_NUL};

				if (i == (length - 1))
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					makeWordforms(temparray, min_word_len);

					nc = 0;
				}
				else if (inbuf[i] != '\n' && inbuf[i] != ' ')
				{
					temparray [nc++] = inbuf[i];
				}
				else
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					makeWordforms(temparray, min_word_len);

					if (inbuf[i] == '\n')
						master_wordform = false;

					nc = 0;
				}
			}
			inFile.close();
			free (inbuf);
		}
		else
		{
			cerr << "Error: file " << wordforms_filename << " not found!" << endl;
			sb_stemmer_delete(stemmer);
			free (wordform_struct);
			index_close(false);
			return false;
		}
	}

	string synonyms_filename = (confpath + "/" + "synonyms.txt");

	if (synonyms_filename.length() > 0)
	{
		unsigned int length;
		char *inbuf = NULL;
		unsigned int synonyms_buffer_count = 0;
		unsigned int synonyms_buffer_lines = 0;
	
		ifstream inFile;  //input file stream variable
		inFile.open(synonyms_filename); //open the input file
	
	 	if (inFile)
		{	
		// posiziona in cursore alla fine del file per rilevarne la lunghezza per poi riposizionarlo all'inizio:
			inFile.seekg (0, ios::end);
			length = inFile.tellg();
			inFile.seekg (0, ios::beg);
		
			// alloca la memoria del inbuf:
			inbuf = CBALLOC(char, MALLOC, (length + 1));
		
			// legge i dati in un unico blocco:
			inFile.read (inbuf,length);
			inbuf[length] = ASCII_NUL;

			// determino in maniera approssimativa (ma in eccesso) la quantità di wordid da inserire in synonyms_buffer
			for (size_t i = 0; i < length; i++)
			{
					if (i == 0)
						synonyms_buffer_count++;
					else if (isalpha(inbuf[i]) && (inbuf[i - 1] == ' ' || inbuf[i - 1] == '\n'))
						synonyms_buffer_count++;

					if (i > 0 && (inbuf[i - 1] == '\n' || inbuf[i - 1] == ASCII_NUL))
						synonyms_buffer_lines++;
			}

			synonyms_buffer_lines++;

			synonyms_buffer = CBALLOC(char, MALLOC, (length * sizeof(wordid_t)));

			line_synonyms_structs = CBALLOC(line_synonyms_t, MALLOC, synonyms_buffer_lines);

			// line_synonyms_structs[0].line_offset = 0;

			//cout.write (inbuf,length);
			unsigned short nc = 0;

			unsigned short line = 0;

			unsigned int word_counter = 0;

			//copio i dati del file ad il puntatore di puntatori pwt
			for (size_t i = 0; i < length; i++)
			{
				// P.S. nel file dei sinonimi non sono consentiti commenti o linee vuote

				static char temparray[MAX_STR_LEN] = {ASCII_NUL};

				if (i == (length - 1))
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					makeSynonyms(temparray, synonyms_buffer, min_word_len, line);

					if (word_counter == 0)
						strcpy(synonyms_buffer, temparray);
					else
						strcat(synonyms_buffer, temparray);

					word_counter++;

					if (nc > 0)
						strcat(synonyms_buffer, " ");

					nc = 0;
				}
				else if (inbuf[i] != '\n' && inbuf[i] != ' ')
				{
					temparray [nc++] = inbuf[i];
					temparray [nc] = ASCII_NUL;
				}
				else
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					makeSynonyms(temparray, synonyms_buffer, min_word_len, line);

					if (word_counter == 0)
						strcpy(synonyms_buffer, temparray);
					else
						strcat(synonyms_buffer, temparray);

					word_counter++;

					if (inbuf[i] == '\n')
					{
						if (line > UINT_MAX)
							die ("Error: Too many lines in configuration file of synonyms!");
						else
							line++;
					}

					if (nc > 0)
						strcat(synonyms_buffer, " ");

					nc = 0;
				}
			}
			inFile.close();
			free (inbuf);
		}
		else
		{
			cerr << "Error: file " << synonyms_filename << " not found!" << endl;
			sb_stemmer_delete(stemmer);
			free (wordform_struct);
			index_close(false);
			return false;
		}
	}

	string config_filename = (confpath + "/" + "contexts.conf");

	if (config_filename.length() > 0)
	{
		unsigned int length;
		char *inbuf = NULL;
	
		ifstream inFile;  //input file stream variable
		inFile.open(config_filename); //open the input file

	 	if (inFile)
		{	
		// posiziona in cursore alla fine del file per rilevarne la lunghezza per poi riposizionarlo all'inizio:
			inFile.seekg (0, ios::end);
			length = inFile.tellg();
			inFile.seekg (0, ios::beg);
		
			// alloca la memoria del inbuf:
			inbuf = CBALLOC(char, MALLOC, (length + 1));
		
			// legge i dati in un unico blocco:
			inFile.read (inbuf,length);
			inbuf[length] = ASCII_NUL;
	
			//cout.write (inbuf,length);
			unsigned short nc = 0;

			unsigned short line = 0;

			thematics_counter = 0;

			synonyms_counter = 0;

			stemming_counter = 0;

			terms_count = 0;

			bool thematic_check = true;
			bool is_thematic = false;

			size_t them_buffer_len = 0;

			size_t stem_buffer_len = 0;

			// creo gli indici delle tematiche e degli stemming dei termini dei contesti (quelli dopo la '|')
			for (size_t i = 0; i < length; i++)
			{

				if ((synonyms_counter + 2) == UINT_MAX)
					die("Too many synonyms parameters in context comfiguration file.\nExit forced!");

				if (inbuf[i] == '#')
				{
					while (inbuf[i] != '\n' && inbuf[i] != ASCII_NUL)
						i++;

					line++;

					continue;
				}

				if (inbuf[i] == '+')
				{
					while (inbuf[i] == '+' || inbuf[i] == ' ')
						i++;

					thematic_check = false;

					are_synonyms = true;
				}
				else if (inbuf[i] == '|')
				{
					while (inbuf[i] == '|' || inbuf[i] == ' ')
						i++;

					thematic_check = false;

					are_synonyms = false;
				}

				static char temparray[MAX_STR_LEN] = {ASCII_NUL};


				if (i == (length - 1))
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != ASCII_NUL)
						mcrule++;

						if (thematic_check == true)
							is_thematic = true;

						mcline = line;
					}

					if (is_thematic == true)
					{
						makeContexts(temparray, min_word_len, is_thematic, false);

						them_buffer_len += nc;

						is_thematic = false;

						thematics_counter++;
					}
					else if (are_synonyms == false)
					{
						makeContexts(temparray, min_word_len, is_thematic, false);

						stem_buffer_len += nc;

						stemming_counter++;
					}
					else if (are_synonyms == true && isdigit(temparray[0]))
						synonyms_counter++;

					first_stem_uid = 0;

					are_synonyms = false;

					terms_count++;

					nc = 0;
				}
				else if (inbuf[i] != '\n' && inbuf[i] != ' ')
				{
					temparray [nc++] = inbuf[i];
				}
				else
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != ASCII_NUL)
						mcrule++;

						if (thematic_check == true)
							is_thematic = true;

						mcline = line;
					}

					if (is_thematic == true)
					{
						makeContexts(temparray, min_word_len, is_thematic, false);

						them_buffer_len += nc;

						is_thematic = false;

						thematics_counter++;
					}
					else if (are_synonyms == false)
					{
						makeContexts(temparray, min_word_len, is_thematic, false);

						stem_buffer_len += nc;

						stemming_counter++;
					}
					else if (are_synonyms == true && isdigit(temparray[0]))
						synonyms_counter++;

					if (inbuf[i] == '\n')
					{
						if (line >= UINT_MAX)
							die ("Error: Too many lines in configuration file of contexts!");
						else
							line++;

						first_stem_uid = 0;
						are_synonyms = false;
						thematic_check = true;
					}

					terms_count++;

					nc = 0;
				}
			}

			// ora che si conosce la quantità di regole nel file principale si possono creare le strutture necessarie a ricavare gli offset in main_buffer
			main_structs = CBALLOC(main_t, MALLOC, mcrule);
		
			main_buffer = CBALLOC(context_t, MALLOC, terms_count);

			// si impostano i valori iniziali delle strutture 'main_t' puntate da main_struct
			// la prima struttura puntata NON si utilizza in quanto corrisponderebbe al stemid '0'!
			for (unsigned short i = 0; i < mcrule; i++)
			{
				main_structs[i].rule_offset = 0;
				main_structs[i].thematic = 0;
				main_structs[i].terms = 0;
			}

			line = 0;
			mcline = 0;
			mcrule = 0;

			terms_counter = 0;

			thematic_check = true;
			is_thematic = false;

			// popola il buffer principale (main_buffer) che incorpora la configurazione nel formato della struttura tipo context_t
			for (size_t i = 0; i < length; i++)
			{
				if (inbuf[i] == '#')
				{
					while (inbuf[i] != '\n' && inbuf[i] != ASCII_NUL)
						i++;

					line++;

					continue;
				}

				if (inbuf[i] == '+')
				{
					while (inbuf[i] == '+' || inbuf[i] == ' ')
						i++;

					thematic_check = false;

					are_synonyms = true;
				}
				else if (inbuf[i] == '|')
				{
					while (inbuf[i] == '|' || inbuf[i] == ' ')
						i++;

					thematic_check = false;

					are_synonyms = false;
				}

				static char temparray[MAX_STR_LEN] = {ASCII_NUL};

				// setto la struttura puntata ai valori iniziali
				main_buffer[terms_counter].rule = false;
				main_buffer[terms_counter].is_synonyms = false;
				main_buffer[terms_counter].is_thematic = false;
				main_buffer[terms_counter].generic_id = (stemid_t)0;

				if (i == (length - 1))
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != ASCII_NUL)
						{
							mcrule++;
							main_structs[(mcrule - 1)].rule_offset = terms_counter;
						}

						if (thematic_check == true)
							is_thematic = true;
						
						mcline = line;
					}

					if (is_thematic == true)
					{
						makeContexts(temparray, min_word_len, is_thematic, true);
						is_thematic = false;

						// Le tematiche non vengono contate come termini (vedi esempio opposto sotto)
					}
					else if (are_synonyms == false)
					{
						makeContexts(temparray, min_word_len, is_thematic, true);
						main_structs[(mcrule - 1)].terms++;

						if (main_structs[(mcrule - 1)].terms < USHRT_MAX)
							main_structs[(mcrule - 1)].terms++;
						else
						{
							cerr << "Error: Too many terms in configuration file of contexts at rule ";
							cerr << (mcrule - 1) << " (line " << mcline << ')' << endl;
						}
					}
					else if (are_synonyms == true && isdigit(temparray[0]))
					{
							int tempint = atoi(temparray);
	
							if (tempint <= 0 || tempint >= USHRT_MAX)
							{
								cerr << "Error: Invalid synonyms line in configuration file of contexts at rule ";
								cerr << mcrule << " (line " << mcline << ')' << endl;
								sb_stemmer_delete(stemmer);
								free (wordform_struct);
								index_close(false);
								free (synonyms_buffer);
								free (line_synonyms_structs);
								free (main_buffer);
								free (main_structs);
								return false;
							}
							else
							{
								main_buffer[terms_counter].rule = mcrule;
								main_buffer[terms_counter].is_synonyms = true;
								main_buffer[terms_counter].generic_id = (stemid_t)(tempint - 1);

								terms_counter++;

								if (main_structs[(mcrule - 1)].terms < USHRT_MAX)
									main_structs[(mcrule - 1)].terms++;
								else
								{
									cerr << "Error: Too many terms in configuration file of contexts at rule ";
									cerr << (mcrule - 1) << " (line " << mcline << ')' << endl;
									sb_stemmer_delete(stemmer);
									free (wordform_struct);
									index_close(false);
									free (synonyms_buffer);
									free (line_synonyms_structs);
									free (main_buffer);
									free (main_structs);
									return false;
								}
							}
					}

					first_stem_uid = 0;

					are_synonyms = false;

					nc = 0;
				}
				else if (inbuf[i] != '\n' && inbuf[i] != ' ')
				{
					temparray [nc++] = inbuf[i];
				}
				else
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != ASCII_NUL)
						{
							mcrule++;
							main_structs[(mcrule - 1)].rule_offset = terms_counter;
						}

						if (thematic_check == true)
							is_thematic = true;

						mcline = line;
					}

					if (is_thematic == true)
					{
						makeContexts(temparray, min_word_len, is_thematic, true);
						is_thematic = false;

						// Le tematiche non vengono contate come termini (vedi esempio opposto sotto)
					}
					else if (are_synonyms == false)
					{
						makeContexts(temparray, min_word_len, is_thematic, true);

						if (main_structs[(mcrule - 1)].terms < USHRT_MAX)
							main_structs[(mcrule - 1)].terms++;
						else
						{
							cerr << "Error: Too many terms in configuration file of contexts at rule ";
							cerr << (mcrule - 1) << " (line " << mcline << ')' << endl;
						}
					}
					else if (are_synonyms == true && isdigit(temparray[0]))
					{
							int tempint = atoi(temparray);
	
							if (tempint <= 0 || tempint >= USHRT_MAX)
							{
								cerr << "Error: Invalid synonyms line in configuration file of contexts at rule ";
								cerr << (mcrule - 1) << " (line " << mcline << ')' << endl;
								sb_stemmer_delete(stemmer);
								free (wordform_struct);
								index_close(false);
								free (synonyms_buffer);
								free (line_synonyms_structs);
								free (main_buffer);
								free (main_structs);
								return false;
							}
							else
							{
								main_buffer[terms_counter].rule = (mcrule - 1);
								main_buffer[terms_counter].is_synonyms = true;
								main_buffer[terms_counter].generic_id = (stemid_t)(tempint - 1);

								terms_counter++;

								if (main_structs[(mcrule - 1)].terms < USHRT_MAX)
									main_structs[(mcrule - 1)].terms++;
								else
								{
									cerr << "Error: Too many terms in configuration file of contexts at rule ";
									cerr << (mcrule - 1) << " (line " << mcline << ')' << endl;
									sb_stemmer_delete(stemmer);
									free (wordform_struct);
									index_close(false);
									free (synonyms_buffer);
									free (line_synonyms_structs);
									free (main_buffer);
									free (main_structs);
									return false;
								}
							}
					}

					if (inbuf[i] == '\n')
					{
						if (line >= UINT_MAX)
							die ("Error: Too many lines in configuration file of contexts!");
						else
							line++;

						first_stem_uid = 0;
						are_synonyms = false;
						thematic_check = true;
					}

					nc = 0;
				}
			}

			inFile.close();
			free (inbuf);

			th_dist_st = CBALLOC(thematic_vs_main_rules_t, MALLOC, (openidx->them_count + 1));

			th_dist = CBALLOC(unsigned short, MALLOC, thematics_counter);

			thematics_counter = 0;

			// il themid '0' non si utilizza
			th_dist_st[0].th_dist_offset = (unsigned int)UINT_MAX;

			// crea lo schema di distribuzione nelle regole (rules) del main_buffer, delle tematiche
			for (themid_t themid = 1; themid <= openidx->them_count; themid++)
			{
				bool isoffset = true;

				th_dist_st[themid].th_dist_offset = (unsigned int)UINT_MAX;

				unsigned int old_th_dist_offset = (unsigned int)UINT_MAX;

				if (themid > 1)
					old_th_dist_offset = th_dist_st[themid - 1].th_dist_offset;

				for (unsigned long int i = 0; i < terms_counter; i++)
				{
					if (main_buffer[i].is_thematic == true && main_buffer[i].generic_id == themid)
					{
						if (isoffset == true)
						{
							th_dist_st[themid].th_dist_offset = thematics_counter;

							if ((th_dist_st[themid].th_dist_offset - old_th_dist_offset) >= UCHAR_MAX)
							{
								char *thematic = CBALLOC(char, MALLOC, (MAX_WORD_LEN + 1));

								themidx_them_by_themid(themid, thematic);

								cerr << "Too many rule for thematic " << thematic << " in main configuration file!" << endl;

								free(thematic);
								sb_stemmer_delete(stemmer);
								free (wordform_struct);
								index_close(false);
								free (synonyms_buffer);
								free (line_synonyms_structs);
								free (main_buffer);
								free (main_structs);
								free (th_dist_st);
								free (th_dist);
								return false;
							}

							isoffset = false;
						}

						th_dist[thematics_counter] = main_buffer[i].rule;
						thematics_counter++;
					}
							
				}	
			}

			sy_dist_st = CBALLOC(synonyms_vs_main_rules_t, MALLOC, (msline + 1));

			sy_dist = CBALLOC(idx_id_vs_rules_t, MALLOC, synonyms_counter);

			synonyms_counter = 0;

			// crea lo schema di distribuzione nelle regole (rules) del main_buffer, dei sinonimi
			for (unsigned short syn_line = 0; syn_line <= msline; syn_line++)
			{
				bool isoffset = true;

				sy_dist_st[syn_line].sy_dist_offset = (unsigned int)UINT_MAX;
				sy_dist_st[syn_line].amount_rules = 0;

				for (unsigned long int i = 0; i < terms_counter; i++)
				{
					if (main_buffer[i].is_synonyms == true && main_buffer[i].is_thematic == false && main_buffer[i].generic_id == syn_line)
					{
						if (isoffset == true)
						{
							sy_dist_st[syn_line].sy_dist_offset = synonyms_counter;
							isoffset = false;
						}

						sy_dist[synonyms_counter].rule = main_buffer[i].rule;
						sy_dist[synonyms_counter].location_coefficient = 1;

						if (sy_dist_st[syn_line].amount_rules < UCHAR_MAX)
							sy_dist_st[syn_line].amount_rules++;
						else
						{
							cerr << "Too many terms at line " << syn_line << " of synonyms file." << endl;
							sb_stemmer_delete(stemmer);
							free (wordform_struct);
							index_close(false);
							free (synonyms_buffer);
							free (line_synonyms_structs);
							free (main_buffer);
							free (main_structs);
							free (th_dist_st);
							free (th_dist);
							free (sy_dist_st);
							free (sy_dist);
							return false;
						}

						synonyms_counter++;
					}
							
				}	
			}

			st_dist_st = CBALLOC(stemming_vs_main_rules_t, MALLOC, (openidx->stem_count + 1));

			st_dist = CBALLOC(idx_id_vs_rules_t, MALLOC, stemming_counter);

			stemming_counter = 0;

			// lo stemid '0' non si utilizza
			st_dist_st[0].st_dist_offset = (unsigned int)UINT_MAX;

			// crea lo schema di distribuzione nelle regole (rules) del main_buffer, degli stemming
			for (stemid_t stemid = 1; stemid <= openidx->stem_count; stemid++)
			{
				bool isoffset = true;

				st_dist_st[stemid].st_dist_offset = (unsigned int)UINT_MAX;

				unsigned int old_st_dist_offset = (unsigned int)UINT_MAX;

				if (stemid > 1)
					old_st_dist_offset = st_dist_st[stemid - 1].st_dist_offset;
				else
					old_st_dist_offset = 0;

				for (unsigned long int i = 0; i < terms_counter; i++)
				{
					if (main_buffer[i].is_synonyms == false && main_buffer[i].is_thematic == false && main_buffer[i].generic_id == stemid)
					{
						if (isoffset == true)
						{
							st_dist_st[stemid].st_dist_offset = stemming_counter;

							if ((st_dist_st[stemid].st_dist_offset - old_st_dist_offset) >= UCHAR_MAX)
							{

								char *stemming = CBALLOC(char, MALLOC, (MAX_WORD_LEN + 1));

								themidx_stem_by_stemid(stemid, stemming);

								cerr << "Too many rule for stemming " << stemming << " in main configuration file!" << endl;

								free (stemming);
								sb_stemmer_delete(stemmer);
								free (wordform_struct);
								index_close(false);
								free (synonyms_buffer);
								free (line_synonyms_structs);
								free (main_buffer);
								free (main_structs);
								free (th_dist_st);
								free (th_dist);
								free (sy_dist_st);
								free (sy_dist);
								free (st_dist_st);
								free (st_dist);
								return false;

								exit(1);
							}

							isoffset = false;
						}

						st_dist[stemming_counter].rule = main_buffer[i].rule;
						stemming_counter++;
					}
							
				}	
			}

			// calcolo coefficenti distribuzione stemming dei contesti
			for (stemid_t stemid = 1; stemid <= openidx->stem_count; stemid++)
				if (st_dist_st[stemid].st_dist_offset < UINT_MAX)
				{
					unsigned char amount_rules = 0;

					if (stemid < openidx->stem_count)
						amount_rules = (st_dist_st[stemid + 1].st_dist_offset - st_dist_st[stemid].st_dist_offset);
					else
						amount_rules = (stemming_counter - st_dist_st[stemid].st_dist_offset);

					struct them {
						themid_t thematic;
						unsigned short count;
					} *thems = CBALLOC(them, MALLOC, amount_rules);

					bool found = false;

					unsigned char pos = 0;

					for (unsigned char a = 0; a < amount_rules; a++)
						thems[a].thematic = 0;

					for (unsigned char a = 0; a < amount_rules; a++)
					{
						for (unsigned char b = 0; b < amount_rules; b++)
						{
							if (thems[b].thematic == main_structs[st_dist[(st_dist_st[stemid].st_dist_offset + a)].rule].thematic)
							{
								found = true;
								thems[b].count++;
								break;
							}
						}

						if (found == false)
						{
							thems[pos].thematic = main_structs[st_dist[(st_dist_st[stemid].st_dist_offset + a)].rule].thematic;

							thems[pos].count = 1;
							pos++;
						}
						else
							found = false;
					}

					unsigned short ttfs = 0; // total thematics for stemid

					for (unsigned char a = 0; a < amount_rules && thems[a].thematic > 0; a++)
						ttfs++;
						
					for (unsigned char a = 0; a < amount_rules; a++)
					{
						themid_t thematic = main_structs[st_dist[(st_dist_st[stemid].st_dist_offset + a)].rule].thematic;

						unsigned char them_address = 0;

						for (them_address = 0; them_address < amount_rules && thems[them_address].thematic > 0; them_address++)
							if (thematic == thems[them_address].thematic)
								break;

						// se la tematica è 'null' non si calcola la distribuzione dentro la tematica nulla
						if (thematic == (themid_t)1) // null
							st_dist[(st_dist_st[stemid].st_dist_offset + a)].location_coefficient = ttfs;
						else
							st_dist[(st_dist_st[stemid].st_dist_offset + a)].location_coefficient = ttfs * thems[them_address].count;
					}
/*// uso debug
					//char *ppp = (char *) malloc (MAX_WORD_LEN * sizeof(char));
					//themsidx_stem_by_stemid(stemid, ppp);
					//cout << endl;
					//free (ppp);
*/////
					free (thems);
				}


			// distingue le linee di sinonimi presenti nel main file e no
			cerr << "Removing unused synonyms from hash" << endl; 
			
			unsigned short *synonyms_used_lines = CBALLOC(unsigned short, MALLOC, terms_counter);
			unsigned int sil_offset = 0;
			
			for (unsigned short s = 0; s < terms_counter; s++)
			{
				if (main_buffer[s].is_thematic == false)
					if (main_buffer[s].is_synonyms == true)
					{
						synonyms_used_lines[sil_offset] = main_buffer[s].generic_id;
						sil_offset++;
					}
						
			}
			
			//cout << "elenco tutti gli elementi dell'hash: " << endl;
			//for (iter_map_syn = map_synonyms.begin(); iter_map_syn != map_synonyms.end(); ++iter_map_syn)
			//	cout << "map[ " << iter_map_syn->first << " ] = " << iter_map_syn->second << ";\n";
			
			for (iter_map_syn = map_synonyms.begin(); iter_map_syn != map_synonyms.end(); ++iter_map_syn)
			{
				bool found_synonmys = false;
			
				for (unsigned int i = 0; i < sil_offset; i++)
				{
					if (synonyms_used_lines[i] == iter_map_syn->second.line)
					{
						found_synonmys = true;
						break;
					}
				}
			
				if (found_synonmys == true)
					map_synonyms[iter_map_syn->first] = {false, iter_map_syn->second.line}; // la mappa completa (popolata quì) dei sinonimi serve per l'elaborazione dei termini sensibili
			}
			
			free (synonyms_used_lines);
			// fine distinzione sinonimi
			
			// calcolo coefficenti distribuzione sinonimi DA FARE
			for (unsigned short syn_line = 1; syn_line <= msline; syn_line++)
			{
				unsigned char amount_rules = sy_dist_st[syn_line].amount_rules;

				if (amount_rules > 0 && sy_dist_st[syn_line].sy_dist_offset < UINT_MAX)
				{
					struct them {
						themid_t thematic;
						unsigned short count;
					} *thems = CBALLOC(them, MALLOC, amount_rules);

					bool found = false;

					unsigned char pos = 0;

					for (unsigned char a = 0; a < amount_rules; a++)
						thems[a].thematic = 0;

					// conta su quante tematiche è distribuita la linea di sinonimi	
					for (unsigned char a = 0; a < amount_rules; a++)
					{
						for (unsigned char b = 0; b < amount_rules; b++)
						{
							if (thems[b].thematic == main_structs[sy_dist[(sy_dist_st[syn_line].sy_dist_offset + a)].rule].thematic)
							{
								found = true;
								thems[b].count++;
								break;
							}
						}

						if (found == false)
						{
							thems[pos].thematic = main_structs[sy_dist[(sy_dist_st[syn_line].sy_dist_offset + a)].rule].thematic;

							thems[pos].count = 1;
							pos++;
						}
						else
							found = false;
					}

					unsigned short ttfs = 0; // total thematics for syn_line

					for (unsigned char a = 0; a < amount_rules && thems[a].thematic > 0; a++)
						ttfs++;
						
					for (unsigned char a = 0; a < amount_rules; a++)
					{
						themid_t thematic = main_structs[sy_dist[(sy_dist_st[syn_line].sy_dist_offset + a)].rule].thematic;

						unsigned char them_address = 0;

						for (them_address = 0; them_address < amount_rules && thems[them_address].thematic > 0; them_address++)
							if (thematic == thems[them_address].thematic)
								break;

						// se la tematica è 'null' non si calcola la distribuzione dentro la tematica nulla
						if (thematic == (themid_t)1) // null
							sy_dist[(sy_dist_st[syn_line].sy_dist_offset + a)].location_coefficient = ttfs;
						else
							sy_dist[(sy_dist_st[syn_line].sy_dist_offset + a)].location_coefficient = ttfs * thems[them_address].count;
					}
					free (thems);
				}
			}
			/*/// debug
			for (unsigned short s = 0; s <= msline; s++)
				if (sy_dist_st[s].sy_dist_offset < UINT_MAX)
						cout << "Synonsys line " << s << " offset of rule start in main_buffer "
						<< sy_dist_st[s].sy_dist_offset << " rules " << (int)sy_dist_st[s].amount_rules << endl;

			for (stemid_t stemid = 1; stemid <= openidx->stem_count; stemid++)
				if (st_dist_st[stemid].st_dist_offset < UINT_MAX)
						cout << "Stemming id " << stemid << " offset of rule start in main_buffer "
						<< st_dist_st[stemid].st_dist_offset << endl;

			for (themid_t themid = 1; themid <= openidx->them_count; themid++)
				if (th_dist_st[themid].th_dist_offset < UINT_MAX)
						cout << "Thematic id " << themid << " offset of rule start in main_buffer "
						<< th_dist_st[themid].th_dist_offset << endl;
			*//// fine debug //
		}
		else
		{
			cerr << "Error: file " << config_filename << " not found!" << endl;
			sb_stemmer_delete(stemmer);
			free (wordform_struct);
			index_close(false);
			free (synonyms_buffer);
			free (line_synonyms_structs);
			free (main_buffer);
			free (main_structs);
			free (th_dist_st);
			free (th_dist);
			free (sy_dist_st);
			free (sy_dist);
			free (st_dist_st);
			free (st_dist);
			return false;
		}
	}

	// se è stata scelta la relativa opzione in combinazione con 'debugonly' stampa le tematiche ed esce immediatamente
	if (showthematics == true)
	{
		cerr << "Print thematics and exit..." << endl;
		char *stemname = CBALLOC(char, MALLOC, MAX_WORD_LEN);
		stemname[0] = ASCII_NUL;
		char *dstname = CBALLOC(char, MALLOC, MAX_WORD_LEN);
		dstname[0] = ASCII_NUL;
		char *thematic = CBALLOC(char, MALLOC, MAX_WORD_LEN);
		thematic[0] = ASCII_NUL;
		char *wordname = CBALLOC(char, MALLOC, MAX_WORD_LEN);
		wordname[0] = ASCII_NUL;

		unsigned short oldrule = 0;
		bool synonyms = false;
		bool stemming = false;

		for (unsigned short s = 0; s < terms_counter; s++)
		{
			if (s == 0)
				cout << "regola 0 ";

			if (main_buffer[s].rule > oldrule)
			{
				cout << endl;
				oldrule = main_buffer[s].rule;
				cout << "regola " << main_buffer[s].rule << ' ';
				synonyms = false;
				stemming = false;
			}

			if (main_buffer[s].is_thematic == true)
			{
				char *thematic = CBALLOC(char, MALLOC, (MAX_WORD_LEN + 1));

				themidx_them_by_themid(main_buffer[s].generic_id, thematic);

				cout << thematic;

				free (thematic);

				cout << ' ';
			}
			else if (main_buffer[s].is_thematic == false)
			{
				if (main_buffer[s].is_synonyms == true)
				{
					size_t start = 0;
					size_t end = 0;

					if (main_buffer[s].generic_id == 0)
						start = 0;
					else
						start = line_synonyms_structs[main_buffer[s].generic_id].line_offset;

					if (main_buffer[s].generic_id < msline)
						end = line_synonyms_structs[(main_buffer[s].generic_id + 1)].line_offset;
					else
						end = strlen(synonyms_buffer);

					if (synonyms == false)
					{
						cout << "+ ";
						synonyms = true;
					}

					for (size_t o = start; o < end; o++)
						cout << synonyms_buffer[o];
				}
				else
				{
					if (stemming == false)
					{
						cout << '|';
						stemming = true;
					}

					char *original = CBALLOC(char, MALLOC, (MAX_WORD_LEN + 1));

					themidx_stem_by_stemid(main_buffer[s].generic_id, original);

					cout << ' ' << original;

					free (original);
				}
			}
			//	cout << ' ' << main_buffer[s].generic_id << endl;
		}

		cout << endl;

		free (stemname);
		free (dstname);
		free (thematic);
		free (wordname);

		return true;
	}

	return true;
}

//
// Name: Thematics::makeWordforms 
//
// Description: Riceve i termini wordforms dal file wordforms.txt e crea la struttura dei termini wordforms (ai termini wordforms non viene applicato stemming)
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola.
//
void Thematics::makeWordforms(char *ptext, const size_t min_word_len)
{
	size_t textlen = strlen(ptext);

	// rimuove eventuali spazi in coda
	while (ptext[textlen - 1] == ' ' && textlen > 0)
		textlen--;

	size_t pos = 0;
	size_t toffstart = 0;
	size_t toffstop = 0;
	bool found = false;
	bool single_char = false;

	if (((int)textlen - (int)min_word_len) >= 0)
	do
	{
		while (isalpha(ptext[pos]) && pos < textlen)
		{
			pos++;

			found = true;
		}

		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(ptext[pos]) == false) && isalpha(ptext[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(ptext[pos]) == false)))
					toffstop = (pos - 1);
				else if (pos == (textlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			char *pword = printWord(ptext, toffstart, (toffstop + 1), true);

			wordid_t wordid = 0;

			themidx_status_t wrc = THEMIDX_ERROR;

			if (((toffstop + 1) - toffstart) < MAX_WORD_LEN && ((toffstop + 1) - toffstart) > min_word_len)
			{
				// quì va salvato tutto
				wrc = themidx_resolve_word( pword, &(wordid), false );

				if ( wrc == THEMIDX_CREATED_WORD )
					wordformsmax++;

				if ( ! (wrc == THEMIDX_CREATED_WORD) && master_wordform == false)
				{
					cerr << "Error: '" << pword << "' is duplicated with id " << wordid << endl;
					die ("Check error in wordforms file!");
					
				}
				else
				{
					if (master_wordform == true)
						wordform_struct[left_wordform_uid].master_wordform_uid = wordid;

					if (master_wordform == true && wrc == THEMIDX_CREATED_WORD)
						wordform_struct[wordid].master_wordform_uid = wordid;

					if (left_wordform_uid == 0)
						left_wordform_uid = wordid;
					else
						left_wordform_uid = 0;
				}
			}
			free (pword);
		}

		while ((isalpha(ptext[pos]) == false) && pos < (textlen - min_word_len))
			pos++;

		toffstart = pos;

		found = false;
		single_char = false;
	}
	while (pos++ < (textlen - min_word_len));
}

//
// Name: Thematics::makeSynonyms 
//
// Description: Riceve i termini sinonimi dal file synonyms.txt e crea la struttura dei sinonimi, i termini sinonimi vengono accodati all'indice delle parole.
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola.
//
void Thematics::makeSynonyms(char *ptext, char *synonyms_buffer, const size_t min_word_len, unsigned short line)
{
	// conta le righe di configurazione valide del file dei sinonimi
	if (msline < line)
	{
		msline = line;

		// salva l'offset dove inizia ogni regola nel puntatore che contiene i wordid dei relativi termini nel file dei sinonimi
		line_synonyms_structs[msline].line_offset = strlen(synonyms_buffer);
	}

	size_t textlen = strlen(ptext);

	// rimuove eventuali spazi in coda
	while (ptext[textlen - 1] == ' ' && textlen > 0)
		textlen--;

	size_t pos = 0;
	size_t toffstart = 0;
	size_t toffstop = 0;
	bool found = false;
	bool single_char = false;

	if (((int)textlen - (int)min_word_len) >= 0)
	do
	{
		while (isalpha(ptext[pos]) && pos < textlen)
		{
			pos++;

			found = true;
		}

		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(ptext[pos]) == false) && isalpha(ptext[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(ptext[pos]) == false)))
					toffstop = (pos - 1);
				else if (pos == (textlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			char *pword = printWord(ptext, toffstart, (toffstop + 1), true);

			themidx_status_t wrc = THEMIDX_ERROR;

			wordid_t wordid = 0;

			if (((toffstop + 1) - toffstart) < MAX_WORD_LEN && ((toffstop + 1) - toffstart) > min_word_len)
			{
				// quì va salvato tutto
				wrc = themidx_resolve_word( pword, &(wordid), true );

				if ( wrc == THEMIDX_EXISTENT)
				{
					if (wordid <= wordformsmax)
						map_synonyms[wordform_struct[wordid].master_wordform_uid] = {true, msline};
					else
					{
						cerr << "Error: '" << pword << "' is duplicated with id " << wordid << endl;
						die ("Check error in synonyms file!");
					}
				}
				else
				{
					size_t pword_len = strlen(pword);

					// N.B. il file dei sinonimi non gestisce accenti
					char *stemming = doBaseStemming(pword, pword_len, (pword_len + 1));

					wrc = themidx_resolve_word( stemming, &(wordid), false );

					free (stemming);

					if ( wrc == THEMIDX_CREATED_WORD && wordid > wordformsmax )
						map_synonyms[wordid] = {true, msline}; // i strutture per i valori le accetta 'solo' in questo modo
				}
			}
			free (pword);
		}

		while ((isalpha(ptext[pos]) == false) && pos < (textlen - min_word_len))
			pos++;

		toffstart = pos;

		found = false;
		single_char = false;
	}
	while (pos++ < (textlen - min_word_len));
}

//
// Name: Thematics::makeContexts 
//
// Description: Riceve i contesti ed eventuali tematiche dal file di configurazione principale contexts.conf e crea la struttura dei contesti
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola, numero linea nel file.
//
void Thematics::makeContexts(char *ptext, const size_t min_word_len, bool is_thematic, bool append_buffer)
{
	size_t textlen = strlen(ptext);

	// rimuove eventuali spazi in coda
	while (ptext[textlen - 1] == ' ' && textlen > 0)
		textlen--;

	size_t pos = 0;
	size_t toffstart = 0;
	size_t toffstop = 0;
	bool found = false;
	bool single_char = false;

	if (((int)textlen - (int)min_word_len) >= 0)
	do
	{
		while ((isalpha(ptext[pos]) || convSpecialChar(ptext, textlen, pos) != ' ') && pos < textlen)
		{
			if (convSpecialChar(ptext, textlen, pos) != ' ')
				pos += 2;
			else
				pos++;

			found = true;
		}

		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(ptext[pos]) == false) && isalpha(ptext[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(ptext[pos]) == false) && convSpecialChar(ptext, textlen, pos) == ' '))
					toffstop = (pos - 1);
				else if (pos == (textlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			bool eccezione_carattere = false; // quasi tutte le vocali e consonanti seguite da apostrofo

			char *pword = printWord(ptext, toffstart, (toffstop + 1), true);

			size_t reallength = strlen(pword); // nel caso il termine originale contiene lettere 'conosciute' accentate la lunghezza di pword è minore

			themidx_status_t trc = THEMIDX_ERROR;
			themidx_status_t src = THEMIDX_ERROR;
			themidx_status_t wrc = THEMIDX_ERROR;

			wordid_t wordid = 0;
			themid_t themid = 0;
			stemid_t stemid = 0;

			if (((toffstop + 1) - toffstart) <= 2)
			{
				// quì va salvato tutto
				// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
				// in quanto non si tratta di una parola
				if ((reallength == 1 && (pword[0] == 'a' || pword[0] == 'e' || pword[0] == 'i' || pword[0] == 'o' || pword[0] == 'd' || pword[0] == 'l')))
				{
					eccezione_carattere = true;

					if (is_thematic == true)
					{
						if (append_buffer == false)
						{
							wrc = themidx_resolve_word( pword, &(wordid), true );

							if (wrc == THEMIDX_EXISTENT)
							{
								if (wordid <= wordformsmax && map_synonyms.count(wordform_struct[wordid].master_wordform_uid) == 0)
								{
									char *masterwordform = CBALLOC(char, MALLOC, MAX_WORD_LEN);
									masterwordform[0] = ASCII_NUL;
	
									themidx_word_by_wordid( wordform_struct[wordid].master_wordform_uid, masterwordform );
	
									// Se il programma NON indica che il termine NON è già stato utilizzato allora si può procedere
									themidx_resolve_them( pword, masterwordform, &(themid), false );

									free (masterwordform);
								}
								else
								{
									cerr << "Thematic '" << pword << "' is already used in file of synonmys!" << endl;
									exit(1);
								}
							}
							else
							{
								char *stemming = doBaseStemming(pword, reallength, ((toffstop + 2) - toffstart));
	
								if (stemming != NULL)
								{
									wrc = themidx_resolve_word( stemming, &(wordid), true );
									// se nell'indice dei wordforms non si è trovato il termine intero può darsi che esista
									// sotto forma di stemming di sinonimi (in questo caso il wordid sarà maggiore di 'wordformsmax'
									if (wrc == THEMIDX_NOT_FOUND)
										src = themidx_resolve_stem( pword, stemming, NULL, true );

									if (wrc == THEMIDX_EXISTENT && src == THEMIDX_ERROR)
									{
										cerr << "Thematic '" << pword << "' is already used in file of synonmys!" << endl;
										exit(1);
									}
								
									// Se il programma NON indica che il termine NON è già stato utilizzato allora si può procedere
									themidx_resolve_them( pword, stemming, &(themid), false );
								
									free (stemming);
								}
								else
								{
									cerr << "Thematic '" << pword << "' cannot be processed (context term)!" << endl;
									exit(1);
								}
							}
						}
						else
						{
							char *stemming = doStemming(pword, reallength, ((toffstop + 2) - toffstart));

							trc = themidx_resolve_them( NULL, stemming, &(themid), true );

							free (stemming);

							main_structs[(mcrule - 1)].thematic = themid;
	
							if (trc == THEMIDX_EXISTENT)
							{
								main_buffer[terms_counter].rule = (mcrule - 1);
								main_buffer[terms_counter].is_thematic = is_thematic;
								main_buffer[terms_counter].generic_id = (stemid_t)themid;

								terms_counter++;
							}
						}
					}
					else // Quando un termine risulta inserito in wordforms, questi viene escluso dallo stemming.
					// Al suo posto nell'indice dello stemming viene inserito il termine corrispettivo (arbitrariamente chiamato masterwordform)
					// presente nella colonna destra del file di configurazione dei termini wordforms.
					{
						wrc = themidx_resolve_word( pword, &(wordid), true );

						if (wrc == THEMIDX_EXISTENT)
						{
							if (wordid <= wordformsmax && map_synonyms.count(wordform_struct[wordid].master_wordform_uid) == 0)
							{
								char *masterwordform = CBALLOC(char, MALLOC, MAX_WORD_LEN);
								masterwordform[0] = ASCII_NUL;
	
								themidx_word_by_wordid( wordform_struct[wordid].master_wordform_uid, masterwordform );
	
								src = themidx_resolve_stem( pword, masterwordform, &(stemid), false );
	
								free (masterwordform);
							}
							else
							{
								cerr << "Stemming of '" << pword << "' is already used as synonmys!" << endl;
								exit(1);
							}
						}
						else
						{
							// se le condizioni lo permettono estraiamo lo stemming dalla parola
							if (reallength > min_word_len && reallength < MAX_WORD_LEN)
							{
								char *stemming = doBaseStemming(pword, reallength, ((toffstop + 2) - toffstart));
	
								if (stemming != NULL)
								{
									wrc = themidx_resolve_word( stemming, NULL, true );
	
									if (wrc == THEMIDX_NOT_FOUND)
										src = themidx_resolve_stem( pword, stemming, &(stemid), false );
									else
									{
										cerr << "Stemming of '" << pword << "' is already used as synonmys!" << endl;
										exit(1);
									}

									free (stemming);
								}
								else
								{
									cerr << "Stemming '" << pword << "' cannot be processed (context term)!" << endl;
									exit(1);
								}
							}
						}
	
						if (append_buffer == true)
						{
							if (src == THEMIDX_EXISTENT)
							{
								main_buffer[terms_counter].rule = (mcrule - 1);
								main_buffer[terms_counter].generic_id = stemid;
	
								terms_counter++;
							}
						}
					}
				}
				else if (reallength == 1)
				{
					eccezione_carattere = true;
				}
			}

			trc = THEMIDX_ERROR;
			src = THEMIDX_ERROR;
			wrc = THEMIDX_ERROR;

			if (((toffstop + 1) - toffstart) < MAX_WORD_LEN && ((toffstop + 1) - toffstart) > min_word_len && eccezione_carattere == false)
			{
				// quì va salvato tutto
				// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
				// in quanto non si tratta di una parola
				if ( ! (reallength == 3 && strcmp(pword, "amp") == 0)) // equivale ad unless in perl
				if (reallength > min_word_len && reallength < MAX_WORD_LEN)
				{
					if (is_thematic == true)
					{
						if (append_buffer == false)
						{
							wrc = themidx_resolve_word( pword, &(wordid), true );

							if (wrc == THEMIDX_EXISTENT)
							{
								if (wordid <= wordformsmax && map_synonyms.count(wordform_struct[wordid].master_wordform_uid) == 0)
								{
									char *masterwordform = CBALLOC(char, MALLOC, MAX_WORD_LEN);
									masterwordform[0] = ASCII_NUL;
	
									themidx_word_by_wordid( wordform_struct[wordid].master_wordform_uid, masterwordform );
	
									// Se il programma NON indica che il termine NON è già stato utilizzato allora si può procedere
									themidx_resolve_them( pword, masterwordform, &(themid), false );

									free (masterwordform);
								}
								else
								{
									cerr << "Thematic '" << pword << "' is already used in file of synonmys!" << endl;
									exit(1);
								}
							}
							else
							{
								char *stemming = doBaseStemming(pword, reallength, ((toffstop + 2) - toffstart));
	
								if (stemming != NULL)
								{
									wrc = themidx_resolve_word( stemming, &(wordid), true );
									// se nell'indice dei wordforms non si è trovato il termine intero può darsi che esista
									// sotto forma di stemming di sinonimi (in questo caso il wordid sarà maggiore di 'wordformsmax'
									if (wrc == THEMIDX_NOT_FOUND)
										src = themidx_resolve_stem( pword, stemming, NULL, true );

									if (wrc == THEMIDX_EXISTENT && src == THEMIDX_ERROR)
									{
										cerr << "Thematic '" << pword << "' is already used in file of synonmys!" << endl;
										exit(1);
									}
								
									// Se il programma NON indica che il termine NON è già stato utilizzato allora si può procedere
									themidx_resolve_them( pword, stemming, &(themid), false );

									free (stemming);
								}
								else
								{
									cerr << "Thematic '" << pword << "' cannot be processed (context term)!" << endl;
									exit(1);
								}
							}
						}
						else
						{
							char *stemming = doStemming(pword, reallength, ((toffstop + 2) - toffstart));

							trc = themidx_resolve_them( NULL, stemming, &(themid), true );

							free (stemming);

							main_structs[(mcrule - 1)].thematic = themid;
	
							if (trc == THEMIDX_EXISTENT)
							{
								main_buffer[terms_counter].rule = (mcrule - 1);
								main_buffer[terms_counter].is_thematic = is_thematic;
								main_buffer[terms_counter].generic_id = (stemid_t)themid;

								terms_counter++;
							}
						}
					}
					else // Quando un termine risulta inserito in wordforms, questi viene escluso dallo stemming.
					// Al suo posto nell'indice dello stemming viene inserito il termine corrispettivo (arbitrariamente chiamato masterwordform)
					// presente nella colonna destra del file di configurazione dei termini wordforms.
					{
						wrc = themidx_resolve_word( pword, &(wordid), true );

						if (wrc == THEMIDX_EXISTENT)
						{
							if (wordid <= wordformsmax && map_synonyms.count(wordform_struct[wordid].master_wordform_uid) == 0)
							{
								char *masterwordform = CBALLOC(char, MALLOC, MAX_WORD_LEN);
								masterwordform[0] = ASCII_NUL;
	
								themidx_word_by_wordid( wordform_struct[wordid].master_wordform_uid, masterwordform );
	
								src = themidx_resolve_stem( pword, masterwordform, &(stemid), false );
	
								free (masterwordform);
							}
							else
							{
								cerr << "Stemming of '" << pword << "' is already used as synonmys!" << endl;
								exit(1);
							}
						}
						else
						{
							// se le condizioni lo permettono estraiamo lo stemming dalla parola
							if (reallength > min_word_len && reallength < MAX_WORD_LEN)
							{
								char *stemming = doBaseStemming(pword, reallength, ((toffstop + 2) - toffstart));
	
								if (stemming != NULL)
								{
									wrc = themidx_resolve_word( stemming, NULL, true );
	
									if (wrc == THEMIDX_NOT_FOUND)
										src = themidx_resolve_stem( pword, stemming, &(stemid), false );
									else
									{
										cerr << "Stemming of '" << pword << "' is already used as synonmys!" << endl;
										exit(1);
									}

									free (stemming);
								}
							}
						}
	
						if (append_buffer == true)
						{
							if (src == THEMIDX_EXISTENT)
							{
								main_buffer[terms_counter].rule = (mcrule - 1);
								main_buffer[terms_counter].generic_id = stemid;
	
								terms_counter++;
							}
						}
					}
				}
			}
			free (pword);
		}

		bool testspecial = false;

		while ((isalpha(ptext[pos]) == false) && pos < (textlen - min_word_len))
			if (ptext[pos] != ' ' && (convSpecialChar(ptext, textlen, pos) != ' '))
			{
				testspecial = true;
				pos--;
				break;
			}
			else
				pos++;

		if (testspecial == true)
			toffstart = pos + 1;
		else
			toffstart = pos;

		found = false;
		single_char = false;
	}
	while (pos++ < (textlen - min_word_len));
}

//
// Name: Thematics::doStemming 
//
// Description: Converte un termine nel suo stemming dopo aver prima verificato che non abbia un wordform.
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola.
//
char *Thematics::doStemming(char *pword, size_t reallength, size_t sb_symbol_size) const
{
	assert(pword != NULL);
	assert(strlen(pword) > 0);
	themidx_status_t wrc = THEMIDX_ERROR;

	wordid_t wordid = 0;

	wrc = themidx_resolve_word( pword, &(wordid), true );

	// esiste nel file dei wordform e non si deve estrarre lo stemming	
	if (wrc == THEMIDX_EXISTENT && wordid <= wordformsmax)
	{
		char *stemming = CBALLOC(char, MALLOC, (MAX_WORD_LEN + 1));
		stemming[0] = ASCII_NUL;

		themidx_word_by_wordid( wordform_struct[wordid].master_wordform_uid, stemming );

		return stemming;
	}

	sb_symbol *b = CBALLOC(sb_symbol, MALLOC, sb_symbol_size);

	for (size_t o = 0; o <= reallength; o++)
	{
		if (o == reallength)
			b[o] = ASCII_NUL;
		else
        		b[o] = pword[o];
	}

	unsigned short err_count = 0;
	unsigned short max_alloc = 3;

	const sb_symbol *stemmed;

	do
	{
		err_count++;
		stemmed = sb_stemmer_stem(stemmer, b, reallength);

		if (stemmed == NULL && err_count > max_alloc)
		{
			free (b);
			free (pword);
			cerr << "Error allocating stemming memory for " << err_count << " times." << endl;
       			die ("process died");
       	}
	}
	while (stemmed == NULL);

	free(b);

	int lout = sb_stemmer_length(stemmer);

	if (lout > 0)
	{
		char *stemming = CBALLOC(char, MALLOC, (lout + 1));

		memcpy(stemming, (const char *)stemmed, (lout + 1));

		return stemming;
	}

	return NULL;
}

//
// Name: Thematics::doBaseStemming 
//
// Description: Converte un termine nel suo stemming.
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola.
//
char *Thematics::doBaseStemming(char *pword, size_t reallength, size_t sb_symbol_size) const
{
	assert(pword != NULL);
	assert(strlen(pword) > 0);
	const sb_symbol *stemmed = NULL;

	sb_symbol *b = CBALLOC(sb_symbol, MALLOC, sb_symbol_size);

	for (size_t o = 0; o <= reallength; o++)
	{
		if (o == reallength)
			b[o] = ASCII_NUL;
		else
        		b[o] = pword[o];
	}

	unsigned short err_count = 0;
	unsigned short max_alloc = 3;

	do
	{
		err_count++;
		stemmed = sb_stemmer_stem(stemmer, b, reallength);

		if (stemmed == NULL && err_count > max_alloc)
		{
			free (b);
			free (pword);
			cerr << "Error allocating stemming memory for " << err_count << " times." << endl;
       			die ("process died");
       		}
	}
        while (stemmed == NULL);

	free(b);

	int lout = sb_stemmer_length(stemmer);

	if (lout > 0)
	{
		char *stemming = CBALLOC(char, MALLOC, (lout + 1));

		memcpy(stemming, (const char *)stemmed, (lout + 1));

		return stemming;
	}

	return NULL;
}

//
// Name: Thematics::doStemming 
//
// Description: Converte un termine nel suo stemming dopo aver prima verificato che non abbia un wordform.
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola.
//
char *Thematics::doStemming(thematic_out_t *tro, char *pword, size_t reallength, size_t sb_symbol_size) const
{
	assert(pword != NULL);
	assert(strlen(pword) > 0);
	themidx_status_t wrc = THEMIDX_ERROR;

	wordid_t wordid = 0;

	wrc = themidx_resolve_word( pword, &(wordid), true );

	// esiste nel file dei wordform e non si deve estrarre lo stemming	
	if (wrc == THEMIDX_EXISTENT && wordid <= wordformsmax)
	{
		char *stemming = CBALLOC(char, MALLOC, (MAX_WORD_LEN + 1));
		stemming[0] = ASCII_NUL;

		themidx_word_by_wordid( wordform_struct[wordid].master_wordform_uid, stemming );

		return stemming;
	}

	sb_symbol *b = CBALLOC(sb_symbol, MALLOC, sb_symbol_size);

	for (size_t o = 0; o <= reallength; o++)
	{
		if (o == reallength)
			b[o] = ASCII_NUL;
		else
        		b[o] = pword[o];
	}

	unsigned short err_count = 0;
	unsigned short max_alloc = 3;

	const sb_symbol *stemmed;

	do
	{
		err_count++;
		stemmed = sb_stemmer_stem(tro->stemmer, b, reallength);

		if (stemmed == NULL && err_count > max_alloc)
		{
			free (b);
			free (pword);
			cerr << "Error allocating stemming memory for " << err_count << " times." << endl;
       			die ("process died");
       		}
	}
        while (stemmed == NULL);

	free(b);

	int lout = sb_stemmer_length(tro->stemmer);

	if (lout > 0)
	{
		char *stemming = CBALLOC(char, MALLOC, (lout + 1));

		memcpy(stemming, (const char *)stemmed, (lout + 1));

		return stemming;
	}

	return NULL;
}

//
// Name: Thematics::doBaseStemming 
//
// Description: Converte un termine nel suo stemming.
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola.
//
char *Thematics::doBaseStemming(thematic_out_t *tro, char *pword, size_t reallength, size_t sb_symbol_size) const
{
	assert(pword != NULL);
	assert(strlen(pword) > 0);
	const sb_symbol *stemmed = NULL;

	sb_symbol *b = CBALLOC(sb_symbol, MALLOC, sb_symbol_size);

	for (size_t o = 0; o <= reallength; o++)
	{
		if (o == reallength)
			b[o] = ASCII_NUL;
		else
        		b[o] = pword[o];
	}

	unsigned short err_count = 0;
	unsigned short max_alloc = 3;

	do
	{
		err_count++;
		stemmed = sb_stemmer_stem(tro->stemmer, b, reallength);

		if (stemmed == NULL && err_count > max_alloc)
		{
			free (b);
			free (pword);
			cerr << "Error allocating stemming memory for " << err_count << " times." << endl;
       			die ("process died");
       		}
	}
        while (stemmed == NULL);

	free(b);

	int lout = sb_stemmer_length(tro->stemmer);

	if (lout > 0)
	{
		char *stemming = CBALLOC(char, MALLOC, (lout + 1));

		memcpy(stemming, (const char *)stemmed, (lout + 1));

		return stemming;
	}

	return NULL;
}

//
// Name: Thematics::checkThematicWord 
//
// Description: Controlla se la parola in input è inserita in un contesto...

//
// Argomenti: puntatore a parola da elaborare, limite minimo lunghezza parola.
//
unsigned short Thematics::checkThematicWord(thematic_out_t *tro, char *ptext, const size_t min_word_len, bool stop_ranking, bool indomain, bool is_clevel) const
{
	size_t textlen = strlen(ptext);

	unsigned short words_counter = 0; // ad ogni chiamata di funzione viene restituito il numero di parole elaborato

	// rimuove eventuali spazi in coda
	while (ptext[textlen - 1] == ' ' && textlen > 0)
		textlen--;

	size_t pos = 0;
	size_t toffstart = 0;
	size_t toffstop = 0;
	bool found = false;
	bool single_char = false;

	if (((int)textlen - (int)min_word_len) >= 0)
	do
	{
		while ((isalpha(ptext[pos]) || convSpecialChar(ptext, textlen, pos) != ' ') && pos < textlen)
		{
			if (convSpecialChar(ptext, textlen, pos) != ' ')
				pos += 2;
			else
				pos++;

			found = true;
		}

		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(ptext[pos]) == false) && isalpha(ptext[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(ptext[pos]) == false) && convSpecialChar(ptext, textlen, pos) == ' '))
					toffstop = (pos - 1);
				else if (pos == (textlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			bool eccezione_carattere = false; // quasi tutte le vocali e consonanti seguite da apostrofo

			char *pword = printWord(ptext, toffstart, (toffstop + 1), true);

			if (words_counter < (USHRT_MAX- 1))
				words_counter++;

			size_t reallength = strlen(pword); // nel caso il termine originale contiene lettere 'conosciute' accentate la lunghezza di pword è minore

			themidx_status_t mrc = THEMIDX_ERROR;
			themidx_status_t trc = THEMIDX_ERROR;
			themidx_status_t src = THEMIDX_ERROR;
			themidx_status_t wrc = THEMIDX_ERROR;
			themidx_status_t drc = THEMIDX_ERROR;

			metaid_t metaid = 0;
			themid_t themid = 0;
			wordid_t wordid = 0;
			stemid_t stemid = 0;
			duplid_t duplid = 0;

			if (((toffstop + 1) - toffstart) <= MIN_WORD_LEN)
			{
				// quì va salvato tutto
				// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
				// in quanto non si tratta di una parola
				if ((reallength == 1 && (pword[0] == 'a' || pword[0] == 'e' || pword[0] == 'i' || pword[0] == 'o' || pword[0] == 'd' || pword[0] == 'l')))
				{
					eccezione_carattere = true;

					wrc = themidx_resolve_word( pword, &(wordid), true );

					if (wrc == THEMIDX_NOT_FOUND)
					{
						char *stemming = doBaseStemming(tro, pword, reallength, ((toffstop + 2) - toffstart));

						wrc = themidx_resolve_word( stemming, &(wordid), true );
						// se nell'indice dei wordforms non si è trovato il termine intero può darsi che esista
						// sotto forma di stemming di sinonimi (in questo caso il wordid sarà maggiore di 'wordformsmax'

						if (indomain == true)
							// aggiunge il termine se non presente, all'indice delle meta words
							mrc = themidx_resolve_meta(tro,  stemming, &(metaid), false );
						else
							// verifica se il termine è gia stato elaborato
							drc = themidx_resolve_dupl(tro,  pword, stemming, &(duplid), false );
							
						free (stemming);
					}

					map_synonyms_value_t map_synonyms_value = {true, USHRT_MAX}; // assegnazione valori in struttura

					if (wrc == THEMIDX_EXISTENT)
					{
						if (wordid > wordformsmax)
						{
							if (map_synonyms.count(wordid) > 0) // allora la chiave esiste			
								map_synonyms_value = map_synonyms.find(wordid)->second;
	
							if (indomain == false)
							{
								// crea una lista di sinonimi già elaborati
								unsigned short pos = 0;

								while (tro->synonyms_found[pos] != USHRT_MAX && pos < msline)
								{
									if (tro->synonyms_found[pos] == map_synonyms_value.line)
									{
										free (pword);
										goto skip;
									}

									pos++;
								}

								// incrementa la lista delle linee sinonimi verificate
								tro->synonyms_found[pos] = map_synonyms_value.line;
							}
						}
						else
						{
							wordid = wordform_struct[wordid].master_wordform_uid;

							char *masterwordform = CBALLOC(char, MALLOC, MAX_WORD_LEN);
							masterwordform[0] = ASCII_NUL;
	
							themidx_word_by_wordid( wordid, masterwordform );

							if (indomain == true)
								// aggiunge il termine se non presente, all'indice delle meta words
								mrc = themidx_resolve_meta(tro,  masterwordform, &(metaid), false );
							else
								// verifica se il termine è gia stato elaborato
								drc = themidx_resolve_dupl(tro,  pword, masterwordform, &(duplid), false );
							
							free (masterwordform);
						}

						if (indomain == false)
						{
							if (map_synonyms_value.only_synonyms == false && map_synonyms_value.line < USHRT_MAX)
							{
								if (drc == THEMIDX_EXISTENT && duplid < tro->duplicates_split_offset[0]) // punteggio a headings nel contenuto
									rankingAllocation(tro, (stemid_t)map_synonyms_value.line, true, true, false, false);

								if (drc == THEMIDX_CREATED_DUPL && stop_ranking == false)
									rankingAllocation(tro, (stemid_t)map_synonyms_value.line, true, false, false, false);
							}
						}
						else
						{
							if (map_synonyms_value.only_synonyms == false && map_synonyms_value.line < USHRT_MAX && mrc == THEMIDX_CREATED_META)
							{
								if (is_clevel == false) // punteggio trattato come headings nel contenuto
									rankingAllocation(tro, (stemid_t)map_synonyms_value.line, true, true, false, false);
								else	
									rankingAllocation(tro, (stemid_t)map_synonyms_value.line, true, false, false, false);
							}
						}

						// termine non presente nel file dei sinonimi e non ancora elaborato. Cerco tra gli stemming
						if (map_synonyms_value.line == USHRT_MAX && (mrc == THEMIDX_CREATED_META || drc == THEMIDX_CREATED_DUPL))
						{
							// condizione in teoria non necessaria perchè un wordid > wordformsmax significa
							// che è un termine sinonimo e non può esistere negli stemming (contesti)
							if (wordid > wordformsmax)
							{
								char *stemming = doBaseStemming(tro, pword, reallength, ((toffstop + 2) - toffstart));

								src = themidx_resolve_stem( tro, pword, stemming, &(stemid), true );

								free (stemming);
							}
							else
							{
								char *masterwordform = CBALLOC(char, MALLOC, MAX_WORD_LEN);
								masterwordform[0] = ASCII_NUL;
	
								themidx_word_by_wordid( wordid, masterwordform );
	
								// verifica prima se il termine è una tematica
								if (strcmp(masterwordform, "null") != 0)
									trc =  themidx_resolve_them( tro, NULL, masterwordform, &(themid), true );

								src = themidx_resolve_stem( tro, NULL, masterwordform, &(stemid), true );
							
								free (masterwordform);
							}

							if (indomain == false)
							{
								if (stop_ranking == false)
								{
									// punteggio a headings nel contenuto
									if (duplid < tro->duplicates_split_offset[0])
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, true, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, true, false, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, false, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, false, false, false);
									}
								}
							}
							else
							{
								if (is_clevel == false) // punteggio trattato come headings nel contenuto
								{
									if (trc == THEMIDX_EXISTENT)
										rankingAllocation(tro, (stemid_t)themid, false, true, true, false);

									if (src == THEMIDX_EXISTENT)
										rankingAllocation(tro, stemid, false, true, false, false);
								}
								else	
								{
									if (trc == THEMIDX_EXISTENT)
										rankingAllocation(tro, (stemid_t)themid, false, false, true, false);

									if (src == THEMIDX_EXISTENT)
										rankingAllocation(tro, stemid, false, false, false, false);
								}
							}
						}
					}
					else
					{
						char *stemming = doBaseStemming(tro, pword, reallength, ((toffstop + 2) - toffstart));

						if (stemming != NULL)
						{
							// verifica prima se il termine è una tematica
							if (strcmp(stemming, "null") != 0)
								trc =  themidx_resolve_them( tro, NULL, stemming, &(themid), true );

							src = themidx_resolve_stem( tro, NULL, stemming, &(stemid), true );

							if (indomain == false)
							{
								if (drc == THEMIDX_CREATED_DUPL && stop_ranking == false)
								{
									// punteggio a headings nel contenuto
									if (duplid < tro->duplicates_split_offset[0])
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, true, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, true, false, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, false, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, false, false, false);
									}
								}
							}
							else
							{
								if (mrc == THEMIDX_CREATED_META)
								{
									// punteggio a headings nel contenuto
									if (is_clevel == false) // punteggio trattato come headings nel contenuto
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, true, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, true, false, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, false, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, false, false, false);
									}
								}
							}

							free (stemming);
						}
					}
				}
				else if (reallength == 1)
				{
					eccezione_carattere = true;
				}
			}

			if (((toffstop + 1) - toffstart) < MAX_WORD_LEN && ((toffstop + 1) - toffstart) > min_word_len && eccezione_carattere == false)
			{
				// quì va salvato tutto
				// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
				// in quanto non si tratta di una parola
				if ( ! (reallength == 3 && strcmp(pword, "amp") == 0)) // equivale ad unless in perl
				if (reallength > min_word_len && reallength < MAX_WORD_LEN)
				{
					wrc = themidx_resolve_word( pword, &(wordid), true );

					if (wrc == THEMIDX_NOT_FOUND)
					{
						char *stemming = doBaseStemming(tro, pword, reallength, ((toffstop + 2) - toffstart));

						wrc = themidx_resolve_word( stemming, &(wordid), true );
						// se nell'indice dei wordforms non si è trovato il termine intero può darsi che esista
						// sotto forma di stemming di sinonimi (in questo caso il wordid sarà maggiore di 'wordformsmax'

						if (indomain == true)
							// aggiunge il termine se non presente, all'indice delle meta words
							mrc = themidx_resolve_meta( tro,  stemming, &(metaid), false );
						else
							// verifica se il termine è gia stato elaborato
							drc = themidx_resolve_dupl( tro,  pword, stemming, &(duplid), false );
							
						free (stemming);
					}

					map_synonyms_value_t map_synonyms_value = {true, USHRT_MAX}; // assegnazione valori in struttura

					if (wrc == THEMIDX_EXISTENT)
					{
						if (wordid > wordformsmax)
						{
							if (map_synonyms.count(wordid) > 0) // allora la chiave esiste			
								map_synonyms_value = map_synonyms.find(wordid)->second;
	
							if (indomain == false)
							{
								// crea una lista di sinonimi già elaborati
								unsigned short pos = 0;

								while (tro->synonyms_found[pos] != USHRT_MAX && pos < msline)
								{
									if (tro->synonyms_found[pos] == map_synonyms_value.line)
									{
										free (pword);
										goto skip;
									}

									pos++;
								}

								// incrementa la lista delle linee sinonimi verificate
								tro->synonyms_found[pos] = map_synonyms_value.line;
							}
						}
						else
						{
							wordid = wordform_struct[wordid].master_wordform_uid;

							char *masterwordform = CBALLOC(char, MALLOC, MAX_WORD_LEN);
							masterwordform[0] = ASCII_NUL;
	
							themidx_word_by_wordid( wordid, masterwordform );

							if (indomain == true)
								// aggiunge il termine se non presente, all'indice delle meta words
								mrc = themidx_resolve_meta(tro,  masterwordform, &(metaid), false );
							else
								// verifica se il termine è gia stato elaborato
								drc = themidx_resolve_dupl(tro,  pword, masterwordform, &(duplid), false );
							
							free (masterwordform);
						}

						if (indomain == false)
						{
							if (map_synonyms_value.only_synonyms == false && map_synonyms_value.line < USHRT_MAX)
							{
								if (drc == THEMIDX_EXISTENT && duplid < tro->duplicates_split_offset[0]) // punteggio a headings nel contenuto
									rankingAllocation(tro, (stemid_t)map_synonyms_value.line, true, true, false, false);

								if (drc == THEMIDX_CREATED_DUPL && stop_ranking == false)
									rankingAllocation(tro, (stemid_t)map_synonyms_value.line, true, false, false, false);
							}
						}
						else
						{
							if (map_synonyms_value.only_synonyms == false && map_synonyms_value.line < USHRT_MAX && mrc == THEMIDX_CREATED_META)
							{
								if (is_clevel == false) // punteggio trattato come headings nel contenuto
									rankingAllocation(tro, (stemid_t)map_synonyms_value.line, true, true, false, false);
								else	
									rankingAllocation(tro, (stemid_t)map_synonyms_value.line, true, false, false, false);
							}
						}

						// termine non presente nel file dei sinonimi e non ancora elaborato. Cerco tra gli stemming
						if (map_synonyms_value.line == USHRT_MAX && (mrc == THEMIDX_CREATED_META || drc == THEMIDX_CREATED_DUPL))
						{
							// condizione in teoria non necessaria perchè un wordid > wordformsmax significa
							// che è un termine sinonimo e non può esistere negli stemming (contesti)
							if (wordid > wordformsmax)
							{
								char *stemming = doBaseStemming(tro, pword, reallength, ((toffstop + 2) - toffstart));

								src = themidx_resolve_stem( tro, pword, stemming, &(stemid), true );

								free (stemming);
							}
							else
							{
								char *masterwordform = CBALLOC(char, MALLOC, MAX_WORD_LEN);
								masterwordform[0] = ASCII_NUL;
	
								themidx_word_by_wordid( wordid, masterwordform );
	
								// verifica prima se il termine è una tematica
								if (strcmp(masterwordform, "null") != 0)
									trc =  themidx_resolve_them( tro, NULL, masterwordform, &(themid), true );

								src = themidx_resolve_stem( tro, NULL, masterwordform, &(stemid), true );
							
								free (masterwordform);
							}

							if (indomain == false)
							{
								if (stop_ranking == false)
								{
									// punteggio a headings nel contenuto
									if (duplid < tro->duplicates_split_offset[0])
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, true, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, true, false, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, false, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, false, false, false);
									}
								}
							}
							else
							{
								if (is_clevel == false) // punteggio trattato come headings nel contenuto
								{
									if (trc == THEMIDX_EXISTENT)
										rankingAllocation(tro, (stemid_t)themid, false, true, true, false);

									if (src == THEMIDX_EXISTENT)
										rankingAllocation(tro, stemid, false, true, false, false);
								}
								else	
								{
									if (trc == THEMIDX_EXISTENT)
										rankingAllocation(tro, (stemid_t)themid, false, false, true, false);

									if (src == THEMIDX_EXISTENT)
										rankingAllocation(tro, stemid, false, false, false, false);
								}
							}
						}
					}
					else
					{
						char *stemming = doBaseStemming(tro, pword, reallength, ((toffstop + 2) - toffstart));

						if (stemming != NULL)
						{
							// verifica prima se il termine è una tematica
							if (strcmp(stemming, "null") != 0)
								trc =  themidx_resolve_them( tro, NULL, stemming, &(themid), true );

							src = themidx_resolve_stem( tro, NULL, stemming, &(stemid), true );

							if (indomain == false)
							{
								if (drc == THEMIDX_CREATED_DUPL && stop_ranking == false)
								{
									// punteggio a headings nel contenuto
									if (duplid < tro->duplicates_split_offset[0])
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, true, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, true, false, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, false, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, false, false, false);
									}
								}
							}
							else
							{
								if (mrc == THEMIDX_CREATED_META)
								{
									// punteggio a headings nel contenuto
									if (is_clevel == false) // punteggio trattato come headings nel contenuto
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, true, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, true, false, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation(tro, (stemid_t)themid, false, false, true, false);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(tro, stemid, false, false, false, false);
									}
								}
							}

							free (stemming);
						}
					}
				}
			}
			free (pword);
		}

		skip:

		bool testspecial = false;

		while ((isalpha(ptext[pos]) == false) && pos < (textlen - min_word_len))
			if (ptext[pos] != ' ' && (convSpecialChar(ptext, textlen, pos) != ' '))
			{
				testspecial = true;
				pos--;
				break;
			}
			else
				pos++;

		if (testspecial == true)
			toffstart = pos + 1;
		else
			toffstart = pos;

		found = false;
		single_char = false;
	}
	while (pos++ < (textlen - min_word_len));

	return words_counter;
}

//
// Name: Thematics::checkSensitiveWord 
//
// Description: Controlla se le parole in input sono inserite nel contenuto (headings, body) della pagina
// L'argomento 'synonyms_sensitive_found' in input controlla che non venga aggiunta la linea di sinonimi più di una volta nel puntatore dentro la struttura
//

//
// Argomenti: puntatore a parola da elaborare, limite minimo lunghezza parola.
//
// Restituisce: il puntatore alla lista dei sinonimi trovati per poi riprenderlo come argomento
unsigned short *Thematics::checkSensitiveWord(thematic_out_t *tro, char *ptext, const size_t min_word_len, unsigned short *synonyms_sensitive_found) const
{
	size_t textlen = strlen(ptext);

	unsigned short words_counter = 0; // ad ogni chiamata di funzione viene restituito il numero di parole elaborato

	// rimuove eventuali spazi in coda
	while (ptext[textlen - 1] == ' ' && textlen > 0)
		textlen--;

	size_t pos = 0;
	size_t toffstart = 0;
	size_t toffstop = 0;
	bool found = false;
	bool single_char = false;

	if (((int)textlen - (int)min_word_len) >= 0)
	do
	{
		while ((isalpha(ptext[pos]) || convSpecialChar(ptext, textlen, pos) != ' ') && pos < textlen)
		{
			if (convSpecialChar(ptext, textlen, pos) != ' ')
				pos += 2;
			else
				pos++;

			found = true;
		}

		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(ptext[pos]) == false) && isalpha(ptext[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(ptext[pos]) == false) && convSpecialChar(ptext, textlen, pos) == ' '))
					toffstop = (pos - 1);
				else if (pos == (textlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			bool eccezione_carattere = false; // quasi tutte le vocali e consonanti seguite da apostrofo

			char *pword = printWord(ptext, toffstart, (toffstop + 1), true);

			if (words_counter < (USHRT_MAX- 1))
				words_counter++;

			size_t reallength = strlen(pword); // nel caso il termine originale contiene lettere 'conosciute' accentate la lunghezza di pword è minore

			themidx_status_t trc = THEMIDX_ERROR;
			themidx_status_t src = THEMIDX_ERROR;
			themidx_status_t wrc = THEMIDX_ERROR;
			themidx_status_t drc = THEMIDX_ERROR;
			themidx_status_t mrc = THEMIDX_ERROR;

			themid_t themid = 0;
			wordid_t wordid = 0;
			stemid_t stemid = 0;
			duplid_t duplid = 0;
			metaid_t metaid = 0;

			if (((toffstop + 1) - toffstart) < MAX_WORD_LEN && ((toffstop + 1) - toffstart) > min_word_len && eccezione_carattere == false)
			{
				// quì va salvato tutto
				// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
				// in quanto non si tratta di una parola
				if ( ! (reallength == 3 && strcmp(pword, "amp") == 0)) // equivale ad unless in perl
				if (reallength > min_word_len && reallength < MAX_WORD_LEN)
				{
					wrc = themidx_resolve_word( pword, &(wordid), true ); // cerca nei wordforms (cerca il termine intero)

					if (wrc == THEMIDX_NOT_FOUND)
					{
						char *stemming = doBaseStemming(tro, pword, reallength, ((toffstop + 2) - toffstart));

						wrc = themidx_resolve_word( stemming, &(wordid), true );
						// se nell'indice dei wordforms non si è trovato il termine intero può darsi che esista
						// sotto forma di stemming di sinonimi (in questo caso il wordid sarà maggiore di 'wordformsmax'
						free (stemming);
					}

					map_synonyms_value_t map_synonyms_value = {true, USHRT_MAX}; // assegnazione valori in struttura

					if (wrc == THEMIDX_EXISTENT) // termine sicuramente presente nei wordforms o nei sinonimi
					{
						size_t start = 0;
						size_t end = 0;

						if (wordid > wordformsmax) //stemming di sinonimi (sicuramente)
						{
							if (map_synonyms.count(wordid) > 0)
								map_synonyms_value = map_synonyms.find(wordid)->second;

							if (map_synonyms_value.line < USHRT_MAX)
							{
								// crea una lista di parole sensibili (e contemporaneamente sinonimi) già elaborate
								unsigned short pos = 0;

								while (synonyms_sensitive_found[pos] != USHRT_MAX && pos < msline)
								{
									if (synonyms_sensitive_found[pos] == map_synonyms_value.line)
									{
										free (pword);
										return synonyms_sensitive_found;
									}

									pos++;
								}

								// incrementa la lista delle linee sinonimi verificate
								synonyms_sensitive_found[pos] = map_synonyms_value.line;

								if (map_synonyms_value.line == 0)
									start = 0;
								else
									start = line_synonyms_structs[map_synonyms_value.line].line_offset;

								if (map_synonyms_value.line < msline)
									end = line_synonyms_structs[(map_synonyms_value.line + 1)].line_offset;
								else
									end = strlen(synonyms_buffer);
							}

							char * stemming = doBaseStemming(tro, pword, reallength, ((toffstop + 2) - toffstart));

							// verifica se il termine è presente nel contenuto della pagina 
							drc = themidx_resolve_dupl( tro,  NULL, stemming, &(duplid), true );
							
							// aggiunge il termine se non presente, all'indice delle meta words
							mrc = themidx_resolve_meta( tro,  stemming, &(metaid), false );

							// inserisce il termine (se non presente) tra le parole sensibili
							if (drc == THEMIDX_EXISTENT && mrc == THEMIDX_CREATED_META)
							{
								if ((tro->swlen + reallength) < MAX_STR_LEN)
								{
									if (tro->sensitive_words[0] == ASCII_NUL)
									{
										strcpy(tro->sensitive_words, pword);
										tro->swlen = reallength;
									}
									else
									{
										strcat(tro->sensitive_words, " ");
										strcat(tro->sensitive_words, pword);
										tro->swlen += (1 + reallength);
									}
								}
							}

							free (stemming);
						}
						else
						{
							wordid = wordform_struct[wordid].master_wordform_uid;

							char *masterwordform = CBALLOC(char, MALLOC, MAX_WORD_LEN);

							masterwordform[0] = ASCII_NUL;

							themidx_word_by_wordid( wordid, masterwordform );

							// verifica se il termine è presente nel contenuto della pagina 
							drc = themidx_resolve_dupl(tro,  NULL, masterwordform, &(duplid), true);
							
							// aggiunge il termine se non presente, all'indice delle meta words
							mrc = themidx_resolve_meta(tro,  masterwordform, &(metaid), false);

							// inserisce il termine (se non presente) tra le parole sensibili
							if (drc == THEMIDX_EXISTENT && mrc == THEMIDX_CREATED_META)
							{
								if ((tro->swlen + reallength) < MAX_STR_LEN)
								{
									if (tro->sensitive_words[0] == ASCII_NUL)
									{
										strcpy(tro->sensitive_words, masterwordform);
										tro->swlen = reallength;
									}
									else
									{
										strcat(tro->sensitive_words, " ");
										strcat(tro->sensitive_words, masterwordform);
										tro->swlen += (1 + reallength);
									}
								}
							}

							free (masterwordform);

							if (map_synonyms.count(wordid) > 0)
								map_synonyms_value = map_synonyms.find(wordid)->second;
						}

						// condizione necessaria affinchè sia una termine sensibile
						if (drc == THEMIDX_EXISTENT && mrc == THEMIDX_CREATED_META)
						{
							if (map_synonyms_value.only_synonyms == false && map_synonyms_value.line < USHRT_MAX) // se in context.conf
							{
								if (duplid < tro->duplicates_split_offset[0]) // punteggio a headings nel contenuto
									rankingAllocation(tro, (stemid_t)map_synonyms_value.line, true, true, false, true);
								else	
									rankingAllocation(tro, (stemid_t)map_synonyms_value.line, true, false, false, true);
							}
							else // termine NON presente nei sinonimi ma potrebbe esistere nelle tematiche
							{    // o negli stemming (ma sotto forma di wordforms nei termini contesti)
								char *masterwordform = CBALLOC(char, MALLOC, MAX_WORD_LEN);
								masterwordform[0] = ASCII_NUL;

								themidx_word_by_wordid( wordid, masterwordform );

								// verifica se il termine è una tematica
								if (strcmp(masterwordform, "null") != 0)
									trc =  themidx_resolve_them(tro, NULL, masterwordform, &(themid), true);

								src = themidx_resolve_stem(tro, NULL, masterwordform, &(stemid), true);
						
								free (masterwordform);

								if (trc == THEMIDX_EXISTENT)
								{
									if (duplid < tro->duplicates_split_offset[0]) // punteggio a headings nel contenuto
										rankingAllocation(tro, (stemid_t)themid, false, true, true, true);
									else	
										rankingAllocation(tro, (stemid_t)themid, false, false, true, true);
								}

								if (src == THEMIDX_EXISTENT)
								{
									if (duplid < tro->duplicates_split_offset[0]) // punteggio a headings nel contenuto
										rankingAllocation(tro, stemid, false, true, false, true);
									else	
										rankingAllocation(tro, stemid, false, false, false, true);
								}

								if (trc == THEMIDX_NOT_FOUND && src == THEMIDX_NOT_FOUND && (tro->swlen + reallength) < MAX_STR_LEN)
								{
									// esiste linea sinonimi non presente nel main file
									if (map_synonyms_value.only_synonyms == true && map_synonyms_value.line < USHRT_MAX)
									{
										char temparray[MAX_WORD_LEN] = {ASCII_NUL};

										char *exclude_word = pword;

										size_t ta_counter = 0;

										// tutti i sinonimi relativi alla linea (tranne quello originale) sono
										// collocati in 'tro->good_words'
										for (size_t o = start; o < end; o++)
										{
											if (synonyms_buffer[o] == ' ')
											{
												size_t tlength = strlen(temparray);

												if (strcmp (exclude_word, temparray) != 0 && (tro->gwlen + tlength) < MAX_STR_LEN)
												{
													if (tro->good_words[0] == ASCII_NUL)
													{
														strcpy(tro->good_words, temparray);
														tro->gwlen = tlength;
													}
													else
													{
														strcat(tro->good_words, " ");
														strcat(tro->good_words, temparray);
														tro->gwlen += (tlength + 1);
													}
												
												}

												memset (temparray,ASCII_NUL,MAX_WORD_LEN);
												ta_counter = 0;
											}
											else
											{
												temparray[ta_counter] = synonyms_buffer[o];
												ta_counter++;
											}
										}			
									}
								}
							}
						}
					}
					else
					{
						char * stemming = doBaseStemming(tro, pword, reallength, ((toffstop + 2) - toffstart));

						if (stemming != NULL)
						{
							// verifica se il termine è una tematica
							if (strcmp(stemming, "null") != 0)
								trc =  themidx_resolve_them(tro, NULL, stemming, &(themid), true);

							src = themidx_resolve_stem(tro, NULL, stemming, &(stemid), true);

							// verifica se il termine è presente nel contenuto della pagina 
							drc = themidx_resolve_dupl(tro,  NULL, stemming, NULL, true );
					
							// aggiunge il termine se non presente, all'indice delle meta words
							mrc = themidx_resolve_meta(tro,  stemming, &(metaid), false );
						}

						free (stemming);

						// condizione necessaria affinchè sia una termine sensibile
						if (drc == THEMIDX_EXISTENT && mrc == THEMIDX_CREATED_META)
						{
							if (trc == THEMIDX_EXISTENT)
							{
								if (duplid < tro->duplicates_split_offset[0]) // punteggio a headings nel contenuto
									rankingAllocation(tro, (stemid_t)themid, false, true, true, true);
								else	
									rankingAllocation(tro, (stemid_t)themid, false, false, true, true);
							}

							if (src == THEMIDX_EXISTENT)
							{
								if (duplid < tro->duplicates_split_offset[0]) // punteggio a headings nel contenuto
									rankingAllocation(tro, stemid, false, true, false, true);
								else	
									rankingAllocation(tro, stemid, false, false, false, true);
							}

							if ((tro->swlen + reallength) < MAX_STR_LEN)
							{
								if (tro->sensitive_words[0] == ASCII_NUL)
								{
									strcpy(tro->sensitive_words, pword);
									tro->swlen = reallength;
								}
								else
								{
									strcat(tro->sensitive_words, " ");
									strcat(tro->sensitive_words, pword);
									tro->swlen += (1 + reallength);
								}
							}
						}
					}
				}
			}
			free (pword);
		}

		bool testspecial = false;

		while ((isalpha(ptext[pos]) == false) && pos < (textlen - min_word_len))
			if (ptext[pos] != ' ' && (convSpecialChar(ptext, textlen, pos) != ' '))
			{
				testspecial = true;
				pos--;
				break;
			}
			else
				pos++;

		if (testspecial == true)
			toffstart = pos + 1;
		else
			toffstart = pos;

		found = false;
		single_char = false;
	}
	while (pos++ < (textlen - min_word_len));

	return synonyms_sensitive_found;
}

void Thematics::rankingAllocation(thematic_out_t *tro, stemid_t id, bool is_synonyms, bool is_heading, bool is_thematic, bool in_sensitive) const
{
	unsigned int rank_limit = (UINT_MAX - USHRT_MAX);

	unsigned short HEADING_AWARD = 30; // valore aggiunto in percentuale se il termine si trova nel puntatore poutt->headings

	if (is_thematic == true)
	{
		themid_t themid = id;

		unsigned char amount_rules = 0;

		unsigned int rank = 0;

		if (themid < openidx->them_count)
			amount_rules = (th_dist_st[themid + 1].th_dist_offset - th_dist_st[themid].th_dist_offset);
		else
			amount_rules = (thematics_counter - th_dist_st[themid].th_dist_offset);
			// thematics_counter indica la lunghezza del buffer th_dist

		if (amount_rules > 0)
		{
			if (is_heading == true && in_sensitive == true)
				rank = (USHRT_MAX + ((USHRT_MAX / 100) * HEADING_AWARD));
			else if (is_heading == true || in_sensitive == true)
				rank = (USHRT_MAX + ((USHRT_MAX / 100) * HEADING_AWARD / 2));
			else
				rank = USHRT_MAX;

			rank_limit = (UINT_MAX - rank); // imposta il valore massimo del ranking
		}

		for (unsigned char a = 0; a < amount_rules; a++)
		{
			unsigned char i;

			bool ranking_assigned = false;

			for (i = 0; i < RBSIZE; i++)
			{
				if (tro->ranking_buffer[i].rule == USHRT_MAX)
					break;
	
				if (tro->ranking_buffer[i].rule == th_dist[(th_dist_st[themid].th_dist_offset + a)])
				{
					// non deve superare il limite del tipo dato
					if (tro->ranking_buffer[i].them_ranking >= (rank_limit - 1))
						return;

					tro->ranking_buffer[i].them_ranking += rank;

					ranking_assigned = true;

					break;
				}
			}

			// non è stata trovata la regola nel tro->ranking_buffer ma esiste lo spazio per inserirla
			if (ranking_assigned == false && i < (RBSIZE - 1))
			{
				// non deve superare il limite del tipo dato
				if (tro->ranking_buffer[i].them_ranking >= (rank_limit - 1))
					return;

				tro->ranking_buffer[i].them_ranking += rank;

				tro->ranking_buffer[i].rule = th_dist[(th_dist_st[themid].th_dist_offset + a)];

				tro->ranked_rules++;
			}
		}
		/* debug purpose
		char *word = CBALLOC(char, MALLOC, MAX_WORD_LEN);
		themidx_them_by_themid(themid, word);
		cout << word << '-' << themid << '-' << is_synonyms << '-' << is_heading << '-' <<  is_thematic << '-' <<  in_sensitive << endl;
		free(word);
		*/
	}
	else if (is_synonyms == true)
	{
		if ((unsigned short)id < USHRT_MAX)
		{
			unsigned short synonyms_line = (unsigned short)id;

			unsigned int rank_max = 0;

			unsigned int rank = 0;

			if (sy_dist_st[synonyms_line].amount_rules > 0)
			{
				if (is_heading == true)
					rank_max = (USHRT_MAX + ((USHRT_MAX / 100) * HEADING_AWARD));
				else
					rank_max = USHRT_MAX;
			}

			for (unsigned char a = 0; a < sy_dist_st[synonyms_line].amount_rules; a++)
			{
				unsigned char i;

				bool ranking_assigned = false;

				// imposta il valore massimo del ranking. In quante tematiche e in quante regole dentro tali tematiche del file pricipale
				// è presente il termine, in tal caso perde valore
				rank = rank_max / sy_dist[(sy_dist_st[synonyms_line].sy_dist_offset + a)].location_coefficient;

				rank_limit = (UINT_MAX - rank);

				for (i = 0; i < RBSIZE; i++)
				{
					if (tro->ranking_buffer[i].rule == USHRT_MAX)
						break;

					if (tro->ranking_buffer[i].rule == sy_dist[(sy_dist_st[synonyms_line].sy_dist_offset + a)].rule)
					{
						// non deve superare il limite del tipo dato
						if (tro->ranking_buffer[i].ranking >= (rank_limit - 1))
							return;

						// in quante regole del file pricipale è presente il sinonimo, in tal caso perde valore
						tro->ranking_buffer[i].ranking += rank;

						ranking_assigned = true;

						break;
					}
				}

				// non è stata trovata la regola nel tro->ranking_buffer ma esiste lo spazio per inserirla
				if (ranking_assigned == false && i < (RBSIZE - 1))
				{
					// non deve superare il limite del tipo dato
					if (tro->ranking_buffer[i].ranking >= (rank_limit - 1))
						return;

					tro->ranking_buffer[i].rule = sy_dist[(sy_dist_st[synonyms_line].sy_dist_offset + a)].rule;

					// in quante regole del file pricipale è presente il sinonimo, in tal caso perde valore
					tro->ranking_buffer[i].ranking += rank;

					tro->ranked_rules++;
				}
			}
		}
	}
	else
	{
		stemid_t stemid = id;

		unsigned char amount_rules = 0;

		unsigned int rank_max = 0;

		unsigned int rank = 0;

		if (stemid < openidx->stem_count)
			amount_rules = (st_dist_st[stemid + 1].st_dist_offset - st_dist_st[stemid].st_dist_offset);
		else
			amount_rules = (stemming_counter - st_dist_st[stemid].st_dist_offset);
			// stemming_counter indica la lunghezza del buffer st_dist

		if (amount_rules > 0)
		{
			if (is_heading == true)
				rank_max = (USHRT_MAX + ((USHRT_MAX / 100) * HEADING_AWARD));
			else
				rank_max = USHRT_MAX;
		}

		for (char a = 0; a < amount_rules; a++)
		{
			unsigned char i;

			bool ranking_assigned = false;

			// imposta il valore massimo del ranking. In quante tematiche e in quante regole dentro tali tematiche del file pricipale
			// è presente il termine, in tal caso perde valore
			rank = rank_max / st_dist[(st_dist_st[stemid].st_dist_offset + a)].location_coefficient;

			rank_limit = (UINT_MAX - rank);

			for (i = 0; i < RBSIZE; i++)
			{

				if (tro->ranking_buffer[i].rule == USHRT_MAX)
						break;
	
				if (tro->ranking_buffer[i].rule == st_dist[(st_dist_st[stemid].st_dist_offset + a)].rule)
				{
					// non deve superare il limite del tipo dato
					if (tro->ranking_buffer[i].ranking >= (rank_limit - 1))
						return;

					tro->ranking_buffer[i].ranking += rank;

					ranking_assigned = true;

					break;
				}
			}

			// non è stata trovata la regola nel tro->ranking_buffer ma esiste lo spazio per inserirla
			if (ranking_assigned == false && i < (RBSIZE - 1))
			{
				// non deve superare il limite del tipo dato
				if (tro->ranking_buffer[i].ranking >= (rank_limit - 1))
					return;

				tro->ranking_buffer[i].rule = st_dist[(st_dist_st[stemid].st_dist_offset + a)].rule;

				tro->ranking_buffer[i].ranking += rank;

				tro->ranked_rules++;
			}
		}
		/* debug purpose
		char *word = CBALLOC(char, MALLOC, MAX_WORD_LEN);
		themidx_stem_by_stemid(stemid, word);
		cout << word << '-' << stemid << endl;
		free(word);
		*/
	}
}

thematic_out_t *Thematics::make_dupl_index (Language &_lang, char *charenc, const size_t min_word_len, pes_t *poutt, size_t content_len) const
{
	// thematic ranking statistics are inside
	thematic_out_t *tro = CBALLOC(thematic_out_t, NEW, 1); // thematic ranking out
 
	// creazione indici con durata limitata all'esecuzione della funzione
	// Alloc and clean hash tables
	tro->tempidx.dupl_hash = CBALLOC(off64_t, CALLOC, MAXDUPLICATES);

	// Set default values
	tro->tempidx.dupl_count = 0;
	tro->tempidx.dupl_next_char = 1; // start in 1

	// dupl_list
	tro->tempidx.dupl_list = CBALLOC(off64_t, MALLOC, (MAXDUPLICATES + 1));

	// Create memory area for word names
	THEMIDX_DUPL_SIZE = THEMIDX_EXPECTED_DUPL_SIZE * MAXDUPLICATES;
	tro->tempidx.dupl = CBALLOC(char, MALLOC, THEMIDX_DUPL_SIZE);
	tro->tempidx.dupl[0] = ASCII_NUL;

	/* prepare stemming process: */
	tro->stemmer = NULL;

	char *la = lower_lang();

	tro->stemmer = sb_stemmer_new(la, charenc);

	if (tro->stemmer == NULL)
		die("unknown stemmer libstemmer_%s", la);

	free(la);

	// assegna memoria ai puntatori nella struttura che riassume il risultato che restituisce la classe delle tematiche
	tro->language = _lang;
	tro->thematic[0] = ASCII_NUL;
	tro->sensitive_words[0] = ASCII_NUL;
	tro->top_words[0] = ASCII_NUL;
	tro->good_words[0] = ASCII_NUL;
	tro->swlen = 0;
	tro->twlen = 0;
	tro->gwlen = 0;
	tro->count_terms = 0;
	tro->ranked_rules = 0;
	tro->ranked_thematics = 0;
	tro->ranking = 0;
	tro->synonyms_found = CBALLOC(unsigned short, MALLOC, (msline + 1));
	// fine assegnazione memoria

	// imposta ai valori iniziali
	for (unsigned char i = 0; i < msline; i++)
		tro->synonyms_found[i] = USHRT_MAX;

	// indica i limiti di numerazione degli id di duplicati
	// (gli id relativi a termini inseriti anche negli headings saranno inferiori a tro->duplicates_split_offset[0])
	tro->duplicates_split_offset[0] = (duplid_t)0;
	tro->duplicates_split_offset[1] = (duplid_t)0;

	// inserisco i valori iniziali nel buffer del ranking
	for (unsigned int i = 0; i < RBSIZE; i++)
	{
		tro->ranking_buffer[i].rule = USHRT_MAX;
		tro->ranking_buffer[i].ranking = 0;
		tro->ranking_buffer[i].them_ranking = 0;
	}

	tro->thematic_ranking = CBALLOC(unsigned long int, CALLOC, (openidx->them_count + 1));

	// Inizio lettura stdin
	bool content_readed = false;
	char *elaborate = CBALLOC(char, MALLOC, (MAX_WORD_LEN + 1));
	elaborate[0] = ASCII_NUL;
	size_t elaborate_offset = 0;
	size_t offset = 0;

	bool stop_ranking = false;
	const bool indomain = false;
	const bool is_clevel = false;

	duplid_t valid_words = ((double)((double)(content_len / PRATICAL_WORD_SIZE) / 100) * TEXTCHUNK); // parole dentro la parte di contenuto da analizzare

	unsigned int words_counter = 0;

	char *buffer = poutt->headings;

	run_again:

	if (buffer != NULL && buffer[0] != ASCII_NUL) // se esistono headings, questi si inseriscono prima nei duplicati
	{
		while(buffer[offset] != ASCII_NUL)
		{
			if (buffer[offset] != ASCII_SP)
			{
				if (elaborate_offset >= MAX_WORD_LEN) // skip whole string to next space
				{
					elaborate_offset = 0;
					elaborate[elaborate_offset] = ASCII_NUL;

					while (! (buffer[offset] == ASCII_NUL || buffer[offset] == ASCII_SP))
						offset++;

					continue;
				}
				else
				{
					elaborate[elaborate_offset++] = buffer[offset];
					elaborate[elaborate_offset] = ASCII_NUL;
				}

			}
			else
			{
				if (elaborate_offset > 1)
				{
					if (elaborate_offset <= MAX_WORD_LEN)
					{
						if (content_readed == false)
							checkThematicWord(tro, elaborate, min_word_len, stop_ranking, indomain, is_clevel);
						else
						{
							if (words_counter > valid_words)
								stop_ranking = true;

							if (words_counter < (UINT_MAX - USHRT_MAX)) // USHRT_MAX perchè al massimo la funzione 'checkThematicWord' restituisce al max USHRT_MAX
								words_counter += checkThematicWord(tro, elaborate, min_word_len, stop_ranking, indomain, is_clevel);
							else
								checkThematicWord(tro, elaborate, min_word_len, stop_ranking, indomain, is_clevel);
						}

						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
					}
				}
				else
				{
						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
				}
			}

			offset++;
		}

		if (content_readed == true)
			if (words_counter > valid_words)
				stop_ranking = true;

		if (elaborate_offset > min_word_len && elaborate_offset <= MAX_WORD_LEN)
			checkThematicWord(tro, elaborate, min_word_len, stop_ranking, indomain, is_clevel);

		if (content_readed == false)
			tro->duplicates_split_offset[0] = tro->tempidx.dupl_count; // a tutti i duplicati con id inferiori a questo (headings) verrà assegnato un punteggio maggiore
	}

	if (poutt->content != NULL && poutt->content[0] != ASCII_NUL && content_readed == false) 
	{
		elaborate[0] = ASCII_NUL;
		elaborate_offset = 0;
		offset = 0;
		buffer = poutt->content;
		content_readed = true;
		goto run_again;
	}

	tro->duplicates_split_offset[1] = tro->tempidx.dupl_count;

	free (elaborate);

	return tro;
}

void Thematics::index_read (thematic_out_t *tro, const char matrix[NUMROWS][NUMCOLS], unsigned int &row_dictionary_url, const size_t &min_word_len, pes_t *poutt, size_t &content_len, char *purlwords, char *cleveldomain, char *olevelsdomain) const
{
	// creazione indici con durata limitata all'esecuzione della funzione
	// Alloc and clean hash tables
	tro->tempidx.meta_hash = CBALLOC(off64_t, CALLOC, MAXMETA);

	tro->tempidx.meta_count = 0;
	tro->tempidx.meta_next_char = 1; // start in 1

	// meta_list
	tro->tempidx.meta_list = CBALLOC(off64_t, MALLOC, (MAXMETA + 1));

	// Create memory area for word names
	THEMIDX_META_SIZE = THEMIDX_EXPECTED_META_SIZE * MAXMETA;
	tro->tempidx.meta = CBALLOC(char, MALLOC, THEMIDX_META_SIZE);
	tro->tempidx.meta[0] = ASCII_NUL;

	duplid_t realmaxduplicates = ((MAXDUPLICATES / 100) * 80); // il numero massimo dei termini negli indici ebbene non superi mai l'80% del teorico (vedi THEMIDX_MAX_OCCUPANCY)

	/////////////////////////////////////////////// inizio ricerca parole sensibili ////////////////////////////////////////////////////////////////////////////
	// primo passo è inserire nell'indice delle meta word i termini già presenti nei nomi dominio affinchè siano preservati da inutili ricerche di parole sensibili
	char *elaborate = CBALLOC(char, MALLOC, (MAX_WORD_LEN + 1));
	elaborate[0] = ASCII_NUL;
	size_t elaborate_offset = 0;
	size_t offset = 0;

	char *buffer = cleveldomain;

	tro->metawords_split_offset = 0;

	if (buffer != NULL && buffer[0] != ASCII_NUL) // versione migliorata del ciclo dentro la condizione 'if' perchè deve gestire i buffer overflow 
	{
		while(buffer[offset] != ASCII_NUL)
		{
			if (buffer[offset] != ASCII_SP)
			{
				if (elaborate_offset >= MAX_WORD_LEN) // skip whole string to next space
				{
					elaborate_offset = 0;
					elaborate[elaborate_offset] = ASCII_NUL;

					while (! (buffer[offset] == ASCII_NUL || buffer[offset] == ASCII_SP))
						offset++;

					continue;
				}
				else
				{
					elaborate[elaborate_offset++] = buffer[offset];
					elaborate[elaborate_offset] = ASCII_NUL;
				}

			}
			else
			{
				if (elaborate_offset > 1)
				{
					if (elaborate_offset <= MAX_WORD_LEN)
					{
						checkThematicWord(tro, elaborate, min_word_len, false, true, true);
						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
					}
				}
				else
				{
						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
				}
			}

			offset++;
		}

		if (elaborate_offset > min_word_len && elaborate_offset <= MAX_WORD_LEN)
			checkThematicWord(tro, elaborate, min_word_len, false, true, true);
	}

	elaborate[0] = ASCII_NUL;
	elaborate_offset = 0;
	offset = 0;

	buffer = olevelsdomain; //

	if (buffer != NULL && buffer[0] != ASCII_NUL) // versione migliorata del ciclo dentro la condizione 'if' perchè deve gestire i buffer overflow 
	{
		while(buffer[offset] != ASCII_NUL)
		{
			if (buffer[offset] != ASCII_SP)
			{
				if (elaborate_offset >= MAX_WORD_LEN) // skip whole string to next space
				{
					elaborate_offset = 0;
					elaborate[elaborate_offset] = ASCII_NUL;

					while (! (buffer[offset] == ASCII_NUL || buffer[offset] == ASCII_SP))
						offset++;

					continue;
				}
				else
				{
					elaborate[elaborate_offset++] = buffer[offset];
					elaborate[elaborate_offset] = ASCII_NUL;
				}

			}
			else
			{
				if (elaborate_offset > 1)
				{
					if (elaborate_offset <= MAX_WORD_LEN)
					{
						checkThematicWord(tro, elaborate, min_word_len, false, true, false);
						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
					}
				}
				else
				{
						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
				}
			}

			offset++;
		}

		if (elaborate_offset > min_word_len && elaborate_offset <= MAX_WORD_LEN)
			checkThematicWord(tro, elaborate, min_word_len, false, true, false);
	}

	tro->metawords_split_offset = tro->tempidx.meta_count; // Indica l'ultimo metaid relativo ai termini dentro i nomi di dominio
	// fine primo punto

	// inizio preparazione puntatore in cui area puntata accorre trovare i termini sensibili							
	size_t ptextsize = 0; // occorre aggiungere solo '1' spazio separatatore xchè purlwords ha già lo spazio finale

	// calcola lo spazio necessario a ptext
	if (purlwords != NULL)
		ptextsize = strlen(purlwords);

	if (poutt->metakeyw[0] != ASCII_NUL)
	{
		ptextsize += (strlen(poutt->metakeyw) + 1); // occorre aggiungere solo '1' spazio separatatore xchè purlwords ha già lo spazio finale

		if (poutt->metadesc[0] != ASCII_NUL)
			ptextsize += 1;
	}

	if (poutt->metadesc[0] != ASCII_NUL)
		ptextsize += (strlen(poutt->metadesc)); // al momento i termini dentro le mata descrizioni non vengono cercati (si limita l'utilizzo della cpu) 

	char *ptext = NULL;

	if (ptextsize > 0)
	{
		ptext = CBALLOC(char, MALLOC, (ptextsize + 1));
		ptext[0] = ASCII_NUL;

		if (purlwords != NULL)
				strcpy(ptext,purlwords); // purlwords ha già lo spazio finale

		if (poutt->metakeyw[0] != ASCII_NUL)
		{
			if (purlwords == NULL)
				strcpy(ptext,poutt->metakeyw);
			else
				strcat(ptext,poutt->metakeyw);

			if (poutt->metadesc[0] != ASCII_NUL)
				strcat(ptext, " ");
		}

		if (poutt->metadesc[0] != ASCII_NUL)
		{
			if (purlwords != NULL || poutt->metakeyw[0] != ASCII_NUL)
				strcat(ptext,poutt->metadesc);
			else
				strcpy(ptext,poutt->metadesc);
		}

		// rimuove eventuali spazi in coda
		while (ptext[ptextsize - 1] == ' ' && ptextsize > 1)
		{
			ptextsize--;
			ptext[ptextsize] = ASCII_NUL;
		}


		elaborate[0] = ASCII_NUL;
		elaborate_offset = 0;
		offset = 0;

		buffer = ptext;

		// Crea il puntatore che contiene le linee sinonimi presenti in ptext (serve per evitare parole di sinonimi duplicati in synonyms_words)
		// Ad ogni chiamata della funzione checkSensitiveWord l'argomento viene passato e ricevuto eventualmente incrementato
		unsigned short *synonyms_sensitive_found = CBALLOC(unsigned short, MALLOC, msline);

		for (unsigned short pos = 0; pos < msline; pos++)
			synonyms_sensitive_found[pos] = USHRT_MAX;

		if (buffer != NULL && buffer[0] != ASCII_NUL) // versione migliorata del ciclo dentro la condizione 'if' perchè deve gestire i buffer overflow 
		{
			while(buffer[offset] != ASCII_NUL)
			{
				// normalmente in ptext ci sono parecchi caratteri separatori, meglio cercarli a monte
				if ( ! (buffer[offset] == ASCII_SP ||
						buffer[offset] == ASCII_CM ||
						buffer[offset] == ASCII_SL ||
						buffer[offset] == ASCII_DT ||
						buffer[offset] == ASCII_CO ||
						buffer[offset] == ASCII_SC) )
				{
					if (elaborate_offset >= MAX_WORD_LEN) // skip whole string to next space
					{
						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;

						while ( ! ( buffer[offset] == ASCII_NUL ||
									buffer[offset] == ASCII_SP ||
									buffer[offset] == ASCII_CM ||
									buffer[offset] == ASCII_SL ||
									buffer[offset] == ASCII_DT ||
									buffer[offset] == ASCII_CO ||
									buffer[offset] == ASCII_SC ) )
							offset++;

						continue;
					}
					else
					{
						elaborate[elaborate_offset++] = buffer[offset];
						elaborate[elaborate_offset] = ASCII_NUL;
					}

				}
				else
				{
					if (elaborate_offset > 1)
					{
						if (elaborate_offset <= MAX_WORD_LEN)
						{
							synonyms_sensitive_found = checkSensitiveWord(tro, elaborate, min_word_len, synonyms_sensitive_found);

							elaborate_offset = 0;
							elaborate[elaborate_offset] = ASCII_NUL;
						}
					}
					else
					{
							elaborate_offset = 0;
							elaborate[elaborate_offset] = ASCII_NUL;
					}
				}

				offset++;
			}

			if (elaborate_offset > min_word_len && elaborate_offset <= MAX_WORD_LEN)
				synonyms_sensitive_found = checkSensitiveWord(tro, elaborate, min_word_len, synonyms_sensitive_found);
		}

		free(synonyms_sensitive_found);
	}

	if (ptext != NULL)
		free(ptext);
	// fine ricerca parole sensibili

	if (tro->ranked_rules == 0)
	{
		tro->ranking = 0;
		free(elaborate);
		return;
	}

	// debug of ranking
	unsigned long int average_rank = 0;
	unsigned long int second_rank = 0;
	unsigned short null_thematic_count = 0;

	struct null_struct {
		unsigned long int rank;
		unsigned short rule;
		unsigned short terms;
	} top_null_thematic, second_null_thematic;

	top_null_thematic.rank = 0;
	top_null_thematic.rule = 0;
	top_null_thematic.terms = 0;
	second_null_thematic.rank = 0;
	second_null_thematic.rule = 0;
	second_null_thematic.terms = 0;

	themid_t top_thematic = 0;

	unsigned short text_quality = (realmaxduplicates / logarithm(tro->tempidx.dupl_count,(double)2)); // Più e lungo un testo "più è probabile sia vago" 

	// assegna il punteggio alle tematiche
	for (unsigned char c = 0; c < RBSIZE; c++)
		if (tro->ranking_buffer[c].rule < USHRT_MAX)
		{
			unsigned long int rank = (tro->ranking_buffer[c].ranking / logarithm(main_structs[(tro->ranking_buffer[c].rule)].terms,(double)2)) * text_quality;

			if (main_structs[(tro->ranking_buffer[c].rule)].thematic > 1)
			{
				if (tro->thematic_ranking[main_structs[(tro->ranking_buffer[c].rule)].thematic] == 0 && ((rank + tro->ranking_buffer[c].them_ranking) < UINT_MAX))
					rank = rank + tro->ranking_buffer[c].them_ranking;
			}
			else
			{
				if ((rank + tro->ranking_buffer[c].ranking) < UINT_MAX)
					rank = rank + tro->ranking_buffer[c].ranking;
			}


			if (rank < UINT_MAX && rank > 0)
			{
				if (tro->thematic_ranking[main_structs[(tro->ranking_buffer[c].rule)].thematic] == 0 || main_structs[(tro->ranking_buffer[c].rule)].thematic == 1)
					tro->ranked_thematics++;

				if (main_structs[(tro->ranking_buffer[c].rule)].thematic > 1)
					tro->thematic_ranking[main_structs[(tro->ranking_buffer[c].rule)].thematic] += rank;
				else
				{
					if (rank > top_null_thematic.rank)
					{
						
						second_null_thematic.rank = top_null_thematic.rank;
						second_null_thematic.rule = top_null_thematic.rule;
						second_null_thematic.terms = top_null_thematic.terms;
						top_null_thematic.rank = rank;
						top_null_thematic.rule = tro->ranking_buffer[c].rule;
						top_null_thematic.terms = main_structs[tro->ranking_buffer[c].rule].terms;
					}
					else if (rank > second_null_thematic.rank)
					{
						second_null_thematic.rank = rank;
						second_null_thematic.rule = tro->ranking_buffer[c].rule;
						second_null_thematic.terms = main_structs[tro->ranking_buffer[c].rule].terms;
					}
					// Calcola la media in 'tempo reale' per ogni punteggio aggiunto.
					double coefficent = ((double)null_thematic_count / ((double)null_thematic_count + 1));

					null_thematic_count++;

					average_rank = average_rank * coefficent + rank / null_thematic_count;
				}
			}

		}
		else
			break;

	// Se esistono tematiche nulle che influiscono sulla media occorre ricalcolare la stessa in base al numero totale di tematiche coinvolte nel ranking
	if (null_thematic_count > 0)
	{
		double coefficent = ((double)null_thematic_count / ((double)tro->ranked_thematics));

		average_rank = average_rank * coefficent;
	}

	// trova la tematica (ad esclusione della nulla) con maggiore punteggio
	if (tro->ranked_thematics > 0)
	{
		for (themid_t themid = 2; themid <= openidx->them_count; themid++)
		{
			average_rank += (tro->thematic_ranking[themid] / tro->ranked_thematics);

			if (tro->thematic_ranking[themid] > tro->ranking )
			{
				second_rank = tro->ranking;
				tro->ranking = tro->thematic_ranking[themid];
				top_thematic = themid;
			}
			else if (tro->thematic_ranking[themid] > second_rank)
				second_rank = tro->thematic_ranking[themid];
		}
	}
	else
	{
		tro->ranking = 0;
		free(elaborate);
		return;
	}

	unsigned int top_thematic_terms = 0;

	// confronta le tematiche con eventuali tematiche nulle
	if (top_null_thematic.rank > tro->ranking)
	{
		top_thematic_terms = main_structs[top_null_thematic.rule].terms;
		tro->ranking = top_null_thematic.rank;
		top_thematic = 1;
	}
	else
	{
		// se è stata trovata una sola tematica occorre trovare il numero di termini totali utilizzati nella stessa tematica
		if (tro->ranked_thematics == 1 && top_null_thematic.rank == 0)
			for (unsigned char c = 0; c < RBSIZE; c++)
			{
				if (tro->ranking_buffer[c].rule < USHRT_MAX)
				{
					if (main_structs[tro->ranking_buffer[c].rule].thematic == top_thematic)
						top_thematic_terms += main_structs[tro->ranking_buffer[c].rule].terms;
				}
				else
					break;
			}
	}

	// Se sono state trovate tematiche nulle ma nessuna di queste è al top in classifica
	// cerca se eventualmente potrebbe avere il secondo punteggio
	if (top_thematic > 1 && null_thematic_count > 1)
	{
		if (top_null_thematic.rank > second_rank)
			second_rank = top_null_thematic.rank;
		else if (second_null_thematic.rank > second_rank)
			second_rank = second_null_thematic.rank;
	}
///////////////////////////////// da continuare //////////////////////////////////////

	// se è stata trovata più di una tematica la media non deve essere influenzata dal punteggio assegnato a top_thematic
	unsigned int *ranking = &tro->ranking;
	themid_t *rt = &tro->ranked_thematics;

	if (tro->ranked_thematics > 1)
		average_rank = (average_rank - (*ranking / *rt)) / (*rt - 1) * (*rt);

	if (top_thematic > 0 && top_thematic <= openidx->them_count && ((*rt > 1 && (*ranking > (second_rank * SR_CONST)) && (*ranking >= (average_rank * FM))) || ((*rt == 1 && (*ranking >= ((USHRT_MAX / logarithm(top_thematic_terms,(double)2)) * text_quality * FM))))))
	{
		unsigned char amount_rules = 0;

		if (top_thematic > 1)
		{
			if (top_thematic < openidx->them_count)
				amount_rules = (th_dist_st[top_thematic + 1].th_dist_offset - th_dist_st[top_thematic].th_dist_offset);
			else
				amount_rules = (thematics_counter - th_dist_st[top_thematic].th_dist_offset);
		}
		else
			amount_rules = 1;

		//cout << "top thematic " << top_thematic << " ranking " << *ranking << " thematics " << *rt << " second " << second_rank << " average " << average_rank << " amount rules " << (int)amount_rules << endl;

		if (amount_rules > 0)
		{
			if (top_thematic > 1) // se diversa da null ricava il nome della tematica
				themidx_them_by_themid(top_thematic, tro->thematic);

			size_t storic_size = 0;

			if (top_thematic > 1)
			{
				for (unsigned char a = 0; a < amount_rules; a++)
				{
					unsigned short rule = th_dist[(th_dist_st[top_thematic].th_dist_offset + a)];

					storic_size += ((rule < (mcrule - 1)) ? main_structs[(rule + 1)].rule_offset : terms_counter) - main_structs[rule].rule_offset;
				}
			}
			else
				storic_size = top_null_thematic.terms;

			unsigned short *line_synonyms_visited = CBALLOC(unsigned short, MALLOC, storic_size);

			for (size_t pos = 0; pos < storic_size; pos++)
				line_synonyms_visited[pos] = USHRT_MAX;				

			stemid_t *stemid_visited = CBALLOC(stemid_t, MALLOC, storic_size);

			for (size_t pos = 0; pos < storic_size; pos++)
				stemid_visited[pos] = 0;				

			for (unsigned char a = 0; a < amount_rules; a++)
			{
				unsigned short rule = USHRT_MAX;

				if (top_thematic > 1)
					rule = th_dist[(th_dist_st[top_thematic].th_dist_offset + a)];
				else
					rule = top_null_thematic.rule;

				size_t main_offset_start = main_structs[rule].rule_offset;

				size_t main_offset_stop = (rule < (mcrule - 1)) ? main_structs[(rule + 1)].rule_offset : terms_counter;

				bool synonyms = false;
				bool stemming = false;

				for (unsigned short s = (main_offset_start + 1); s < main_offset_stop; s++)
				{
					if (main_buffer[s].is_thematic == false)
					{
						if (main_buffer[s].is_synonyms == true)
						{
							// crea una lista di parole sensibili e contemporaneamente sinonimi già elaborate
							size_t pos = 0;

							bool found_line = false;

							for (pos = 0; line_synonyms_visited[pos] < USHRT_MAX; pos++)
							{
								if (line_synonyms_visited[pos] == main_buffer[s].generic_id)
								{
									found_line = true;
									break;
								}
							}

							if (found_line == true)
								continue;

							line_synonyms_visited[pos] = main_buffer[s].generic_id; // incrementa la lista delle linee sinonimi verificate

							size_t start = (main_buffer[s].generic_id == 0) ? 0 : line_synonyms_structs[main_buffer[s].generic_id].line_offset;
							size_t end = (main_buffer[s].generic_id < msline) ? line_synonyms_structs[(main_buffer[s].generic_id + 1)].line_offset : strlen(synonyms_buffer);

							if (synonyms == false)
								synonyms = true;

							char temparray[MAX_WORD_LEN] = {ASCII_NUL};

							char exclude_word[MAX_WORD_LEN] = {ASCII_NUL};

							size_t ta_counter = 0;

							bool word_exist = true;

							get_synoyms:

							for (size_t o = start; o < end; o++)
							{
								if (synonyms_buffer[o] == ' ')
								{
									size_t tlength = strlen(temparray);

									if (word_exist == true)
									{
										themidx_status_t drc = THEMIDX_ERROR;
										themidx_status_t mrc = THEMIDX_ERROR;
										metaid_t metaid = 0;

										bool found_indomain = false;

										char *stemming = doStemming(tro, temparray, tlength, (tlength + 1));

										drc = themidx_resolve_dupl(tro,  NULL, stemming, NULL, true );

										mrc = themidx_resolve_meta(tro,  stemming, &(metaid), true );

										if (mrc == THEMIDX_EXISTENT && metaid <= tro->metawords_split_offset)
											found_indomain = true;

										free(stemming);

										if (found_indomain == false && drc == THEMIDX_EXISTENT)
										{
											word_exist = false;

											strcpy(exclude_word, temparray);

											if ((tro->twlen + tlength) < MAX_STR_LEN)
											{
												if (tro->top_words[0] == ASCII_NUL)
												{
													strcpy(tro->top_words, temparray);
													tro->twlen = tlength;
												}
												else
												{
													strcat(tro->top_words, " ");
													strcat(tro->top_words, temparray);
													tro->twlen += (tlength + 1);
												}

												tro->count_terms++;
											}

											memset (temparray,ASCII_NUL,MAX_WORD_LEN);
											ta_counter = 0;
											goto get_synoyms;
										}
									}
									else
									{
										if (strcmp (exclude_word, temparray) != 0 && (tro->gwlen + tlength) < MAX_STR_LEN)
										{
											if (tro->good_words[0] == ASCII_NUL)
											{
												strcpy(tro->good_words, temparray);
												tro->gwlen = tlength;
											}
											else
											{
												strcat(tro->good_words, " ");
												strcat(tro->good_words, temparray);
												tro->gwlen += (tlength + 1);
											}
										}
									}

									memset (temparray,ASCII_NUL,MAX_WORD_LEN);
									ta_counter = 0;
								}
								else
								{
									temparray[ta_counter] = synonyms_buffer[o];
									ta_counter++;
								}
							}			
						}
						else
						{
							// crea una lista di parole sensibili e contemporaneamente sinonimi già elaborate
							size_t pos = 0;

							bool found_line = false;

							for (pos = 0; stemid_visited[pos] > 0; pos++)
							{
								if (stemid_visited[pos] == main_buffer[s].generic_id)
								{
									found_line = true;
									break;
								}
							}

							if (found_line == true)
								continue;

							// incrementa la lista degli identificativi di stemming verificati
							stemid_visited[pos] = main_buffer[s].generic_id;

							themidx_status_t mrc = THEMIDX_ERROR;
							themidx_status_t drc = THEMIDX_ERROR;

							if (stemming == false)
								stemming = true;

							char *original = CBALLOC(char, MALLOC, (MAX_WORD_LEN + 1));

							themidx_stem_by_stemid(main_buffer[s].generic_id, original);

							size_t olen = strlen(original);

							duplid_t duplid = 0;
							metaid_t metaid = 0;

							bool found_indomain = false;

							char *stemming = doStemming(tro, original, olen, (olen + 1));

							drc = themidx_resolve_dupl(tro,  NULL, stemming, &(duplid), true );

							mrc = themidx_resolve_meta(tro,  stemming, &(metaid), true );

							if (mrc == THEMIDX_EXISTENT && metaid <= tro->metawords_split_offset)
								found_indomain = true;

							free(stemming);

							if (found_indomain == false && drc == THEMIDX_EXISTENT && (tro->twlen + olen) < MAX_STR_LEN)
							{
								if (tro->top_words[0] == ASCII_NUL)
								{
									strcpy(tro->top_words, original);
									tro->twlen = olen;
								}
								else
								{
									strcat(tro->top_words, " ");
									strcat(tro->top_words, original);
									tro->twlen += (olen + 1);
								}

								tro->count_terms++;
							}

							free(original);
							}
						}
					}
			}

			free(line_synonyms_visited);
			free(stemid_visited);
		}

		// DA UN'INDICAZIONE REALE SU QUANTO VALE IL RANKING (questo dato è utile al motore di ricerca)
		// Al ranking finale viene sottratta la media (per capire quanto prevale su di essa) e
		// la differenza tra il ranking e il second_ranking divisa per la radice quadrata del numero delle tematiche totali trovate
		//
		if (tro->ranked_thematics > 1)
		{
			unsigned int val = *ranking - ((average_rank + (*ranking - second_rank)) / sqrt(*rt));

			if (val > THEMTHRESHOLD)
				val = THEMTHRESHOLD;

			// pseudo normalizzazione del ranking della tematica riferita appunto a THEMTHRESHOLD
			tro->ranking = ((float)val / (float)THEMTHRESHOLD) * THEMRANK_MAX;
		}
		else
			tro->ranking = ((float)*ranking / (float)THEMTHRESHOLD) * THEMRANK_MAX;
			// pseudo normalizzazione del ranking della tematica riferita appunto a THEMTHRESHOLD
	}
	else
		tro->ranking = 0;

	free(elaborate);
}

void Thematics::free_dupl_index (thematic_out_t *tro) const
{

	sb_stemmer_delete(tro->stemmer); tro->stemmer = NULL;
	free( tro->thematic_ranking ); tro->thematic_ranking = NULL;
	free( tro->synonyms_found ); tro->synonyms_found = NULL;
	free( tro->tempidx.dupl_list ); tro->tempidx.dupl_list = NULL;
	free( tro->tempidx.meta_list ); tro->tempidx.meta_list = NULL;
	free( tro->tempidx.dupl_hash ); tro->tempidx.dupl_hash = NULL;
	free( tro->tempidx.meta_hash ); tro->tempidx.meta_hash = NULL;
	free( tro->tempidx.dupl ); tro->tempidx.dupl = NULL;
	free( tro->tempidx.meta ); tro->tempidx.meta = NULL;
	delete [] tro; tro = NULL;
}

void Thematics::index_open (void)
{
	cerr << "Open word indexes for elaboration " << endl;
	themidx_new(); // themidx_open() non necessaria se non si lavora su disco
}

void Thematics::index_close (bool close_all)
{
//	cerr << "Close word indexes." << endl;
	themidx_close();

	if (close_all == true)
	{
		sb_stemmer_delete(stemmer);
		free (wordform_struct);
		free (synonyms_buffer);
		free (line_synonyms_structs);
		free (main_buffer);
		free (main_structs);
		free (th_dist_st);
		free (th_dist);
		free (sy_dist_st);
		free (sy_dist);
		free (st_dist_st);
		free (st_dist);
	}
}

//
// Name: themidx_new
//
// Description:
//   Creates a new index in the given directory
//
// Input:
//   dirname - directory to create url index
//
// Return:
//   urlindex structure
//
void Thematics::themidx_new( void ) {

	openidx = CBALLOC(themidx_t, MALLOC, 1);

	assert( CONF_OK );

	// Alloc and clean hash tables
	openidx->them_hash = CBALLOC(off64_t, CALLOC, MAXTHEMATICS);

	// Alloc and clean hash tables
	openidx->stem_hash = CBALLOC(off64_t, CALLOC, MAXSTEMMING);

	// Alloc and clean hash tables
	openidx->word_hash = CBALLOC(off64_t, CALLOC, MAXWORDS);

	// Set default values
	openidx->them_count = 0;
	openidx->them_next_char = 1; // start in 1
	openidx->stem_count = 0;
	openidx->stem_next_char = 1; // start in 1
	openidx->word_count = 0;
	openidx->word_next_char = 1; // start in 1

	// them_list
	openidx->them_list = CBALLOC(off64_t, MALLOC, (MAXTHEMATICS + 1));

	// stem_list
	openidx->stem_list = CBALLOC(off64_t, MALLOC, (MAXSTEMMING + 1));

	// word_list
	openidx->word_list = CBALLOC(off64_t, MALLOC, (MAXWORDS + 1));

	// Create memory area for thematics word names
	THEMIDX_THEM_SIZE = THEMIDX_EXPECTED_THEM_SIZE * MAXTHEMATICS;
	openidx->them = CBALLOC(char, MALLOC, THEMIDX_THEM_SIZE);
	openidx->them[0] = ASCII_NUL;

	// Create memory area for word names
	THEMIDX_STEM_SIZE = THEMIDX_EXPECTED_STEM_SIZE * MAXSTEMMING;
	openidx->stem = CBALLOC(char, MALLOC, THEMIDX_STEM_SIZE);
	openidx->stem[0] = ASCII_NUL;

	// Create memory area for word names
	THEMIDX_WORD_SIZE = THEMIDX_EXPECTED_WORD_SIZE * MAXWORDS;
	openidx->word = CBALLOC(char, MALLOC, THEMIDX_WORD_SIZE);
	openidx->word[0] = ASCII_NUL;
} 
                                            
//
// Name: themidx_resolve_them
//
// Description:
//   Verify a stemming of word name and add it whole word if necessary
//
// Input:
//   themidx - the url index structure
//   them - the thematic to check
//
// Output:
//   themid - themid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the thematic existed
//   THEMIDX_CREATED_THEM - the thematic word was added
//   THEMIDX_NOT_FOUND - the thematic word is not known and was not created
//
themidx_status_t Thematics:: themidx_resolve_them( const char *original, const char *them, themid_t *themid, bool readonly ) const {
	assert( openidx != NULL );
	assert( them != NULL );
	assert( strlen(them) > 0);

	if (them == NULL)
		return THEMIDX_NOT_FOUND;

	size_t olen = 0;

	if (readonly == false)
	{
		assert( original != NULL );
		olen = strlen(original);
		assert( olen > 0 );
	}

	themid_t bucket;

	// Check if the them exists
	// Check if the stemming of original word exists

	themid_t themid_check = themidx_check_them( them, &(bucket) );

	if( themid_check > 0 ) {
		if( themid != NULL ) {
			*themid	= themid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next themid
		*themid = ++(openidx->them_count);

		//cout << "Result 0 o 2, Sito:   " << them << "       Recupero il primo themid disponibile " << openidx->them_count << '-' << bucket << endl;
		if( openidx->them_count > MAXTHEMATICS ) {
			die( "Maximum number of thems exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->them_hash)[bucket] = (openidx->them_next_char);
//		cout << "Inserisco " << (openidx->them_next_char) << " in (openidx->them_hash)[" << bucket << "]" << " conferma " << (openidx->them_hash)[bucket] << endl;

		// Save in list of thems
		openidx->them_list[*themid - 1] = openidx->them_next_char;

		// Store string
		memcpy( openidx->them + openidx->them_next_char, original, olen + 1 );

		// Store themid
		memcpy( openidx->them + openidx->them_next_char + olen + 1, themid, sizeof(themid_t) );

		// Move char pointer
		openidx->them_next_char = openidx->them_next_char + olen + 1 + sizeof(themid_t);
		if( openidx->them_next_char > THEMIDX_THEM_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXTHEMATICS or EXPECTED_THEM_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_THEM;
}
                                            
//
// Name: themidx_resolve_them
//
// Description:
//   Verify a stemming of word name and add it whole word if necessary
//
// Input:
//   themidx - the url index structure
//   them - the thematic to check
//
// Output:
//   themid - themid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the thematic existed
//   THEMIDX_CREATED_THEM - the thematic word was added
//   THEMIDX_NOT_FOUND - the thematic word is not known and was not created
//
themidx_status_t Thematics:: themidx_resolve_them( thematic_out_t *tro, const char *original, const char *them, themid_t *themid, bool readonly ) const {
	assert( openidx != NULL );
	assert( them != NULL );
	assert( strlen(them) > 0);

	if (them == NULL)
		return THEMIDX_NOT_FOUND;

	size_t olen = 0;

	if (readonly == false)
	{
		assert( original != NULL );
		olen = strlen(original);
		assert( olen > 0 );
	}

	themid_t bucket;

	// Check if the them exists
	// Check if the stemming of original word exists

	themid_t themid_check = themidx_check_them( tro, them, &(bucket) );

	if( themid_check > 0 ) {
		if( themid != NULL ) {
			*themid	= themid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next themid
		*themid = ++(openidx->them_count);

		//cout << "Result 0 o 2, Sito:   " << them << "       Recupero il primo themid disponibile " << openidx->them_count << '-' << bucket << endl;
		if( openidx->them_count > MAXTHEMATICS ) {
			die( "Maximum number of thems exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->them_hash)[bucket] = (openidx->them_next_char);
//		cout << "Inserisco " << (openidx->them_next_char) << " in (openidx->them_hash)[" << bucket << "]" << " conferma " << (openidx->them_hash)[bucket] << endl;

		// Save in list of thems
		openidx->them_list[*themid - 1] = openidx->them_next_char;

		// Store string
		memcpy( openidx->them + openidx->them_next_char, original, olen + 1 );

		// Store themid
		memcpy( openidx->them + openidx->them_next_char + olen + 1, themid, sizeof(themid_t) );

		// Move char pointer
		openidx->them_next_char = openidx->them_next_char + olen + 1 + sizeof(themid_t);
		if( openidx->them_next_char > THEMIDX_THEM_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXTHEMATICS or EXPECTED_THEM_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_THEM;
}

//
// Name: themidx_resolve_stem
//
// Description:
//   Verify a stemming of word name and add it whole word if necessary
//   For pratical and performance reason, stemming was elaborate out of function.
//
// Input:
//   themidx - the url index structure
//   stem - the stem to check
//
// Output:
//   stemid - stemid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the site existed
//   THEMIDX_CREATED_STEM - the stemmed word was added
//   THEMIDX_NOT_FOUND - the second level stem is not known and was not created
//
themidx_status_t Thematics::themidx_resolve_stem( const char *original, const char *stem, stemid_t *stemid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( stem != NULL );

	if (stem == NULL)
		return THEMIDX_NOT_FOUND;

	size_t olen = 0;

	if (readonly == false)
	{
		assert( original != NULL );
		olen = strlen(original);
		assert( olen > 0 );
	}

	stemid_t bucket;

	// Check if the stem exists
	// Check if the stemming of original word exists

	stemid_t stemid_check = themidx_check_stem( stem, &(bucket) );

	if( stemid_check > 0 ) {
		if( stemid != NULL ) {
			*stemid	= stemid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next stemid
		*stemid = ++(openidx->stem_count);

		//cout << "Result 0 o 2, Sito:   " << stem << "       Recupero il primo stemid disponibile " << openidx->stem_count << '-' << bucket << endl;
		if( openidx->stem_count > MAXSTEMMING ) {
			die( "Maximum number of stems exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->stem_hash)[bucket] = (openidx->stem_next_char);
//		cout << "Inserisco " << (openidx->stem_next_char) << " in (openidx->stem_hash)[" << bucket << "]" << " conferma " << (openidx->stem_hash)[bucket] << endl;

		// Save in list of stems
		openidx->stem_list[*stemid - 1] = openidx->stem_next_char;

		// Store string
		memcpy( openidx->stem + openidx->stem_next_char, original, olen + 1 );

		// Store stemid
		memcpy( openidx->stem + openidx->stem_next_char + olen + 1, stemid, sizeof(stemid_t) );

		// Move char pointer
		openidx->stem_next_char = openidx->stem_next_char + olen + 1 + sizeof(stemid_t);
		if( openidx->stem_next_char > THEMIDX_STEM_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXSTEMMING or EXPECTED_STEM_SIZE" << endl;
			return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_STEM;
}

//
// Name: themidx_resolve_stem
//
// Description:
//   Verify a stemming of word name and add it whole word if necessary
//   For pratical and performance reason, stemming was elaborate out of function.
//
// Input:
//   themidx - the url index structure
//   stem - the stem to check
//
// Output:
//   stemid - stemid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the site existed
//   THEMIDX_CREATED_STEM - the stemmed word was added
//   THEMIDX_NOT_FOUND - the second level stem is not known and was not created
//
themidx_status_t Thematics::themidx_resolve_stem( thematic_out_t *tro, const char *original, const char *stem, stemid_t *stemid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( stem != NULL );

	if (stem == NULL)
		return THEMIDX_NOT_FOUND;

	size_t olen = 0;

	if (readonly == false)
	{
		assert( original != NULL );
		olen = strlen(original);
		assert( olen > 0 );
	}

	stemid_t bucket;

	// Check if the stem exists
	// Check if the stemming of original word exists

	stemid_t stemid_check = themidx_check_stem( tro, stem, &(bucket) );

	if( stemid_check > 0 ) {
		if( stemid != NULL ) {
			*stemid	= stemid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next stemid
		*stemid = ++(openidx->stem_count);

		//cout << "Result 0 o 2, Sito:   " << stem << "       Recupero il primo stemid disponibile " << openidx->stem_count << '-' << bucket << endl;
		if( openidx->stem_count > MAXSTEMMING ) {
			die( "Maximum number of stems exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->stem_hash)[bucket] = (openidx->stem_next_char);
//		cout << "Inserisco " << (openidx->stem_next_char) << " in (openidx->stem_hash)[" << bucket << "]" << " conferma " << (openidx->stem_hash)[bucket] << endl;

		// Save in list of stems
		openidx->stem_list[*stemid - 1] = openidx->stem_next_char;

		// Store string
		memcpy( openidx->stem + openidx->stem_next_char, original, olen + 1 );

		// Store stemid
		memcpy( openidx->stem + openidx->stem_next_char + olen + 1, stemid, sizeof(stemid_t) );

		// Move char pointer
		openidx->stem_next_char = openidx->stem_next_char + olen + 1 + sizeof(stemid_t);
		if( openidx->stem_next_char > THEMIDX_STEM_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXSTEMMING or EXPECTED_STEM_SIZE" << endl;
			return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_STEM;
}

//
// Name: themidx_resolve_word
//
// Description:
//   Verify a word name and add it if necessary
//
// Input:
//   themidx - the url index structure
//   word - the word to check
//
// Output:
//   wordid - wordid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the word existed
//   THEMIDX_CREATED_WORD - the word was added
//   THEMIDX_NOT_FOUND - the word is not known and was not created
//
themidx_status_t Thematics::themidx_resolve_word( const char *word, wordid_t *wordid, bool readonly ) const {
	assert( openidx != NULL );

	assert( word != NULL );

	if (word == NULL)
		return THEMIDX_NOT_FOUND;

	size_t wlen = strlen(word);
	assert( wlen > 0 );

	wordid_t bucket;
	wordid_t wordid_check;

	// Check if the word exists
	wordid_check = themidx_check_word( word, &(bucket) );

	if( wordid_check > 0 ) {
		if( wordid != NULL ) {
			*wordid	= wordid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next wordid
		*wordid = ++(openidx->word_count);
		//cout << "Result 0 o 2, Sito:   " << word << "       Recupero il primo wordid disponibile " << openidx->word_count << '-' << bucket << endl;
		if( openidx->word_count > MAXWORDS ) {
			die( "Maximum number of words exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->word_hash)[bucket] = (openidx->word_next_char);
//		cout << "Inserisco " << (openidx->word_next_char) << " in (openidx->word_hash)[" << bucket << "]" << " conferma " << (openidx->word_hash)[bucket] << endl;

		// Save in list of words
		openidx->word_list[*wordid - 1] = openidx->word_next_char;

		// Store string
		memcpy( openidx->word + openidx->word_next_char, word, wlen + 1 );

		// Store wordid
		memcpy( openidx->word + openidx->word_next_char + wlen + 1, wordid, sizeof(wordid_t) );

		// Move char pointer
		openidx->word_next_char = openidx->word_next_char + wlen + 1 + sizeof(wordid_t);
		if( openidx->word_next_char > THEMIDX_WORD_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXWORDS or EXPECTED_WORD_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_WORD;
}

//
// Name: themidx_resolve_dupl
//
// Description:
//   Verify a dupl name and add it if necessary
//
// Input:
//   themidx - the url index structure
//   dupl - the dupl to check
//
// Output:
//   duplid - duplid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the duplatic existed
//   THEMIDX_CREATED_DUPL - the duplatic dupl was added
//   THEMIDX_NOT_FOUND - the duplatic dupl is not known and was not created
//
themidx_status_t Thematics::themidx_resolve_dupl( thematic_out_t *tro,  const char *original, const char *dupl, duplid_t *duplid, bool readonly ) const {
	assert( tro != NULL );

	if (dupl == NULL)
		return THEMIDX_NOT_FOUND;

	size_t olen = 0;

	if (readonly == false)
	{
		assert( original != NULL );
		olen = strlen(original);
		assert( olen > 0 );
	}

	duplid_t bucket;

	// Check if the stemming of original word exists
	duplid_t duplid_check = themidx_check_dupl(tro,  dupl, &(bucket) );
	
	if( duplid_check > 0 ) {
		if( duplid != NULL ) {
			*duplid	= duplid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next duplid
		*duplid = ++(tro->tempidx.dupl_count);
		//cout << "Result 0 o 2, Sito:   " << dupl << "       Recupero il primo duplid disponibile " << tro->tempidx.dupl_count << '-' << bucket << endl;
		if( tro->tempidx.dupl_count > MAXDUPLICATES ) {
			die( "Maximum number of duplicates exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(tro->tempidx.dupl_hash)[bucket] = (tro->tempidx.dupl_next_char);
//		cout << "Inserisco " << (tro->tempidx.dupl_next_char) << " in (tro->tempidx.dupl_hash)[" << bucket << "]" << " conferma " << (tro->tempidx.dupl_hash)[bucket] << endl;

		// Save in list of dupls
		tro->tempidx.dupl_list[*duplid - 1] = tro->tempidx.dupl_next_char;

		// Store string
		memcpy( tro->tempidx.dupl + tro->tempidx.dupl_next_char, original, olen + 1 );

		// Store duplid
		memcpy( tro->tempidx.dupl + tro->tempidx.dupl_next_char + olen + 1, duplid, sizeof(duplid_t) );

		// Move char pointer
		tro->tempidx.dupl_next_char = tro->tempidx.dupl_next_char + olen + 1 + sizeof(duplid_t);
		if( tro->tempidx.dupl_next_char > THEMIDX_DUPL_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXDUPLICATES or EXPECTED_DUPL_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_DUPL;
}

//
// Name: themidx_resolve_meta
//
// Description:
//   Verify a meta name and add it if necessary
//
// Input:
//   themidx - the url index structure
//   meta - the meta to check
//
// Output:
//   metaid - metaid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the meta word existed
//   THEMIDX_CREATED_DUPL - the meta word was added
//   THEMIDX_NOT_FOUND - the meta word is not known and was not created
//
themidx_status_t Thematics::themidx_resolve_meta( thematic_out_t *tro, const char *meta, metaid_t *metaid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( meta != NULL );

	if (meta == NULL)
		return THEMIDX_NOT_FOUND;

	size_t mlen = strlen(meta);
	assert( mlen > 0 );

	metaid_t bucket;
	metaid_t metaid_check;

	// Check if the meta exists
	metaid_check = themidx_check_meta(tro,  meta, &(bucket) );

	if( metaid_check > 0 ) {
		if( metaid != NULL ) {
			*metaid	= metaid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next metaid

		// Save in list of metas
		*metaid = ++(tro->tempidx.meta_count);
		//cout << "Result 0 o 2, Sito:   " << meta << "       Recupero il primo metaid disponibile " << tro->tempidx.meta_count << '-' << bucket << endl;
		if( tro->tempidx.meta_count > MAXMETA ) {
			die( "Maximum number of metaicates exceeded, increase in configuration file"  );
		}


		// Save in list of metas
		// Put in bucket
		(tro->tempidx.meta_hash)[bucket] = (tro->tempidx.meta_next_char);
//		cout << "Inserisco " << (tro->tempidx.meta_next_char) << " in (tro->tempidx.meta_hash)[" << bucket << "]" << " conferma " << (tro->tempidx.meta_hash)[bucket] << endl;

		// Save in list of meta words
		tro->tempidx.meta_list[*metaid - 1] = tro->tempidx.meta_next_char;

		// Store string
		memcpy( tro->tempidx.meta + tro->tempidx.meta_next_char, meta, mlen + 1 );

		// Store metaid
		memcpy( tro->tempidx.meta + tro->tempidx.meta_next_char + mlen + 1, metaid, sizeof(metaid_t) );

		// Move char pointer
		tro->tempidx.meta_next_char = tro->tempidx.meta_next_char + mlen + 1 + sizeof(metaid_t);
		if( tro->tempidx.meta_next_char > THEMIDX_META_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXMETA or EXPECTED_META_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_META;
}

//
// Name: themidx_check_them
//
// Description:
//   Check if a word exists
//
// Input:
//   themidx - the thematic index structure
//   them - the thematic name to check
//   bucket - the bucket in which this was found
//
// Return
//   a wordid if resolved
//   0 if not found
//
themid_t Thematics::themidx_check_them( const char *them, themid_t *bucket ) const {
	assert( openidx != NULL );
	assert( them != NULL );
	assert( strlen( them ) > 0 );

	// First attempt to find bucket (debug purpose)
	//themid_t test = Url.hashing_them( them );
	//cout << "DOMAIN " << them << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_them( them );

	// Linear probing
	while( openidx->them_hash[(*bucket)] > 0 ) {

		off64_t position = (openidx->them_hash)[(*bucket)];
		// See if it's the same
		size_t len = strlen((openidx->them) + position);

		char *stemming = doStemming((openidx->them) + position, len, (len + 1));

		char *startpointer = stemming; // indirizzo iniziale che serve per liberare le risorse successivamente

		const char *input = them;

		if( stemming != NULL ) {
			// confronta passo-passo il termine originale con quello fornito come argomento
			while (*(stemming) != ASCII_NUL && *(input) != ASCII_NUL && *(stemming) == *(input) && *(stemming++) && *(input++));

			if (*stemming == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			{
				free (startpointer);

				return *((themid_t *)((openidx->them) + position + len + 1)); // restituisce l'id
			}

			free (startpointer);
		}
		(*bucket) = ((*bucket) + 1) % MAXTHEMATICS;
	}

	return (themid_t)0;
}

//
// Name: themidx_check_them
//
// Description:
//   Check if a word exists
//
// Input:
//   themidx - the thematic index structure
//   them - the thematic name to check
//   bucket - the bucket in which this was found
//
// Return
//   a wordid if resolved
//   0 if not found
//
themid_t Thematics::themidx_check_them( thematic_out_t *tro, const char *them, themid_t *bucket ) const {
	assert( openidx != NULL );
	assert( them != NULL );
	assert( strlen( them ) > 0 );

	// First attempt to find bucket (debug purpose)
	//themid_t test = Url.hashing_them( them );
	//cout << "DOMAIN " << them << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_them( them );

	// Linear probing
	while( openidx->them_hash[(*bucket)] > 0 ) {

		off64_t position = (openidx->them_hash)[(*bucket)];
		// See if it's the same
		size_t len = strlen((openidx->them) + position);

		char *stemming = doStemming(tro, (openidx->them) + position, len, (len + 1));

		char *startpointer = stemming; // indirizzo iniziale che serve per liberare le risorse successivamente

		const char *input = them;

		if( stemming != NULL ) {
			// confronta passo-passo il termine originale con quello fornito come argomento
			while (*(stemming) != ASCII_NUL && *(input) != ASCII_NUL && *(stemming) == *(input) && *(stemming++) && *(input++));

			if (*stemming == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			{
				free (startpointer);

				return *((themid_t *)((openidx->them) + position + len + 1)); // restituisce l'id
			}

			free (startpointer);
		}
		(*bucket) = ((*bucket) + 1) % MAXTHEMATICS;
	}

	return (themid_t)0;
}

//
// Name: urlddx_check_stem
//
// Description:
//   Check if a stem exists
//
// Input:
//   themidx - the stem index structure
//   stem - the stem name to check
//   bucket - the bucket in which this was found
//
// Return
//   a stemid if resolved
//   0 if not found
//
stemid_t Thematics::themidx_check_stem( const char *stem, stemid_t *bucket ) const {
	assert( openidx != NULL );
	assert( stem != NULL );
	assert( strlen( stem ) > 0 );

	// First attempt to find bucket (debug purpose)
	//stemid_t test = Url.hashing_them( stem );
	//cout << "DOMAIN " << stem << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_stem( stem );

	// Linear probing
	while( openidx->stem_hash[(*bucket)] > 0 ) {

		off64_t position = (openidx->stem_hash)[(*bucket)];
		// See if it's the same
		size_t len = strlen((openidx->stem) + position);

		char *stemming = doStemming((openidx->stem) + position, len, (len + 1));

		char *startpointer = stemming; // indirizzo iniziale che serve per liberare le risorse successivamente

		const char *input = stem;

		if( stemming != NULL ) {
			// confronta passo-passo il termine originale con quello fornito come argomento
			while (*(stemming) != ASCII_NUL && *(input) != ASCII_NUL && *(stemming) == *(input) && *(stemming++) && *(input++));

			if (*stemming == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			{
				free (startpointer);

				return *((stemid_t *)((openidx->stem) + position + len + 1)); // restituisce l'id
			}

			free (startpointer);
		}
		(*bucket) = ((*bucket) + 1) % MAXSTEMMING;
	}

	return (stemid_t)0;
}

//
// Name: urlddx_check_stem
//
// Description:
//   Check if a stem exists
//
// Input:
//   themidx - the stem index structure
//   stem - the stem name to check
//   bucket - the bucket in which this was found
//
// Return
//   a stemid if resolved
//   0 if not found
//
stemid_t Thematics::themidx_check_stem( thematic_out_t *tro, const char *stem, stemid_t *bucket ) const {
	assert( openidx != NULL );
	assert( stem != NULL );
	assert( strlen( stem ) > 0 );

	// First attempt to find bucket (debug purpose)
	//stemid_t test = Url.hashing_them( stem );
	//cout << "DOMAIN " << stem << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_stem( stem );

	// Linear probing
	while( openidx->stem_hash[(*bucket)] > 0 ) {

		off64_t position = (openidx->stem_hash)[(*bucket)];
		// See if it's the same
		size_t len = strlen((openidx->stem) + position);

		char *stemming = doStemming(tro, (openidx->stem) + position, len, (len + 1));

		char *startpointer = stemming; // indirizzo iniziale che serve per liberare le risorse successivamente

		const char *input = stem;

		if( stemming != NULL ) {
			// confronta passo-passo il termine originale con quello fornito come argomento
			while (*(stemming) != ASCII_NUL && *(input) != ASCII_NUL && *(stemming) == *(input) && *(stemming++) && *(input++));

			if (*stemming == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			{
				free (startpointer);

				return *((stemid_t *)((openidx->stem) + position + len + 1)); // restituisce l'id
			}

			free (startpointer);
		}
		(*bucket) = ((*bucket) + 1) % MAXSTEMMING;
	}

	return (stemid_t)0;
}

//
// Name: urlddx_check_word
//
// Description:
//   Check if a word exists
//
// Input:
//   themidx - the word index structure
//   word - the word name to check
//   bucket - the bucket in which this was found
//
// Return
//   a wordid if resolved
//   0 if not found
//
wordid_t Thematics::themidx_check_word( const char *word, wordid_t *bucket ) const {
	assert( openidx != NULL );
	assert( word != NULL );
	assert( strlen( word ) > 0 );


	// First attempt to find bucket (debug purpose)
	//wordid_t test = Url.hashing_them( word );
	//cout << "DOMAIN " << word << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_word( word );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( openidx->word_hash[(*bucket)] > 0 ) {

		char *pidx = openidx->word + openidx->word_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = word;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != ASCII_NUL && *(input) != ASCII_NUL && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			return *((wordid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % MAXWORDS;
	}

	return (wordid_t)0;
}

//
// Name: urlddx_check_dupl
//
// Description:
//   Check if a word exist
//
// Input:
//   themidx - the word index structure
//   dupl - the duplicate name to check
//   bucket - the bucket in which this was found
//
// Return
//   a duplid if resolved
//   0 if not found
//
duplid_t Thematics::themidx_check_dupl( thematic_out_t *tro, const char *dupl, duplid_t *bucket ) const {
	assert( openidx != NULL );
	assert( dupl != NULL );
	assert( strlen( dupl ) > 0 );


	// First attempt to find bucket (debug purpose)
	//duplid_t test = Url.hashing_them( dupl );
	//cout << "DOMAIN " << dupl << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_dupl( dupl );

	// Linear probing
	while( tro->tempidx.dupl_hash[(*bucket)] > 0 ) {

		off64_t position = (tro->tempidx.dupl_hash)[(*bucket)];
		// See if it's the same
		size_t len = strlen((tro->tempidx.dupl) + position); // misura da 'position' al primo carattere null

		char *stemming = doStemming(tro, (tro->tempidx.dupl) + position, len, (len + 1));

		char *startpointer = stemming; // indirizzo iniziale che serve per liberare le risorse successivamente

		const char *input = dupl;

		if( stemming != NULL ) {
			// confronta passo-passo il termine originale con quello fornito come argomento
			while (*(stemming) != ASCII_NUL && *(input) != ASCII_NUL && *(stemming) == *(input) && *(stemming++) && *(input++));

			if (*stemming == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			{
				free (startpointer);

				return *((duplid_t *)((tro->tempidx.dupl) + position + len + 1)); // restituisce l'id
			}

			free (startpointer);
		}
		(*bucket) = ((*bucket) + 1) % MAXDUPLICATES;
	}

	return (duplid_t)0;
}

//
// Name: urlddx_check_meta
//
// Description:
//   Check if a word exist
//
// Input:
//   themidx - the word index structure
//   meta - the meta name to check
//   bucket - the bucket in which this was found
//
// Return
//   a metaid if resolved
//   0 if not found
//
metaid_t Thematics::themidx_check_meta( thematic_out_t *tro, const char *meta, metaid_t *bucket ) const {
	assert( openidx != NULL );
	assert( meta != NULL );
	assert( strlen( meta ) > 0 );


	// First attempt to find bucket (debug purpose)
	//metaid_t test = Url.hashing_them( meta );
	//cout << "DOMAIN " << meta << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_meta( meta );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( tro->tempidx.meta_hash[(*bucket)] > 0 ) {

		char *pidx = tro->tempidx.meta + tro->tempidx.meta_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = meta;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != ASCII_NUL && *(input) != ASCII_NUL && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			return *((metaid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % MAXDUPLICATES;
	}

	return (metaid_t)0;
}

// Hashing Functions for thematic words
themid_t Thematics::themidx_hashing_them( const char *text ) const {
	themid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXTHEMATICS );
	}
	return val;
}

// Hashing Functions for stemming words
stemid_t Thematics::themidx_hashing_stem( const char *text ) const {
	stemid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXSTEMMING );
	}
	return val;
}

// Hashing Functions for whole words
wordid_t Thematics::themidx_hashing_word( const char *text ) const {
	wordid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXWORDS );
	}
	return val;
}

// Hashing Functions for duplicated words
duplid_t Thematics::themidx_hashing_dupl( const char *text ) const {
	duplid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXDUPLICATES );
	}
	return val;
}

// Hashing Functions for meta words
metaid_t Thematics::themidx_hashing_meta( const char *text ) const {
	metaid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXMETA );
	}
	return val;
}

// Name: themidx_them_by_themid
//
// Description:
//   Get the name of a word based on its id
//
//	TODO: This function must fail in an error condition.
//
void Thematics::themidx_them_by_themid(themid_t themid, char *themname ) const {

	if ( themid > 0 && themid <= openidx->them_count)
	{
		// Read offset
		off64_t offset;
		offset = openidx->them_list[(themid - 1)];

		// Copy
		assert( strlen( (openidx->them) + offset ) < MAX_WORD_LEN );
		strcpy( themname, (openidx->them) + offset );
	}
	else
		themname[0] = ASCII_NUL;
}

// Name: themidx_stem_by_stemid
//
// Description:
//   Get the name of a stem based on its id
//
//	TODO: This function must fail in an error condition.
//
void Thematics::themidx_stem_by_stemid( stemid_t stemid, char *stemname ) const {

	if ( stemid > 0 && stemid <= openidx->stem_count)
	{
		// Read offset
		off64_t offset;
		offset = openidx->stem_list[(stemid - 1)];

		// Copy
		assert( strlen( (openidx->stem) + offset ) < MAX_WORD_LEN );
		strcpy( stemname, (openidx->stem) + offset );
	}
	else
		stemname[0] = ASCII_NUL;
}

// Name: themidx_word_by_wordid
//
// Description:
//   Get the name of a word based on its id
//
//	TODO: This function must fail in an error condition.
//
void Thematics::themidx_word_by_wordid( wordid_t wordid, char *wordname ) const {

	if ( wordid > 0 && wordid <= openidx->word_count)
	{
		// Read offset
		off64_t offset;
		offset = openidx->word_list[(wordid - 1)];

		// Copy
		assert( strlen( (openidx->word) + offset ) < MAX_WORD_LEN );
		strcpy( wordname, (openidx->word) + offset );
	}
	else
		wordname[0] = ASCII_NUL;
}

// Name: themidx_dupl_by_duplid
//
// Description:
//   Get the name of a duplicated word in a page based on its id
//
//	TODO: This function must fail in an error condition.
//
void Thematics::themidx_dupl_by_duplid( thematic_out_t *tro, duplid_t duplid, char *duplname ) const {

	if ( duplid > 0 && duplid <= tro->tempidx.dupl_count)
	{
		// Read offset
		off64_t offset;
		offset = tro->tempidx.dupl_list[(duplid - 1)];

		// Copy
		assert( strlen( (tro->tempidx.dupl) + offset ) < MAX_WORD_LEN );
		strcpy( duplname, (tro->tempidx.dupl) + offset );
	}
	else
		duplname[0] = ASCII_NUL;
}

//
// Name: themidx_meta_by_metaid
//
// Description:
//   Get the name of a meta word in a page based on its id
//
//	TODO: This function must fail in an error condition.
//
void Thematics::themidx_meta_by_metaid( thematic_out_t *tro, metaid_t metaid, char *metaname ) const {

	if ( metaid > 0 && metaid <= tro->tempidx.meta_count)
	{
		// Read offset
		off64_t offset;
		offset = tro->tempidx.meta_list[(metaid - 1)];

		// Copy
		assert( strlen( (tro->tempidx.meta) + offset ) < MAX_WORD_LEN );
		strcpy( metaname, (tro->tempidx.meta) + offset );
	}
	else
		metaname[0] = ASCII_NUL;
}

//
// Name: lower_lang
//
// Description: Convert upper string language to lower
//
// Return: pointer to lower string
//
char *Thematics::lower_lang( void ) const {
	char *la = CBALLOC(char, CALLOC, 3);
	strncpy(la, LANGUAGE_STR(language), 2);
	la[0] = tolower(la[0]);
	la[1] = tolower(la[1]);
	la[2] = ASCII_NUL;
	return la;
}

//
// Name: themidx_close
//
// Description:
//   Closes the url index, saving data to disk
//
// Input:
//   themidx - the url index structure
//
void Thematics::themidx_close(void) {
	// Check what i'm going to close
	assert( openidx != NULL );

	// Close and nullify all the static filehandlers
	free( openidx->them_list ); openidx->them_list = NULL;
	free( openidx->stem_list ); openidx->stem_list = NULL;
	free( openidx->word_list ); openidx->word_list = NULL;
	free( openidx->them_hash ); openidx->them_hash = NULL;
	free( openidx->stem_hash ); openidx->stem_hash = NULL;
	free( openidx->word_hash ); openidx->word_hash = NULL;
	free( openidx->them ); openidx->them = NULL;
	free( openidx->stem ); openidx->stem = NULL;
	free( openidx->word ); openidx->word = NULL;
	free( openidx ); openidx = NULL;
}
