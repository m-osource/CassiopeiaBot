/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

// N.B. Il check della variabile http_status servirà (se necessario) come implementazione futura ad indicare al motore di ricerca i docid da cancellare o ripristinare
// al cambiare di tale stato
//if(HTTP_IS_OK(doc.http_status))

#include "doc_language_finder.h"

using namespace std;

thread_local cpu_set_t system_cpus;

pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;

const size_t min_word_len = 1;

// 
// Name: main
//
// Description:
//   Main program
int main( int argc, char **argv ) {

	cbot_start("words-binder"); // imposta le constanti

	while(1) {
		int option_index = 0;

		static struct option long_options[] = {
			{"help", 0, 0, 0},
			{"debugonly", 0, 0, 0},
			{"showlanguages", 0, 0, 0},
			{"from", 1, 0, 0},
			{"to", 1, 0, 0},
			{0, 0, 0, 0}
		};

		char c = getopt_long (argc, argv, "h", long_options, &option_index);

		if (c == -1)
			break;

		switch (c) {
			case 0:
				if( !strcmp( long_options[option_index].name, "from" ) ) {
					opt_from = atol( optarg );
					if( opt_from == 0 ) {
						doc_language_finder_usage();
					}
				} else if( !strcmp( long_options[option_index].name, "to" ) ) {
					opt_to = atol( optarg );
					if( opt_to == 0 ) {
						doc_language_finder_usage();
					}
				} else if( !strcmp( long_options[option_index].name, "debugonly" ) ) {
					debugonly = true;
				} else if( !strcmp( long_options[option_index].name, "showlanguages" ) ) {
					showlanguages = true;
				} else if( !strcmp( long_options[option_index].name, "help" ) ) {
					doc_language_finder_usage();
				}
				break;
			case 'h':
				doc_language_finder_usage();
				break;
			default:
				doc_language_finder_usage();
		}
	}

	// Reading configuration files of languages
	if (! (showlanguages == true && debugonly == true))
		cerr << "Prepare index of languages ... ";

	bool index_status = false;

	if (showlanguages == true && debugonly == true)
		index_status = la.index_setup ( (const size_t)1, true ); // min_word_len == 1
	else
		index_status = la.index_setup ( (const size_t)1, false ); // min_word_len == 1

	if (index_status == false)
		return 0;

	if (showlanguages == true && debugonly == true)
	{
		cerr << endl << "Closing index of languages ... ";
		la.index_close (true);
		cerr << "done" << endl;
		return 0;
	}
	else
		cerr << "done." << endl;


	// creazione indece temporaneo e popolamento parziale dei dati 'statici' che non dovranno più essere aggiunti
	//readStaticTerms (terms_split_offset, min_word_len, pexcluded, helpstring);


	// Open metaindex
	cerr << "metaindex ...";
	meta = new Meta ( COLLECTION_METADATA, true );
	meta->ddx_open();

	// Open storage
	cerr << "storage ... ";
	strg = new Storage ( COLLECTION_TEXT, true );
	strg->st_open();

	cerr << "done." << endl;


	//docid_t ndocs_ok	= 0;
	pthread_t *threads = (pthread_t *) malloc (CONF_COLLECTION_DISTRIBUTED * sizeof(pthread_t));

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		pthread_create( &threads[i], NULL, thread_function, &i );
	
	CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

	free(threads);

	cerr << endl << "Closing index of languages ... ";
	la.index_close (true);
	cerr << "done" << endl;

	cbot_stop(0);
}

void *thread_function(void *dummyPtr)
{
try
{
	instance_t *instance = (instance_t *) dummyPtr;

	instance_t inst = *instance;

	CPU_OPTIMIZE;

	char *buffer	= (char *)malloc(sizeof(char)*MAX_DOC_LEN);
	assert( buffer != NULL );
	// Default options
	docid_t start		= (*instance + 1);
	docid_t finish		= meta->doc_count();

	// Limits
	if( opt_from > (CONF_COLLECTION_DISTRIBUTED) ) {
		start = ((((opt_from - 1) / CONF_COLLECTION_DISTRIBUTED) * CONF_COLLECTION_DISTRIBUTED) + *instance);
	}

	if( opt_to > 0 && opt_to < meta->doc_count() ) {
		finish = opt_to;
	}

	for(docid_t docnum = start; docnum <= finish; docnum += CONF_COLLECTION_DISTRIBUTED)
	{
		metaddx_status_t rc;
		doc_t ddoc;
		ddoc.docid = docnum;

		rc = meta->doc_retrieve( &(ddoc) );

	   	if( rc == METADDX_OK && ddoc.duplicate_of == 0 ) 
		{
			if (binder(&(ddoc), buffer))
			{
				size_t length = 0;
				pes_t *poutt;
 
				if (ddoc.mime_type == MIME_TEXT_HTML)
				{
					poutt = htmlSplit(buffer); // Estrapolazione dei meta tags, contenuto ecc... dal buffer storage
				
					length = strlen(poutt->content);
				}
				else if (ddoc.mime_type == MIME_APPLICATION_PDF)
				{
					poutt = pdfSplit(buffer); // Estrapolazione dei meta informazioni, contenuto ecc... dal buffer storage
				
					length = strlen(poutt->content);
				}
				else if (ddoc.mime_type == MIME_TEXT_PLAIN)
				{
					poutt = (pes_t*) malloc (sizeof(pes_t));
					poutt->content = (char*) malloc (sizeof(char) * MAX_DOC_LEN);
					poutt->content[0] = ASCII_NUL;
					strcpy(poutt->content,buffer);
				
					length = strlen(buffer);

					poutt->title[0] = ASCII_NUL;
					poutt->headings[0] = ASCII_NUL;
					poutt->metadesc[0] = ASCII_NUL;
					poutt->metakeyw[0] = ASCII_NUL;
					poutt->metalmon = pes_t::NO_LOCAL_MONETARY;
				}
				else
					return NULL;

				// preparo l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
				// utile alla classe delle tematiche e alla ricerca dei termini infissi in map_abbreviated
				la.make_analisys_index (*instance, min_word_len, poutt, length);

				// Ricava il ranking delle tematiche e le parole sensibili, cioè presenti contemporaneamente in più campi della pagina html
				language_out_t *langinfo = la.index_analisys_read(*instance);

				if (debugonly == true && langinfo->ranking > 0)
				{
					char printout[50];
					sprintf (printout, "Language: %s for docid %lu", langinfo->language, (unsigned long int)ddoc.docid);
					cout << printout << endl;
				}

				// libero l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
				la.free_analisys_index(*instance);

				poutt->title[0] = ASCII_NUL;
				poutt->headings[0] = ASCII_NUL;
				poutt->metadesc[0] = ASCII_NUL;
				poutt->metakeyw[0] = ASCII_NUL;
				poutt->metalmon = pes_t::NO_LOCAL_MONETARY;

				// libera l'area (dealloca) di memoria puntata dal puntatore content anche se di default avviene al termine del programma
				free(poutt->content);
				free(poutt);
			}
		}
	}

	free(buffer);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(NULL);
}
}

// Nome: binder
//
// Descrizione: Funzione in cui vengono elaborati definitivamente i documenti prima di essere salvati dalla stessa funzione nell'indice/i
// del motore di ricerca con database 'tipo sql'.
//
// Argomenti: struttura doc_t, input buffer
//
// Restituisce: booleano che indica 'vero' se la funzione ha eseguito con successo
//
bool binder(doc_t *doc, char *buf)
{
	assert(doc->docid > 0);

	if (doc->duplicate_of > 0)
		return 1; // do nothing, but analyse in updatescores sessions

	storage_status_t rc = strg->read_document( doc, buf );

	if(rc != STORAGE_OK)
	{
		if (debugonly == false)
			cerr << "x";

		return 0;
	}

	return 1;
}

//
// Name: cleanup
//
// Description: 
//   Closes files, indexes
//
void cleanup() {
	if( meta != NULL ) {
		meta->ddx_close();
		delete meta;
		cerr << "[metaddx] ";
	}
	if( strg != NULL ) {
		strg->st_close();
		delete strg;
		cerr << "[storage] ";
	}
}

//
// Name: doc_language_finder_usage
//
// Description:
//   Prints an usage message, then stops
//
void doc_language_finder_usage() {
	cerr << "Usage: program --filelanguage filename [OPTION]" << endl;
	cerr << "Extract documents to be indexed, this is invoked by" << endl;
	cerr << "the indexer program, you should not run it directly." << endl;
	cerr << endl;
	cerr << " --from [arg]          First docid to index, default 1" << endl;
	cerr << " --to [arg]            Last docid to index, default ndocs" << endl;
	cerr << " --debugonly           DO NOT save site's content to disk or index data. It use /tmp partition for all operation." << endl;
	cerr << "                       Check if /tmp is mounted as tmpfs in /etc/fstab and if it have a large size!!!" << endl;
	cerr << " --showlanguages       If the option 'debugonly' has been selected, print only the languages stopwords and exit." << endl;
	cerr << " --help                This help message" << endl;
	cerr << endl;
	exit (0);
}
