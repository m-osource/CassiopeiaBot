/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "infixd.h"
#include <iomanip>
#include <getopt.h>

off64_t KEYIDX_KEY_SIZE;
off64_t KEYIDX_STEM_SIZE;

void program_usage() {
	cerr << "Usage: program --form [arg]" << endl;
	cerr << "Read all documents in infix database." << endl;
	cerr << endl;
	cerr << " --spaces [arg]          Formatting char distance from domain and infix, default is 40" << endl;
	cerr << " --help                This help message" << endl;
	cerr << endl;
	exit (0);
}
//using namespace std;

int main( int argc, char **argv ) {

	cbot_start("infix-reader" ); // imposta le constanti

	int spaces = 40;

	while(1) {
		int option_index = 0;

		static struct option long_options[] = {
			{"help", 0, 0, 0},
			{"spaces", 1, 0, 0},
			{0, 0, 0, 0}
		};

		char c = getopt_long (argc, argv, "h",
			long_options, &option_index);

		if (c == -1)
			break;

		switch (c) {
			case 0:
				if( !strcmp( long_options[option_index].name,
							"spaces" ) ) {
					spaces = atol( optarg );
					if( spaces == 0 ) {
						program_usage();
					}
				} else if( !strcmp( long_options[option_index].name,
							"help" ) ) {
					program_usage();
				}
				break;
			case 'h':
				program_usage();
				break;
			default:
				program_usage();
		}
	}

	char *collection_keys = (char *) malloc ((strlen(CONF_INDEX_CONNECTOR_BASEPATH) + strlen(RELATIVE_WORK_DIRECTORY) + 2) * sizeof(char));
    strcpy(collection_keys, CONF_INDEX_CONNECTOR_BASEPATH);
    strcat(collection_keys, "/");
    strcat(collection_keys, RELATIVE_WORK_DIRECTORY);

    if (mkdir(collection_keys, S_IRWXU|S_IRGRP|S_IXGRP) != 0)
        perror("collection_keys ... mkdir() info");

//	cerr << "Open key indexes for reading ... " << endl;
	keyidx_t *openidx = keyidx_open( collection_keys, true );
	assert( openidx != NULL );

	char key[MAX_STR_LEN] = {'\0'};

	// cout << "Connected." << endl;
	for (keyid_t keyid = 1; keyid <= openidx->key_count; keyid++)
	{
			keyidx_key_by_keyid( openidx, keyid, key );
			value_t out = readSectors(openidx, key);
			cout << keyid << "\t" << key << setw(spaces - strlen(key)) << ' ' << out.value << endl;
			key[0] = '\0';
			free(out.value);
	}

	// cerr << "Close key indexes." << endl;
	keyidx_close( openidx);

	free (collection_keys);

	cbot_stop(0);

    return 0;
}

//
// Name: readSectors
//
// Description:
//   Legge sequenzialmente i settori del buffer che compongono la stringa 'valore'
//
// Input:
//   keyidx - the url index structure
//   lvalue - la lunghezza del valore restituito
//
// Return:
//   La struttura contente valore e lunghezza relativi alla chiave immessa
//
value_t readSectors(keyidx_t *u, char *key)
{
	value_t tvalue;

	tvalue.value = NULL;
	tvalue.value_size = 0;

	const char *endstring = ":ok:";

	char *pend = strchr(key,':'); // gli ultimi due punti se presenti vengono già rimossi in precendenza

	if (pend != NULL)
		pend[0] = '\0';

	char *pkey = key;

	keyid_t keyid = 0;

	keyidx_status_t krc = keyidx_resolve_key( u, pkey, &(keyid), true );

	if (krc == KEYIDX_EXISTENT)
	{
		off64_t next = u->values_start_sector[keyid];

		for(;;)
		{
			if (u->values_geo[next] > 0)
			{
				next = u->values_geo[next];
				tvalue.value_size += KEYIDX_EXPECTED_SECTOR_SIZE;
			}
			else
				break;
		}

		size_t chunk_size = 0;

		// Si misura la lunghezza stringa dati contenuta nell'ultimo settore
		if (tvalue.value_size > 0) // se i dati da leggere occupano più settori
		{
			for (unsigned short i = 0; i < KEYIDX_EXPECTED_SECTOR_SIZE; i++)
					if (u->values[((next * KEYIDX_EXPECTED_SECTOR_SIZE) + i)] != '\0')
						chunk_size++;

			tvalue.value_size = (tvalue.value_size + chunk_size);
		}
		else
		{
			for (unsigned short i = 0; i < KEYIDX_EXPECTED_SECTOR_SIZE; i++)
					if (u->values[((next * KEYIDX_EXPECTED_SECTOR_SIZE) + i)] != '\0')
						chunk_size++;

			tvalue.value_size = chunk_size;
		}

		tvalue.value = (char *) malloc ((tvalue.value_size + 1) * sizeof(char));

		if (tvalue.value != NULL)
		{
			tvalue.value[0] = '\0';

			next = u->values_start_sector[keyid];

			off64_t dest_offset = 0;

			while (u->values_geo[next] > 0)
			{
				memcpy(tvalue.value + dest_offset, &(u->values[(next * KEYIDX_EXPECTED_SECTOR_SIZE)]), KEYIDX_EXPECTED_SECTOR_SIZE);

				dest_offset += KEYIDX_EXPECTED_SECTOR_SIZE;

				next = u->values_geo[next];
			}

			memcpy(tvalue.value + dest_offset, &(u->values[(next * KEYIDX_EXPECTED_SECTOR_SIZE)]), chunk_size);
			tvalue.value[tvalue.value_size] = '\0';
		}
	}
	else
	{
		tvalue.value = (char *) malloc ((tvalue.value_size + 1) * sizeof(char));
		memcpy(tvalue.value + (tvalue.value_size - 4), endstring, 4);
		tvalue.value[tvalue.value_size] = '\0';
	}

	return tvalue;
}

//
// Name: keyidx_open
//
// Description:
//   Opens a url index in the given directory, or
//   create a new one if necessary.
//
// Input:
//   dirname - directory in which the url index is located
//   readonly - flag for readonly mode
//
// Return:
//   urlindex structure
//
keyidx_t *keyidx_open( const char *dirname, bool readonly ) {
	// The configuration file has to be open
	//assert( CONF_OK );

	// Open the main file
	char filename[MAX_STR_LEN];
	sprintf( filename, "%s/%s", dirname, KEYIDX_FILENAME_ALL );
	FILE *file_all = fopen64( filename, "r" );

	if( file_all == NULL ) {
		cerr << "keyidx: no index found in " << dirname << endl;
		exit (0);
	}

	// Malloc
	keyidx_t *u = (keyidx_t *)malloc(sizeof(keyidx_t));

	// The structure is big, so malloc can fail
	assert( u != NULL);

	// Read the main file
	size_t count;
	count = fread( u, sizeof(keyidx_t), 1, file_all );
	assert( count == 1 );
	fclose( file_all );

	// Set readonly mode
	u->readonly	= readonly;

	// Add the dirname
	strcpy( u->dirname, dirname );

	// Open the other files
	sprintf( filename, "%s/%s", dirname, KEYIDX_FILENAME_KEY_LIST );
	if( u->readonly ) {
		u->key_list = fopen64( filename, "r" );
	} else {
		u->key_list = fopen64( filename, "a+" );
	}

	if( u->key_list == NULL ) {
		perror( "Opening url index, key list" );
		die( "Failed to open url index" );
	}

	// Read key names
	KEYIDX_KEY_SIZE = KEYIDX_EXPECTED_KEY_SIZE * CONF_COLLECTION_MAXSITE;

	// Open key's file
	sprintf( filename, "%s/%s", dirname, KEYIDX_FILENAME_KEY );
	FILE *key_file = fopen64( filename, "r" );

	// Get key's file size
	off64_t file_key_length;
	fseeko( key_file, 0, SEEK_END );
	file_key_length = ftello( key_file );
	assert( file_key_length > 0 );
	fseeko( key_file, 0, SEEK_SET );
	if( file_key_length >= KEYIDX_KEY_SIZE ) {
		cerr << "The KEYIDX_SITE_SIZE is too small, increase MAXSITE or EXPECTED_SITENAME_SIZE" << endl;
		exit(1);
	}

	// Allocate memory
	u->key = (char *)malloc( KEYIDX_KEY_SIZE );
	assert( u->key != NULL );

	// Read
	count = fread( u->key, file_key_length, 1, key_file );
	assert( count == 1 );

	// Close
	fclose( key_file );

	// Read KEY hash table
	u->key_hash = (off64_t *)malloc(sizeof(off64_t)*CONF_COLLECTION_MAXSITE);
	assert( u->key_hash != NULL );
	sprintf( filename, "%s/%s", dirname, KEYIDX_FILENAME_KEY_HASH );

	// Open
	FILE *file_key_hash = fopen64( filename, "r" );
	assert( file_key_hash != NULL );

	// Read
	keyid_t keys_readed = fread( u->key_hash, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_key_hash );
	assert( keys_readed == CONF_COLLECTION_MAXSITE );

	// Close
	fclose( file_key_hash );

	// Read infix ranking from table
	u->key_irank = (off64_t *)malloc(sizeof(off64_t)*CONF_COLLECTION_MAXSITE);
	assert( u->key_irank != NULL );
	sprintf( filename, "%s/%s", dirname, KEYIDX_FILENAME_KEY_IRANK );

	// Open
	FILE *file_key_irank = fopen64( filename, "r" );
	assert( file_key_irank != NULL );

	// Read
	keyid_t irank_readed = fread( u->key_irank, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_key_irank );
	assert( irank_readed == CONF_COLLECTION_MAXSITE );

	// Close
	fclose( file_key_irank );

	// Read values_start_sector table
	u->values_start_sector = (off64_t *)malloc(sizeof(off64_t)*CONF_COLLECTION_MAXSITE);
	assert( u->values_start_sector != NULL );
	sprintf( filename, "%s/%s", dirname, KEYIDX_FILENAME_VALUES_OFFSET );

	// Open
	FILE *file_values_start_sector = fopen64( filename, "r" );
	assert( file_values_start_sector != NULL );

	// Read
	keyid_t values_start_sector_readed = fread( u->values_start_sector, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_values_start_sector );
	assert( values_start_sector_readed == CONF_COLLECTION_MAXSITE );

	// Close
	fclose( file_values_start_sector );

	// Read values_geo table
	u->values_geo = (off64_t *)malloc((CONF_COLLECTION_MAXSITE * KEYIDX_EXPECTED_SECTORS) * sizeof(off64_t));
	assert( u->values_geo != NULL );
	sprintf( filename, "%s/%s", dirname, KEYIDX_FILENAME_VALUES_GEO );

	// Open
	FILE *file_values_geo = fopen64( filename, "r" );
	assert( file_values_geo != NULL );

	// Read
	keyid_t values_geo_readed = fread( u->values_geo, sizeof(off64_t), (CONF_COLLECTION_MAXSITE * KEYIDX_EXPECTED_SECTORS), file_values_geo );
	assert( values_geo_readed == (CONF_COLLECTION_MAXSITE * KEYIDX_EXPECTED_SECTORS) );

	// Close
	fclose( file_values_geo );

	// Read total sectors in values table
	u->values = (char *)malloc((CONF_COLLECTION_MAXSITE * KEYIDX_EXPECTED_SECTOR_SIZE * KEYIDX_EXPECTED_SECTORS) * sizeof(char));
	assert( u->values != NULL );
	sprintf( filename, "%s/%s", dirname, KEYIDX_FILENAME_VALUES );

	// Open
	FILE *file_values = fopen64( filename, "r" );
	assert( file_values != NULL );

	// Read
	keyid_t values_readed = fread( u->values, sizeof(char), (CONF_COLLECTION_MAXSITE * KEYIDX_EXPECTED_SECTOR_SIZE * KEYIDX_EXPECTED_SECTORS), file_values );
	assert( values_readed == (CONF_COLLECTION_MAXSITE * KEYIDX_EXPECTED_SECTOR_SIZE * KEYIDX_EXPECTED_SECTORS));

	// Close
	fclose( file_values );

	/* Only for debug purpose!
	cout << "Stampa il contenuto di file della lista dei domini (" << u->key_count << '-' << u->key_next_char << ")";
	off64_t zz = 0;
	do
	cout << zz << u->key[zz];
	while (zz++ < file_key_length);
	cout << zz << endl;
	
	cout << "Stampa il contenuto di file hash";
	off64_t yy = 0;
	do
	//	if (u->key_hash[yy] > (off64_t)0)
			cout << u->key_hash[yy] << '-';
	while ( yy++ < CONF_COLLECTION_MAXSITE);
	cout << endl;
	*/

	// Return
	return u;
}

//
// Description:
//   Verify a key name and add it if necessary
//
// Input:
//   keyidx - the url index structure
//   key - the key to check
//
// Output:
//   keyid - keyid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   KEYIDX_EXISTENT - the site existed
//   KEYIDX_CREATED_KEY - the second level key was added
//   KEYIDX_NOT_FOUND - the second level key is not known and was not created
//
keyidx_status_t keyidx_resolve_key( keyidx_t *u, const char *key, keyid_t *keyid, bool readonly ) {
	assert( u != NULL );
	assert( strlen(key) > 0 );

	if (key == NULL)
		return KEYIDX_NOT_FOUND;

	size_t klen = strlen(key);
	assert( klen > 0 );

	keyid_t bucket;
	keyid_t keyid_check;

	// Check if the key exists
	keyid_check = keyidx_check_key( u, key, &(bucket) );

	if( keyid_check > 0 ) {
		if( keyid != NULL ) {
			*keyid	= keyid_check;
		}
		return KEYIDX_EXISTENT;
	}

	if( readonly == true )
		return KEYIDX_NOT_FOUND;
	else {
		// Get the next keyid
		*keyid = ++(u->key_count);
		//cout << "Result 0 o 2, Sito:   " << key << "       Recupero il primo keyid disponibile " << u->key_count << '-' << bucket << endl;
		if( u->key_count > CONF_COLLECTION_MAXSITE ) {
			die( "Maximum number of keys exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(u->key_hash)[bucket] = (u->key_next_char);
//		cout << "Inserisco " << (u->key_next_char) << " in (u->key_hash)[" << bucket << "]" << " conferma " << (u->key_hash)[bucket] << endl;

		// Save in list of keys
		fwrite( &(u->key_next_char), sizeof(off64_t), 1, u->key_list );

		// Store string
		memcpy( u->key + u->key_next_char, key, strlen(key) + 1 );

		// Store keyid
		memcpy( u->key + u->key_next_char + strlen(key) + 1, keyid, sizeof(keyid_t) );

		// Move char pointer
		u->key_next_char = u->key_next_char + strlen(key) + 1 + sizeof(keyid_t);
		if( u->key_next_char > KEYIDX_KEY_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase CONF_COLLECTION_MAXSITE or EXPECTED_KEY_SIZE" << endl;
			return(KEYIDX_ERROR);
		}
	}

	// Return
	return KEYIDX_CREATED_KEY;
}

//
// Name: urlddx_check_key
//
// Description:
//   Check if a key exists
//
// Input:
//   keyidx - the key index structure
//   key - the key name to check
//   bucket - the bucket in which this was found
//
// Return
//   a keyid if resolved
//   0 if not found
//
keyid_t keyidx_check_key( keyidx_t *u, const char *key, keyid_t *bucket ) {
	assert( u != NULL );
	assert( key != NULL );
	assert( strlen( key ) > 0 );

	// First attempt to find bucket (debug purpose)
	//keyid_t test = Url.hashing_key( key );
	//cout << "DOMAIN " << key << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = keyidx_hashing_key( key );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( u->key_hash[(*bucket)] > 0 ) {

		char *pidx = u->key + u->key_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = key;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != '\0' && *(input) != '\0' && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
			return *((keyid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % CONF_COLLECTION_MAXSITE;
	}

	return (keyid_t)0;
}

// Hashing Functions for keys
keyid_t keyidx_hashing_key( const char *text ) {
	keyid_t val;
	for( val=0; *text; text++ ) {
		val = 131 * (val == 0 ? 1 : val) + *text;
	}
	return( val % CONF_COLLECTION_MAXSITE );
}
//
// Name: keyidx_close
//
// Description:
//   Closes the url index, saving data to disk
//
// Input:
//   keyidx - the url index structure
//
void keyidx_close( keyidx_t *u ) {
	char filename[MAX_STR_LEN];
	size_t count;
	//assert( CONF_OK );

	// Check what i'm going to close
	assert( u != NULL );

	// Close and nullify all the filehandlers
	fclose( u->key_list ); u->key_list = NULL;

	// If readonly mode, bail out, do not write anything
	if( u->readonly ) {
		free(u->key);
		free(u->key_hash);
		free(u->key_irank);
		free(u->values_start_sector);
		free(u->values_geo);
		free(u->values);
		free(u);
		return;
	}

	// Save the key names 
	sprintf( filename, "%s/%s", u->dirname, KEYIDX_FILENAME_KEY );

	// Open
	FILE *key_file = fopen64( filename, "w" );
	assert( key_file != NULL );

	// Write
	count = fwrite( u->key, u->key_next_char, 1, key_file );
	assert( count == 1);

	// Close
	fclose( key_file );
	free( u->key );
	u->key = NULL;

	// Save the KEY hash tables
	sprintf( filename, "%s/%s", u->dirname, KEYIDX_FILENAME_KEY_HASH );

	// Open
	FILE *file_key_hash = fopen64( filename, "w" );
	assert( file_key_hash != NULL );

	// Write
	keyid_t keys_writed = fwrite( u->key_hash, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_key_hash );
	assert( keys_writed == CONF_COLLECTION_MAXSITE );

	// Close
	fclose( file_key_hash );
	free( u->key_hash );
	u->key_hash = NULL;

	// Save the irank tables
	sprintf( filename, "%s/%s", u->dirname, KEYIDX_FILENAME_KEY_IRANK );

	// Open
	FILE *file_key_irank = fopen64( filename, "w" );
	assert( file_key_irank != NULL );

	// Write
	keyid_t irank_writed = fwrite( u->key_irank, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_key_irank );
	assert( irank_writed == CONF_COLLECTION_MAXSITE );

	// Close
	fclose( file_key_irank );
	free( u->key_irank );
	u->key_irank = NULL;

	// Save the values_start_sector tables
	sprintf( filename, "%s/%s", u->dirname, KEYIDX_FILENAME_VALUES_OFFSET );

	// Open
	FILE *file_key_values_start_sector = fopen64( filename, "w" );
	assert( file_key_values_start_sector != NULL );

	// Write
	keyid_t values_start_sector_writed = fwrite( u->values_start_sector, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_key_values_start_sector );
	assert( values_start_sector_writed == CONF_COLLECTION_MAXSITE );

	// Close
	fclose( file_key_values_start_sector );
	free( u->values_start_sector );
	u->values_start_sector = NULL;

	// Save the values_geo tables
	sprintf( filename, "%s/%s", u->dirname, KEYIDX_FILENAME_VALUES_GEO );

	// Open
	FILE *file_key_values_geo = fopen64( filename, "w" );
	assert( file_key_values_geo != NULL );

	// Write
	keyid_t values_geo_writed = fwrite( u->values_geo, sizeof(off64_t), (CONF_COLLECTION_MAXSITE * KEYIDX_EXPECTED_SECTORS), file_key_values_geo );
	assert( values_geo_writed == (CONF_COLLECTION_MAXSITE * KEYIDX_EXPECTED_SECTORS) );

	// Close
	fclose( file_key_values_geo );
	free( u->values_geo );
	u->values_geo = NULL;

	// Save the values buffer
	sprintf( filename, "%s/%s", u->dirname, KEYIDX_FILENAME_VALUES );

	// Open
	FILE *file_values = fopen64( filename, "w" );
	assert( file_values != NULL );

	// Write
	keyid_t values_writed = fwrite( u->values, sizeof(char), (CONF_COLLECTION_MAXSITE * KEYIDX_EXPECTED_SECTOR_SIZE * KEYIDX_EXPECTED_SECTORS), file_values );
	assert( values_writed == (CONF_COLLECTION_MAXSITE * KEYIDX_EXPECTED_SECTOR_SIZE * KEYIDX_EXPECTED_SECTORS) );

	// Close
	fclose( file_values );
	free( u->values );
	u->values = NULL;

	// Write the whole structure to disk
	sprintf( filename, "%s/%s", u->dirname, KEYIDX_FILENAME_ALL );

	// Open
	FILE *file_all = fopen64( filename, "w" );
	assert( file_all != NULL );

	// Write
	count = fwrite( u, sizeof(keyidx_t), 1, file_all ); // falso positivo in valgrind
	assert( count == 1 );

	// Close
	fclose( file_all );

	// Nullify to avoid re-closing
	free(u);
}

// Name: keyidx_key_by_keyid
//
// Description:
//   Get the name of a key based on its id
//
//	TODO: This function must fail in an error condition.
//
void keyidx_key_by_keyid( keyidx_t *u, keyid_t keyid, char *keyname ) {

	// Seek
	fseeko( u->key_list, (keyid - 1) * sizeof(off64_t), SEEK_SET );

	// Read offset
	off64_t offset;
	fread( &offset, sizeof(off64_t), 1, u->key_list );

	// Copy
	assert( strlen( (u->key) + offset ) < MAX_KEY_LEN );
	strcpy( keyname, (u->key) + offset );

	// Put at end
	fseeko( u->key_list, 0, SEEK_END );
}

//
// Name: keyidx_remove
//
// Description:
//   Deletes all files for an keyidx
//
// Input:
//   dirname - the directory to clean
//

void keyidx_remove( const char *dirname ) {
	queue<string> files;

	// Push files
	files.push( KEYIDX_FILENAME_KEY_LIST );
	files.push( KEYIDX_FILENAME_KEY );
	files.push( KEYIDX_FILENAME_KEY_HASH );
	files.push( KEYIDX_FILENAME_VALUES_OFFSET );
	files.push( KEYIDX_FILENAME_VALUES );
	files.push( KEYIDX_FILENAME_ALL );

	// Delete
	while( ! files.empty() ) {

		// Create filename
		char filename[MAX_STR_LEN];
		sprintf( filename, "%s/%s", dirname, files.front().c_str() );

		// Delete file
		int rc = unlink( filename );
		if( rc != 0 && errno != ENOENT ) {
			perror( files.front().c_str() );
		}

		// Remove file from queue
		files.pop();

	}
}

// Name: cleanup
//
// Description: 
//   Closes files, indexes
//

// IMPORTANTE altrimenti non si compila
// non utilizzato dal programma ma necessario perchè sarà importato nella libreria 'utils.h' attraverso extern
void cleanup() {
}
