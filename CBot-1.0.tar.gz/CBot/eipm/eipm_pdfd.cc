/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "eipm_pdfd.h"

off64_t memory_count = 0; // N.B. Causa bug memory leak nella libreria poppler ogni tanto occorre riavviare il programma attraverso daemontools

int main(int argc, char **argv)
{
	// cbot_start("pdfd" ); // viene escluso per configurazioni selinux
	//
	instance_t instance = 0;

	// Parse options
	while(1) {
		int option_index = 0;
		static struct option long_options[] = {
			{"instance", 1, 0, 0},
			{"help", 0, 0, 0}
		};

		char c = getopt_long( argc, argv, "i:",
				long_options, &option_index );

		if( c == -1)
			break;

		switch(c) {
			case 0:
				if (!strcmp( long_options[option_index].name, "instance"))
					instance = (instance_t)atol( optarg );
				else if (!strcmp( long_options[option_index].name, "help"))
					eipm_pdfd_usage();
			break;
			case 'i':
				instance = (instance_t)atol(optarg);
			break;
			case 'h':
				eipm_pdfd_usage();
			break;
		}
	}

	// check cpu_affinity
	assert(instance == (instance_t)sched_getcpu());

	int s, s2, len;
	bool start_process = true;
	struct sockaddr_un local, remote;
	char SOCKET_PATH[MAX_STR_LEN];
	sprintf(SOCKET_PATH, SOCK_PATH, (unsigned long int)instance);

	restart_socket:

	remove(SOCKET_PATH);

	if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
		perror("socket");
		exit(1);
	}

	local.sun_family = AF_UNIX;
	strcpy(local.sun_path, SOCKET_PATH);
	remove(local.sun_path);
	len = strlen(local.sun_path) + sizeof(local.sun_family);
	if (bind(s, (struct sockaddr *)&local, len) == -1) {
		perror("bind");
		exit(1);
	}

	if (chmod(SOCKET_PATH, S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH|S_IWOTH) < 0) {
		perror("chmod: ");
		exit(1);
	}

	setSockTimeouts(s, 2.00);

	if (listen(s, 5) == -1) {
		perror("listen");
		exit(1);
	}

	char *inbuf = (char *) malloc ((CONF_MAX_FILE_SIZE + 1) * sizeof(char));

	char *outbuf = (char *) malloc ((CONF_MAX_FILE_SIZE + 1) * sizeof(char));

	if (start_process == true)
	{
		cerr << "Ready on socket " << SOCKET_PATH << '!' << endl;
		start_process = false;
	}
	else
		cerr << "Socket Restart!" << endl;

	while(true)
	{
		int done = 0;
		char headrec[33];
		bool checkin = false;
		double recv_timeout = 2.00; // (in secondi) valido solo se la ricezione avviene con cicli multipli
		unsigned short cicles = 0;

		// cout << "Waiting for a connection..." << endl;
		unsigned int t = sizeof(remote);

		// if ((s2 = accept(s, (struct sockaddr *)&remote, &t)) == -1) {
		if ((s2 = accept(s, (struct sockaddr *)&remote, &t)) == -1 || fcntl(s2, F_GETFD) == -1 || errno == EBADF) {
			cerr << "Error in accepting connection. Ready for new accept." << endl;//perror("accept");
			free (inbuf);
			inbuf = NULL;
			free (outbuf);
			outbuf = NULL;
			close(s);
			close(s2);
			goto restart_socket; // exit(1);
		}

		// cout << "Connected." << endl;

		time_t now = time(NULL);

		off64_t readed = 0;

		do {
			if (checkin == false)
			{
				off64_t ret = recv(s2, headrec, 33, 0);

				if (difftime(time(NULL), now) > recv_timeout)
				{
					cerr << "Data receiving timeout." << endl;
					done = 1;
				}

				if (ret <= 0)
				{
					cerr << "Length header not received or not valid. Ready for other request." << endl;
							done = 1;
				}
				else
				{
					headrec[ret] = '\0';

							if (send(s2, headrec, ret, MSG_NOSIGNAL) < 0)
								done = 1;
						
					checkin = true;
				}
			}

			if (checkin == true)
			{
				char read[(MAX_STR_LEN * 5)];
				size_t read_ofst = 0;

				off64_t ret = recv(s2, read, (MAX_STR_LEN * 5), 0);

				if (difftime(time(NULL), now) > recv_timeout)
				{
					cerr << "Data receiving timeout." << endl;
					done = 1;
				}

				if (ret <= 0)
				{
					if (ret < 0)
						done = 1; // se ret == -1 si mette nuovamente in listen per una nuova connessione
				}
				else
				{
					if ((readed + ret) < CONF_MAX_FILE_SIZE)
					{
						for (off64_t i = readed; (i + ret) < CONF_MAX_FILE_SIZE && read_ofst < (unsigned int)ret; i++, read_ofst++)
							inbuf[i] = read[read_ofst];

						readed += ret;
					}
					else
					{
						cerr << "Received document too long!" << endl;

						if (send(s2, "0\0\0", 2, MSG_NOSIGNAL) < 0) // forza l'invio di un null char accodato
							cerr << "Data sending timeout. Broken pipe" << endl; // perror("data sending send");

						free (inbuf);
						inbuf = NULL;
						free (outbuf);
						outbuf = NULL;
						close(s);
						close(s2);
						goto restart_socket; // exit(1);
					}
				}


				cicles++;

				if (cicles > ((CONF_MAX_FILE_SIZE / (MAX_STR_LEN * 5)) + MAX_CICLES))
				{
					cerr << "Too many cycles in received session." << endl;

					if (send(s2, "0\0\0", 2, MSG_NOSIGNAL) < 0) // forza l'invio di un null char accodato
						cerr << "Data sending timeout. Broken pipe" << endl; // perror("data sending send");

					free (inbuf);
					inbuf = NULL;
					free (outbuf);
					outbuf = NULL;
					close(s);
					close(s2);
					goto restart_socket; // exit(1);
				}

				if (!done && readed == atoi (headrec)) 
				{
					memory_count += readed;

					inbuf[readed] = '\0';

					ret = parser_process_pdf( inbuf, readed, outbuf);

					if (ret > CONF_MAX_FILE_SIZE)
					{
						ret = 0;
						outbuf[0] = '\0';
					}
					else if (ret > MAX_DOC_LEN)
					{
						ret = MAX_DOC_LEN;
						outbuf[MAX_DOC_LEN] = '\0';
					}

					char datasize[33] = {'\0'};
					snprintf(datasize, sizeof(datasize), "%d", (int)ret);

					if (send(s2, datasize, (strlen(datasize) + 1), MSG_NOSIGNAL) < 0) // forza l'invio di un null char accodato
						cerr << "Datasize sending timeout. Broken pipe" << endl; // perror("data sending send");
					else if (send(s2, outbuf, ret, MSG_NOSIGNAL) < 0)
							cerr << "Data sending timeout. Broken pipe" << endl; // perror("data sending send");

					if (memory_count > MEM_LEAK_LIMIT) // vedi bug poppler memory leak
					{
						cerr << "Administrative choice! Exit forced to protect from memory leak (limit " << MEM_LEAK_LIMIT <<
							") of poppler library." << endl;

						free (inbuf);
						inbuf = NULL;
						free (outbuf);
						outbuf = NULL;
						close(s);
						close(s2);
						exit(1);
					}

					done = 1;
				}
			}
		} while (!done);
	}

	free (inbuf);
	free (outbuf);
	close(s);
	close(s2);

	// cbot_stop(0); // viene escluso per configurazioni selinux

	return 0;
}

void setSockTimeouts(int sock, double secs) {
	struct timeval tv;
	tv.tv_sec = (int)secs;
	tv.tv_usec = (int)((long long)(secs*1000*1000) % (1000*1000));
	//bool ok = setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char *) &tv, sizeof(tv) ) == 0;
	//if( !ok ) cout << "unabled to set SO_RCVTIMEO" << endl;
	bool ok = setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, (char *) &tv, sizeof(tv) ) == 0;
	if( !ok ) cout << "unabled to set SO_SNDTIMEO" << endl;
}

//
// N.B. Utilizza la libreria poppler (-lpoppler)
//
// Descrizione: Converte i dati dal formato pdf al testo estrapolando anche i meta dati
//
// Argumenti: Il buffer contenete dati pdf e la sua relativa lunghezza
//
// Restituisce se ok la lunghezza totale del buffer, altrimenti '-1'
//
off64_t parser_process_pdf(char *inbuf, off64_t in_length, char *outbuf)
{
PDFDoc *document;
GooString *ownerPW, *userPW;
TextOutputDev *textOut;
UnicodeMap *uMap;
Object info;
static char TextEOL[] = "unix";
static double resolution = 72.0;
static char ownerPassword[33] = "\001";
static char userPassword[33] = "\001";

size_t AuthorLen = 0;
size_t SubjectLen = 0;
size_t TitleLen = 0;
size_t KeywordsLen = 0;
string Author;
string Subject;
string Title;
string Keywords;
bool havetitle = false;
const char *dotsequence = "... ";
off64_t outpos = 0;
off64_t metapos = 0;

		outbuf[0] = '\0';

	globalParams = new GlobalParams();

	globalParams->setTextEOL(TextEOL);

	globalParams->setTextPageBreaks(gFalse);

	globalParams->setErrQuiet(gTrue);

	// get mapping to output encoding
	if (!(uMap = globalParams->getTextEncoding())) {
		delete globalParams;
		return 0;
	}

	// open PDF file
	if (ownerPassword[0] != '\001') {
		ownerPW = new GooString(ownerPassword);
	} else {
		ownerPW = NULL;
	}

	if (userPassword[0] != '\001') {
		userPW = new GooString(userPassword);
	} else {
		userPW = NULL;
	}

	//create stream
	info.initNull();

	MemStream *str = new MemStream(inbuf, 0, (int)in_length, &info);

	document = new PDFDoc(str, ownerPW, userPW); // str non occorre liberarlo

	if (userPW)
		delete userPW;

	if (ownerPW)
		delete ownerPW;

	if (!document->isOk())
	{
		delete document;
		uMap->decRefCnt();
		return 0;
	}

	document->getDocInfo(&info);

	if (info.isDict())
	{
		Author = infoString(info.getDict(), "Author", uMap);
		Subject = infoString(info.getDict(), "Subject", uMap);

		Object obj; // get title

		if (info.getDict()->lookup("Title", &obj)->isString())
		{
			havetitle = true;
			Title = infoString(info.getDict(), "Title", uMap);
		}
		
		obj.free(); // end get title

		Keywords = infoString(info.getDict(), "Keywords", uMap);

		/*
		infoDate(f, info.getDict(), "CreationDate", "<meta name=\"CreationDate\" content=\"\"/>\n");
		infoDate(f, info.getDict(), "LastModifiedDate", "<meta name=\"ModDate\" content=\"\"/>\n");
		*/
	}

	info.free();

	AuthorLen = Author.size();
	SubjectLen = Subject.size();

	if (havetitle == true)
		TitleLen = Title.size();

	KeywordsLen = Keywords.size();

	if (AuthorLen > 0)
	{
		if (AuthorLen > UCHAR_MAX)
			outbuf[0] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[0] = (char)(SCHAR_MAX - UCHAR_MAX + AuthorLen + 1);
	}
	else
		outbuf[0] = (SCHAR_MIN + 1);

	if (SubjectLen > 0)
	{
		if (SubjectLen > UCHAR_MAX)
			outbuf[1] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[1] = (char)(SCHAR_MAX - UCHAR_MAX + SubjectLen + 1);
	}
	else
		outbuf[1] = (SCHAR_MIN + 1);


	if (havetitle == true && TitleLen > 0)
	{
		if (TitleLen > UCHAR_MAX)
			outbuf[2] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[2] = (char)(SCHAR_MAX - UCHAR_MAX + TitleLen + 1);
	}
	else
		outbuf[2] = (SCHAR_MIN + 1);


	if (KeywordsLen > 0)
	{
		if (KeywordsLen > UCHAR_MAX)
			outbuf[3] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[3] = (char)(SCHAR_MAX - UCHAR_MAX + KeywordsLen + 1);
	}
	else
		outbuf[3] = (SCHAR_MIN + 1);

	char *poutbuf = &(outbuf[4]);

	if (AuthorLen > UCHAR_MAX)
	{
		strncpy(poutbuf, Author.c_str(), UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (AuthorLen > 0)
	{
		strncpy(poutbuf, Author.c_str(), AuthorLen);
		poutbuf = &(poutbuf[AuthorLen]);
	}

	if (SubjectLen > UCHAR_MAX)
	{
		strncpy(poutbuf, Subject.c_str(), UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (SubjectLen > 0)
	{
		strncpy(poutbuf, Subject.c_str(), SubjectLen);
		poutbuf = &(poutbuf[SubjectLen]);
	}

	if (havetitle == true && TitleLen > UCHAR_MAX)
	{
		strncpy(poutbuf, Title.c_str(), UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (havetitle == true && TitleLen > 0)
	{
		strncpy(poutbuf, Title.c_str(), TitleLen);
		poutbuf = &(poutbuf[TitleLen]);
	}

	if (KeywordsLen > UCHAR_MAX)
	{
		strncpy(poutbuf, Keywords.c_str(), UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (KeywordsLen > 0)
	{
		strncpy(poutbuf, Keywords.c_str(), KeywordsLen);
		poutbuf = &(poutbuf[KeywordsLen]);
	}

	outpos = (4 + AuthorLen + SubjectLen + TitleLen + KeywordsLen);
	
	outbuf[outpos] = '\0';

	metapos = outpos;

	// write text file
	textOut = new TextOutputDev(NULL, gFalse, 0, gTrue, gTrue);

	if (textOut->isOk())
	{
		int oldpage = 0;
		bool notorderedtext = false;

		for (int page = 1; page <= document->getNumPages(); ++page)
		{
			//std::cout << oldpage << '-' << page << std::endl;
			//	  fprintf(f, "  <page width=\"%f\" height=\"%f\">\n",document->getPageMediaWidth(page), document->getPageMediaHeight(page));
			document->displayPage(textOut, page, resolution, resolution, 0, gTrue, gFalse, gFalse);
			TextWordList *wordlist = textOut->makeWordList();
			const int word_length = wordlist != NULL ? wordlist->getLength() : 0;
			double xMinA, yMinA, xMaxA, yMaxA, yMaxAlast = 0;

			if (word_length == 0)
			{
				delete wordlist;
				continue;
			}

			for (int i = 0; i < word_length; ++i)
			{
				TextWord *word = wordlist->get(i);
				GBool spaceAfter = word->hasSpaceAfter();
				word->getBBox(&xMinA, &yMinA, &xMaxA, &yMaxA);

				const string rstr = myXmlTokenReplace(word->getText()->getCString());

				size_t rstrl = (rstr.length() + 1);

				char *cstr = new char [(rstrl + 1)];

				if (rstrl > 2 && spaceAfter == gFalse && rstr[(rstrl - 2)] == '-')
				{
					strncpy(cstr, rstr.c_str(), (rstrl - 2));
					cstr[(rstrl - 2)] = '\0';
				}
				else
				{
					strcpy(cstr, rstr.c_str());
					strcat(cstr, " ");
				}
					
				// printf("<word xMin=\"%f\" yMin=\"%f\" xMax=\"%f\" yMax=\"%f\">%s</word>\n", xMinA, yMinA, xMaxA, yMaxA, word->getText()->getCString());
				if (yMaxA >= yMaxAlast)
				{
					if ((outpos + (strlen(cstr) + 4)) < (CONF_MAX_FILE_SIZE - 1) && page > oldpage && notorderedtext == true)
					{
						outpos += (strlen(cstr) + 4);
						strcat(outbuf, dotsequence);
						strcat(outbuf, cstr);
						notorderedtext = false;
					}
					else if ((outpos + (strlen(cstr) + 4)) < (CONF_MAX_FILE_SIZE - 1))
					{
						outpos += strlen(cstr);
						strcat(outbuf, cstr);
					}
					else
					{
						delete [] cstr;
						yMaxAlast = 0;
						oldpage = page;
						break;
					}
				}
				else if ((outpos + (strlen(cstr) + 4)) < (CONF_MAX_FILE_SIZE - 1))
				{
					outpos += (strlen(cstr) + 4);
					strcat(outbuf, dotsequence);
					strcat(outbuf, cstr);
					notorderedtext = true;
				}
				else
				{
					delete [] cstr;
					yMaxAlast = 0;
					oldpage = page;
					break;
				}

				yMaxAlast = yMaxA;
				oldpage = page;

				delete [] cstr;
				}

			delete wordlist;
		}
	}

	delete textOut;

	delete document;

	delete globalParams;

	// check for memory leaks
	//Object::memCheck(stderr); // solo uso debug
	//gMemReport(stderr);

//	doc->charset = CHARSET_UTF_8;

		outbuf[outpos] = '\0';

		if (outpos > metapos) // se si estrapola il contenuto del pdf ("corpo body") restituisce la lunghezza del buffer
				return outpos;

	return 0;
}

static string myStringReplace(const string &inString, const string &oldToken, const string &newToken)
{
	string result = inString;
	size_t foundLoc;
	int advance = 0;
	do
	{
		foundLoc = result.find(oldToken, advance);
		if (foundLoc != string::npos)
		{
		result.replace(foundLoc, oldToken.length(), newToken);
		advance = foundLoc + newToken.length();
		}
	} while (foundLoc != string::npos );

	return result;
}

static string myXmlTokenReplace(const char *inString)
{
	string myString(inString);
	myString = myStringReplace(myString, "&",  "&amp;" );
//	myString = myStringReplace(myString, "'",  "&apos;" );
//	myString = myStringReplace(myString, "\"", "&quot;" );
//	myString = myStringReplace(myString, "<",  "&lt;" );
//	myString = myStringReplace(myString, ">",  "&gt;" );
	return myString;
}

static string infoString(Dict *infoDict, const char *key, UnicodeMap *uMap)
{
	Object obj;
	GooString *s1;
	GBool isUnicode;
	Unicode u;
	char buf[9];
	int i, n;
	string myString;

	if (infoDict->lookup(key, &obj)->isString())
	{
		s1 = obj.getString();

		if ((s1->getChar(0) & 0xff) == 0xfe && (s1->getChar(1) & 0xff) == 0xff)
		{
			isUnicode = gTrue;
			i = 2;
		}
		else
		{
			isUnicode = gFalse;
			i = 0;
		}

		while (i < obj.getString()->getLength())
		{
			if (isUnicode)
			{
				u = ((s1->getChar(i) & 0xff) << 8) | (s1->getChar(i+1) & 0xff);
				i += 2;
			}
			else
			{
				u = pdfDocEncoding[s1->getChar(i) & 0xff];
				++i;
			}

			n = uMap->mapUnicode(u, buf, sizeof(buf));
			buf[n] = '\0';
			myString.append(myXmlTokenReplace(buf));
		}
	}

	obj.free();
	return myString;
}

//
// Name: eipm_pdfd_usage
//
// Description: 
//   Show an usage message
//
void eipm_pdfd_usage(void)
{
	cerr << "Usage: program [OPTION]" << endl;
	cerr << endl;
	cerr << " --instance			  the number of instance for which is in linstening" << endl;
	cerr << " --help				  this help message" << endl;
	cerr << endl;
}

//
// Name: cleanup
//
// Description: 
//   Closes files, indexes
//

// IMPORTANTE altrimenti non si compila
// non utilizzato dal programma ma necessario perchè sarà importato nella libreria 'utils.h' attraverso extern
// void cleanup() { // escluso per configurazioni selinux
// }

/*
// N.B. Utilizza la libreria podofo (-lpodofo)
//
// Descrizione: Converte i dati dal formato pdf al testo estrapolando anche i meta dati
//
// Argumenti: Il buffer contenete dati pdf e la sua relativa lunghezza
//
// Restituisce se ok la lunghezza totale del buffer, altrimenti '-1'
//
off64_t parser_process_pdf(doc_t *doc, char *inbuf, char *outbuf)
{
	using namespace PoDoFo;

	PdfError::EnableDebug( false );
	PdfError::EnableLogging( false );

	// Allo stato attuale non è in grado di leggere i pdf criptati e per evitare segmentation fault occorre abilitare l'algoritmo
	PdfEncrypt::SetEnabledEncryptionAlgorithms( PdfEncrypt::ePdfEncryptAlgorithm_RC4V1 | PdfEncrypt::ePdfEncryptAlgorithm_RC4V2 );

	PdfMemDocument *document;
	document = new PoDoFo::PdfMemDocument();

	try {
			document->Load( inbuf, (long)doc->raw_content_length );
	} catch( PdfError & e ) { // Grazie all'abilitazione degli algoritmi in caso di pdf criptati non va più in segmentation fault
		delete document;
		return 0;
	}

	//PdfError( ePdfError_InvalidPassword ) 

	off64_t outpos = 0;
	off64_t metapos = 0;

	outbuf[0] = '\0';

	size_t AuthorLen = document->GetInfo()->GetAuthor().GetStringUtf8().size();
	size_t SubjectLen = document->GetInfo()->GetSubject().GetStringUtf8().size();
	size_t TitleLen = document->GetInfo()->GetTitle().GetStringUtf8().size();
	size_t KeywordsLen = document->GetInfo()->GetKeywords().GetStringUtf8().size();

	if (AuthorLen > 0)
	{
		if (AuthorLen > UCHAR_MAX)
			outbuf[0] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[0] = (char)(SCHAR_MAX - UCHAR_MAX + AuthorLen + 1);
	}
	else
		outbuf[0] = (CHAR_MIN + 1);

	if (SubjectLen > 0)
	{
		if (SubjectLen > UCHAR_MAX)
			outbuf[1] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[1] = (char)(SCHAR_MAX - UCHAR_MAX + SubjectLen + 1);
	}
	else
		outbuf[1] = (CHAR_MIN + 1);


	if (TitleLen > 0)
	{
		if (TitleLen > UCHAR_MAX)
			outbuf[2] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[2] = (char)(SCHAR_MAX - UCHAR_MAX + TitleLen + 1);
	}
	else
		outbuf[2] = (CHAR_MIN + 1);


	if (KeywordsLen > 0)
	{
		if (KeywordsLen > UCHAR_MAX)
			outbuf[3] = (char)(SCHAR_MAX - UCHAR_MAX + 1);
		else
			outbuf[3] = (char)(SCHAR_MAX - UCHAR_MAX + KeywordsLen + 1);
	}
	else
		outbuf[3] = (CHAR_MIN + 1);


	char *poutbuf = &(outbuf[4]);

	if (AuthorLen > UCHAR_MAX)
	{
		strncpy(poutbuf, document->GetInfo()->GetAuthor().GetStringUtf8().c_str(), UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (AuthorLen > 0)
	{
		strncpy(poutbuf, document->GetInfo()->GetAuthor().GetStringUtf8().c_str(), AuthorLen);
		poutbuf = &(poutbuf[AuthorLen]);
	}

	if (SubjectLen > UCHAR_MAX)
	{
		strncpy(poutbuf, document->GetInfo()->GetSubject().GetStringUtf8().c_str(), UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (SubjectLen > 0)
	{
		strncpy(poutbuf, document->GetInfo()->GetSubject().GetStringUtf8().c_str(), SubjectLen);
		poutbuf = &(poutbuf[SubjectLen]);
	}

	if (TitleLen > UCHAR_MAX)
	{
		strncpy(poutbuf, document->GetInfo()->GetTitle().GetStringUtf8().c_str(), UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (TitleLen > 0)
	{
		strncpy(poutbuf, document->GetInfo()->GetTitle().GetStringUtf8().c_str(), TitleLen);
		poutbuf = &(poutbuf[TitleLen]);
	}

	if (KeywordsLen > UCHAR_MAX)
	{
		strncpy(poutbuf, document->GetInfo()->GetKeywords().GetStringUtf8().c_str(), UCHAR_MAX);
		poutbuf = &(poutbuf[UCHAR_MAX]);
	}
	else if (KeywordsLen > 0)
	{
		strncpy(poutbuf, document->GetInfo()->GetKeywords().GetStringUtf8().c_str(), KeywordsLen);
		poutbuf = &(poutbuf[KeywordsLen]);
	}

	outpos = (4 + AuthorLen + SubjectLen + TitleLen + KeywordsLen);
	outbuf[outpos] = '\0';

	metapos = outpos;

	int nCount = document->GetPageCount();

	for( int i=0; i<nCount; i++ ) 
	{
			PdfPage* pPage = document->GetPage( i );

		const char*	  pszToken = NULL;
		PdfVariant	   var;
		EPdfContentsType eType;

		PdfContentsTokenizer tokenizer( pPage );

		bool   bTextBlock   = false;
		PdfFont* pCurFont   = NULL;

		std::stack<PdfVariant> stack;

		while( tokenizer.ReadNext( eType, pszToken, var ) )
		{
			if( eType == ePdfContentsType_Keyword )
			{
				if( strcmp( pszToken, "BT" ) == 0 ) 
					bTextBlock   = true;	 
				else if( strcmp( pszToken, "ET" ) == 0 ) 
				{
					if( !bTextBlock ) // cerr <<  "WARNING: Found ET without BT!" << endl;
					{
						delete document;
						return 0;
					}
				}

				if( bTextBlock )
				{
					if( strcmp( pszToken, "Tf" ) == 0 ) 
					{
						stack.pop();
						PdfName fontName = stack.top().GetName();
						PdfObject* pFont = pPage->GetFromResources( PdfName("Font"), fontName );

						if( !pFont ) // PODOFO_RAISE_ERROR_INFO( ePdfError_InvalidHandle, "Cannot create font!" );
						{
							delete document;
							return 0;
						}

						pCurFont = document->GetFont( pFont );

						}
					else if( strcmp( pszToken, "Tj" ) == 0 || strcmp( pszToken, "'" ) == 0 ) 
					{
						// cerr << "WARNING: Found text but do not have a current font: " << rString.GetString() << endl;
						if( !pCurFont )
						{
							delete document;
							return 0;
						}

						// cerr << "WARNING: Found text but do not have a current encoding: " << rString.GetString() << endl;
						if( !pCurFont->GetEncoding() )
						{
							delete document;
							return 0;
						}

						// For now just write to console
						PdfString unicode = pCurFont->GetEncoding()->ConvertToUnicode( stack.top().GetString(), pCurFont );

						const char	*pszData = unicode.GetStringUtf8().c_str();

						char *Data = (char *)pszData;

						size_t pszDataLen = 0;

						while( *pszData ) {

							if (outpos < CONF_MAX_FILE_SIZE) // codice dentro la condizione che elimina spazi in eccesso
							{
								if (outpos == 0)
								{
									if (Data[pszDataLen] != ' ')
									{
										outbuf[outpos] = Data[pszDataLen];
										outpos++;
									}
								}
								else
								{
									if (! (outbuf[outpos - 1] == ' ' && Data[pszDataLen] == ' '))
									{
										outbuf[outpos] = Data[pszDataLen];
										outpos++;
									}
								}
							}

							++pszData;
							++pszDataLen;
						}

						stack.pop();
					}
					else if( strcmp( pszToken, "\"" ) == 0 )
					{
						// cerr << "WARNING: Found text but do not have a current font: " << rString.GetString() << endl;
						if( !pCurFont )
						{
							delete document;
							return 0;
						}

						// cerr << "WARNING: Found text but do not have a current encoding: " << rString.GetString() << endl;
						if( !pCurFont->GetEncoding() )
						{
							delete document;
							return 0;
						}

						// For now just write to console
						PdfString unicode = pCurFont->GetEncoding()->ConvertToUnicode( stack.top().GetString(), pCurFont );

						const char	*pszData = unicode.GetStringUtf8().c_str();

						char *Data = (char *)pszData;

						size_t pszDataLen = 0;

						while( *pszData ) {

							if (outpos < CONF_MAX_FILE_SIZE) // codice dentro la condizione che elimina spazi in eccesso
							{
								if (outpos == 0)
								{
									if (Data[pszDataLen] != ' ')
									{
										outbuf[outpos] = Data[pszDataLen];
										outpos++;
									}
								}
								else
								{
									if (! (outbuf[outpos - 1] == ' ' && Data[pszDataLen] == ' '))
									{
										outbuf[outpos] = Data[pszDataLen];
										outpos++;
									}
								}
							}

							++pszData;
							++pszDataLen;
						}

						stack.pop();
						stack.pop(); // remove char spacing from stack
						stack.pop(); // remove word spacing from stack
					}
					else if( strcmp( pszToken, "TJ" ) == 0 ) 
					{
						PdfArray array = stack.top().GetArray();
						stack.pop();
						
						for( int i=0; i<static_cast<int>(array.GetSize()); i++ ) 
						{
							if( array[i].IsString() )
							{
								// cerr << "WARNING: Found text but do not have a current font: " << rString.GetString() << endl;
								if( !pCurFont )
								{
									delete document;
									return 0;
								}

								// cerr << "WARNING: Found text but do not have a current encoding: " << rString.GetString() << endl;
								if( !pCurFont->GetEncoding() )
								{
									delete document;
									return 0;
								}

								// For now just write to console
								PdfString unicode = pCurFont->GetEncoding()->ConvertToUnicode( array[i].GetString(), pCurFont );

								const char	*pszData = unicode.GetStringUtf8().c_str();

								char *Data = (char *)pszData;

								size_t pszDataLen = 0;

								while( *pszData ) {

									if (outpos < CONF_MAX_FILE_SIZE) // codice dentro la condizione che elimina spazi in eccesso
									{
										if (outpos == 0)
										{
											if (Data[pszDataLen] != ' ')
											{
												outbuf[outpos] = Data[pszDataLen];
												outpos++;
											}
										}
										else
										{
											if (! (outbuf[outpos - 1] == ' ' && Data[pszDataLen] == ' '))
											{
												outbuf[outpos] = Data[pszDataLen];
												outpos++;
											}
										}
									}

									++pszData;
									++pszDataLen;
								}
							}
						}
					}
				}
			}
			else if ( eType == ePdfContentsType_Variant )
			{
				stack.push( var );
			}
			else
			{
				delete document;
				return 0; // Impossible; type must be keyword or variant // PODOFO_RAISE_ERROR( ePdfError_InternalLogic );
			}
		}
		}

	delete document;

	doc->charset = CHARSET_UTF_8;

	outbuf[outpos] = '\0';

	if (outpos > 4) // se si estrapola il contenuto del pdf ("corpo body") restituisce la lunghezza del buffer
		return outpos;

	return 0;
} */
