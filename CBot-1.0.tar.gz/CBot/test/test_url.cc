/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "config.h"
#include "const.h"
#include "xmlconf.h"
#include "xmlconf-main.h"
#include "utils.h"
#include "perfect_hash.h"
#include "Url.h"

// Global

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

Url *url = NULL;

void do_url_test( perfhash_t *extensions_dynamic, const char *_url, char **varnames, int nvariables ) {
	char newurl[MAX_STR_LEN];
	assert( strlen(_url) < (MAX_STR_LEN-3) );

	// Copy (we don't want do accidentally modify a constant)
	strcpy( newurl, _url );

	// We will put this character at the end to check for errors
	int origlen = strlen(newurl);
	newurl[origlen+2] = '_';

	// Now we check
	cerr << endl;
	cerr << "<<<OLD<<< " << newurl << endl;
	cerr << "is_dynamic? " << (url->is_dynamic( extensions_dynamic, newurl ) ? "yes" : "no") << endl;

	// Lower case, avoid non-alphanum characters
	char extension[MAX_STR_LEN];
	url->get_lowercase_extension( newurl, extension );
	cerr << "extension: " << extension << endl;

	for( int i=0; i<nvariables; i++ ) {
		url->remove_variable( newurl, varnames[i] );
	}

	url->remove_sessionids_heuristic( newurl );
	url->sanitize_url( newurl );

	cerr << ">>>NEW>>> " << newurl << endl;
	cerr << endl;

	// Check the character past the end
	assert( newurl[origlen+2] == '_' );
}

#define MAX_SESSIONID_VARIABLES 255

int main( int argc, char **argv )
{
try
{
	cbot_start( "testurl" );

	url = new Url (NULL, Url::RO);
	// We don't need open urlddx index, but we have the need to use only functions inside Url class.

	perfhash_t extensions_dynamic;
	extensions_dynamic.check_matches = true;
    perfhash_create( &(extensions_dynamic), CONF_SEEDER_LINK_DYNAMIC_EXTENSION );

	// Create a table with variable names for better speed
	int nvars	= 0;
	char **varnames	= tokenizeToTable( CONF_SEEDER_SESSIONIDS, &(nvars) );

	
	do_url_test( &(extensions_dynamic), "a.html", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a.cgi", varnames, nvars );
	do_url_test( &(extensions_dynamic), "x/z/b.html;jsessionid=0000000", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a.html?check=1", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a/b/c.php?storyid=204&amp;page=1&PHPSESSID=5555", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a/b/c.php;PHPSESSID=5555", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a/b/c.php;x=y?z=a.html", varnames, nvars );
	do_url_test( &(extensions_dynamic), "/a/test.html;PHPSESSID=5555?a=9999", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a.html;PHPSESSID=?a=9999", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a.html?PHPSESSID=X&amp;a=9999", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a.html?b=zzzz&PHPSESSID=X&amp;a=9999", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a.html;a=1?b=zzzz&amp;PHPSESSID=X&amp;a=9999", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a.html;a=1?b=zzzz&amp;PHPSESSID=X&", varnames, nvars );
	do_url_test( &(extensions_dynamic), "PHPSESSID=X", varnames, nvars );
	do_url_test( &(extensions_dynamic), "a.html?PHPSESSID=X&a=000&jsessionid=X", varnames, nvars );
	do_url_test( &(extensions_dynamic), "es_CL/footer_pages/site_map.jhtml;jsessionid=G2PJ3IAIZFEWHFYKJOPCFEY", varnames, nvars );
	do_url_test( &(extensions_dynamic), "tienda/?page=shop/browse&category_id=2506000&ps_session=e32379da6e396b8bc7ef216792a80d42", varnames, nvars );
	do_url_test( &(extensions_dynamic), "session_alive.php", varnames, nvars );
	do_url_test( &(extensions_dynamic), "tienda/tienda.cgi?page=shop&category_id=2506000&session-id=e32379da6e396b8bc7ef216792a80d42", varnames, nvars );
	do_url_test( &(extensions_dynamic), "editorial.asp?session-id=05d103c58feb464db7f09201c261460a", varnames, nvars );
	do_url_test( &(extensions_dynamic), "?session-id=0226b83b44e31c97cd7d12788fa7433a", varnames, nvars );
	do_url_test( &(extensions_dynamic), "forums/index.php?s=269327b02a890d20316f48eca13c4d70&amp;showtopic=5&amp;view=getnewpost", varnames, nvars );
	do_url_test( &(extensions_dynamic), "forums/catalog.php?s=123&amp;showtopic=5&amp;view=getnewpost", varnames, nvars );
	do_url_test( &(extensions_dynamic), "forum/index.php?s=29f9a30263dd7a0453bb13ff71e46590&amp;showtopic=42&amp;view=getnewpost", varnames, nvars );
	do_url_test( &(extensions_dynamic), "forum//index.php?s=29f9a30263dd7a0453bb13ff71e46590&amp;showtopic=42&amp;view=getnewpost", varnames, nvars );
	do_url_test( &(extensions_dynamic), "q_/asp/Subcategory=34/CartID=1282081312201653/Category=10/_q/subcategory.htm", varnames, nvars );
	do_url_test( &(extensions_dynamic), "forums/?sid=1c7853c4453c51fba76deeb985d4e585", varnames, nvars );
	do_url_test( &(extensions_dynamic), "links/index.php?catid=116&amp;sid=1cfa24e9e70f0abb491ca3935d623550", varnames, nvars );
	do_url_test( &(extensions_dynamic), "member.php?s=dd32a854fc1aa29111b01a28d4416386&action=getinfo&userid=2555", varnames, nvars );

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}
}

void cleanup() {

	if (url != NULL)
		delete url;
}

