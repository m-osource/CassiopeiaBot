/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _TEST_PARSER_H_INCLUDED_
#define _TEST_PARSER_H_INCLUDED_

#include <config.h>

// System libraries

#include <fstream>
#include <getopt.h>
#include <mbedtls/net.h>
#include <mbedtls/ssl.h>
#include <mbedtls/entropy.h>
#include <mbedtls/ctr_drbg.h>

// Local libraries

#include "perfect_hash.h"
#include "xmlconf.h"
#include "const.h"
#include "utils.h"
#include "cleanup.h"
#include "http_codes.h"
#include "harvestidx.h"
#include "Meta.h"
#include "pollvec.h"
#include "activepool.h"
#include "waitq.h"
#include "server.h"
#include "linkidx.h"
#include "Storage.h"
#include "page.h"
#include "show.h"
#include "cmd5.h"
#include "xmlconf.h"
#include "int_stack.h"

#include "harvester.h"

server_t *servers;

void parser_init();
void parser_close();
off64_t parser_process( starter_t *, siteid_t, char *, char *, int &, size_t & );

// Functions

void test_parser_usage();

#endif
