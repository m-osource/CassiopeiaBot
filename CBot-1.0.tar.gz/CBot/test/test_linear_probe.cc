/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

/*
 * New version of linear probing (multithread) with hash STORED AS DEFINITIVE MAXIMUM VALUE.
 * The hash in not the offset (except when size of array is equal of CONF_HASH_DOC_MAX_DEFINITIVE),
 * it give us the instance where save but offset is obtained with ((STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED)
 */

#include <config.h>

// System libraries

#include <iostream>
#include <getopt.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

//Local libraries
#include "const.h"
#include "xmlconf.h"
#include "xmlconf-main.h"
#include "Storage.h"

#define STORAGE_HASH_TEST
#define MAXSHOW 12

typedef struct {
	    docid_t max_offset;
	    docid_t max_docid;
	    doc_hash_t *doc_hash; // linear_probe: hash by docid
	    docid_t *duplicates; // linear_probe: docid by hash offset
		doc_hash_t count_hash;
	} test_storage_t;

typedef struct {
		instance_t inst;
	} thread_args_t;

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

pthread_barrier_t *barrier = NULL;
strgmutex_t *lock = NULL;
test_storage_t *distributed = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

// init internal variables
atomic<internal_long_uint_t> step_counter (0);

// Max size of duplicates hash
double TEST_STORAGE_DUPLICATE_HASH_FACTOR = 1;
doc_hash_t TEST_STORAGE_HASH_MAX = 0;

docid_t TEST_CONF_COLLECTION_MAXDOC = MAXSHOW;
instance_t instance = 0;
instance_t rinstance = 0;
time_t virttime = time(NULL);
bool vt = false;
atomic<doc_hash_t> duplicates_occupation (0);

using namespace std;

void sync_threads(pthread_barrier_t *barrier);
void setmutex(strgmutex_t **lock);
void destroymutex(void);
void lock_a_dupl(instance_t &inst);
void wrlock_hashs(void);
void rdlock_hashs(void);
void rdlock_a_hash(instance_t &inst);
void wrlock_a_hash(instance_t &binst);
void unlock_a_dupl(instance_t &inst);
void unlock_hashs(void);
void unlock_a_hash(instance_t &binst);

// Hash Linear Probing: check if content of document is found on storage as duplicate or create a new bucket
linear_probe_status_t test_linear_probe_resolve( doc_t *, char *, doc_hash_t & );

// Hash Linear Probing: delete docid from array of duplicates and relative hash from array of hash
linear_probe_status_t test_linear_probe_delete( doc_t * );

void *thread_function_probing( void * );
static void linear_probing_usage( void );

int main(int argc, char **argv)
{
try
{
	cbot_start("probing");

	int rc = 0;
	docid_t incr = 1;
	instance = CONF_COLLECTION_DISTRIBUTED;

	// IGNORE REAL TEST_CONF_COLLECTION_MAXDOC
	TEST_CONF_COLLECTION_MAXDOC = 12;

	while (true)
	{
		int option_index = 0;
		static struct option long_options[] = {
			{"size", required_argument, NULL, 's'},
			{"virttime", required_argument, NULL, 'v'},
			{"instance", required_argument, NULL, 'i'},
			{"help", no_argument, NULL, 'h'},
			{NULL, 0, NULL, 0}
		};

		char c = getopt_long(argc, argv, "s:v:i:h", long_options, &option_index);

		if(c == -1)
			break;

		switch (c)
		{
			case 0:
				if (!strcmp(long_options[option_index].name, "size"))
					TEST_CONF_COLLECTION_MAXDOC = (instance_t)(atoi(optarg));
				else if (!strcmp(long_options[option_index].name, "virttime") && strlen(optarg) == 10)
				{
					virttime = (time_t)(atoi(optarg));
					vt = true;
				}
				else if (!strcmp(long_options[option_index].name, "instance"))
					instance = (instance_t)(atoi(optarg));
				else if (!strcmp(long_options[option_index].name, "help"))
					linear_probing_usage();
				break;
			case 's':
				if (optarg != NULL)
					TEST_CONF_COLLECTION_MAXDOC = (time_t)(atoi(optarg));
				else
					cerr << "Getopt error" << endl;

				break;
			case 'v':
				if (optarg != NULL)
				{
					virttime = (time_t)(atoi(optarg));
					vt = true;
				}
				else
					cerr << "Getopt error" << endl;

				break;
			case 'i':
				if (optarg != NULL)
					instance = (instance_t)(atoi(optarg));
				else
					cerr << "Getopt error" << endl;

				break;
			case 'h':
				linear_probing_usage();

				break;
			default:
				linear_probing_usage();

				break;
		}
	}

	if (instance > CONF_COLLECTION_DISTRIBUTED)
		linear_probing_usage();

	// Prepare seed for threadsafe random generator
	srand48((long int)virttime);

	rinstance = ((lrand48() % CONF_COLLECTION_DISTRIBUTED));

	if (vt == false) cerr << "Used virttime " << virttime << endl;

	cerr << "Find duplicate hash factor ... ";

	do
	{
		TEST_STORAGE_DUPLICATE_HASH_FACTOR = ((double)(TEST_CONF_COLLECTION_MAXDOC + incr) / (double)TEST_CONF_COLLECTION_MAXDOC);
		TEST_STORAGE_HASH_MAX = (doc_hash_t)(TEST_CONF_COLLECTION_MAXDOC * TEST_STORAGE_DUPLICATE_HASH_FACTOR);
		incr++;
	}
	while (TEST_STORAGE_HASH_MAX == TEST_CONF_COLLECTION_MAXDOC);
/*
	do
	{
		TEST_STORAGE_DUPLICATE_HASH_FACTOR += (double)0.1;
		TEST_STORAGE_HASH_MAX = (doc_hash_t)(TEST_CONF_COLLECTION_MAXDOC * TEST_STORAGE_DUPLICATE_HASH_FACTOR);
	}
	while (TEST_STORAGE_HASH_MAX == TEST_CONF_COLLECTION_MAXDOC);
*/
	cerr << "done. " << endl;

	distributed = CBALLOC(test_storage_t, NEW, CONF_COLLECTION_DISTRIBUTED);
	memset(distributed, 0, (sizeof(test_storage_t) * CONF_COLLECTION_DISTRIBUTED));

	pthread_mutexattr_t attr;

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		setmutex(&lock);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", strerror(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", strerror(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		thread_args_t *args = CBALLOC(thread_args_t, MALLOC, 1);
	    args->inst = inst;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if ( pthread_create( &threads[inst], NULL, thread_function_probing, (void *) args ) )
				die("error creating thread!");
		}
		else
			thread_function_probing((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		destroymutex();

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", strerror(rc));
	}

	delete [] distributed; distributed = NULL;

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
} // catch exception in the main function
catch (CBotExitException eex)
{
	delete eex.Exception();
    
	cbot_stop(1);
}
}

// threads sync
void sync_threads(pthread_barrier_t *barrier)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc = pthread_barrier_wait(barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
        pthread_exit(NULL);
}
                                            
//
// Name: setmutex
//
// Description: Allocate memory and create mutex
//
// Input:
//
// Return:
//
void setmutex(strgmutex_t **lock)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
			*lock = CBALLOC(strgmutex_t, MALLOC, 1);
			(*lock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->rwlocka = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->rwlockb = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->rwlockc = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));

			for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			{
				(*lock)->locka[i] = PTHREAD_MUTEX_INITIALIZER;
				(*lock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
				(*lock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER;
				(*lock)->rwlocka[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*lock)->rwlockb[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*lock)->rwlockc[i] = PTHREAD_RWLOCK_INITIALIZER;
			}

	//		this->lock = *lock;
	}
}
                                            
//
// Name: destroymutex
//
// Description: Free memory and destroy mutex
//
// Input:
//
// Return:
//
void destroymutex(void)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
			// now, we ensure that all mutex are unused and destroyed
		int rc = 0;

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
		{
			if ((rc = pthread_mutex_destroy(&(lock->locka[i]))) != 0)
				die("error destroying mutex %s", strerror(rc));

			if ((rc = pthread_mutex_destroy(&(lock->lockb[i]))) != 0)
				die("error destroying mutex %s", strerror(rc));

			if ((rc = pthread_mutex_destroy(&(lock->lockc[i]))) != 0)
				die("error destroying mutex %s", strerror(rc));

			if ((rc = pthread_rwlock_destroy(&(lock->rwlocka[i]))) != 0)
				die("error destroying mutex %s", strerror(rc));

			if ((rc = pthread_rwlock_destroy(&(lock->rwlockb[i]))) != 0)
				die("error destroying mutex %s", strerror(rc));

			if ((rc = pthread_rwlock_destroy(&(lock->rwlockc[i]))) != 0)
				die("error destroying mutex %s", strerror(rc));
		}

		free(lock->locka); lock->locka = NULL;
		free(lock->lockb); lock->lockb = NULL;
		free(lock->lockc); lock->lockc = NULL;
		free(lock->rwlocka); lock->rwlocka = NULL;
		free(lock->rwlockb); lock->rwlockb = NULL;
		free(lock->rwlockc); lock->rwlockc = NULL;
		free(lock);
	}
}

// Functions to lock/unlock mutexes

//
// Description: lock mutex
//
// Input: The instance of duplicates
//
// Return:
//
void lock_a_dupl(instance_t &inst)
{
	int rc = 0;

	if (lock != NULL && lock->locka != NULL)
		if ((rc = pthread_mutex_lock(&(lock->locka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
//
// Description: lock mutex for read only operations
//
// Input: The instance of hashes
//
// Return:
//
void wrlock_hashs(void)
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_wrlock(&(lock->rwlocka[CONF_COLLECTION_DISTRIBUTED]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
//
// Description: lock mutex for read only operations
//
// Input: The instance of hashes
//
// Return:
//
void rdlock_hashs(void)
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_rdlock(&(lock->rwlocka[CONF_COLLECTION_DISTRIBUTED]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
//
// Description: lock mutex for read only operations
//
// Input: The instance of hashes
//
// Return:
//
void rdlock_a_hash(instance_t &inst)
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_rdlock(&(lock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
//
// Description: lock mutex for read write operations
//
// Input: The instance of hashes
//
// Return:
//
void wrlock_a_hash(instance_t &binst)
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_wrlock(&(lock->rwlocka[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void unlock_a_dupl(instance_t &inst)
{
	int rc = 0;

	if (lock != NULL && lock->locka != NULL)
		if ((rc = pthread_mutex_unlock(&(lock->locka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void unlock_hashs(void)
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_unlock(&(lock->rwlocka[CONF_COLLECTION_DISTRIBUTED]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void unlock_a_hash(instance_t &binst)
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_unlock(&(lock->rwlocka[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
//
// Description: call 'CBotSort' class
//
// Name: thread_function_probing
//
// Description:
//   Prints an usage message, then stops
//

void *thread_function_probing(void *args)
{
try
{
	thread_args_t *arguments = (thread_args_t *)args;
	instance_t inst = arguments->inst;

	#define MAXHASH (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED)

	// Setting to 0 max_docid for documents. Will be increased in this function
	distributed[inst].max_docid = 0;

	// array of hashs to needed for reduce readins of content from disk
	distributed[inst].doc_hash = CBALLOC(doc_hash_t, MALLOC, TEST_CONF_COLLECTION_MAXDOC);

	for (docid_t d = 0; d < TEST_CONF_COLLECTION_MAXDOC; d++) distributed[inst].doc_hash[d] = CONF_HASH_DOC_MAX_DEFINITIVE;

	// array of duplicates
	distributed[inst].duplicates = CBALLOC(docid_t, CALLOC, TEST_STORAGE_HASH_MAX);

	if (TEST_CONF_COLLECTION_MAXDOC > MAXSHOW) ccerr << "Assigning random hashs: " << endl;

	sync_threads(barrier);

	// if we have inserted a virtualtime, we want ricreate same storage to be examined. Using singlecore.
	if (vt == true)
	{
		if ((inst % CONF_COLLECTION_DISTRIBUTED) == rinstance)
		{
			for (docid_t docid = 1; docid <= (TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED); docid++)
			{
				doc_hash_t hash = ((lrand48() % CONF_HASH_DOC_MAX_DEFINITIVE));

				_retry:

				// Find hash instance (can change inside of function)
				instance_t hinst = (hash % CONF_COLLECTION_DISTRIBUTED);
				doc_hash_t pos = ((hash % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED)) / CONF_COLLECTION_DISTRIBUTED);

				// Find instance
				instance_t doc_inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);
				docid_t doc_offset = ((docid - 1) / CONF_COLLECTION_DISTRIBUTED);

				distributed[doc_inst].doc_hash[doc_offset] = hash;

				// lock duplicates
				lock_a_dupl(hinst);

				docid_t duplicate_docid = distributed[hinst].duplicates[pos];

				// Linear Probe
				while (duplicate_docid != (docid_t)0 && duplicate_docid != docid && distributed[hinst].count_hash < TEST_STORAGE_HASH_MAX)
				{
					pos = ((pos + 1) % TEST_STORAGE_HASH_MAX);
					duplicate_docid = distributed[hinst].duplicates[pos];
				}

				// instance storage bucket is full
				// try to put it inside other instance
				if (distributed[hinst].count_hash == (TEST_STORAGE_HASH_MAX - 1))
				{
					// unlock duplicates
					unlock_a_dupl(hinst);

					hash = ((hash + 1) % CONF_HASH_DOC_MAX_DEFINITIVE);
					goto _retry;
				}

				// mcout << "instance " << (unsigned long int)inst << " hash instance " << (unsigned long int)hinst << " docid " << docid << " hash_offset " << pos << " hash " << hash << mendl;

				duplicates_occupation++;
				distributed[hinst].count_hash++;
				distributed[hinst].duplicates[pos] = docid;

				if (TEST_CONF_COLLECTION_MAXDOC > MAXSHOW)
				{
					if (docid == (TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED))
					{
	   					printf("\rDocid is: %s%lu%s %c", GRE, (unsigned long int)docid, NOR, '\b');
						fflush(stdout);
					}
					else if (docid > ((TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED) / 2))
					{
		   				printf("\rDocid is: %s%lu%s %c", BRO, (unsigned long int)docid, NOR, '\b');
						fflush(stdout);
					}
					else if (docid <= ((TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED) / 2))
					{
		   				printf("\rDocid is: %s%lu%s %c", RED, (unsigned long int)docid, NOR, '\b');
						fflush(stdout);
					}
				}

				// unlock duplicates
				unlock_a_dupl(hinst);
			}
		}
	}
	else
	{
		for (docid_t docid = (inst + 1); docid <= (TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED); docid += CONF_COLLECTION_DISTRIBUTED)
		{
			doc_hash_t hash = ((lrand48() % MAXHASH));

			retry:

			// Find hash instance (can change inside of function)
			instance_t hinst = (hash % CONF_COLLECTION_DISTRIBUTED);
			doc_hash_t pos = ((hash % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED)) / CONF_COLLECTION_DISTRIBUTED);

			// Find instance
			instance_t doc_inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);
			docid_t doc_offset = ((docid - 1) / CONF_COLLECTION_DISTRIBUTED);

			assert(doc_inst == inst);

			distributed[doc_inst].doc_hash[doc_offset] = hash;

			// lock duplicates
			lock_a_dupl(hinst);

			docid_t duplicate_docid = distributed[hinst].duplicates[pos];

			// Linear Probe
			while (duplicate_docid != (docid_t)0 && duplicate_docid != docid && distributed[hinst].count_hash < TEST_STORAGE_HASH_MAX)
			{
				pos = ((pos + 1) % TEST_STORAGE_HASH_MAX);
				duplicate_docid = distributed[hinst].duplicates[pos];
			}

			// instance storage bucket is full
			// try to put it inside other instance
			if (distributed[hinst].count_hash == (TEST_STORAGE_HASH_MAX - 1))
			{
				// unlock duplicates
				unlock_a_dupl(hinst);

				hash = ((hash + 1) % CONF_HASH_DOC_MAX_DEFINITIVE);
				goto retry;
			}

			// mcout << "instance " << (unsigned long int)inst << " hash instance " << (unsigned long int)hinst << " docid " << docid << " hash_offset " << pos << " hash " << hash << mendl;


			duplicates_occupation++;
			distributed[hinst].count_hash++;
			distributed[hinst].duplicates[pos] = docid;

			if (TEST_CONF_COLLECTION_MAXDOC > MAXSHOW && inst == rinstance)
			{
				if (docid == ((TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED) - (CONF_COLLECTION_DISTRIBUTED - rinstance - 1)))
				{
	   				printf("\rDocid is: %s%lu%s %c", GRE, (unsigned long int)(docid + (CONF_COLLECTION_DISTRIBUTED - rinstance - 1)), NOR, '\b');
					fflush(stdout);
				}
				else if (docid > ((TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED) / 2))
				{
	   				printf("\rDocid is: %s%lu%s %c", BRO, (unsigned long int)(docid + (CONF_COLLECTION_DISTRIBUTED - rinstance - 1)), NOR, '\b');
					fflush(stdout);
				}
				else if (docid <= ((TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED) / 2))
				{
	   				printf("\rDocid is: %s%lu%s %c", RED, (unsigned long int)(docid + (CONF_COLLECTION_DISTRIBUTED - rinstance - 1)), NOR, '\b');
					fflush(stdout);
				}
			}

			// unlock duplicates
			unlock_a_dupl(hinst);
		}
	}

	sync_threads(barrier);

	if (TEST_CONF_COLLECTION_MAXDOC > MAXSHOW) ccerr << endl << NOR << "done" << endl;

	sync_threads(barrier);

	if (TEST_CONF_COLLECTION_MAXDOC <= MAXSHOW)
	{
		while (true)
		{
			if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
			{
				if (inst == 0) cout << RED << "rel pos      ";

				for (doc_hash_t offset = 0; offset < TEST_STORAGE_HASH_MAX; offset++)
				{
					if (offset < 10) cout << ' ' << offset << ' ';
					else cout << offset << ' ';
				}

				if (inst == (CONF_COLLECTION_DISTRIBUTED - 1)) cout << NOR << endl;

				step_counter++;

				break;
			}
		}

		sync_threads(barrier);

		while (true)
		{
			if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
			{
				if (inst == 0) cout << RED << "positions    ";

				for (doc_hash_t offset = inst; offset < MAXHASH; offset += CONF_COLLECTION_DISTRIBUTED)
				{
					if (offset < 10) cout << ' ' << offset << ' ';
					else cout << offset << ' ';
				}

				if (inst == (CONF_COLLECTION_DISTRIBUTED - 1)) cout << NOR << endl;

				step_counter++;

				break;
			}
		}

		sync_threads(barrier);

		while (true)
		{
			if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
			{
				if (inst == 0) cout << RED << "docid        ";

				for (doc_hash_t pos = 0; pos < TEST_STORAGE_HASH_MAX; pos++)
				{
					docid_t	duplicate_docid = distributed[inst].duplicates[pos];

					if (duplicate_docid == 0) cout << GRE;

					if (duplicate_docid > 0)
					{
						if (duplicate_docid < 10) cout << ' ' << BLU << duplicate_docid << NOR << ' ';
						else cout << BLU << duplicate_docid << NOR << ' ';
					}
					else cout << ' ' << duplicate_docid << ' ';

					if (duplicate_docid == 0)
					{
						cout << NOR;

						continue;
					}
				}

				if (inst == (CONF_COLLECTION_DISTRIBUTED - 1)) cout << NOR << endl;

				step_counter++;

				break;
			}
		}

		sync_threads(barrier);

		while (true)
		{
			if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
			{
				if (inst == 0) cout << RED << "buckets      ";

				for (doc_hash_t pos = 0; pos < TEST_STORAGE_HASH_MAX; pos++)
				{
					doc_hash_t hash = 0;

					docid_t	duplicate_docid = distributed[inst].duplicates[pos];

					if (duplicate_docid == 0)
						cout << GRE;

					if (duplicate_docid > 0)
					{
						// Find instance
						instance_t doc_inst = ((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED);
						docid_t doc_offset = ((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED);

						hash = (distributed[doc_inst].doc_hash[doc_offset] % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));

						if (hash < 10)
							cout << ' ' << NOR << hash << ' ';
						else
							cout << NOR << hash << ' ';
					}
					else cout << ' ' << hash << ' ';

					if (duplicate_docid == 0)
					{
						cout << NOR;

						continue;
					}
				}

				if (inst == (CONF_COLLECTION_DISTRIBUTED - 1)) cout << NOR << endl;

				step_counter++;

				break;
			}
		}

		sync_threads(barrier);
	}
	
	if (TEST_CONF_COLLECTION_MAXDOC > MAXSHOW) ccerr << "Checking integrity:" << endl;

	sync_threads(barrier);

	doc_t doc;

	// Ensure linear probing was created with success
	// for (doc.docid = 1; doc.docid <= (TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED); doc.docid++)
	for (doc.docid = (inst + 1); doc.docid <= TEST_CONF_COLLECTION_MAXDOC; doc.docid += CONF_COLLECTION_DISTRIBUTED)
	{
		// Find instance and offset of docid
		instance_t doc_inst = ((doc.docid - 1) % CONF_COLLECTION_DISTRIBUTED);
		docid_t doc_offset = ((doc.docid - 1) / CONF_COLLECTION_DISTRIBUTED);

		// Find hash value already assigned at document
		doc_hash_t hash = distributed[doc_inst].doc_hash[doc_offset];

		linear_probe_status_t probe = test_linear_probe_resolve(&doc, NULL, hash);

		if (probe == PROBE_ERROR)
		{
			mcout << RED << "Error: docid " << doc.docid << NOR << " (PROBE_ERROR)" << mendl;
			thread_alarm = THREADS_STOP_ONERR;
			break;
		}
		else if (probe == PROBE_CREATED)
		{
			mcout << RED << "Error: docid " << doc.docid << NOR << " (PROBE_CREATED)" << mendl;
			thread_alarm = THREADS_STOP_ONERR;
			break;
		}

		if (thread_alarm != THREADS_OK) break;

		if (TEST_CONF_COLLECTION_MAXDOC > MAXSHOW && inst == rinstance)
		{
			if (doc.docid == (TEST_CONF_COLLECTION_MAXDOC - (CONF_COLLECTION_DISTRIBUTED - rinstance - 1)))
			{
   				printf("\rDocid is: %s%lu%s %c", GRE, (unsigned long int)((doc.docid + (CONF_COLLECTION_DISTRIBUTED - rinstance - 1)) * CONF_COLLECTION_DISTRIBUTED), NOR, '\b');
				fflush(stdout);
			}
			else if (doc.docid > (TEST_CONF_COLLECTION_MAXDOC / 2))
			{
   				printf("\rDocid is: %s%lu%s %c", BRO, (unsigned long int)((doc.docid + (CONF_COLLECTION_DISTRIBUTED - rinstance - 1)) * CONF_COLLECTION_DISTRIBUTED), NOR, '\b');
				fflush(stdout);
			}
			else if (doc.docid <= (TEST_CONF_COLLECTION_MAXDOC / 2))
			{
   				printf("\rDocid is: %s%lu%s %c", RED, (unsigned long int)((doc.docid + (CONF_COLLECTION_DISTRIBUTED - rinstance - 1)) * CONF_COLLECTION_DISTRIBUTED), NOR, '\b');
				fflush(stdout);
			}
		}
	}

	sync_threads(barrier);

	if (thread_alarm == THREADS_STOP_ONERR)
	{
		free(distributed[inst].doc_hash); distributed[inst].doc_hash = NULL;
		free(distributed[inst].duplicates); distributed[inst].duplicates = NULL;

		free(args);

		return NULL;
	}

	if (TEST_CONF_COLLECTION_MAXDOC > MAXSHOW) ccerr << endl << "done." << endl << "Linear unprobing:" << endl;

	sync_threads(barrier);

	if (instance < CONF_COLLECTION_DISTRIBUTED && (inst % CONF_COLLECTION_DISTRIBUTED) == instance)
	{
		for (doc.docid = (inst + 1); doc.docid <= (TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED); doc.docid += CONF_COLLECTION_DISTRIBUTED)
		{
			linear_probe_status_t probe = test_linear_probe_delete(&doc);

			if (probe == PROBE_ERROR)
			{
				mcout << RED << "Error: docid " << doc.docid << NOR << mendl;
				thread_alarm = THREADS_STOP_ONERR;
				break;
			}
			else
			{
				// Find instance and offset of docid
				instance_t doc_inst = ((doc.docid - 1) % CONF_COLLECTION_DISTRIBUTED);
				docid_t doc_offset = ((doc.docid - 1) / CONF_COLLECTION_DISTRIBUTED);

				// write lock hashs
				wrlock_a_hash(doc_inst);

				distributed[doc_inst].doc_hash[doc_offset] = CONF_HASH_DOC_MAX_DEFINITIVE;

				// unlock hashs
				unlock_a_hash(doc_inst);
			}

			if (thread_alarm != THREADS_OK) break;
		}
	}
	else
	{
		for (doc.docid = (inst + 1); doc.docid <= (TEST_CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED); doc.docid += CONF_COLLECTION_DISTRIBUTED)
		{
			linear_probe_status_t probe = test_linear_probe_delete(&doc);

			if (probe == PROBE_ERROR)
			{
				mcout << RED << "Error: docid " << doc.docid << NOR << " (PROBE_ERROR)" << mendl;
				thread_alarm = THREADS_STOP_ONERR;
				break;
			}
			else if (probe == PROBE_NOT_FOUND)
			{
				mcout << RED << "Error: docid " << doc.docid << NOR << " (PROBE_NOT_FOUND)" << mendl;
				thread_alarm = THREADS_STOP_ONERR;
				break;
			}
			else
			{
				// Find instance and offset of docid
				instance_t doc_inst = ((doc.docid - 1) % CONF_COLLECTION_DISTRIBUTED);
				docid_t doc_offset = ((doc.docid - 1) / CONF_COLLECTION_DISTRIBUTED);

				// write lock hashs
				wrlock_a_hash(doc_inst);

				distributed[doc_inst].doc_hash[doc_offset] = CONF_HASH_DOC_MAX_DEFINITIVE;

				if (TEST_CONF_COLLECTION_MAXDOC > MAXSHOW)
				{
					if (duplicates_occupation == 0)
					{
   						printf("\rHash Occupation is: %s%lu%s/%lu %c", GRE, (unsigned long int)duplicates_occupation, NOR, (unsigned long int)MAXHASH, '\b');
						fflush(stdout);
					}
					else if (doc.docid > (TEST_CONF_COLLECTION_MAXDOC / 2))
					{
   						printf("\rHash Occupation is: %s%lu%s/%lu %c", BRO, (unsigned long int)duplicates_occupation, NOR, (unsigned long int)MAXHASH, '\b');
						fflush(stdout);
					}
					else if (doc.docid <= (TEST_CONF_COLLECTION_MAXDOC / 2))
					{
   						printf("\rHash Occupation is: %s%lu%s/%lu %c", RED, (unsigned long int)duplicates_occupation, NOR, (unsigned long int)MAXHASH, '\b');
						fflush(stdout);
					}
				}

				// unlock hashs
				unlock_a_hash(doc_inst);
			}

			if (thread_alarm != THREADS_OK) break;
		}
	}

	sync_threads(barrier);

	if (thread_alarm == THREADS_STOP_ONERR)
	{
		free(distributed[inst].doc_hash); distributed[inst].doc_hash = NULL;
		free(distributed[inst].duplicates); distributed[inst].duplicates = NULL;

		free(args);

		return NULL;
	}

	sync_threads(barrier);

	// At the END check if all hashs are set to default values
	for (docid_t i = 0; i < TEST_CONF_COLLECTION_MAXDOC; i++)
	{
		if (distributed[inst].doc_hash[i] != CONF_HASH_DOC_MAX_DEFINITIVE)
		{
			mcout << RED << "Error: Zombie Hash " << distributed[inst].doc_hash[i] << NOR << " for document " << i << mendl;
			thread_alarm = THREADS_STOP_ONERR;
			break;
		}
	}

	sync_threads(barrier);

	if (thread_alarm == THREADS_STOP_ONERR)
	{
		free(distributed[inst].doc_hash); distributed[inst].doc_hash = NULL;
		free(distributed[inst].duplicates); distributed[inst].duplicates = NULL;

		free(args);

		return NULL;
	}

	sync_threads(barrier);

	// At the END check if all docid are set to unused value
	for (docid_t i = 0; i < TEST_STORAGE_HASH_MAX; i++)
	{
		if (distributed[inst].duplicates[i] != 0)
		{
			mcout << RED << "Error: Zombie Docid " << distributed[inst].doc_hash[i] << NOR << " for offset " << i << mendl;
			thread_alarm = THREADS_STOP_ONERR;
			break;
		}
	}

	sync_threads(barrier);

	if (thread_alarm == THREADS_OK) ccerr << endl << GRE << "All works done!" << NOR << endl;

	free(distributed[inst].doc_hash); distributed[inst].doc_hash = NULL;
	free(distributed[inst].duplicates); distributed[inst].duplicates = NULL;

	free(args);

	// need for handle exceptions - inside Storage this step is inside the caller
	sync_threads(barrier);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(barrier);
}
}

//
// Name: test_linear_probe_resolve
//
// Description:
//   Exec a linear probing on same instance's storage to find if document have a duplicate
//   Hash file not locked because once lock duplicate instance, relative hashs cannot interference with other hash from other instances.
//   WARNING: This function MUST BE a clone of Storage::linear_probe_resolve
//
// Input:
//   doc - document where docid is found
//   buf - content of the document
//
// Output:
//
// Return:
//   status

linear_probe_status_t test_linear_probe_resolve( doc_t *doc, char *buf, doc_hash_t &hash )
{
	assert (doc->docid > 0);
#ifdef STORAGE_HASH_TEST
	assert(buf == NULL);
#else
	assert(buf != NULL);
#endif

//#ifdef STORAGE_HASH_TEST
	assert(hash < CONF_HASH_DOC_MAX_DEFINITIVE);
//#endif

	// Find hash instance (must unchange inside of function)
	instance_t hinst = (hash % CONF_COLLECTION_DISTRIBUTED);

#ifndef STORAGE_HASH_TEST
	doc_hash_t pos = ((hash % (STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED)) / CONF_COLLECTION_DISTRIBUTED);
#else
	doc_hash_t pos = ((hash % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED)) / CONF_COLLECTION_DISTRIBUTED);
#endif

	// lock duplicates
	lock_a_dupl(hinst);

	docid_t duplicate_docid = 0;

	duplicate_docid = distributed[hinst].duplicates[pos];

#ifdef STORAGE_HASH_TEST
	if (duplicate_docid != (docid_t)0 && duplicate_docid == doc->docid)
	{
			// unlock duplicates
			unlock_a_dupl(hinst);

			return PROBE_EXISTENT;
	}
#endif

	// read only lock hashs without instance because during function doc_hash can be readed on different instances
//	rdlock_hashs();

	// Linear Probing
	while (duplicate_docid != (docid_t)0 && duplicate_docid != doc->docid)
	{
#ifndef STORAGE_HASH_TEST
		if (distributed[((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED)].doc_hash[((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED)] == hash)
		{
			// Check if it's duplicate by content
			bool is_duplicate = true;

			errno = 0; // errno is thread-local

			// Read potential duplicate
			string content_path = find_path(duplicate_docid);

			FILE *duplicate_file = fopen(content_path.c_str(), "rb");

			if (duplicate_file == NULL)
			{
				mcerr << RED << "Storage test_linear_probe_resolve: failed to read document " << duplicate_docid << " while checking duplicates of " << doc->docid << NOR << mendl;
				is_duplicate = false;
				break;
			}
			else
			{
				// Ask for memory to load temporary files and compare
				char *tmpbuf = CBALLOC(char, MALLOC, MAX_DOC_LEN);

				// Compare doc->content_lengths and after this compare content byte to byte
				size_t readed = fread(tmpbuf, 1, MAX_DOC_LEN, duplicate_file);

				if (errno != 0)
				{
					mcerr << RED << "Storage test_linear_probe_resolve: couldn't read content file "<< cberr() << " on "  << content_path.c_str() << NOR << mendl;
					is_duplicate = false;
				}

				if (readed == (size_t)doc->content_length)
				{
					if (memcmp(tmpbuf, buf, doc->content_length) != 0)
						is_duplicate = false;
				}
				else
					is_duplicate = false;

				int rc = fclose(duplicate_file);

				if (errno != 0)
				{
					mcerr << "Storage test_linear_probe_resolve: couldn't close file "<< cberr() << " on "  << content_path.c_str() << mendl;
					is_duplicate = false;
				}

				assert( rc == 0 );
				free(tmpbuf);

				if (is_duplicate)
				{
					// document must be saved as duplicate_of ...
					doc->duplicate_of = duplicate_docid;

					// unlock ro mutex for hash
					// unlock_hashs();

					// unlock duplicates
					unlock_a_dupl(hinst);

					return PROBE_EXISTENT;
				}
			}

			// unlock ro mutex for hash
			// unlock_hashs();

			// unlock duplicates
			unlock_a_dupl(hinst);

			return PROBE_EXISTENT;
		}
#else 
		if (distributed[((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED)].doc_hash[((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED)] == hash)
		{
			// unlock ro mutex for hash
			// unlock_hashs();

			// unlock duplicates
			unlock_a_dupl(hinst);

			return PROBE_EXISTENT;
		}
#endif

		// Go ahead until condition
#ifdef STORAGE_HASH_TEST
		pos = ((pos + 1) % TEST_STORAGE_HASH_MAX);
#else
		pos = ((pos + 1) % STORAGE_HASH_MAX);
#endif

		duplicate_docid = distributed[hinst].duplicates[pos];
	}

#ifdef STORAGE_HASH_TEST
	if (duplicate_docid != (docid_t)0 && duplicate_docid == doc->docid)
	{
		// unlock ro mutex for hash
		// unlock_hashs();

		// unlock duplicates
		unlock_a_dupl(hinst);

		return PROBE_EXISTENT;
	}
#endif

	// unlock ro mutex for hash
	// unlock_hashs();

	distributed[hinst].duplicates[pos] = doc->docid;
	distributed[hinst].count_hash++;

	// Find instance and offset of docid
	instance_t doc_inst = ((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t doc_offset = ((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED);

	// write lock hashs
//	wrlock_hashs();

	// Save hash value (ready for query
	distributed[doc_inst].doc_hash[doc_offset] = hash;

	// unlock hashs
//	unlock_hashs();

	// unlock duplicates
	unlock_a_dupl(hinst);

	return PROBE_CREATED;
}

//
// Name: test_linear_probe_delete
//
// Description:
//   Exec a linear probing on same instance's storage for shift offset at left and fill empty position
//   Hash file not locked because once lock duplicate instance, relative hashs cannot interference with other hash from other instances.
//   WARNING: This function MUST BE a clone of Storage::linear_probe_delete
//
// Input:
//   doc - document where docid is found
//
// Output:
//
// Return:
//   status

linear_probe_status_t test_linear_probe_delete(doc_t *doc)
{
	assert (doc->docid > 0);

	// Find instance and offset of docid
	instance_t doc_inst = ((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t doc_offset = ((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED);

	// Find real hash
	doc_hash_t hash = distributed[doc_inst].doc_hash[doc_offset];

	// Return because document not found inside storage
	if (hash == CONF_HASH_DOC_MAX_DEFINITIVE) return PROBE_NOT_FOUND;

	// Find hash instance (must unchange inside of function)
	instance_t hinst = (hash % CONF_COLLECTION_DISTRIBUTED);

#ifndef STORAGE_HASH_TEST
	hash %= (STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED);
#else
	hash %= (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED);
#endif

	// Find hash position
	doc_hash_t chain_start = (hash / CONF_COLLECTION_DISTRIBUTED);

#ifdef STORAGE_HASH_TEST
	instance_t remove_instance = hinst;
	doc_hash_t remove_offset = chain_start;
#endif

	bool probe_ok = false;

	// lock duplicates
	lock_a_dupl(hinst);

	assert(distributed[hinst].duplicates[chain_start] > 0); // TODO solo uso debug

	// Return error because document must be inside storage
	if (distributed[hinst].duplicates[chain_start] == 0)
	{
		// unlock duplicates
		unlock_a_dupl(hinst);

		return PROBE_ERROR;
	}

	//find position where docid is found with Linear Probe and set chain_start
	while (distributed[hinst].duplicates[chain_start] > 0)
	{
		if (distributed[hinst].duplicates[chain_start] == doc->docid)
		{
			probe_ok = true;
			break;
		}

		// Linear Probing
#ifdef STORAGE_HASH_TEST
		chain_start = ((chain_start + 1) % TEST_STORAGE_HASH_MAX);
#else
		chain_start = ((chain_start + 1) % STORAGE_HASH_MAX);
#endif
	}

	if (probe_ok == false)
	{
		// unlock duplicates
		unlock_a_dupl(hinst);

#ifdef STORAGE_HASH_TEST
		mcout << NOR << "buckets err  ";

		for (instance_t hinst = 0; hinst < CONF_COLLECTION_DISTRIBUTED; hinst++)
		{
			for (doc_hash_t pos = 0; pos < TEST_STORAGE_HASH_MAX; pos++)
			{
				doc_hash_t hash = 0;

				docid_t	duplicate_docid = distributed[hinst].duplicates[pos];

				if (duplicate_docid == 0) cout << GRE;

				if (duplicate_docid > 0)
				{
					// Find instance
					instance_t doc_inst = ((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED);
					docid_t doc_offset = ((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED);

#ifndef STORAGE_HASH_TEST
					hash = (distributed[doc_inst].doc_hash[doc_offset] % (STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));
#else
					hash = (distributed[doc_inst].doc_hash[doc_offset] % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));
#endif

					if (hash < 10) cout << ' ' << hash << ' ';
					else cout << hash << ' ';
				}
				else cout << ' ' << hash << ' ';

				if (duplicate_docid == 0)
				{
					cout << NOR;

					continue;
				}
			}
		}

		cout << NOR << mendl;
#endif
		return PROBE_ERROR;
	}

	// now chain_start indicates where docid is found
	doc_hash_t chain_end = chain_start; // become relative end of chain
	doc_hash_t empty_offset = chain_start; // where offset become empty
	doc_hash_t hash_offset = chain_start; 

	while (distributed[hinst].duplicates[chain_end] > 0)
	{
#ifdef STORAGE_HASH_TEST
		chain_end = ((chain_end + 1) % TEST_STORAGE_HASH_MAX);
#else
		chain_end = ((chain_end + 1) % STORAGE_HASH_MAX);
#endif
	}

	// read only lock hashs without instance because during function doc_hash can be readed on different instances
	// rdlock_hashs();

	// Linear UnProbe algo by MS
	// Shift offset to left
	while (distributed[hinst].duplicates[hash_offset] > 0)
	{
		// Get next_docid only to find the value of the hash
		docid_t next_docid = distributed[hinst].duplicates[hash_offset];

		doc_hash_t hash_value = distributed[((next_docid - 1) % CONF_COLLECTION_DISTRIBUTED)].doc_hash[((next_docid - 1) / CONF_COLLECTION_DISTRIBUTED)];

#ifndef STORAGE_HASH_TEST
		hash_value %= (STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED);
#else
		hash_value %= (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED);
#endif

		doc_hash_t hash_value_offset = (hash_value / CONF_COLLECTION_DISTRIBUTED);

		if (hash_value_offset < hash_offset)
		{
			if (hash_value_offset <= empty_offset && hash_offset > empty_offset)
			{	// shift hash_value
				distributed[hinst].duplicates[empty_offset] = distributed[hinst].duplicates[hash_offset];
				empty_offset = hash_offset;
			}
		}
		else if (hash_value_offset > hash_offset)
		{
			if ((empty_offset >= 0 && empty_offset < chain_end && hash_value_offset > chain_end) || hash_value_offset <= empty_offset)
			{	// shift hash_value
				distributed[hinst].duplicates[empty_offset] = distributed[hinst].duplicates[hash_offset];
				empty_offset = hash_offset;
			}
		}

		// goto next position on same instance
#ifdef STORAGE_HASH_TEST
		hash_offset = ((hash_offset + 1) % TEST_STORAGE_HASH_MAX);
#else
		hash_offset = ((hash_offset + 1) % STORAGE_HASH_MAX);
#endif
	}

	// Linear UnProbe

	// unlock ro mutex for hash
	// unlock_hashs();

	// Empty end of chain
	if (empty_offset != chain_start)
	{
		distributed[doc_inst].doc_hash[doc_offset] = CONF_HASH_DOC_MAX_DEFINITIVE;

		distributed[hinst].duplicates[empty_offset] = 0;

		distributed[hinst].count_hash--;

		// unlock duplicates
		unlock_a_dupl(hinst);

#ifdef STORAGE_HASH_TEST
		if (TEST_CONF_COLLECTION_MAXDOC <= MAXSHOW)
		{
			mcout << NOR << "buckets " << doc->docid;

			if (doc->docid < 10) cout << "    ";
			else cout << "   ";

			for (instance_t hinst = 0; hinst < CONF_COLLECTION_DISTRIBUTED; hinst++)
			{
				for (doc_hash_t pos = 0; pos < TEST_STORAGE_HASH_MAX; pos++)
				{
					doc_hash_t hash = 0;

					docid_t	duplicate_docid = distributed[hinst].duplicates[pos];

					if (duplicate_docid == 0) cout << GRE;

					if (hinst == remove_instance && pos == remove_offset) cout << BRO;

					if (duplicate_docid > 0)
					{
						// Find instance
						instance_t doc_inst = ((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED);
						docid_t doc_offset = ((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED);

						hash = (distributed[doc_inst].doc_hash[doc_offset] % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));

						if (hash < 10) cout << ' ' << hash << NOR << ' ';
						else cout << hash << NOR << ' ';
					}
					else cout << ' ' << hash << NOR << ' ';


					if (duplicate_docid == 0)
					{
						cout << NOR;

						continue;
					}
				}
			}

			cout << NOR << mendl;
		}

		duplicates_occupation--;
#endif
		return PROBE_DELETE;
	}
	else if (distributed[hinst].duplicates[chain_start] > 0) // deletion on perfect offset
	{
		distributed[doc_inst].doc_hash[doc_offset] = CONF_HASH_DOC_MAX_DEFINITIVE;

		distributed[hinst].duplicates[chain_start] = 0;

		distributed[hinst].count_hash--;

		// unlock duplicates
		unlock_a_dupl(hinst);

#ifdef STORAGE_HASH_TEST
		if (TEST_CONF_COLLECTION_MAXDOC <= MAXSHOW)
		{
			mcout << NOR << "buckets " << doc->docid;

			if (doc->docid < 10) cout << "    ";
			else cout << "   ";

			for (instance_t hinst = 0; hinst < CONF_COLLECTION_DISTRIBUTED; hinst++)
			{
				for (doc_hash_t pos = 0; pos < TEST_STORAGE_HASH_MAX; pos++)
				{
					doc_hash_t hash = 0;

					docid_t	duplicate_docid = distributed[hinst].duplicates[pos];

					if (duplicate_docid == 0) cout << GRE;

					if (hinst == remove_instance && pos == remove_offset) cout << BRO;

					if (duplicate_docid > 0)
					{
						// Find instance
						instance_t doc_inst = ((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED);
						docid_t doc_offset = ((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED);

						hash = (distributed[doc_inst].doc_hash[doc_offset] % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));

						if (hash < 10) cout << ' ' << hash << NOR << ' ';
						else cout << hash << NOR << ' ';
					}
					else cout << ' ' << hash << NOR << ' ';

					if (duplicate_docid == 0)
					{
						cout << NOR;

						continue;
					}
				}
			}

			cout << NOR << mendl;
		}

		duplicates_occupation--;
#endif
		return PROBE_DELETE;
	}

	// unlock duplicates
	unlock_a_dupl(hinst);

#ifdef STORAGE_HASH_TEST
	if (TEST_CONF_COLLECTION_MAXDOC <= MAXSHOW)
	{
		mcout << NOR << "buckets err  ";

		for (instance_t hinst = 0; hinst < CONF_COLLECTION_DISTRIBUTED; hinst++)
		{
			for (doc_hash_t pos = 0; pos < TEST_STORAGE_HASH_MAX; pos++)
			{
				doc_hash_t hash = 0;

				docid_t	duplicate_docid = distributed[hinst].duplicates[pos];

				if (duplicate_docid == 0) cout << GRE;

				if (duplicate_docid > 0)
				{
					// Find instance
					instance_t doc_inst = ((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED);
					docid_t doc_offset = ((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED);


#ifndef STORAGE_HASH_TEST
					hash = (distributed[doc_inst].doc_hash[doc_offset] % (STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));
#else
					hash = (distributed[doc_inst].doc_hash[doc_offset] % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));
#endif

					if (hash < 10) cout << ' ' << hash << ' ';
					else cout << hash << ' ';
				}
				else cout << ' ' << hash << ' ';

				if (duplicate_docid == 0)
				{
					cout << NOR;

					continue;
				}
			}
		}

		cout << NOR << mendl;
	}
#endif

	return PROBE_ERROR;
}

void cleanup()
{
}

//
// Name: linear_probing_usage
//
// Description:
//   Prints an usage message, then stops
//

void linear_probing_usage() {
	cerr << "Usage: program [OPTION]" << endl;
	cerr << RED << "WARNING: This program is only for developer testing and the user must know what are doing!" << NOR << endl;
	cerr << RED << "IMPORTANT: Each hash storage (here called duplicate file) must have at least ONE empty offset and in real world situation";
	cerr << "you have to consider sufficient space as to ensure the working of algorithm, else you can have stalled situations..." << NOR << endl;
	cerr << "It check linear unprobing algorithm!"<< endl;
	cerr << endl;
	cerr << " --size value (-s)             set the size of instance Storage.hash, with a size major of " << MAXSHOW << " you can only check if algorithm give errors." << endl;
	cerr << " --virtualtime value (-v)      set a const time for checking same simulation" << endl;
	cerr << " --instance value (-i)         set the instance to debug without interferences of other threads" << endl;
	cerr << " --help (-h)                   this help message" << endl;
	cerr << endl;
	cbot_stop(0);
}
