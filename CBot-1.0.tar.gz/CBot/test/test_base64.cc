/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include <config.h>

// System libraries

#include <ctime>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string.h>
#include <unistd.h>
#include <assert.h>


// Local libraries

#include "cleanup.h"
#include "base64.h"

#ifndef TESTS
#define TESTS 10000
#endif

using namespace std;

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

static void usage(void);

void GenerateRandomString(std::string *string, size_t size) {
  string->resize(size);

  for (size_t i = 0; i < size; ++i) {
    (*string)[i] = rand() % 256;
  }
}

void GenerateRandomAlphaNumString(std::string *string, size_t size) {
  static const char kAlphaNum[] =
      "0123456789"
      "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
      "abcdefghijklmnopqrstuvwxyz";

  string->resize(size);

  for (size_t i = 0; i < size; ++i) {
    (*string)[i] = kAlphaNum[rand() % (sizeof(kAlphaNum) - 1)];
  }
}

long GenerateRandomNumber(long max) {
  return rand() % max;
}

long GenerateRandomNumber(long min, long max) {
  return rand() % (max - min) + min;
}

bool TestBase64(const std::string &input, bool strip_padding = false) {
  static std::string encoded;
  static std::string decoded;

  if (!Base64::Encode(input, &encoded)) {
    std::cout << "Failed to encode input string" << std::endl;
    return false;
  }

  if (strip_padding) Base64::StripPadding(&encoded);

  if (!Base64::Decode(encoded, &decoded)) {
    std::cout << "Failed to decode encoded string" << std::endl;
    return false;
  }

  if (input != decoded) {
    std::cout << "Input and decoded string differs" << std::endl;
    return false;
  }

  return true;
}

bool TestCBase64(const std::string &input, bool strip_padding = false) {
  static std::string encoded;
  static std::string decoded;

  encoded.resize(Base64::EncodedLength(input));
  if (!Base64::Encode(input.c_str(), input.size(), &encoded[0], encoded.size())) {
    std::cout << "Failed to encode input string" << std::endl;
    return false;
  }

  if (strip_padding) Base64::StripPadding(&encoded);

  decoded.resize(Base64::DecodedLength(encoded));
  if (!Base64::Decode(encoded.c_str(), encoded.size(), &decoded[0], decoded.size())) {
    std::cout << "Failed to decode encoded string" << std::endl;
    return false;
  }

  if (input != decoded) {
    std::cout << "Input and decoded string differs" << std::endl;
    return false;
  }

  return true;
}

int main(int argc, char **argv)
{
try
{
	while (true)
	{
		char c = getopt(argc, argv, "ts:h");

		if( c == -1)
			break;
	
		switch (c)
		{
			case 's':

				if (optarg != NULL)
				{
	//				options.domains[options.ndomains - 1] = strdup(optarg);
				}
				else
					usage();

				break;
			case 't':
			/*
				if (!strcasecmp(optarg,"a"))
					addr_family = AF_INET;
				else if (!strcasecmp(optarg,"aaaa"))
					addr_family = AF_INET6;
				else if (!strcasecmp(optarg,"u"))
					addr_family = AF_UNSPEC;
				else */
					usage();

				break;
			case 'h':
			default:
				usage();

			break;
		}
	}
/*	
	argc -= optind;
	argv += optind;
	
	if (argc < 1)
		usage();
*/	
  srand(time(NULL));

  std::string input;

  for (size_t i = 0; i < TESTS; ++i) {
    GenerateRandomAlphaNumString(&input, GenerateRandomNumber(100, 200));

    if (!TestBase64(input)) return -1;
    if (!TestCBase64(input)) return -1;
  }

  for (size_t i = 0; i < TESTS; ++i) {
    GenerateRandomString(&input, GenerateRandomNumber(100, 200));

    if (!TestBase64(input)) return -1;
    if (!TestCBase64(input)) return -1;
  }

  for (size_t i = 0; i < TESTS; ++i) {
    GenerateRandomAlphaNumString(&input, GenerateRandomNumber(100, 200));

    if (!TestBase64(input, true)) return -1;
    if (!TestCBase64(input, true)) return -1;
  }

  for (size_t i = 0; i < TESTS; ++i) {
    GenerateRandomString(&input, GenerateRandomNumber(100, 200));

    if (!TestBase64(input, true)) return -1;
    if (!TestCBase64(input, true)) return -1;
  }

	// End
	if (thread_alarm == THREADS_OK)
		return 0;
	else
		return 1;
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	return 1;
}
}
	
static void usage(void)
{
	// cerr << "Usage: program [-s {server}] [-t {a|aaaa|u}] {host|addr} ..." << endl;
	exit(1);
}
