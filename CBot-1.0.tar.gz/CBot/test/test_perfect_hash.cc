/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include <stdio.h>
#include <assert.h>
#include "perfect_hash.h"
#include "perfect_hash.cc"
#include "config.h"
#include "const.h"
#include "xmlconf.h"
#include "xmlconf-main.h"
#include "utils.h"
#include "cleanup.h"
//#define MAX_STR_LEN 1024

// Globals

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

void cleanup()
{
	return;
}

int main( int argc, char **argv )
{
try
{
	cbot_start( "cbot-test-perfhash" );

	perfhash_t keep_tag;       // HTML elements keepd
	perfhash_t keep_attribute; // HTML attrs keepd
	perfhash_t accept_protocol; // Protocols to accept 
	perfhash_t blocked_ip;    // Bad ipv4 address
	perfhash_t keep_special;    // Special domains keepd (see domainid) 
	perfhash_t discard_content;    // Elements whose content is discarded
	perfhash_t extensions_ignore;  // Extensions to ignore
	perfhash_t extensions_log;     // Extensions to log, but not to download
	perfhash_t extensions_stat;    // Extensions to count, but neither log nor download


	bool double_check_kept_markup = false;

	// Can be set to false for better speed, but less reliability
	// while discarding tags

	/* We don't want to loose text accidentaly */
	cerr << "Initializing mappings: " << endl << "discard_content, ";
	discard_content.check_matches = true;
	// perfhash_create( &(discard_content), "style script object embed" );
	perfhash_create( &(discard_content), CONF_GATHERER_DISCARD_CONTENT );
	perfhash_dump( &(discard_content) );
	/* We will tokenize only once */
	char *word = strtok( CONF_GATHERER_DISCARD_CONTENT, CONF_LIST_SEPARATOR );

	while( word != NULL )
	{
		assert( perfhash_check( &(discard_content), word ) );
		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	perfhash_destroy( &(discard_content) );


	cerr << "keep tags, ";
	keep_tag.check_matches = double_check_kept_markup;
	perfhash_create( &(keep_tag), CONF_GATHERER_KEEP_TAG );
	perfhash_dump( &(keep_tag) );
	/* We will tokenize only once */
	word = strtok( CONF_GATHERER_KEEP_TAG, CONF_LIST_SEPARATOR );

	while( word != NULL )
	{
		assert( perfhash_check( &(keep_tag), word ) );
		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	perfhash_destroy( &(keep_tag) );

	cerr << "keep attributes, ";
	keep_attribute.check_matches = double_check_kept_markup;
	perfhash_create( &(keep_attribute), CONF_GATHERER_KEEP_ATTRIBUTE );
	perfhash_dump( &(keep_attribute) );
	/* We will tokenize only once */
	word = strtok( CONF_GATHERER_KEEP_ATTRIBUTE, CONF_LIST_SEPARATOR );

	while( word != NULL )
	{
		assert( perfhash_check( &(keep_attribute), word ) );
		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	perfhash_destroy( &(keep_attribute) );

	cerr << "accepted protocols, ";
	accept_protocol.check_matches = true;
	perfhash_create( &(accept_protocol), CONF_SEEDER_LINK_ACCEPT_PROTOCOL );
	perfhash_dump( &(accept_protocol) );
	/* We will tokenize only once */
	word = strtok( CONF_SEEDER_LINK_ACCEPT_PROTOCOL, CONF_LIST_SEPARATOR );

	while( word != NULL )
	{
		assert( perfhash_check( &(accept_protocol), word ) );
		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	perfhash_destroy( &(accept_protocol) );

	cerr << "blocked ip, ";
	blocked_ip.check_matches = true;
	perfhash_create( &(blocked_ip), CONF_HARVESTER_BLOCKED_IP );
	perfhash_dump( &(blocked_ip) );
	/* We will tokenize only once */
	word = strtok( CONF_HARVESTER_BLOCKED_IP, CONF_LIST_SEPARATOR );

	while( word != NULL )
	{
		assert( perfhash_check( &(blocked_ip), word ) );
		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	perfhash_destroy( &(blocked_ip) );

	cerr << "keep special domains, ";
	keep_special.check_matches = true;
	perfhash_create( &(keep_special), CONF_COLLECTION_IT_SPECIAL_DOMAINS );
	perfhash_dump( &(keep_special) );
	/* We will tokenize only once */
	word = strtok( CONF_COLLECTION_IT_SPECIAL_DOMAINS, CONF_LIST_SEPARATOR );

	while( word != NULL )
	{
		assert( perfhash_check( &(keep_special), word ) );
		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	cerr << "extensions to ignore, ";
	extensions_ignore.check_matches = true;
	perfhash_create( &(extensions_ignore), CONF_SEEDER_LINK_EXTENSIONS_IGNORE );
	perfhash_dump( &(extensions_ignore) );
	/* We will tokenize only once */
	word = strtok( CONF_SEEDER_LINK_EXTENSIONS_IGNORE, CONF_LIST_SEPARATOR );

	while( word != NULL )
	{
		assert( perfhash_check( &(extensions_ignore), word ) );
		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	perfhash_destroy( &(extensions_ignore) );

	cerr << "extensions to log, ";
	extensions_log.check_matches = true;
	perfhash_create( &(extensions_log), CONF_SEEDER_LINK_EXTENSIONS_LOG );
	perfhash_dump( &(extensions_log) );
	/* We will tokenize only once */
	word = strtok( CONF_SEEDER_LINK_EXTENSIONS_LOG, CONF_LIST_SEPARATOR );

	while( word != NULL )
	{
		assert( perfhash_check( &(extensions_log), word ) );
		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	perfhash_destroy( &(extensions_log) );

	cerr << "keep special domains, ";
	extensions_stat.check_matches = true;
	perfhash_create( &(extensions_stat), CONF_SEEDER_LINK_EXTENSIONS_STAT );
	perfhash_dump( &(extensions_stat) );
	/* We will tokenize only once */
	word = strtok( CONF_SEEDER_LINK_EXTENSIONS_STAT, CONF_LIST_SEPARATOR );

	while( word != NULL )
	{
		assert( perfhash_check( &(extensions_stat), word ) );
		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	perfhash_destroy( &(extensions_stat) );

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}
}
