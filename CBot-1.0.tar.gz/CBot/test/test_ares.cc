/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include <config.h>

// System libraries

#include <iostream>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <ares.h>

//Local libraries
#include "cleanup.h"

using namespace std;

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

static void callback(void *arg, int status, int timeouts, struct hostent *host);
static void usage(void);

int main(int argc, char **argv)
{
try
{
	struct ares_options options;
	int optmask = 0;
	ares_channel channel;
	int status, nfds, addr_family = AF_INET;
	fd_set read_fds, write_fds;
	struct timeval *tvp, tv;
	struct in_addr addr4;
	struct ares_in6_addr addr6;
	
	memset(&options, 0, sizeof(options));

	options.domains = NULL;
	
	status = ares_library_init(ARES_LIB_INIT_ALL);

	if (status != ARES_SUCCESS)
	{
		cerr <<  "ares_library_init: " << ares_strerror(status) << endl;
		return 1;
	}
	
	while (true)
	{
		char c = getopt(argc, argv, "ts:h");

		if( c == -1)
			break;
	
		switch (c)
		{
			case 's':

				if (options.domains == NULL && optarg != NULL)
				{
					optmask |= ARES_OPT_DOMAINS;
					options.ndomains++;
					options.domains = (char **) malloc (options.ndomains * sizeof(char *));
					options.domains[options.ndomains - 1] = strdup(optarg);
				}
				else
					usage();

				break;
			case 't':
				if (!strcasecmp(optarg,"a"))
					addr_family = AF_INET;
				else if (!strcasecmp(optarg,"aaaa"))
					addr_family = AF_INET6;
				else if (!strcasecmp(optarg,"u"))
					addr_family = AF_UNSPEC;
				else
					usage();

				break;
			case 'h':
			default:
				usage();

			break;
		}
	}
	
	argc -= optind;
	argv += optind;
	
	if (argc < 1)
		usage();
	
	status = ares_init_options(&channel, &options, optmask);

	if (status != ARES_SUCCESS)
	{
		cerr <<  "ares_init: " << ares_strerror(status) << endl;
		return 1;
	}
	
	/* Initiate the queries, one per command-line argument. */
	for ( ; *argv; argv++)
	{
		if (ares_inet_pton(AF_INET, *argv, &addr4) == 1)
			ares_gethostbyaddr(channel, &addr4, sizeof(addr4), AF_INET, callback, *argv);
		else if (ares_inet_pton(AF_INET6, *argv, &addr6) == 1)
			ares_gethostbyaddr(channel, &addr6, sizeof(addr6), AF_INET6, callback, *argv);
		else
			ares_gethostbyname(channel, *argv, addr_family, callback, *argv);
	}
	
	/* Wait for all queries to complete. */
	while (true)
	{
		int res;

		FD_ZERO(&read_fds);
		FD_ZERO(&write_fds);

		nfds = ares_fds(channel, &read_fds, &write_fds);

		if (nfds == 0)
			break;

		tvp = ares_timeout(channel, NULL, &tv);
		res = select(nfds, &read_fds, &write_fds, NULL, tvp);

		if (-1 == res)
			break;

		ares_process(channel, &read_fds, &write_fds);
	}

	if (options.domains != NULL && options.domains[0] != NULL)
		free(options.domains[0]);

	if (options.domains != NULL)
		free(options.domains);
	
	ares_destroy(channel);
	ares_library_cleanup();
	
	return 0;
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	return 1;
}
}
	
static void callback(void *arg, int status, int timeouts, struct hostent *host)
{
	char **p;
	
	(void)timeouts;
	
	if (status != ARES_SUCCESS)
	{
		cerr << (char *)arg << ": " << ares_strerror(status) << endl;
		return;
	}
	
	for (p = host->h_addr_list; *p; p++)
	{
		char addr_buf[INET6_ADDRSTRLEN] = "??";
	
		ares_inet_ntop(host->h_addrtype, *p, addr_buf, sizeof(addr_buf));
		printf("%-32s\t%s", host->h_name, addr_buf);

#if 0
		if (host->h_aliases[0])
		{
			int i;
	
			printf (", Aliases: ");
			for (i = 0; host->h_aliases[i]; i++)
				cout << host->h_aliases[i]) << endl;
		}
#endif

		puts("");
	}
}
	
static void usage(void)
{
	cerr << "Usage: program [-s {server}] [-t {a|aaaa|u}] {host|addr} ..." << endl;;
	exit(1);
}
