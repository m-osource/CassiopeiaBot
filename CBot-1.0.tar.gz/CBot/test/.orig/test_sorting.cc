/* Copyright 1998 by the Massachusetts Institute of Technology.
*
*
* Permission to use, copy, modify, and distribute this
* software and its documentation for any purpose and without
* fee is hereby granted, provided that the above copyright
* notice appear in all copies and that both that copyright
* notice and this permission notice appear in supporting
* documentation, and that the name of M.I.T. not be used in
* advertising or publicity pertaining to distribution of the
* software without specific, written prior permission.
* M.I.T. makes no representations about the suitability of
* this software for any purpose.  It is provided "as is"
* without express or implied warranty.
*/

#include <config.h>

// System libraries

#include <iostream>
#include <getopt.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <ares.h>

//Local libraries
#include "const.h"
#include "xmlconf.h"
#include "xmlconf-main.h"
#include "Meta.h"
#include "templates.h"

typedef struct {
		instance_t inst;
		CBotSort<priority_t, docid_t> *sortp;
	} thread_args_t;


// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

using namespace std;

void *thread_function_sorting( void * );
static void sorting_usage( void );

int main(int argc, char **argv)
{
	cbot_start("sorting");

	int rc = 0;
	size_t size = 0;
	size_t offset = 0;

	while (true)
	{
		int option_index = 0;
		static struct option long_options[] = {
			{"offset", 1, 0, 0},
			{"size", 1, 0, 0},
			{"help", 0, 0, 0}
		};

		char c = getopt_long(argc, argv, "os:h", long_options, &option_index);

		if(c == -1)
			break;
	
		switch (c)
		{
			case 0:
				if (!strcmp(long_options[option_index].name, "offset"))
					offset = (size_t)(atol(optarg));
				else if (!strcmp(long_options[option_index].name, "size"))
					size = (size_t)(atol(optarg));
				else if (!strcmp(long_options[option_index].name, "help"))
					sorting_usage();

				break;
			case 'o':
				offset = (size_t)(atol(optarg));
			break;
			case 's':
				size = (size_t)(atol(optarg));
			break;
			case 'h':
				sorting_usage();
			break;
			default:
				sorting_usage();
			break;
		}
	}


	
//	argc -= optind;
//	argv += optind;
	
	if (argc < 5 || size < offset || size < 5)
		sorting_usage();

	priority_t *priority = CBALLOC(priority_t, CALLOC, (size + offset));
	docid_t *order = CBALLOC(docid_t, CALLOC, (size + offset));

	// assign priority
	for (size_t i = offset; i < (size + offset); i++)
	{
		if ((i % 2) == 1)
			priority[i] = -1;
		else
		{
			priority[i] = 106;
			assert((size % 2) == 0);
			//priority[i] = (static_cast<priority_t>(rand()%100) / 100);
		}

//		cout << i << ' ' << priority[i] << endl;
	}

	CBotSort<priority_t, docid_t> *sortp = new CBotSort<priority_t, docid_t> (priority, order, size, 0, offset, NULL, false, false, false);
	sortp->barrier_init();

	pthread_mutexattr_t attr;

	pthread_t *threads = NULL;

	pthread_barrier_t *barrier = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", strerror(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", strerror(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		thread_args_t *args = CBALLOC(thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->sortp = sortp;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if ( pthread_create( &threads[inst], NULL, thread_function_sorting, (void *) args ) )
				die("error creating thread!");
		}
		else
			thread_function_sorting((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
			pthread_join( threads[inst], NULL);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", strerror(rc));
	}

	// check order
	for (size_t i = offset; i < (size + offset); i++)
	{
		if ((i <= (size / 2)) && ((order[i] % 2) == 0))
			cout << i << ' ' << order[i] << " priority " << priority[order[i]] << endl;
		else if ((i >= (size / 2)) && ((order[i] % 2) == 1))
			cout << i << ' ' << order[i] << " priority " << priority[order[i]] << endl;
		else
		{
			sleep(2);
			cerr << endl;
			cerr << RED << "ERROR: " << i << ' ' << order[i] << " priority " << priority[order[i]] << NOR << endl;
			break;
		}
	}

	free(priority);
	free(order);
	delete sortp;

	// Exit
	cbot_stop(0);
}

void *thread_function_sorting(void *args)
{
	thread_args_t *arguments = (thread_args_t *)args;
	instance_t inst = arguments->inst;
	CBotSort<priority_t, docid_t> *sortp = arguments->sortp;

	sortp->order(inst);

	return NULL;
}

void cleanup()
{
}

//
// Name: manager_usage
//
// Description:
//   Prints an usage message, then stops
//

void sorting_usage() {
	cerr << "Usage: program [OPTION]" << endl;
	cerr << RED << "WARNING: This program is only for developer testing and the user must know what are doing!" << NOR << endl;
	cerr << "It check sorting algorithm!"<< endl;
	cerr << endl;
	cerr << " --offset            set the offset for base array" << endl;
	cerr << " --size              set the size of the base array" << endl;
	cerr << " --help              this help message" << endl;
	cerr << endl;
	cbot_stop(0);
}
