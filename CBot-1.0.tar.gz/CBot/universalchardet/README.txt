#######################

Aggiornato 22 gennaio del 2017 e scaricato da https://www.freedesktop.org/software/uchardet/releases/

Versione uchardet 0.0.6

Da testare se tutto ok
