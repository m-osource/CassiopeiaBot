/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "connddx.h"

connddx_t *connddx_open(const char *dirname, bool readonly)
{
	// Request memory for the structure
	connddx_t *n = CBALLOC(connddx_t, MALLOC, 1);
	n->count_nvc = 0;
	n->readonly = readonly;

	n->distributed = CBALLOC(cddx_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	assert(n->distributed != NULL);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		connddx_thread_function_args_t *args = CBALLOC(connddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->n = n;
		args->d = (char *)dirname;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[i], NULL, connddx_thread_function_open, (void *) args))
				die("error creating thread!");
		}
		else
			connddx_thread_function_open((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		// Update nvc master counter
		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			n->count_nvc += n->distributed[i].count_nvc;

		free(threads);
	}
	else
	{
			instance_t i = (CONF_COLLECTION_DISTRIBUTED - 1);

			// Update nvc master counter
			n->count_nvc += n->distributed[i].count_nvc;
	}

	if (n->count_nvc > 0)
		cerr << endl << "Found " << n->count_nvc << " nvcs." << endl;

	return n;
}

//
// Name: connddx_thread_function_open
//
// Description: invoked by 'connddx_open' as thread
//
// Arguments: a void pointer to connddx_thread_function_args_t type structure 
//
// Return: NULL
//
void *connddx_thread_function_open(void *args)
{
try
{
	cpu_set_t system_cpus;

	connddx_thread_function_args_t *arguments = (connddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	connddx_t *n = arguments->n;
	char *dirname = arguments->d;

	char filename[MAX_STR_LEN];
	struct stat64 statbuf;

	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
	strcpy(n->distributed[inst].dirname, relative_rem_path);
	free(relative_rem_path);
	n->distributed[inst].count_nvc = 0;

	// Go ahead to nvcs .... Create or open filename
	sprintf(filename, "%s/%s", n->distributed[inst].dirname, CONNDDX_FILENAME_NVC);

	errno = 0; // errno is thread-local

	// Check if file exists
	if(stat64(filename, &statbuf) == 0)
	{
		// Verify file size
		if((unsigned long int)(statbuf.st_size) != (sizeof(nvc_t) * INSTANCE_MAXDOC))
		{
//			if((unsigned long int)(statbuf.st_size) != (sizeof(nvc_old_t) * INSTANCE_MAXDOC))
//			{
				cerr << "Inconsistency in nvc_t:" << endl;
				cerr << "- Distributed          : " << inst << endl;
				cerr << "- Sizeof(nvc_t)        : " << sizeof(nvc_t) << endl;
//				cerr << "- Sizeof(nvc_old_t)    : " << sizeof(nvc_old_t) << endl;
				cerr << "- Maxnvcs              : " << INSTANCE_MAXDOC << endl;
				cerr << "- Size of current file : " << (unsigned long int)(statbuf.st_size) << endl;
				cerr << "- Expected size        : " << sizeof(nvc_t) * INSTANCE_MAXDOC << endl;
				die("Inconsistency in nvc_t");
				// cerr << "The size of the file of metadata of nvcs is wrong" << endl;
				// cerr << "Probably you changed maxnvc in the configuration" << endl;
				// cerr << "Or the version of CBOT is wrong" << endl;
				// die("Inconsistency in the size of nvc_t");
//			}
//			else
//				connddx_convert_old_nvc_file(filename);
		}

		if(n->readonly)
			n->distributed[inst].file_nvc = open64(filename, O_RDONLY);
		else
			n->distributed[inst].file_nvc = open64(filename, O_RDWR, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (errno != 0)
			die("connddx_open: couldn't open file %s on %s", cberr(), filename);

		// Read the header nvc document
		assert(lseek(n->distributed[inst].file_nvc, (off64_t)0, SEEK_SET) == 0);

		if (errno != 0)
			die("connddx_open: couldn't seek file %s on %s", cberr(), filename);

		nvc_t nvc_header;
		assert(read(n->distributed[inst].file_nvc, &nvc_header, sizeof(nvc_t)) == sizeof(nvc_t));

		if (errno != 0)
			die("connddx_open: couldn't read file %s on %s", cberr(), filename);

		// Read data from it
		n->distributed[inst].count_nvc = nvc_header.docid;
	}
	else
	{

		// Check readonly
		if(n->readonly)
			die("Couldn't create index: readonly mode enabled");

		// Create file
		n->distributed[inst].file_nvc = open64(filename, O_RDWR|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (n->distributed[inst].file_nvc == -1 && errno != 0)
			die("connddx_open: couldn't open file %s on %s", cberr(), filename);

		nvc_t nvc;
		memset (&nvc, 0, sizeof(nvc_t));

		for(docid_t is = 0; is < INSTANCE_MAXDOC; is++) write(n->distributed[inst].file_nvc, &nvc, sizeof(nvc_t));

		// Initialize data
		n->distributed[inst].count_nvc = 0;
	}

	// if(n->distributed[inst].file_nvc == NULL)
	if(n->distributed[inst].file_nvc == 0)
	{
		sprintf(filename, "%s/%s", n->distributed[inst].dirname, CONNDDX_FILENAME_NVC);
		perror(filename);
	}
	
	// assert(n->distributed[inst].file_nvc != NULL);
	assert(n->distributed[inst].file_nvc != 0);

	arguments->d = NULL;
	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}

//

//
// Name: connddx_close
//
// Description:
//   Closes a structure. Writes data to disk.
//
// Input:
//   connddx - the connddx structure
//
// Return: 
//   status code
//

connddx_status_t connddx_close(connddx_t *n)
{

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		assert(n->distributed[i].file_nvc != 0);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		connddx_thread_function_args_t *args = CBALLOC(connddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->n = n;
		args->d = NULL;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if(n->readonly == false)
			{
				if (pthread_create(&threads[i], NULL, connddx_thread_function_close, (void *) args))
					die("error creating thread!");
			}
			else
			{
				if (pthread_create(&threads[i], NULL, connddx_thread_function_ronly_close, (void *) args))
					die("error creating thread!");
			}

		}
		else
		{
			if(n->readonly == false)
				connddx_thread_function_close((void *) args); // if only one distribution, function is call without thread
			else
				connddx_thread_function_ronly_close((void *) args); // if only one distribution, function is call without thread 
		}
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}

	// Free
	free(n->distributed);
	free(n);

	return CONNDDX_OK;
}

//
// Name: connddx_thread_function_close
//
// Description: invoked by 'connddx_close' as thread
//
// Arguments: a void pointer to connddx_thread_function_args_t type structure that contain instance and connddx_t type structure 
//
// Return: NULL
//
void *connddx_thread_function_close(void *args)
{
try
{
	cpu_set_t system_cpus;

	connddx_thread_function_args_t *arguments = (connddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	connddx_t *n = arguments->n;

	int rc;

	errno = 0; // errno is thread_local

	// check if file descriptors are valid
	assert(fcntl(n->distributed[inst].file_nvc, F_GETFL) != 1);

	if (errno != 0)
		die("connddx close: do not have a valid nvc file descriptor %s", cberr());

	nvc_t nvc_header;
	memset(&nvc_header, 0, sizeof(nvc_t));

	// Generate data for headers
	nvc_header.docid = n->distributed[inst].count_nvc;

	// Write headers
	assert(lseek(n->distributed[inst].file_nvc, (off64_t)0, SEEK_SET) == 0);

	if (errno != 0)
		die("connddx close: couldn't seek nvc file %s", cberr());

	assert(write(n->distributed[inst].file_nvc, &nvc_header, sizeof(nvc_t)) == sizeof(nvc_t));

	if (errno != 0)
		die("connddx close: couldn't write nvc file %s", cberr());

	// Test if there is corruption
	if (n->distributed[inst].count_nvc > 1)
	{
		nvc_t test;
		test.docid = (docid_t)(inst + 1);
		int rc = connddx_nvc_retrieve(n, &(test));

		if (rc != CONNDDX_OK)
			die("connddx close: corruption at closing time, the connddx has more than 1 docid but metadata of nvc 1 can not be read!");

		if (test.docid != (docid_t)(inst + 1))
			die("connddx close: corruption at closing time, nvc 1 was read but had the wrong docid!");
	}
/*
	rc = fsync(n->distributed[inst].file_nvc);

	if (errno != 0)
		die("connddx close: error syncing site file descriptor %s", cberr());

	assert(rc == 0);
*/

	rc = close(n->distributed[inst].file_nvc);

	if (errno != 0)
		die("connddx close: error closing nvc file descriptor %s", cberr());

	if (rc != 0)
		die("connddx close: couldn't close nvc file descriptor because return invalid status\n");

	n->distributed[inst].file_nvc = 0;

	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}

//
// Name: connddx_thread_function_ronly_close
//
// Description: invoked by 'connddx_close' as thread
//
// Arguments: a void pointer to connddx_thread_function_args_t type structure that contain instance and connddx_t type structure 
//
// Return: NULL
//
void *connddx_thread_function_ronly_close(void *args)
{
try
{
	cpu_set_t system_cpus;

	nvc_t nvc_header;
	memset(&nvc_header, 0, sizeof(nvc_t));

	connddx_thread_function_args_t *arguments = (connddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	connddx_t *n = arguments->n;

	errno = 0; // errno is thread_local

	int rc = close(n->distributed[inst].file_nvc);

	if (errno != 0)
		die("connddx close: error closing nvc file descriptor %s", cberr());

	if (rc != 0)
		die("connddx close: couldn't close nvc file descriptor because return invalid status\n");

	n->distributed[inst].file_nvc = 0;

	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}



//
// Name: connddx_remove
//
// Description:
//   Removes files into directories connddx0, connddx1... and optionally connddx0, connddx1... (unneeded)
//
// Input:
//   dirname - the directory
//   

void connddx_remove(const char *dirname)
{
	struct stat64 statbuf;

	pthread_t *threads = NULL;

	instance_t max_instances = 0;

	// check how many directory contain data to delete
	for (instance_t i = 0; i < ((instance_t)(~0)); i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, i);

		if (stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
			max_instances++;
		else
		{
			free(relative_rem_path);
			break;
		}

		free(relative_rem_path);
	}

	if (max_instances > 1)
		threads = CBALLOC(pthread_t, MALLOC, max_instances);

	for (instance_t i = 0; i < max_instances; i++)
	{
		connddx_thread_function_args_t *args = CBALLOC(connddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->n = NULL;
		args->d = (char *)dirname;

		if (max_instances > 1)
		{
			if (pthread_create(&threads[i], NULL, connddx_thread_function_remove, (void *) args))
				die("error creating thread!");
		}
		else
			connddx_thread_function_remove((void *) args); // only one distribution, function is call without thread 
	}

	if (max_instances > 1)
	{
		CBotjoin(threads, max_instances);

		free(threads);
	}
}

//
// Name: connddx_thread_function_remove
//
// Description: invoked by 'connddx_remove' as thread
//
// Arguments: a void pointer to connddx_thread_function_args_t type structure 
//
// Return: NULL
//
void *connddx_thread_function_remove(void *args)
{
try
{
	cpu_set_t system_cpus;

	connddx_thread_function_args_t *arguments = (connddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	char *dirname = arguments->d;
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);

	queue<string> files;

	// Push files
	files.push(CONNDDX_FILENAME_NVC);

	// Delete
	while(! files.empty())
	{
		// Create filename
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, files.front().c_str());

		// Delete file
		int rc = unlink(filename);

		if (rc != 0 && errno != ENOENT)
		{
			perror(files.front().c_str());
			die("Couldn't unlink file");
		}

		// Remove file from queue
		files.pop();
	}

	if (inst >= CONF_COLLECTION_DISTRIBUTED)
	{
		// Delete dir (rimuove le directory metadata0, metadata1 ecc..)
		int rc = remove(relative_rem_path);

		if (rc != 0 && errno != ENOENT)
		{
			perror(relative_rem_path); 
			// die("Couldn't remove directory");
		}
	}

	free(relative_rem_path);

	arguments->d = NULL;
	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}

//
// Name: connddx_nvc_store
//
// Description:
//   Stores information about a nvc in MULTITHREAD!
//   With 'old_nvc' it compare byte to byte struct before write to disk (performances reasons but now not needed).
//
// Input:
//    connddx - the connddx structure
//    nvc - the nvc to be stored
//    old_nvc - the 'old_nvc' to be compared with the new (only update)
// 
// Return:
//    status code
//
connddx_status_t connddx_nvc_store(connddx_t *n, nvc_t *nvc)
{
	assert(nvc->docid > 0);
	assert(nvc->docid < CONF_COLLECTION_MAXDOC);
	assert(!n->readonly);

	instance_t instance =	((nvc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = (((nvc->docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	errno = 0; // errno is thread_local

	// Seek
	off64_t address = ((off64_t)sizeof(nvc_t)) * id_offset;

	ssize_t wr = pwrite64(n->distributed[instance].file_nvc, &nvc, sizeof(nvc_t), address);

	if (errno != 0)
		die("connddx_nvc_store: for docid %llu couldn't write file (address %llu) %s", nvc->docid, (unsigned long long int)address, cberr());

	assert(wr == (ssize_t)(sizeof(nvc_t)));

	// Update distributed count
	if (id_offset > n->distributed[instance].count_nvc)
		n->distributed[instance].count_nvc = id_offset;

	return CONNDDX_OK;
}

// 
// Name: connddx_nvc_retrieve
//
// Description:
//   Retrieves information about a nvcument
//
// Input:
//   connddx - metaindex holding the information
//   nvc.docid - nvc id of the retrieved nvc
//
// Output:
//   nvc - nvcument
//
// Return:
//   CONNDDX_OK - success
//   CONNDDX_EOF - docid out of range
//
connddx_status_t connddx_nvc_retrieve(connddx_t *n, nvc_t *nvc)
{
	assert(nvc->docid > 0);

	docid_t real_docid = nvc->docid;
	instance_t instance =	((nvc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	nvc->docid = (((nvc->docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// See if it's inside the range
	if(nvc->docid > n->distributed[instance].count_nvc)
	{
		nvc->docid = real_docid;
		return CONNDDX_EOF;
	}

	errno = 0; // errno is thread_local

	ssize_t wr = pread64(n->distributed[instance].file_nvc, &nvc, sizeof(nvc_t), (off64_t)(sizeof(nvc_t) * nvc->docid));

	if (errno != 0)
		die("connddx_nvc_retreive: for docid %llu couldn't read file %s", nvc->docid, cberr());

	assert(wr == (ssize_t)(sizeof(nvc_t)));

	if (nvc->docid == 0)
		return CONNDDX_EOF;
	else
	{
		nvc->docid = real_docid;
		return CONNDDX_OK;
	}
}

// 
// Name: connddx_dump_nvc_status
//
// Description:
//   Prints the status of a nvc
//
// Input:
//   nvc - nvc
//

void connddx_dump_nvc_status(nvc_t *nvc)
{
	// Main variables
	cerr << "docid                 " << nvc->docid << endl;
	cerr << "siterank              " << nvc->siterank << endl;
	cerr << "pagerank              " << nvc->pagerank << endl;
	cerr << "wlrank                " << nvc->wlrank << endl;
	cerr << "liverank              " << nvc->liverank << endl;
	cerr << "cscore                " << nvc->cscore << endl;
	cerr << "uscore                " << nvc->uscore << endl;
	cerr << "number_visits_changed " << nvc->number_visits_changed << endl;
	cerr << "http_status           " << nvc->http_status
		<< " (" << HTTP_STR(nvc->http_status) << ": "
		<<  HTTP_IS_STR(nvc->http_status) << ")" << endl;
}

// 
// Name: connddx_dump_nvc_header
//
// Description:
//   Prints a line with the header data
//   for connddx_dump_nvc
//
// Input:
//   out - the output file handler
//
void connddx_dump_nvc_header(FILE *out)
{
	assert(out != NULL);
	
	// The order is very important. It must be consistent with
	// connddx_dump_nvc

//	fprintf(out, "1docid,");
	fprintf(out, "1docid\n");
//	fprintf(out, "37sitemap priority\n");
}

// 
// Name: connddx_dump_nvc
//
// Description:
//   Prints a line with the data about a nvc
//
// Input:
//   nvc - nvc
//   out - the output file handler
//

void connddx_dump_nvc(nvc_t *nvc, FILE *out)
{
	assert(nvc != NULL);
	assert(out != NULL);

	// The order is very important. It must be consistent with
	// connddx_dump_nvc_header

	// fprintf(out, "%lu,",  	nvc->docid);
	fprintf(out, "%lu\n",  	(unsigned long int)nvc->docid);
//	fprintf(out, "%d\n",  	doc->sitemap_prio);
}

// 
// Name: connddx_dump_nvc_short_status
//
// Description:
//   Prints the status of a nvc in one line
//
// Input:
//   nvc - nvc
//

void connddx_dump_nvc_short_status(nvc_t *nvc)
{
/*
	// Status
	cerr << DOC_STATUS_STR(doc->status) << " ";
	cerr << MIME_TYPE_STR(doc->mime_type) << " ";
	cerr << HTTP_STR(doc->http_status) << ":"
		<<	HTTP_IS_STR(doc->http_status) << " ";

	// Scores
	cerr << "in " << doc->in_degree << " ";
	cerr << "out " << doc->out_degree << " ";
	cerr << "pr " << doc->pagerank;
	cerr << "wl " << doc->wlrank;
	cerr << "lr " << doc->liverank;
*/
}

//
// Name: connddx_nvc_default
//
// Description:
//   Fills all the default data about a nvc
//
// Input:
//   nvc - empty nvc object
//
// Output:
//   nvc - fill nvc object
//
void connddx_nvc_default(nvc_t *nvc)
{

	memset(nvc, 0, sizeof(nvc_t)); // to prevent valdrind warning set all (but really all) bytes to 0 in structure

	nvc->docid			= (docid_t)0;
	nvc->siterank = (siterank_t)0;
	nvc->pagerank = (pagerank_t)0;
	nvc->wlrank = (wlrank_t)0;
	nvc->liverank = (liverank_t)0;
	nvc->cscore = (priority_t)0;
	nvc->uscore = (priority_t)0;
	nvc->number_visits_changed = 0;
	nvc->http_status = HTTP_STATUS_UNDEFINED;
}

//
// Name: connddx_dump_status
// 
// Description:
//   Dumps the status of the connddx
//

void connddx_dump_status(connddx_t *connddx)
{
	cerr << "Begin status dump for connddx" << endl;

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		cerr << "- dirname on distributed   " << i << " is " << connddx->distributed[i].dirname << endl;
		cerr << "- count_nvc  on distributed " << i << " is " << connddx->distributed[i].count_nvc << endl;
	}

	cerr << "- count_nvc      " << connddx->count_nvc << endl;
	cerr << "- bytes per nvc   " << sizeof(nvc_t) << endl;
	cerr << "End status dump for connddx" << endl;
}

