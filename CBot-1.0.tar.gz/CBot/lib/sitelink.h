/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _SITELINK_H_INCLUDED_
#define _SITELINK_H_INCLUDED_

#include <config.h>

// System libraries

#include <iostream>
#include <assert.h>
#include <getopt.h>
#include <map>

using namespace std;

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "utils.h"
#include "Meta.h"
#include "cleanup.h"
#include "linkidx.h"
#include "Url.h"
#include "Storage.h"
#include "pthread.h"
#include "templates.h"


// Constants

#define UNMARKED (_nsites + 1)
#define VISITED UNMARKED
#define UNDEFINED_ID UNMARKED
#define ALMOR load(memory_order_relaxed) // atomic load value in memory_order_relaxed mode
#define COMPONENT_MAX 11

#define SITELINK_MAX_OUTDEGREE	(10000)
#define SITELINK_MAX_ITERATIONS (500)

// Typedefs

// Globals

//extern Meta			*meta;
//extern Storage		*lidx; // storage of hrefs links
extern linkidx_t	*linkidx;

enum sitelink_call_t {
	SITELINK_CREATE					= 0,
	SITELINK_LOAD					= 1,
	SITELINK_UNLOAD					= 2,
	SITELINK_ANALYSIS_SITERANK		= 3,
	SITELINK_ANALYSIS_COMPONENTS	= 4,
	SITELINK_DLFSTS					= 5
};

class Sitelink; // forward declaration for 'friend class' use

//
// Name: SCC
//
// Description: Strongly Connected Components calculations (Friend Class of 'Sitelink' Class). ITERATIVE!
//	Method more slow than recursive but also more stable.
//
// Input: pointer to Sitelink class
//
// Return: 
//
class SCC
{
	typedef struct {
		instance_t marked; // marked sequence
		siteid_t lsn; // link starting node
		siteid_t rsn; // revlink starting node
	} scc_t;

	Sitelink *sl;
	atomic<siteid_t> **scc_vec_id;
	atomic<siteid_t> **scc_vec_relative_finish;
	siteid_t **scc_vec_order;
	siteid_t **scc_base_count;
	atomic<siteid_t> **scc_vec_component;
	atomic<siteid_t> scc_count;
	atomic<siteid_t> **scc_size;
	siteid_t *scc_giant_component;
	siteid_t *scc_giant_component_size;
	siteid_t *scc_singletons;
	siteid_t *scc_no_outlinks;
	siteid_t *scc_no_inlinks;
	siteid_t *nsites_not_undef;
	siteid_t **count_component;
	map<siteid_t, siteid_t> *scc_size_histogram;
	atomic<component_t> **component;
/*
	bool **scc_vec_mark;
	siteid_t **scc_vec_component;
	siteid_t **_scc_vec_component;
	siteid_t *scc_vec_finish;
	siteid_t *_scc_vec_finish; // testing
	siteid_t *scc_vec_order;
	siteid_t scc_finish_time;
	siteid_t **scc_size;
	siteid_t *scc_count;
	siteid_t *scc_no_outlinks;
	siteid_t *scc_no_inlinks;
	scc_t **scc_vec_reference;
	atomic<bool> *scc_vec_canceled;
	atomic<siteid_t> **scc_vec_size;
	siteid_t *scc_vec_sum;
	map<siteid_t, siteid_t> *scc_size_histogram;
	siteid_t *scc_giant_component;
	siteid_t *scc_giant_component_size;
	siteid_t *scc_singletons;
	siteid_t *nsites_not_undef;
	siteid_t **component_count;
	component_t **component;
*/
	pthread_mutex_t **locks;
	atomic<unsigned char> act_challenge; // activity challenge. First thread that change the variable then execute work.
	atomic<instance_t> sequence;

	atomic<siteid_t> *testing; // uso sperimentale
	atomic<siteid_t> *_testing; // uso sperimentale

	// Analyze components
	void *thread_function_analysis_components( void * );

	// On revlinks, following the scc_vec_order numerate each graph and saving on scc_vec_component as 'root of tree'.
	void dfs_decreasing( const siteid_t, const siteid_t );

	// Marks all the sites that are reachable from a site in the graph of site links...
	void mark_reachable( siteid_t, component_t, component_t, bool );

	// Marks all the sites that are reachable from a site in the graph of reverse site links...
	void mark_reachable_rev( siteid_t, component_t, component_t, bool );

	// On links, numerate each graph and saving on scc_vec_id as 'root of tree'.
	void dfs_set_id( const siteid_t );

	// On links, assign a relative counter of node for each graph.
	void dfs_compute_relative_finish( const siteid_t );

	// Assign atomically at the vector offset the 'definitive' low value.
	template <typename T, typename U, typename W> bool scc_vec_challenge (T id, U definitive, W **vec)
	{
		instance_t id_inst = ((id - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t id_offset = ((id - 1) / CONF_COLLECTION_DISTRIBUTED);
	
		// Update the counter in thread-safe mode
		while (true)
		{
			T check = vec[id_inst][id_offset];
	
			if (definitive < check)
	        {   // if counter have value expected as 'check' it can be updated
				if (vec[id_inst][id_offset].compare_exchange_strong(check, definitive) == true)
					return true;
				else 
					continue;
			}
			else
				break;
		}
	 
		return false;
	} 

	// Function to proxy to non-static function
	static void* thread_function_caller( void * );

	public:

	SCC (Sitelink *S)
		: sl (S)
		, scc_vec_id (NULL)
		, scc_vec_relative_finish (NULL)
		, scc_vec_order (NULL)
		, scc_base_count (NULL)
		, scc_vec_component (NULL)
		, scc_count (0)
		, scc_size (NULL)
		, scc_giant_component (NULL)
		, scc_giant_component_size (NULL)
		, scc_singletons (NULL)
		, scc_no_outlinks (NULL)
		, scc_no_inlinks (NULL)
		, nsites_not_undef (NULL)
		, count_component (NULL)
		, scc_size_histogram (NULL)
		, act_challenge (0)
		, sequence (0)
	{
	}

	~SCC () // dtor
	{
	}

	// need to passing arguments to threads functions
	// Because function call by pthread_create need to be pass first through 'urlddx_thread_function_caller', these works with other temporary object
	typedef struct {
		instance_t inst;
		SCC *obj;
		sitelink_call_t f; // corrisponde alla chiamata di determinate funzioni fatta da pthread_create
		Storage *lidx; // only for analysis
		Meta *meta; // only for analysis
		bool opt_sitelinks_siterank;
	} thread_args_t;

	// Analyze components (SCC algorithm)
	void analysis_components( Meta *, bool & );

	// lock a mutex
	void lock(instance_t &id_instance, siteid_t offset)
	{
		int rc = 0;

		if (locks != NULL && (rc = pthread_mutex_lock(&(locks[id_instance][offset]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}

	// lock a mutex
	void unlock(instance_t &id_instance, siteid_t offset)
	{
		int rc = 0;

		if (locks != NULL && (rc = pthread_mutex_unlock(&(locks[id_instance][offset]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
};

//
// Name: Sitelink
//
// Description: Class that with calling other class execute siterank ranking
//
// Input:
//
// Return: 
//
class Sitelink
{
	typedef struct _sitelink_t {
		siteid_t	siteid;
		docid_t		weight;
		_sitelink_t	*next;
	} sitelink_t;

	typedef struct {
		siteid_t	siteid;
		docid_t		weight;
	} saved_sitelink_t;

	typedef struct {
		siteid_t		count_site;
		unsigned int	ndests;
		out_link_t		*dests;
		sitelink_t		**links;
		sitelink_t		**revlinks;
		docid_t			*internal_links; // used only inside function 'thread_function_create' to avoid atomic data
	} sitelinkidx_t;

	// need to passing arguments to threads functions
	typedef struct {
		instance_t inst;
		Sitelink *obj;
		sitelink_call_t f; // corrisponde alla chiamata di determinate funzioni fatta da pthread_create
		Storage *lidx; // only for analysis
		Meta *meta; // only for analysis
		Url *url; // only for function 'dump_links_from_sitenames_to_sitename'
		bool use_internal_links;
		bool use_site_size;
		siteid_t siteid;
	} thread_args_t;

	sitelinkidx_t *distributed;
	const char *dirname;
	bool readonly;
	docid_t ndocs;
	siteid_t nsites;
	siteid_t *nactive;
	bool **site_is_active;
	siteid_t **siteid;
	bool **doc_is_ignored;
	siteid_t *nsites_active;
	docid_t *ndocs_total;
	siterank_t *siterank;
	siterank_t *siterankTmp;
	docid_t *count_doc_ok;
	atomic<siteid_t> *in_degree;
	siteid_t *out_degree;
	siteid_t *linearize_order;
	siterank_t *sum_weight;
	siterank_t *sum_siteranks;
	siterank_t *siterank_delta;
	unsigned short **adjacency_list_length;
	docid_t **internal_links; // not used inside function 'thread_function_create'
	pthread_barrier_t *barrier;
	pthread_mutex_t *slocks;
	atomic<internal_long_uint_t> print_winner2;
	instance_t static_random_inst; 
	CBotSort<siterank_t, siteid_t> *sortr;
	CBotSort<siterank_t, siteid_t> *sortt;

	Storage *sidx; // storage of sites links

	// Function required by sl_create (pthread use)
	void *thread_function_create( void * );

	// Function required by sl_load (pthread use)
	void *thread_function_load( void * );

	// Dealloc linked list in multithreads (required by debug functions)
	void sl_unload( void );

	// Function required by sl_unload (pthread use)
	void *thread_function_unload( void * );

	// Dump sitenames that link to single sitename
	void *thread_function_dump_links_from_sitenames_to_sitename( void * );

	// Save on storage sidx
	void sl_save( instance_t & );

	// Dump links for each siteid
	void dump_links( siteid_t &siteid );

	// Dump links for each siteid
	void dump_revlinks( siteid_t &siteid );

	// Reverse outgoing link structure to new incoming link structure (SCC)
	void reverse_structure( instance_t & );

	// Function required by analysis_siterank (pthread use)
	void *thread_function_analysis_siterank( void * );

	// Function to proxy to non-static function
	static void* thread_function_caller( void * );

	// Syncronize threads with barrier
	void sync_threads( pthread_barrier_t * );

	public:

	Sitelink (const char *_X, bool _Y) // ctor
		: distributed (CBALLOC(sitelinkidx_t, NEW, CONF_COLLECTION_DISTRIBUTED)) // Create sitelinkidx structure
		, dirname (_X)
		, readonly (_Y)
		, ndocs (0)
		, nsites (0)
		, nactive (NULL)
		, site_is_active (NULL)
		, siteid (NULL)
		, doc_is_ignored (NULL)
		, nsites_active (NULL)
		, ndocs_total (NULL)
		, siterank (NULL)
		, siterankTmp (NULL)
		, count_doc_ok (NULL)
		, in_degree (NULL)
		, out_degree (NULL)
		, linearize_order (NULL)
		, sum_weight (NULL)
		, sum_siteranks (NULL)
		, siterank_delta (NULL)
		, adjacency_list_length (NULL)
		, internal_links (NULL)
		, barrier (NULL)
		, slocks (NULL)
		, print_winner2 (0)
		, static_random_inst (rand() % CONF_COLLECTION_DISTRIBUTED)
		, sortr (NULL)
		, sidx (NULL)
	{
	}

	~Sitelink () // dtor
	{
		if (distributed != NULL)
		{
			delete [] distributed;
			distributed = NULL;
		}
	}

	// Generate the sitelink index
	void sl_create( Storage *, Meta * );

	// Load on linked list the sitelink index
	void sl_load( Storage *, Meta * );

	// Analyze components (SCC)
	//void analysis_components( Meta * );

	// lock a mutex
	void lock(instance_t &id_instance, pthread_mutex_t *locks)
	{
		int rc = 0;

		if (locks != NULL && (rc = pthread_mutex_lock(&locks[id_instance])) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}

	// lock a mutex
	void unlock(instance_t &id_instance, pthread_mutex_t *locks)
	{
		int rc = 0;

		if (locks != NULL && (rc = pthread_mutex_unlock(&locks[id_instance])) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}

	// Dump incoming links to sitename
	void dump_links_from_sitenames_to_sitename( Url *, siteid_t );

	// Dump outgoing link from sitename
	void dump_links_from_sitename_to_others( Url *, siteid_t );

	// Dump structure of sitelink index
	void dump_structure( void );

	// Dump structure of sitelink index
	void dump_revstructure( void );

	// Analyze
	void analysis_siterank( Meta *meta, bool use_internal_links, bool use_site_size, bool linearize );

	friend class SCC;
};

#endif
