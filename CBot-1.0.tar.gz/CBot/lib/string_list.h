/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _STRING_LIST_INCLUDED_
#define _STRING_LIST_INCLUDED_

#include <config.h>

// System libraries

#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>
#include <xmlconf.h>
#include <fstream>

// Local libraries

#include "die.h"
#include "const.h"
#include "cleanup.h"

// Constants

#define MAX_STRING_LIST_LENGTH	(20000)

// Typedefs

typedef struct {
	char *str[MAX_STRING_LIST_LENGTH];
	uint len[MAX_STRING_LIST_LENGTH];
	uint count;
} string_list_t;

// Functions

string_list_t *string_list_create( char *words );
void string_list_free( string_list_t *list );
bool string_list_suffix( string_list_t *list, char *str );

#endif
