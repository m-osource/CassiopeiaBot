/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _PERFHASH_INCLUDED_
#define _PERFHASH_INCLUDED_

#include <config.h>

// System libraries

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

// Local libraries

#include "xmlconf.h"
#include "die.h"
#include "cleanup.h"

// Constants

#define PERFHASH_MAX_WORD_LEN	254
#define PERFHASH_MAX_WORDS		1000
#define PERFHASH_MAX_RETRIES	100

/* The probability of false positives will be 1/255 * 1/(1-SECURITY) */
#define PERFHASH_SECURITY_FACTOR		0.99

// Typedefs

typedef struct {
	unsigned int *table; // i valori di default devono essere impostati a '0'
	char *keywords[(PERFHASH_MAX_WORDS + 1)]; // N.B. l'indirizzo '0' non è utilizzato per inserire i termini
	unsigned int length; // lunghezza della tabella (array) 'table'
	unsigned int count; // numero di parole nell'array 'keywords'
	unsigned int A; // numero casuale necessario per creare il bucket che consente di distribuire gli indirizzi dell'array 'keywords' nella tabella 'table'
	unsigned int B; // numero casuale necessario per creare il bucket da inserire nella tabella 'table' (check_matches == false)
	bool check_matches; // se 'false' viene comparato solo il bucket inserito nella tabella 'table',
						// (N.B. il bucket potrebbe essere duplicato ed esserci falsi positivi).
						// se 'true' le keywords 'puntate' dalla tabella 'table' vengono comparate byte per byte con il termine da cercare
} perfhash_t;

// Functions

void perfhash_create( perfhash_t *, char * );
bool perfhash_check( perfhash_t *, char * );
void perfhash_destroy( perfhash_t * );
void perfhash_dump( perfhash_t * );

void _perfhash_clear_table( perfhash_t * );
void _perfhash_hash( perfhash_t *, char *, unsigned int *, unsigned int * );
bool _perfhash_try_parameters( perfhash_t *, char *, unsigned int );

#endif
