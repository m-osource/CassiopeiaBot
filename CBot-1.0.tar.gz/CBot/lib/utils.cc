/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "utils.h"

#define IS_MULTI_BYTE_SEQ(c)  (128 <= c && c <= 191)

static char cbot_progname[MAX_STR_LEN];

//
// Name: tokenizeToMap
//
// Description:
//   Split a string in tokens, save all tokens as keys in a map
//   The values will be boolean true
//
// Input:
//   str - String to tokenize
//
// Output:
//   theMap - Output map
//

void tokenizeToMap(char *str, map<string,bool> &theMap) {
    if( str==NULL ) {
        return;
    }

    uint element_count = 0;

    char *s = strtok(str,CONF_LIST_SEPARATOR);
    while(s != NULL) {
        theMap[s] = true;
	element_count++;
        cerr << s << ", ";
        s = strtok(NULL,CONF_LIST_SEPARATOR);
    }

    return;
}

// 
// Name: tokenizeToTable
//
// Description:
//   Split a string into tokens, save all tokens in a table
//
// Input:
//   str - String to tokenize
//
// Output:
//   nvars - the number of vars
//
// Return:
//   a pointer to the table
//
char **tokenizeToTable( char *str, int *ntokens_out ) {
	// Copy the string, to avoid changing it
	char *token_cpy = NULL;
	char str_cpy[MAX_STR_LEN];
	strcpy( str_cpy, str );

	// Table with tokens
	char **table	= (char **)malloc(sizeof(char *) * MAX_TOKENS);

	// Iterate through the copy

	int ntokens   = 0;
	char *token = strtok( str_cpy, CONF_LIST_SEPARATOR );
	while( token != NULL ) {
		size_t tlen = strlen(token);
		table[ntokens] = (char *)malloc((tlen + 1) * sizeof(char));
		assert( table[ntokens] != NULL );
		strncpy(table[ntokens], token, tlen);
		table[ntokens][tlen] = '\0';
		ntokens++;
		free (token_cpy);
		token			= strtok( NULL, CONF_LIST_SEPARATOR );
		assert( ntokens < MAX_TOKENS );
	}

	// Copy the number of variables
	(*ntokens_out)	= ntokens;

	// Return the created table
	return table;
}

//
// Name: tokenizeToRegex
//
// Description:
//   Split a string in tokens, save all tokens as strings
//   to match in a regex
//
// Input:
//   str - String to tokenize
//
// Output:
//   regex - The regular expression
//

void tokenizeToRegex(char *str, regex_t *regex ) {
    if( str==NULL ) {
        return;
    }

	int rc;
	char reg_expression[MAX_STR_LEN];
	reg_expression[0] = '\0';
	uint str_count = 0;

    char *s = strtok(str,CONF_LIST_SEPARATOR);
    while(s != NULL) {
		if( str_count > 0 ) {
			strcat( reg_expression, "|" );
		}
		strcat( reg_expression, s );
        s = strtok(NULL,CONF_LIST_SEPARATOR);
		str_count ++;
    }

	rc = regcomp( regex, reg_expression, REG_EXTENDED|REG_NOSUB );

	if( rc ) {
			char error[MAX_STR_LEN];
			sprintf( error, "Can't compile this regexp: '%s'", reg_expression );
			die( error );
	}

    return;
}


//
// Name: unescape_url_hex_to_char
//
// Description:
//   Convert a two-char hex string into the char it represents.
//
// Input:
//   what - pointer to the char string to be converted
//
char unescape_url_hex_to_char(char *what) {
   register char digit;

   digit = (what[0] >= 'A' ? ((what[0] & 0xdf) - 'A')+10 : (what[0] - '0'));
   digit *= 16;
   digit += (what[1] >= 'A' ? ((what[1] & 0xdf) - 'A')+10 : (what[1] - '0'));
   return(digit);
}

//
// Name: char2hex
//
// Description:
//   Convert a char into the two-char hex string it represents.
//
// Input:
//   dec - the char to be converted
//
// Return:
//   hex string correspondent to the char value
//
string char2hex( char dec )
{
    char dig1 = (dec&0xF0)>>4;
    char dig2 = (dec&0x0F);
    if ( 0<= dig1 && dig1<= 9) dig1+=48;    //0,48inascii
    if (10<= dig1 && dig1<=15) dig1+=65-10; //A,65inascii
    if ( 0<= dig2 && dig2<= 9) dig2+=48;
    if (10<= dig2 && dig2<=15) dig2+=65-10;

    string r;
    r.append( &dig1, 1);
    r.append( &dig2, 1);
    return r;
}



//
// Name: parse_hex_char
//
// Description:
//   Convert a hex char into a value it represents.
//
// Return:
//   the value of the caracter and -1 if it's not a valid char
//
ssize_t parse_hex_char(char character) {
	unsigned char c = toupper(character);

	if (c < '0' || ( c > '9' && c < 'A') || c > 'F'){
		return -1;
	}

	return (c >= 'A' ? (c - 'A')+10 : (c - '0'));
}

//
// Name: parse_hex_string
//
// Description:
//   Convert a hex string into a offt64 it represents.
//
// Return:
//   the number of bytes read
//
ssize_t parse_hex_string(char *what, size_t max_length, off64_t *value, bool *is_quoted_string, bool *is_chunked_extension) {
	unsigned int i = 0;

	cerr << "caracteres a serem parseados:" << what[0] << what[1] << what[2] << what[3] << what[4] << what[5] << endl;

	while (i < max_length){
		unsigned char c = toupper(what[i]);
		if (c < '0' || ( c > '9' && c < 'A') || c > 'F' || *is_chunked_extension == true){
			*is_chunked_extension = true;
			while ((c != '\r' || *is_quoted_string == true ) && i < max_length){
				if (c == '\"')
					*is_quoted_string =!*is_quoted_string;
				else if (*is_quoted_string && c == '\\')
					i++;
				i++;
			}

			if (c == '\r'){
				*is_chunked_extension = false;
			} else


			return i;
		}
		//cerr << c;
		*value *= 16;
		*value += (c >= 'A' ? (c - 'A')+10 : (c - '0'));
		i++;
	}
	return i;
}

//
// Name: unescape_url
//
// Description:
//   Reduce any %xx escape sequences to the characters they represent
//   Fixed from NCSA HTTPD's example programs
//
// Input:
//   url - with escapes (e.g.: 'www/%7ejsmith')
//
// Output
//   url - without escapes (e.g.: 'www/~jsmith' )
//
void unescape_url(char *url) {
    register int x,y;

    for(x=0;url[x];x++)
	if(url[x] == '%')
	    url[x+1] = unescape_url_hex_to_char(&url[x+1]);

    for(x=0,y=0;url[y];++x,++y) {
	if((url[x] = url[y]) == '%') {
	    url[x] = url[y+1];
	    y+=2;
	}
    }
    url[x] = '\0';
}

//
// Name: is_reserved_char
//
// Description:
//   test if a char is considered reserved by rfc 3986
//
// Input:
//   encoded_char - char to be verified.
//
// Return:
//   true if the char is reserved
//   false if it is not.
//
int is_reserved_char(char encoded_char){
	switch (encoded_char){
		case ' ':
		case '%':
		case ':':
		case '/':
		case '?':
		case '#':
		case '[':
		case ']':
		case '@':
		case '!':
		case '$':
		case '&':
		case '\'':
		case '(':
		case ')':
		case '*':
		case '+':
		case ',':
		case ';':
		case '=':
			return true;
	}
	return false;
}



//
// Name: normalize_percent_encoding
//
// Description:
//   convert all characters that are not reserved from percent encoding to its original form.
//
// Input:
//   url - url string to be normalized
//
// Output:
//   url - normalized url
//
void normalize_percent_encoding(char *url) {
    register int i,j;
    bool query = false;

	for (i = 0, j = 0; url[j]; ++i, ++j) {
		if (url[i] == '?') {
			query = true;
		}
		if ((url[i] = url[j]) == '%') {
			if (url[j + 1] != '\0' && url[j + 2] != '\0') {
				url[i] = toupper(url[i]);
				url[i + 1] = toupper(url[i + 1]);
				char encoded_char = unescape_url_hex_to_char(&url[j + 1]);

				if ((unsigned int)encoded_char < 127) // La conversione da exadec. a char avviene solo per determinati caratteri.
				{ // Senza questa modifica, url con determinati valori esadecimali verrebbero elaborati con un ciclo loop infinito...
					if (!is_reserved_char(encoded_char) || (query && encoded_char == '/')){
						url[i] = encoded_char;
						j += 2;
					}
				}
			}
		}
	}
	url[i] = '\0';
}

//
// Name: url_encode
//
// Description:
//   transform all non ASCII characters to percent-encoding.
//
// Input:
//   c - point to a url string to be converted
//
// Output:
//   c - modified string
//
void url_encode(char *c)
{

    string escaped="";
    int max = strlen(c);
    for(int i=0; i<max; i++)
    {

        if ( (0 <= c[i] && c[i] <= 127) ||//ASCII
             (is_reserved_char(c[i]))) {

            escaped.append( &c[i], 1);

        } else if (194 <= (unsigned char) c[i] && (unsigned char) c[i] <= 223) {

        	if (i + 1 < max &&
        			IS_MULTI_BYTE_SEQ((unsigned char)  c[i + 1])){

				escaped.append("%");
				escaped.append( char2hex(c[i]) );//converts char 255 to string "ff"
				escaped.append("%");
				escaped.append( char2hex(c[i + 1]) );//converts char 255 to string "ff"

        	} else {
				escaped.append("%FF%FD");
			}
			i += 1;

        } else if (224 <= (unsigned char) c[i] && (unsigned char) c[i] <= 239){

        	if 	(i + 2 < max &&
        			IS_MULTI_BYTE_SEQ((unsigned char) c[i + 1]) &&
        			IS_MULTI_BYTE_SEQ((unsigned char) c[i + 2])){

        		escaped.append("%");
				escaped.append( char2hex(c[i]) );//converts char 255 to string "ff"
				escaped.append("%");
				escaped.append( char2hex(c[i + 1]) );//converts char 255 to string "ff"
				escaped.append("%");
				escaped.append( char2hex(c[i + 2]) );//converts char 255 to string "ff"

			} else {
    			escaped.append("%FF%FD");
    		}
			i += 2;

		} else if (240 <= (unsigned char) c[i] && (unsigned char) c[i] <= 244) {

			if (i + 3 < max &&
					IS_MULTI_BYTE_SEQ((unsigned char) c[i + 1]) &&
					IS_MULTI_BYTE_SEQ((unsigned char) c[i + 2]) &&
					IS_MULTI_BYTE_SEQ((unsigned char) c[i + 3])){

				escaped.append("%");
				escaped.append( char2hex(c[i]) );//converts char 255 to string "ff"
				escaped.append("%");
				escaped.append( char2hex(c[i + 1]) );//converts char 255 to string "ff"
				escaped.append("%");
				escaped.append( char2hex(c[i + 2]) );//converts char 255 to string "ff"
				escaped.append("%");
				escaped.append( char2hex(c[i + 3]) );//converts char 255 to string "ff"
			} else {
				escaped.append("%FF%FD");
			}
			i += 3;

		} else {
			cout << char2hex(c[i]) << endl;
			escaped.append("%FF%FD");
		}

    }
    char str_aux [MAX_STR_LEN * 3];
    strcpy(str_aux, escaped.c_str());
    if (strlen(str_aux) > MAX_STR_LEN);
    str_aux[MAX_STR_LEN - 1] = '\0';
    strcpy(c, str_aux);
}


//
// Name: has_nonprintable_character
//
// Description:
//   Check for non printable characters, using the isprint() macro
//
// Input:
//   str - a string to check
//
// Return:
//   true iff str has at least 1 non-printable character
//

bool has_nonprintable_characters( char *str ) {
	assert( str != NULL );
	size_t len	= strlen(str);
	assert( len < MAX_STR_LEN );

	for( size_t i=0; i<len; i++ ) {
		if( ! isprint(str[i]) ) {
			return true;
		}
	}

	return false;
}

//
// Name: timestamp
//
// Description:
//   Generates a timestamp string, useful for naming
//   directories. Its resolution is up to the hour
//
// Output:
//   str - the string containing the timestamp
//

void timestamp( char *str ) {
	assert( str != NULL );
	time_t timevalue    = time(NULL);
	struct tm *timestruct   = localtime(&(timevalue));

	strftime( str, MAX_STR_LEN, "%Y%m%d_%Hh", timestruct );
}

//
// Name: createdir
//
// Description:
//   Tries to create a directory, die if fails, skip if exists
//
// Input:
//   dirname - the directory name
//

void createdir( const char *dirname ) {
	int sysrc = mkdir( dirname, 0777 );
	if( sysrc != 0 && errno != EEXIST ) {
		perror( dirname );
		die( "Failed to create directory" );
	}
}

//
// Name: replace_all
//
// Description:
//   Replaces occurences of a string in another
//
// Input:
//   str - the original string
//   pat - the string to search
//   rep - the new string
//

void replace_all( char *str, const char *pat, const char *rep ) {
	assert( str != NULL );
	assert( pat != NULL );
	assert( rep != NULL );

	assert( strlen(pat) > 0 );

	char *start;
	char copy[MAX_STR_LEN];

	while( (start = strstr( str, pat )) ) {

		// Copy the first part
		if( start != str ) {
			strncpy( copy, str, start - str );
		}

		copy[start-str]		= '\0';

		// Copy the replacement
		strcat( copy, rep );

		// Copy the rest
		strcat( copy, start + strlen(pat) );

		// Copy back to the string
		strcpy( str, copy );
	}
}

//
// Name: str_handler
//
// Description: Convert input string of byte/multibyte UPPER chars to byte/multibyte LOWER chars and exclude NON alpha characters from start and end of string
//
// Input: string of byte/multibyte chars
// boolean str_tolower indicating whether it is necessary convert to lower string
//
// Return: pointer to structure str_handler_t (if 'have_noalpha == true' or input string is invalid)
//
str_handler_t *str_handler(const char *mbsinput, bool str_tolower)
{
	str_handler_t *out = CBALLOC(str_handler_t, MALLOC, 1);
	out->handled = NULL;
	out->mbslen = 0;
	out->wcslen = 0;
	out->have_noalpha = false;
	
	char *mbsoutput = NULL;
	bool have_multibyte_char = false;
	size_t mbsinputlen = 0;

	const char *c = mbsinput;

	// Get size of input string and check if it contain multibyte char
	while(mbsinput[mbsinputlen] != '\0')
	{
		if (have_multibyte_char == false &&
			(IS_MULTI_BYTE_SEQ((unsigned char) c[mbsinputlen])) == true)
			have_multibyte_char = true;

		mbsinputlen++; // Number of bytes characters in source
	}

	if (mbsinputlen == 0)
		return out;

	if (have_multibyte_char == true)
	{ // Input string contain multibyte characters and will be converted to other multibyte characters with ONLY output characters
		wchar_t *wcs;       /* Pointer to converted wide character string */
		mbstate_t *mbs = (mbstate_t *) calloc (1, sizeof(mbstate_t)); // need for no data race

		if ( !mbsinit(mbs) )
			memset (mbs,0,sizeof(&mbs));  /* set to initial state */

		/* Calculate the length required to hold multibytesequence converted to a wide character string */
		out->wcslen = mbsrtowcs (NULL, &mbsinput, 0, mbs); // :-) no data race

		// Invalid multibytesequence
		if (out->wcslen < (size_t)1 || out->wcslen == (size_t)ULONG_MAX)
		{
			free(mbs);
			return out;
		}

		// Allocate wide character string of the desired size.  Add 1 to allow for terminating null wide character (L'\0').
		wcs = (wchar_t *) calloc ((out->wcslen + 1), sizeof(wchar_t));

		if (wcs == NULL)
		{
			free(mbs);
			return out;
		}

		if ( !mbsinit(mbs) )
			memset (mbs,0,sizeof(&mbs));  /* set to initial state */

		// Convert the multibyte character string in str to a wide character string
		if (mbsrtowcs(wcs, &mbsinput, (out->wcslen + 1), mbs) < (size_t)1)
		{
			free(mbs);
			free(wcs);
			return out;
		}

		size_t o = 0;

		for (o = 0; o < out->wcslen; o++)
			if (iswalpha(wcs[o]))
				break;

		out->wcslen -= o;

		wchar_t *str_cleared = (wchar_t *) calloc ((out->wcslen + 1), sizeof(wchar_t));

		if (str_cleared == NULL)
		{
			free(mbs);
			free(wcs);
			return out;
		}

		wcsncpy(str_cleared, &(wcs[o]), out->wcslen); // eventuali caratteri non alfabetici inizio stringa rimossi

		str_cleared[out->wcslen] = L'\0';

		for (; out->wcslen > 0; out->wcslen--)
			if (iswalpha(str_cleared[(out->wcslen - 1)]))
				break;

		str_cleared[out->wcslen] = L'\0'; // eventuali caratteri non alfabetici fine stringa rimossi

		// Allocate wide character string of the desired size.  Add 1 to allow for terminating null wide character (L'\0').
		wchar_t *wcsoutput = (wchar_t *) calloc ((out->wcslen + 1), sizeof(wchar_t));
		wchar_t *p_wcsoutput = wcsoutput;

		if (wcsoutput == NULL)
		{
			free(str_cleared);
			free(mbs);
			free(wcs);
			return out;
		}

		if (str_tolower == true)
		{
			for (size_t i = 0; i < out->wcslen; i++)
			{
				if (out->have_noalpha == false)
				{
					if (! iswalpha(str_cleared[i]))
					{
						out->have_noalpha = true; // la string contiene caratteri non alphabetici all'interno, dunque lo stemming non sarà applicabile
						wcsoutput[i] = str_cleared[i];
					}
					else
					{
						if (iswupper(str_cleared[i]))
							wcsoutput[i] = towlower(str_cleared[i]);
						else
							wcsoutput[i] = str_cleared[i];
					}
				}
				else
				{
					if (! iswalpha(str_cleared[i])) // la stringa contiene troppi caratteri NON alfabetici dunque potrebbe non essere una parola 'valida'
					{
						free(p_wcsoutput);
						free(str_cleared);
						free(mbs);
						free(wcs);
						return out;
					}
					else
					{
						if (iswupper(str_cleared[i]))
							wcsoutput[i] = towlower(str_cleared[i]);
						else
							wcsoutput[i] = str_cleared[i];
					}
				}
			}
		}
		else
		{
			// controlla se la stringa contiene apici, trattini o altri caratteri non alfabetici (massimo uno al suo interno per essere considerata parola 'valida')
			for (size_t i = 0; i < out->wcslen; i++)
			{
				if (out->have_noalpha == false)
				{
					if (! iswalpha(str_cleared[i]))
						out->have_noalpha = true; // la string contiene caratteri non alphabetici all'interno, dunque lo stemming non sarà applicabile
				}
				else
				{
					if (! iswalpha(str_cleared[i])) // la stringa contiene troppi caratteri NON alfabetici dunque potrebbe non essere una parola 'valida'
					{
						free(p_wcsoutput);
						free(str_cleared);
						free(mbs);
						free(wcs);
						return out;
					}
				}

				// copia su stringa di destinazione
				wcsoutput[i] = str_cleared[i];
			}
		}

		wcsoutput[out->wcslen] = L'\0';

		// Prepare new array to store multibyte output char
		//size_t mbsoutputlen = (wcslen(wcsoutput) * sizeof(wchar_t));
		size_t mbsoutputlen = (out->wcslen * sizeof(wchar_t));
		mbsoutput = (char *) malloc ((mbsoutputlen + sizeof(wchar_t)) * sizeof(char));

		if (mbsoutput == NULL)
		{
			free(p_wcsoutput);
			free(str_cleared);
			free(mbs);
			free(wcs);
			return out;
		}

		if ( !mbsinit(mbs) )
			memset (mbs,0,sizeof(&mbs));  /* set to initial state */

		// Convert wide char to multibyte char
		out->mbslen = wcsrtombs(mbsoutput,(const wchar_t **)&wcsoutput,mbsoutputlen, mbs);

		if (out->mbslen < 1)
		{
			free(mbsoutput);
			free(p_wcsoutput);
			free(str_cleared);
			free(mbs);
			free(wcs);
			return out;
		}

		free(p_wcsoutput);
		free(str_cleared);
		free(mbs);
		free(wcs);

		out->handled = mbsoutput;

		return out;

		// Now do some inspection of the classes of the characters in the wide character string annd converted it to output
		//	for (wp = wcs; *wp != 0; wp++)
		//	{
		//		if (iswalpha(*wp) && iswupper(*wp))
		//			*wp = towoutput(*wp);
		//	} // funzione interessante a livello sintattico
	}
	else
	{ // Input string contain ONLY ascii characters (not UTF-8 chars) and will have ONLY output characters
		size_t mbsoutputlen = (mbsinputlen * sizeof(char));
		mbsoutput = (char *) malloc ((mbsoutputlen + 1) * sizeof(char));

		size_t o = 0;

		for (o = 0; o < mbsoutputlen; o++)
			if (isalpha(mbsinput[o]))
				break;

		mbsoutputlen -= o;

		char *str_cleared = (char *) malloc ((mbsoutputlen + 1) * sizeof(char));

		strcpy(str_cleared, &(mbsinput[o])); // eventuali caratteri non alfabetici inizio stringa rimossi

		for (; mbsoutputlen > 0; mbsoutputlen--)
			if (isalpha(str_cleared[(mbsoutputlen - 1)]))
				break;

		str_cleared[mbsoutputlen] = '\0'; // eventuali caratteri non alfabetici fine stringa rimossi

		out->mbslen = mbsoutputlen;

		if (str_tolower == true)
		{
			// controlla se la stringa contiene apici, trattini o altri caratteri non alfabetici (massimo uno al suo interno per essere considerata parola 'valida')
			for (size_t i = 0; i < mbsoutputlen; i++)
			{
				if (out->have_noalpha == false)
				{
					if (! isalpha(str_cleared[i]))
					{
						out->have_noalpha = true; // la string contiene caratteri non alphabetici all'interno, dunque lo stemming non sarà applicabile
						mbsoutput[i] = str_cleared[i];
					}
					else
					{
						if (isupper(str_cleared[i]))
							mbsoutput[i] = tolower(str_cleared[i]);
						else
							mbsoutput[i] = str_cleared[i];
					}
				}
				else
				{
					if (! isalpha(str_cleared[i])) // la stringa contiene troppi caratteri NON alfabetici dunque potrebbe non essere una parola 'valida'
					{
						free(str_cleared);
						free(mbsoutput);
						return out;
					}
					else
					{
						if (isupper(str_cleared[i]))
							mbsoutput[i] = tolower(str_cleared[i]);
						else
							mbsoutput[i] = str_cleared[i];
					}
				}
			}
		}
		else
		{
			// controlla se la stringa contiene apici, trattini o altri caratteri non alfabetici (massimo uno al suo interno per essere considerata parola 'valida')
			for (size_t i = 0; i < mbsoutputlen; i++)
			{
				if (out->have_noalpha == false)
				{
					if (! isalpha(str_cleared[i]))
						out->have_noalpha = true; // la string contiene caratteri non alphabetici all'interno, dunque lo stemming non sarà applicabile
				}
				else
				{
					if (! isalpha(str_cleared[i])) // la stringa contiene troppi caratteri NON alfabetici dunque potrebbe non essere una parola 'valida'
					{
						free(str_cleared);
						free(mbsoutput);
						return out;
					}
				}

				// copia su stringa di destinazione
				mbsoutput[i] = str_cleared[i];
			}
		}

		mbsoutput[mbsoutputlen] = '\0';

		free(str_cleared);

		out->handled = mbsoutput;

		return out;
	}

	return NULL;
}

//
// Name: read_file
//
// Description:
//   Loads a file into a char array, up
//   to MAX_DOC_LEN bytes
//
// Input:
//   filename - the file name
//   buffer - the pointer to output buffer (already memory allocated)
//   len - the size (null char less) of buffer 
//
// Output:
//   buffer - the buffer, filled with the contents of the file
//
//

size_t read_file( char *filename, char *buffer, size_t len ) {
	assert( filename != NULL );
	assert( strlen(filename) > 0 );
	assert( buffer != NULL );

	// Ensure a consistent buffer
	buffer[0]	= '\0';

	// Open file
	FILE *file = fopen64( filename, "r" );
	if( file == NULL ) {
		perror( filename );
		die( "Can't load file" );
	}
	assert( file != NULL );
	size_t bytes = 0;

	// Read the contents of the file, they can be more
	// than MAX_DOC_LEN bytes
	bytes = fread( buffer, 1, len, file );
	assert( bytes <= len );
	fclose( file );

	// Close string
	buffer[bytes] = '\0';

	return bytes;
}

//
// Name: siteToDomain
//
// Description:
//   Estrae da un nome di dominio FQDN il corrispettivo nome di dominio di secondo livello
//
// Input:
//   sitename - il nome di dominio FQDN
//
// Output:
//   puntatore a caratteri sull'array che contiene il dominio di secondo livello
//
//
char *siteToDomain( perfhash_t keep_special, char *sitename ) {
	bool is_italian_domain = false;
	bool is_special_domain = false;
	unsigned short firstpoint = 0;
	unsigned short middlepoint = 0;
	unsigned short lastpoint = 0;

	unsigned short dcount = strlen(sitename);

	char *_domain = (char *) malloc (MAX_DOMAIN_LEN * sizeof(char));

	strncpy(_domain,sitename,dcount); // per sicurezza si crea una copia del nome del sito

	_domain[dcount] = '\0';

	// ricava la posizione dove comincia il dominio di primo livello
	while (dcount > 0 && _domain[--dcount] != '.');

	lastpoint = dcount;

	// verifico se si tratta di un dominio di primo livello italiano
	if (strcmp(&(_domain[lastpoint + 1]),"it") == 0)
		is_italian_domain = true;

	// ricava la posizione dove comincia il dominio di secondo livello
	while (dcount > 0 && _domain[--dcount] != '.');

	if (dcount == 0) // se il dominio contiene un solo punto non occorre procedere nell'elaborazione
		return _domain;

	middlepoint = dcount;

	if (is_italian_domain == true && middlepoint > 0)
	{
		if ((lastpoint - middlepoint - 1) > 2)
		{
			_domain[lastpoint] = '\0'; // per ottenere il 'pezzo' di area puntata relativo all'eventuale dominio speciale

			if( perfhash_check( &(keep_special), &(_domain[(middlepoint + 1)]) ) )
				is_special_domain = true;

			_domain[lastpoint] = '.'; // ripristino il punto in corrispondenza 'lastpoint'
		}
		else if ((lastpoint - middlepoint - 1) == 2)
			is_special_domain = true;
	}

	// ricava la posizione dove comincia il dominio di terzo livello
	while (dcount > 0 && _domain[--dcount] != '.');

	firstpoint = dcount;

	if (is_special_domain == true)
	{
		if (firstpoint > 0)
		{
			char *domainstring = (char *) malloc ((strlen(sitename) - firstpoint) * sizeof(char));

			strcpy(domainstring, (const char*)(&(_domain[firstpoint + 1])));

			free(_domain);

			return domainstring;
		}
		else
			return _domain;
	}

	// char *domainstring = (char *) malloc ((strlen(sitename) - middlepoint) * sizeof(char));
	char *domainstring = CBALLOC(char, MALLOC, ((strlen(sitename) - middlepoint) * sizeof(char)));
	domainstring[0] = ASCII_NUL;

	strcpy(domainstring, (const char*)(&(_domain[middlepoint + 1])));

	free(_domain);

	return domainstring;
}

//
// Name: fqdn_to_domain
//
// Description:
//   Estrae da un nome di dominio FQDN il corrispettivo nome di dominio di secondo livello
//
// Input:
//   sitename - il nome di dominio FQDN
//
// Output:
//   puntatore a caratteri sull'array che contiene il dominio di secondo livello
//
//
void fqdn_to_domain(perfhash_t keep_special, char *fqdn, char *&domain, char *&special_domain)
{
	assert(domain == NULL);
	assert(special_domain == NULL);

	bool is_italian_domain = false;
	bool is_special_domain = false;
	unsigned short firstpoint = 0;
	unsigned short middlepoint = 0;
	unsigned short lastpoint = 0;

	unsigned short dcount = strlen(fqdn);

	// per sicurezza si crea una copia del nome del dominio completo
	char *_fqdn = CBALLOC(char, MALLOC, (dcount + 1));

	_fqdn[0] = ASCII_NUL;

	strncpy(_fqdn,fqdn,dcount);

	_fqdn[dcount] = '\0';

	// ricava la posizione dove comincia il dominio di primo livello
	while (dcount > 0 && _fqdn[--dcount] != '.');

	lastpoint = dcount;

	// verifico se si tratta di un dominio di primo livello italiano
	if (strcmp(&(_fqdn[lastpoint + 1]),"it") == 0)
		is_italian_domain = true;

	// ricava la posizione dove comincia il dominio di secondo livello
	while (dcount > 0 && _fqdn[--dcount] != '.');

	if (dcount == 0) // se il dominio contiene un solo punto non occorre procedere nell'elaborazione
	{
		unsigned short len = strlen(fqdn);

		domain = CBALLOC(char, MALLOC, (len + 1));

		domain[0] = ASCII_NUL;

		strncpy(domain,fqdn,len);

		domain[len] = '\0';

		free(_fqdn);

		return;
	}

	middlepoint = dcount;

	if (is_italian_domain == true)
	{
		if ((lastpoint - middlepoint - 1) > 2)
		{
			_fqdn[lastpoint] = '\0'; // per ottenere il 'pezzo' di area puntata relativo all'eventuale dominio speciale

			if( perfhash_check( &(keep_special), &(_fqdn[(middlepoint + 1)]) ) )
				is_special_domain = true;

			_fqdn[lastpoint] = '.'; // ripristino il punto in corrispondenza 'lastpoint'
		}
		else if ((lastpoint - middlepoint - 1) == 2)
			is_special_domain = true;
	}

	// ricava la posizione dove comincia il dominio di terzo livello
	while (dcount > 0 && _fqdn[--dcount] != '.');

	firstpoint = dcount;

	if (is_special_domain == true)
	{
		if (firstpoint > 0)
		{
			special_domain = CBALLOC(char, MALLOC, ((strlen(_fqdn) - firstpoint) * sizeof(char)));
			special_domain[0] = ASCII_NUL;
			strcpy(special_domain, (const char*)(&(_fqdn[firstpoint + 1])));
		}
		else
		{
			special_domain = CBALLOC(char, MALLOC, ((strlen(fqdn) + 1) * sizeof(char)));
			special_domain[0] = ASCII_NUL;
			strcpy(special_domain, (const char*)(fqdn));
		}
	}

	// the standard second level domain
	domain = CBALLOC(char, MALLOC, ((strlen(fqdn) - middlepoint) * sizeof(char)));
	domain[0] = ASCII_NUL;
	strcpy(domain, (const char*)(&(_fqdn[middlepoint + 1])));

	free(_fqdn);
}

//
// Name logarithm
//
// Description Calcola il logarimo del primo argomento della funzione, con qualsiasi base
//
// Restituisce il risultato del calcolo
//
double logarithm(double x, double base)
{
	double result;

	if (base == 10)
		result = log (x);
	else
		result = log (x) / log (base);

	return result;		
}

//
// Name: cbot_start
//  
// Description:
//   Starts the system, prints a message about this program
//   Reads the configuration file.
//   Changes to the base dir
//
// Input:
//   program_name - this program name
//   

void cbot_start ( const char *program_name )
{
	thread_alarm = THREADS_OK;

	const unsigned char size = 6;
	const char pid_file[size][80] = {"angel", "seeder", "manager", "harvester", "connector", "info-analysis"};

	// Print program banner
	cerr << PACKAGE << " " << VERSION << " " << program_name << endl;

	// Apply the specified locale
	if (setlocale(LC_ALL, "en_US.UTF-8") == NULL) { // oppure en_GB.UTF-8
		perror("setlocale");
		exit(EXIT_FAILURE);
	}

	// Se i programmi sono in scrittura per ciò che concerne metadati, ecc..
	// allora la variabile di sistema TZ deve sempre essere settata su
	// Universal Time Clock
	if (strcmp(program_name,"reset") == 0 ||
		strcmp(program_name,"seeder") == 0 ||
		strcmp(program_name,"manager") == 0 ||
		strcmp(program_name,"harvester") == 0 ||
		strcmp(program_name,"connector") == 0 ||
		strcmp(program_name,"info-analysis") == 0)
		utc_timezone_setup();

	// Read configuration and enable cleanup handler
	cerr << "Load configuration ... ";
	xmlconf_load();

	assert(CONF_COLLECTION_DISTRIBUTED >= 2);
	assert(CONF_COLLECTION_DISTRIBUTED <= ((instance_t)(~0) + 1));
	assert(CONF_COLLECTION_DISTRIBUTED <= sysconf(_SC_NPROCESSORS_ONLN));

	assert(sizeof(siteid_t) <= sizeof(site_hash_t));
	assert(sizeof(docid_t) <= sizeof(doc_hash_t));
	assert(sizeof(docid_t) >= sizeof(siteid_t));

	assert(CONF_COLLECTION_MAXDOMAIN < (CONF_MAX_TWOLEVELDOMAINID / CONF_COLLECTION_DISTRIBUTED));
	assert(CONF_COLLECTION_MAXSITE < ((((siteid_t)(~0)) - CONF_SITE_HASH_RESERVE) / CONF_COLLECTION_DISTRIBUTED));
	assert(CONF_COLLECTION_MAXDOC < ((((docid_t)(~0)) - CONF_DOC_HASH_RESERVE) / CONF_COLLECTION_DISTRIBUTED));

	assert(CONF_COLLECTION_MAXDOMAIN <= CONF_COLLECTION_MAXSITE);
	assert(CONF_COLLECTION_MAXSITE < CONF_COLLECTION_MAXDOC);

	assert(CONF_MANAGER_SCORE_PERIODIC_ENABLED >= 0 && CONF_MANAGER_SCORE_PERIODIC_ENABLED < 2);
	assert(CONF_MANAGER_SCORE_PERIODIC_BEST_MOMENT >= 0 && CONF_MANAGER_SCORE_PERIODIC_BEST_MOMENT < 24);
	assert(CONF_MANAGER_SCORE_PERIODIC_INTERVAL > 0 && CONF_MANAGER_SCORE_PERIODIC_INTERVAL < 29);
	assert(CONF_MANAGER_MINPERIOD_FEEDS_FORBIDDEN < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_FEEDS_UNSUCCESSFUL < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_FEEDS_SUCCESSFUL_BUT_NOT_OK < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_FEEDS_SUCCESSFUL_AND_OK < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_FORBIDDEN < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_UNSUCCESSFUL < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_SUCCESSFUL_BUT_NOT_OK < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_SUCCESSFUL_AND_OK < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_ROBOTS_TXT_VALID < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_ROBOTS_TXT_NOT_VALID < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_ROBOTS_RDF_VALID < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_ROBOTS_RDF_NOT_VALID < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_ROBOTS_XML_VALID < (31536000 * 5)); // inferior at one year in seconds
	assert(CONF_MANAGER_MINPERIOD_ROBOTS_XML_NOT_VALID < (31536000 * 5)); // inferior at one year in seconds
	
	// Change to the base directory
	cerr << "chdir ... ";

	int rc = chdir( CONF_COLLECTION_BASE );

	if (rc)
	{
		perror( CONF_COLLECTION_BASE );
		die( "Couldn't change to the base dir of the collection, please create this directory or check the configuration file" );
	}
	else
		errno = 0;

	// Notice that if you want a core file for examining it
	// you don't want to cleanup_enable()
	cleanup_enable();
	cerr << "done." << endl;

	if (CONF_NFS_ANGELS == 1 || CONF_NFS_ANGELS == 2)
	{
		bool presentation = false;

		// First, checking existance of zombies pid files
		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			struct stat sb;
       		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_RUN, i);
			char pid_filename[MAX_STR_LEN];

			memset(&sb, 0, sizeof(struct stat));
			errno = 0;

			int rc = stat(relative_rem_path, &sb);

			if (rc == -1)
			{
				die("%scbot_start: %s %s. Cannot continue!%s\n", RED, relative_rem_path, cberr(), NOR);

		        free(relative_rem_path);

				break;
			}

			// check for pid angels
			// Note: only remote daemons can remove pid files of angels
			if (CONF_NFS_ANGELS == 2)
			{
				bool have_angels = false;

				wait_angels:

				// checking for angels first
				memset(&sb, 0, sizeof(struct stat));
				pid_filename[0] = '\0';
				sprintf(pid_filename, "%s/angel.cpn", relative_rem_path);
				errno = 0;
				rc = stat(pid_filename, &sb);

				if (rc == 0)
				{
					if (presentation == false)
					{
						cerr << endl << RED << "Waiting for notice that standalone daemons have stopped works: " << NOR;
						presentation = true;
					}

					cerr << '.';

					have_angels = true;
				}

				if (have_angels == true)
				{
					sleep(5);
					have_angels = false;
					goto wait_angels;
				}

				if (presentation == true && i == (CONF_COLLECTION_DISTRIBUTED - 1))
				{
					cerr << GRE << " done." << NOR << endl;
					sleep(2);
					cerr << GRE << "Go ahead!" << NOR << endl;
				}
			}

			for (unsigned char s = 0; s < size; s++)
			{
				memset(&sb, 0, sizeof(struct stat));
				pid_filename[0] = '\0';
				sprintf(pid_filename, "%s/%s.pid", relative_rem_path, pid_file[s]);
				errno = 0;
				int rc = stat(pid_filename, &sb);

				if (rc == 0)
				{
					die("%scbot_start: A %s process was terminated with errors! (see inside %s). Cannot continue!%s\n", RED, pid_file[s], relative_rem_path, NOR);
					break;
				}
			}

    	    free(relative_rem_path);

			if (thread_alarm != THREADS_OK)
				break;
		}
	}

	if (thread_alarm != THREADS_OK) exit(EXIT_FAILURE);

	if (CONF_NFS_ANGELS == 1 || CONF_NFS_ANGELS == 2)
	{
		// Make PID files for each distributed storage
		if (strcmp(program_name,"seeder") == 0 ||
			strcmp(program_name,"manager") == 0 ||
			strcmp(program_name,"harvester") == 0 ||
			strcmp(program_name,"connector") == 0 ||
			strcmp(program_name,"info-analysis") == 0)
		{
			pid_t _pid = getpid();

			// Making pid files
			for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			{
				char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_RUN, i);
				char pid_filename[MAX_STR_LEN];

				pid_filename[0] = '\0';
				sprintf(pid_filename, "%s/%s.pid", relative_rem_path, program_name);
				errno = 0;

				FILE *pid_file = fopen(pid_filename, "w");

				if (errno != 0)
				{
					die("cbot_start: couldn't create %s.pid, %s on %s\n", program_name, cberr(), relative_rem_path);

			        free(relative_rem_path);

					break;
				}

				assert(pid_file != NULL);

				// protect file from reading from other programs during this writing
				if (file_lock(pid_file, false) == true)
				{
					char pid[MAX_STR_LEN];
					sprintf(pid, "%llu", (unsigned long long int)_pid);

					size_t written = fwrite(pid, sizeof(char), strlen(pid), pid_file);

					if (errno != 0)
						die("cbot_start: couldn't write file %s on %s\n", cberr(), pid_filename);

					assert(written == (size_t)(strlen(pid)));
				}
				else
					die("cbot_start: couldn't not lock file %s\n", pid_filename);

				if (file_unlock(pid_file) == false)
					die("cbot_start: couldn't not unlock file %s\n", pid_filename);

				assert(fclose(pid_file) == 0);

				if (CONF_NFS_ANGELS == 2)
				{
					pid_filename[0] = '\0';
					sprintf(pid_filename, "%s/angel.cpn", relative_rem_path);
					errno = 0;
					pid_file = fopen(pid_filename, "w");

					if (errno != 0)
					{
						die("cbot_start: couldn't create angel.cpn, %s on %s\n", cberr(), relative_rem_path);

				        free(relative_rem_path);

						break;
					}

					assert(pid_file != NULL);

					// protect file from reading from other programs during this writing
					if (file_lock(pid_file, false) == true)
					{	// writing Calling Program Name into angel.cpn
						size_t written = fwrite(program_name, sizeof(char), strlen(program_name), pid_file);

						if (errno != 0)
							die("cbot_start: couldn't write file %s on %s/angel.cpn\n", cberr(), relative_rem_path);

						assert(written == (size_t)(strlen(program_name)));
					}
					else
						die("cbot_start: couldn't not lock file %s\n", pid_filename);

					if (file_unlock(pid_file) == false)
						die("cbot_start: couldn't not unlock file %s\n", pid_filename);

					assert(fclose(pid_file) == 0);
				}

		        free(relative_rem_path);
			}
		}
	}

	if (thread_alarm != THREADS_OK) exit(EXIT_FAILURE);

	// Write to syslog
	openlog( PACKAGE, LOG_PERROR|LOG_PID, LOG_USER );
	syslog( LOG_INFO, "%s start", program_name );

	// Initialize a thread-safe stdout, stderr, stdlog
	unsigned char *sp_counts = CBALLOC(unsigned char, CALLOC, CONF_COLLECTION_DISTRIBUTED);
    sp = new SemaphorePrint (sp_counts);
    assert(sp != NULL);

	symshown = CBALLOC(bool, MALLOC, 1);
	*(symshown) = false;

	// setup stdout,stderr,stdlog mutexes
	console_lock = CBALLOC(pthread_mutex_t, MALLOC, 1);
	*(console_lock) = PTHREAD_MUTEX_INITIALIZER;

	cbot_progname[0] = '\0';
	strcpy(cbot_progname, program_name);
}

//
// Name: cbot_stop
//
// Description:
//   Closes syslog, ends the program
//
// Input:
//   code - exit code

void cbot_stop(int code)
{
	// free all resource stdout,stderr,stdlog
	if (sp)
	{
		delete sp;
		sp = NULL;
	}

	int rc = 0;

	if	(code == 0)
		cerr << "Finish with ... ";
	else
	{
    	cerr << RED << "*** Emergency cleanup ... " << NOR << endl;;
		cerr << "Exit, code=" << code << " ... ";
	}

	// Clean up
	cleanup_disable();
	cleanup();
	cerr << "done." << endl;

	if (thread_alarm != THREADS_OK && code == 0)
		code = 1;

	// Destroy print mutex
	if (console_lock && (rc = pthread_mutex_destroy(console_lock)) != 0)
		fprintf(stderr, "cbot_stop: error destroying stdout mutexes %s", strerror(rc));

	if (symshown)
	{
		free(symshown);
		symshown = NULL;
	}

	if (console_lock)
	{
		free(console_lock);
		console_lock = NULL;
	}

	// Write to syslog
	if (code == 0)
		syslog( LOG_INFO, "normal stop" );
	else
		syslog( LOG_WARNING, "%scbot-%s: abnormal stop, exit(%d)%s", RED, cbot_progname, code, NOR );

	closelog();

	if (code == 0 && (CONF_NFS_ANGELS == 1 || CONF_NFS_ANGELS == 2))
	{
		// Delete PID files for each distributed storage
		if (strcmp(cbot_progname,"seeder") == 0 ||
			strcmp(cbot_progname,"manager") == 0 ||
			strcmp(cbot_progname,"harvester") == 0 ||
			strcmp(cbot_progname,"connector") == 0 ||
			strcmp(cbot_progname,"analysis") == 0)
		{
			// Delete pid files
			for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			{
				char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_RUN, i);
				char pid_filename[MAX_STR_LEN];
				pid_filename[0] = '\0';
				sprintf(pid_filename, "%s/%s.pid", relative_rem_path, cbot_progname);

				int rc = unlink(pid_filename);

				if (rc != 0 && errno != ENOENT)
				{
					fprintf(stderr, "cbot_stop: couldn't delete file %s on %s\n", cberr(), pid_filename);
					code = 1;
				}

				free(relative_rem_path);
    		}
		}
	}

	// Exit
	exit(code);
}

//
// Name: cbot_stats
//
// Description:
//   Closes syslog, ends the program
//
// Input:
//   code - exit code

bool cbot_stats(bool readonly)
{
	int rc = 0;
	char filename[MAX_STR_LEN];
	struct stat64 statbuf;
	time_t last_ranking;
	crawler_stats_t crawler_stats;
	int crawler_stats_fd = 0;

	struct flock lock;
	lock.l_whence = SEEK_SET;
	lock.l_start = (off_t)0;
	lock.l_len = (size_t)0;

	// Go ahead to sites .... Create or open filename
	sprintf(filename, "/tmp/%s", CRAWLER_FILENAME_STATS);

	// check if ranking interval was passed
	if (stat64(filename, &statbuf) == 0)
	{	// Verify file size
		if ((internal_long_uint_t)(statbuf.st_size) != sizeof(crawler_stats_t))
		{
			if (strcmp(cbot_progname,"info-shell") == 0)
				return false;

			// Create an empty file
			crawler_stats_fd = open64(filename, O_RDWR|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

			if (crawler_stats_fd == -1 && errno != 0)
				die("cbot-stats: couldn't open %s on %s\n", cberr(), filename);

			memset(&crawler_stats, 0, sizeof(crawler_stats_t));

			// crawler_stats.last_ranking = time(NULL);

			if (fcntl(crawler_stats_fd, F_GETFL) == -1)
				die("cbot-stats: stats do not have a valid file descriptor %s on %s\n", cberr(), filename);

			lock.l_type = F_WRLCK;

			if (fcntl(crawler_stats_fd, F_SETLKW, &lock) == -1)
				die("cbot-stats: error on file descriptor %s on %s\n", cberr(), filename);

			if (pwrite(crawler_stats_fd, &crawler_stats, sizeof(crawler_stats_t), 0) != (ssize_t)sizeof(crawler_stats_t))
				die("cbot-stats: error writing file descriptor %s on %s\n", cberr(), filename);

			lock.l_type = F_UNLCK;

			// unlock
			if (fcntl(crawler_stats_fd, F_SETLK, &lock) == -1)
				die("cbot-stats: error on file descriptor %s on %s\n", cberr(), filename);

			if (close(crawler_stats_fd) != 0)
				die("cbot-stats: error closing stats file descriptor %s\n", cberr());

			crawler_stats_fd = 0;

			return true;
		}
		else
		{
			// Read file
			if (strcmp(cbot_progname,"info-shell") == 0)
				crawler_stats_fd = open64(filename, O_RDONLY); // Open read only
			else
				crawler_stats_fd = open64(filename, O_RDWR|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

			if (crawler_stats_fd == -1 && errno != 0)
				die("cbot-stats: couldn't open %s on %s\n", cberr(), filename);

			if (fcntl(crawler_stats_fd, F_GETFL) == -1)
				die("cbot-stats: do not have a valid file descriptor %s on %s\n", cberr(), filename);

			if (strcmp(cbot_progname,"info-shell") == 0)
				lock.l_type = F_RDLCK;
			else
				lock.l_type = F_WRLCK;

			// wait for lock
			if (fcntl(crawler_stats_fd, F_SETLKW, &lock) == -1)
				die("cbot-stats: error on file descriptor %s on %s\n", cberr(), filename);

			// Read
			if (pread(crawler_stats_fd, &(crawler_stats), sizeof(crawler_stats_t), (off_t)0) != sizeof(crawler_stats_t))
				die("cbot-stats: couldn't read %s on %s\n", cberr(), filename);
			//if (pread(crawler_stats_fd, &(crawler_stats), sizeof(crawler_stats_t), (off_t)0) != sizeof(crawler_stats_t));
			//	die("cbot-stats: couldn't read %s on %s\n", cberr(), filename);

//sleep(60);
			lock.l_type = F_UNLCK;

			if (strcmp(cbot_progname,"manager") == 0)
			{
				if (CONF_MANAGER_SCORE_PERIODIC_ENABLED)
				{
					time_t ranking_lasttime = crawler_stats.last_ranking;
					time_t now = time(NULL);
					struct tm *ranking_lasttm = localtime(&ranking_lasttime);

					ranking_lasttm->tm_hour = CONF_MANAGER_SCORE_PERIODIC_BEST_MOMENT;
					ranking_lasttm->tm_min = 0;
					ranking_lasttm->tm_sec = 0;

					// if (difftime(now,mktime(ranking_lasttm)) > (CONF_MANAGER_SCORE_PERIODIC_INTERVAL)) // used for testing
					if (difftime(now,mktime(ranking_lasttm)) > (CONF_MANAGER_SCORE_PERIODIC_INTERVAL * 86400))
					{
						crawler_stats.last_ranking = now;

						if (pwrite(crawler_stats_fd, &crawler_stats, sizeof(crawler_stats_t), 0) != (ssize_t)sizeof(crawler_stats_t))
							die("cbot-stats: error writing file descriptor %s on %s\n", cberr(), filename);

						// unlock
						if (fcntl(crawler_stats_fd, F_SETLK, &lock) == -1)
							die("cbot-stats: error on file descriptor %s on %s\n", cberr(), filename);

						if (close(crawler_stats_fd) != 0)
							die("cbot-stats: error closing stats file descriptor %s\n", cberr());

						crawler_stats_fd = 0;

						return true;
					}
				}
			}
			else if (strcmp(cbot_progname,"info-shell") == 0)
			{
				if (CONF_MANAGER_SCORE_PERIODIC_ENABLED)
				{
					time_t ranking_lasttime = crawler_stats.last_ranking;
					ranking_lasttime += (time_t)(CONF_MANAGER_SCORE_PERIODIC_INTERVAL * 86400);
					struct tm *ranking_lasttm = localtime(&ranking_lasttime);

					ranking_lasttm->tm_hour = CONF_MANAGER_SCORE_PERIODIC_BEST_MOMENT;
					ranking_lasttm->tm_min = 0;
					ranking_lasttm->tm_sec = 0;

					cerr << GRE << "Next document's score ranking will be executed at " << ranking_lasttm->tm_mday << '/' << (ranking_lasttm->tm_mon + 1) << '/' << (ranking_lasttm->tm_year + 1900) << " after the " << CONF_MANAGER_SCORE_PERIODIC_BEST_MOMENT << " o'clock." << NOR << endl;
				}
			}

			// unlock
			if (fcntl(crawler_stats_fd, F_SETLK, &lock) == -1)
				die("cbot-stats: error on file descriptor %s on %s\n", cberr(), filename);

			if (close(crawler_stats_fd) != 0)
				die("cbot-stats: error closing stats file descriptor %s\n", cberr());

			crawler_stats_fd = 0;
		}
	}
	else if (strcmp(cbot_progname,"info-shell") != 0)
	{	// Create file
		crawler_stats_fd = open64(filename, O_RDWR|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (crawler_stats_fd == -1 && errno != 0)
			die("cbot-stats: couldn't open %s on %s\n", cberr(), filename);

		memset(&crawler_stats, 0, sizeof(crawler_stats_t));

		crawler_stats.last_ranking = time(NULL);

		if (fcntl(crawler_stats_fd, F_GETFL) == -1)
			die("cbot-stats: do not have a valid file descriptor %s on %s\n", cberr(), filename);

		lock.l_type = F_WRLCK;

		// wait for lock
		if (fcntl(crawler_stats_fd, F_SETLKW, &lock) == -1)
			die("cbot-stats: error on file descriptor %s on %s\n", cberr(), filename);

		if (pwrite(crawler_stats_fd, &crawler_stats, sizeof(crawler_stats_t), 0) != (ssize_t)sizeof(crawler_stats_t))
			die("cbot-stats: error writing file descriptor %s on %s\n", cberr(), filename);

		lock.l_type = F_UNLCK;

		// unlock
		if (fcntl(crawler_stats_fd, F_SETLK, &lock) == -1)
			die("cbot-stats: error on file descriptor %s on %s\n", cberr(), filename);

		if (close(crawler_stats_fd) != 0)
			die("cbot-stats: error closing stats file descriptor %s\n", cberr());

		crawler_stats_fd = 0;

		return true;
	}

	return false;
}

//
// Name: timer_delta
// 
// Description:
//   Gets the difference in seconds between two timevals
//
// Input:
//   tv1, tv2 - two times
//
// Returns:
//   tv2 - tv1
//

float timer_delta(struct timeval *tv1, struct timeval *tv2)
{
	return ((tv1->tv_sec - tv2->tv_sec) + ((tv1->tv_usec - tv2->tv_usec) / (float)1000000.0));
}

//
// Name: utc_timezone_setup
//
// Description: check if system timezone environment is setting to UTC and if not, force setting to UTC
//
// Arguments: none
//
// Return: none
//
void utc_timezone_setup (void)
{
	char *local_tz = getenv( "TZ" );

	// If not set to UTC. force setting to Universal Time Clock
	if (local_tz == NULL)
	{
		setenv( "TZ", "UTC", 1 );
		tzset();
	}
	else if ((strlen(local_tz) != 3 || strncasecmp( local_tz, "UTC", 3) != 0))
	{
		setenv( "TZ", "UTC", 1 );
		tzset();

		char *_local_tz = getenv( "TZ" );

		if ((strlen(_local_tz) != 3 || strncasecmp( _local_tz, "UTC", 3) != 0))
			die("Can't setup user TZ environment");
	}
}

//
// Name: get_time
//
// Description: Giving a string date like "Wed, 30 Mar 1966 09:00:00 CET" convert to UTC time_t format consider also TimeZone of string
// N.B. year format MUST be always %Y. In this mode function can handle INDISTINCTLY years with four digits or two digits
//
// Arguments: string date, string format like in 'strptime' es: "%a, %d %b %Y %H:%M:%S" (N.B. Timezone must be excluded in format string)
//
// Return: the value of type time_t that represents the local time if true else, one second before 'January 1st 1970 at midnight GMT' as type time_t
//
time_t get_time(const char *datastr, const char *format)
{
#define MIN_DATE_LEN 11
#define EPOCH_YEAR 1970
#define BASE_YEAR 1900
#define THIRD_MILLENIUM 2000
#define HOUR(x) ((x) * 3600)

/* Tokens.  */
#define DSTOFFSET 3600
#define TIMEOFFSET 0

/* An entry in the lexical lookup table.  */
typedef struct
{
  char const *name;
  int type;
  int value;
} table;

/* The universal time zone table.  These labels can be used even for
   time stamps that would not otherwise be valid, e.g., GMT time
   stamps in London during summer.  */
static table const universal_timezone_table[] =
{
  { "GMT",      TIMEOFFSET,     HOUR ( 0) }, /* Greenwich Mean */
  { "UT",       TIMEOFFSET,     HOUR ( 0) }, /* Universal (Coordinated) */
  { "UTC",      TIMEOFFSET,     HOUR ( 0) },
  { NULL, 0, 0 }
};

/* The time zone table.  This table is necessarily incomplete, as time
   zone abbreviations are ambiguous; e.g. Australians interpret "EST"
   as Eastern time in Australia, not as US Eastern Standard Time.
   You cannot rely on parse_datetime to handle arbitrary time zone
   abbreviations; use numeric abbreviations like "-0500" instead.  */
static table const timezone_table[] =
{
  { "WET",      TIMEOFFSET,     HOUR ( 0) }, /* Western European */
  { "WEST",     DSTOFFSET,      HOUR ( 0) }, /* Western European Summer */
  { "BST",      DSTOFFSET,      HOUR ( 0) }, /* British Summer */
  { "ART",      TIMEOFFSET,    -HOUR ( 3) }, /* Argentina */
  { "BRT",      TIMEOFFSET,    -HOUR ( 3) }, /* Brazil */
  { "BRST",     DSTOFFSET,     -HOUR ( 3) }, /* Brazil Summer */
  { "NST",      TIMEOFFSET,   -(HOUR ( 3) + 30) },   /* Newfoundland Standard */
  { "NDT",      DSTOFFSET,    -(HOUR ( 3) + 30) },   /* Newfoundland Daylight */
  { "AST",      TIMEOFFSET,    -HOUR ( 4) }, /* Atlantic Standard */
  { "ADT",      DSTOFFSET,     -HOUR ( 4) }, /* Atlantic Daylight */
  { "CLT",      TIMEOFFSET,    -HOUR ( 4) }, /* Chile */
  { "CLST",     DSTOFFSET,     -HOUR ( 4) }, /* Chile Summer */
  { "EST",      TIMEOFFSET,    -HOUR ( 5) }, /* Eastern Standard */
  { "EDT",      DSTOFFSET,     -HOUR ( 5) }, /* Eastern Daylight */
  { "CST",      TIMEOFFSET,    -HOUR ( 6) }, /* Central Standard */
  { "CDT",      DSTOFFSET,     -HOUR ( 6) }, /* Central Daylight */
  { "MST",      TIMEOFFSET,    -HOUR ( 7) }, /* Mountain Standard */
  { "MDT",      DSTOFFSET,     -HOUR ( 7) }, /* Mountain Daylight */
  { "PST",      TIMEOFFSET,    -HOUR ( 8) }, /* Pacific Standard */
  { "PDT",      DSTOFFSET,     -HOUR ( 8) }, /* Pacific Daylight */
  { "AKST",     TIMEOFFSET,    -HOUR ( 9) }, /* Alaska Standard */
  { "AKDT",     DSTOFFSET,     -HOUR ( 9) }, /* Alaska Daylight */
  { "HST",      TIMEOFFSET,    -HOUR (10) }, /* Hawaii Standard */
  { "HAST",     TIMEOFFSET,    -HOUR (10) }, /* Hawaii-Aleutian Standard */
  { "HADT",     DSTOFFSET,     -HOUR (10) }, /* Hawaii-Aleutian Daylight */
  { "SST",      TIMEOFFSET,    -HOUR (12) }, /* Samoa Standard */
  { "WAT",      TIMEOFFSET,     HOUR ( 1) }, /* West Africa */
  { "CET",      TIMEOFFSET,     HOUR ( 1) }, /* Central European */
  { "CEST",     DSTOFFSET,      HOUR ( 1) }, /* Central European Summer */
  { "MET",      TIMEOFFSET,     HOUR ( 1) }, /* Middle European */
  { "MEZ",      TIMEOFFSET,     HOUR ( 1) }, /* Middle European */
  { "MEST",     DSTOFFSET,      HOUR ( 1) }, /* Middle European Summer */
  { "MESZ",     DSTOFFSET,      HOUR ( 1) }, /* Middle European Summer */
  { "EET",      TIMEOFFSET,     HOUR ( 2) }, /* Eastern European */
  { "EEST",     DSTOFFSET,      HOUR ( 2) }, /* Eastern European Summer */
  { "CAT",      TIMEOFFSET,     HOUR ( 2) }, /* Central Africa */
  { "SAST",     TIMEOFFSET,     HOUR ( 2) }, /* South Africa Standard */
  { "EAT",      TIMEOFFSET,     HOUR ( 3) }, /* East Africa */
  { "MSK",      TIMEOFFSET,     HOUR ( 3) }, /* Moscow */
  { "MSD",      DSTOFFSET,      HOUR ( 3) }, /* Moscow Daylight */
  { "IST",      TIMEOFFSET,    (HOUR ( 5) + 30) },   /* India Standard */
  { "SGT",      TIMEOFFSET,     HOUR ( 8) }, /* Singapore */
  { "KST",      TIMEOFFSET,     HOUR ( 9) }, /* Korea Standard */
  { "JST",      TIMEOFFSET,     HOUR ( 9) }, /* Japan Standard */
  { "GST",      TIMEOFFSET,     HOUR (10) }, /* Guam Standard */
  { "NZST",     TIMEOFFSET,     HOUR (12) }, /* New Zealand Standard */
  { "NZDT",     DSTOFFSET,      HOUR (12) }, /* New Zealand Daylight */
  { NULL, 0, 0 }
};

/* Military time zone table.

   Note 'T' is a special case, as it is used as the separator in ISO
   8601 date and time of day representation. */
static table const timezone_military_table[] =
{
  { "A", TIMEOFFSET, -HOUR ( 1) },
  { "B", TIMEOFFSET, -HOUR ( 2) },
  { "C", TIMEOFFSET, -HOUR ( 3) },
  { "D", TIMEOFFSET, -HOUR ( 4) },
  { "E", TIMEOFFSET, -HOUR ( 5) },
  { "F", TIMEOFFSET, -HOUR ( 6) },
  { "G", TIMEOFFSET, -HOUR ( 7) },
  { "H", TIMEOFFSET, -HOUR ( 8) },
  { "I", TIMEOFFSET, -HOUR ( 9) },
  { "K", TIMEOFFSET, -HOUR (10) },
  { "L", TIMEOFFSET, -HOUR (11) },
  { "M", TIMEOFFSET, -HOUR (12) },
  { "N", TIMEOFFSET,  HOUR ( 1) },
  { "O", TIMEOFFSET,  HOUR ( 2) },
  { "P", TIMEOFFSET,  HOUR ( 3) },
  { "Q", TIMEOFFSET,  HOUR ( 4) },
  { "R", TIMEOFFSET,  HOUR ( 5) },
  { "S", TIMEOFFSET,  HOUR ( 6) },
  { "T", TIMEOFFSET,  HOUR ( 7) },
  { "U", TIMEOFFSET,  HOUR ( 8) },
  { "V", TIMEOFFSET,  HOUR ( 9) },
  { "W", TIMEOFFSET,  HOUR (10) },
  { "X", TIMEOFFSET,  HOUR (11) },
  { "Y", TIMEOFFSET,  HOUR (12) },
  { "Z", TIMEOFFSET,  HOUR ( 0) },
  { NULL, 0, 0 }
};

char *date_tail = NULL; // string relativa alla coda della data che parte dal carattere successivo analizzato in format
time_t rawtime = static_cast<time_t>(0);
tm *time_struct = localtime ( &rawtime ); // Settato come valore di partenza a 'January 1st 1970 at midnight GMT' Unix Born Date
time_t time = static_cast<time_t>(-1);
size_t date_len = strlen(datastr);

	if (date_len > UCHAR_MAX)
		return time; // stringa data, troppo lunga. Ignorata

	char *date = CBALLOC(char , MALLOC, (date_len + 1));
	char *base_date = date; // 'base_date' serve per liberare date, in quanto 'date' in seguito potrebbe non partire date &(date[0])... 

	strcpy(date, datastr);

	unsigned char s = date_len;

	while ((date[(s - 1)] == ASCII_SP || date[(s - 1)] == ASCII_NL || date[(s - 1)] == ASCII_CR || date[(s - 1)] == ASCII_TB) && s > MIN_DATE_LEN) s--;

	if (s < MIN_DATE_LEN) // string troppo breve per contenere anche una semplice data del tipo DD-MM-YYYY
	{
		free(base_date);
		return time; // troppi spazi finali in time. Ignorato
	}

	date[s] = '\0';
	date_len = s;
	s = 0;

	while ((date[s] == ASCII_SP || date[s] == ASCII_NL || date[s] == ASCII_CR || date[s] == ASCII_TB) && s < ((date_len / 2) + 2) && s < UCHAR_MAX) s++;

	if (s == UCHAR_MAX || s > (date_len / 2))
	{
		free(base_date);
		return time; // troppi spazi iniziali in time. Ignorato
	}

	if (s > 0)
	{
		date = &(date[s]);
		date_len -= s;
	}

	// RSS Time Format
	if ((date_tail = strptime( date, format, time_struct )) != NULL) 	// dovrebbe terminare con (+/-)0000 (opzionale)
	{
		if (time_struct->tm_year < -1800) // Handle years with 2 digits
			time_struct->tm_year = THIRD_MILLENIUM + time_struct->tm_year;

		unsigned short c = 0;

		if (date_tail[0] == ASCII_DT)
		{
			c++;

			while (date_tail[c] != '\0' && isdigit(date_tail[c]))
				c++;
		}

		if (c > 7) // nel caso di frazione di secondo non è ammessa oltre il milionesimo
		{
			free(base_date);
			return time; 
		}

		date_tail = &(date_tail[c]);

		c = 0;

		while (date_tail[c] != '\0' && date_tail[c] == ASCII_SP)
			c++;

		date_tail = &(date_tail[c]);

		size_t len = strlen(date_tail);

		if (date_tail[0] == ASCII_HM)
		{
			date_tail = &(date_tail[1]);

			len--;

			int hours = 0;
			int minutes = 0;
			int num_values = 0;
			char *tza = NULL; // Time Zone Abbreviated

			if (len == 5 || (len > 5 && ! isdigit(date_tail[5])))
			{
				tza = (char *) malloc (6 * sizeof(char));
				strncpy(tza, date_tail, 5);
				tza[5] = '\0';
				num_values = sscanf (tza,"%d:%d",&hours,&minutes);

				if (num_values == 2 && hours < 25 && minutes < 100) // string have colon
				{
					int delta = ((hours * 3600) + (minutes * 60));

					if (delta <= 86400)
						time = mktime( time_struct ) + (time_t)delta;
				}

				free(tza);
			}
			else if (len == 4 || (len > 4 && ! isdigit(date_tail[4])))
			{
				tza = (char *) malloc (5 * sizeof(char));
				strncpy(tza, date_tail, 4);
				tza[4] = '\0';

				num_values = sscanf (tza,"%d:%d",&hours,&minutes);

				if (num_values == 2 && hours < 25 && minutes < 100) // string have colon
				{
					int delta = ((hours * 3600) + (minutes * 60));

					if (delta <= 86400)
						time = mktime( time_struct ) + (time_t)delta;
				}
				else if (isdigit(tza[0]) && isdigit(tza[1]) && isdigit(tza[2]) && isdigit(tza[3]))
				{
					minutes = (((int)(tza[2] - 48) * 10) + int(tza[3] - 48));
					hours	= (((int)(tza[0] - 48) * 10) + int(tza[1] - 48));

					int delta = ((hours * 3600) + (minutes * 60));

					if (delta <= 86400)
						time = mktime( time_struct ) + ((time_t)delta);
				}

				free(tza);
			}
			else if (len == 3 || (len > 3 && ! isdigit(date_tail[3])))
			{
				tza = (char *) malloc (4 * sizeof(char));
				strncpy(tza, date_tail, 3);
				tza[3] = '\0';
				num_values = sscanf (tza,"%d:%d",&hours,&minutes);

				if (num_values == 2 && hours < 25 && minutes < 100) // string have colon
				{
					int delta = ((hours * 3600) + (minutes * 60));

					if (delta <= 86400)
						time = mktime( time_struct ) + (time_t)delta;
				}
				else if (isdigit(tza[0]) && isdigit(tza[1]) && isdigit(tza[2]))
				{
					minutes = (((int)(tza[1] - 48) * 10) + int(tza[2] - 48));
					hours	= int(tza[0] - 48);

					int delta = ((hours * 3600) + (minutes * 60));

					if (delta <= 86400)
						time = mktime( time_struct ) + ((time_t)delta);
				}

				free(tza);
			}
			else if (len == 2 || (len > 2 && ! isdigit(date_tail[2])))
			{
				tza = (char *) malloc (3 * sizeof(char));
				strncpy(tza, date_tail, 2);
				tza[2] = '\0';

				if (isdigit(tza[0]) && isdigit(tza[1]))
				{
					hours = atoi(tza);

					if (hours <= 24)
						time = mktime( time_struct ) + (time_t)(hours * 3600);
				}

				free(tza);
			}
			else if (len == 1 || (len > 1 && ! isdigit(date_tail[1])))
			{
				tza = (char *) malloc (2 * sizeof(char));
				tza[0] = date_tail[0];
				tza[1] = '\0';

				if (isdigit(tza[0]))
				{
					hours = atoi(tza);

					if (hours <= 24)
						time = mktime( time_struct ) + (time_t)(hours * 3600);
				}

				free(tza);
			}
		}
		else if (date_tail[0] == ASCII_PL)
		{
			date_tail = &(date_tail[1]);

			len--;

			int hours = 0;
			int minutes = 0;
			int num_values = 0;
			char *tza = NULL; // Time Zone Abbreviated

			if (len == 5 || (len > 5 && ! isdigit(date_tail[5])))
			{
				tza = (char *) malloc (6 * sizeof(char));
				strncpy(tza, date_tail, 5);
				tza[5] = '\0';
				num_values = sscanf (tza,"%d:%d",&hours,&minutes);

				if (num_values == 2 && hours < 25 && minutes < 100) // string have colon
				{
					int delta = ((hours * 3600) + (minutes * 60));

					if (delta <= 86400)
						time = mktime( time_struct ) - (time_t)delta;
				}

				free(tza);
			}
			else if (len == 4 || (len > 4 && ! isdigit(date_tail[4])))
			{
				tza = (char *) malloc (5 * sizeof(char));
				strncpy(tza, date_tail, 4);
				tza[4] = '\0';

				num_values = sscanf (tza,"%d:%d",&hours,&minutes);

				if (num_values == 2 && hours < 25 && minutes < 100) // string have colon
				{
					int delta = ((hours * 3600) + (minutes * 60));

					if (delta <= 86400)
						time = mktime( time_struct ) - (time_t)delta;
				}
				else if (isdigit(tza[0]) && isdigit(tza[1]) && isdigit(tza[2]) && isdigit(tza[3]))
				{
					minutes = (((int)(tza[2] - 48) * 10) + int(tza[3] - 48));
					hours	= (((int)(tza[0] - 48) * 10) + int(tza[1] - 48));

					int delta = ((hours * 3600) + (minutes * 60));

					if (delta <= 86400)
						time = mktime( time_struct ) - ((time_t)delta);
				}

				free(tza);
			}
			else if (len == 3 || (len > 3 && ! isdigit(date_tail[3])))
			{
				tza = (char *) malloc (4 * sizeof(char));
				strncpy(tza, date_tail, 3);
				tza[3] = '\0';
				num_values = sscanf (tza,"%d:%d",&hours,&minutes);

				if (num_values == 2 && hours < 25 && minutes < 100) // string have colon
				{
					int delta = ((hours * 3600) + (minutes * 60));

					if (delta <= 86400)
						time = mktime( time_struct ) - (time_t)delta;
				}
				else if (isdigit(tza[0]) && isdigit(tza[1]) && isdigit(tza[2]))
				{
					minutes = (((int)(tza[1] - 48) * 10) + int(tza[2] - 48));
					hours	= int(tza[0] - 48);

					int delta = ((hours * 3600) + (minutes * 60));

					if (delta <= 86400)
						time = mktime( time_struct ) - ((time_t)delta);
				}

				free(tza);
			}
			else if (len == 2 || (len > 2 && ! isdigit(date_tail[2])))
			{
				tza = (char *) malloc (3 * sizeof(char));
				strncpy(tza, date_tail, 2);
				tza[2] = '\0';

				if (isdigit(tza[0]) && isdigit(tza[1]))
				{
					hours = atoi(tza);

					if (hours <= 24)
						time = mktime( time_struct ) - (time_t)(hours * 3600);
				}

				free(tza);
			}
			else if (len == 1 || (len > 1 && ! isdigit(date_tail[1])))
			{
				tza = (char *) malloc (2 * sizeof(char));
				tza[0] = date_tail[0];
				tza[1] = '\0';

				if (isdigit(tza[0]))
				{
					hours = atoi(tza);

					if (hours <= 24)
						time = mktime( time_struct ) - (time_t)(hours * 3600);
				}

				free(tza);
			}
		}
		else
		{
			unsigned short a = 0;
			unsigned short b = 0;
			unsigned short c = 0;

			if (len == 0)
				time = mktime( time_struct );
			else if (len == 1 || (len > 1 && (! isalpha(date_tail[1]))))
			{
				while (timezone_military_table[a].name != NULL)
				{
					if (timezone_military_table[a].name[0] == toupper(date_tail[0]))
						break;

					a++;
				}

				if (timezone_military_table[a].name != NULL)
					time = mktime( time_struct ) - (time_t)timezone_military_table[a].value;
			}
			else
			{
				if ((len == 2 || (len > 2 && (! isalpha(date_tail[2])))) ||
					(len == 3 || (len > 3 && (! isalpha(date_tail[3])))))
				{
					while (universal_timezone_table[b].name != NULL)
					{
						if ((strlen(universal_timezone_table[b].name) == len && strncasecmp( date_tail, universal_timezone_table[b].name, len) == 0))
							break;

						b++;
					}

					if (universal_timezone_table[b].name != NULL)
						time = mktime( time_struct );
				}

				if (((len == 3 || (len > 3 && (! isalpha(date_tail[3])))) && universal_timezone_table[b].name == NULL) || 
					(len == 4 || (len > 4 && (! isalpha(date_tail[4])))))
					//(len == 4 || (len > 4 && (date_tail[4] == ASCII_SP || ! isalpha(date_tail[4])))))
				{
					while (timezone_table[c].name != NULL)
					{
						if ((strlen(timezone_table[c].name) == len && strncasecmp( date_tail, timezone_table[c].name, len) == 0))
							break;

						c++;
					}

					if (timezone_table[c].name != NULL)
						time = mktime( time_struct ) - ((time_t)timezone_table[c].value + timezone_table[c].type);
				}
			}
		}
	}

	if (base_date != NULL)
		free(base_date);

	return time;
}

//
// Name: get_addr
// 
// Description:
//   Gets the ipv4/ipv6 address from portable structure 'sockaddr_storage'
//
// Input:
//   the structure
//
// Returns:
//   the pointer to address buffer
//

bool get_addr(struct sockaddr_storage *ss, char *buf)
{
	struct sockaddr_in *sin = NULL;
	struct sockaddr_in6 *sin6 = NULL;

	switch (ss->ss_family)
	{
		case AF_INET6:
			sin6 = (struct sockaddr_in6 *)ss;
			inet_ntop(ss->ss_family, &sin6->sin6_addr, buf, INET6_ADDRSTRLEN);
			sin6 = NULL;
		break;
		case AF_INET:
			sin = (struct sockaddr_in *)ss;
			inet_ntop(ss->ss_family, &sin->sin_addr, buf, INET_ADDRSTRLEN);
			sin = NULL;
		break;
		default:
			return false;
		break;
	}

	return true;
}

//
// Name: url_has_protocol
//
// Description:
//   verify if the url start with a protocol
//
// Input:
//   url - string containg the url
//
// Returns:
//  true if the url starts with a protocol and false if it doesn't
//
int url_has_protocol (char *_url)
{
	return (strchr(_url, ':') != NULL && ((strchr(_url, '?')) == NULL || strchr(_url, ':') < strchr(_url, '?')) && ((strchr(_url, '#')) == NULL || strchr(_url, ':') < strchr(_url, '#')));
}

//
// Name: adjust_URL_path
//
// Description:
//   trys to normalize a url given acordingly to RFC 3986
//
// Input:
//   the url to be normalized
//
void url_adjust_path(char *href)
{
	  string str = href;                // "this is a test string."
	  //cout << str << endl;

	  size_t pos_question_mark = string::npos;
	  size_t pos_dot_sla = string::npos;
	  pos_question_mark = str.find("?", 0);
	  pos_dot_sla = str.find("/./", 0);

	  //remoção de /./
	  while (pos_dot_sla != string::npos && (pos_question_mark == string::npos || pos_dot_sla < pos_question_mark)){
		  str.replace(pos_dot_sla, 2, "");
		  pos_dot_sla = str.find("/./", pos_dot_sla);
		  pos_question_mark = str.find("?", 0); // a me questo sembra non necessario
	  }

	  size_t pos_start_path = string::npos;
	  pos_start_path = str.find("://", 0);
	  if(pos_start_path != string::npos) {
		  pos_start_path += 3;
	  } else {
		  pos_start_path = 0;
	  }

	  size_t pos_start_multi_sla = string::npos;
	  size_t pos_multi_sla = string::npos;
	  pos_start_multi_sla = (pos_start_path > 0) ? (pos_start_path - 1) : 0; // utilizzo dell'operatore condizionale
	  pos_multi_sla = str.find("//", pos_start_multi_sla);
	  // normalizzazione di tutti gli slash multipli (dopo '://')
	  while (pos_multi_sla != string::npos && (pos_question_mark == string::npos || pos_multi_sla < pos_question_mark)){
		str.replace(pos_multi_sla, 2, "/");
		pos_multi_sla = str.find("//", pos_start_multi_sla);
		pos_question_mark = str.find("?", 0);
	  }

	  size_t pos_sladotdot = string::npos;
	  size_t pos_previous_sla = string::npos;
	  pos_sladotdot = str.find("/..", 0);
	  pos_previous_sla = str.rfind("/", pos_sladotdot - 1);
	  while (pos_sladotdot != string::npos && (pos_question_mark == string::npos || pos_sladotdot < pos_question_mark)){
		if (pos_previous_sla == string::npos || pos_previous_sla < pos_start_path){
			pos_previous_sla = pos_sladotdot;
		}
	    str.replace(pos_previous_sla, pos_sladotdot - pos_previous_sla + 3, "");
	  	pos_sladotdot = str.find("/..", pos_previous_sla);
	  	pos_previous_sla = str.rfind("/", pos_sladotdot - 1);
	  	pos_question_mark = str.find("?", 0);
	  }

	  pos_dot_sla = str.rfind("/.");

      // sostituzione di /. con / alla fine di href
      if (pos_dot_sla != string::npos && ((pos_dot_sla + 2) == str.size()))
        str.replace(pos_dot_sla, 2, "/");

	  pos_dot_sla = str.find("/.", 0); // TODO a me non sembra utile ultimo controllo (in futuro verificare magari RFC 3986 perchè non capisco il senso)

	// "http://www.comune.oristano.it/.galleries/doc-tematiche-casa-e-urbanistica/./ristrutturazione_Piscina_Oristano/.";

	  //remoção de /. no fim
	  if (pos_dot_sla != string::npos && (pos_question_mark == string::npos || pos_dot_sla < pos_question_mark)){
     //     mcout << "check why seem abnormal href: " << str << mendl;
		  //str.replace(pos_dot_sla, 2, "/");
	  }

	  strcpy(href, str.c_str());
}

// Name: DataRetention::make
//
// Description: make partial path relative to instance
//
// Arguments:
// 	basedir - the first directory of dataretention path
// 	instance - number of instance
//
// Return: relative path where document is found
//
char *DataRetention::make(drdir_t basedir, instance_t instance)
{
	char instance_suffix[8]; // N.B. l'istanza SUFFISSO partirà dal valore zero
	snprintf(instance_suffix, sizeof(instance_suffix), "%d", instance);
	char *relative_rem_path = CBALLOC(char, MALLOC, (20 + 10));
	relative_rem_path[0] = '\0';
	strcpy(relative_rem_path, drdir(basedir));
	strcat(relative_rem_path, "/");
	strcat(relative_rem_path, "distr");
	strcat(relative_rem_path, instance_suffix);

	return relative_rem_path;
}

// Name: DataRetention::make
//
// Description: make partial path relative to instance
//
// Arguments:
// 	basedir - the first directory of dataretention path
// 	reldir - relative directory where create hierarchy
// 	instance - number of instance
//
// Return: relative path where document is found
//
char *DataRetention::make(drdir_t basedir, const char *reldir, instance_t instance)
{
	assert (reldir != NULL);

	char instance_suffix[8]; // N.B. l'istanza SUFFISSO partirà dal valore zero
	snprintf(instance_suffix, sizeof(instance_suffix), "%d", instance);
	unsigned short collection_reldir_len = strlen(reldir);
	char *relative_rem_path = CBALLOC(char, MALLOC, (20 + 10 + collection_reldir_len));
	relative_rem_path[0] = '\0';
	strcpy(relative_rem_path, drdir(basedir));
	strcat(relative_rem_path, "/");
	strcat(relative_rem_path, "distr");
	strcat(relative_rem_path, instance_suffix);
	strcat(relative_rem_path, "/");
	strcat(relative_rem_path, reldir);

	return relative_rem_path;
}

const char *DataRetention::drdir (drdir_t drdir)
{
	switch (drdir)
	{
		case REMDR:
			return "remdr";
		case LOCDR:
			return "locdr";
	};

	return NULL;
}

char *digits_to_ascii( off64_t w )
{
size_t size = 20; // numero di caratteri sufficiente a contenere un numero a 20 cifre (unsigned long long int)
const static char ascii_ch[] = {48,49,50,51,52,53,54,55,56,57};
char *converted = (char *) malloc ((size + 1) * sizeof(char));
char *invert = (char *) malloc ((size + 1) * sizeof(char));
unsigned short a = 0;

	for (size_t i = 0; i <= size; i++)
	{
		invert[i] = '\0';
		converted[i] = '\0';
	}

	unsigned int t = w;

	do
	{
		invert[a++] = ascii_ch[t % 10]; // ogni cifra viene convertita nel suo compatibile carattere ascii (praticamente il numero cambia da 9 a '9')
		t = t / 10; // nessun resto 
	}
	while (t > 0);

	t = a;

	for (unsigned short v = 0; v < a; v++)
	{
		converted[v] = invert[--t]; // chiave ora contiene un array di cifre che compongono il numero contenuto in w
	}

	free(invert);

	return converted;
}

//
// Name: robots_txt_display
//
// Description: display rules
//
// Arguments: input rules to display, input rules size
//
// Return: 
//
void robots_txt_display(char *rules, size_t size)
{
	size_t c = 0;

	while (c < size)
	{
		size_t _c = c;
		size_t __c = c;

		// get end of single rule and count wildcard and dollar symbols
        while (rules[c] != ASCII_NUL) c++;

		assert(c <= size);

		while (_c < c)
		{
			if (_c == __c)
			{
				switch (rules[_c])
				{
					case (ROBOTS_ALLOW):
						cout << GRE << ROBOT_TXT_RULE_STR(rules[_c]);
					break;
					case (ROBOTS_DISALLOW):
						cout << RED << ROBOT_TXT_RULE_STR(rules[_c]);
						break;
					default:
						cout << "Unknown";
						break;
				};

				if (rules[_c] == ROBOTS_UNKNOWN)
				{
					cout << ": " << &rules[(_c + 1)] << NOR << endl;

					_c = c;
					// check other rules
					continue;
				}
				else
				{
					// prepare for skip first slash
					_c++;

					cout << ": " << &rules[_c] << NOR << endl;
				}

				_c++;
				continue;
			}

			_c++;
		}

		c++;
	}
}

//
// Name: robots_txt_syntax
//
// Description: create rules skipping duplicated and giving precedence at 'allow' rules
//
// Arguments: input rules to check, input rules size, new buffer rules, new buffer size
//
// Output: new buffer size
//
// Return: new buffer of rules
//
void robots_txt_syntax(const char *_rules, size_t _size, char *rules, size_t &size)
{
	// first save allow rules
	for (size_t i = 0; i < _size; i++)
	{
		if (i == 0)
		{
			bool present = false;
			int s = strlen(&_rules[i]);

//cout << endl << size << '|' << &_rules[i] << endl;
			if (_rules[i] == ROBOTS_ALLOW)
			{	// skip duplicate rule
				for (size_t _i = 0; _i < size; _i++)
				{
					if (_i == 0)
					{
						int _s = strlen(&rules[_i]);

						if (rules[_i] == ROBOTS_ALLOW && _s == s && memcmp(&rules[(_i + 1)], &_rules[(i + 1)], (_s - 1)) == 0)
							present = true;

						_i += _s;
					}
					else
					{
						int _s = strlen(&rules[_i]);

						if (rules[_i] == ROBOTS_ALLOW && _s == s && memcmp(&rules[(_i + 1)], &_rules[(i + 1)], (_s - 1)) == 0)
							present = true;

						_i += _s;
					}
				}

				if (present == false)
				{
					memcpy(rules + size, &_rules[i], s);
					size += s;
					rules[size] = ASCII_NUL;
					size++;
				}
			}

			i += s;
		}
		else
		{
			bool present = false;
			int s = strlen(&_rules[i]);

//cout << endl << size << '_' << &_rules[i] << endl;
			if (_rules[i] == ROBOTS_ALLOW)
			{	// skip duplicate rule
				for (size_t _i = 0; _i < size; _i++)
				{
					if (_i == 0)
					{
						int _s = strlen(&rules[_i]);

						if (rules[_i] == ROBOTS_ALLOW && _s == s && memcmp(&rules[(_i + 1)], &_rules[(i + 1)], (_s - 1)) == 0)
							present = true;

						_i += _s;
					}
					else
					{
						int _s = strlen(&rules[_i]);

						if (rules[_i] == ROBOTS_ALLOW && _s == s && memcmp(&rules[(_i + 1)], &_rules[(i + 1)], (_s - 1)) == 0)
							present = true;

						_i += _s;
					}
				}

				if (present == false)
				{
					memcpy(rules + size, &_rules[i], s);
					size += s;
					rules[size] = ASCII_NUL;
					size++;
				}
			}

			i += s;
		}
	}

	// save disallow rules
	for (size_t i = 0; i < _size; i++)
	{
		if (i == 0)
		{
			bool present = false;
			int s = strlen(&_rules[i]);

//cout << endl << size << '|' << &_rules[i] << endl;
			if (_rules[i] == ROBOTS_DISALLOW)
			{	// skip duplicate rule
				for (size_t _i = 0; _i < size; _i++)
				{
					if (_i == 0)
					{
						int _s = strlen(&rules[_i]);

						if (_s == s &&
							(rules[_i] == ROBOTS_ALLOW || rules[_i] == ROBOTS_DISALLOW) &&
							(memcmp(&rules[(_i + 1)], &_rules[(i + 1)], (_s - 1)) == 0))
							present = true;

						_i += _s;
					}
					else
					{
						int _s = strlen(&rules[_i]);

						if (_s == s &&
							(rules[_i] == ROBOTS_ALLOW || rules[_i] == ROBOTS_DISALLOW) &&
							(memcmp(&rules[(_i + 1)], &_rules[(i + 1)], (_s - 1)) == 0))
							present = true;

						_i += _s;
					}
				}

				if (present == false)
				{
					memcpy(rules + size, &_rules[i], s);
					size += s;
					rules[size] = ASCII_NUL;
					size++;
				}
			}

			i += s;
		}
		else// if (_rules[i] == ASCII_NUL)
		{
			bool present = false;
			int s = strlen(&_rules[i]);

//cout << endl << size << '_' << &_rules[i] << endl;
			if (_rules[i] == ROBOTS_DISALLOW)
			{	// skip duplicate rule
				for (size_t _i = 0; _i < size; _i++)
				{
					if (_i == 0)
					{
						int _s = strlen(&rules[_i]);

						if (_s == s &&
							(rules[_i] == ROBOTS_ALLOW || rules[_i] == ROBOTS_DISALLOW) &&
							(memcmp(&rules[(_i + 1)], &_rules[(i + 1)], (_s - 1)) == 0))
							present = true;

						_i += _s;
					}
					else
					{
						int _s = strlen(&rules[_i]);

						if (_s == s &&
							(rules[_i] == ROBOTS_ALLOW || rules[_i] == ROBOTS_DISALLOW) &&
							(memcmp(&rules[(_i + 1)], &_rules[(i + 1)], (_s - 1)) == 0))
							present = true;

						_i += _s;
					}
				}

				if (present == false)
				{
					memcpy(rules + size, &_rules[i], s);
					size += s;
					rules[size] = ASCII_NUL;
					size++;
				}
			}

			i += s;
		}
	}
}

//
// Name: robots_txt_mached
//
// Description: check if url prefix is allow or disallow
//
// Arguments: input rules to check, input rules size, url path to search
//
// Return: struct with matched rule
//
robots_txt_matched_t *robots_txt_match(char *rules, size_t size, char *search)
{
	assert(rules != NULL);

	size_t c = 0;
	size_t wc_ofs = 0;
	unsigned short nmatch = 0;

	// skip first slash
	size_t ___c = 0;

	// const char *search = "/nblnckluzblab";
	// const char *search = "/bnm";

	assert(search[0] == '/');

	auto slen = (size_t)strlen(search);

	// find the full match rule

	char *rulename = NULL;

	robots_txt_matched_t *winner = CBALLOC(robots_txt_matched_t, MALLOC, 1);

	winner->rule = ROBOTS_UNKNOWN;
	winner->rulename = NULL;
	winner->vote = 0;

	while (c < size)
	{
		bool wc_chk = false; // wildcard check (*)
		bool dollar = false;
		size_t _c = c;
		size_t __c = c;
		size_t valid_chars_count = 0;

		// save offset where rule start
		wc_ofs = c;

		// get end of single rule and count wildcard and dollar symbols
		while (rules[c] != ASCII_NUL)
		{
			if (rules[c] != ASCII_AS && rules[c] != ASCII_DO)
				valid_chars_count++;

			c++;
		}

		valid_chars_count--;

		assert(c <= size);

		if (rules[c - 1] == ASCII_DO)
			dollar = true;

		while (_c < c)
		{
			if (_c == __c)
			{
/*				switch (rules[_c])
				{
					case (ROBOTS_ALLOW):
						cout << GRE << ROBOT_TXT_RULE_STR(rules[_c]);
					break;
					case (ROBOTS_DISALLOW):
						cout << RED << ROBOT_TXT_RULE_STR(rules[_c]);
						break;
					default:
						cout << "Unknown";
						break;
				};
*/
				if (rules[_c] == ROBOTS_UNKNOWN)
				{
//					cout << ": " << &rules[(_c + 1)] << NOR << endl;

					_c = c;
					// check other rules
					continue;
				}
				else
				{
					rulename = &rules[_c];

					// prepare for skip first slash
					_c++;

//					cout << ": " << &rules[_c] << NOR << endl;
				}

				// end of rule as wildchar
				if (_c == (c - 1)) nmatch = 1;

				_c++;
				___c++;
				continue;
			}
			else
			{
				if (___c < slen)
				{
					if (wc_chk == true)
					{
						size_t o = 0;
						size_t _o = 0;
						size_t ____c = ___c;

						while ((wc_ofs + o) < c)
						{
//cout << rules[(wc_ofs + o)] << '-' << search[___c] << ' ' << wc_ofs << ' ' << _o << ' ' << o << ' ' << ___c << endl;
							if ((___c < slen) && rules[(wc_ofs + o)] == search[___c])
								o++;
							else
							{
								____c++;
								o = _o;
							}

				 			// match 
							if (rules[(wc_ofs + o)] == ASCII_NUL)
							{   // end of rule reached with success
								nmatch += (unsigned short)(o - _o);
								_c = c;
								break;
							}
							else if (rules[(wc_ofs + o)] == ASCII_DO)
							{	// matched if input end with same last string of regex rule
								if (___c == (slen - 1))
								{
									nmatch += (unsigned short)(o - _o);
									_c = c;
									break;
								}
							}
							else if (rules[(wc_ofs + o)] == ASCII_AS)
							{   // match partial rule
								nmatch += (unsigned short)(o - _o);

								___c++;

								if (___c == slen)
									break;

								o++;
								_o = o;
								continue;
							}

							if (o == _o)
								___c = ____c;
							else
								___c++;

							// reached end of input string without success
							if (___c == slen)
							{
								_c = c;
								break;
							}
						}
					}

					if (wc_chk == false)
					{
						if ((___c < slen) && rules[_c] == search[___c])
							___c++;
						else
						{	// check with no success and skip rule
							if (rules[(_c + 1)] == ASCII_NUL)
							{
								nmatch = (unsigned short)___c;
								___c = slen;
								_c++;
								continue;
							}
							else if ((_c - __c) == (___c + 1) && rules[_c] == ASCII_AS)
							{
// cout << _c << ' ' << __c << ' ' << slen << ' ' << ___c << endl;
								nmatch = ___c;
								wc_chk = true;
								wc_ofs = _c;
								wc_ofs++;
							}
							else
							{
// cout << _c << ' ' << __c << ' ' << slen << ' ' << rules[_c] << endl;
								nmatch = (unsigned short)___c;
								___c = slen;
								_c = c;
								continue;
							}
						}

						// match without regex
						if (___c == valid_chars_count)
							nmatch = valid_chars_count;
					}
				}
			}

			_c++;
		}

		// give vote but if same vote remember, 'Allow' win always!
		if (nmatch == valid_chars_count)
		{
			if (dollar == true) nmatch++;

			if (rulename[0] == ROBOTS_ALLOW)
			{
				if (winner->rule == ROBOTS_UNKNOWN && nmatch > winner->vote) winner->rule = (robots_txt_rule_t)rulename[0];

				if (winner->rule == ROBOTS_ALLOW && nmatch > winner->vote)
				{
					winner->rulename = rulename;
					winner->vote = nmatch;
				}
				else if (winner->rule == ROBOTS_DISALLOW && nmatch >= winner->vote)
				{
					winner->rule = (robots_txt_rule_t)rulename[0];
					winner->rulename = rulename;
					winner->vote = nmatch;
				}
			}
			else if (nmatch > winner->vote)
			{
				if (winner->rule == ROBOTS_ALLOW) winner->rulename = rulename;
				else if (winner->rulename == NULL) winner->rulename = rulename;

				winner->rule = (robots_txt_rule_t)rulename[0];
				winner->vote = nmatch;
			}
		}

//		if (nmatch == valid_chars_count) cout << " Found (" << ((dollar == false) ? nmatch : (nmatch + 1)) << ") " << endl;

		c++;
		___c = 0;
	}

	return winner;
}

//
// Name: file_lock (work with NFS)
//
// Description: Lock file.
//
// Input: file The file stream, typelock false write mode, typelock true read mode
//
// Return: true on success, false on failure.
//
bool file_lock(FILE *file, bool typelock) 
{
	int fd = fileno(file); // obtain the file descriptor
	struct flock lock;
	memset (&lock, 0, sizeof(lock));

	if (typelock == false)
		lock.l_type = F_WRLCK;
	else
		lock.l_type = F_RDLCK;

	int flags = fcntl (fd, F_OFD_SETLKW, &lock);

	if (flags == -1)
		return false;

	return true;
}

//
// Name: fd_lock (work with NFS)
//
// Description: Set a file descriptor to blocking or non-blocking mode.
//
// Input: fd The file descriptor, typelock false write mode, typelock true read mode
//
// Return: true on success, false on failure.
//
bool fd_lock(int fd, bool typelock) 
{
	struct flock lock;
	memset (&lock, 0, sizeof(lock));

	if (typelock == false)
		lock.l_type = F_WRLCK;
	else
		lock.l_type = F_RDLCK;

	int flags = fcntl (fd, F_OFD_SETLKW, &lock);

	if (flags == -1)
		return false;

	return true;
}

//
// Name: file_unlock (work with NFS)
//
// Description: Unlock file.
//
// Input: file The file stream
//
// Return: true on success, false on failure.
//
bool file_unlock(FILE *file) 
{
	int fd = fileno(file); // obtain the file descriptor
	struct flock lock;
	memset (&lock, 0, sizeof(lock));

	lock.l_type = F_UNLCK;

	int flags = fcntl (fd, F_OFD_SETLKW, &lock);

	if (flags == -1)
		return false;

	return true;
}

//
// Name: fd_unlock (work with NFS)
//
// Description: Set a file descriptor to blocking or non-blocking mode.
//
// Input: fd The file descriptor
//
// Return: true on success, false on failure.
//
bool fd_unlock(int fd) 
{
	struct flock lock;
	memset (&lock, 0, sizeof(lock));

	lock.l_type = F_UNLCK;

	int flags = fcntl(fd, F_OFD_SETLKW, &lock);

	if (flags == -1)
		return false;

	return true;
}

//
// Nome htmlSplit
//
// Descrizione Esegue l'estrapolazione dei metadati nel testo html precedentemente convertito dal crawler in testo
//
// Restituisce la struttura in cui sono presenti i testi contenuti nel titolo , keywords, description
// e copia il testo del contenuto tra i tags body nel buffer 'content'
//
pes_t *htmlSplit(char *inbuf)
{
	pes_t *inn = CBALLOC(pes_t, MALLOC, 1);

	// Occorre inizializzare gli array della struttura di tipo pes_t nel caso non vengano scritti durante l'esecuzione del programma
	inn->title[0] = ASCII_NUL;
	inn->headings[0] = ASCII_NUL;
	inn->metadesc[0] = ASCII_NUL;
	inn->metakeyw[0] = ASCII_NUL;
	inn->metalmon = pes_t::NO_LOCAL_MONETARY;

	unsigned short offset = HTMLMETAPREFIXSIZE;

	if (((int)inbuf[0] + SCHAR_MAX) > 0)
	{
		// Title
		unsigned short len = ((int)inbuf[0] + SCHAR_MAX);

		if (len < TITLESIZE)
		{
			strncpy(inn->title, &(inbuf[offset]), len);
			inn->title[len] = '\0';
		}
		else
		{
			len = TITLESIZE;

			if (inbuf[(offset + len)] != ASCII_SP)
			{
				while (len > 0 && inbuf[(offset + len)] != ASCII_SP) len--;
					
				while (len > 0 && inbuf[(offset + len)] == ASCII_SP) len--; // si ferma all'ultimo spazio partendo dalla coda del buffer

				len++;
			}

			strncpy(inn->title, &(inbuf[offset]), len);
			inn->title[len] = '\0';
		}
	}

	offset += ((int)inbuf[0] + SCHAR_MAX);

	if (((int)inbuf[1] + SCHAR_MAX) > 0)
	{
		// Subject
		unsigned short len = ((int)inbuf[1] + SCHAR_MAX);

		if (len < DESCSIZE)
		{
			strncpy(inn->metadesc, &(inbuf[offset]), len);
			inn->metadesc[len] = '\0';
		}
		else
		{
			len = DESCSIZE;

			if (inbuf[(offset + len)] != ASCII_SP)
			{
				while (len > 0 && inbuf[(offset + len)] != ASCII_SP) len--;
					
				while (len > 0 && inbuf[(offset + len)] == ASCII_SP) len--; // si ferma all'ultimo spazio partendo dalla coda del buffer

				len++;
			}

			strncpy(inn->metadesc, &(inbuf[offset]), len);
			inn->metadesc[len] = '\0';
		}
	}

	offset += ((int)inbuf[1] + SCHAR_MAX);

	if (((int)inbuf[2] + SCHAR_MAX) > 0)
	{
		// Keywords
		unsigned short len = ((int)inbuf[2] + SCHAR_MAX);

		if (len < KEYWSIZE)
		{
			strncpy(inn->metakeyw, &(inbuf[offset]), len);
			inn->metakeyw[len] = '\0';
		}
		else
		{
			len = KEYWSIZE;

			if (inbuf[(offset + len)] != ASCII_SP)
			{
				while (len > 0 && inbuf[(offset + len)] != ASCII_SP) len--;
					
				while (len > 0 && inbuf[(offset + len)] == ASCII_SP) len--;// si ferma all'ultimo spazio partendo dalla coda del buffer

				len++;
			}

			strncpy(inn->metakeyw, &(inbuf[offset]), len);
			inn->metakeyw[len] = '\0';
		}
	}

	offset += ((int)inbuf[2] + SCHAR_MAX);

	if (((int)inbuf[3] + SCHAR_MAX) > 0)
	{
		// Headings
		unsigned short len = ((int)inbuf[3] + SCHAR_MAX);

		if (len < HEADINGSSIZE)
		{
			strncpy(inn->headings, &(inbuf[offset]), len);
			inn->headings[len] = '\0';
		}
		else
		{
			len = HEADINGSSIZE;

			if (inbuf[(offset + len)] != ASCII_SP)
			{
				while (len > 0 && inbuf[(offset + len)] != ASCII_SP) len--;
					
				while (len > 0 && inbuf[(offset + len)] == ASCII_SP) len--; // si ferma all'ultimo spazio partendo dalla coda del buffer

				len++;
			}

			strncpy(inn->headings, &(inbuf[offset]), len);
			inn->headings[len] = '\0';
		}
	}

	offset += ((int)inbuf[3] + SCHAR_MAX);

	while (inbuf[offset] == ASCII_SP) // hide initial spaces
		offset++; 

	off64_t len = ((strlen(&inbuf[HTMLMETAPREFIXSIZE]) + HTMLMETAPREFIXSIZE) - offset);

	inn->content = (char *) malloc ((len + 1) * sizeof(char));

	strncpy(inn->content, &(inbuf[offset]), len);
	inn->content[len] = '\0'; 

	return inn;
}

//
// Nome pdfSplit
//
// Descrizione Esegue l'estrapolazione dei metadati nel testo pdf già convertito dal crawler in testo
//
// Restituisce la struttura in cui sono presenti i testi contenuti nel titolo , keywords, description
// e copia il testo del corpo del pdf nul buffer 'content'
//
pes_t *pdfSplit(char *inbuf)
{
	pes_t *inn = CBALLOC(pes_t, MALLOC, 1);

	// Occorre inizializzare gli array della struttura di tipo pes_t nel caso non vengano scritti durante l'esecuzione del programma
	inn->metadesc[0] = '\0';
	inn->metakeyw[0] = '\0';
	inn->title[0] = '\0';
	inn->headings[0] = '\0';

	unsigned short offset = PDFMETAPREFIXSIZE;

	/*if (((int)inbuf[0] + CHAR_MAX) > 0)
	{
		cout << "Author: ";

		for (unsigned short i = offset; i <= (offset + (int)inbuf[0] + CHAR_MAX - 1); i++)
			cout << inbuf[(int)i];

		cout << endl;
	}*/

	offset += ((int)inbuf[0] + SCHAR_MAX);

	if (((int)inbuf[1] + SCHAR_MAX) > 0)
	{
		// Subject
		unsigned short len = (offset + (int)inbuf[1] + SCHAR_MAX);

		if (len < DESCSIZE)
		{
			strncpy(inn->metadesc, &(inbuf[offset]), len);
			inn->metadesc[len] = '\0';
		}
		else
		{
			len = DESCSIZE;

			if (inbuf[(offset + len)] != ASCII_SP)
			{
				while (len > 0 && inbuf[(offset + len)] != ASCII_SP) len--;
					
				while (len > 0 && inbuf[(offset + len)] == ASCII_SP) len--;// si ferma all'ultimo spazio partendo dalla coda del buffer

				len++;
			}

			strncpy(inn->metadesc, &(inbuf[offset]), len);
			inn->metadesc[len] = '\0';
		}
	}

	offset += ((int)inbuf[1] + SCHAR_MAX);

	if (((int)inbuf[2] + SCHAR_MAX) > 0)
	{
		// Title
		unsigned short len = (offset + (int)inbuf[2] + SCHAR_MAX);

		if (len < TITLESIZE)
		{
			strncpy(inn->title, &(inbuf[offset]), len);
			inn->title[len] = '\0';
		}
		else
		{
			len = TITLESIZE;

			if (inbuf[(offset + len)] != ASCII_SP)
			{
				while (len > 0 && inbuf[(offset + len)] != ASCII_SP) len--;
					
				while (len > 0 && inbuf[(offset + len)] == ASCII_SP) len--; // si ferma all'ultimo spazio partendo dalla coda del buffer

				len++;
			}

			strncpy(inn->title, &(inbuf[offset]), len);
			inn->title[len] = '\0';
		}
	}

	offset += ((int)inbuf[2] + SCHAR_MAX);

	if (((int)inbuf[3] + SCHAR_MAX) > 0)
	{
		// keywords
		unsigned short len = (offset + (int)inbuf[3] + SCHAR_MAX);

		if (len < KEYWSIZE)
		{
			strncpy(inn->metakeyw, &(inbuf[offset]), len);
			inn->metakeyw[len] = '\0';
		}
		else
		{
			len = KEYWSIZE;

			if (inbuf[(offset + len)] != ASCII_SP)
			{
				while (len > 0 && inbuf[(offset + len)] != ASCII_SP) len--;
					
				while (len > 0 && inbuf[(offset + len)] == ASCII_SP) len--;// si ferma all'ultimo spazio partendo dalla coda del buffer

				len++;
			}

			strncpy(inn->metakeyw, &(inbuf[offset]), len);
			inn->metakeyw[len] = '\0';
		}
	}

	offset += ((int)inbuf[3] + SCHAR_MAX);

	while (inbuf[offset] == ASCII_SP) offset++;// hide initial spaces

	off64_t len = ((strlen(&inbuf[PDFMETAPREFIXSIZE]) + PDFMETAPREFIXSIZE) - offset);

	inn->content = (char *) malloc ((len + 1) * sizeof(char));

	strncpy(inn->content, &(inbuf[offset]), len);
	inn->content[len] = '\0';

	return inn;
}
