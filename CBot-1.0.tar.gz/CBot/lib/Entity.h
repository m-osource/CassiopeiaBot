/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _ENTITYIDX_H_
#define _ENTITYIDX_H_

// System libraries

#include <assert.h>
#include <iostream>
#include <fstream>
#include <errno.h>

using namespace std;

// Local libraries

#include "const.h"
#include "xmlconf.h"

// Constants

// Filenames
// Local variables
const off64_t MAXENTITIES = 5000;
const off64_t EXPECTED_ENTITY_SIZE = 16; // in bytes
const off64_t ENTITYIDX_EXPECTED_ENTITY_SIZE = (EXPECTED_ENTITY_SIZE + 1 + sizeof(entityid_t));

// Status
enum entityidx_status_t { 
	ENTITYIDX_ERROR 			= 0,
	ENTITYIDX_CREATED_ENTITY	= 1,
	ENTITYIDX_EXISTENT		= 2,
	ENTITYIDX_NOT_FOUND		= 3
};

// Entities types
enum entity_type_t { 
	ENTITYIDX_ENTITY_ALPHANUM	= 0,
	ENTITYIDX_ENTITY_DECIMAL	= 1,
	ENTITYIDX_ENTITY_HEXDECIMAL	= 2,
	ENTITYIDX_ENTITY_INVALID	= 3
};

// struttura che restituisce i dati della delle entità
typedef struct {
	bool found;
    unsigned int entity_code;
} entity_out_t;


// Classe Entità (html)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Entities {

	// Attenzione: TUTTE le dichiarazioni in questa sezione sono valide per tutte le funzioni all'interno della classe.
	// Motivo per cui NON occorre passarle come argomenti alle stesse.
	//
	// Attenzione: Quando un metodo ha il solo compito di riportare informazioni su un oggetto, senza modificarne il contenuto, si può, per evitare errori,
	// imporre tale condizione a priori, inserendo lo specificatore 'const' dopo la lista degli argomenti della funzione
	// (sia nella dichiarazione che nella definizione). Esistono comunque delle particolari eccezioni...

	// Constants
//	#define MAXENTITIES 5000 // usando il define la dichiarazione crea un warning tra 'parser' e 'parser_extended'


	// Variables
	typedef struct {
		// Entities
		char *entity;								// Strings    [memory]
		off64_t *entity_hash;                       // Hash table [memory]
		entityid_t entity_count;					// Count      [memory]
		off64_t entity_next_char;					// String Pos [memory]
		bool *valid_codes;							// Decimal Valid Codes (by positions, true if code exist) [memory]
	} entityidx_t;

	entityidx_t *openidx;

	public:

	bool index_setup (const size_t, bool);

	void index_open(void);

	void index_close(void);

	// New URL index
	void entityidx_new(void);
	
	// Close an URL index
	void entityidx_close(void);

	// Check if html entity is found in index
	entityidx_status_t checkEntity(char *, entityid_t *, entity_type_t *) const;

	// Get the entityid for a entity
	entityidx_status_t entityidx_resolve_entity( const char *entity, entityid_t *entityid, bool readonly ) const; // * performance **
	
	// Get a entity from a entityid // CANNOT EB EXIST BECAUSE 'entityid' IS NOT UNIVOCAL
	// void entityidx_entity_by_entityid( entityid_t entityid, char *name ) const;
	
	// Get the entityid bucket for a entity
	entityid_t entityidx_check_entity( const char *entity, entityid_t *bucket, bool readonly ) const; // **
	
	// Hash functions
	entityid_t entityidx_hashing_entity( const char *text ) const;
};

#endif
