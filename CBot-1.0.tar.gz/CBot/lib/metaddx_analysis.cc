/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "metaddx_analysis.h"

//
// Name: thread_function_caller
//
// Description:
//   A proxy function to pass non-static function at pthread_create
//   Note: function called by thread_function_caller need to have real class object passed through args
//
// Input:
//   args - void arguments
//
// Return:
//   pointer to void
//
void *Analysis::thread_function_caller(void *args)
{
	assert (args);

	Analysis::thread_args_t *arguments = (Analysis::thread_args_t *)args;

try
{
	Analysis *newObj = NULL; // Note function called work to 'this' temporary object and need to be deleted at the end of the same.

	try
	{
		newObj = new Analysis (NULL); // Note function called work to 'this' temporary object and need to be deleted at the end of the same.
	}
	catch (std::bad_alloc &ba)
	{
		die("Analysis thread_function_caller: bad_alloc caught %s", ba.what());
	}

	switch (arguments->f)
	{
		case ANALYSIS_SITE_STATISTICS:
			newObj->thread_function_site_statistics(args);
			break;
		case ANALYSIS_DOC_STATISTICS:
			newObj->thread_function_doc_statistics(args);
			break;
		default:
			break;
	}

	delete newObj;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(arguments->obj->barrier); 
}

	// Each thread must exit with 'pthread_barrier_wait'
	// in normal condition
	if (arguments->obj->barrier)
	{
		int rc = pthread_barrier_wait(arguments->obj->barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	free(arguments);
	arguments = NULL;

	return NULL;
}

// threads sync
void Analysis::sync_threads(pthread_barrier_t *barrier) const
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc = pthread_barrier_wait(barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
		pthread_exit(NULL);
}

//
// Name: site_statistics
//
// Description:
//   Generates statistics about sites:
//    Age of oldest page
//    Age of newest page
//    Various document counts
//    Max depth
//
// Input:
//
// Return:
//
//void Analysis::site_statistics()
void Analysis::site_statistics(void)
{
	int rc = 0;

	assert(meta != NULL);

	ndocs	= meta->doc_count();
	assert(ndocs > 0);
	nsites = meta->site_count();
	assert(nsites > 0);

	count_doc = CBALLOC(docid_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	count_doc_gathered = CBALLOC(docid_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	count_doc_ignored = CBALLOC(docid_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	count_doc_new = CBALLOC(docid_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	count_doc_assigned = CBALLOC(docid_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	count_doc_ok = CBALLOC(docid_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	count_doc_date_ok = CBALLOC(docid_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	count_doc_static = CBALLOC(docid_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	count_doc_dynamic = CBALLOC(docid_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	max_depth = CBALLOC(unsigned int **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	age_oldest_page = CBALLOC(time_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	age_newest_page = CBALLOC(time_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	age_average_page = CBALLOC(double **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	sum_pagerank = CBALLOC(pagerank_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	sum_hubrank = CBALLOC(hubrank_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	sum_authrank = CBALLOC(authrank_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));
	sum_liverank = CBALLOC(liverank_t **, MALLOC, (CONF_COLLECTION_DISTRIBUTED));

	// For summary statistics. Note: macro CBALLOC cannot used to allocate with 'map'
	site_status_map = new map<site_optmask_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_status_map != NULL);
	site_count_doc_map = new map<docid_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_count_doc_map != NULL);
	site_raw_content_length_mb = new map<unsigned int, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_raw_content_length_mb != NULL);
	site_age_oldest_page_months = new map<time_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_age_oldest_page_months != NULL);
	site_age_newest_page_months = new map<time_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_age_newest_page_months != NULL);
	site_age_average_page_months = new map<time_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_age_average_page_months != NULL);
	site_age_oldest_page_years = new map<time_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_age_oldest_page_years != NULL);
	site_age_newest_page_years = new map<time_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_age_newest_page_years != NULL);
	site_age_average_page_years = new map<time_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_age_average_page_years != NULL);
	site_internal_links = new map<docid_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_internal_links != NULL);
	site_internal_links_by_ndocs = new map<unsigned int, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_internal_links_by_ndocs != NULL);
	site_in_degree = new map<siteid_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_in_degree != NULL);
	site_out_degree = new map<siteid_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_out_degree != NULL);
	site_max_depth = new map<depth_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_max_depth != NULL);
	site_sum_pagerank = new map<double, docid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_sum_pagerank != NULL);
	site_sum_hubrank = new map<double, docid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_sum_hubrank != NULL);
	site_sum_authrank = new map<double, docid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_sum_authrank != NULL);
	site_sum_liverank = new map<double, docid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_sum_liverank != NULL);
	site_siterank = new map<double, docid_t> [CONF_COLLECTION_DISTRIBUTED];
	assert(site_siterank != NULL);
	sum_count_doc = CBALLOC(docid_t, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	sum_count_doc_static = CBALLOC(docid_t, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	media_age_oldest_page_months = CBALLOC(double, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	media_age_newest_page_months = CBALLOC(double, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	media_age_average_page_months = CBALLOC(double, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	media_in_degree = CBALLOC(double, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	media_out_degree = CBALLOC(double, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	media_internal_links = CBALLOC(double, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	media_raw_content_length_mb = CBALLOC(double, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	media_max_depth = CBALLOC(double, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	nsites_age_valid = CBALLOC(siteid_t, CALLOC, (CONF_COLLECTION_DISTRIBUTED));
	nsites_ok = CBALLOC(siteid_t, CALLOC, (CONF_COLLECTION_DISTRIBUTED));

	pthread_mutexattr_t attr;

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		thread_args_t *args = CBALLOC(thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = ANALYSIS_SITE_STATISTICS;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_site_statistics((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}
	// For summary statistics. Note: macro CBALLOC cannot used to allocate with 'map'

	free(nsites_ok);
	free(nsites_age_valid);
	free(media_max_depth);
	free(media_raw_content_length_mb);
	free(media_internal_links);
	free(media_out_degree);
	free(media_in_degree);
	free(media_age_average_page_months);
	free(media_age_newest_page_months);
	free(media_age_oldest_page_months);
	free(sum_count_doc_static);
	free(sum_count_doc);
	delete [] site_siterank;
	delete [] site_sum_liverank;
	delete [] site_sum_authrank;
	delete [] site_sum_hubrank;
	delete [] site_sum_pagerank;
	delete [] site_max_depth;
	delete [] site_out_degree;
	delete [] site_in_degree;
	delete [] site_internal_links_by_ndocs;
	delete [] site_internal_links;
	delete [] site_age_average_page_years;
	delete [] site_age_newest_page_years;
	delete [] site_age_oldest_page_years;
	delete [] site_age_average_page_months;
	delete [] site_age_newest_page_months;
	delete [] site_age_oldest_page_months;
	delete [] site_raw_content_length_mb;
	delete [] site_count_doc_map;
	delete [] site_status_map;
	free(sum_liverank);
	free(sum_authrank);
	free(sum_hubrank);
	free(sum_pagerank);
	free(age_average_page);
	free(age_newest_page);
	free(age_oldest_page);
	free(max_depth);
	free(count_doc_dynamic);
	free(count_doc_static);
	free(count_doc_date_ok);
	free(count_doc_ok);
	free(count_doc_assigned);
	free(count_doc_new);
	free(count_doc_ignored);
	free(count_doc_gathered);
	free(count_doc);
}

//
// Name: thread_function_site_statistics
//
// Description:
//   Generates statistics about sites:
//    Age of oldest page
//    Age of newest page
//    Various document counts
//    Max depth
//
// Input: pointer to void
//
// Return:
//
void *Analysis::thread_function_site_statistics(void *args)
{
	cpu_set_t system_cpus;

	thread_args_t *arguments = (thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Analysis *obj = arguments->obj;

	obj->count_doc[inst] = CBALLOC(docid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->count_doc_gathered[inst] = CBALLOC(docid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->count_doc_ignored[inst] = CBALLOC(docid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->count_doc_new[inst] = CBALLOC(docid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->count_doc_assigned[inst] = CBALLOC(docid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->count_doc_ok[inst] = CBALLOC(docid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->count_doc_date_ok[inst] = CBALLOC(docid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->count_doc_static[inst] = CBALLOC(docid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->count_doc_dynamic[inst] = CBALLOC(docid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->max_depth[inst] = CBALLOC(unsigned int *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->age_oldest_page[inst] = CBALLOC(time_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->age_newest_page[inst] = CBALLOC(time_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->age_average_page[inst] = CBALLOC(double *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->sum_pagerank[inst] = CBALLOC(pagerank_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->sum_hubrank[inst] = CBALLOC(hubrank_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->sum_authrank[inst] = CBALLOC(authrank_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	obj->sum_liverank[inst] = CBALLOC(liverank_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		obj->count_doc[inst][i] = CBALLOC(docid_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->count_doc_gathered[inst][i] = CBALLOC(docid_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->count_doc_ignored[inst][i] = CBALLOC(docid_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->count_doc_new[inst][i] = CBALLOC(docid_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->count_doc_assigned[inst][i] = CBALLOC(docid_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->count_doc_ok[inst][i] = CBALLOC(docid_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->count_doc_date_ok[inst][i] = CBALLOC(docid_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->count_doc_static[inst][i] = CBALLOC(docid_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->count_doc_dynamic[inst][i] = CBALLOC(docid_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->max_depth[inst][i] = CBALLOC(unsigned int, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->age_oldest_page[inst][i] = CBALLOC(time_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->age_newest_page[inst][i] = CBALLOC(time_t, MALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->age_average_page[inst][i] = CBALLOC(double, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->sum_pagerank[inst][i] = CBALLOC(pagerank_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->sum_hubrank[inst][i] = CBALLOC(hubrank_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->sum_authrank[inst][i] = CBALLOC(authrank_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
		obj->sum_liverank[inst][i] = CBALLOC(liverank_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
	}

	time_t now	= time(NULL);

	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			obj->age_newest_page[inst][i][((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)] = now;		// Very old, age=maximum

	// Go through the list of docs
	docid_t ndocs_div_50	= obj->ndocs / 50;

	ccerr << "Pass 1/2: read docs   |--------------------------------------------------|" << endl << "                      ";

	sync_threads(obj->barrier);

	doc_t	doc;
	siteid_t	siteid = 0;

    for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
	{
		doc.docid	= docid;
		obj->meta->doc_retrieve(&(doc));
		assert(doc.docid == docid);
		siteid = doc.siteid;
		assert(siteid > 0 && siteid <= obj->nsites);

		instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
		off64_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (ndocs_div_50 > 0 && doc.docid % ndocs_div_50 == 0)
			cerr << ".";

		// Skip ignored documents
		if (doc.status == STATUS_DOC_IGNORED)
			obj->count_doc_ignored[inst][s_inst][s_offset]++;
		else
		{
			obj->count_doc[inst][s_inst][s_offset]++;

			if (doc.is_dynamic)
{
				obj->count_doc_dynamic[inst][s_inst][s_offset]++;
			} else {
				obj->count_doc_static[inst][s_inst][s_offset]++;
			}

			// Count documents by status
			if (doc.status == STATUS_DOC_GATHERED)
				obj->count_doc_gathered[inst][s_inst][s_offset]++;
			else if (doc.status == STATUS_DOC_ASSIGNED)
				obj->count_doc_assigned[inst][s_inst][s_offset]++;
			else if (doc.status == STATUS_DOC_NEW)
				obj->count_doc_new[inst][s_inst][s_offset]++;
			else
				assert(doc.status == STATUS_DOC_EXCLUSION || doc.status == STATUS_DOC_FORBIDDEN);

			// Link scores
			obj->sum_pagerank[inst][s_inst][s_offset ]+= doc.pagerank;
			obj->sum_hubrank[inst][s_inst][s_offset] += doc.hubrank;
			obj->sum_authrank[inst][s_inst][s_offset] += doc.authrank;
			obj->sum_liverank[inst][s_inst][s_offset] += doc.liverank;

			// Only consider OK documents
			if (HTTP_IS_OK(doc.http_status))
			{
				obj->count_doc_ok[inst][s_inst][s_offset]++;
				// max depth for each instance
				if (doc.depth > obj->max_depth[inst][s_inst][s_offset])
					obj->max_depth[inst][s_inst][s_offset]	= doc.depth;

				// Only consider valid dates, i.e.:
				// they can be at most 1 day in the future,
				// considering date/time
				// 86400 = 60 secs/min x 60 mins/hr x 24 hrs/day
				if (((doc.last_modified - 86400) < doc.last_visit) && doc.last_modified > 0)
				{

					// Fix last modified time
					if (doc.last_modified > doc.last_visit)
{
						doc.last_modified = doc.last_visit;
					}

					docid_t count = obj->count_doc_date_ok[inst][s_inst][s_offset];
					obj->count_doc_date_ok[inst][s_inst][s_offset]++;

					if (count == 0)
						obj->age_average_page[inst][s_inst][s_offset] = (double)(doc.last_visit - doc.last_modified);
					else
						obj->age_average_page[inst][s_inst][s_offset] = (obj->age_average_page[inst][s_inst][s_offset] * ((double)count/(double)(count+1))) + (obj->age_average_page[inst][s_inst][s_offset] * ((double)1/(double)(count+1)));

					if (obj->age_newest_page[inst][s_inst][s_offset] > (doc.last_visit - doc.last_modified)) // This is newer
						obj->age_newest_page[inst][s_inst][s_offset] = doc.last_visit - doc.last_modified;

					if (obj->age_oldest_page[inst][s_inst][s_offset] < (doc.last_visit - doc.last_modified)) // This is older
						obj->age_oldest_page[inst][s_inst][s_offset] = doc.last_visit - doc.last_modified;
				}
			}
		}
	}

	sync_threads(obj->barrier);

	ccerr << endl;

	docid_t *_count_doc_date_ok = CBALLOC(docid_t, CALLOC, (obj->nsites + 1));

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		for (siteid_t siteid = 1; siteid <= obj->nsites; siteid++)
		{
			instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			off64_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

			_count_doc_date_ok[siteid] += obj->count_doc_date_ok[i][s_inst][s_offset];
		}

	ccerr << "Pass 2/2: write sites |--------------------------------------------------|" << endl << "                      ";

	sync_threads(obj->barrier);

	// Go through the list of docs
	siteid_t nsites_div_50 = obj->nsites/50;


	site_t site;

    for (site.siteid = (inst + 1); site.siteid <= obj->nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{

        if (nsites_div_50 > 0 && (site.siteid % nsites_div_50) == 0)
			cerr << ".";

		// Read
		siteid_t siteid = site.siteid;
		obj->meta->site_retrieve(&(site));
		assert(site.siteid == siteid);

		instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
		off64_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		site.count_doc			= 0;
		site.count_doc_ok		= 0;
		site.count_doc_gathered	= 0;
		site.count_doc_ignored	= 0;
		site.count_doc_new		= 0;
		site.count_doc_assigned	= 0;
		site.count_doc_static	= 0;
		site.count_doc_dynamic	= 0;
		site.max_depth			= 0;
		site.sum_pagerank		= 0;
		site.sum_hubrank		= 0;
		site.sum_authrank		= 0;
		site.sum_liverank		= 0;

		// Add statistics
		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			site.count_doc			+= obj->count_doc[i][s_inst][s_offset];
			site.count_doc_ok		+= obj->count_doc_ok[i][s_inst][s_offset];
			site.count_doc_gathered	+= obj->count_doc_gathered[i][s_inst][s_offset];
			site.count_doc_ignored	+= obj->count_doc_ignored[i][s_inst][s_offset];
			site.count_doc_new		+= obj->count_doc_new[i][s_inst][s_offset];
			site.count_doc_assigned	+= obj->count_doc_assigned[i][s_inst][s_offset];
			site.count_doc_static	+= obj->count_doc_static[i][s_inst][s_offset];
			site.count_doc_dynamic	+= obj->count_doc_dynamic[i][s_inst][s_offset];

			if (obj->max_depth[i][s_inst][s_offset] > site.max_depth)
				site.max_depth = obj->max_depth[i][s_inst][s_offset];

			site.sum_pagerank		+= obj->sum_pagerank[i][s_inst][s_offset];
			site.sum_hubrank		+= obj->sum_hubrank[i][s_inst][s_offset];
			site.sum_authrank		+= obj->sum_authrank[i][s_inst][s_offset];
			site.sum_liverank		+= obj->sum_liverank[i][s_inst][s_offset];
		}

		if (_count_doc_date_ok[siteid] > (docid_t)0)
		{
			for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			{
				site.age_oldest_page	+= obj->age_oldest_page[i][s_inst][s_offset];
				site.age_newest_page	+= obj->age_newest_page[i][s_inst][s_offset];
				site.age_average_page	+= (time_t)(obj->age_average_page[i][s_inst][s_offset]);
			}

			obj->site_age_oldest_page_months[inst][(site.age_oldest_page / 2592000)]++;
			obj->site_age_newest_page_months[inst][(site.age_newest_page / 2592000)]++;
			obj->site_age_average_page_months[inst][(site.age_average_page / 2592000)]++;

			obj->site_age_oldest_page_years[inst][(site.age_oldest_page / 31536000)]++;
			obj->site_age_newest_page_years[inst][(site.age_newest_page / 31536000)]++;
			obj->site_age_average_page_years[inst][(site.age_average_page / 31536000)]++;

			obj->nsites_age_valid[inst]++;

			media_<double, time_t, siteid_t>(obj->media_age_oldest_page_months[inst], (site.age_oldest_page / 2592000), obj->nsites_ok[inst]);
			media_<double, time_t, siteid_t>(obj->media_age_newest_page_months[inst], (site.age_newest_page / 2592000), obj->nsites_ok[inst]);
			media_<double, time_t, siteid_t>(obj->media_age_average_page_months[inst], (site.age_average_page / 2592000), obj->nsites_ok[inst]);
		}
		else
		{
			site.age_oldest_page	= 0;
			site.age_newest_page	= 0;
			site.age_average_page	= 0;
		}

		// Write
		obj->meta->site_store(&(site));

		// Get site statistics
		obj->site_status_map[inst][(obj->meta->site_option_get(site.siteid, SITE_OPT_NEW, true) == METADDX_OK ? SITE_OPT_NEW : SITE_OPT_FALSE)]++;

		if (site.count_doc_ok >= 1)
		{
			obj->nsites_ok[inst]++;

			obj->site_count_doc_map[inst][site.count_doc]++;
			obj->site_raw_content_length_mb[inst][((unsigned int)rint((off64_t)site.raw_content_length / (off64_t)1048576))]++;

			obj->site_internal_links[inst][site.internal_links]++;

			unsigned int internal_links_by_ndocs = 0;

			if (site.count_doc_ok > 0)
				internal_links_by_ndocs = (unsigned int)rint((double)site.internal_links * (double)10 / (double)site.count_doc_ok);

			obj->site_internal_links_by_ndocs[inst][internal_links_by_ndocs]++; 
			obj->site_in_degree[inst][site.in_degree]++;
			obj->site_out_degree[inst][site.out_degree]++;
			obj->site_max_depth[inst][site.max_depth]++;

			// Sum of link scores
			obj->site_sum_pagerank[inst][(ROUND_DOUBLE(site.sum_pagerank))]++;
			obj->site_sum_hubrank[inst][(ROUND_DOUBLE(site.sum_hubrank))]++;
			obj->site_sum_authrank[inst][(ROUND_DOUBLE(site.sum_authrank))]++;
			obj->site_sum_liverank[inst][(ROUND_DOUBLE(site.sum_authrank))]++;
			obj->site_siterank[inst][(ROUND_DOUBLE(site.siterank))]++;

			// Calculate sums for summary stats
			obj->sum_count_doc[inst]				+= site.count_doc;
			obj->sum_count_doc_static[inst]			+= site.count_doc_static;
			media<double, docid_t, siteid_t>(obj->media_in_degree[inst], site.in_degree, obj->nsites_ok[inst]);
			media<double, docid_t, siteid_t>(obj->media_out_degree[inst], site.out_degree, obj->nsites_ok[inst]);
			media<double, docid_t, siteid_t>(obj->media_internal_links[inst], site.internal_links, obj->nsites_ok[inst]);
			media_<double, off64_t, siteid_t>(obj->media_raw_content_length_mb[inst], ((off64_t)site.raw_content_length / (off64_t)1048576), obj->nsites_ok[inst]);
			media<double, unsigned short, siteid_t>(obj->media_max_depth[inst], site.max_depth, obj->nsites_ok[inst]);
		}
	}

	free(_count_doc_date_ok);

	sync_threads(obj->barrier);

	// Create dated directory for output
	ccerr << endl << "* Writing summary statistics" << endl;

	instance_t step_counter = obj->static_random_inst;

	char basename[MAX_STR_LEN];
	char filename[MAX_STR_LEN];
	FILE *output;

	strcpy(basename, "site");

	sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);
	createdir(filename);

	// Create dated directory for output
	ccerr << "Output dir    : " << filename << endl;

	sync_threads(obj->barrier);

	// free unneeded memory
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		free(obj->sum_liverank[inst][i]);
		free(obj->sum_authrank[inst][i]);
		free(obj->sum_hubrank[inst][i]);
		free(obj->sum_pagerank[inst][i]);
		free(obj->age_average_page[inst][i]);
		free(obj->age_newest_page[inst][i]);
		free(obj->age_oldest_page[inst][i]);
		free(obj->max_depth[inst][i]);
		free(obj->count_doc_dynamic[inst][i]);
		free(obj->count_doc_static[inst][i]);
		free(obj->count_doc_date_ok[inst][i]);
		free(obj->count_doc_ok[inst][i]);
		free(obj->count_doc_assigned[inst][i]);
		free(obj->count_doc_new[inst][i]);
		free(obj->count_doc_ignored[inst][i]);
		free(obj->count_doc_gathered[inst][i]);
		free(obj->count_doc[inst][i]);
	}

	free(obj->sum_liverank[inst]);
	free(obj->sum_authrank[inst]);
	free(obj->sum_hubrank[inst]);
	free(obj->sum_pagerank[inst]);
	free(obj->age_average_page[inst]);
	free(obj->age_newest_page[inst]);
	free(obj->age_oldest_page[inst]);
	free(obj->max_depth[inst]);
	free(obj->count_doc_dynamic[inst]);
	free(obj->count_doc_static[inst]);
	free(obj->count_doc_date_ok[inst]);
	free(obj->count_doc_ok[inst]);
	free(obj->count_doc_assigned[inst]);
	free(obj->count_doc_new[inst]);
	free(obj->count_doc_ignored[inst]);
	free(obj->count_doc_gathered[inst]);
	free(obj->count_doc[inst]);

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		// Summary
		sprintf(filename, "%s/%s/site_summary.csv", COLLECTION_ANALYSIS, basename);
		mcerr << "- Summary info -> " << filename << mendl;
		output = fopen64(filename, "w");

		char buffer[MAX_STR_LEN];
		int wc = 0;
		docid_t sum_count_doc = adder<docid_t>(obj->sum_count_doc);
		docid_t sum_count_doc_static = adder<docid_t>(obj->sum_count_doc_static);
		siteid_t nsites_ok = adder<siteid_t>(obj->nsites_ok);

		wc = snprintf(buffer, MAX_STR_LEN, "Number of sites ok,%lu\n", (unsigned long int)nsites_ok);

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Number of sites with valid page age,%lu\n", (unsigned long int)adder<siteid_t>(obj->nsites_age_valid));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average pages per site,%e\n", ((double)sum_count_doc / (double)nsites_ok));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average static pages per site,%e\n", ((double)sum_count_doc_static / (double)nsites_ok));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average dynamic pages per site,%e\n", ((double)(sum_count_doc - sum_count_doc_static) / (double)nsites_ok));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average of age of oldest page in months,%e\n", joinmedia<siteid_t>(obj->media_age_oldest_page_months, obj->nsites_age_valid));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average of age of newest page in months,%e\n", joinmedia<siteid_t>(obj->media_age_newest_page_months, obj->nsites_age_valid));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average of age of average page in months,%e\n", joinmedia<siteid_t>(obj->media_age_average_page_months, obj->nsites_age_valid));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average in-degree,%e\n", joinmedia<siteid_t>(obj->media_in_degree, obj->nsites_ok));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average out-degree,%e\n", joinmedia<siteid_t>(obj->media_out_degree, obj->nsites_ok));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average internal links,%e\n", joinmedia<siteid_t>(obj->media_internal_links, obj->nsites_ok));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average site size in MB,%e\n", joinmedia<siteid_t>(obj->media_raw_content_length_mb, obj->nsites_ok));

		if (wc >= 0 && wc < MAX_STR_LEN)
			wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "Average site max depth,%e\n", joinmedia<siteid_t>(obj->media_max_depth, obj->nsites_ok));

		fprintf(output, "%s", buffer);

		fclose(output);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Age oldest page
		sprintf(filename, "%s/%s/site_status.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Site status -> " << filename << mendl;

		map<site_optmask_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_status_map[i])
				_map[it.first] += it.second;

			obj->site_status_map[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Site status,Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				//string Status = SITE_STATUS_STR(it.second);
				string Status = (it.first == SITE_OPT_NEW ? "STATUS_SITE_NEW" : "STATUS_SITE_VISITED");
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Status' or 'Fraction' in chars is twelve (with scientific output)

				line_len += Status.size();

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%s,%lu,%e\n", Status.c_str(), (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%s,%lu,%e\n", Status.c_str(), (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

	//	_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Age oldest page
		sprintf(filename, "%s/%s/site_count_doc.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Site doc count -> " << filename << mendl;

		map<docid_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_count_doc_map[i])
				_map[it.first] += it.second;

			obj->site_count_doc_map[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Site doc count,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				docid_t Count_doc = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Count_doc' or 'Fraction' in chars is twelve (with scientific output)

				while (Count_doc > 1 && (Count_doc /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Count_doc = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%lu,%lu,%e\n", (unsigned long int)Count_doc, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%lu,%lu,%e\n", (unsigned long int)Count_doc, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Age oldest page
		sprintf(filename, "%s/%s/site_raw_content_length_mb.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Raw content length in MB -> " << filename << mendl;

		map<unsigned int, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_raw_content_length_mb[i])
				_map[it.first] += it.second;

			obj->site_raw_content_length_mb[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Raw content length in MB,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				unsigned int Raw_content_length_mb = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Raw_content_length_mb' or 'Fraction' in chars is twelve (with scientific output)

				while (Raw_content_length_mb > 1 && (Raw_content_length_mb /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Raw_content_length_mb = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%d,%lu,%e\n", Raw_content_length_mb, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%d,%lu,%e\n", Raw_content_length_mb, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Age oldest page
		sprintf(filename, "%s/%s/site_age_oldest_page_months.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Age oldest page months -> " << filename << mendl;

		map<time_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_age_oldest_page_months[i])
				_map[it.first] += it.second;

			obj->site_age_oldest_page_months[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Age oldest page in months,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				time_t Age_old_page_months = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Age_old_page_months' or 'Fraction' in chars is twelve (with scientific output)

				while (Age_old_page_months > 1 && (Age_old_page_months /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Age_old_page_months = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%lu,%lu,%e\n", Age_old_page_months, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%lu,%lu,%e\n", Age_old_page_months, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Age newest page
		sprintf(filename, "%s/%s/site_age_newest_page_months.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Age newest page months -> " << filename << mendl;

		map<time_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_age_newest_page_months[i])
				_map[it.first] += it.second;

			obj->site_age_newest_page_months[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Age newest page in months,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				time_t Age_new_page_months = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Age_new_page_months' or 'Fraction' in chars is twelve (with scientific output)

				while (Age_new_page_months > 1 && (Age_new_page_months /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Age_new_page_months = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%lu,%lu,%e\n", Age_new_page_months, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%lu,%lu,%e\n", Age_new_page_months, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Age average page
		sprintf(filename, "%s/%s/site_age_average_page_months.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Age average page months -> " << filename << mendl;

		map<time_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_age_average_page_months[i])
				_map[it.first] += it.second;

			obj->site_age_average_page_months[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Age average page in months,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				time_t Age_avg_page_months = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Age_avg_page_months' or 'Fraction' in chars is twelve (with scientific output)

				while (Age_avg_page_months > 1 && (Age_avg_page_months /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Age_avg_page_months = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%lu,%lu,%e\n", Age_avg_page_months, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%lu,%lu,%e\n", Age_avg_page_months, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Age oldest page
		sprintf(filename, "%s/%s/site_age_oldest_page_years.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Age oldest page years -> " << filename << mendl;

		map<time_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_age_oldest_page_years[i])
				_map[it.first] += it.second;

			obj->site_age_oldest_page_years[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Age oldest page in years,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				time_t Age_old_page_years = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Age_old_page_years' or 'Fraction' in chars is twelve (with scientific output)

				while (Age_old_page_years > 1 && (Age_old_page_years /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Age_old_page_years = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%lu,%lu,%e\n", Age_old_page_years, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%lu,%lu,%e\n", Age_old_page_years, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Age newest page
		sprintf(filename, "%s/%s/site_age_newest_page_years.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Age newest page years -> " << filename << mendl;

		map<time_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_age_newest_page_years[i])
				_map[it.first] += it.second;

			obj->site_age_newest_page_years[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Age newest page in years,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				time_t Age_new_page_years = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Age_new_page_years' or 'Fraction' in chars is twelve (with scientific output)

				while (Age_new_page_years > 1 && (Age_new_page_years /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Age_new_page_years = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%lu,%lu,%e\n", Age_new_page_years, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%lu,%lu,%e\n", Age_new_page_years, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Age average page
		sprintf(filename, "%s/%s/site_age_average_page_years.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Age average page years -> " << filename << mendl;

		map<time_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_age_average_page_years[i])
				_map[it.first] += it.second;

			obj->site_age_average_page_years[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Age average page in years,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				time_t Age_avg_page_years = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Age_avg_page_years' or 'Fraction' in chars is twelve (with scientific output)

				while (Age_avg_page_years > 1 && (Age_avg_page_years /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Age_avg_page_years = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%lu,%lu,%e\n", (unsigned long int)Age_avg_page_years, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%lu,%lu,%e\n", (unsigned long int)Age_avg_page_years, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Internal links
		sprintf(filename, "%s/%s/site_internal_links.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w");

		mcerr << "- Internal links -> " << filename << mendl;

		map<docid_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_internal_links[i])
				_map[it.first] += it.second;

			obj->site_internal_links[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Internal links,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				docid_t Int_links = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Int_links' or 'Fraction' in chars is twelve (with scientific output)

				while (Int_links > 1 && (Int_links /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Int_links = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%lu,%lu,%e\n", (unsigned long int)Int_links, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%lu,%lu,%e\n", (unsigned long int)Int_links, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Internal links by ndocs
		sprintf(filename, "%s/%s/site_internal_links_by_ndocs.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Internal links by ndocs -> " << filename << mendl;

		map<unsigned int, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_internal_links_by_ndocs[i])
				_map[(it.first)] += it.second;

			obj->site_internal_links_by_ndocs[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Internal links by page,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				double Int_links_by_ndocs = (((double)it.first) / (double)10);
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 28; // max length of 'Int_links_by_ndocs' or 'Fraction' in chars is twelve (with scientific output)

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%e,%lu,%e\n", Int_links_by_ndocs, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%e,%lu,%e\n", Int_links_by_ndocs, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// In degree
		sprintf(filename, "%s/%s/site_in_degree.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Incoming links -> " << filename << mendl;

		map<siteid_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_in_degree[i])
				_map[it.first] += it.second;

			obj->site_in_degree[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Incoming links,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				siteid_t In_degree = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'In_degree' or 'Fraction' in chars is twelve (with scientific output)

				while (In_degree > 1 && (In_degree /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				In_degree = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%lu,%lu,%e\n", (unsigned long int)In_degree, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%lu,%lu,%e\n", (unsigned long int)In_degree, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Out degree
		sprintf(filename, "%s/%s/site_out_degree.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Outgoing links -> " << filename << mendl;

		map<siteid_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_out_degree[i])
				_map[it.first] += it.second;

			obj->site_out_degree[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Outgoing links,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				siteid_t Out_degree = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Out_degree' or 'Fraction' in chars is twelve (with scientific output)

				while (Out_degree > 1 && (Out_degree /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Out_degree = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%lu,%lu,%e\n", (unsigned long int)Out_degree, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%lu,%lu,%e\n", (unsigned long int)Out_degree, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Max depth
		sprintf(filename, "%s/%s/site_max_depth.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Max depth -> " << filename << mendl;

		map<depth_t, siteid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_max_depth[i])
				_map[it.first] += it.second;

			obj->site_max_depth[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Max depth,(unsigned long int)Sites,Fraction of Sites to total sites\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				depth_t Max_depth = it.first;
				siteid_t Sites = it.second;
				double Fraction = ((double)Sites / (double)obj->nsites);

				size_t line_len = 17; // max length of 'Max_depth' or 'Fraction' in chars is twelve (with scientific output)

				while (Max_depth > 1 && (Max_depth /= 10))
					line_len++;

				while (Sites > 1 && (Sites /= 10))
					line_len++;

				Max_depth = it.first;
				Sites = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%d,%lu,%e\n", Max_depth, (unsigned long int)Sites, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%d,%lu,%e\n", Max_depth, (unsigned long int)Sites, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Pagerank
		sprintf(filename, "%s/%s/sum_pagerank.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Sum of Pagerank > " << filename << mendl;

		map<double,docid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_sum_pagerank[i])
				_map[it.first] += it.second;

			obj->site_sum_pagerank[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Sum of Pagerank,Documents,Fraction of Documents to total documents\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				double Pagerank_sum = it.first;
				docid_t Documents = it.second;
				double Fraction = ((double)Documents / (double)obj->ndocs);

				size_t line_len = 28; // max length of 'Pagerank_sum' or 'Fraction' in chars is twelve (with scientific output)

				while (Documents > 1 && (Documents /= 10))
					line_len++;

				Documents = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%e,%lu,%e\n", Pagerank_sum, (unsigned long int)Documents, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%e,%lu,%e\n", Pagerank_sum, (unsigned long int)Documents, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Hubrank
		sprintf(filename, "%s/%s/sum_hubrank.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Sum of Hubrank > " << filename << mendl;

		map<double,docid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_sum_hubrank[i])
				_map[it.first] += it.second;

			obj->site_sum_hubrank[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Sum of Hubrank,(unsigned long int)Documents,Fraction of Documents to total documents\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				double Hubrank_sum = it.first;
				docid_t Documents = it.second;
				double Fraction = ((double)Documents / (double)obj->ndocs);

				size_t line_len = 28; // max length of 'Hubrank_sum' or 'Fraction' in chars is twelve (with scientific output)

				while (Documents > 1 && (Documents /= 10))
					line_len++;

				Documents = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%e,%lu,%e\n", Hubrank_sum, (unsigned long int)Documents, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%e,%lu,%e\n", Hubrank_sum, (unsigned long int)Documents, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Authrank
		sprintf(filename, "%s/%s/sum_authrank.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Sum of Authrank > " << filename << mendl;

		map<double,docid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_sum_authrank[i])
				_map[it.first] += it.second;

			obj->site_sum_authrank[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Sum of Authrank,(unsigned long int)Documents,Fraction of Documents to total documents\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				double Authrank_sum = it.first;
				docid_t Documents = it.second;
				double Fraction = ((double)Documents / (double)obj->ndocs);

				size_t line_len = 28; // max length of 'Authrank_sum' or 'Fraction' in chars is twelve (with scientific output)

				while (Documents > 1 && (Documents /= 10))
					line_len++;

				Documents = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%e,%lu,%e\n", Authrank_sum, (unsigned long int)Documents, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%e,%lu,%e\n", Authrank_sum, (unsigned long int)Documents, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Liverank
		sprintf(filename, "%s/%s/sum_liverank.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Sum of Liverank > " << filename << mendl;

		map<double,docid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_sum_liverank[i])
				_map[it.first] += it.second;

			obj->site_sum_liverank[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Sum of Liverank,(unsigned long int)Documents,Fraction of Documents to total documents\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				double Liverank_sum = it.first;
				docid_t Documents = it.second;
				double Fraction = ((double)Documents / (double)obj->ndocs);

				size_t line_len = 28; // max length of 'Liverank_sum' or 'Fraction' in chars is twelve (with scientific output)

				while (Documents > 1 && (Documents /= 10))
					line_len++;

				Documents = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%e,%lu,%e\n", Liverank_sum, (unsigned long int)Documents, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%e,%lu,%e\n", Liverank_sum, (unsigned long int)Documents, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	step_counter++;

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Siterank
		sprintf(filename, "%s/%s/siterank.csv", COLLECTION_ANALYSIS, basename);
		output = fopen64(filename, "w+");

		mcerr << "- Siterank > " << filename << mendl;

		map<double,docid_t> _map;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			for (auto &it : obj->site_siterank[i])
				_map[it.first] += it.second;

			obj->site_siterank[i].clear();
		}

		written = snprintf(pbuffer, space_left, "Siterank,Documents,Fraction of Documents to total documents\n");

		for (auto &it : _map)
			if (it.first > 0)
			{
				double Siterank = it.first;
				docid_t Documents = it.second;
				double Fraction = ((double)Documents / (double)obj->ndocs);

				size_t line_len = 28; // max length of 'Siterank' or 'Fraction' in chars is twelve (with scientific output)

				while (Documents > 1 && (Documents /= 10))
					line_len++;

				Documents = it.second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left,  "%e,%lu,%e\n", Siterank, (unsigned long int)Documents, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written,  "%e,%lu,%e\n", Siterank, (unsigned long int)Documents, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		_map.clear();

		fclose(output);
		free(pbuffer);
	}

	return NULL;
}

//
// Name: thread_function_caller
//
// Description:
//   A proxy function to pass non-static function at pthread_create
//   Note: function called by thread_function_caller need to have real class object passed through args
//
// Input:
//   args - void arguments
//
// Return:
//   pointer to void
//
void *AnalysisManager::thread_function_caller(void *args)
{
	assert(args);

	AnalysisManager::thread_args_t *arguments = (AnalysisManager::thread_args_t *)args;

try
{
	bool virtual_opt_dont_generate = false;

	// Note function called work to 'this' temporary object and need to be deleted at the end of the same.
	AnalysisManager *newObj = NULL;

	try
	{
		newObj = new AnalysisManager (NULL, NULL, NULL, NULL, virtual_opt_dont_generate);
	}
	catch (std::bad_alloc &ba)
	{
		die("Analysis thread_function_caller: bad_alloc caught %s", ba.what());
	}

	switch (arguments->f)
	{
		case ANALYSIS_CALCULATE_SCORES:
			newObj->thread_function_calculate_scores(args);
			break;
		default:
			delete newObj;
			return NULL;
	}

	delete newObj;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(arguments->obj->barrier); 
}

	// Each thread must exit with 'pthread_barrier_wait'
	// in normal condition
	if (arguments->obj->barrier)
	{
		int rc = pthread_barrier_wait(arguments->obj->barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	free(args);
	args = NULL;

	return NULL;
}

// threads sync
void AnalysisManager::sync_threads(pthread_barrier_t *barrier) const
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc = pthread_barrier_wait(barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
		pthread_exit(NULL);
}

//
// Name: calculate_scores
//
// Description:
//   Calculates all scores for harvesting
//
// Input:
//
// Output:
//   doc.freshness - freshness
//
void AnalysisManager::calculate_scores(void)
{
	int rc = 0;

	assert(meta != NULL);
	assert(priority != NULL);
	assert(order != NULL);
	assert(docid_to_siteid != NULL);

	ndocs	= meta->doc_count();
	assert(ndocs > 0);
	nsites	= meta->site_count();
	assert(nsites > 0);

	// Load site data if necessary
	if (CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0)
		siterank = CBALLOC(siterank_t, CALLOC, (nsites + 1));

	// Manipolate queuesize if required
	if (CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
	{
		queuesize = CBALLOC(docid_t, CALLOC, (nsites + 1));
		max_queue_size = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	}

	skipped_successful_and_ok = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	skipped_successful_but_not_ok = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	skipped_unsuccessful = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	skipped_exclusion = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	skipped_forbidden = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	skipped_ignored = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	skipped_depth = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	skipped_other = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	nsites_too_many_errors = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	nsites_data = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	nsites_assigned = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	if (opt_dont_generate == false)
	{
		// Prepare class to sort by priority
		// Note: we move offset ahead to one because docid == 0 DO NOT EXIST
		const priority_t skip_count = 1;
		sortp = new CBotSort<priority_t, docid_t> (priority, order, ndocs, 0, skip_count, NULL, false, false, false);
		sortp->barrier_init();
	}

	pthread_mutexattr_t attr;

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		thread_args_t *args = CBALLOC(thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = ANALYSIS_CALCULATE_SCORES;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_calculate_scores((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	cerr << "ok." << endl;

	cerr << "- Total number of sites           : " << nsites << endl;
	cerr << "- Sites with too many errors      : " << adder<siteid_t>(nsites_too_many_errors) << endl;
	cerr << "- Sites that have transfered data : " << adder<siteid_t>(nsites_data) << endl;
	cerr << "- Sites assigned to other harvest : " << adder<siteid_t>(nsites_assigned) << endl;
	cerr << endl;

	// Report totals

	cerr << "Pages that are being excluded, because they were visited not long ago:" << endl;
	cerr << "- Successfully downloaded and HTTP OK (code 200)     : " << adder<docid_t>(skipped_successful_and_ok) << endl;
	cerr << "- Successfully downloaded but not ok (code 400, 500) : " << adder<docid_t>(skipped_successful_but_not_ok) << endl;
	cerr << "- Not successfully downloaded (errors)               : " << adder<docid_t>(skipped_unsuccessful) << endl;
	cerr << "Pages that are being excluded for other reasons:" << endl;
	cerr << "- Administratively deny                              : " << adder<docid_t>(skipped_exclusion) << endl;
	cerr << "- Robots exclusion protocol                          : " << adder<docid_t>(skipped_forbidden) << endl;
	cerr << "- Too deep                                           : " << adder<docid_t>(skipped_depth) << endl;
	cerr << "- Marked as ignored                                  : " << adder<docid_t>(skipped_ignored) << endl;
	cerr << "- Other reasons (normally this is zero)              : " << adder<docid_t>(skipped_other) << endl;

	docid_t total_excluded = adder<docid_t>(skipped_successful_and_ok) +
							 adder<docid_t>(skipped_successful_but_not_ok) +
							 adder<docid_t>(skipped_unsuccessful) +
							 adder<docid_t>(skipped_exclusion) +
							 adder<docid_t>(skipped_forbidden) +
							 adder<docid_t>(skipped_ignored) +
							 adder<docid_t>(skipped_depth) +
							 adder<docid_t>(skipped_other);

	cerr << "Totals:" << endl;
	cerr << "- Excluded from being assigned    : " << total_excluded << endl;
	cerr << "- Included in possible assignment : " << (ndocs - total_excluded) << endl;
	cerr << "- Total pages in the collection   : " << ndocs << endl;
	cerr << "- Total without ignored pages     : " << (ndocs - adder<docid_t>(skipped_ignored)) << endl;
	cerr << endl;

	if (opt_dont_generate == false)
		delete sortp;

	free(nsites_assigned);
	free(nsites_data);
	free(nsites_too_many_errors);
	free(skipped_other);
	free(skipped_depth);
	free(skipped_ignored);
	free(skipped_exclusion);
	free(skipped_forbidden);
	free(skipped_unsuccessful);
	free(skipped_successful_but_not_ok);
	free(skipped_successful_and_ok);

	if (CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0)
		free(siterank);

	if (CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
	{
		free(max_queue_size);
		free(queuesize);
	}

}

//
// Name: thread_function_calculate_scores
//
// Description:
//   Calculates the present and future score of each document
//

void *AnalysisManager::thread_function_calculate_scores(void *args)
{
	cpu_set_t system_cpus;

	thread_args_t *arguments = (thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    AnalysisManager *obj = arguments->obj;


	sync_threads(obj->barrier);

	internal_long_uint_t conf_manager_minperiod_forbidden = 0;
	internal_long_uint_t conf_manager_minperiod_unsuccessful = 0;
	internal_long_uint_t conf_manager_minperiod_successful_but_not_ok = 0;
	internal_long_uint_t conf_manager_minperiod_successful_and_ok = 0;

	time_t now = time(NULL);

	site_t site;

	docid_t _max_queue_size = 0;

	for (site.siteid = (inst + 1); site.siteid <= obj->nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{

		// Load the data from the site
		obj->meta->site_retrieve(&(site));

		if (CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0)
			obj->siterank[site.siteid] = site.siterank;

		if (CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
		{
			obj->queuesize[site.siteid] = (site.count_doc - (site.count_doc_ok - site.count_error));

			if (obj->queuesize[site.siteid] > obj->max_queue_size[inst])
				obj->max_queue_size[inst] = obj->queuesize[site.siteid];
		}

		if (site.count_error > CONF_MAX_ERRORS_DIFFERENT_BATCH)
			obj->nsites_too_many_errors[inst]++;

		if (site.raw_content_length > 0)
			obj->nsites_data[inst]++;

		if (site.harvest_id > 0)
			obj->nsites_assigned[inst]++;
	}

	sync_threads(obj->barrier);

	if (CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
	{
		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			if (obj->max_queue_size[inst] > _max_queue_size)
				_max_queue_size = obj->max_queue_size[inst];
	}

	sp->reset(inst);

	// Normalize queuesize
	if (CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0 && _max_queue_size > 0)
		for (site.siteid = (inst + 1); site.siteid <= obj->nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
			obj->queuesize[site.siteid] /= _max_queue_size;

	sync_threads(obj->barrier);

	// Iterate documents
	if (sp->go_ahead(inst) == true)
	{
		cerr << endl;
		cerr << "Iterating through " << obj->ndocs << " documents in the collection" << endl;
		cerr << "Calculating scores |--------------------------------------------------|" << endl;
		cerr << "                   ";
	}

	docid_t ndocs_div_50 = ndocs / 50;

	// Documents
	doc_t doc;

	for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
	{
		// Report
		if (ndocs_div_50 > 0 && docid % ndocs_div_50 == 0)
			cerr << ".";

		doc.docid = docid;
		obj->meta->doc_retrieve(&(doc));
		assert(doc.docid == docid);


		// Save siteid in a cache of siteids
		assert(obj->docid_to_siteid[docid] == 0);
		obj->docid_to_siteid[docid] = doc.siteid;

		// It's not necessary to calculate
		// scores for all documents, some documents will have priority=-1 (min)

		// Skip documents that were succesfully fetched not long ago
		// The condition doc.last_visit is because it could have been
		// reported as modified by sitemap.rdf/sitemap.xml file.
		// The harvester NEVER saves a last_modified date in the
		// future, even if the Web server provides a date in the future

		double diff_time = difftime(now,doc.last_visit);

		if (doc.mime_type == MIME_ROBOTS_TXT)
		{
			obj->priority[doc.docid] = (priority_t)(-1);
			continue;
		}
		else if (doc.mime_type == MIME_ROBOTS_RDF || doc.mime_type == MIME_ROBOTS_RDF_BROKEN)
		{
			obj->priority[doc.docid] = (priority_t)(-1);
			continue;
		}
		else if (doc.mime_type == MIME_ROBOTS_XML
				|| doc.mime_type == MIME_ROBOTS_XML_GZ
				|| doc.mime_type == MIME_ROBOTS_XML_BROKEN)
		{
			conf_manager_minperiod_forbidden = CONF_MANAGER_MINPERIOD_FORBIDDEN;
			conf_manager_minperiod_unsuccessful = CONF_MANAGER_MINPERIOD_UNSUCCESSFUL;
			conf_manager_minperiod_successful_but_not_ok = CONF_MANAGER_MINPERIOD_ROBOTS_XML_NOT_VALID;
			conf_manager_minperiod_successful_and_ok = CONF_MANAGER_MINPERIOD_ROBOTS_XML_VALID;

			if (obj->meta->site_option_get(doc.siteid, SITE_OPT_DENY, true) == METADDX_OK) // site administratively excluded/deny
			{
				obj->priority[doc.docid] = (priority_t)(-1);
				obj->skipped_successful_and_ok[inst]++;
			}
			else if (doc.status == STATUS_DOC_EXCLUSION) // docid administratively excluded/deny
			{
					obj->priority[doc.docid] = (priority_t)(-1);
					obj->skipped_successful_and_ok[inst]++;
			}
			else if (doc.status == STATUS_DOC_FORBIDDEN) // forbidden by robots.txt and maybe also without visit page therefore without 'http_status'
			{
				if (diff_time < conf_manager_minperiod_forbidden) // five is an arbitrary value
				{
					obj->priority[doc.docid] = (priority_t)(-1);
					obj->skipped_forbidden[inst]++;
				}
				else // Calculate scores
				{
					if	(CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0 && CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
						obj->doc_calculate_scores(&(doc), obj->siterank[doc.siteid], queuesize[doc.siteid]);
					else if (CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0)
						obj->doc_calculate_scores(&(doc), obj->siterank[doc.siteid], (docid_t)0);
					else if	(CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
						obj->doc_calculate_scores(&(doc), (siterank_t)0, queuesize[doc.siteid]);
					else
						obj->doc_calculate_scores(&(doc), (siterank_t)0, (docid_t)0);

					// Save the scores
					obj->meta->doc_store(&(doc));

					obj->priority[doc.docid] = (doc.future_score - doc.current_score);

					if (obj->priority[doc.docid] == (priority_t)(-1))
						obj->skipped_other[inst]++;
				}
			}
			else
			{

				if ((diff_time < conf_manager_minperiod_successful_and_ok)
					&& HTTP_IS_OK(doc.http_status)
					&& doc.last_visit >= doc.last_modified)
				{
					obj->priority[doc.docid] = (priority_t)(-1);
					obj->skipped_successful_and_ok[inst]++;
				}
				else if ((diff_time < conf_manager_minperiod_successful_but_not_ok)
					&& HTTP_IS_OK(doc.http_status)
					&& doc.has_valid_mimetype == false
					&& doc.last_visit >= doc.last_modified)
				{
					obj->priority[doc.docid] = (priority_t)(-1);
					obj->skipped_successful_but_not_ok[inst]++;
				}
				else if ((diff_time  < conf_manager_minperiod_successful_but_not_ok)
					&& (!HTTP_IS_OK(doc.http_status))
					&& (!HTTP_IS_ERROR(doc.http_status))
					&& (!HTTP_IS_UNDEF(doc.http_status))
					&& doc.last_visit >= doc.last_modified)
				{
					obj->priority[doc.docid] = (priority_t)(-1);
					obj->skipped_successful_but_not_ok[inst]++;
				}
				else if ((diff_time < conf_manager_minperiod_unsuccessful)
					&& HTTP_IS_ERROR(doc.http_status)
					&& (doc.http_status != HTTP_ERROR_SKIPPED)
					&& doc.last_visit >= doc.last_modified)
				{
					obj->priority[doc.docid] = (priority_t)(-1);
					obj->skipped_unsuccessful[inst]++;
				}
				else if (doc.status == STATUS_DOC_EXCLUSION) // Check if this is excluded
				{
					obj->priority[doc.docid] = (priority_t)(-1);
					obj->skipped_exclusion[inst]++;
				}
				else if (doc.status == STATUS_DOC_IGNORED) // Check if this must be ignored
				{
					obj->priority[doc.docid] = (priority_t)(-1);
					obj->skipped_ignored[inst]++;
				}
				else if (doc.depth > (doc.is_dynamic ? CONF_MANAGER_MAXDEPTH_DYNAMIC : CONF_MANAGER_MAXDEPTH_STATIC)) // Check if its too deep
				{
					obj->priority[doc.docid] = (priority_t)(-1);
					obj->skipped_depth[inst]++;

				}
				else // Calculate scores
				{
					if	(CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0 && CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
						obj->doc_calculate_scores(&(doc), obj->siterank[doc.siteid], queuesize[doc.siteid]);
					else if (CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0)
						obj->doc_calculate_scores(&(doc), obj->siterank[doc.siteid], (docid_t)0);
					else if	(CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
						obj->doc_calculate_scores(&(doc), (siterank_t)0, queuesize[doc.siteid]);
					else
						obj->doc_calculate_scores(&(doc), (siterank_t)0, (docid_t)0);

					// Save the scores
					obj->meta->doc_store(&(doc));

					obj->priority[doc.docid] = (doc.future_score - doc.current_score);

					if (obj->priority[doc.docid] == (priority_t)(-1))
						obj->skipped_other[inst]++;
				}
			}

			continue;
		}

		int delta = 0; // now per non lasciarlo vuoto

		if (doc.sitemap_changefreq == HOURLY)
			delta = 3600;
		else if (doc.sitemap_changefreq == DAILY)
			delta = 86400;
		else if (doc.sitemap_changefreq == WEEKLY)
			delta = 604800;
		else if (doc.sitemap_changefreq == MONTHLY) // 30 giorni
			delta = 2592000;
		else if (doc.sitemap_changefreq == YEARLY) // 365 giorni
			delta = 31536000;

		if (doc.mime_type == MIME_FEEDS_ATOM_XML
			|| doc.mime_type == MIME_FEEDS_ATOM_XML_GZ
			|| doc.mime_type == MIME_FEEDS_ATOM_XML_BROKEN
			|| doc.mime_type == MIME_FEEDS_RSS_XML
			|| doc.mime_type == MIME_FEEDS_RSS_XML_GZ
			|| doc.mime_type == MIME_FEEDS_RSS_XML_BROKEN)
		{
			conf_manager_minperiod_forbidden = CONF_MANAGER_MINPERIOD_FEEDS_FORBIDDEN;
			conf_manager_minperiod_unsuccessful = CONF_MANAGER_MINPERIOD_FEEDS_UNSUCCESSFUL;
			conf_manager_minperiod_successful_but_not_ok = CONF_MANAGER_MINPERIOD_FEEDS_SUCCESSFUL_BUT_NOT_OK;

			if (delta > 0)
				conf_manager_minperiod_successful_and_ok = delta;
			else
				conf_manager_minperiod_successful_and_ok = CONF_MANAGER_MINPERIOD_FEEDS_SUCCESSFUL_AND_OK;
		}
		else
		{
			conf_manager_minperiod_forbidden = CONF_MANAGER_MINPERIOD_FORBIDDEN;
			conf_manager_minperiod_unsuccessful = CONF_MANAGER_MINPERIOD_UNSUCCESSFUL;
			conf_manager_minperiod_successful_but_not_ok = CONF_MANAGER_MINPERIOD_SUCCESSFUL_BUT_NOT_OK;

			if (delta > 0)
				conf_manager_minperiod_successful_and_ok = delta;
			else if (doc.liverank > 0 &&
				CONF_MANAGER_MINPERIOD_EXTREME_SUCCESSFUL_AND_OK > 0 &&
				CONF_MANAGER_MINPERIOD_SUCCESSFUL_AND_OK > CONF_MANAGER_MINPERIOD_EXTREME_SUCCESSFUL_AND_OK)
			{
				internal_long_uint_t diff = (CONF_MANAGER_MINPERIOD_SUCCESSFUL_AND_OK - CONF_MANAGER_MINPERIOD_EXTREME_SUCCESSFUL_AND_OK);
				internal_long_uint_t interval = (diff - (internal_long_uint_t)(diff * doc.liverank));

				conf_manager_minperiod_successful_and_ok = (CONF_MANAGER_MINPERIOD_EXTREME_SUCCESSFUL_AND_OK + interval);
			}
			else																									// dovrebbe esistere anche ...PERIOD... in cbot.conf
				conf_manager_minperiod_successful_and_ok = CONF_MANAGER_MINPERIOD_SUCCESSFUL_AND_OK;
		}

		if (obj->meta->site_option_get(doc.siteid, SITE_OPT_DENY, true) == METADDX_OK) // site administratively excluded/deny
		{
			obj->priority[doc.docid] = (priority_t)(-1);
			obj->skipped_successful_and_ok[inst]++;
		}
		else if (doc.status == STATUS_DOC_EXCLUSION) // docid administratively excluded/deny
		{
				obj->priority[doc.docid] = (priority_t)(-1);
				obj->skipped_successful_and_ok[inst]++;
		}
		else if (doc.status == STATUS_DOC_FORBIDDEN) // forbidden by robots.txt and maybe also without visit page therefore without 'http_status'
		{
			if (diff_time < conf_manager_minperiod_forbidden)
			{
				obj->priority[doc.docid] = (priority_t)(-1);
				obj->skipped_forbidden[inst]++;
			}
			else
			{
				// Calculate scores
				if (CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0 && CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
					obj->doc_calculate_scores(&(doc), obj->siterank[doc.siteid], queuesize[doc.siteid]);
				else if (CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0)
					obj->doc_calculate_scores(&(doc), obj->siterank[doc.siteid], (docid_t)0);
				else if (CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
					obj->doc_calculate_scores(&(doc), (siterank_t)0, queuesize[doc.siteid]);
				else
					obj->doc_calculate_scores(&(doc), (siterank_t)0, (docid_t)0);

				// Save the scores
				obj->meta->doc_store(&(doc));

				obj->priority[doc.docid] = (doc.future_score - doc.current_score);

				if (obj->priority[doc.docid] == (priority_t)(-1))
					obj->skipped_other[inst]++;
			}
		}
		else
		{
			if ((diff_time < conf_manager_minperiod_successful_and_ok)
				&& HTTP_IS_OK(doc.http_status)
				&& doc.last_visit >= doc.last_modified)
			{
				obj->priority[doc.docid] = (priority_t)(-1);
				obj->skipped_successful_and_ok[inst]++;
			}
			else if ((diff_time  < conf_manager_minperiod_successful_but_not_ok)
				&& (!HTTP_IS_OK(doc.http_status))
				&& (!HTTP_IS_ERROR(doc.http_status))
				&& (!HTTP_IS_UNDEF(doc.http_status))
				&& doc.last_visit >= doc.last_modified)
			{
				obj->priority[doc.docid] = (priority_t)(-1);
				obj->skipped_successful_but_not_ok[inst]++;
			}
			else if ((diff_time < conf_manager_minperiod_unsuccessful)
				&& HTTP_IS_ERROR(doc.http_status)
				&& (doc.http_status != HTTP_ERROR_SKIPPED)
				&& doc.last_visit >= doc.last_modified)
			{
				obj->priority[doc.docid] = (priority_t)(-1);
				obj->skipped_unsuccessful[inst]++;
			}
			else if (doc.status == STATUS_DOC_IGNORED) // Check if this must be ignored
			{
				obj->priority[doc.docid] = (priority_t)(-1);
				obj->skipped_ignored[inst]++;
			}
			else if (doc.depth > (doc.is_dynamic ? CONF_MANAGER_MAXDEPTH_DYNAMIC : CONF_MANAGER_MAXDEPTH_STATIC)) // Check if its too deep
			{
				priority[doc.docid-1] = (priority_t)(-1);
				obj->skipped_depth[inst]++;
			}
			else
			{
				if (doc.sitemap_changefreq == NEVER
					&& HTTP_IS_OK(doc.http_status)
					&& doc.number_visits > 0
					&& doc.last_visit >= doc.last_modified)
				{
					obj->priority[doc.docid] = (priority_t)(-1);
					obj->skipped_successful_and_ok[inst]++;
				}
				else
				{
					// Calculate scores
					if (CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0 && CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
						obj->doc_calculate_scores(&(doc), obj->siterank[doc.siteid], queuesize[doc.siteid]);
					else if (CONF_MANAGER_SCORE_SITERANK_WEIGHT > 0)
						obj->doc_calculate_scores(&(doc), obj->siterank[doc.siteid], (docid_t)0);
					else if (CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT > 0)
						obj->doc_calculate_scores(&(doc), (siterank_t)0, queuesize[doc.siteid]);
					else
						obj->doc_calculate_scores(&(doc), (siterank_t)0, (docid_t)0);

					// Save the scores
					obj->meta->doc_store(&(doc));

					obj->priority[doc.docid] = (doc.future_score - doc.current_score);

					if (obj->priority[doc.docid] == (priority_t)(-1))
						obj->skipped_other[inst]++;
				}
			}
		}
	}

	if (sp->go_ahead(inst) == true)
	{
		if (obj->opt_dont_generate == false)
			cerr << " ok." << endl << "Checking sites and ordering documents by priority ... ";
		else
			cerr << " ok." << endl << "Checking sites ... ";
	}

	sync_threads(obj->barrier);

	// Sort documents by predicted scores
	if (obj->opt_dont_generate == false)
	{
		obj->sortp->order(inst);

		sync_threads(obj->barrier);

		// Set '0' inside order[offset] where priority[order[offset]] is low because is need to create harvest list
		for (docid_t i = (inst + 1); i <= obj->ndocs; i += CONF_COLLECTION_DISTRIBUTED)
			if (obj->priority[obj->order[i]] == (priority_t)(-1))
				obj->order[i] = (docid_t)0;
	}

	return NULL;
}

//
// Name: doc_calculate_scores
//
// Description:
//   Calculates all scores
//
// Input:
//   doc - the document object
//   siterank - the ranking of the site
//
// Output:
//   doc.freshness - freshness
//

void AnalysisManager::doc_calculate_scores(doc_t *doc, siterank_t siterank, docid_t queuesize) const
{
	// Base score is 0
	doc->current_score = (priority_t)(0);
	doc->future_score = (priority_t)(0);

	// Duplicates have zero score
	if (doc->duplicate_of > (docid_t)0)
		return;
	else if (doc->status == STATUS_DOC_IGNORED)
		return;

	// Calculate Freshness
	doc->freshness = doc_freshness(doc);

	// Depth
	depth_t max_depth;
	max_depth = CONF_MANAGER_MAXDEPTH_STATIC;

	priority_t depth_score;
	if (doc->depth > max_depth)
{
		// Pages too deep have zero depth_score
		depth_score = (priority_t)0;
	} else {
		// Score is proportional to depth
		// if depth=1, then score=1,
		// if depth=max_depth, score=1/max_depth
		depth_score = ((priority_t)max_depth - ((priority_t)doc->depth - (priority_t)1)) / (priority_t)max_depth;
	}

	// Scores
	priority_t static_score	= (doc->is_dynamic?0:1);
	priority_t random_score	= ((priority_t)rand()/(priority_t)RAND_MAX);

	doc->future_score = 
			  CONF_MANAGER_SCORE_PAGERANK_WEIGHT  * doc->pagerank
			+ CONF_MANAGER_SCORE_WLSCORE_WEIGHT    * doc->wlrank
			+ CONF_MANAGER_SCORE_HITS_HUB_WEIGHT   * doc->hubrank
			+ CONF_MANAGER_SCORE_HITS_AUTHORITY_WEIGHT  * doc->authrank
			+ CONF_MANAGER_SCORE_LIVERANK_WEIGHT  * doc->liverank
			+ CONF_MANAGER_SCORE_SITERANK_WEIGHT  * siterank
			+ CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT  * queuesize
			+ CONF_MANAGER_SCORE_DEPTH_WEIGHT 	* depth_score
			+ CONF_MANAGER_SCORE_STATIC_WEIGHT	* static_score
			+ CONF_MANAGER_SCORE_RANDOM_WEIGHT	* random_score;

	// Boost the score of the front page.
	// This will encourage the crawler to visit the first page of
	// each site often, and will help the discovery of new pages
	if (CONF_MANAGER_SCORE_BOOSTFRONTPAGE && (doc->depth == (depth_t)1))
		doc->future_score = CONF_MANAGER_SCORE_PAGERANK_WEIGHT + CONF_MANAGER_SCORE_WLSCORE_WEIGHT + CONF_MANAGER_SCORE_HITS_HUB_WEIGHT + CONF_MANAGER_SCORE_HITS_AUTHORITY_WEIGHT + CONF_MANAGER_SCORE_LIVERANK_WEIGHT + CONF_MANAGER_SCORE_SITERANK_WEIGHT + CONF_MANAGER_SCORE_QUEUESIZE_WEIGHT + CONF_MANAGER_SCORE_DEPTH_WEIGHT + CONF_MANAGER_SCORE_STATIC_WEIGHT + CONF_MANAGER_SCORE_RANDOM_WEIGHT;

	// Check freshness of the documents
	if (doc->freshness == (double)0)
		doc->current_score = (priority_t)0;
	else
	{
		if (doc->sitemap_changefreq == NONE) 
		{
			if (CONF_MANAGER_SCORE_AGE_EXPONENT == 1)
				doc->current_score = doc->future_score * (double)(doc->freshness);
			else
				doc->current_score = doc->future_score * (priority_t)pow((double)doc->freshness, (double)CONF_MANAGER_SCORE_AGE_EXPONENT);
		}
		else
		{
			const double default_prio = 5; // => 0.5 -> default
			double default_prio_constant = (logarithm((default_prio * 2), (double)default_prio) - 1); // 0,430676558
			double prio = default_prio;

			if (doc->sitemap_prio >= 5) // scavalcato valore di default 
				prio = (logarithm((doc->sitemap_prio + 1 + default_prio), (double)default_prio) - default_prio_constant);
			else if (doc->sitemap_prio == -1) // default priority
				prio = (logarithm((default_prio * 2), (double)default_prio) - default_prio_constant);
			else
			{
				prio = (logarithm((doc->sitemap_prio + default_prio), (double)default_prio) - default_prio_constant);
			}

			if (CONF_MANAGER_SCORE_AGE_EXPONENT == 1)
				doc->current_score = doc->future_score * (double)(doc->freshness) * prio;
			else
				doc->current_score = doc->future_score * (priority_t)pow((double)doc->freshness, (double)CONF_MANAGER_SCORE_AGE_EXPONENT) * prio;
		}
	}
}

//
// Name: doc_freshness
//
// Description:
//   Gets the freshness of a page as the probability that the
//   local copy equals the remote copy
//   From: Cho & Garcia-Molina: Estimating Frequency of Change 2000
//
// Input:
//   doc - the document object
//
// Output:
//   the freshness (1=updated, 0=old)
//

freshness_t AnalysisManager::doc_freshness(doc_t *doc) const
{
	assert(doc != NULL);
	assert(doc->docid > 0);
	assert(doc->docid < (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));

	// Check simple cases
	if (doc->status == STATUS_DOC_IGNORED)
		return 0;
	else if (doc->number_visits == 0) // Unvisited, it's not fresh
		return 0;
	else if (doc->number_visits > 1 && (doc->number_visits_changed == doc->number_visits)) // Always change
		return 0;
	else if (! HTTP_IS_OK(doc->http_status)) // Last visit failed
		return 0;
	else if (doc->last_modified > doc->last_visit) // We have last-modified information for this document, provided by another mechanism (e.g.: sitemap.rdf file)
		return 0;

	// Visited page
	time_t now = time(NULL);
	double lambda;
	
	// Check if we have last modified data
	if (doc->last_modified > 0)
	{

		// Last_modified available, check how many visits
		if (doc->number_visits == 1)// Last_modified available, check how many visits
			lambda = (double)1 / (double)(doc->last_visit - doc->last_modified); // Only one visit
		else
		{
			// More than one visit
			lambda = (((double)doc->number_visits_changed - (double)1) - ((double)doc->number_visits_changed/((double)doc->number_visits * log((double)1 - ((double)doc->number_visits_changed/(double)doc->number_visits)))))/(((double)now - (double)doc->first_visit) * ((double)doc->time_unchanged));

			if (lambda == 0)
				die("Error calculating freshness for document %llu\nlambda = 0\n", (internal_long_uint_t)doc->docid);
		}

	}
	else if (doc->number_visits_changed < doc->number_visits) // No last_modified data, but there is some data about change (ie.: text analysis)
		lambda = (-((double)doc->number_visits) * log((double)1 - ((double)doc->number_visits_changed / (double)doc->number_visits)))/((double)now - (double)doc->first_visit);
	else
		return 0;

	// Return probability
	return exp(-(lambda) * (double)(now - doc->last_visit));
}

//
// Name: doc_statistics
//
// Description:
//   Generates statistics about docs:
//    Age of oldest page
//    Age of newest page
//    Various document counts
//    Max depth
//
// Input:
//
// Return:
//
void Analysis::doc_statistics(void)
{
	int rc = 0;

	assert(meta != NULL);

	ndocs	= meta->doc_count();
	assert(ndocs > 0);

	cerr << endl << "Directories where all statistics are found:" << endl;

	createdir(COLLECTION_ANALYSIS);

	for (unsigned char x = 0; x < 3; x++)
		for (unsigned char y = 0; y < 3; y++)
		{
			char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
			static_dynamic_string[0] = '\0';
			char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
			status_string[0] = '\0';
			char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
			basename[0] = '\0';
			//FILE *output;

			// Get a string to show the static/dynamic filter type
			strcpy(static_dynamic_string,
				y == 0 ? "all"
				: y == 1 ? "static"
				: y == 2 ? "dynamic"
				: "(invalid)");

			// Get a string to show the status filter type
			strcpy(status_string,
				x == 0 ? "all"
				: x == 1 ? "new"
				: x == 2 ? "gathered"
				: "(invalid)");

			// Get directory name
			sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
			char filename[MAX_STR_LEN];
			sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

			// Create output directory
			createdir(filename);

			cerr << "Status: " << status_string << setw(20 - strlen(status_string));
			cerr << "Type: " << static_dynamic_string << setw(25 - strlen(static_dynamic_string));
			cerr << "Output dir: " << filename << endl;
		}

	cerr << endl;

	pdsi = CBALLOC(doc_stat_instance_t **, NEW, CONF_COLLECTION_DISTRIBUTED);
	pds = CBALLOC(doc_stat_t *, NEW, 3);

	for (unsigned char i = 0; i < 3; i++)
		pds[i] = CBALLOC(doc_stat_t, NEW, 3);

	pthread_mutexattr_t attr;

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		// setup document statistics mutexes
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
				pds[x][y].lock = PTHREAD_MUTEX_INITIALIZER;

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Analysis::thread_args_t *args = CBALLOC(Analysis::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = ANALYSIS_DOC_STATISTICS;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_doc_statistics((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));

		// destroy mutexes
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
				if ((rc = pthread_mutex_destroy(&pds[x][y].lock)) != 0)
					die("error destroying stdout mutexes %s", CBoterr(rc));
	}

	for (unsigned char i = 0; i < 3; i++)
		delete [] pds[i];

	delete [] pds;
	delete [] pdsi;
}

//
// Name: thread_function_doc_statistics
//
// Description:
//   Generates statistics about docs:
//    Age of oldest page
//    Age of newest page
//    Various document counts
//    Max depth
//
// Input: pointer to void
//
// Return:
//
void *Analysis::thread_function_doc_statistics(void *args)
{
	cpu_set_t system_cpus;

	Analysis::thread_args_t *arguments = (Analysis::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Analysis *obj = arguments->obj;


	obj->pdsi[inst] = CBALLOC(doc_stat_instance_t *, NEW, 3);

	sync_threads(obj->barrier);

	for (unsigned char i = 0; i < 3; i++)
		obj->pdsi[inst][i] = CBALLOC(doc_stat_instance_t, NEW, 3);

	// Go through the list of docs
	docid_t ndocs_div_50	= obj->ndocs / 50;

	ccerr << "Calculating           |--------------------------------------------------|" << endl << "                      ";

	sync_threads(obj->barrier);

	// after create structures 'doc_stat_instance_t' type, set counters to zero
	for (unsigned char x = 0; x < 3; x++)
		for (unsigned char y = 0; y < 3; y++)
		{
			doc_stat_instance_t *p = &obj->pdsi[inst][x][y];
			p->doc_count = 0;
			p->dynamic_count = 0;
			p->duplicates_count = 0;
		}

	doc_t	doc;
	metaddx_status_t rc = METADDX_ERROR;

	// increase variable inside struct
    for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
	{
		doc.docid	= docid;
		rc = obj->meta->doc_retrieve(&(doc));
		assert(rc == METADDX_OK);
		assert(doc.docid == docid);

		if (ndocs_div_50 > 0 && doc.docid % ndocs_div_50 == 0)
			cerr << ".";

		// Ignored documents are not considered for statistics
		if (doc.status == STATUS_DOC_IGNORED)
			continue;

		// ignore status and dynamic check
		obj->doc_statistics_sum(obj->pdsi[inst][0][0], obj->pds[0][0], doc);

		if (doc.is_dynamic == true)
			obj->doc_statistics_sum(obj->pdsi[inst][0][1], obj->pds[0][1], doc);
		else if (doc.is_dynamic == false)
			obj->doc_statistics_sum(obj->pdsi[inst][0][2], obj->pds[0][2], doc);

		if (doc.status == STATUS_DOC_NEW)
		{
			obj->doc_statistics_sum(obj->pdsi[inst][1][0], obj->pds[1][0], doc);

			if (doc.is_dynamic == true)
				obj->doc_statistics_sum(obj->pdsi[inst][1][1], obj->pds[1][1], doc);
			else if (doc.is_dynamic == false)
				obj->doc_statistics_sum(obj->pdsi[inst][1][2], obj->pds[1][2], doc);
		}

		if (doc.status == STATUS_DOC_GATHERED)
		{
			obj->doc_statistics_sum(obj->pdsi[inst][2][0], obj->pds[2][0], doc);

			if (doc.is_dynamic == true)
				obj->doc_statistics_sum(obj->pdsi[inst][2][1], obj->pds[2][1], doc);
			else if (doc.is_dynamic == false)
				obj->doc_statistics_sum(obj->pdsi[inst][2][2], obj->pds[2][2], doc);
		}
	}

	instance_t step_counter = obj->static_random_inst;

	sync_threads(obj->barrier);

	ccerr << endl << endl;

	sync_threads(obj->barrier);

	// Write summary statistics

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Full path
				sprintf(filename, "%s/%s/stats.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				docid_t first = 0;
				docid_t second = 0;
				docid_t third = 0;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					first += obj->pdsi[i][x][y].doc_count;
					second += obj->pdsi[i][x][y].dynamic_count;
					third += obj->pdsi[i][x][y].duplicates_count;
				}

				written = snprintf(pbuffer, space_left, "Total,Dynamic,Duplicated\n");

				size_t line_len = 6; // for each digit to count, len must be already increased to one

				while (first > 1 && (first /= 10))
					line_len++;

				while (second > 1 && (second /= 10))
					line_len++;

				while (third > 1 && (third /= 10))
					line_len++;

				first = 0;
				second = 0;
				third = 0;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					first += obj->pdsi[i][x][y].doc_count;
					second += obj->pdsi[i][x][y].dynamic_count;
					third += obj->pdsi[i][x][y].duplicates_count;
				}

				if (space_left > (written + line_len))
					written += snprintf(pbuffer + written, space_left - written, "%lu,%lu,%lu\n", (unsigned long int)first, (unsigned long int)second, (unsigned long int)third);

				if (written > 0)
					fprintf(output, pbuffer);

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Summary statistics and puts inside files 'stats.csv'" << mendl;

	}

	step_counter++;

	// Dump documents status

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/doc_status.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<doc_status_t, docid_t> _map;
				map<doc_status_t, docid_t>::iterator it;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].doc_status_map)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].doc_status_map.clear();
				}

				written = snprintf(pbuffer, space_left, "Document status,Document code,Documents,Fraction\n");

				for (auto &it : _map)
					if (it.first > 0)
					{
						string Doc_status_str = DOC_STATUS_STR(it.first);
						auto Doc_status = (unsigned int)it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 18; // max length of 'Fraction' in chars is twelve (with scientific output)

						line_len += Doc_status_str.size();

						while (Doc_status > 1 && (Doc_status /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Doc_status = (unsigned int)it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%s,%u,%lu,%e\n", Doc_status_str.c_str(), Doc_status, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%s,%u,%lu,%e\n", Doc_status_str.c_str(), Doc_status, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Status of documents and puts inside files 'doc_status.csv'" << mendl;
	}

	step_counter++;

	// HTTP Codes

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/http_code.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<int, docid_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].http_status_map)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].http_status_map.clear();
				}

				written = snprintf(pbuffer, space_left, "HTTP Status,HTTP Code,Documents,Fraction\n");

				for (auto &it : _map)
					if (it.first > 0)
					{
						string Http_status_str = HTTP_STR(it.first);
						auto Http_status = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 18; // max length of 'Fraction' in chars is twelve (with scientific output)

						line_len += Http_status_str.size();

						while (Http_status > 1 && (Http_status /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Http_status = (int)it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%s,%d,%lu,%e\n", Http_status_str.c_str(), Http_status, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%s,%d,%lu,%e\n", Http_status_str.c_str(), Http_status, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated HTTP code statistics and puts inside files 'http_code.csv'" << mendl;
	}

	step_counter++;

	// MIME Codes

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/mime_type.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<mime_type_t, docid_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].mime_type_map)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].mime_type_map.clear();
				}

				written = snprintf(pbuffer, space_left, "MIME type,Internal Code,Documents,Fraction\n");

				for (auto &it : _map)
					if (it.first > 0)
					{
						string Mime_type_str = MIME_TYPE_STR(it.first);
						auto Mime_type = (int)it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 18; // max length of 'Fraction' in chars is twelve (with scientific output)

						line_len += Mime_type_str.size();

						while (Mime_type > 1 && (Mime_type /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Mime_type = (int)it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%s,%d,%lu,%e\n", Mime_type_str.c_str(), Mime_type, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%s,%d,%lu,%e\n", Mime_type_str.c_str(), Mime_type, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated MIME types statistics and puts inside files 'mime_type.csv'" << mendl;
	}

	step_counter++;

	// IN Degree

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/in_degree.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<unsigned int, docid_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].in_degree_map)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].in_degree_map.clear();
				}

				written = snprintf(pbuffer, space_left, "In-degree,Documents,Fraction\n");

				for (auto &it : _map)
					if (it.first > 0)
					{
						auto IN_degree = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 17; // max length of 'Fraction' in chars is twelve (with scientific output)

						while (IN_degree > 1 && (IN_degree /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						IN_degree = it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%u,%lu,%e\n", IN_degree, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%u,%lu,%e\n", IN_degree, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated IN Degree statistics and puts inside files 'in_degree.csv'" << mendl;
	}

	step_counter++;

	// OUT Degree

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/out_degree.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<unsigned int, docid_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].out_degree_map)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].out_degree_map.clear();
				}

				written = snprintf(pbuffer, space_left, "Out-degree,Documents,Fraction\n");

				for (auto &it : _map)
					if (it.first > 0)
					{
						auto OUT_degree = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 17; // max length of 'Fraction' in chars is twelve (with scientific output)

						while (OUT_degree > 1 && (OUT_degree /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						OUT_degree = it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%u,%lu,%e\n", OUT_degree, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%u,%lu,%e\n", OUT_degree, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated OUT Degree statistics and puts inside files 'out_degree.csv'" << mendl;
	}

	step_counter++;

	// Content length, in KB

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/content_length_kb.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<unsigned int, docid_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].content_length_kb_map)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].content_length_kb_map.clear();
				}

				written = snprintf(pbuffer, space_left, "Parsed content length in KB,Documents,Fraction\n");

				for (auto &it : _map)
					if (it.first > 0)
					{
						auto Content_length_kb = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 17; // max length of 'Fraction' in chars is twelve (with scientific output)

						while (Content_length_kb > 1 && (Content_length_kb /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Content_length_kb = it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%u,%lu,%e\n", Content_length_kb, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%u,%lu,%e\n", Content_length_kb, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Content length in KB statistics and puts inside files 'content_length_kb.csv'" << mendl;
	}

	step_counter++;

	// RAW Content length, in KB

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/raw_content_length_kb.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<unsigned int, docid_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].raw_content_length_kb_map)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].raw_content_length_kb_map.clear();
				}

				written = snprintf(pbuffer, space_left, "Content length in KB,Documents,Fraction\n");


				for (auto &it : _map)
					if (it.first > 0)
					{
						auto RAW_content_length_kb = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 17; // max length of 'Fraction' in chars is twelve (with scientific output)

						while (RAW_content_length_kb > 1 && (RAW_content_length_kb /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						RAW_content_length_kb = it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%u,%lu,%e\n", RAW_content_length_kb, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%u,%lu,%e\n", RAW_content_length_kb, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated RAW content length in KB statistics and puts inside files 'raw_content_length_kb.csv'" << mendl;
	}

	step_counter++;

	// Depth

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/depth.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<depth_t, docid_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].depth_count)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].depth_count.clear();
				}

				written = snprintf(pbuffer, space_left, "Document depth,Documents,Fraction\n");

				for (auto &it : _map)
					if (it.first > 0)
					{
						auto Depth = (unsigned int)it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 17; // max length of 'Fraction' in chars is twelve (with scientific output)

						while (Depth > 1 && (Depth /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Depth = (unsigned int)it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%u,%lu,%e\n", Depth, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%u,%lu,%e\n", Depth, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Depth statistics and puts inside files 'depth.csv'" << mendl;
	}

	step_counter++;

	// Page rank

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/pagerank.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				written = snprintf(pbuffer, space_left, "Pagerank,Documents,Fraction\n");

				for (auto &it : obj->pds[x][y].pagerank_map)
				{
					if (it.first > 0)
					{
						auto Pagerank = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 28; // max length of 'Pagerank' and 'Fraction' in chars is twelve (with scientific output)

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%e,%lu,%e\n", Pagerank, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%e,%lu,%e\n", Pagerank, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				obj->pds[x][y].pagerank_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Pagerank statistics and puts inside files 'pagerank.csv'" << mendl;
	}

	step_counter++;


	// Wl score

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest wl
				sprintf(filename, "%s/%s/wlrank.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				written = snprintf(pbuffer, space_left, "Wlrank,Documents,Fraction\n");

				for (auto &it : obj->pds[x][y].wlrank_map)
				{
					if (it.first > 0)
					{
						auto Wlrank = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 28; // max length of 'Wlrank' and 'Fraction' in chars is twelve (with scientific output)

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%e,%lu,%e\n", Wlrank, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%e,%lu,%e\n", Wlrank, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				obj->pds[x][y].wlrank_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated CBotrank statistics and puts inside files 'wlrank.csv'" << mendl;
	}

	step_counter++;

	// Hub score

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/hubrank.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				written = snprintf(pbuffer, space_left, "Hubrank,Documents,Fraction\n");

				for (auto &it : obj->pds[x][y].hubrank_map)
				{
					if (it.first > 0)
					{
						auto Hubrank = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 28; // max length of 'Hubrank' and 'Fraction' in chars is twelve (with scientific output)

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%e,%lu,%e\n", Hubrank, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%e,%lu,%e\n", Hubrank, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				obj->pds[x][y].hubrank_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Hubrank statistics and puts inside files 'hubrank.csv'" << mendl;
	}

	step_counter++;

	// Authority score

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/authrank.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				written = snprintf(pbuffer, space_left, "Authrank,Documents,Fraction\n");

				for (auto &it : obj->pds[x][y].authrank_map)
				{
					if (it.first > 0)
					{
						auto Authrank = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 28; // max length of 'Authrank' and 'Fraction' in chars is twelve (with scientific output)

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%e,%lu,%e\n", Authrank, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%e,%lu,%e\n", Authrank, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				obj->pds[x][y].authrank_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Authrank statistics and puts inside files 'authrank.csv'" << mendl;
	}

	step_counter++;


	// Live score

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/liverank.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				written = snprintf(pbuffer, space_left, "Liverank,Documents,Fraction\n");

				for (auto &it : obj->pds[x][y].liverank_map)
				{
					if (it.first > 0)
					{
						auto Liverank = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 28; // max length of 'Liverank' and 'Fraction' in chars is twelve (with scientific output)

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%e,%lu,%e\n", Liverank, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%e,%lu,%e\n", Liverank, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				obj->pds[x][y].liverank_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Liverank statistics and puts inside files 'liverank.csv'" << mendl;
	}

	step_counter++;

	// Page rank for each depth

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/pagerank_depth.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<depth_t,pagerank_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].pagerank_depth)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].pagerank_depth.clear();
				}

				written = snprintf(pbuffer, space_left, "Depth,Pagerank,Cumulative\n");

				long double Cumulative = 0;

				for (auto &it : _map)
				{
					if (it.first > 0)
					{
						depth_t Depth = it.first;
						pagerank_t Pagerank = it.second;
						Cumulative += it.second;

						size_t line_len = 28; // max length of 'Depth' and 'Cumulative' in chars is twelve (with scientific output)

						while (Depth > 1 && (Depth /= 10))
							line_len++;

						Depth = it.first;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%u,%e,%Le\n", Depth, Pagerank, Cumulative);
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%u,%e,%Le\n", Depth, Pagerank, Cumulative);
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Pagerank and depth statistics and puts inside files 'pagerank_depth.csv'" << mendl;
	}

	step_counter++;

	// Wl score for each depth

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/wlrank_depth.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<depth_t,wlrank_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].wlrank_depth)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].wlrank_depth.clear();
				}

				written = snprintf(pbuffer, space_left, "Depth,WLrank,Cumulative\n");

				long double Cumulative = 0;

				for (auto &it : _map)
				{
					if (it.first > 0)
					{
						depth_t Depth = it.first;
						wlrank_t Wlrank = it.second;
						Cumulative += it.second;

						size_t line_len = 28; // max length of 'Depth' and 'Cumulative' in chars is twelve (with scientific output)

						while (Depth > 1 && (Depth /= 10))
							line_len++;

						Depth = it.first;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%u,%e,%Le\n", Depth, Wlrank, Cumulative);
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%u,%e,%Le\n", Depth, Wlrank, Cumulative);
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Cbotrank and depth statistics and puts inside files 'wlrank_depth.csv'" << mendl;
	}

	step_counter++;

	// Hub score for each depth

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/hubrank_depth.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<depth_t,hubrank_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].hubrank_depth)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].hubrank_depth.clear();
				}

				written = snprintf(pbuffer, space_left, "Depth,Hubrank,Cumulative\n");

				long double Cumulative = 0;

				for (auto &it : _map)
				{
					if (it.first > 0)
					{
						depth_t Depth = it.first;
						hubrank_t Hubrank = it.second;
						Cumulative += it.second;

						size_t line_len = 28; // max length of 'Depth' and 'Cumulative' in chars is twelve (with scientific output)

						while (Depth > 1 && (Depth /= 10))
							line_len++;

						Depth = it.first;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%u,%e,%Le\n", Depth, Hubrank, Cumulative);
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%u,%e,%Le\n", Depth, Hubrank, Cumulative);
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Hubrank and depth statistics and puts inside files 'hubrank_depth.csv'" << mendl;
	}

	step_counter++;

	// Authority score for each depth

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/authrank_depth.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<depth_t,authrank_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].authrank_depth)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].authrank_depth.clear();
				}

				written = snprintf(pbuffer, space_left, "Depth,Authrank,Cumulative\n");

				long double Cumulative = 0;

				for (auto &it : _map)
				{
					if (it.first > 0)
					{
						depth_t Depth = it.first;
						authrank_t Authrank = it.second;
						Cumulative += it.second;

						size_t line_len = 28; // max length of 'Depth' and 'Cumulative' in chars is twelve (with scientific output)

						while (Depth > 1 && (Depth /= 10))
							line_len++;

						Depth = it.first;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%u,%e,%Le\n", Depth, Authrank, Cumulative);
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%u,%e,%Le\n", Depth, Authrank, Cumulative);
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Authrank and depth statistics and puts inside files 'authrank_depth.csv'" << mendl;
	}

	step_counter++;

	// Live score for each depth

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/liverank_depth.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				map<depth_t,liverank_t> _map;

				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					for (auto &it : obj->pdsi[i][x][y].liverank_depth)
						_map[it.first] += it.second;

					obj->pdsi[i][x][y].liverank_depth.clear();
				}

				written = snprintf(pbuffer, space_left, "Depth,Liverank,Cumulative\n");

				long double Cumulative = 0;

				for (auto &it : _map)
				{
					if (it.first > 0)
					{
						depth_t Depth = it.first;
						liverank_t Liverank = it.second;
						Cumulative += it.second;

						size_t line_len = 28; // max length of 'Depth' and 'Cumulative' in chars is twelve (with scientific output)

						while (Depth > 1 && (Depth /= 10))
							line_len++;

						Depth = it.first;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%u,%e,%Le\n", Depth, Liverank, Cumulative);
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%u,%e,%Le\n", Depth, Liverank, Cumulative);
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Liverank and depth statistics and puts inside files 'liverank_depth.csv'" << mendl;
	}

	step_counter++;

	// Age in hours

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/age_hours.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				written = snprintf(pbuffer, space_left, "Age in hours,Documents,Fraction\n");

				for (auto &it : obj->pds[x][y].age_hours_map)
				{
					if (it.first > 0)
					{
						auto Age = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 17; // max length of 'Fraction' in chars is twelve (with scientific output)

						while (Age > 1 && (Age /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Age = it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%d,%lu,%e\n", (int)Age, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%d,%lu,%e\n", (int)Age, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				obj->pds[x][y].age_hours_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Age in hours statistics and puts inside files 'age_hours.csv'" << mendl;
	}

	step_counter++;

	// Age in months

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/age_months.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				written = snprintf(pbuffer, space_left, "Age in months,Documents,Fraction\n");

				for (auto &it : obj->pds[x][y].age_months_map)
				{
					if (it.first > 0)
					{
						auto Age = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 17; // max length of 'Fraction' in chars is twelve (with scientific output)

						while (Age > 1 && (Age /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Age = it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%d,%lu,%e\n", (int)Age, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%d,%lu,%e\n", (int)Age, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				obj->pds[x][y].age_months_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Age in months statistics and puts inside files 'age_months.csv'" << mendl;
	}

	step_counter++;

	// Age in years

	if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
	{
		for (unsigned char x = 0; x < 3; x++)
			for (unsigned char y = 0; y < 3; y++)
			{
				int written = 0;
				size_t space_left = (MAX_STR_LEN * 50);
				char *pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
				pbuffer[0] = '\0';
				char *static_dynamic_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				static_dynamic_string[0] = '\0';
				char *status_string = CBALLOC(char, MALLOC, MAX_STR_LEN);
				status_string[0] = '\0';
				char *basename = CBALLOC(char, MALLOC, MAX_STR_LEN);
				basename[0] = '\0';
				FILE *output;

				// Get a string to show the static/dynamic filter type
				strcpy(static_dynamic_string,
					y == 0 ? "all"
					: y == 1 ? "static"
					: y == 2 ? "dynamic"
					: "(invalid)");

				// Get a string to show the status filter type
				strcpy(status_string,
					x == 0 ? "all"
					: x == 1 ? "new"
					: x == 2 ? "gathered"
					: "(invalid)");

				// Get directory name
				sprintf(basename, "doc_%s_%s", status_string, static_dynamic_string);
				char filename[MAX_STR_LEN];
				sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

				// Age oldest page
				sprintf(filename, "%s/%s/age_years.csv", COLLECTION_ANALYSIS, basename);
				output = fopen64(filename, "w+");

				written = snprintf(pbuffer, space_left, "Age in years,Documents,Fraction\n");

				for (auto &it : obj->pds[x][y].age_years_map)
				{
					if (it.first > 0)
					{
						auto Age = it.first;
						docid_t Docs = it.second;
						double Fraction = ((double)Docs / (double)obj->ndocs);

						size_t line_len = 17; // max length of 'Fraction' in chars is twelve (with scientific output)

						while (Age > 1 && (Age /= 10))
							line_len++;

						while (Docs > 1 && (Docs /= 10))
							line_len++;

						Age = it.first;
						Docs = it.second;

						while (true)
						{
							if (written == 0)
								written += snprintf(pbuffer, space_left, "%d,%lu,%e\n", (int)Age, (unsigned long int)Docs, Fraction );
							else if (written >= 0)
							{
								if (space_left > (written + line_len))
									written += snprintf(pbuffer + written, space_left - written, "%d,%lu,%e\n", (int)Age, (unsigned long int)Docs, Fraction );
								else
								{
									fprintf(output, pbuffer);
									written = 0;
									pbuffer[written] = '\0';
									continue;
								}
							}

							break;
						}
					}
				}

				if (written > 0)
					fprintf(output, pbuffer);

				obj->pds[x][y].age_years_map.clear();

				free(basename);
				free(status_string);
				free(static_dynamic_string);
				free(pbuffer);
				fclose(output);
			}

		mcerr << "* Generated Age in years statistics and puts inside files 'age_years.csv'" << mendl;
	}

	sync_threads(obj->barrier);

	for (unsigned char i = 0; i < 3; i++)
		delete [] obj->pdsi[inst][i];

	sync_threads(obj->barrier);

	delete [] obj->pdsi[inst];

	return NULL;
}

//
// Name: doc_statistics_sum
//
// Description:
//   Do calculation for 'thread_function_doc_statistics'
//
// Input: struct doc_stat_instance_t, struct doc_stat_t, document
//
// Return:
//
void Analysis::doc_statistics_sum(doc_stat_instance_t &doc_stat_inst, doc_stat_t &doc_stat, doc_t &doc)
{
	doc_stat_inst.doc_count++;
/*
	// Show this document if necessary (svantaggioso applicarlo in multithread, dubbia utilità)
	if ((doc_count % CONF_ANALYSIS_DOC_SAMPLE_EVERY) == 0)
{
		meta->dump_doc(&(doc), output);
	}
	*/

	doc_stat_inst.doc_status_map[doc.status]++;
	doc_stat_inst.http_status_map[doc.http_status]++;
	doc_stat_inst.depth_count[doc.depth]++;
	doc_stat_inst.in_degree_map[doc.in_degree]++;
	doc_stat_inst.out_degree_map[doc.out_degree]++;
	doc_stat_inst.content_length_kb_map[(uint)(doc.content_length/1024)]++;
	doc_stat_inst.raw_content_length_kb_map[(uint)(doc.raw_content_length/1024)]++;
	doc_stat_inst.mime_type_map[doc.mime_type]++;

	if (doc.is_dynamic)
{
		doc_stat_inst.dynamic_count++;
	}

	if (doc.duplicate_of > 0)
{
		doc_stat_inst.duplicates_count++;
	}

	// Link scores
	doc_stat_inst.pagerank_depth[doc.depth] += doc.pagerank;
	doc_stat_inst.wlrank_depth[doc.depth] += doc.wlrank;
	doc_stat_inst.hubrank_depth[doc.depth] += doc.hubrank;
	doc_stat_inst.authrank_depth[doc.depth] += doc.authrank;
	doc_stat_inst.liverank_depth[doc.depth] += doc.liverank;

	int rc = 0;

	if (CONF_COLLECTION_DISTRIBUTED > 1 && (rc = pthread_mutex_lock(&doc_stat.lock)) != 0)
		die("error locking mutex %s", CBoterr(rc));

	doc_stat.pagerank_map[ROUND_DOUBLE(doc.pagerank)]++;
	doc_stat.wlrank_map[ROUND_DOUBLE(doc.wlrank)]++;
	doc_stat.hubrank_map[ROUND_DOUBLE(doc.hubrank)]++;
	doc_stat.authrank_map[ROUND_DOUBLE(doc.authrank)]++;
	doc_stat.liverank_map[ROUND_DOUBLE(doc.liverank)]++;

	// Last modified
	if (doc.last_visit > 0 && doc.last_modified > 0)
	{
		if (doc.last_visit <= doc.last_modified)
		{
			doc_stat.age_hours_map[(time_t)0]++;
			doc_stat.age_months_map[(time_t)0]++;
			doc_stat.age_years_map[(time_t)0]++;
		}
		else
		{
			// 60 seconds in 1 minute
			// 60 minutes in 1 hour
			// 1 hour = 3600 seconds
			//
			// 24 hours in 1 day
			// 30 days in 1 month
			// 1 hour = 2592000 seconds
			// 1 year = 31536000
			doc_stat.age_hours_map[((doc.last_visit - doc.last_modified)/((time_t)3600))]++;
			doc_stat.age_months_map[((doc.last_visit - doc.last_modified)/((time_t)2592000))]++;
			doc_stat.age_years_map[((doc.last_visit - doc.last_modified)/((time_t)31536000))]++;
		}
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1 && (rc = pthread_mutex_unlock(&doc_stat.lock)) != 0)
		die("error unlocking mutex %s", CBoterr(rc));
}
