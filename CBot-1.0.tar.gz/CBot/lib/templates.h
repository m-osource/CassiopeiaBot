/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _TEMPLATES_H_INCLUDED_
#define _TEMPLATES_H_INCLUDED_


// System libraries

#include <typeinfo>
#include <typeindex>

using namespace std;

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "cleanup.h"
#include "pthread.h"
#include "atomic"


// Constants

// Typedefs

// Template Functions

// Template Classes

//
// Name: CBotSort 
//
// Description: Class for sort and linearize an array of any type of double
//
// Input:
//
// Return: 
//
template <typename T, typename P> class CBotSort
{
	int rc;
	bool skip_all_zeros;
	bool ascending;
	bool linearize;
	bool *is_ignored;
	P skip_count;
	P RAS; // warning: RAS may be inferior of input array size
	P nelements;
	P fract;
	T *rastart; // array of ranks start always from '0' offset
	T *rankarray; // warning: rankarry may non start from real '0' offset of input array
	P *spstart; // array of orders start always from '0' offset
	P *sourcepositions; // warning: sourcepositions may non start from real '0' offset of input array
	T ***towers;
	size_t **matrix;
	size_t *tmediasize;
	size_t *mcloudsize;
	size_t *tleft;
	size_t *trigth;
	size_t *toldleft;
	size_t *toldrigth;
	size_t *tlmediasize;
	size_t *trmediasize;
	internal_long_double_t *tmedia;
	internal_long_double_t *mcloud;
	internal_long_double_t *tlmedia;
	internal_long_double_t *trmedia;
	pthread_barrier_t *barrier; // barrier synchronization object
	bool *error;
	size_t *error_size;
	P *zero_counter;
	const unsigned int OPTIMAL_MIN_SIZE = 20000000; // DON'T TOUCH THIS VALUE because algorithm work best with array with size equal or major of OPTIMAL_MIN_SIZE
	const unsigned int THRESHOLD_FACTOR = 10000; // increase to best precision (10000 is a good value), it can be equal to RAS only for testing use
	const size_t error_size_threshold = 400; // valore scelto arbitrariamente (400 è un buon valore), limite per ogni mediana (pivot) da calcolare

	// Sync threads
	void sync_threads(pthread_barrier_t &barrier);

	// Split array with use of matrix and sort it.
	void make_matrix( instance_t & );

	// Get status of exit of algorithm
	bool check( void );
	
	public:

	//
	// Description: Multithread Sorting using Matrix
	//
	// Arguments:
	// pointer to array to evaluate,
	// pointer to order empty array,
	// full length of array to evaluate for sorting,
	// fraction to be used in linearization (zero value to be ignored),
	// offset where sorting must begin,
	// pointer to 'is_ignored' not null if we want consider it (only with linearize true),
	// boolean true if we want not ignore zeros (only with linearize true and 'is_ignored' and 'fract are ignored),
	// boolean true if we want ascending sort,
	// boolean true for linearize
	//
	// Return: the order array populated
	//
	CBotSort (T *_T, P *_P, P _S, P _F, const P _SC, bool *_I, bool _V, bool _O, bool _Q) // ctor
		: rc (0)
		, skip_all_zeros (_V)
		, ascending (_O)
		, linearize (_Q)
		, is_ignored (_I)
		, skip_count (_SC)
		, RAS (_S - _SC)
		, nelements (_S)
		, fract (_F)
		, rastart (_T)
		, rankarray (&_T[_SC])
		, spstart (_P)
		, sourcepositions (&_P[_SC])
		, towers (CBALLOC(T **, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, matrix (CBALLOC(size_t *, CALLOC, CONF_COLLECTION_DISTRIBUTED))
		, tmediasize (CBALLOC(size_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, mcloudsize (CBALLOC(size_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, tleft (CBALLOC(size_t, MALLOC, CONF_COLLECTION_DISTRIBUTED)) // each position must contain same value (inside cicle while of 'order')
		, trigth (CBALLOC(size_t, MALLOC, CONF_COLLECTION_DISTRIBUTED)) // each position must contain same value (inside cicle while of 'order')
		, toldleft (CBALLOC(size_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, toldrigth (CBALLOC(size_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, tlmediasize (CBALLOC(size_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, trmediasize (CBALLOC(size_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, tmedia (CBALLOC(internal_long_double_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, mcloud (CBALLOC(internal_long_double_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, tlmedia (CBALLOC(internal_long_double_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, trmedia (CBALLOC(internal_long_double_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, barrier (CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED)) // barrier synchronization object inside class
		, error (CBALLOC(bool, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, error_size (CBALLOC(size_t, MALLOC, CONF_COLLECTION_DISTRIBUTED))
		, zero_counter (CBALLOC(P, CALLOC, CONF_COLLECTION_DISTRIBUTED))
	{
		assert(sp != NULL);

		const std::type_info& ti0 = typeid(T);
		const std::type_info& ti1 = typeid(double);
		const std::type_info& ti2 = typeid(internal_long_double_t);

		if (ti0.hash_code() != ti1.hash_code() && ti0.hash_code() != ti2.hash_code())
			die("Error linearization must be applied only for data type %s or %s", typeid(double).name(), typeid(internal_long_double_t).name());

		mcloud[0] = 0; // this value must be always at 0

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			error[i] = false;
			error_size[i] = 0;
		}
	}
	
	~CBotSort () // dtor
	{
		// destroy a barrier object with a count of 3
		if (CONF_COLLECTION_DISTRIBUTED > 1)
			for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
    			pthread_barrier_destroy(&barrier[i]);

		free(towers);
		free(matrix);
		free(tmediasize);
		free(mcloudsize);
		free(tleft);
		free(trigth);
		free(toldleft);
		free(toldrigth);
		free(tlmediasize);
		free(trmediasize);
		free(tmedia);
		free(mcloud);
		free(tlmedia);
		free(trmedia);
		free(barrier);
		free(error);
		free(error_size);
		free(zero_counter);
	}

	//
	// Name: sortcmp
	//
	// Description: 
	//
	// Input: Values to compare
	//
	// Return: 1 if 'a' is major or equal at 'b'
	//
    template<typename D, typename S> static int ascending_sortcmp ( const void *a, const void *b, void *arg )
	{
		S *p = (S *)arg;

		if (p[(*((const D *)a))] < p[(*((const D *)b))])
			return 0;

		return 1;
	}

	//
	// Name: sortcmp
	//
	// Description: 
	//
	// Input: Values to compare
	//
	// Return: 1 if 'a' is minor or equal at 'b'
	//
    template<typename D, typename S> static int descending_sortcmp ( const void *a, const void *b, void *arg )
	{
		S *p = (S *)arg;

		if (p[(*((const D *)a))] > p[(*((const D *)b))])
			return 0;

		return 1;
	}

	// Init thread barriers of class
	void barrier_init( void );

	// Calculate medians into array (algorithm that depend from OPTIMAL_MIN_SIZE)
	void order( instance_t & );
};

//
// Name: check 
//
// Description: check if any mcloud give an error
//
// Input:
//
// Return: true if all is OK
//
template <typename T, typename P> bool CBotSort<T, P>::check(void)
{
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (error[i] == true)
			return false;

	return true;
}

//
// Name sync threads
//
// Description: sync threads inside class and inside mclouds
//
// Input: barrier object
//
// Return: true if syncronized
//
template <typename T, typename P> void CBotSort<T, P>::sync_threads(pthread_barrier_t &barrier)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc =pthread_barrier_wait(&barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
		pthread_exit(NULL);
}

//
// Name: barrier_init
//
// Description: Prepare barriers to work inside class and with mclouds
//
// Input: 
//
// Return:
//
template <typename T, typename P> void CBotSort<T, P>::barrier_init(void)
{
	// create barriers objects
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		instance_t nthreads = (instance_t)CONF_COLLECTION_DISTRIBUTED;

		pthread_barrier_init(&barrier[0], NULL, nthreads); // main barrier

		for (instance_t v = 0; v < (instance_t)log2((double)CONF_COLLECTION_DISTRIBUTED); v++)
		{
			for (instance_t i = (nthreads / 2); i < CONF_COLLECTION_DISTRIBUTED; i += nthreads)
				pthread_barrier_init(&barrier[i], NULL, nthreads);

			nthreads /= 2;
		}
	}
}

//
// Name: order
//
// Description: Step by step, split array (single media cloud) to medians in CONF_COLLECTION_DISTRIBUTED (CCD) number of chunks (media clouds) and at the end
// of 'for cicle', at this point when array is again intact call make_matrix function.
//	At each step number of mclouds was multiplied for two (2), if CCD is 4 for cicle must run 2 steps ... if CCD is 64 for cicle must run 6 steps and so on ...
//	Inside each mcloud works nthreads.
//
// Input: Number of instance
//
// Return:
//
template <typename T, typename P> void CBotSort<T, P>::order(instance_t &inst)
{
	instance_t nthreads = CONF_COLLECTION_DISTRIBUTED;
	P threshold = 0;
	bool _error = false;

	// size of array is too small to bee worked with threads (it is not really an error)
	// execute with SINGLE thread and function 'make_matrix' is not called
	if (CONF_COLLECTION_DISTRIBUTED == 1 || nelements < THRESHOLD_FACTOR)
	{
		if (sp->go_ahead(inst))
		{
			// Prepare array for linearization
			for (P i = 0; i < nelements; i++)
				sourcepositions[i] = (P)(i + skip_count);

			cerr << "ordering, ";

			if (ascending == true)
				qsort_r(sourcepositions, nelements, sizeof(P), ascending_sortcmp<P, T>, rastart);
			else
				qsort_r(sourcepositions, nelements, sizeof(P), descending_sortcmp<P, T>, rastart);

			if (linearize == false)
			{
				sync_threads(barrier[0]);
       

				return;
			}

			// Shift, so newly the order starts from 0 offset
			sourcepositions = spstart;

			cerr << "assigning, ";

			// While linearizing
			// Avoid giving rank > 0 to position with rank = 0
			P _zero_counter = (P)0;

			// While linearizing
			// Avoid giving rank > 0 to position with rank = 0
			if (skip_all_zeros == false)
				for (P i = 0; i < nelements; i++)
					if (rankarray[i] == 0)
						_zero_counter++;

			T value = (T)0;

			assert(fract < nelements);

			if (fract == 0)
			{
				if (skip_all_zeros == false)
					value = ((T)1/(T)(nelements - _zero_counter));
				else
					value = ((T)1/(T)nelements);
			}
			else
				value = ((T)1/(T)fract);

			if (fract == 0)
			{
				if (skip_all_zeros == false)
				{
					if (ascending == true)
						for (P i = _zero_counter; i < nelements; i++)
							rastart[sourcepositions[(i + skip_count)]] = (value * (i - _zero_counter + 1));
					else
						for (P i = 0; i < (nelements - _zero_counter); i++)
							rastart[sourcepositions[(i + skip_count)]] = (1 - (value * i));
				}
				else
				{
					if (ascending == true)
						for (P i = 0; i < nelements; i++)
							rastart[sourcepositions[(i + skip_count)]] = (value * (i + 1));
					else
						for (P i = 0; i < nelements; i++)
							rastart[sourcepositions[(i + skip_count)]] = (1 - (value * i));
				}
			}
			else // da verificare in un caso reale
			{
				assert (is_ignored != NULL);

				if (ascending == true)
					for (P i = 0; i < nelements; i++)
					{
						P offset = sourcepositions[(i + skip_count)];

						if (is_ignored[offset] == true)
							rastart[offset] = (T)0;
						else if (rastart[offset] > 0)
							rastart[offset] = (value * (i + 1));
					}
				else
					for (P i = 0; i < nelements; i++)
					{
						P offset = sourcepositions[(i + skip_count)];

						if (is_ignored[offset] == true)
							rastart[offset] = (T)0;
						else if (rastart[offset] > 0)
							rastart[offset] = (1 - (value * i));
					}
			}

			cerr << "done." << endl;

			sync_threads(barrier[0]);
        
		}
		else sync_threads(barrier[0]);


		return;
	}

	ccerr << "ordering, ";

	/*
	 * Get Medians
	 *	At each step number of mclouds was multiplied for two (2), if CCD is 4 for cicle must run 2 steps ... if CCD is 64 for cicle must run 6 steps and so on ...
	 *	Inside each mcloud threads numbers are always a value calculated in CCD divided the power of 2 with 'step' as exponent.
	 */
	for (instance_t step = 0; step < (instance_t)log2((double)CONF_COLLECTION_DISTRIBUTED); step++)
	{
		bool solved = false;
		P error_size_sum = 0;
		tleft[inst] = 0;
		trigth[inst] = 0;
		P leftsum = 0;
		P rigthsum = 0;
		tmedia[inst] = 0;
		tmediasize[inst] = 0;
		P omin = ((inst / nthreads) * nthreads);
		P omax = (omin + nthreads);
		instance_t mcpos = (omin + (nthreads / 2));

		if (nelements < OPTIMAL_MIN_SIZE)
			threshold = nthreads; // only for testing use
		else
			threshold = (nelements / THRESHOLD_FACTOR * nthreads);

		// Sync all threads at the begin of step
		sync_threads(barrier[0]);

		// Check if any media cloud had gived error
		if (check() == false)
		{
			_error = true;

			break;
		}

		T media = (T)0; // must be the same value in all threads
		P mediasize = 0;

		// get instance's main media
		if (nthreads == CONF_COLLECTION_DISTRIBUTED)
			for (P i = inst; i < nelements; i += nthreads)
			{
				tmedia[inst] = (((tmedia[inst] / (tmediasize[inst] + 1)) * tmediasize[inst]) + (rankarray[i] / (tmediasize[inst] + 1)));

				tmediasize[inst]++;
			}
		else
		{
			T val = 0;

			if (omax == CONF_COLLECTION_DISTRIBUTED)
				val = 0;
			else
				val = mcloud[omax];
					
			const T max = val;
			const T min = mcloud[omin];

			if (omin == 0)
			{
				for (P i = (inst % nthreads); i < nelements; i += nthreads)
				{
					if (rankarray[i] <= max)
					{
						tmedia[inst] = (((tmedia[inst] / (tmediasize[inst] + 1)) * tmediasize[inst]) + (rankarray[i] / (tmediasize[inst] + 1)));

						tmediasize[inst]++;
					}
				}
			}
			else if (omax == CONF_COLLECTION_DISTRIBUTED)
			{
				for (P i = (inst % nthreads); i < nelements; i += nthreads)
				{
					if (min < rankarray[i])
					{
						tmedia[inst] = (((tmedia[inst] / (tmediasize[inst] + 1)) * tmediasize[inst]) + (rankarray[i] / (tmediasize[inst] + 1)));

						tmediasize[inst]++;
					}
				}
			}
			else
			{
				for (P i = (inst % nthreads); i < nelements; i += nthreads)
				{
					if (min < rankarray[i] && rankarray[i] <= max)
					{
						tmedia[inst] = (((tmedia[inst] / (tmediasize[inst] + 1)) * tmediasize[inst]) + (rankarray[i] / (tmediasize[inst] + 1)));

						tmediasize[inst]++;
					}
				}
			}
		}

		// get main media
		sync_threads(barrier[mcpos]);

		for (instance_t i = omin; i < (omin + nthreads); i++)
			mediasize += tmediasize[i];

		for (instance_t i = omin; i < (omin + nthreads); i++)
			media += ((tmedia[i] / mediasize) * tmediasize[i]);

		/*
		 * Here, before calculate another media because expensive for cpu,
		 * we check if left and right count are balanced
		 */
		if (nthreads == CONF_COLLECTION_DISTRIBUTED)
			for (P i = inst; i < nelements; i += nthreads)
			{
				if (rankarray[i] <= media)
					tleft[inst]++;
				else if (rankarray[i] > media)
					trigth[inst]++;
			}
		else
		{
			T val = 0;

			if (omax == CONF_COLLECTION_DISTRIBUTED)
				val = 0;
			else
				val = mcloud[omax];
					
			const T max = val;
			const T min = mcloud[omin];

			if (omin == 0)
			{
				for (P i = (inst % nthreads); i < nelements; i += nthreads)
				{
					if (rankarray[i] <= max)
					{
						if (rankarray[i] <= media)
							tleft[inst]++;
						else if (rankarray[i] > media)
							trigth[inst]++;
					}
				}
			}
			else if (omax == CONF_COLLECTION_DISTRIBUTED)
			{
				for (P i = (inst % nthreads); i < nelements; i += nthreads)
				{
					if (min < rankarray[i])
					{
						if (rankarray[i] <= media)
							tleft[inst]++;
						else if (rankarray[i] > media)
							trigth[inst]++;
					}
				}
			}
			else
			{
				for (P i = (inst % nthreads); i < nelements; i += nthreads)
				{
					if (min < rankarray[i] && rankarray[i] <= max)
					{
						if (rankarray[i] <= media)
							tleft[inst]++;
						else if (rankarray[i] > media)
							trigth[inst]++;
					}
				}
			}
		}

		P prevleft = leftsum;

		sync_threads(barrier[mcpos]);

		// check if media can be used to divide to half
		for (instance_t i = omin; i < (omin + nthreads); i++)
		{
			leftsum += tleft[i];
			rigthsum += trigth[i];
		}

		// algorithm cannot find mediana
		// and get this result on the first attempt is a very unusual case
		if (prevleft == leftsum)
		{
			// cerr << "Error on instance " << inst << " (" << error_size_sum << ',' << prevleft << ',' << rigthsum << ") " << threshold << endl;
			error[inst] = true;
		}

		sync_threads(barrier[mcpos]);

		// Check if this media cloud had gived error
		for (instance_t i = omin; i < (omin + nthreads); i++)
			if (error[i] == true)
			{
				_error = true;

				nthreads /= 2;

				break;
			}

		if (_error == true)
			continue;

		// already balanced, pivot solved (continue...)
		if ((leftsum > (rigthsum - threshold) && leftsum <= rigthsum) || (rigthsum > (leftsum - threshold) && rigthsum <= leftsum))
		{
			if (inst == mcpos)
				mcloud[mcpos] = media;

			// tell rigth size for each mediana (pivot)
			if (nthreads == 2)
			{
				if ((inst % 2) == 0)
					mcloudsize[inst] = leftsum;
				else
					mcloudsize[inst] = rigthsum;
			}

			nthreads /= 2;

			continue; // find pivot
		}

		P tower_size = 0;

		if (rigthsum > leftsum)
		{
			T **start = NULL;
			towers[inst] = CBALLOC(T *, MALLOC, (trigth[inst] + 1));
			towers[inst][trigth[inst]] = NULL;
			trmedia[inst] = (T)0;
			trmediasize[inst] = 0;
			tlmediasize[inst] = tleft[inst];
			start = towers[inst];

			if (nthreads == CONF_COLLECTION_DISTRIBUTED)
				for (P i = inst; i < nelements; i += nthreads)
				{
					if (rankarray[i] > media)
					{
						trmedia[inst] = (((trmedia[inst] / (trmediasize[inst] + 1)) * trmediasize[inst]) + (rankarray[i] / (trmediasize[inst] + 1)));
						trmediasize[inst]++;
						towers[inst][tower_size] = &rankarray[i];
						tower_size++;
					}
				}
			else
			{
				T val = 0;

				if (omax == CONF_COLLECTION_DISTRIBUTED)
					val = 0;
				else
					val = mcloud[omax];
					
				const T max = val;
				const T min = mcloud[omin];

				if (omin == 0)
				{
					for (P i = (inst % nthreads); i < nelements; i += nthreads)
					{
						if (rankarray[i] > media && rankarray[i] <= max)
						{
							trmedia[inst] = (((trmedia[inst] / (trmediasize[inst] + 1)) * trmediasize[inst]) + (rankarray[i] / (trmediasize[inst] + 1)));
							trmediasize[inst]++;
							towers[inst][tower_size] = &rankarray[i];
							tower_size++;
						}
					}
				}
				else if (omax == CONF_COLLECTION_DISTRIBUTED)
				{
					for (P i = (inst % nthreads); i < nelements; i += nthreads)
					{
						if (rankarray[i] > media && min < rankarray[i])
						{
							trmedia[inst] = (((trmedia[inst] / (trmediasize[inst] + 1)) * trmediasize[inst]) + (rankarray[i] / (trmediasize[inst] + 1)));
							trmediasize[inst]++;
							towers[inst][tower_size] = &rankarray[i];
							tower_size++;
						}
					}
				}
				else
				{
					for (P i = (inst % nthreads); i < nelements; i += nthreads)
					{
						if (rankarray[i] > media && min < rankarray[i] && rankarray[i] <= max)
						{
							trmedia[inst] = (((trmedia[inst] / (trmediasize[inst] + 1)) * trmediasize[inst]) + (rankarray[i] / (trmediasize[inst] + 1)));
							trmediasize[inst]++;
							towers[inst][tower_size] = &rankarray[i];
							tower_size++;
						}
					}
				}
			}

			towers[inst] = start;
		}
		else
		{
			T **start = NULL;
			towers[inst] = CBALLOC(T *, MALLOC, (tleft[inst] + 1));
			towers[inst][tleft[inst]] = NULL;
			tlmedia[inst] = (T)0;
			tlmediasize[inst] = 0;
			trmediasize[inst] = trigth[inst];
			start = towers[inst];

			if (nthreads == CONF_COLLECTION_DISTRIBUTED)
				for (P i = inst; i < nelements; i += nthreads)
				{
					if (rankarray[i] <= media)
					{
						tlmedia[inst] = (((tlmedia[inst] / (tlmediasize[inst] + 1)) * tlmediasize[inst]) + (rankarray[i] / (tlmediasize[inst] + 1)));
						tlmediasize[inst]++;
						towers[inst][tower_size] = &rankarray[i];
						tower_size++;
					}
				}
			else
			{
				T val = 0;

				if (omax == CONF_COLLECTION_DISTRIBUTED)
					val = 0;
				else
					val = mcloud[omax];
					
				const T max = val;
				const T min = mcloud[omin];

				if (omin == 0)
					for (P i = (inst % nthreads); i < nelements; i += nthreads)
					{
						if (rankarray[i] <= media && rankarray[i] <= max)
						{
							tlmedia[inst] = (((tlmedia[inst] / (tlmediasize[inst] + 1)) * tlmediasize[inst]) + (rankarray[i] / (tlmediasize[inst] + 1)));
							tlmediasize[inst]++;
							towers[inst][tower_size] = &rankarray[i];
							tower_size++;
						}
					}
				else if (omax == CONF_COLLECTION_DISTRIBUTED)
					for (P i = (inst % nthreads); i < nelements; i += nthreads)
					{
						if (rankarray[i] <= media && min < rankarray[i])
						{
							tlmedia[inst] = (((tlmedia[inst] / (tlmediasize[inst] + 1)) * tlmediasize[inst]) + (rankarray[i] / (tlmediasize[inst] + 1)));
							tlmediasize[inst]++;
							towers[inst][tower_size] = &rankarray[i];
							tower_size++;
						}
					}
				else
					for (P i = (inst % nthreads); i < nelements; i += nthreads)
					{
						if (rankarray[i] <= media && min < rankarray[i] && rankarray[i] <= max)
						{
							tlmedia[inst] = (((tlmedia[inst] / (tlmediasize[inst] + 1)) * tlmediasize[inst]) + (rankarray[i] / (tlmediasize[inst] + 1)));
							tlmediasize[inst]++;
							towers[inst][tower_size] = &rankarray[i];
							tower_size++;
						}
					}
			}

			towers[inst] = start;
		}

		toldleft[inst] = 0;
		toldrigth[inst] = 0;
		tleft[inst] = leftsum; // from this point, each element of 'tleft' array contain same value as sum of instance's left
		trigth[inst] = rigthsum; // from this point, each element of 'trigth' array contain same value as sum of instance's rigth
		P prev_max_offset = tower_size;
		P max_offset = tower_size;
		unsigned long int error_count = 0;

		sync_threads(barrier[mcpos]);

		/*
		 * Split mcloud as required by threshold.
		 * N.B. mcloud is the sum of medians finds by single thread dedicated by the 'step'
		 */
		while (true)
		{
			if (tleft[inst] > (trigth[inst] + threshold))
			{
				media = 0;
				mediasize = 0;

				toldrigth[inst] = trmediasize[inst] + toldrigth[inst];

				for (instance_t i = omin; i < (omin + nthreads); i++)
					mediasize += tlmediasize[i]; 

				for (instance_t i = omin; i < (omin + nthreads); i++)
					media += ((tlmedia[i] / mediasize) * tlmediasize[i]);
			}
			else if (trigth[inst] > (tleft[inst] + threshold))
			{
				media = 0;
				mediasize = 0;

				toldleft[inst] = tlmediasize[inst] + toldleft[inst];

				for (instance_t i = omin; i < (omin + nthreads); i++)
					mediasize += trmediasize[i]; 

				for (instance_t i = omin; i < (omin + nthreads); i++)
					media += ((trmedia[i] / mediasize) * trmediasize[i]);
			}
			else
			{
				free(towers[inst]);

				if (inst == mcpos)
					mcloud[mcpos] = media;

				if (nthreads == 2)
				{
					if ((inst % 2) == 0)
						mcloudsize[inst] = tleft[inst];
					else
						mcloudsize[inst] = trigth[inst];
				}

				nthreads /= 2;

				solved = true; // find pivot
			}

			if (solved == true)
				break;

			// alarm: this thread on this cicle don't give new useful mediana, if possible try in next cicle
			// algorithm cannot find mediana
			if (error_size_sum > error_size_threshold)
				error[inst] = true;

			sync_threads(barrier[mcpos]);

			// Check if this media cloud had gived error
			for (instance_t i = omin; i < (omin + nthreads); i++)
				if (error[i] == true)
				{
					if (inst == mcpos) // Don't touch nthreads here. It must be calculated outside this function.
						mcloud[mcpos] = media;

					if (nthreads == 2)
					{
						if ((inst % 2) == 0)
							mcloudsize[inst] = tleft[inst];
						else
							mcloudsize[inst] = trigth[inst];
					}

					_error = true;

					break;
				}

			if (_error == true)
			{
				free(towers[inst]);

				nthreads /= 2;

				break;
			}

			P tlms = 0;
			P trms = 0;
			P tol = 0;
			P tor = 0;
			tlmedia[inst] = 0;
			trmedia[inst] = 0;
			tlmediasize[inst] = 0;
			trmediasize[inst] = 0;

			sync_threads(barrier[mcpos]);

			for (P min_offset = 0; min_offset < max_offset; min_offset++)
			{
				if (*towers[inst][min_offset] <= media)
					tlmediasize[inst]++;
				else if (*towers[inst][min_offset] > media)
					trmediasize[inst]++;
			}

			sync_threads(barrier[mcpos]);

			for (instance_t i = omin; i < (omin + nthreads); i++)
			{
				tlms += tlmediasize[i];
				trms += trmediasize[i];
				tol += toldleft[i];
				tor += toldrigth[i];
			}

			sync_threads(barrier[mcpos]);

			if ((tlms + tol) > (trms + tor))
			{
				tlmediasize[inst] = 0;

				for (P min_offset = 0; min_offset < max_offset; min_offset++)
				{
					if (*towers[inst][min_offset] <= media)
					{
						tlmedia[inst] = (((tlmedia[inst] / (tlmediasize[inst] + 1)) * tlmediasize[inst]) + (*towers[inst][min_offset] / (tlmediasize[inst] + 1)));
						tlmediasize[inst]++;
					}
					else
					{
						towers[inst][min_offset] = towers[inst][(max_offset - 1)];

						max_offset--;
						min_offset--;
					}
				}
			}
			else
			{
				trmediasize[inst] = 0;

				for (P min_offset = 0; min_offset < max_offset; min_offset++)
				{
					if (*towers[inst][min_offset] > media)
					{
						trmedia[inst] = (((trmedia[inst] / (trmediasize[inst] + 1)) * trmediasize[inst]) + (*towers[inst][min_offset] / (trmediasize[inst] + 1)));
						trmediasize[inst]++;
					}
					else
					{
						towers[inst][min_offset] = towers[inst][(max_offset - 1)];

						max_offset--;
						min_offset--;
					}
				}
			}

			// alarm: this thread on this cicle don't give new useful mediana, if possible try next cicle
			if (max_offset == prev_max_offset)
			{
				error_size[inst] += ((max_offset / nthreads) + error_count);
				error_count++;
			}

			prev_max_offset = max_offset;

			sync_threads(barrier[mcpos]);

			tleft[inst] = 0;
			trigth[inst] = 0;

			for (instance_t i = omin; i < (omin + nthreads); i++)
			{
				tleft[inst] += (tlmediasize[i] + toldleft[i]);
				trigth[inst] += (trmediasize[i] + toldrigth[i]);
				error_size_sum += error_size[i]; // errors sum on media cloud
			}

			// Note: inside the cicle while 'tleft[inst]' and 'trigth[inst]' (after barrier) must be contain same value per instance!!! 
			sync_threads(barrier[mcpos]);
		}
	} // End of get medians

	// Try to apply matrix only if all steps was reached
	if (nthreads == 1)
	{
		// Sync all threads before check errors
		sync_threads(barrier[0]);
   	    

		// call make_matrix
		if (check() == true)
			make_matrix(inst);
		else // execute with single thread
		{
			if (sp->go_ahead(inst))
			{
				// Prepare array for linearization
				for (P i = 0; i < nelements; i++)
					sourcepositions[i] = (P)(i + skip_count);

				cerr << "ordering, ";

				if (ascending == true)
					qsort_r(sourcepositions, nelements, sizeof(P), ascending_sortcmp<P, T>, rastart);
				else
					qsort_r(sourcepositions, nelements, sizeof(P), descending_sortcmp<P, T>, rastart);

				if (linearize == false)
				{
					sync_threads(barrier[0]);
       

					return;
				}

				// Shift, so newly the order starts from 0 offset
				sourcepositions = spstart;

				cerr << "assigning, ";

				// While linearizing
				// Avoid giving rank > 0 to position with rank = 0
				P _zero_counter = (P)0;

				// While linearizing
				// Avoid giving rank > 0 to position with rank = 0
				if (skip_all_zeros == false)
					for (P i = 0; i < nelements; i++)
						if (rankarray[i] == 0)
							_zero_counter++;

				T value = (T)0;

				assert(fract < nelements);

				if (fract == 0)
				{
					if (skip_all_zeros == false)
						value = ((T)1/(T)(nelements - _zero_counter));
					else
						value = ((T)1/(T)nelements);
				}
				else
					value = ((T)1/(T)fract);

				if (fract == 0)
				{
					if (skip_all_zeros == false)
					{
						if (ascending == true)
							for (P i = _zero_counter; i < nelements; i++)
								rastart[sourcepositions[(i + skip_count)]] = (value * (i - _zero_counter + 1));
						else
							for (P i = 0; i < (nelements - _zero_counter); i++)
								rastart[sourcepositions[(i + skip_count)]] = (1 - (value * i));
					}
					else
					{
						if (ascending == true)
							for (P i = 0; i < nelements; i++)
								rastart[sourcepositions[(i + skip_count)]] = (value * (i + 1));
						else
							for (P i = 0; i < nelements; i++)
								rastart[sourcepositions[(i + skip_count)]] = (1 - (value * i));
					}
				}
				else // da verificare in un caso reale
				{
					assert (is_ignored != NULL);

					if (ascending == true)
						for (P i = 0; i < nelements; i++)
						{
							P offset = (sourcepositions[(i + skip_count)]);

							if (is_ignored[offset] == true)
								rastart[offset] = (T)0;
							else if (rastart[offset] > 0)
								rastart[offset] = (value * (i + 1));
						}
					else
						for (P i = 0; i < nelements; i++)
						{
							P offset = (sourcepositions[(i + skip_count)]);

							if (is_ignored[offset] == true)
								rastart[offset] = (T)0;
							else if (rastart[offset] > 0)
								rastart[offset] = (1 - (value * i));
						}
				}

				cerr << "done." << endl;

				sync_threads(barrier[0]);

			}
			else sync_threads(barrier[0]);
        

			return;
		}
	}

	return;
}

//
// Name: make_matrix
//
// Description: Split really array in CCD chuncks e write inside without use any type of mutex...
//
// Input: Number of instance
//
// Return:
//
template <typename T, typename P> void CBotSort<T, P>::make_matrix(instance_t &inst)
{
	matrix[inst] = CBALLOC(size_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	const instance_t imax = (CONF_COLLECTION_DISTRIBUTED - 1);

	sync_threads(barrier[0]);

	// draws matrices (calculate orizzontal array sizes)
	if (ascending == true)
		for (P i = inst; i < nelements; i += CONF_COLLECTION_DISTRIBUTED)
		{
			instance_t grp_offset = 0;

			if (rankarray[i] <= mcloud[1])
					grp_offset = 0;
			else if (rankarray[i] > mcloud[imax])
					grp_offset = imax;
			else
				for (instance_t v = 1; v < imax; v++)
					if (mcloud[v] < rankarray[i] && rankarray[i] <= mcloud[(v + 1)])
						grp_offset = v;
			
			assert(grp_offset < CONF_COLLECTION_DISTRIBUTED);
			matrix[inst][grp_offset]++;
		}
	else
		for (P i = inst; i < nelements; i += CONF_COLLECTION_DISTRIBUTED)
		{
			instance_t grp_offset = 0;

			if (rankarray[i] > mcloud[imax])
					grp_offset = 0;
			else if (rankarray[i] <= mcloud[1])
					grp_offset = imax;
			else
				for (instance_t v = 1; v < imax; v++)
					if (mcloud[v] < rankarray[i] && rankarray[i] <= mcloud[(v + 1)])
						grp_offset = (imax - v);

			assert(grp_offset < CONF_COLLECTION_DISTRIBUTED);
			matrix[inst][grp_offset]++;
		}


	sync_threads(barrier[0]);

	P *o  = CBALLOC(P, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	// tip pointers 'o[?]' to relative offset
	for (instance_t grp_offset = 0; grp_offset < CONF_COLLECTION_DISTRIBUTED; grp_offset++)
	{
        if (grp_offset == 0)
		{
			P sum_vertical_offsets = 0;

			for (instance_t i = 0; i < inst; i++)
				sum_vertical_offsets += matrix[i][grp_offset];

			o[grp_offset] = sum_vertical_offsets;
		}
		else
		{
			P size_left_matrix = 0;
			P sum_vertical_offsets = 0;

			if (ascending == true)
				for (instance_t g = 0; g < grp_offset; g++)
					size_left_matrix += mcloudsize[g];
			else
				for (instance_t g = 0; g < grp_offset; g++)
					size_left_matrix += mcloudsize[(imax - g)];

			for (instance_t i = 0; i < inst; i++)
				sum_vertical_offsets += matrix[i][grp_offset];

			o[grp_offset] = (size_left_matrix + sum_vertical_offsets);
		}
    }

	// copy data...
	if (ascending == true)
		for (P i = inst; i < nelements; i += CONF_COLLECTION_DISTRIBUTED)
		{
			instance_t grp_offset = 0;

			if (rankarray[i] <= mcloud[1])
					grp_offset = 0;
			else if (rankarray[i] > mcloud[imax])
					grp_offset = imax;
			else
				for (instance_t v = 1; v < imax; v++)
					if (mcloud[v] < rankarray[i] && rankarray[i] <= mcloud[(v + 1)])
						grp_offset = v;

			assert(o[grp_offset] < nelements);
			sourcepositions[o[grp_offset]] = (P)(skip_count + i);;
			o[grp_offset]++;
		}
	else
		for (P i = inst; i < nelements; i += CONF_COLLECTION_DISTRIBUTED)
		{
			instance_t grp_offset = 0;

			if (rankarray[i] > mcloud[imax])
					grp_offset = 0;
			else if (rankarray[i] <= mcloud[1])
					grp_offset = imax;
			else
				for (instance_t v = 1; v < imax; v++)
					if (mcloud[v] < rankarray[i] && rankarray[i] <= mcloud[(v + 1)])
						grp_offset = (imax - v);

			assert(o[grp_offset] < nelements);
			sourcepositions[o[grp_offset]] = (P)(i + skip_count);;
			o[grp_offset]++;
		}

	free(o);

	sync_threads(barrier[0]);

	free(matrix[inst]);

	P offset = 0;

	if (ascending == true)
	{
		for (instance_t i = 0; i < inst; i++)
			offset += mcloudsize[i];

		qsort_r(&sourcepositions[offset], mcloudsize[inst], sizeof(P), ascending_sortcmp<P, T>, rastart);
	}
	else
	{
		for (instance_t i = 0; i < inst; i++)
			offset += mcloudsize[(imax - i)];

		qsort_r(&sourcepositions[offset], mcloudsize[(imax - inst)], sizeof(P), descending_sortcmp<P, T>, rastart);
	}

	if (linearize == false)
		return;

	sync_threads(barrier[0]);

	ccerr << "assigning, ";

	// While linearizing
	// Avoid giving rank > 0 to position with rank = 0
	if (skip_all_zeros == false)
	{
		if (ascending == true)
		{
			for (P i = inst; i < mcloudsize[0]; i += CONF_COLLECTION_DISTRIBUTED)
				if (rastart[sourcepositions[i]] == 0)
					zero_counter[inst]++;
		}
		else
		{
			for (P i = (nelements - inst - 1); i > mcloudsize[imax]; i -= CONF_COLLECTION_DISTRIBUTED)
				if (rastart[sourcepositions[i]] == 0)
					zero_counter[inst]++;
		}		
	}

	sync_threads(barrier[0]);
       
	P _zero_counter = (P)0;

	if (skip_all_zeros == false)
		for (instance_t x = 0; x < CONF_COLLECTION_DISTRIBUTED; x++)
			_zero_counter += zero_counter[x];

	assert(_zero_counter <= nelements);

	sync_threads(barrier[0]);

	T value = (T)0;

	assert(fract < nelements);

	if (fract == 0)
	{
		if (skip_all_zeros == false)
			value = ((T)1/(T)(nelements - _zero_counter));
		else
			value = ((T)1/(T)nelements);
	}
	else
		value = ((T)1/(T)fract);

	if (fract == 0)
	{
		if (skip_all_zeros == false)
		{
			if (ascending == true)
				for (P i = (inst + _zero_counter); i < nelements; i += CONF_COLLECTION_DISTRIBUTED)
					rastart[sourcepositions[i]] = (value * (i - _zero_counter + 1));
			else
				for (P i = inst; i < (nelements - _zero_counter); i += CONF_COLLECTION_DISTRIBUTED)
					rastart[sourcepositions[i]] = (1 - (value * i));
		}
		else
		{
			if (ascending == true)
				for (P i = inst; i < nelements; i += CONF_COLLECTION_DISTRIBUTED)
					rastart[sourcepositions[i]] = (value * (i + 1));
			else
				for (P i = inst; i < nelements; i += CONF_COLLECTION_DISTRIBUTED)
					rastart[sourcepositions[i]] = (1 - (value * i));
		}
	}
	else // da verificare in un caso reale
	{
		assert (is_ignored != NULL);

		if (ascending == true)
			for (P i = inst; i < nelements; i += CONF_COLLECTION_DISTRIBUTED)
			{
				if (is_ignored[sourcepositions[i]] == true)
					rastart[sourcepositions[i]] = (T)0;
				else if (rastart[sourcepositions[i]] > 0)
					rastart[sourcepositions[i]] = (value * (i + 1));
			}
		else
			for (P i = inst; i < nelements; i += CONF_COLLECTION_DISTRIBUTED)
			{
				if (is_ignored[sourcepositions[i]] == true)
					rastart[sourcepositions[i]] = (T)0;
				else if (rastart[sourcepositions[i]] > 0)
					rastart[sourcepositions[i]] = (1 - (value * i));
			}
	}


	ccerr << "done. ";

	sync_threads(barrier[0]);
}

#endif
