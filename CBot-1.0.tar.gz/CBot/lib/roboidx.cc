/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "roboidx.h"

//
// Name: roboidx_open
//
// Description:
//   opens or creates a robo index in a directory
//
// Input:
//   dirname - name of the directory to be created
//
// Return:
//   the structure
//

Storage *roboidx_open( const char *dirname, bool readonly )
{
	if (thread_alarm != THREADS_OK)
		return NULL;

    // Check if there is all main files in storage
	bool storage_found = true;
	char filename[MAX_STR_LEN];

	Storage *ridx = NULL;

	for (unsigned int i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		// Copy directory name
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, i);
		assert( strlen(relative_rem_path) < MAX_STR_LEN );

        // Open the main files
		sprintf( filename, "%s/%s", relative_rem_path, STORAGE_FILENAME_MAIN );
		free(relative_rem_path);

		struct stat64 buf;
		stat64(filename, &(buf));

		if (errno != 0)
		{
			storage_found = false;
			break;
		}
	}

	if (storage_found == false && readonly == true )
		die( "Can't create roboidx in readonly mode" );

	ridx = new Storage ( dirname, readonly );

	if (ridx == NULL)
		die( "Can't open roboidx" );

	if (storage_found == false)
		ridx->st_create();
	else
		ridx->st_open();

	// Returns
	return ridx;
}
