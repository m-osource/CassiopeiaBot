/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "file.h"

#ifdef DEBUG

//
// Description: close file stream
//
// Input:
//   freference - the reference of file
//   name - the name of program or the name of class where is executed
//   funcname - the name of the function or program where is executed
//   filen - the filename to close needed for debugging
//
// Return:
//
void CBotfclose(const char *date, const char *time, const char *file, int line, FILE *freference, char *name, char *funcname, const char *filen)
{
	assert(name != NULL);
	assert(funcname != NULL);

	if (freference == NULL)
			CBotdie(date, time, file, line, "%s %s: couldn't close %s filehandle because null\n", name, funcname, filen);

	int rc = 0;

	errno = 0; // errno is thread-local

	rc = fclose(freference);

	if (errno != 0)
			CBotdie(date, time, file, line, "%s %s: couldn't close %s filehandle %s\n", name, funcname, filen, CBoterr(errno));

	if (rc != 0)
			CBotdie(date, time, file, line, "%s %s: couldn't close %s filehandle return invalid status\n", name, funcname, filen);

	freference = NULL;

	return;
}

//
// Description: close file freference
//
// Input:
//   freference - the reference of file
//   name - the name of program or the name of class where is executed
//   funcname - the name of the function or program where is executed
//   filen - the filename to close needed for debugging
//
// Return:
//
void CBotfclose(const char *date, const char *time, const char *file, int line, int &freference, char *name, char *funcname, const char *filen)
{
	assert(name != NULL);
	assert(funcname != NULL);

	if (fcntl(freference, F_GETFL) == 1)
			CBotdie(date, time, file, line, "%s %s: %s do not have a valid file descriptor\n", name, funcname, filen);

	int rc = 0;

	errno = 0; // errno is thread-local

	rc = close(freference);

	if (errno != 0)
			CBotdie(date, time, file, line, "%s %s: couldn't close %s file descriptor %s\n", name, funcname, filen, CBoterr(errno));

	if (rc != 0)
			CBotdie(date, time, file, line, "%s %s: couldn't close %s file descriptor because return invalid status\n", name, funcname, filen);

	freference = 0;

	return;
}

#else

//
// Description: close file stream
//
// Input:
//   freference - the reference of file
//   name - the name of program or the name of class where is executed
//   funcname - the name of the function or program where is executed
//   filen - the filename to close needed for debugging
//
// Return:
//
void CBotfclose(FILE *freference, char *name, char *funcname, const char *filen)
{
	assert(name != NULL);
	assert(funcname != NULL);

	if (freference == NULL)
			die("%s %s: couldn't close %s filehandle because null\n", name, funcname, filen);

	int rc = 0;

	errno = 0; // errno is thread-local

	rc = fclose(freference);

	if (errno != 0)
			die("%s %s: couldn't close %s filehandle %s\n", name, funcname, filen, CBoterr(errno));

	if (rc != 0)
			die("%s %s: couldn't close %s filehandle because return invalid status\n", name, funcname, filen);

	freference = NULL;

	return;
}

//
// Description: close file freference
//
// Input:
//   freference - the reference of file
//   name - the name of program or the name of class where is executed
//   funcname - the name of the function or program where is executed
//   filen - the filename to close needed for debugging
//
// Return:
//
void CBotfclose(int &freference, char *name, char *funcname, const char *filen)
{
	assert(name != NULL);
	assert(funcname != NULL);

	if (fcntl(freference, F_GETFL) == 1)
			die("%s %s: %s do not have a valid file descriptor\n", name, funcname, filen);

	int rc = 0;

	errno = 0; // errno is thread-local

	rc = close(freference);

	if (errno != 0)
			die("%s %s: couldn't close %s file descriptor %s\n", name, funcname, filen, CBoterr(errno));

	if (rc != 0)
			die("%s %s: couldn't close %s file descriptor because return invalid status\n", name, funcname, filen);

	freference = 0;

	return;
}

#endif
