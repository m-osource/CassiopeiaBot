/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _DIE_H_INCLUDED_
#define _DIE_H_INCLUDED_

// Local libraries
#include "const.h"

// System libraries
#include <config.h>
#include <stdlib.h>
#include <signal.h>
#include <assert.h>
#include <string.h>
#include <syslog.h>
#include <stdio.h>
#include <stdarg.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>

// Preprocessor macro
#ifdef DEBUG
#define die( ... ) CBotdie( __DATE__, __TIME__, __FILE__, __LINE__, __VA_ARGS__ )
#else
#define die( ... ) CBotdie( __VA_ARGS__ )
#endif

#define cberr() CBoterr(errno)

using namespace std;

// Globals
extern pthread_mutex_t *console_lock;
extern atomic<thread_alarm_t> thread_alarm;


// External functions

// Classes

//
// Name: CBotException
//
// Description: keep exceptions on single thread and multithreads
//   Warning: exceptionally ctors and dtors function are in cleanup.cc
//
class CBotException: public exception
{
	atomic<thread_alarm_t> code;
	char *message;
	instance_t messages_size;
	char **messages;

public:

	CBotException(thread_alarm_t _C, char *_M); // ctor

	CBotException(thread_alarm_t _C, instance_t _S, char **_M); // ctor

	~CBotException(); // dtor

	virtual const char* what() const throw()
	{
		return message;
	}

	virtual const char** whats() const throw()
	{
		return (const char **)messages;
	}
};

//
// Name: CBotExitException
//
// Description: Create  an  exception-signaling  thread  exit  with  RETURN_VALUE.
//
class CBotExitException 
{
	// The  return  value  that  will  be  used  when  exiting  the  thread.
	CBotException *ex;
	bool sync_thread; // before exit require sync thread

public: 

	CBotExitException (thread_alarm_t _C, char *_M) // ctor
		: ex (NULL)
		, sync_thread (false)
	{
		if (_M)
		{
			ex = new CBotException (_C, _M);
			sync_thread = true;
		}
	} 

	CBotExitException (thread_alarm_t _C, instance_t _S, char **_M) // ctor
		: ex (NULL)
		, sync_thread (false)
	{
		ex = new CBotException (_C, _S, _M);
	} 

	~CBotExitException () // dtor
	{
	} 

	// Return the exception.
	CBotException* Exception( void ) const;

	// Exit from thread passing the exception to 'pthread_join'
	void DoThreadExit( void ) const;

	// Sync the threads and then exit from thread passing the exception to 'pthread_join'
	void DoThreadExit( pthread_barrier_t *barrier ) const;
}; 

// Functions
#ifdef DEBUG
void CBotdie( const char *date, const char *time, const char *file, int line, const char *format, ... );
#else
void CBotdie( const char *format, ... );
#endif

char *CBoterr(int &_errno);

#endif
