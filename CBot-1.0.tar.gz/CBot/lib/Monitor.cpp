/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "Monitor.h"

//
// Name: thread_function_caller
//
// Description:
//   A proxy function to pass non-static function at pthread_create
//   Note: function called by thread_function_caller need to have real class object passed through args
//
// Input:
//   args - void arguments
//
// Return:
//   pointer to void
//

void *Monitor::thread_function_caller(void *args)
{
	assert(args);

try
{
	Monitor::thread_args_t *arguments = (Monitor::thread_args_t *)args;

	Monitor *newObj = NULL;

	try
	{
		newObj = new Monitor (true); // Note function called work to 'this' temporary object and need to be deleted at the end of the same.
	}
	catch (std::bad_alloc& ba)
	{
		die("thread_function_caller bad_alloc caught: %s", ba.what());
	}

	switch (arguments->f)
	{
		case MONITOR_OPEN:
			newObj->thread_function_open(args);
			break;
		case MONITOR_CLOSE:
			newObj->thread_function_close(args);
			break;
		case MONITOR_REMOVE:
			newObj->thread_function_remove(args);
			break;
		default:
			break;
	}

	delete newObj;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL); 
}

	free(args);
	args = NULL;

	return NULL;
}

void Monitor::convert_old_monmaster_file(char *infile, bool quiet)
{
	char outfile[MAX_STR_LEN];
	sprintf(outfile, "%s.tmp", infile);

	if (quiet == false)
		cerr << "Converting monmaster file ... ";
/*
	// Create file
	FILE *in = fopen64(infile, "r");
	assert(in != NULL);
	FILE *out = fopen64(outfile, "w");
	assert(out != NULL);

	doc_old_t doc_old;
	doc_t doc_new;

	doc_default(&(doc_new));

	for(siteid_t i = 0; i < CONF_COLLECTION_MAXDOC; i++) {
		fread(&doc_old, sizeof(doc_old_t), 1, in);

		doc_new.docid				= doc_old.docid;
		doc_new.siteid				= doc_old.siteid;
		doc_new.status       	  	= doc_old.status;
		doc_new.mime_type			= doc_old.mime_type;
		doc_new.http_status        	= doc_old.http_status;

		doc_new.effective_speed    	= doc_old.effective_speed;
		doc_new.latency				= 0;
		doc_new.latency_connect		= 0;

		doc_new.number_visits      	= doc_old.number_visits;
		doc_new.number_visits_changed    = doc_old.number_visits_changed;

		doc_new.time_unchanged     	= doc_old.time_unchanged;
		doc_new.first_visit        	= doc_old.first_visit;
		doc_new.last_visit			= doc_old.last_visit;
		doc_new.last_modified      	= doc_old.last_modified;

		doc_new.raw_content_length 	= doc_old.raw_content_length;
		doc_new.content_length     	= doc_old.content_length;
		doc_new.duplicate_of		= doc_old.duplicate_of;

		doc_new.depth              	= doc_old.depth;
		doc_new.is_dynamic			= doc_old.is_dynamic;

		doc_new.in_degree			= doc_old.in_degree;
		doc_new.out_degree			= doc_old.out_degree;

		doc_new.pagerank			= doc_old.pagerank;
		doc_new.wlrank            	= doc_old.wlrank;
		doc_new.hubrank           	= doc_old.hubrank;
		doc_new.authrank          	= doc_old.authrank;

		doc_new.freshness			= doc_old.freshness;
		doc_new.current_score		= doc_old.current_score;
		doc_new.future_score		= doc_old.future_score;

		fwrite(&doc_new, sizeof(doc_t), 1, out);
	}

	if (quiet == false)
		cerr << "done" << endl;

	fclose(in);
	fclose(out);

	rename(outfile, infile);
*/
}

void Monitor::convert_old_monremote_file(char *infile, bool quiet)
{
	char outfile[MAX_STR_LEN];
	sprintf(outfile, "%s.tmp", infile);

	if (quiet == false)
		cerr << "Converting monremote file ... ";
/*
	// Create file
	FILE *in = fopen64(infile, "r");
	assert(in != NULL);
	FILE *out = fopen64(outfile, "w");
	assert(out != NULL);

	doc_old_t doc_old;
	doc_t doc_new;

	doc_default(&(doc_new));

	for(siteid_t i = 0; i < CONF_COLLECTION_MAXDOC; i++) {
		fread(&doc_old, sizeof(doc_old_t), 1, in);

		doc_new.docid				= doc_old.docid;
		doc_new.siteid				= doc_old.siteid;
		doc_new.status       	  	= doc_old.status;
		doc_new.mime_type			= doc_old.mime_type;
		doc_new.http_status        	= doc_old.http_status;

		doc_new.effective_speed    	= doc_old.effective_speed;
		doc_new.latency				= 0;
		doc_new.latency_connect		= 0;

		doc_new.number_visits      	= doc_old.number_visits;
		doc_new.number_visits_changed    = doc_old.number_visits_changed;

		doc_new.time_unchanged     	= doc_old.time_unchanged;
		doc_new.first_visit        	= doc_old.first_visit;
		doc_new.last_visit			= doc_old.last_visit;
		doc_new.last_modified      	= doc_old.last_modified;

		doc_new.raw_content_length 	= doc_old.raw_content_length;
		doc_new.content_length     	= doc_old.content_length;
		doc_new.duplicate_of		= doc_old.duplicate_of;

		doc_new.depth              	= doc_old.depth;
		doc_new.is_dynamic			= doc_old.is_dynamic;

		doc_new.in_degree			= doc_old.in_degree;
		doc_new.out_degree			= doc_old.out_degree;

		doc_new.pagerank			= doc_old.pagerank;
		doc_new.wlrank            	= doc_old.wlrank;
		doc_new.hubrank           	= doc_old.hubrank;
		doc_new.authrank          	= doc_old.authrank;

		doc_new.freshness			= doc_old.freshness;
		doc_new.current_score		= doc_old.current_score;
		doc_new.future_score		= doc_old.future_score;

		fwrite(&doc_new, sizeof(doc_t), 1, out);
	}

	if (quiet == false)
		cerr << "done" << endl;

	fclose(in);
	fclose(out);

	rename(outfile, infile);
*/
}

void Monitor::open(void)
{
	if (thread_alarm != THREADS_OK)
		return;

	// Request memory for the structure
	m = CBALLOC(monitor_t, NEW, 1);
	mm = CBALLOC(mon_master_t, NEW, 1);
	mm_cache = CBALLOC(monmaster_t, NEW, 1);
	mm_cache2 = CBALLOC(monmaster_t, NEW, 1);

	m->readonly = this->readonly;

	char filename[MAX_STR_LEN];
	struct stat64 statbuf;

	// Go ahead .... Create or open monitor master filename
	sprintf(filename, "%s/%s", DataRetention::drdir(DataRetention::REMDR), MONITOR_FILENAME_MASTER);

	errno = 0; // errno is thread-local

	// Check if file exists
	if(stat64(filename, &statbuf) == 0)
	{
		// Verify file size
		if ((internal_long_uint_t)(statbuf.st_size) != sizeof(monmaster_t))
		{
			if ((internal_long_uint_t)(statbuf.st_size) != sizeof(monmaster_old_t))
			{
				cerr << "Inconsistency in monmaster_t:" << endl;
				cerr << "- Sizeof(monmaster_t)        : " << sizeof(monmaster_t) << endl;
				cerr << "- Sizeof(monmaster_old_t)    : " << sizeof(monmaster_old_t) << endl;
				cerr << "- Size of current file : " << (internal_long_uint_t)(statbuf.st_size) << endl;
				cerr << "- Expected size        : " << sizeof(monmaster_t) << endl;
				die("Inconsistency in monmaster_t");
			}
			else
				convert_old_monmaster_file(filename, false);
		}

		if (this->readonly)
			mm->file_monitor_master = open64(filename, O_RDONLY);
		else
			mm->file_monitor_master = open64(filename, O_RDWR, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (errno != 0)
			die("Monitor open: couldn't open monitor master file %s on %s\n", cberr(), filename);

		// Load structure on cache
        assert(lseek(mm->file_monitor_master, (off64_t)0, SEEK_SET) == 0);

        if (errno != 0)
            die("Monitor open: couldn't seek monitor master file %s on %s\n", cberr(), filename);

        assert(read(mm->file_monitor_master, mm_cache, sizeof(monmaster_t)) == sizeof(monmaster_t));

        if (errno != 0)
            die("Meta ddx_open: couldn't read monitor master file %s on %s\n", cberr(), filename);

		memcpy(mm_cache2, mm_cache, sizeof(monmaster_t));
	}
	else
	{
		// Check readonly
		if(this->readonly)
			die("Couldn't create index: readonly mode enabled");

		// Create file
		mm->file_monitor_master = open64(filename, O_RDWR|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (mm->file_monitor_master == -1 && errno != 0)
			die("Monitor open: couldn't open monitor remote file %s on %s\n", cberr(), filename);

		memset(mm_cache, 0, sizeof(monmaster_t));

		// Set initial values
		mm_cache->instance = CONF_COLLECTION_DISTRIBUTED; // Cannot be changed without reset collection
		mm_cache->commands = MON_COM_FALSE;
/*
		mr_data.meta_old_sizeof_sites = (sizeof(site_t) * (CONF_COLLECTION_MAXSITE + 1)); // aggiungere '1' anche su Meta...
		mr_data.meta_sizeof_sites = (sizeof(site_t) * (CONF_COLLECTION_MAXSITE + 1));

		// set default site options
		mr_data.options = SITE_OPT_FALSE;
        mr_data.options += SITE_OPT_DENY;
        mr_data.options += SITE_OPT_NEW;

		mr_data.meta_old_sizeof_optmask_sites = (sizeof(site_options_t) * CONF_COLLECTION_MAXSITE);
		mr_data.meta_sizeof_optmask_sites = (sizeof(site_options_t) * CONF_COLLECTION_MAXSITE);
		mr_data.meta_old_sizeof_docs = (sizeof(doc_t) * (CONF_COLLECTION_MAXDOC + 1));
		mr_data.meta_sizeof_docs = (sizeof(doc_t) * (CONF_COLLECTION_MAXDOC + 1));

*/
		memcpy(mm_cache2, mm_cache, sizeof(monmaster_t));
		write(mm->file_monitor_master, mm_cache, sizeof(monmaster_t));
	}

	m->distributed = CBALLOC(mon_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

//	use_lock = CBALLOC(bool, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Monitor::thread_args_t *args = CBALLOC(Monitor::thread_args_t, MALLOC, 1);
	    args->inst = inst;
    	args->obj = this;
	//	args->d = (char *)this->dirname;
		args->f = MONITOR_OPEN;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_open((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}
}

//
// Name: thread_function_open
//
// Description: invoked by 'monitor_open' as thread
//
// Arguments: a void pointer to thread_function_args_t type structure 
//
// Return: NULL
//
void *Monitor::thread_function_open(void *args)
{
	cpu_set_t system_cpus;

	Monitor::thread_args_t *arguments = (Monitor::thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

//	char *dirname = arguments->d;
	Monitor *obj = arguments->obj;
	assert(obj->m != NULL);
	monitor_t *m = obj->m;

	m->distributed[inst].m_cache = CBALLOC(monremote_t, NEW, 1);
	m->distributed[inst].m_cache2 = CBALLOC(monremote_t, NEW, 1);


	char filename[MAX_STR_LEN];
	struct stat64 statbuf;

	// Copy directory name
    sprintf(m->distributed[inst].dirname, "%s/distr%lu", DataRetention::drdir(DataRetention::REMDR), (unsigned long int)inst);

	// Go ahead .... Create or open filename
	sprintf(filename, "%s/%s", m->distributed[inst].dirname, MONITOR_FILENAME_REMOTE);

	errno = 0; // errno is thread-local

	// Check if file exists
	if(stat64(filename, &statbuf) == 0)
	{
		// Verify file size
		if ((internal_long_uint_t)(statbuf.st_size) != sizeof(monremote_t))
		{
			if ((internal_long_uint_t)(statbuf.st_size) != sizeof(monremote_old_t))
			{
				cerr << "Inconsistency in monremote_t:" << endl;
				cerr << "- Distributed          : " << inst << endl;
				cerr << "- Sizeof(monremote_t)        : " << sizeof(monremote_t) << endl;
				cerr << "- Sizeof(monremote_old_t)    : " << sizeof(monremote_old_t) << endl;
				cerr << "- Size of current file : " << (internal_long_uint_t)(statbuf.st_size) << endl;
				cerr << "- Expected size        : " << sizeof(monremote_t) << endl;
				die("Inconsistency in monremote_t on instance %lu", (unsigned long int)inst);
			}
			else
				convert_old_monremote_file(filename, false);
		}

		if (m->readonly)
			m->distributed[inst].file_monitor_remote = open64(filename, O_RDONLY);
		else
			m->distributed[inst].file_monitor_remote = open64(filename, O_RDWR, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (errno != 0)
			die("Monitor open: couldn't open monitor remote file %s on %s\n", cberr(), filename);

		// Load structure on cache
        assert(lseek(m->distributed[inst].file_monitor_remote, (off64_t)0, SEEK_SET) == 0);

        if (errno != 0)
            die("Monitor open: couldn't seek monitor remote file %s on %s\n", cberr(), filename);

        site_t site_header;
        assert(read(m->distributed[inst].file_monitor_remote, m->distributed[inst].m_cache, sizeof(monremote_t)) == sizeof(monremote_t));

        if (errno != 0)
            die("Meta ddx_open: couldn't read monitor remote file %s on %s\n", cberr(), filename);

		memcpy(m->distributed[inst].m_cache2, m->distributed[inst].m_cache, sizeof(monremote_t));
	}
	else
	{
		// Check readonly
		if(m->readonly)
			die("Couldn't create index: readonly mode enabled");

		// Create file
		m->distributed[inst].file_monitor_remote = open64(filename, O_RDWR|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (m->distributed[inst].file_monitor_remote == -1 && errno != 0)
			die("Monitor open: couldn't open monitor remote file %s on %s\n", cberr(), filename);

		memset(m->distributed[inst].m_cache, 0, sizeof(monremote_t));

		// Set initial values
		m->distributed[inst].m_cache->instance = inst; // Cannot be changed without reset collection
		m->distributed[inst].m_cache->meta_old_sizeof_sites = (sizeof(site_t) * (CONF_COLLECTION_MAXSITE + 1)); // aggiungere '1' anche su Meta...
		m->distributed[inst].m_cache->meta_sizeof_sites = (sizeof(site_t) * (CONF_COLLECTION_MAXSITE + 1));

		// set default site options like on Meta.cpp
		m->distributed[inst].m_cache->options = SITE_OPT_FALSE;
		m->distributed[inst].m_cache->options += SITE_OPT_DENY;
		m->distributed[inst].m_cache->options += SITE_OPT_NEW;

		m->distributed[inst].m_cache->meta_old_sizeof_optmask_sites = (sizeof(site_options_t) * CONF_COLLECTION_MAXSITE);
		m->distributed[inst].m_cache->meta_sizeof_optmask_sites = (sizeof(site_options_t) * CONF_COLLECTION_MAXSITE);
		m->distributed[inst].m_cache->meta_old_sizeof_docs = (sizeof(doc_t) * (CONF_COLLECTION_MAXDOC + 1));
		m->distributed[inst].m_cache->meta_sizeof_docs = (sizeof(doc_t) * (CONF_COLLECTION_MAXDOC + 1));

		memcpy(m->distributed[inst].m_cache2, m->distributed[inst].m_cache, sizeof(monremote_t));
		write(m->distributed[inst].file_monitor_remote, m->distributed[inst].m_cache, sizeof(monremote_t));
	}

//	arguments->d = NULL;
	return NULL;
}

//
// Name: close
//
// Description:
//   Closes a structure. Writes data to disk.
//
// Input:
//   monitor - the monitor structure
//
// Return: 
//   status code
//
monitor_status_t Monitor::close(void)
{
	if (thread_alarm != THREADS_OK)
		return MONITOR_ERROR;

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Monitor::thread_args_t *args = CBALLOC(Monitor::thread_args_t, MALLOC, 1);
	    args->inst = inst;
    	args->obj = this;
//		args->d = NULL;
		args->f = MONITOR_CLOSE;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_close((void *) args); // if only one distribution, function is call without thread
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}

	// Free
	free(m->distributed);

	delete [] m; m = NULL;

	int rc = 0;

	errno = 0; // errno is thread-local

	// check if file descriptors are valid
	assert(fcntl(mm->file_monitor_master, F_GETFL) != 1);

	if (errno != 0)
		die("Monitor close: documents do not have a valid file descriptor %s\n", cberr());

	if (this->readonly == true)
	{
		rc = ::close(mm->file_monitor_master);

		if (errno != 0)
			die("Monitor close: error closing monitor master file descriptor %s\n", cberr());

		assert(rc == 0);
		mm->file_monitor_master = 0;

		return MONITOR_ERROR;
	}

	// Write on structure only if there are changes
	if (memcmp(mm_cache, mm_cache2, sizeof(monmaster_t)) != 0)
	{
		assert(lseek(mm->file_monitor_master, (off64_t)0, SEEK_SET) == 0);

		if (errno != 0)
			die("Monitor close: couldn't seek monitor master file %s\n", cberr());

		assert(write(mm->file_monitor_master, mm_cache2, sizeof(monmaster_t)) == sizeof(monmaster_t));

		if (errno != 0)
			die("Monitor close: couldn't write monitor master file %s\n", cberr());

		rc = fsync(mm->file_monitor_master);

		if (errno != 0)
			die("Monitor ddx_close: error syncing doc file descriptor %s\n", cberr());

		assert(rc == 0);
	}

	rc = ::close(mm->file_monitor_master);

	if (errno != 0)
		die("Monitor ddx_close: error closing doc file descriptor %s\n", cberr());

	assert(rc == 0);
	mm->file_monitor_master = 0;

	delete [] mm_cache2; mm_cache2 = NULL;
	delete [] mm_cache; mm_cache = NULL;
	delete [] mm; mm = NULL;

	return MONITOR_OK;
}

//
// Name: thread_function_close
//
// Description: invoked by 'monitor_close' as thread
//
// Arguments: a void pointer to Monitor::thread_args_t type structure that contain instance and monitor_t type structure 
//
// Return: NULL
//
void *Monitor::thread_function_close(void *args)
{
	cpu_set_t system_cpus;

	Monitor::thread_args_t *arguments = (Monitor::thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	Monitor *obj = arguments->obj;
	assert(obj->m != NULL);
	monitor_t *m = obj->m;

	int rc = 0;

	errno = 0; // errno is thread-local

	// check if file descriptors are valid
	assert(fcntl(m->distributed[inst].file_monitor_remote, F_GETFL) != 1);

	if (errno != 0)
		die("Monitor close: documents do not have a valid file descriptor %s\n", cberr());

	if (m->readonly == true)
	{
		rc = ::close(m->distributed[inst].file_monitor_remote);

		if (errno != 0)
			die("Monitor close: error closing monitor remote file descriptor %s\n", cberr());

		assert(rc == 0);
		m->distributed[inst].file_monitor_remote = 0;

			return NULL;
	}


	// Write on structure only if there are changes
	if (memcmp(m->distributed[inst].m_cache, m->distributed[inst].m_cache2, sizeof(monremote_t)) != 0)
	{
		assert(lseek(m->distributed[inst].file_monitor_remote, (off64_t)0, SEEK_SET) == 0);

		if (errno != 0)
			die("Monitor close: couldn't seek monitor remote file %s\n", cberr());

		assert(write(m->distributed[inst].file_monitor_remote, m->distributed[inst].m_cache2, sizeof(monremote_t)) == sizeof(monremote_t));

		if (errno != 0)
			die("Monitor close: couldn't write monitor remote file %s\n", cberr());

		rc = fsync(m->distributed[inst].file_monitor_remote);

		if (errno != 0)
			die("Monitor ddx_close: error syncing doc file descriptor %s\n", cberr());

		assert(rc == 0);
	}

	rc = ::close(m->distributed[inst].file_monitor_remote);

	if (errno != 0)
		die("Monitor ddx_close: error closing doc file descriptor %s\n", cberr());

	assert(rc == 0);
	m->distributed[inst].file_monitor_remote = 0;

	delete [] m->distributed[inst].m_cache2; m->distributed[inst].m_cache2 = NULL;
	delete [] m->distributed[inst].m_cache; m->distributed[inst].m_cache = NULL;

	return NULL;
}

//
// Name: remove
//
// Description:
//   Removes files into directories monitor0, monitor1... and optionally monitor0, monitor1... (unneeded)
//
// Input:
//   

void Monitor::remove(void)
{
	struct stat64 statbuf;
	char relative_rem_path[MAX_STR_LEN];

	pthread_t *threads = NULL;

	instance_t max_instances = 0;

	// Create filename
	char filename[MAX_STR_LEN];
	sprintf(filename, "%s/%s", DataRetention::drdir(DataRetention::REMDR), MONITOR_FILENAME_MASTER);

	// Delete file monitor master
	int rc = unlink(filename);

	if (rc != 0 && errno != ENOENT)
		die("Couldn't unlink file %s %s", MONITOR_FILENAME_MASTER, cberr());

	// check how many directory contain data to delete
	for (instance_t inst = 0; inst < ((instance_t)(~0)); inst++)
	{
		relative_rem_path[0] = ASCII_NUL;

    	sprintf(relative_rem_path, "%s/distr%lu/", DataRetention::drdir(DataRetention::REMDR), (unsigned long int)inst);


		if (stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
			max_instances++;
		else
			break;
	}

	if (max_instances > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, max_instances);

		for (instance_t inst = 0; inst < max_instances; inst++)
		{
			Monitor::thread_args_t *args = CBALLOC(Monitor::thread_args_t, MALLOC, 1);
		    args->inst = inst;
    		args->obj = NULL;
//			args->d = (char *)this->dirname;
			args->f = MONITOR_REMOVE;

			if (max_instances > 1)
			{
				if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
					die("error creating thread!");
			}
			else
				thread_function_remove((void *) args); // only one distribution, function is call without thread 
		}

		CBotjoin(threads, max_instances);

		free(threads);
	}
}

//
// Name: thread_function_remove
//
// Description: invoked by 'monitor_remove' as thread
//
// Arguments: a void pointer to Monitor::thread_args_t type structure 
//
// Return: NULL
//
void *Monitor::thread_function_remove(void *args)
{
	cpu_set_t system_cpus;

	Monitor::thread_args_t *arguments = (Monitor::thread_args_t *)args;

	instance_t inst = arguments->inst;

//	CPU_OPTIMIZE;

//	char *dirname = arguments->d;
	char relative_rem_path[MAX_STR_LEN];
    sprintf(relative_rem_path, "%s/distr%lu", DataRetention::drdir(DataRetention::REMDR), (unsigned long int)inst);


	queue<string> files;

	// Push files
	files.push(MONITOR_FILENAME_REMOTE);

	errno = 0; // errno is thread-local

	// Delete
	while(! files.empty()) {

		// Create filename
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, files.front().c_str());

		// Delete file
		int rc = unlink(filename);

		if (rc != 0 && errno != ENOENT)
			die("Couldn't unlink file %s %s", files.front().c_str(), cberr());

		// Remove file from queue
		files.pop();
	}

//	arguments->d = NULL;

	return NULL;
}

//
// Name: option_set
//
// Description:
//    store option information about a command to be executed at a leter time by responsible program
//    Cuncurrecy writing CANNOT set the same bit to different value (eg. one to true and other to false)
//
// Input:
//    optmask - the monitor_comask_t value
//    boolean - true or false
//
// Return:
//    status code
//
monitor_status_t Monitor::command_set(monitor_comask_t optmask, bool boolean)
{
	assert(this->readonly == false);
	assert(mm_cache2);

	if ((bool)((mm_cache2->commands / optmask) % 2) == boolean)
		return MONITOR_OK; // already set
	else
		while (((bool)((mm_cache2->commands / optmask) % 2) != boolean))
		{
			if (boolean == true)
				mm_cache2->commands += optmask;
			else
				mm_cache2->commands -= optmask;
		}

	return MONITOR_OK;
}

//
// Name: option_get
//
// Description:
//    read option information about a command to be executed at a leter time by responsible program
//    Cuncurrecy writing CANNOT set the same bit to different value (eg. one to true and other to false)
//
// Input:
//    optmask - the monitor_comask_t value
//    boolean - true or false
//
// Return:
//    status code
//
monitor_status_t Monitor::command_get(monitor_comask_t optmask, bool boolean)
{
	assert(mm_cache);

	if ((bool)((mm_cache->commands / optmask) % 2) == boolean)
		return MONITOR_OK; // already set

	return MONITOR_KO;
}



/*
//
// Name: status_store
//
// Description:
//   Stores information about a document
//   With 'old_doc' it compare byte to byte struct before write to disk (performances reasons).
//
// Input:
//    monitor - the monitor structure
//    doc - the document to be stored
//    old_doc - the 'old_doc' to be compared with the new (only update)
// 
// Return:
//    status code
//
monitor_status_t Monitor::status_store(doc_t *doc)
{
	assert(doc->docid > 0);
	assert(doc->siteid > 0);
	assert(doc->docid < (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));
	assert(doc->siteid < (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));
	assert(!m->readonly);

	instance_t inst =	((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = (((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// Seek
	off64_t address = ((off64_t)sizeof(doc_t)) * id_offset;

	errno = 0; // errno is thread-local

	// Store
	ssize_t wr = pwrite64(m->distributed[inst].file_doc, doc, sizeof(doc_t), address);

	if (errno != 0)
		die("Monitor doc_store: for docid %llu couldn't write file (address %llu) %s\n", doc->docid, (unsigned long long int)address, cberr());

	assert(wr == (ssize_t)(sizeof(doc_t)));

	// Update distributed count
	if (id_offset > m->distributed[inst].count_doc)
		m->distributed[inst].count_doc = id_offset;

	docid_t check = m->count_doc;

	// Update the counter in thread-safe mode
	while (true)
	{
		if (doc->docid > check)
		{	// if counter have value expected as 'check' it can be updated
			if (m->count_doc.compare_exchange_strong(check, doc->docid) == true)
				break;
			else // else, check have new counter value updated from other threads during 'compare_exchange_strong' call
				continue;
		}
		else
			break;
	}

	return METADDX_OK;
}

// 
// Name: doc_retrieve
//
// Description:
//   Retrieves information about a document
//   This function is use only from 'ddx_close'
//
// Input:
//   monitor - metaindex holding the information
//   doc.docid - document id of the retrieved document
//
// Output:
//   doc - document
//
// Return:
//   METADDX_OK - success
//   METADDX_EOF - docid out of range
//
monitor_status_t Monitor::doc_retrieve(monitor_t *m, doc_t *doc)
{
	assert(doc->docid > 0);

	docid_t real_docid = doc->docid;
	instance_t inst =	((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	doc->docid = (((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// See if it's inside the range
	if(doc->docid > m->distributed[inst].count_doc) {
		doc->docid = real_docid;
		return METADDX_EOF;
	}

	errno = 0; // errno is thread-local

	// Retrieve
	ssize_t wr = pread64(m->distributed[inst].file_doc, doc, sizeof(doc_t), (off64_t)(sizeof(doc_t) * doc->docid));

	if (errno != 0)
		die("Monitor doc_retrieve: for docid %llu couldn't read file %s\n", doc->docid, cberr());

	assert(wr == (ssize_t)(sizeof(doc_t)));

	if(doc->docid == 0)
		return METADDX_EOF;
	else {
		doc->docid = real_docid;
		return METADDX_OK;
	}
}

// 
// Name: doc_retrieve
//
// Description:
//   Retrieves information about a document
//
// Input:
//   doc.docid - document id of the retrieved document
//
// Output:
//   doc - document
//
// Return:
//   METADDX_OK - success
//   METADDX_EOF - docid out of range
//
monitor_status_t Monitor::status_retrieve(doc_t *doc)
{
	assert(doc->docid > 0);

	docid_t real_docid = doc->docid;
	instance_t inst =	((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	doc->docid = (((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// See if it's inside the range
	if(doc->docid > m->distributed[inst].count_doc) {
		doc->docid = real_docid;
		return METADDX_EOF;
	}

	errno = 0; // errno is thread-local

	// Retrieve
	ssize_t wr = pread64(m->distributed[inst].file_doc, doc, sizeof(doc_t), (off64_t)(sizeof(doc_t) * doc->docid));

	if (errno != 0)
		die("Monitor doc_retrieve: for docid %llu couldn't read file %s\n", doc->docid, cberr());

	assert(wr == (ssize_t)(sizeof(doc_t)));

	if(doc->docid == 0)
		return METADDX_EOF;
	else {
		doc->docid = real_docid;
		return METADDX_OK;
	}

		return METADDX_OK; // temporaneo
}

// 
// Name: dump_doc_header
//
// Description:
//   Prints a line with the header data for dump_doc
//
// Input:
//   out - the output file handler
//

void Monitor::dump_doc_header(FILE *out)
{
	assert(out != NULL);
	char buffer[MAX_STR_LEN];
    int wc = 0;
	
	// The order is very important. It must be consistent with dump_doc
	wc = snprintf(buffer, MAX_STR_LEN, "1docid,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "2siteid,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "3domonitorid,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "4status,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "5mime_type,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "6http_status,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "7raw_content_length,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "8effective_speed,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "9latency,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "10latency_connect,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "11number_visits,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "12number_visits_changed,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "13time_unchanged,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "14first_visit,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "15last_visit,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "16last_modified,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "17content_length,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "18duplicate_of,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "19content_encoding,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "20last_modified_credits,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "21depth,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "22is_dynamic,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "23in_degree,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "24out_degree,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "25pagerank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "26wlrank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "27hubrank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "28authrank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "29liverank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "30freshness,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "31current_score,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "32future_score,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "33from_feed,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "34has_valid_mimetype,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "35sitemap changefreq,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "36sitemap priority\n");

	fprintf(out, buffer);
}
// 
// Name: dump_doc
//
// Description:
//   Prints a line with the data about a document
//
// Input:
//   doc - document
//   out - the output file handler
//

void Monitor::dump_doc(doc_t *doc, FILE *out)
{
	assert(doc != NULL);
	assert(out != NULL);

	char buffer[MAX_STR_LEN];
    int wc = 0;
	
	// The order is very important. It must be consistent with dump_doc_header
	wc = snprintf(buffer, MAX_STR_LEN, "%llu,",  (unsigned long long int)doc->docid);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,",  	(unsigned long int)doc->siteid);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,",  	(unsigned long int)doc->domonitorid);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->status));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->mime_type));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->http_status);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,",  	(long unsigned int)(doc->raw_content_length));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%f,",  	doc->effective_speed);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%f,",  	doc->latency);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%f,",  	doc->latency_connect);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->number_visits);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->number_visits_changed);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->time_unchanged));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->first_visit));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->last_visit));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->last_modified));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,",  	(long unsigned int)(doc->content_length));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,",  	(unsigned long int)doc->duplicate_of);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->content_encoding);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->last_modified_credits));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->depth);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->is_dynamic);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->in_degree);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->out_degree);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->pagerank);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->wlrank);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->hubrank);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->authrank);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->liverank);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->freshness);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->current_score);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->future_score);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->from_feed);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->has_valid_mimetype);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->sitemap_changefreq);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d\n",  	doc->sitemap_prio);

	fprintf(out, buffer);
}

// 
// Name: dump_doc_short_status
//
// Description:
//   Prints the status of a document in one line
//
// Input:
//   doc - document
//

void Monitor::dump_doc_short_status(doc_t *doc)
{
	// Status
	cerr << DOC_STATUS_STR(doc->status) << " ";
	cerr << MIME_TYPE_STR(doc->mime_type) << " ";
	cerr << HTTP_STR(doc->http_status) << ":"
		<<	HTTP_IS_STR(doc->http_status) << " ";

	// Scores
	cerr << "in " << doc->in_degree << " ";
	cerr << "out " << doc->out_degree << " ";
	cerr << "pr " << doc->pagerank;
	cerr << "wl " << doc->wlrank;
	cerr << "lr " << doc->liverank;
}

//
// Name: dump_status
// 
// Description:
//   Dumps the status of the monitor
//

void Monitor::dump_status(void)
{
	cerr << "Begin status dump for monitor" << endl;

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		cerr << "- dirname on distributed    " << (unsigned long int)inst << " is " << m->distributed[inst].dirname << endl;
		cerr << "- count_doc on distributed  " << (unsigned long int)inst << " is " << m->distributed[inst].count_doc << endl;
		cerr << "- count_site on distributed " << (unsigned long int)inst << " is " << m->distributed[inst].count_site << endl;
	}

	cerr << "- count_doc       " << m->count_doc << endl;
	cerr << "- count_site      " << m->count_site << endl;
	cerr << "- bytes per doc   " << sizeof(doc_t) << endl;
	cerr << "- bytes per site  " << sizeof(site_t) << endl;
	cerr << "End status dump for monitor" << endl;
}

//
// Name: doc_default
//
// Description:
//   Fills all the default data about a doc
//
// Input:
//   doc - empty doc object
//
// Output:
//   doc - fill doc object
//
void Monitor::doc_default(doc_t *doc)
{

	memset(doc, 0, sizeof(doc_t)); // to prevent valdrind warning set all (but really all) bytes to 0 in structure

	doc->docid					= (docid_t)0;
	// Siteid and domonitorid are not changed
	doc->status       			= STATUS_DOC_NEW;
	doc->mime_type				= MIME_UNKNOWN;
	doc->http_status			= 0;

	doc->effective_speed		= 0;
	doc->latency				= 0;
	doc->latency_connect		= (float)0;

	doc->number_visits      	= 0;
   	doc->number_visits_changed	= 0;

	doc->time_unchanged			= 0;
	doc->first_visit			= 0;
	doc->last_visit				= 0;
	doc->last_modified			= 0;

	doc->raw_content_length		= 0;
	doc->content_length			= 0;
	doc->hash_value_links		= CONF_HASH_DOC_MAX_DEFINITIVE;
	doc->duplicate_of			= 0;
	doc->content_encoding		= (content_encoding_t)0;
	doc->last_modified_credits	= 0;

	doc->depth					= (depth_t)1;
	doc->is_dynamic				= false;

	doc->in_degree				= 0;
	doc->out_degree				= 0;

	doc->pagerank				= (pagerank_t)0;
	doc->wlrank					= (wlrank_t)0;
	doc->hubrank				= (hubrank_t)0;
	doc->authrank				= (authrank_t)0;
	doc->liverank				= (liverank_t)0;

	doc->freshness				= 0;
	doc->current_score			= 0;
	doc->future_score			= 0;

	doc->charset				= CHARSET_UNKNOWN; //4 Bytes
	doc->language				= Language::UNKNOWN;

	doc->options				= (doc_options_t)0;

	doc->from_feed				= false;
	doc->has_valid_mimetype		= false;
	doc->abs_last_modified		= false;
	doc->sitemap_changefreq		= (sitemap_xml_changefreq_t)0;
	doc->sitemap_prio			= (sitemap_xml_priority_t)-1;

	doc->chunked				= false;
}
*/
