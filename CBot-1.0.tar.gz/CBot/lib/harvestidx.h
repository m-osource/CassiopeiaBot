/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _HARVESTIDX_INCLUDED_
#define _HARVESTIDX_INCLUDED_

#include <config.h>

// System libraries

#include <errno.h>
#include <map>
#include <string>
#include <queue>
#include <sys/types.h>
#include <dirent.h>
#include <magic.h>

// Local libraries

#include "const.h"
#include "die.h"
#include "file.h"
#include "xmlconf.h"
#include "linkidx.h"
#include "Meta.h"

// Filenames

#define HARVESTIDX_FILENAME_MAIN	"%s/%lu_harvestidx.harvest_t"

#define HARVESTIDX_FILENAME_DOC		"%s/%lu_harvestidx.doc_t"
#define HARVESTIDX_FILENAME_SITE	"%s/%lu_harvestidx.site_t"
#define HARVESTIDX_FILENAME_PATH	"%s/%lu_harvestidx.path.txt"
#define HARVESTIDX_FILENAME_SITENAME	"%s/%lu_harvestidx.sitename.txt"
#define HARVESTIDX_FILENAME_OCCURRED	"%s/%lu_harvestidx.occurred.txt"

// Possible status of a harvest

enum harvest_status_t {
	STATUS_HARVEST_EMPTY		= 0,
	STATUS_HARVEST_ASSIGNED_NEW	= 1,
	STATUS_HARVEST_ASSIGNED 	= 2,
	STATUS_HARVEST_RUNNING		= 3,
	STATUS_HARVEST_ABORTED		= 4,
	STATUS_HARVEST_DONE			= 5,
	STATUS_HARVEST_SEEDED		= 6
};

#define HARVEST_STATUS_STR(x) (\
		x==0 ? "STATUS_HARVEST_EMPTY" :\
		x==1 ? "STATUS_HARVEST_ASSIGNED_NEW" :\
		x==2 ? "STATUS_HARVEST_ASSIGNED" :\
		x==3 ? "STATUS_HARVEST_RUNNING" :\
		x==4 ? "STATUS_HARVEST_ABORTED" :\
		x==5 ? "STATUS_HARVEST_DONE" :\
		x==6 ? "STATUS_HARVEST_SEEDED" : "(invalid)" )


// Structure 

typedef struct {
	instance_t inst;
	unsigned int harvest_id;
	harvest_status_t harvest_status;
	FILE *links_download;
	FILE *links_log;
	FILE *links_stat;
	void *servers;
	void *a_channel;
	const void *a_options;
	const int *a_optmask;
	magic_t m_cookie;
	pthread_mutex_t *server_locks_a;
	pthread_mutex_t *server_locks_b;
	pthread_rwlock_t *server_rwlocks_b;
	bool testing; // set 'true' only from 'cbot-test-program_name'
} starter_t;

// Structure for a harvest

typedef struct {
	// Directory
	char dirname[MAX_STR_LEN];

	// Global id
	int	id;

	// Number and size
	uint count;
	uint count_ok;
	uint count_site;
	off64_t raw_size;               // Number of bytes downloaded
	off64_t size;                   // Number of bytes kept after parsing

	// Links discovered
	uint link_total;
	uint link_old_pages;
	uint link_new_pages;
	uint link_new_sites;

	// Host in which the harvest was run
	char hostname[MAX_STR_LEN];

	// Times
	time_t creationtime;            
	time_t begintime;
	time_t endtime;

	// Status for the harvest
	harvest_status_t status;

	// Volatile data
	// Readonly flag
	bool readonly;
	doc_t *doc_list;
	site_t *site_list;
	
	// Files
	FILE *file_doc;
	FILE *file_site;
	FILE *file_path;
	FILE *file_sitename;

	// Doc_map
	map <docid_t,string> *map_path;
	map <siteid_t,string> *map_sitename;
	map <siteid_t,site_t> *map_site;

} harvest_old_t;

// Structure for a harvest

typedef struct {
	// Directory
	char dirname[MAX_STR_LEN];

	// Global id
	int	id;

	// Number and size
	uint count;
	uint count_ok;
	uint count_site;
	off64_t raw_size;
	off64_t size;

	// Links discovered
	uint link_total;
	uint link_old_pages;
	uint link_new_pages;
	uint link_new_sites;

	// Host in which the harvest was run
	char hostname[MAX_STR_LEN];

	// Times
	time_t creationtime;            
	time_t begintime;
	time_t endtime;

	// Status for the harvest
	harvest_status_t status;

	// Statistics
	double	speed_ok;		// docs/sec.
	double	links_ratio;	// newlinks/total
	off64_t	bytes_in;		// total bytes read
	off64_t	bytes_out;		// total bytes written

	double	sum_pagerank;
	double	sum_wlrank;
	double	sum_hubrank;
	double	sum_authrank;
	double	sum_liverank;

	docid_t	sum_in_degree;
	uint	sum_depth;
	docid_t	sum_ok;

	// Reserved
	char reserved[500];

	// Volatile data
	// Readonly flag
	bool readonly;
	doc_t *doc_list;
	site_t *site_list;
	
	// Files
	FILE *file_doc;
	FILE *file_site;
	FILE *file_path;
	FILE *file_sitename;
	FILE *file_occurred;

	// Doc_map
	map <docid_t,string> *map_path;
	map <siteid_t,string> *map_sitename;
	map <siteid_t,site_t> *map_site;

} harvest_t;

enum harvest_call_t {
    HARVEST_CREATE                  = 0,
    HARVEST_OPEN                    = 1,
    HARVEST_CLOSE         	        = 2,
    HARVEST_PREPARE         	    = 3,
    HARVEST_ASSIGNED_ID             = 4,
    HARVEST_CANCEL_UNSEEDED         = 5,
    HARVEST_IS_FOUND                = 6,
    HARVEST_REMOVE                  = 7,
    HARVEST_REMOVE_ALL              = 8,
    HARVEST_REMOVE_FILES            = 9,
    HARVEST_DUMP_STATUS             = 11,
    HARVEST_ANALYZE_READING_HARVEST = 12,
    HARVEST_ANALYZE_ANALYZING_DOCS  = 13,
    HARVEST_ANALYZE_WRITE_DATA      = 14,
    HARVEST_EXTRACT_DUMP_DATA      = 15
};


//
// Name: Harvest
//
// Description: Class for harvesting
//
// Input:
//
// Return: 
//
class Harvest
{
	typedef struct _harvlist_t {
		unsigned int harvestid;
		harvest_status_t status;
		_harvlist_t *next;
	} harvlist_t;

	typedef struct {
		// Global id
		unsigned short id;

		// Number and size
		docid_t count;
		docid_t count_ok;
		siteid_t count_site;
		off64_t raw_size;
		off64_t size;

		// Links discovered
		internal_long_uint_t link_total;
		internal_long_uint_t link_old_pages;
		internal_long_uint_t link_new_pages;
		internal_long_uint_t link_new_sites;

		// Host in which the harvest was run
		char hostname[MAX_STR_LEN];

		// Times
		time_t creationtime;            
		time_t begintime;
		time_t endtime;

		// Status for the harvest
		harvest_status_t status;

		// Statistics
		double	speed_ok;		// docs/sec.
		double	links_ratio;	// newlinks/total
		off64_t	bytes_in;		// total bytes read
		off64_t	bytes_out;		// total bytes written

		double	sum_pagerank;
		double	sum_wlrank;
		double	sum_hubrank;
		double	sum_authrank;
		double	sum_liverank;

		docid_t	sum_in_degree;
		uint	sum_depth;
		docid_t	sum_ok;

		// Reserved
		// char reserved[500];

		// Volatile data
		// Readonly flag
		bool readonly;
		doc_t *doc_list;
		site_t *site_list;
		
		// Files
		FILE *file_doc;
		FILE *file_site;
		FILE *file_path;
		FILE *file_sitename;
		FILE *file_occurred;

		// Doc_map
		map <docid_t,string> *map_path;
		map <siteid_t,string> *map_sitename;
		map <siteid_t,site_t> *map_site;
	} harvest_old_t;

	typedef struct {
		// Global id
		unsigned int id;

		// Number and size -> note: uint old
		uint count;
		uint count_ok;
		uint count_site;
		//docid_t count;
		//docid_t count_ok;
		//siteid_t count_site;
		off64_t raw_size;
		off64_t size;

		// Links discovered
		uint link_total;
		uint link_old_pages;
		uint link_new_pages;
		uint link_new_sites;
		//internal_long_uint_t link_total;
		//internal_long_uint_t link_old_pages;
		//internal_long_uint_t link_new_pages;
		//internal_long_uint_t link_new_sites;

		// Host in which the harvest was run
		char hostname[MAX_STR_LEN];

		// Times
		time_t creationtime;            
		time_t begintime;
		time_t endtime;

		// Status for the harvest
		harvest_status_t status;

		// Statistics
		double	speed_ok;		// docs/sec.
		double	links_ratio;	// newlinks/total
		off64_t	bytes_in;		// total bytes read
		off64_t	bytes_out;		// total bytes written
/*
		double	sum_pagerank;
		double	sum_wlrank;
		double	sum_hubrank;
		double	sum_authrank;
		double	sum_liverank;

		docid_t	sum_in_degree;
		uint	sum_depth;
		docid_t	sum_ok;
*/
		// Reserved
		char reserved[500];

		// Volatile data
		// Readonly flag
		bool readonly;
		doc_t *doc_list;
		site_t *site_list;
		
		// Files
		FILE *file_doc;
		FILE *file_site;
		FILE *file_path;
		FILE *file_sitename;
		FILE *file_occurred;

		// Doc_map
		map <docid_t,string> *map_path;
		map <siteid_t,string> *map_sitename;
		map <siteid_t,site_t> *map_site;
	} harvest_t;

	typedef struct {
		atomic<harvest_status_t> status;
		atomic<unsigned int> count;
		atomic<unsigned int> count_ok;
		atomic<unsigned int> count_site;
		atomic<off64_t> raw_size;
		atomic<off64_t> size;
		atomic<unsigned int> link_total;
		atomic<unsigned int> link_old_pages;
		atomic<unsigned int> link_new_pages;
		atomic<unsigned int> link_new_sites;
		atomic<time_t> creationtime;            
		atomic<time_t> begintime;
		atomic<time_t> endtime;
		atomic<off64_t> bytes_in;		//> total bytes read
		atomic<off64_t> bytes_out;		//> total bytes written
	} harvest_volatile_status_t;

	harvest_t *distributed;
	const char *dirname;
	bool readonly;
	char *classname; // the function name called by single thread (used sometime)
	char *funcname; // the function name called by single thread (used sometime)
	unsigned int global_id; // Main id (must be the same value inside all instances)
	atomic<harvest_status_t> global_status; // Main status (must be the same value inside all instances)
	char global_hostname[MAX_STR_LEN]; // Main hostname (must be the same value inside all instances and cannot be initialized inside at declare classe time)
	time_t global_creationtime; // Main creation time (must be the same value inside all instances)
	time_t global_begintime; // Main creation time (must be the same value inside all instances)

	// Analyze Volatile Statistics Data needed to pass data at thread functions
	unsigned int		 	*harvestids;
	internal_long_double_t	*sum_pagerank;
	internal_long_double_t	*sum_wlrank;
	internal_long_double_t	*sum_hubrank;
	internal_long_double_t	*sum_authrank;
	internal_long_double_t	*sum_liverank;

	internal_long_uint_t	*sum_in_degree;
	internal_long_uint_t	*sum_depth;
	internal_long_uint_t	*sum_ok;
	///////////////////////////////////////////////////////////////////////////

	harvlist_t *listid;
	atomic<bool> alarm;

	pthread_t *threads;
	pthread_mutex_t *mutex_analyze_statistics;
	pthread_barrier_t *barrier;

	// Function required by hv_create (pthread use)
	void *thread_function_create( void * );

	// Function required by hv_open (pthread use)
	void *thread_function_open( void * );

	// Function required by hv_create (pthread use)
	void *thread_function_close( void * );

	// Function required by prepare (pthread use)
	void *thread_function_prepare( void * );

	// Function required by cancel_unseeded (pthread use)
	void *thread_function_cancel_unseeded( void * );

	// Function required by assigned_id (pthread use)
	void *thread_function_assigned_id( void * );

	// Function required by is_found (pthread use)
	void *thread_function_is_found( void * );

	// Function required by hv_remove (pthread use)
	void *thread_function_hv_remove( void * );

	// Function required by hv_remove_all (pthread use)
	void *thread_function_hv_remove_all( void * );

	// Function required by hv_remove_files (pthread use)
	void *thread_function_hv_remove_files( void * );

	// Function required by dump_status (pthread use)
	void *thread_function_dump_status( void * );

	// Function required by analyze (pthread use)
	void *thread_function_analyze_reading_harvest( void * );

	// Function required by analyze (pthread use)
	void *thread_function_analyze_analyzing_docs( void * );

	// Function required by analyze (pthread use)
	void *thread_function_analyze_write_data( void * );

	// Function required by extract (pthread use)
	void *thread_function_extract_dump_data( void * );

	// Set values in structure to default
	void set_default( instance_t & );

	// Remove  on instance
	void hv_remove_files( const char *, unsigned int & );

	// Remove harvest idx on single instance (single thread)
	void hv_remove( const char *, unsigned int & );

	// Read only docids (no paths, no site names) on gived instance
	void read_list_doc_only( instance_t & ) const;

	// Dump data header for analysis
	void dump_data_header( FILE * ) const;

	// Dump data header for analysis
	void dump_data_header_brief( FILE * ) const;

	// Dump data for analysis
	void dump_data( FILE * , harvest_volatile_status_t * ) const;

	// Dump data for analysis
	void dump_data_brief( FILE * , harvest_volatile_status_t * ) const;

	// Set info on current harvest id
	void set_info( instance_t & ) const;

	// Function to proxy to non-static function
	static void* thread_function_caller( void * );

	// Syncronize threads with barrier
	void sync_threads( pthread_barrier_t * ) const;

	public:

	Harvest (const char *_X, bool _Y) // ctor
		: distributed (CBALLOC(harvest_t, NEW, CONF_COLLECTION_DISTRIBUTED)) // Create harvest structure
		, dirname (_X)
		, readonly (_Y)
		, classname (CBALLOC(char, CALLOC, (strlen("Harvest") + 1)))
		, funcname (NULL) // only needed at cbiclose. Must be allocated inside main functions
		, global_id (0)
		, global_status (STATUS_HARVEST_EMPTY)
		, global_creationtime (0)
		, global_begintime (0)
		, sum_pagerank (0)
		, sum_wlrank (0)
		, sum_hubrank (0)
		, sum_authrank (0)
		, sum_liverank (0)
		, sum_in_degree (0)
		, sum_depth (0)
		, sum_ok (0)
		, listid (NULL)
		, alarm (false)
		, threads (NULL)
		, mutex_analyze_statistics (NULL)
		, barrier (NULL)
	{
		errno = 0; // errno is thread-local
		classname[0] = '\0';
		strcpy(classname, "Harvest");
	}

	~Harvest () // dtor
	{
		free(classname);

		if (distributed != NULL)
		{
			delete [] distributed;
			distributed = NULL;
		}
	}

	// need to passing arguments to threads functions
	// Because function call by pthread_create need to be pass first through 'urlddx_thread_function_caller', these works with other temporary object
	typedef struct {
		instance_t inst;
		Harvest *obj;
		harvest_call_t f; // corrisponde alla chiamata di determinate funzioni fatta da pthread_create
		harvest_volatile_status_t *dump;
		unsigned int id;
		bool strict;
		bool debugonly;
		Meta *meta;
		unsigned int nharvests;
	} thread_args_t;

	// Create a new harvest index
	void hv_create( void );

	// Open an existig harvest, reset read-only mode and return status
	harvest_status_t hv_open( unsigned int &, bool );

	// Close 
	void hv_close( void );

	// Setup harvest to running 
	void prepare( unsigned int, bool );

	// Delete harvest that don't have seeded
	void cancel_unseeded( void );

	// Get harvest with status 'HARVEST_ASSIGNED_ID' and check integrity
	unsigned int assigned_id( void );

	// Tell if HARVEST ID is found
	bool is_found( unsigned int );

	// Remove harvest ddx (multithread on all instances)
	void hv_remove( unsigned int & );

	// Remove harvest ddx (multithread on all instances)
	void hv_remove_all( void );

	// Remove files for retry on existing harvest (multithread on all instances)
	void hv_remove_files( unsigned int & );

	// Append site on harvest list
	void append_site( site_t *, char * );

	// Append doc on harvest list
	void append_doc( doc_t *, char * );

	// Return number of current harvest id
	unsigned int hv_id( void ) const;

	// Return start time of current harvest id
	time_t begin( void ) const;

	// Set end time on current harvest id
	void set_end( instance_t & ) const;

	// Set seeded status on current harvest id
	void seeded( instance_t &, pthread_barrier_t * );

	// Set done status on current harvest id
	void done( instance_t & ) const;

	// Return number of current harvest id
	void dump_status( bool );

	// Analyze
	void analyze( Meta * );

	// Extract data from harvesting without including summary statistics (eg: sum_pagerank)
	void extract( void );

	// Show le list of document and path of the harvest
	void dump_list( void );

	// Read the lists from relative instance and put it in memory
	void read_list( instance_t & );

	// Return site count for gived instance
	siteid_t hv_site_count( instance_t & ) const;

	// Give the sums of all instance of bytes_in and bytes_out
	void hv_bytes_sum( off64_t &, off64_t & ) const;

	// Increment raw_size for gived instance
	void hv_incr_raw_size( instance_t &, off64_t ) const;

	// Increment size for gived instance
	void hv_incr_size( instance_t &, off64_t ) const;

	// Increment bytes_in for gived instance
	void hv_incr_bytes_in( instance_t, off64_t ) const;

	// Increment bytes_out for gived instance
	void hv_incr_bytes_out( instance_t, off64_t ) const;

	// Increment doc count ok for gived instance
	void hv_incr_doc_count_ok( instance_t & ) const;

	// Increment by one link_total for gived instance
	void hv_incr_link_total( instance_t & ) const;

	// Increment by one link_old_pages for gived instance
	void hv_incr_link_old_pages( instance_t & ) const;

	// Increment by one link_new_pages for gived instance
	void hv_incr_link_new_pages( instance_t & ) const;

	// Increment by one link_new_sites for gived instance
	void hv_incr_link_new_sites( instance_t & ) const;

	// Return doc count for gived instance
	docid_t hv_doc_count( instance_t & ) const;

	// Return doc count ok for gived instance
	docid_t hv_doc_count_ok( instance_t & ) const;

	// Return site get from site_list for gived instance and serverid
	site_t *hv_site_list( instance_t &, siteid_t ) const;

	// Return hostname get from map_sitename for gived instance
	const char *hv_hostname_map( instance_t &, siteid_t ) const;

	// Return pointer to doc_list element for gived instance
	doc_t *hv_doc_list( instance_t &, docid_t ) const;

	// Return pointer to path get from map_path for gived instance
	const char *hv_path_map( instance_t &, docid_t ) const;
};

#endif
