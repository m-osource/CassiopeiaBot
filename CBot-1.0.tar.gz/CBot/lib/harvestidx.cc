/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "harvestidx.h"

//
// Name: thread_function_caller
//
// Description:
//   A proxy function to pass non-static function at pthread_create
//   Note: function called by thread_function_caller need to have real class object passed through args
//
// Input:
//   args - void arguments
//
// Return:
//   pointer to void
//
void* Harvest::thread_function_caller(void *args)
{
	assert(args);

	Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

try
{
	Harvest *newObj = NULL;

	try
	{
		newObj = new Harvest (NULL, true); // Note function called work to 'this' temporary object and need to be deleted at the end of the same.
	}
	catch (std::bad_alloc &ba)
	{
		die("Harvest thread_function_caller: bad_alloc caught %s", ba.what());
	}

	switch (arguments->f)
	{
		case HARVEST_CREATE:
			newObj->thread_function_create(args);
			break;
		case HARVEST_OPEN:
			newObj->thread_function_open(args);
			break;
		case HARVEST_CLOSE:
			newObj->thread_function_close(args);
			break;
		case HARVEST_PREPARE:
			newObj->thread_function_prepare(args);
			break;
		case HARVEST_ASSIGNED_ID:
			newObj->thread_function_assigned_id(args);
			break;
		case HARVEST_CANCEL_UNSEEDED:
			newObj->thread_function_cancel_unseeded(args);
			break;
		case HARVEST_IS_FOUND:
			newObj->thread_function_is_found(args);
			break;
		case HARVEST_REMOVE:
			newObj->thread_function_hv_remove(args);
			break;
		case HARVEST_REMOVE_ALL:
			newObj->thread_function_hv_remove_all(args);
			break;
		case HARVEST_REMOVE_FILES:
			newObj->thread_function_hv_remove_files(args);
			break;
		case HARVEST_DUMP_STATUS:
			newObj->thread_function_dump_status(args);
			break;
		case HARVEST_ANALYZE_READING_HARVEST:
			newObj->thread_function_analyze_reading_harvest(args);
			break;
		case HARVEST_ANALYZE_ANALYZING_DOCS:
			newObj->thread_function_analyze_analyzing_docs(args);
			break;
		case HARVEST_ANALYZE_WRITE_DATA:
			newObj->thread_function_analyze_write_data(args);
			break;
		case HARVEST_EXTRACT_DUMP_DATA:
			newObj->thread_function_extract_dump_data(args);
			break;
		default:
			break;
	}

	delete newObj;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(arguments->obj->barrier); 
}

	// Each thread must exit with 'pthread_barrier_wait'
	// in normal condition
	if (arguments->obj->barrier)
	{
		int rc = pthread_barrier_wait(arguments->obj->barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	free(args);
	args = NULL;

	return NULL;
}

// threads sync
void Harvest::sync_threads(pthread_barrier_t *barrier) const
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc = pthread_barrier_wait(barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
		pthread_exit(NULL);
}

// 
// Name: hv_id
//
// Description: number of current harvest id
//
// Input:
// 
// Return: id
//
unsigned int Harvest::hv_id(void) const
{
	assert(dirname != NULL);

	return global_id;
}

//
// Name: begin
//
// Description:
//   Return media of begintime of harvester
//
// Input:
//   inst 
//
// Return: the media of begintime
//
time_t Harvest::begin(void) const
{
	assert(dirname != NULL);

	return global_begintime;
}

//
// Name: set_status
//
// Description:
//   Set the status no the harvest
//
// Input:
//   inst - the instance number
//   status - the instance status
//
// Return: the count
//
void Harvest::seeded(instance_t &inst, pthread_barrier_t *barrier)
{
	assert(readonly == false);
	assert(barrier != NULL); // barrier must be borrow by seeder program

	// Note: 'obj' pointer to this object class must be created for preprocess 'diet'
	Harvest *obj = this;

	obj->distributed[inst].status = STATUS_HARVEST_SEEDED; // congruency of status on each instance can be verified at reopen

	sync_threads(barrier);

	// check if status are the same inside all instance
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (alarm == true) // if 'alarm' was set on true for other threads
			break;
		else if (obj->distributed[inst].status != obj->distributed[i].status)
		{	// Note: Only first thread that change value of atomic 'global_status' set 'alarm' on true
			if (obj->global_status.exchange(STATUS_HARVEST_ABORTED) == false)
				alarm = true;
		}

	sync_threads(barrier);

	// after seeded 'hv_dump' must return a congruent status
	if (alarm == false)
		obj->global_status.exchange(STATUS_HARVEST_SEEDED);
}

//
// Name: set_info
//
// Description:
//   Set the info for the harvest
//
// Input:
//   inst - the instance number
//
// Return: the count
//
void Harvest::set_info(instance_t &inst) const
{
	assert(readonly == false);

	if (distributed[inst].creationtime != global_creationtime) distributed[inst].creationtime = global_creationtime;
	if (distributed[inst].begintime != global_begintime) distributed[inst].begintime = global_begintime;
}

//
// Name: set_end
//
// Description:
//   Set end time on harvest for gived instance
//
// Input:
//   inst - the instance number
//
// Return: the count
//
void Harvest::set_end(instance_t &inst) const
{
	assert(dirname != NULL);

	distributed[inst].endtime = time(NULL);
}

//
// Name: set_end
//
// Description:
//   Set done status on harvest for gived instance
//
// Input:
//   inst - the instance number
//
// Return: the count
//
void Harvest::done(instance_t &inst) const
{
	assert(dirname != NULL);

	distributed[inst].status = STATUS_HARVEST_DONE;
}

// 
// Name: hv_create
//
// Description: call relative thread function
//
// Input:
// 
// Output:
//   file containing link structure between sites is created
//   metadata of sites is updated to reflect internal and external links
//
void Harvest::hv_create(void)
{
	assert(dirname != NULL);
	assert(readonly == false);

	if (thread_alarm != THREADS_OK)
		return;

	int rc = 0;
	pthread_mutexattr_t attr;

	cerr << "- Create harvester ... ";

	global_status = STATUS_HARVEST_ASSIGNED_NEW;
	global_creationtime = time(NULL);
	global_hostname[0] = '\0';

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = HARVEST_CREATE;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_create((void *) args); // only one distribution, function is call without thread 

	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}
}

//
// Name: thread_function_create
//
// Description:
//   Create a harvest
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_create(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;

	memset(&obj->distributed[inst], 0, sizeof(harvest_t));

	// disable the cancel of thread because deleting after barrier is more appropriate
	assert(pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL) == 0);

	// Work dir
	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
//	strcpy(obj->distributed[inst].dirname, relative_rem_path);

	int rc;
	char filename[MAX_STR_LEN];

	// Get next harvestid (start from one)
	obj->distributed[inst].id = (unsigned int)(inst + 1);

	struct stat64 buf;

	// Get new harvestid in multithread method
	while (true)
	{
		// Create filename and stat
		sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, obj->distributed[inst].id);
		rc = stat64(filename, &(buf));

		// Check result
		if (rc != 0 && errno != ENOENT)
			die("Harvest hv_create: error while trying to stat main file %s on %s", cberr(), filename);
		else if (rc == 0)
			obj->distributed[inst].id += CONF_COLLECTION_DISTRIBUTED; // Found, try with next
		else
			break; // Not found and create a new
	}

	sync_threads(obj->barrier);


	unsigned int min_harvestid = ~(unsigned int)0;

	// check a new harvestid to be created (the minor value in all instances)
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (obj->distributed[i].id < min_harvestid)
			min_harvestid = obj->distributed[i].id;

	sync_threads(obj->barrier);


	memset(&obj->distributed[inst], 0, sizeof(harvest_t));
	obj->distributed[inst].id = min_harvestid;

	// because SemaphorePrint have a small internal counter and this function can be called thousands of times
	// we prepare it in secure mode (between thread_barrier) before use after next sync_threads
	sp->reset(inst);

	sync_threads(obj->barrier);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (obj->distributed[inst].id != obj->distributed[i].id)
			die("Harvest hv_create: index corrupted!");

	if (sp->go_ahead(inst) == true)
	{
		cerr << obj->distributed[inst].id << " done." << endl;
		obj->global_id = obj->distributed[inst].id;
	}

	// Copy filename
	sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, obj->distributed[inst].id);

	// Stat file to ensure that it is not found for each instance
	rc = stat64(filename, &(buf));

	// Check result
	if (rc != 0 && errno != ENOENT)
		die("Harvest hv_create: error while trying to stat main file %s on %s", cberr(), filename);
	else if (rc == 0)
		die("Harvest hv_create: index corrupted because main file already exist!");

	// Try to open a new file
	FILE *file_main = fopen64(filename, "w");

//	if (errno != 0) // new file no errno check
//		die("Harvest hv_create: couldn't open main file %s on %s", cberr(), filename);

	if (file_main == NULL)
		die("Harvest hv_create: couldn't open main file %s", filename);

	// Create object and set parameters for the harvester
	obj->set_default(inst);

	// Dirname
	// strcpy(obj->distributed[inst].dirname, relative_rem_path); // may be not needed

	// Write object
	size_t written = fwrite(&obj->distributed[inst], sizeof(harvest_t), 1, file_main);
	assert(written == 1);
	fclose(file_main);

	// Open data files
	sprintf(filename, HARVESTIDX_FILENAME_DOC, relative_rem_path, obj->distributed[inst].id);
	obj->distributed[inst].file_doc = fopen64(filename, "w+");

//	if (errno != 0) // new file no errno check
//		die("Harvest hv_create: couldn't open doc file %s on %s", cberr(), filename);

	if (obj->distributed[inst].file_doc == NULL)
		die("Harvest hv_create: couldn't open doc file %s", filename);

	sprintf(filename, HARVESTIDX_FILENAME_SITE, relative_rem_path, obj->distributed[inst].id);
	obj->distributed[inst].file_site = fopen64(filename, "w+");

//	if (errno != 0) // new file no errno check
//		die("Harvest hv_create: couldn't open site file %s on %s", cberr(), filename);

	if (obj->distributed[inst].file_site == NULL)
		die("Harvest hv_create: couldn't open site file %s", filename);

	sprintf(filename, HARVESTIDX_FILENAME_PATH, relative_rem_path, obj->distributed[inst].id);
	obj->distributed[inst].file_path = fopen64(filename, "w+");

//	if (errno != 0) // new file no errno check
//		die("Harvest hv_create: couldn't open path file %s on %s", cberr(), filename);

	if (obj->distributed[inst].file_path == NULL)
		die("Harvest hv_create: couldn't open path file %s", cberr());

	sprintf(filename, HARVESTIDX_FILENAME_SITENAME, relative_rem_path, obj->distributed[inst].id);
	obj->distributed[inst].file_sitename = fopen64(filename, "w+");

//	if (errno != 0) // new file no errno check
//		die("Harvest hv_create: couldn't open sitename file %s on %s", cberr(), filename);

	if (obj->distributed[inst].file_sitename == NULL)
		die("Harvest hv_create: couldn't open sitename file %s", filename);

	free(relative_rem_path);

	return NULL;
}

// 
// Name: hv_close
//
// Description: call relative thread function
//
// Input:
// 
// Output:
//   file containing link structure between sites is created
//   metadata of sites is updated to reflect internal and external links
/*
void Harvest::hv_close(void)
{
	assert(dirname != NULL);

	if (thread_alarm != THREADS_OK)
		return;

	funcname = CBALLOC(char, MALLOC, (strlen((char *)__func__) + 1));
	funcname[0] = '\0';
	strcpy(funcname, (char *)__func__); 

	int rc = 0;
	pthread_mutexattr_t attr;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));

	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = HARVEST_CLOSE;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_close((void *) args); // only one distribution, function is call without thread 

	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	free(funcname);
}
*/
void Harvest::hv_close(void)
{
	assert(dirname != NULL);

	if (thread_alarm != THREADS_OK)
		return;

	funcname = CBALLOC(char, MALLOC, (strlen((char *)__func__) + 1));
	funcname[0] = '\0';
	strcpy(funcname, (char *)__func__); 

	int rc = 0;
	pthread_mutexattr_t attr;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));

	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = HARVEST_CLOSE;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_close((void *) args); // only one distribution, function is call without thread 

	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	free(funcname);
}

//
// Name: thread_function_close
//
// Description:
//   Create a harvest
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_close(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;

	cbiclose(obj->distributed[inst].file_doc, "doc");
	cbiclose(obj->distributed[inst].file_site, "site");
	cbiclose(obj->distributed[inst].file_path, "path");
	cbiclose(obj->distributed[inst].file_sitename, "sitename");

	errno = 0; // errno is thread-local

	// Check readonly mode
	if (obj->readonly == false)
	{
//		harvest_save_info(harvest);
		obj->set_info(inst);

		// Copy directory name
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
		assert(strlen(relative_rem_path) < MAX_STR_LEN);

		char filename[MAX_STR_LEN];

		struct stat64 statbuf;
		int rc;
			
		// Check filename existant and check file size, it should contain a single harvest_t structure
		sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, obj->distributed[inst].id);
		rc = stat64(filename, &(statbuf));

		// Check result
		if (rc != 0 && errno != ENOENT)
			die("Harvest hv_close: error while trying to stat main file %s on %s", cberr(), filename);
		else if (rc == 0)
		{
			// Try to open
			FILE *file_main = fopen64(filename, "w");

			if (errno != 0)
				die("Harvest hv_close: couldn't open main file %s on %s", cberr(), filename);

			if (file_main == NULL)
				die("Harvest hv_close: couldn't open main file %s", filename);

			char bt[50];
			char et[50];

			// Save
			size_t written = fwrite(&(obj->distributed[inst]), sizeof(harvest_t), 1, file_main);

			if (errno != 0)
				die("Harvest hv_close: couldn't write main file %s on %s", cberr(), filename);

			if (written != 1)
				die("Harvest hv_close: couldn't write main file (%d) on %s", written, filename);

			cbiclose(file_main, "main");
		}
		else
			die("Harvest hv_close: couldn't stat main file %s on %s", cberr(), filename);

		free(relative_rem_path);
	}

	// Free lists
	if (obj->distributed[inst].doc_list != NULL)
		free(obj->distributed[inst].doc_list);

	if (obj->distributed[inst].site_list != NULL)
		free(obj->distributed[inst].site_list);

	// free memory of maps
	if (obj->distributed[inst].map_path != NULL)
		delete obj->distributed[inst].map_path;

	if (obj->distributed[inst].map_site != NULL)
		delete obj->distributed[inst].map_site;

	if (obj->distributed[inst].map_sitename != NULL)
		delete obj->distributed[inst].map_sitename;

	return NULL;
}

// 
// Name: assigned_id
//
// Description: call relative thread function
//
// Input:
// 
// Output:
//   file containing link structure between sites is created
//   metadata of sites is updated to reflect internal and external links
//
unsigned int Harvest::assigned_id(void)
{
	assert(dirname != NULL);
	assert(readonly == true);

	if (thread_alarm != THREADS_OK)
		return 0;

	funcname = CBALLOC(char, MALLOC, (strlen((char *)__func__) + 1));
	funcname[0] = '\0';
	strcpy(funcname, (char *)__func__); 

	int rc = 0;
	pthread_mutexattr_t attr;

	// Linked lists
	listid = CBALLOC(harvlist_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = HARVEST_ASSIGNED_ID;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_assigned_id((void *) args); // only one distribution, function is call without thread 

	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	free(listid);

	free(funcname);

	return global_id;
}

//
// Name: thread_function_assigned_id
//
// Description:
//   Get harvest with status 'HARVEST_ASSIGNED_ID' and check integrity
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_assigned_id(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;

	// disable the cancel of thread because deleting after barrier is more appropriate
	assert(pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL) == 0);

	// Work dir
	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);

	char filename[MAX_STR_LEN];

	// Get next harvestid (start from one)
	obj->distributed[inst].id = (unsigned int)(inst + 1);

	struct stat64 statbuf;
	int rc;

	errno = 0; // errno is thread-local

	harvlist_t *ptr = &obj->listid[inst];
	assert(ptr->harvestid == 0);

	ccerr << "Checking harvester indexes ... ";

	// Get new harvestid in multithread method
	while (true)
	{
		// Check filename existant
		sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, obj->distributed[inst].id);
		rc = stat64(filename, &(statbuf));

		// Check result
		if (rc != 0 && errno != ENOENT)
			die("Harvest assigned_id: error while trying to stat main file %s on %s", cberr(), filename);
		else if (rc == 0)
		{
			// Check size of harvest_t
			if (statbuf.st_size != sizeof(harvest_t))
				die("Harvest assigned_id: inconsistency in harvest_t. File size target %d, actual %d", sizeof(harvest_t), statbuf.st_size);

			// Try to open
			FILE *file_main = fopen64(filename, "r");

			if (errno != 0)
				die("Harvest assigned_id: couldn't open main file %s on %s", cberr(), filename);

			if (file_main == NULL)
				die("Harvest assigned_id: couldn't open main file %s", filename);

			assert(file_main != NULL);

			harvest_t main_tmp;
			harvest_status_t status_tmp;
			unsigned int harvestid = 0;

			// Read
			size_t readed = fread(&main_tmp, sizeof(harvest_t), 1, file_main);

			if (errno != 0)
				die("Harvest assigned_id: couldn't read temporary main file %s on %s", cberr(), filename);

			if (readed != 1)
				die("Harvest assigned_id: couldn't read temporary main file %s", filename);

			// Warning: status or id must be the same for each harvest!
			assert(main_tmp.id == obj->distributed[inst].id);
			harvestid = main_tmp.id;
			status_tmp = main_tmp.status;

			cbiclose(file_main, "main");

			if (status_tmp == STATUS_HARVEST_ASSIGNED_NEW || status_tmp == STATUS_HARVEST_ASSIGNED)
				break;
			else // Append harvestid to list
			{
				harvlist_t *node = CBALLOC(harvlist_t, MALLOC, 1);
				node->harvestid = harvestid;
				node->status = status_tmp;
				node->next = NULL;
				ptr->next = node;
				ptr = ptr->next;
			}

			obj->distributed[inst].id += CONF_COLLECTION_DISTRIBUTED; // Found, try with next
		}
		else
			break; // Not found
	}

	sync_threads(obj->barrier);


	ccerr << "done" << endl;

	unsigned int min_harvestid = ~(unsigned int)0;

	// check a empty harvestid (the minor value in all instances)
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (obj->distributed[i].id < min_harvestid)
			min_harvestid = obj->distributed[i].id;

	sync_threads(obj->barrier);


	obj->distributed[inst].id = min_harvestid;

	if ((obj->distributed[inst].id % CONF_COLLECTION_DISTRIBUTED) == inst)
		obj->global_id = min_harvestid;

	sync_threads(obj->barrier);


	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (obj->distributed[inst].id != obj->distributed[i].id)
			die("Harvest assigned_id: index corrupted!");

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		harvlist_t *ptr = obj->listid[i].next;

		while (ptr != NULL)
		{
			if (ptr->harvestid < obj->distributed[inst].id)
				if ((ptr->harvestid % CONF_COLLECTION_DISTRIBUTED) == inst)
					mcerr << "Harvester #" << ptr->harvestid << " skipped with status=" << HARVEST_STATUS_STR(ptr->status) << mendl;

			ptr = ptr->next;
		}
	}

	sync_threads(obj->barrier);


	// Check filename existant and check file size, it should contain a single harvest_t structure
	sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, obj->distributed[inst].id);
	rc = stat64(filename, &(statbuf));

	// Check result
	if (rc != 0 && errno != ENOENT)
		die("Harvest assigned_id: error while trying to stat main file %s on %s", cberr(), filename);
	else if (rc == 0)
	{
		if (statbuf.st_size != sizeof(harvest_t)) // Before proceeding compare to size of harvest_t
		{
			if(statbuf.st_size != sizeof(harvest_old_t)) // It doesn't match, check if it's the old format
			{
				cerr << "Wrong harvest_t (expected " << sizeof(harvest_t) << ", got " << statbuf.st_size << ")" << endl;
				cerr << "Please remove " << filename << " as it might be damaged; you must cancel the remaining harvest rounds" << endl;
				die("Harvest assigned_id: inconsistency in harvest_t");
			}
			else
			{
				if ((obj->distributed[inst].id % CONF_COLLECTION_DISTRIBUTED) == inst)
					mcerr << "[Converting old harvest_t file to new format ignoring readonly mode]" << mendl;

				harvest_old_t harvest_old;
				FILE *file_main_tmp	= fopen64(filename, "r");

				if (errno != 0)
					die("Harvest assigned_id: couldn't open main file %s on %s", cberr(), filename);

				if (file_main_tmp == NULL)
					die("Harvest assigned_id: couldn't open main file %s", filename);

				size_t readed = fread(&(harvest_old), sizeof(harvest_old_t), 1, file_main_tmp);

				if (errno != 0)
					die("Harvest assigned_id: couldn't read old main file %s on %s", cberr(), filename);

				if (readed != 1)
					die("Harvest assigned_id: couldn't read old main file %s", filename);

				if (obj->distributed[inst].id != harvest_old.id)
					die("Harvest assigned_id: index corrupted!");

				cbiclose(file_main_tmp, "main_tmp");

				// Copy old data
				obj->set_default(inst);

				// copy basic values for a valid harvest
	//			strcpy(obj->distributed[inst].dirname, harvest_old.dirname);
				obj->distributed[inst].id				= harvest_old.id;
				obj->distributed[inst].count			= harvest_old.count;
				obj->distributed[inst].count_ok 		= harvest_old.count_ok;
				obj->distributed[inst].count_site		= harvest_old.count_site;
				obj->distributed[inst].raw_size			= harvest_old.raw_size;
				obj->distributed[inst].size				= harvest_old.size;
				obj->distributed[inst].link_total		= harvest_old.link_total;
				obj->distributed[inst].link_old_pages	= harvest_old.link_old_pages;
				obj->distributed[inst].link_new_pages	= harvest_old.link_new_pages;
				obj->distributed[inst].link_new_sites	= harvest_old.link_new_sites;
				strcpy(obj->distributed[inst].hostname, harvest_old.hostname);
				obj->distributed[inst].creationtime		= harvest_old.creationtime;
				obj->distributed[inst].begintime		= harvest_old.begintime;
				obj->distributed[inst].endtime			= harvest_old.endtime;
				obj->distributed[inst].status			= harvest_old.status;

				file_main_tmp	= fopen64(filename, "w");

				if (errno != 0)
					die("Harvest assigned_id: couldn't open main file %s on %s", cberr(), filename);

				if (file_main_tmp == NULL)
					die("Harvest assigned_id: couldn't open main file %s", filename);

				size_t written = fwrite(&(obj->distributed[inst]), sizeof(harvest_t), 1, file_main_tmp);

				if (errno != 0)
					die("Harvest assigned_id: couldn't write main file %s on %s", cberr(), filename);

				if (written != 1)
					die("Harvest assigned_id: couldn't write main file (%d) on %s", written, filename);

				cbiclose(file_main_tmp, "main_tmp");
			}
		}
		else
		{
			// Try to open
			FILE *file_main = fopen64(filename, "r");

		//	if (errno != 0) // if new file no errno check
		//		die("Harvest assigned_id: couldn't open main file %s on %s", cberr(), filename);

			if (file_main == NULL)
				die("Harvest assigned_id: couldn't open main file %s", filename);

			// Read
			size_t readed = fread(&(obj->distributed[inst]), sizeof(harvest_t), 1, file_main);

		//	if (errno != 0) // if new file no errno check
		//		die("Harvest assigned_id: couldn't read main file %s on %s", cberr(), filename);

			if (readed != 1)
				die("Harvest assigned_id: couldn't read main file %s", filename);

			cbiclose(file_main, "main");
		}
	}
	else
		die("Couldn't stat harvest main file %s on %s", cberr(), filename);

	ccerr << "Harvester #" << obj->distributed[inst].id << " ok, created on " << ctime(&(obj->distributed[inst].creationtime));

	// free linked list in parallel mode
	ptr = obj->listid[inst].next;

	while (ptr != NULL)
	{
		harvlist_t *old_ptr = ptr;
		ptr = ptr->next;
		free(old_ptr);
	}

	free(relative_rem_path);

	return NULL;
}

// 
// Name: cancel_unseeded
//
// Description: call relative thread function
//
// Input:
// 
// Output:
//   file containing link structure between sites is created
//   metadata of sites is updated to reflect internal and external links
//
void Harvest::cancel_unseeded(void)
{
	assert(dirname != NULL);
	assert(readonly == false);

	if (thread_alarm != THREADS_OK)
		return;

	funcname = CBALLOC(char, MALLOC, (strlen((char *)__func__) + 1));
	funcname[0] = '\0';
	strcpy(funcname, (char *)__func__); 

	int rc = 0;
	pthread_mutexattr_t attr;

	// Linked lists
	listid = CBALLOC(harvlist_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = HARVEST_CANCEL_UNSEEDED;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_cancel_unseeded((void *) args); // only one distribution, function is call without thread 

	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	free(listid);

	free(funcname);
}

//
// Name: thread_function_cancel_unseeded
//
// Description:
//   Delete harvest that don't have seeded status
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_cancel_unseeded(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;

	// disable the cancel of thread because deleting after barrier is more appropriate
	assert(pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL) == 0);

	// Work dir
	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
//	strcpy(obj->distributed[inst].dirname, relative_rem_path);

	char filename[MAX_STR_LEN];

	// Get next harvestid (start from one)
	obj->distributed[inst].id = (unsigned int)(inst + 1);

	struct stat64 statbuf;
	int rc;

	harvlist_t *ptr = &obj->listid[inst];
	assert(ptr->harvestid == 0);

	ccerr << "Checking harvester indexes ... ";

	// Get new harvestid in multithread method
	while (true)
	{
		// Check filename existant
		sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, obj->distributed[inst].id);
		rc = stat64(filename, &(statbuf));

		// Check result
		if (rc != 0 && errno != ENOENT)
			die("Harvest cancel_unseeded: error while trying to stat main file %s on %s", cberr(), filename);
		else if (rc == 0)
		{
			// Check size of harvest_t
			if (statbuf.st_size != sizeof(harvest_t))
				die("Harvest cancel_unseeded: inconsistency in harvest_t. File size target %d, actual %d", sizeof(harvest_t), statbuf.st_size);

			// Try to open
			FILE *file_main = fopen64(filename, "r");
			assert(file_main != NULL);

			harvest_t main_tmp;
			harvest_status_t status_tmp;
			unsigned int harvestid = 0;

			// Read
			size_t readed = fread(&main_tmp, sizeof(harvest_t), 1, file_main);

			if (errno != 0)
				die("Harvest cancel_unseeded: couldn't read old main file %s on %s", cberr(), filename);

			if (readed != 1)
				die("Harvest cancel_unseeded: couldn't read old main file %s", filename);

			// Warning: status or id must be the same for each harvest!
			assert(main_tmp.id == obj->distributed[inst].id);
			harvestid = main_tmp.id;
			status_tmp = main_tmp.status;
			cbiclose(file_main, "main");

			// Append harvestid to list 
			if (status_tmp != STATUS_HARVEST_SEEDED)
			{
				harvlist_t *node = CBALLOC(harvlist_t, MALLOC, 1);
				node->harvestid = harvestid;
				node->status = STATUS_HARVEST_EMPTY; // not used inside this function
				node->next = NULL;
				ptr->next = node;
				ptr = ptr->next;
			}

			obj->distributed[inst].id += CONF_COLLECTION_DISTRIBUTED; // Found, try with next
		}
		else
			break; // Not found
	}

	sync_threads(obj->barrier);



	ccerr << "done" << endl;

	unsigned int min_harvestid = ~(unsigned int)0;

	// check a empty harvestid (the minor value in all instances)
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (obj->distributed[i].id < min_harvestid)
			min_harvestid = obj->distributed[i].id;

	sync_threads(obj->barrier);



	obj->distributed[inst].id = min_harvestid;

	sync_threads(obj->barrier);



	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (obj->distributed[inst].id != obj->distributed[i].id)
			die("Harvest cancel_unseeded: index corrupted!");

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		harvlist_t *ptr = obj->listid[i].next;

		while (ptr != NULL)
		{
			if (ptr->harvestid < obj->distributed[inst].id)
			{
				obj->hv_remove(relative_rem_path, ptr->harvestid);

				if ((ptr->harvestid % CONF_COLLECTION_DISTRIBUTED) == inst)
					mcerr << "Harvester #" << ptr->harvestid << " canceled, remove" << mendl;
			}

			ptr = ptr->next;
		}
	}

	sync_threads(obj->barrier);

	// free linked list in parallel mode
	ptr = obj->listid[inst].next;

	while (ptr != NULL)
	{
		harvlist_t *old_ptr = ptr;
		ptr = ptr->next;
		free(old_ptr);
	}

	free(relative_rem_path);

	return NULL;
}

// 
// Name: is_found
//
// Description: call relative thread function
//
// Input:
// 
// Output: boolean
//
bool Harvest::is_found(unsigned int harvestid)
{
	assert(dirname != NULL);

	if (thread_alarm != THREADS_OK)
		return false;

	funcname = CBALLOC(char, MALLOC, (strlen((char *)__func__) + 1));
	funcname[0] = '\0';
	strcpy(funcname, (char *)__func__); 

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = HARVEST_IS_FOUND;
		args->id = harvestid;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_is_found((void *) args); // only one distribution, function is call without thread 

	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}

	free(funcname);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (distributed[i].status == STATUS_HARVEST_EMPTY)
			return false;

	return true;
}

//
// Name: thread_function_is_found
//
// Description:
//   Delete harvest that don't have seeded
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_is_found(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;
    unsigned int harvestid = arguments->id;

	// Work dir
	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);

	char filename[MAX_STR_LEN];

	struct stat64 statbuf;

	errno = 0; // errno is thread-local

	// Check filename existant
	sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, harvestid);
	int rc = stat64(filename, &(statbuf));

	// Check result
	if (rc != 0 && errno != ENOENT)
		die("Harvest is_found: error while trying to stat main file %s on %s", cberr(), filename);
	else if (rc == 0)
	{
		// Check size of harvest_t
		if (statbuf.st_size != sizeof(harvest_t))
			die("Harvest is_found: inconsistency in harvest_t. File size target %d, actual %d", sizeof(harvest_t), statbuf.st_size);

			// Try to open
			FILE *file_main = fopen64(filename, "r");

			if (errno != 0)
				die("Harvest is_found: couldn't open main file %s on %s", cberr(), filename);

			if (file_main == NULL)
				die("Harvest is_found: couldn't open main file %s", filename);

			harvest_t main_tmp;

			// Read main file
			size_t readed = fread(&main_tmp, sizeof(harvest_t), 1, file_main);

			if (errno != 0)
				die("Harvest is_found: couldn't read temporary main file %s on %s", cberr(), filename);

			assert(readed == 1);

			// Warning: status or id must be the same for each harvest!
			assert(main_tmp.id == harvestid);
			obj->distributed[inst].status = main_tmp.status;

			cbiclose(file_main, "main");
	}
	else
		obj->distributed[inst].status = STATUS_HARVEST_EMPTY;
		//obj->harvest_not_found++;

	free(relative_rem_path);

	return NULL;
}

//
// Name: hv_remove
//
// Description:
//   Removes files in a harvest
//
// Input:
//   dirname - the directory
//   harvestid - the harvestid
//   
void Harvest::hv_remove(const char *rwd, unsigned int &harvestid)
{
	assert(harvestid > 0);

	queue<string> files;

	// Push files
	files.push(HARVESTIDX_FILENAME_MAIN);
	files.push(HARVESTIDX_FILENAME_DOC);
	files.push(HARVESTIDX_FILENAME_SITE);
	files.push(HARVESTIDX_FILENAME_PATH);
	files.push(HARVESTIDX_FILENAME_SITENAME);

	// Delete main files
	while(! files.empty()) {

		// Create filename
		char filename[MAX_STR_LEN];
		sprintf(filename, files.front().c_str(), rwd, harvestid);

		errno = 0; // errno is thread-local

		// Delete file
		int rc = unlink(filename);

		if(errno != 0 && errno != ENOENT)
			die("Couldn't unlink file %s on %s", cberr(), files.front().c_str());

		assert(rc == 0);

		// Remove file from queue
		files.pop();

	}

	// Remove gatherer files
	char collection_harvest_links[MAX_STR_LEN];
    sprintf(collection_harvest_links, "%s/%s", rwd, COLLECTION_LINK);

	hv_remove_files(collection_harvest_links, harvestid);
}

// 
// Name: hv_remove
//
// Description: call relative thread function
//
// Input: the number of id harvest to remove
// 
// Output:
//
void Harvest::hv_remove(unsigned int &id)
{
	assert(dirname != NULL);
	assert(readonly == false);

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->id = id;
		args->f = HARVEST_REMOVE;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_hv_remove((void *) args); // only one distribution, function is call without thread 

	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}
}

//
// Name: thread_function_hv_remove
//
// Description:
//   Delete harvest 
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_hv_remove(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;
	unsigned int id = arguments->id;

	// Work dir
	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
//	strcpy(obj->distributed[inst].dirname, relative_rem_path);

	int rc;
	char filename[MAX_STR_LEN];

	struct stat64 statbuf;

	// Check filename existant
	sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, id);
	rc = stat64(filename, &(statbuf));

	// Check result
	if (rc != 0 && errno != ENOENT)
		die("Harvest hv_remove: error while trying to stat main file %s on %s", cberr(), filename);
	else if (rc == 0)
	{
		// Check size of harvest_t
		if (statbuf.st_size != sizeof(harvest_t))
			die("Harvest hv_remove: inconsistency in harvest_t. Main file size: target %d, actual %d", sizeof(harvest_t), statbuf.st_size);

	//	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	//		if (obj->distributed[inst].id != id)
	//			die("Harvest hv_remove: index corrupted with id (%d) different from %u!", obj->distributed[inst].id, id);
	//			Non applicabile in quanto nel caso non sia stato creato realmente l'harvest, gli id non sono neppure inizializzati...
	//			nonostante presenti i main files

		obj->hv_remove(relative_rem_path, id);
	}

	free(relative_rem_path);

	return NULL;
}

// 
// Name: hv_remove_files
//
// Description: call relative thread function
//
// Input: the number of id harvest to remove
// 
// Output:
//
void Harvest::hv_remove_files(unsigned int &id)
{
	assert(dirname != NULL);

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->id = id;
		args->f = HARVEST_REMOVE_FILES;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_hv_remove_files((void *) args); // only one distribution, function is call without thread 

	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}
}

//
// Name: thread_function_hv_remove_files
//
// Description:
//    Delete files needed for gathering on instance
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_hv_remove_files(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;
	unsigned int id = arguments->id;

	// Work dir
	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
//	strcpy(obj->distributed[inst].dirname, relative_rem_path);

	int rc;
	char filename[MAX_STR_LEN];

	struct stat64 statbuf;

	// Check filename existant
	sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, id);
	rc = stat64(filename, &(statbuf));

	// Check result
	if (rc != 0 && errno != ENOENT)
		die("Harvest hv_remove_files: error while trying to stat main file %s on %s", cberr(), filename);
	else if (rc == 0)
	{
		// Check size of harvest_t
		if (statbuf.st_size != sizeof(harvest_t))
			die("Harvest hv_remove_files; inconsistency in harvest_t. File size: target %d, actual %d", sizeof(harvest_t), statbuf.st_size);

//		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
//			if (obj->distributed[inst].id != id)
//				die("index corrupted %d!", statbuf.st_size);

		// Remove gatherer files
		char collection_harvest_links[MAX_STR_LEN];
	    sprintf(collection_harvest_links, "%s/%s", relative_rem_path, COLLECTION_LINK);

		obj->hv_remove_files(collection_harvest_links, id);

		// because status already exist, it is not 'assigned new'
		obj->distributed[inst].status = STATUS_HARVEST_ASSIGNED;
	}

	free(relative_rem_path);

	return NULL;
}

// 
// Name: hv_remove_all
//
// Description: call relative thread function
//
// Input: the number of id harvest to remove
// 
// Output:
//
void Harvest::hv_remove_all(void)
{
	assert(dirname != NULL);
	assert(readonly == false);

	instance_t max_instances = 0;

	struct stat64 statbuf;

	// check how many directory contain data to delete
	for (instance_t inst = 0; inst < ((instance_t)(~0)); inst++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);

		if (stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
			max_instances++;
		else
		{
			free(relative_rem_path);
			break;
		}

		free(relative_rem_path);
	}

	if (max_instances > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, max_instances);

		for (instance_t inst = 0; inst < max_instances; inst++)
		{
			Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
		    args->inst = inst;
			args->obj = this;
			args->f = HARVEST_REMOVE_ALL;

			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
					die("error creating thread!");
			}
			else
				thread_function_hv_remove_all((void *) args); // only one distribution, function is call without thread 
		}

		CBotjoin(threads, max_instances);

		free(threads);
	}
}

//
// Name: thread_function_hv_remove_all
//
// Description: Delete all harvest on each instance 
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_hv_remove_all(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;

	// Work dir
	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < (MAX_STR_LEN - 7));

	//remove all files
	char command[MAX_STR_LEN] = "rm -rf ";
	strcat(command, relative_rem_path);
	strcat(command, "/");
	system (command); // 'system' should not create problem with multithread because it work on different path according to instance

	free(relative_rem_path);

	return NULL;
}

//
// Name: hv_remove_files
//
// Description:
//   Removes files inside directory link of idx harvest
//
// Input:
//   dirname - the directory
//   harvestid - the harvestid
//   
void Harvest::hv_remove_files(const char *rwd, unsigned int &harvestid)
{
	assert(harvestid > 0);

	errno = 0; // errno is thread-local

	// Delete fetcher files
	char dir_fetcher[MAX_STR_LEN];
	sprintf(dir_fetcher, "%s/%d", rwd, harvestid);

	// Open directory
	DIR *dir = opendir(dir_fetcher);

	if(dir != NULL)
	{
		struct dirent *file;
		struct stat64 statbuf;

		// Read the directory
		while((file = readdir(dir)))
		{
			char filename[MAX_STR_LEN];
			sprintf(filename, "%s/%s", dir_fetcher, file->d_name);
			int rc = stat64(filename, &(statbuf));

			// Check for normal files
			if (rc == 0)
			{
				if(S_ISREG(statbuf.st_mode))
				{
					int rcunlink = unlink(filename);

					if (rcunlink != 0 && errno != ENOENT)
						die("Couldn't unlink file %s on %s", cberr(), filename);

					assert(rcunlink == 0);
				}
			}

		}
		closedir(dir);

		// Remove the directory
		int rc = rmdir(dir_fetcher);

		if(rc < 0)
			die("Couldn't remove (dir_fetcher) %s on %s", cberr(), dir_fetcher);
	}
}

// 
// Name: hv_open
//
// Description: call relative thread function
//
// Input: the number of id harvest to open
// 
// Output:
//
// Return: the status of the harvest
//
harvest_status_t Harvest::hv_open(unsigned int &id, bool _readonly)
{
	assert(dirname != NULL);

	if (thread_alarm != THREADS_OK)
		return STATUS_HARVEST_ABORTED;

	readonly = _readonly;

	int rc = 0;
	pthread_mutexattr_t attr;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->id = id;
		args->f = HARVEST_OPEN;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_open((void *) args); // only one distribution, function is call without thread 

	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	global_id = id;

	return global_status;
}

//
// Name: thread_function_open
//
// Description:
//    Delete files needed for gathering on instance
//    Function 'cbiclose' is not raccomanded in this case because debug must be very accurated
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_open(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;
	unsigned int id = arguments->id;
	obj->distributed[inst].id = arguments->id;

	errno = 0; // errno is thread-local

	// disable the cancel of thread because deleting after barrier is more appropriate
	assert(pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL) == 0);

	// Work dir
	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);

	int rc;
	char filename[MAX_STR_LEN];

	struct stat64 statbuf;

	// Check filename existant and check file size, it should contain a single harvest_t structure
	sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, obj->distributed[inst].id);

	rc = stat64(filename, &(statbuf));

	// Check result
	if (rc != 0 && errno != ENOENT)
		die("Harvest hv_open: error while trying to stat file %s on %s", cberr(), filename);
	else if (rc == 0)
	{
		if (statbuf.st_size != sizeof(harvest_t)) // Before proceeding compare to size of harvest_t
		{
			if(statbuf.st_size != sizeof(harvest_old_t)) // It doesn't match, check if it's the old format
			{
				cerr << "Wrong harvest_t (expected " << sizeof(harvest_t) << ", got " << statbuf.st_size << ")" << endl;
				cerr << "Please remove " << filename << " as it might be damaged; you must cancel the remaining harvest rounds" << endl;
				die("Harvest hv_open: inconsistency in harvest_t");
			}
			else
			{
				if ((obj->distributed[inst].id % CONF_COLLECTION_DISTRIBUTED) == inst)
					mcerr << "[Converting old harvest_t file to new format ignoring readonly mode]" << mendl;

				harvest_old_t harvest_old;
				FILE *file_main_tmp	= fopen64(filename, "r");

				if (errno != 0)
					die("Harvest hv_open: after recovery couldn't open old main file %s on %s", cberr(), filename);

				if (file_main_tmp == NULL)
					die("Harvest hv_open: after recovery couldn't open old main file %s", filename);

				size_t readed = fread(&(harvest_old), sizeof(harvest_old_t), 1, file_main_tmp);

				if (errno != 0)
					die("Harvest hv_open: after recovery couldn't read old main file %s on %s", cberr(), filename);

				if (readed != 1)
					die("Harvest hv_open: after recovery couldn't read old main file (%d) on %s", readed, filename);

				if (obj->distributed[inst].id != harvest_old.id)
					die("Harvest hv_open: after recovery the index seem be corrupted %s on %s", cberr(), filename);

				int rc = fclose(file_main_tmp);

				if (errno != 0)
					die("Harvest hv_open: after recovery couldn't close old main file %s on %s", cberr(), filename);

				if (rc != 0)
					die("Harvest hv_open: after recovery couldn't close old main file (%d) on %s", rc, filename);

				// Copy old data
				obj->set_default(inst);

				// copy basic values for a valid harvest
	//			strcpy(obj->distributed[inst].dirname, harvest_old.dirname);
				obj->distributed[inst].id				= harvest_old.id;
				obj->distributed[inst].count			= harvest_old.count;
				obj->distributed[inst].count_ok 		= harvest_old.count_ok;
				obj->distributed[inst].count_site		= harvest_old.count_site;
				obj->distributed[inst].raw_size			= harvest_old.raw_size;
				obj->distributed[inst].size				= harvest_old.size;
				obj->distributed[inst].link_total		= harvest_old.link_total;
				obj->distributed[inst].link_old_pages	= harvest_old.link_old_pages;
				obj->distributed[inst].link_new_pages	= harvest_old.link_new_pages;
				obj->distributed[inst].link_new_sites	= harvest_old.link_new_sites;

				size_t hlen = strlen(harvest_old.hostname);
				assert(hlen < MAX_STR_LEN);
				obj->distributed[inst].hostname[0] = '\0';
				strncpy(obj->distributed[inst].hostname, harvest_old.hostname, hlen);
				obj->distributed[inst].hostname[hlen] = '\0';
				

				obj->distributed[inst].creationtime		= harvest_old.creationtime;
				obj->distributed[inst].begintime		= harvest_old.begintime;
				obj->distributed[inst].endtime			= harvest_old.endtime;
				obj->distributed[inst].status			= harvest_old.status;

				file_main_tmp	= fopen64(filename, "w");

				if (errno != 0)
					die("Harvest hv_open: after recovery couldn't open old main file %s on %s", cberr(), filename);

				if (file_main_tmp == NULL)
					die("Harvest hv_open: after recovery couldn't open old main file %s", filename);

				size_t written = fwrite(&(obj->distributed[inst]), sizeof(harvest_t), 1, file_main_tmp);

				if (errno != 0)
					die("Harvest hv_open: after recovery couldn't write old main file %s on %s", cberr(), filename);

				if (written != 1)
					die("Harvest hv_open: after recovery couldn't write old main file (%d) on %s", written, filename);

				rc = fclose(file_main_tmp);

				if (errno != 0)
					die("Harvest hv_open: after recovery couldn't close old main file %s on %s", cberr(), filename);

				if (rc != 0)
					die("Harvest hv_open: after recovery couldn't close old main file (%d) on %s", rc, filename);
			}

			// Try to open even after recovery
			FILE *file_main = fopen64(filename, "r");

			if (errno != 0)
				die("Harvest hv_open: after recovery couldn't open main file %s on %s", cberr(), filename);

			if (file_main == NULL)
				die("Harvest hv_open: after recovery couldn't open main file %s", filename);

			// Read
			size_t readed = fread(&(obj->distributed[inst]), sizeof(harvest_t), 1, file_main);

			if (errno != 0)
				die("Harvest hv_open: after recovery couldn't read main file %s on %s", cberr(), filename);

			if (readed != 1)
				die("Harvest hv_open: after recovery couldn't read main file (%d) on %s", readed, filename);

			if (obj->distributed[inst].id != id)
				die("Harvest hv_open: after recovery the index seem be corrupted %s on %s", cberr(), filename);

			rc = fclose(file_main);

			if (errno != 0)
				die("Harvest hv_open: after recovery couldn't close main file %s on %s", cberr(), filename);

			if (rc != 0)
				die("Harvest hv_open: after recovery couldn't close main file (%d) on %s", rc, filename);
		}
	}
	else
		die("Harvest hv_open: couldn't stat harvest main file %s on %s", cberr(), filename);

	sync_threads(obj->barrier);

	// because SemaphorePrint have a small internal counter and this function can be called thousands of times
	// we prepare it in secure mode (between thread_barrier) before use after next sync_threads
	sp->reset(inst);

	// Try to open
	FILE *file_main = fopen64(filename, "r");

	if (errno != 0)
		die("Harvest hv_open: couldn't open main file %s on %s", cberr(), filename);

	if (file_main == NULL)
		die("Harvest hv_open: after recovery couldn't open temporary main file %s", filename);

	// Read
	size_t readed = fread(&(obj->distributed[inst]), sizeof(harvest_t), 1, file_main);

	if (errno != 0)
		die("Harvest hv_open: couldn't read main file %s on %s", cberr(), filename);

	if (readed != 1)
		die("Harvest hv_open: couldn't read main file (%d) on %s", readed, filename);

	rc = fclose(file_main);

	if (errno != 0)
		die("Harvest hv_open: couldn't close main file %s on %s", cberr(), filename);

	if (rc != 0)
		die("Harvest hv_open: couldn't close main file (%d) on %s", rc, filename);

	// assert(obj->distributed[inst].count > 0); if harvest have no document on instance is  skipped

	sync_threads(obj->barrier);

	// check if status are the same inside all instance
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (alarm == true) // if 'alarm' was set on true for other threads
			break;
		else if (obj->distributed[inst].status != obj->distributed[i].status)
		{	// Note: Only first thread that change value of atomic 'global_status' set 'alarm' on true
			if (obj->global_status.exchange(STATUS_HARVEST_ABORTED) == false)
				alarm = true;
		}

	sync_threads(obj->barrier);

	if (alarm == false)
	{
/*		if (obj->distributed[inst].status == STATUS_HARVEST_DONE)
		{
			int rc = fclose(file_main);

			if (errno != 0)
				die("Harvest hv_open: after harvest's status inconsistency couldn't close main file %s on %s", cberr(), filename);

			assert(rc == 0);

			free(relative_rem_path);

					return NULL;
		}
		else
		{ */
			obj->global_status.exchange(obj->distributed[inst].status);

			if (sp->go_ahead(inst) == true)
			{
				obj->global_hostname[0] = '\0';
				unsigned short hlen = strlen(obj->distributed[inst].hostname);
				strncpy(obj->global_hostname, obj->distributed[inst].hostname, hlen);
				obj->global_hostname[hlen] = '\0';
				obj->global_creationtime = obj->distributed[inst].creationtime;
				obj->global_begintime = obj->distributed[inst].begintime;
			}

	//		cbiclose(file_main, "main");
	//	}
	}
	else
	{
		int rc = fclose(file_main);

		ccerr << "Harvest hv_open: harvest's status inconsistency!" << endl;

		if (errno != 0)
			die("harvest's status inconsistency!\nHarvest hv_open: couldn't close main file %s on %s", cberr(), filename);

		if (rc != 0)
			die("harvest's status inconsistency!\nHarvest hv_open: couldn't close main file (%d) on %s", rc, filename);


		free(relative_rem_path);

			return NULL;
	}
	
	Meta *meta = new Meta (NULL, true);

	sprintf(filename, HARVESTIDX_FILENAME_DOC, relative_rem_path, obj->distributed[inst].id);

	// Check size of file with docs
	if (stat64(filename, &statbuf) == 0)
	{
		// Verify file size
		if ((unsigned int)(statbuf.st_size) != (sizeof(doc_t) * obj->distributed[inst].count))
		{
			if((uint)(statbuf.st_size) != (sizeof(doc_old_t) * obj->distributed[inst].count))
				die("Harvest hv_open: inconsistency in the size of doc_t (probably needs to re-compile)");
			else
			{
				mcerr << "Converting doc file on instance " << inst << " ... " << mendl;
				meta->convert_old_doc_file(filename, true);
				mcerr << "Converted doc file on instance " << inst << " done." << mendl;
			}
		}

	}
	else
		die("Harvest hv_open: couldn't stat file with docs %s", cberr());

	obj->distributed[inst].file_doc = fopen64(filename, "r+");

	if (errno != 0)
		die("Harvest hv_open: couldn't open doc file %s on %s", cberr(), filename);

	if (obj->distributed[inst].file_doc == NULL)
		die("Harvest hv_open: after recovery couldn't open doc file %s", filename);

	sprintf(filename, HARVESTIDX_FILENAME_SITE, relative_rem_path, obj->distributed[inst].id);

	// Check size of file with sites
	if (stat64(filename, &statbuf) == 0)
	{
		// Verify file size
		if ((unsigned int)(statbuf.st_size) != (sizeof(site_t) * obj->distributed[inst].count_site))
		{
			if((uint)(statbuf.st_size) != (sizeof(site_old_t) * obj->distributed[inst].count_site))
				die("Harvest hv_open: inconsistency in the size of site_t (probably needs to re-compile)");
			else
			{
				mcerr << "Converting site file on instance " << inst << " ... " << mendl;
				meta->convert_old_site_file(filename, true);
				mcerr << "Converted site file on instance " << inst << " done." << mendl;
			}
		}

	}
	else
		die("Harvest hv_open: couldn't stat file with sites %s", cberr());

	delete meta;

	obj->distributed[inst].file_site = fopen64(filename, "r+");

	if (errno != 0)
		die("Harvest hv_open: couldn't open site file %s on %s", cberr(), filename);

	if (obj->distributed[inst].file_site == NULL)
		die("Harvest hv_open: couldn't open site file %s", filename);

	sprintf(filename, HARVESTIDX_FILENAME_PATH, relative_rem_path, obj->distributed[inst].id);

	obj->distributed[inst].file_path = fopen64(filename, "r+");

	if (errno != 0)
		die("Harvest hv_open: couldn't open path file %s on %s", cberr(), filename);

	if (obj->distributed[inst].file_path == NULL)
		die("Harvest hv_open: couldn't open path file %s", filename);

	sprintf(filename, HARVESTIDX_FILENAME_SITENAME, relative_rem_path, obj->distributed[inst].id);

	obj->distributed[inst].file_sitename = fopen64(filename, "r+");

	if (errno != 0)
		die("Harvest hv_open: couldn't open sitename file %s on %s", cberr(), filename);

	if (obj->distributed[inst].file_sitename == NULL)
		die("Harvest hv_open: couldn't open sitename file %s", filename);


	// Nullify lists
	obj->distributed[inst].doc_list = NULL;
	obj->distributed[inst].site_list = NULL;

	// Nullify maps
	obj->distributed[inst].map_path = NULL;
	obj->distributed[inst].map_sitename = NULL;
	obj->distributed[inst].map_site = NULL;

	free(relative_rem_path);

	return NULL;
}

// 
// Name: prepare
//
// Description: call relative thread function
//
// Input:
// 
// Output:
//
void Harvest::prepare(unsigned int id, bool debugonly)
{
	assert(dirname != NULL);
	assert(readonly == false);

	if (thread_alarm != THREADS_OK)
		return;

	funcname = CBALLOC(char, MALLOC, (strlen((char *)__func__) + 1));
	funcname[0] = '\0';
	strcpy(funcname, (char *)__func__); 

	global_id = id;
	global_begintime = time(NULL);
	global_hostname[0] = '\0';

	char localhost[MAX_STR_LEN];
    gethostname(localhost, MAX_STR_LEN);
    strcpy(global_hostname, localhost);

	int rc = 0;
	pthread_mutexattr_t attr;

	// Linked lists
	listid = CBALLOC(harvlist_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = HARVEST_PREPARE;
		args->debugonly = debugonly;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_prepare((void *) args); // only one distribution, function is call without thread 

	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	free(funcname);

	free(listid);
}

//
// Name: thread_function_prepare
//
// Description: Setup harvest on relative instance to running
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_prepare(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;
	bool debugonly = arguments->debugonly;

	// disable the cancel of thread because deleting after barrier is more appropriate
	assert(pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL) == 0);

	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);

	static char stringtime[26];
  	sprintf(stringtime, "%s", ctime(&(obj->global_begintime)));
	stringtime[24] = '\0'; // remove newline

	// Get next harvestid (start from one)
	obj->distributed[inst].id = obj->global_id;

	ccerr << "Saving on each instance hostname (" << obj->global_hostname << "), begintime (" << stringtime << ") and status (" << HARVEST_STATUS_STR(STATUS_HARVEST_RUNNING) << ") ... ";

	sync_threads(obj->barrier);


	obj->distributed[inst].hostname[0] = '\0';
    strcpy(obj->distributed[inst].hostname, obj->global_hostname);
	obj->distributed[inst].begintime = obj->global_begintime;
	obj->distributed[inst].status = STATUS_HARVEST_RUNNING;

	sync_threads(obj->barrier);


	ccerr << "done." << endl;

	char filename[MAX_STR_LEN];

	struct stat64 statbuf;
	int rc;
		
	// Check filename existant and check file size, it should contain a single harvest_t structure
	sprintf(filename, HARVESTIDX_FILENAME_MAIN, relative_rem_path, obj->distributed[inst].id);
	rc = stat64(filename, &(statbuf));

	// Check result
	if (rc != 0 && errno != ENOENT)
		die("Harvest prepare: error while trying to stat main file %s on %s", cberr(), filename);
	else if (rc == 0)
	{
		// Try to open
		FILE *file_main = fopen64(filename, "w");
		assert(file_main != NULL);

		// Save
		size_t written = fwrite(&(obj->distributed[inst]), sizeof(harvest_t), 1, file_main);
		assert(written == 1);
		cbiclose(file_main, "main");
	}
	else
		die("Harvest prepare: couldn't stat main file %s on %s", cberr(), filename);

	char workdir[MAX_STR_LEN];

	// Create work directory
	if (debugonly == false)
	{
		sprintf(workdir, "%s/%s/%d", relative_rem_path, COLLECTION_LINK, obj->distributed[inst].id);

		if (mkdir(workdir, S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH))
		{
			// Something went wrong with mkdir
			if (errno == EEXIST) // The directory existed, reuse
			{
				mcerr << "already exists, using ... " << mendl;
				errno = 0;
			}
			else // Other error, exit
				die("Harvest prepare: failed to create working directory %s on %s", cberr(), workdir);
		}

		mcerr << "Created " << workdir << " done." << mendl;
	}

	free(relative_rem_path);

	return NULL;
}

//
// Name: harvest_default
//
// Descriptions:
//   Fills a harvest structure with the default data
//

void Harvest::set_default(instance_t &inst)
{
	assert(distributed != NULL);

	distributed[inst].count		= 0;
	distributed[inst].count_site = 0;
	distributed[inst].count_ok 	= 0;
	distributed[inst].raw_size	= 0;
	distributed[inst].size		= 0;

	distributed[inst].link_total	= 0;
	distributed[inst].link_old_pages	= 0;
	distributed[inst].link_new_pages	= 0;
	distributed[inst].link_new_sites	= 0;

	strcpy(distributed[inst].hostname, "");
	distributed[inst].creationtime = global_creationtime;
	distributed[inst].begintime	= 0;
	distributed[inst].endtime		= 0;
	//distributed[inst].status		= STATUS_HARVEST_EMPTY;
	distributed[inst].status = global_status;
	distributed[inst].readonly	= false;

	distributed[inst].speed_ok		= 0;
	distributed[inst].links_ratio	= 0;
	distributed[inst].bytes_in		= 0;
	distributed[inst].bytes_out		= 0;


	// Nullify lists
	distributed[inst].doc_list = NULL;
	distributed[inst].site_list = NULL;
}

//
// Name: append_doc
//
// Description:
//   Appends a document at the end of the harvest list
//
// Input:
//   harvest - the harvest object
//   doc - the document to append
//
void Harvest::append_doc(doc_t *doc, char *path)
{
	assert(distributed != NULL);
	assert(doc != NULL);

	instance_t inst = ((doc->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	assert(distributed[inst].file_doc != NULL);
	assert(distributed[inst].file_path != NULL);
	assert(distributed[inst].doc_list == NULL);

	int rc;

	// Write document object
	if (fwrite(doc, sizeof(doc_t), 1, distributed[inst].file_doc) != 1)
		die("Harvest append_doc: failed to write document %s", cberr());

	// Check path: it cannot contain \n or \r,
	// otherwise, the path file will not be aligned with
	// the docs file
	int len = strlen(path);

	if (len > 0)
	{
		for(int i=0; i<len; i++)
			assert(path[i] != '\n' && path[i] != '\r');

		// Write path; the paths file for a harvester is a list
		// of paths, one on each line
		if (fwrite(path, len, 1, distributed[inst].file_path) != 1)
			die("Harvest append_doc: failed to write path %s", cberr());
	}

	if (fwrite("\n", 1, 1, distributed[inst].file_path) <= 0)
		die("Harvest append_doc: failed to write path %s", cberr());

	// Increase document count inside harvest on instance 'inst'
	distributed[inst].count++;
}

//
// Name: append_site
//
// Description:
//   Appends a site at the end of the harvest site list
//
// Input:
//   harvest - the harvest object
//   site - the site to append
//
void Harvest::append_site(site_t *site, char *sitename)
{
	assert(distributed != NULL);
	assert(site != NULL);

/*
	unsigned int fcost = 1;

	// TODO Experimental
	// Avoid to assign site with same ip address to different instance
	// to avoid multiple tcp sync at same ip address
	if (CONF_COLLECTION_DISTRIBUTED > ((256 * 256 * 256) - 1))
		fcost = 1;
	else if (CONF_COLLECTION_DISTRIBUTED > ((256 * 256) - 1))
		fcost = ((256 * 256 * 256) - 1);
	else if (CONF_COLLECTION_DISTRIBUTED > (256 - 1))
		fcost = ((256 * 256) - 1);
	else
		fcost = (256 - 1);

//           printf("%u\n", ((site->addr.s_addr % fcost) % ccd));
*/

	instance_t inst = ((site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	assert(distributed[inst].file_site != NULL);
	assert(distributed[inst].file_sitename != NULL);
	assert(distributed[inst].site_list == NULL);


	// Write site object
	if (fwrite(site, sizeof(site_t), 1, distributed[inst].file_site) != 1)
		die("Harvest append_site: failed to write site %s", cberr());

	// Write sitename
	if (fprintf(distributed[inst].file_sitename, "%s\n", sitename) <= 0)
		die("Harvest append_site: failed to write sitename %s", cberr());

	// Increase count of site inside harvest on instance 'inst'
	distributed[inst].count_site++;
}

//
// Name: hv_site_count
//
// Description:
//   Return site count for gived instance
//
// Input:
//   inst - the instance number
//
// Return: the count
//

siteid_t Harvest::hv_site_count(instance_t &inst) const
{
	assert(dirname != NULL);

	return distributed[inst].count_site;
}

//
// Name: hv_bytes_sum
//
// Description: Give the sums of all instance of bytes_in and bytes_out
//
// Input:
//   inst - the references on bytes_in
//   inst - the references on bytes_out
//
// Output: 
//
// Return:
//
void Harvest::hv_bytes_sum(off64_t &bytes_in, off64_t &bytes_out) const
{
	assert(dirname != NULL);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		bytes_in += distributed[i].bytes_in;
		bytes_out += distributed[i].bytes_out;
	}
}

//
// Name: hv_incr_raw_size
//
// Description: Increment raw size for gived instance
//
// Input:
//   inst - the instance number
//   inst - the bytes to sum
//
// Return:
//
void Harvest::hv_incr_raw_size(instance_t &inst, off64_t bytes) const
{
	assert(dirname != NULL);

	distributed[inst].raw_size += bytes;
}

//
// Name: hv_incr_size
//
// Description: Increment size for gived instance
//
// Input:
//   inst - the instance number
//   inst - the bytes to sum
//
// Return:
//
void Harvest::hv_incr_size(instance_t &inst, off64_t bytes) const
{
	assert(dirname != NULL);

	distributed[inst].size += bytes;
}

//
// Name: hv_incr_bytes_in
//
// Description: Increment bytes_in for gived instance
//
// Input:
//   inst - the instance number
//   inst - the bytes to sum
//
// Return:
//
void Harvest::hv_incr_bytes_in(instance_t inst, off64_t bytes) const
{
	assert(dirname != NULL);

	distributed[inst].bytes_in += bytes;
}

//
// Name: hv_incr_bytes_out
//
// Description: Increment bytes_out for gived instance
//
// Input:
//   inst - the instance number
//   inst - the bytes to sum
//
// Return:
//
void Harvest::hv_incr_bytes_out(instance_t inst, off64_t bytes) const
{
	assert(dirname != NULL);

	distributed[inst].bytes_out += bytes;
}

//
// Name: hv_incr_doc_count_ok
//
// Description:
//   Increment doc count for gived instance
//
// Input:
//   inst - the instance number
//
// Return: the count
//
void Harvest::hv_incr_doc_count_ok(instance_t &inst) const
{
	assert(dirname != NULL);

	distributed[inst].count_ok++;
}

//
// Name: hv_incr_link_total
//
// Description: Increment by one link_total for gived instance
//
// Input:
//   inst - the instance number
//
// Return:
//
void Harvest::hv_incr_link_total(instance_t &inst) const
{
	assert(dirname != NULL);

	distributed[inst].link_total++;
}

//
// Name: hv_incr_link_old_pages
//
// Description: Increment by one link_old_pages for gived instance
//
// Input:
//   inst - the instance number
//
// Return:
//
void Harvest::hv_incr_link_old_pages(instance_t &inst) const
{
	assert(dirname != NULL);

	distributed[inst].link_old_pages++;
}

//
// Name: hv_incr_link_new_pages
//
// Description: Increment by one link_new_pages for gived instance
//
// Input:
//   inst - the instance number
//
// Return:
//
void Harvest::hv_incr_link_new_pages(instance_t &inst) const
{
	assert(dirname != NULL);

	distributed[inst].link_new_pages++;
}

//
// Name: hv_incr_link_new_sites
//
// Description: Increment by one link_new_sites for gived instance
//
// Input:
//   inst - the instance number
//
// Return:
//
void Harvest::hv_incr_link_new_sites(instance_t &inst) const
{
	assert(dirname != NULL);

	distributed[inst].link_new_sites++;
}

//
// Name: hv_doc_count
//
// Description:
//   Return doc count for gived instance
//
// Input:
//   inst - the instance number
//
// Return: the count
//
docid_t Harvest::hv_doc_count(instance_t &inst) const
{
	assert(dirname != NULL);

	return distributed[inst].count;
}

//
// Name: hv_doc_count_ok
//
// Description:
//   Return doc count ok for gived instance
//
// Input:
//   inst - the instance number
//
// Return: the count
//
docid_t Harvest::hv_doc_count_ok(instance_t &inst) const
{
	assert(dirname != NULL);

	return distributed[inst].count_ok;
}

//
// Name: hv_site_list
//
// Description:
//   Return site get from site_list for gived instance and serverid
//
// Input:
//   inst - the instance number
//   serverid - the id on the server array
//
// Return site get from site_list for gived instance and serverid
//
site_t *Harvest::hv_site_list(instance_t &inst, siteid_t serverid) const
{
	assert(dirname != NULL);

	return &(distributed[inst].site_list[(serverid - 1)]);
}

//
// Name: hv_hostname_map
//
// Description:
//   Return hostname get from sitemap for gived instance
//
// Input:
//   inst - the instance number
//
// Return: the hostname
//
const char *Harvest::hv_hostname_map(instance_t &inst, siteid_t siteid) const
{
	assert(dirname != NULL);

	return (*(distributed[inst].map_sitename))[siteid].c_str();
}

//
// Name: hv_doc_list
//
// Description:
//   Return pointer to doc_list element for gived instance
//
// Input:
//   inst - the instance number
//   element - the element
//
// Return: the pointer
//
doc_t *Harvest::hv_doc_list(instance_t &inst, docid_t element) const
{
	assert(dirname != NULL);

	return &(distributed[inst].doc_list[element]);
}

//
// Name: hv_path_map
//
// Description:
//   Return pointer to path get from map_path for gived instance
//
// Input:
//   inst - the instance number
//
// Return: the path
//
const char *Harvest::hv_path_map(instance_t &inst, docid_t docid) const
{
	assert(dirname != NULL);

	return (*(distributed[inst].map_path))[docid].c_str();
}

//
// Name: read_list
//
// Description:
//   Read the lists from relative instance and put it in memory
//
// Input:
//   inst - the instance number
//
// Output:
//   distributed[inst].doc_list - list of documents, sorted by docid
//   distributed[inst].site_list - list of sites, sorted by siteid
//

void Harvest::read_list(instance_t &inst)
{
	int rc;

	assert(dirname != NULL);
	assert(distributed[inst].count > 0);
	assert(distributed[inst].doc_list == NULL);
	assert(distributed[inst].site_list == NULL);

	// Get memory
	distributed[inst].doc_list = CBALLOC(doc_t, MALLOC, distributed[inst].count);
	distributed[inst].site_list = CBALLOC(site_t, MALLOC, distributed[inst].count);

	// Go to the beginning of the document file
	rc = fseeko(distributed[inst].file_doc, (off64_t)0, SEEK_SET);

	if(rc != 0)
		die("Harvest read_list: seek error on doc's file");

	// Go to the begining of the path file
	rc = fseeko(distributed[inst].file_path, (off64_t)0, SEEK_SET);

	if(rc != 0)
		die("Harvest read_list: seek error on path's file");

	// Create the map
	distributed[inst].map_path = new map<docid_t,string>;

	// Read documents
	char path[MAX_STR_LEN+1];
	char c;
	int pathlen;
	for (docid_t i = 0; i < distributed[inst].count; i++)
	{
		// Read the document object
		rc = fread(&((distributed[inst].doc_list)[i]), sizeof(doc_t), 1, distributed[inst].file_doc);

		if (errno != 0)
			die("Harvest read_list: readed %llu documents but expected %llu \nCouldn't read doc list (changes in doc_t ?)\n%s", i, distributed[inst].count, cberr());

		if (rc != 1)
			die("Harvest read_list: readed %llu documents but expected %llu \nCouldn't read doc list (changes in doc_t ?)", i, distributed[inst].count);

		// Read the path
		// We don't use fscanf or fgets as there still may be spurious characters
		// in the input
		pathlen = 0;

		while((c = fgetc(distributed[inst].file_path)) != '\n')
		{
			path[pathlen++] = c;

			if(pathlen > MAX_STR_LEN)
				die("Harvest read_list: a long path was found in %s", HARVESTIDX_FILENAME_DOC);
		}

		path[pathlen] = '\0';
		
		// Store the path
		docid_t docid = ((distributed[inst].doc_list)[i]).docid;
		(*(distributed[inst].map_path))[docid] = path;

	}

	char *rc_fgets = fgets(path, MAX_STR_LEN, distributed[inst].file_path);

	// Check that we've reached the end of the file
	if (rc_fgets != NULL)
		die("There are extra lines at the end of %s\nHarvest read_list: the list of documents was not exhausted", HARVESTIDX_FILENAME_DOC);

	// Go to the begining of the site file
	rc = fseeko(distributed[inst].file_site, (off64_t)0, SEEK_SET);

	if(rc != 0)
		die("Harvest read_list: seek error on site's file");

	// Go to the begining of the sitename file
	rc = fseeko(distributed[inst].file_sitename, (off64_t)0, SEEK_SET);

	if(rc != 0)
		die("Harvest read_list: seek error on sitename's file");

	// Create the maps
	distributed[inst].map_site     = new map<siteid_t,site_t>;
	distributed[inst].map_sitename = new map<siteid_t,string>;

	// Read sites
	assert(distributed[inst].count_site > 0);
	for (siteid_t i = 0; i < distributed[inst].count_site; i++)
	{
		// Read the site object
		rc = fread(&((distributed[inst].site_list)[i]), sizeof(site_t), 1, distributed[inst].file_site);

		if (errno != 0)
			die("Readed %lu sites, expected %lu\nHarvest read_list: couldn't read site list (changes in site_t ?)\n%s", (unsigned long int)i, (unsigned long int)distributed[inst].count_site, cberr());

		if (rc != 1)
			die("Readed %lu sites, expected %lu\nHarvest read_list: couldn't read site list (changes in site_t ?)", (unsigned long int)i, (unsigned long int)distributed[inst].count_site);

		// Read the sitename
		char sitename[MAX_STR_LEN];
		fgets(sitename, MAX_STR_LEN, distributed[inst].file_sitename);

		assert(strlen(sitename) > 0);

		// Remove trailing newline
		sitename[strlen(sitename)-1] = '\0';

		// Store the sitename
		siteid_t siteid = ((distributed[inst].site_list)[i]).siteid;
		(*(distributed[inst].map_sitename))[siteid] = sitename;

		// Store the site in the map
		(*(distributed[inst].map_site))[siteid] = (distributed[inst].site_list)[i];

	}
}

//
// Name: read_list_doc_only
//
// Description:
//   Read only docs (no paths, no site names) from file_doc and create list
//
// Input:
//   inst - the instance of harvest
//
// Output:
//   doc_list - list of documents, sorted by docid
//

void Harvest::read_list_doc_only(instance_t &inst) const
{
	int rc;

	assert(this->distributed[inst].count > 0);
	assert(this->distributed[inst].doc_list == NULL);

	// Get memory
	this->distributed[inst].doc_list = CBALLOC(doc_t, MALLOC, (this->distributed[inst].count * sizeof(doc_t)));

	// Go to the begining of the document file
	rc = fseeko(this->distributed[inst].file_doc, (off64_t)0, SEEK_SET);
	assert(rc == 0);

	// Read documents
	for (docid_t i = 0; i < this->distributed[inst].count; i++)
	{	// Read the document object
		rc = fread(&((this->distributed[inst].doc_list)[i]), sizeof(doc_t), 1, this->distributed[inst].file_doc);

		if (errno != 0)
			die("Readed %llu documents, expected %llu\nHarvest read_list_doc_only: couldn't read doc list (changes in doc_t ?)\n%s", (unsigned long long int)i, (unsigned long long int)this->distributed[inst].count, cberr());

		if (rc != 1)
			die("Readed %llu documents, expected %llu\nHarvest read_list_doc_only: couldn't read doc list (changes in doc_t ?)", (unsigned long long int)i, (unsigned long long int)this->distributed[inst].count);
	}
}

// 
// Name: dump_status
//
// Description: call relative thread function
//
// Input: strict true if we want dump for harvest on each instance else summary dump
// 
// Output:
//
void Harvest::dump_status(bool strict)
{
	assert(dirname != NULL);
//	assert(readonly == false);

	if (thread_alarm != THREADS_OK)
		return;

	harvest_volatile_status_t *dump_status = CBALLOC(harvest_volatile_status_t, CALLOC, 1);

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = HARVEST_DUMP_STATUS;
		args->dump = dump_status;
		args->strict = strict;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_dump_status((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}

	cerr << " Begin status dump for harvest #" << global_id << endl;

	if (strict == false)
	{
		cerr << "  - status          : " << HARVEST_STATUS_STR(global_status) << endl;
		cerr << "  - count           : " << dump_status->count << endl;
		cerr << "  - count_site      : " << dump_status->count_site << endl;
		cerr << "  - count_ok        : " << dump_status->count_ok << endl;
		cerr << "  - raw_size        : " << dump_status->raw_size << endl;
		cerr << "  - size            : " << dump_status->size << endl;
		cerr << "  - link_total      : " << dump_status->link_total << endl;
		cerr << "  - link_new_sites  : " << dump_status->link_new_sites << endl;
		cerr << "  - link_old_pages  : " << dump_status->link_old_pages << endl;
		cerr << "  - link_new_pages  : " << dump_status->link_new_pages << endl;

		// links_ratio
		if (dump_status->link_new_pages > 0)
		{
			cerr << "  - newlinks/total  : " << (double)dump_status->link_new_pages / (double)(dump_status->link_new_pages + dump_status->link_old_pages);
			cerr << " (link_new_pages / (link_new_pages + link_old_pages))" << endl;
		}
		else
			cerr << "  - newlinks/total  : 0 (link_new_pages / (link_new_pages + link_old_pages))" << endl;

		cerr << endl;

		cerr << "  - hostname        : " << global_hostname << endl;
		cerr << "  - creationtime    : " << ctime(&(global_creationtime));

		time_t btime = (time_t)(NULL);
		time_t etime = (time_t)(NULL);

		// calculate dynamic media of begintime and endtime
		if (CONF_COLLECTION_DISTRIBUTED > 0)
		{
			// Average snapshop (media istantanea)
			// la media èsempre aggiornata all'aggiunta di un nuovo elemento.
			double media_btime = (double)0;
			double media_etime = (double)0;

			for (instance_t offset = 0; offset < CONF_COLLECTION_DISTRIBUTED; offset++)
			{
				media_btime = (((media_btime / (offset + 1)) * offset) + (distributed[offset].begintime / (double)(offset + 1)));
				media_etime = (((media_etime / (offset + 1)) * offset) + (distributed[offset].endtime / (double)(offset + 1)));
			}

			btime = (time_t)(media_btime);
			etime = (time_t)(media_etime);

			char buf[26];

			buf[0] = '\0';
			ctime_r(&(btime), buf);
			cerr << "  - begintime (avg) : " << buf;

			buf[0] = '\0';
			ctime_r(&(etime), buf);
			cerr << "  - endtime (avg)   : " << buf;
		}
		else
		{
			btime = distributed[0].begintime;
			etime = distributed[0].endtime;

			char buf[26];

			buf[0] = '\0';
			ctime_r(&(distributed[0].begintime), buf);
			cerr << "  - begintime       : " << buf;

			buf[0] = '\0';
			ctime_r(&(distributed[0].endtime), buf);
			cerr << "  - endtime         : " << buf;
		}

		cerr << "  - bytes in        : " << dump_status->bytes_in << endl;
		cerr << "  - bytes out       : " << dump_status->bytes_out << endl;

		// speed_ok
		if (dump_status->count_ok > 0)
		{
			cerr << "  - speed_ok        : " << ((double)dump_status->count_ok / (etime - btime));
			cerr << " (docs(" << dump_status->count_ok << ")/sec(" << (etime - btime) << "))" << endl;
		}
		else
			cerr << "  - speed_ok        : 0 (docs/sec)" << endl;
	}
	else
		cerr << "Status dump must be implemented!" << endl;

	cerr << " End status dump for harvest #" << global_id << endl;

	free(dump_status);
}

//
// Name: thread_function_dump_status
//
// Description:
//   Delete harvest 
//
// Input: pointer to void
// 
// Output:
//
void *Harvest::thread_function_dump_status(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;
	harvest_volatile_status_t *dump = arguments->dump;
	bool strict = arguments->strict;

	if (strict == false)
	{
		dump->count += obj->distributed[inst].count;
		dump->count_site += obj->distributed[inst].count_site;
		dump->count_ok += obj->distributed[inst].count_ok;
		dump->raw_size += obj->distributed[inst].raw_size;
		dump->size += obj->distributed[inst].size;
		dump->link_total += obj->distributed[inst].link_total;
		dump->link_new_sites += obj->distributed[inst].link_new_sites;
		dump->link_old_pages += obj->distributed[inst].link_old_pages;
		dump->link_new_pages += obj->distributed[inst].link_new_pages;
		dump->bytes_in += obj->distributed[inst].bytes_in;
		dump->bytes_out += obj->distributed[inst].bytes_out;
	}

	return NULL;
}

//
// Name: dump_list
//
// Description:
//   Shows the list of the harvest
//
// Input:
//   harvest - structure
//
void Harvest::dump_list()
{
	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		// Read list
		read_list(inst);

		// Iterate
		for (docid_t i = 0; i < hv_doc_count(inst); i++)
		{
			// Get document
			doc_t *doc = &((distributed[inst].doc_list)[i]);

			// Print
			cerr << doc->siteid << " ";
			cerr << doc->docid << " ";
			cerr << (*(distributed[inst].map_sitename))[doc->siteid] << "/";
			cerr << (*(distributed[inst].map_path))[doc->docid] << endl;
		}
	}
}

//
// Name: harvest_analyze_harvests
//
// Description:
//   Analyzes data about the harvests
//
// Input:
//   output - descriptor
//

void Harvest::analyze(Meta *meta)
{
	assert(meta != NULL);
	assert(readonly == true);

	if (thread_alarm != THREADS_OK)
		return;

	int rc;
	pthread_mutexattr_t attr;

	docid_t	ndocs	= meta->doc_count();

	unsigned int nharvests = 1;

	// Warning: harvest list must be consecutive
	while (is_found(nharvests))
		nharvests++;

	nharvests--;

	assert(nharvests > 0);

	cerr << "Harvest rounds to analyze : " << nharvests << endl;

	harvestids = CBALLOC(unsigned int, CALLOC, (ndocs + 1));

	sum_pagerank = CBALLOC(internal_long_double_t, CALLOC, (nharvests + 1));
	sum_wlrank = CBALLOC(internal_long_double_t, CALLOC, (nharvests + 1));
	sum_hubrank = CBALLOC(internal_long_double_t, CALLOC, (nharvests + 1));
	sum_authrank = CBALLOC(internal_long_double_t, CALLOC, (nharvests + 1));
	sum_liverank = CBALLOC(internal_long_double_t, CALLOC, (nharvests + 1));
	sum_in_degree = CBALLOC(internal_long_uint_t, CALLOC, (nharvests + 1));
	sum_depth = CBALLOC(internal_long_uint_t, CALLOC, (nharvests + 1));
	sum_ok = CBALLOC(internal_long_uint_t, CALLOC, (nharvests + 1));

	// Iterate through harvest rounds
	// to see to which round a document belong.
	// Mark the document with the last round in which it was
	// active.
	unsigned int nharvests_div_50	= nharvests / 50;
	cerr << "Reading harvests    |--------------------------------------------------|" << endl;
	cerr << "                     ";
	unsigned int harvest_id	= 1;

	while(is_found(harvest_id))
	{
		if(nharvests_div_50 > 0 && harvest_id % nharvests_div_50 == 0)
			cerr << ".";

		// Open in read-only mode
		harvest_status_t harvest_status = hv_open(harvest_id, readonly);


		if (harvest_status == STATUS_HARVEST_SEEDED)
		{
			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

				barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

				pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

				if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
					die("error setting mutex type %s", CBoterr(rc));

				if ((rc = pthread_mutexattr_init(&attr)) != 0)
					die("error creating mutex with attributes object %s", CBoterr(rc));
			}

			for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
			{
				Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
			    args->inst = inst;
				args->obj = this;
				args->f = HARVEST_ANALYZE_READING_HARVEST;
				args->nharvests = nharvests; 

				if (CONF_COLLECTION_DISTRIBUTED > 1)
				{
					if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
						die("error creating thread!");
				}
				else
					thread_function_analyze_reading_harvest((void *) args); // only one distribution, function is call without thread 

			}

			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

				free(threads);

				pthread_barrier_destroy(barrier);

				free(barrier); barrier = NULL;

				if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
					die("error destroying mutex with attributes object %s", CBoterr(rc));
			}
		}

		// Close
		hv_close();

		// Next
		harvest_id++;
	}
	cerr << "ok." << endl;

	// Iterate through documents
	docid_t ndocs_div_50    = ndocs / 50;
	cerr << "Analyzing docs      |--------------------------------------------------|" << endl;
	cerr << "                     ";

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));

		mutex_analyze_statistics = CBALLOC(pthread_mutex_t, MALLOC, harvest_id);

		for (unsigned int i = 0; i < harvest_id; i++)
			mutex_analyze_statistics[i] = PTHREAD_MUTEX_INITIALIZER;
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = HARVEST_ANALYZE_ANALYZING_DOCS;
		args->meta = meta;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_analyze_analyzing_docs((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		for (unsigned int i = 0; i < harvest_id; i++)
			if ((rc = pthread_mutex_destroy(&mutex_analyze_statistics[i])) != 0)
				die("error destroying mutexes %s", CBoterr(rc));

		free(mutex_analyze_statistics);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	//
	// Write data
	//

	char filename[MAX_STR_LEN];
	FILE *output;

	// Create output dir
	sprintf(filename, "%s/harvest", COLLECTION_ANALYSIS);
	createdir(filename);

	// Write harvest data
	sprintf(filename, "%s/harvest/harvest_analysis.csv", COLLECTION_ANALYSIS);
	output	= fopen64(filename, "w");
	assert(output != NULL);
	dump_data_header(output);

	harvest_volatile_status_t *dump_status = CBALLOC(harvest_volatile_status_t, CALLOC, 1);

	for(unsigned int i = 1; i <= nharvests; i++)
	{
		memset(dump_status, 0, sizeof(harvest_volatile_status_t));

		// Open in read-only mode
		harvest_status_t harvest_status = hv_open(i, readonly);


		if (harvest_status == STATUS_HARVEST_SEEDED)
		{
			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

				barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

				pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

				if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
					die("error setting mutex type %s", CBoterr(rc));

				if ((rc = pthread_mutexattr_init(&attr)) != 0)
					die("error creating mutex with attributes object %s", CBoterr(rc));
			}

			for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
			{
				Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
			    args->inst = inst;
				args->obj = this;
				args->id = global_id;
				args->f = HARVEST_ANALYZE_WRITE_DATA;
				args->dump = dump_status;

				args->nharvests = nharvests; 

				if (CONF_COLLECTION_DISTRIBUTED > 1)
				{
					if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
						die("error creating thread!");
				}
				else
					thread_function_analyze_write_data((void *) args); // only one distribution, function is call without thread 

			}

			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

				free(threads);

				pthread_barrier_destroy(barrier);

				free(barrier); barrier = NULL;

				if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
					die("error destroying mutex with attributes object %s", CBoterr(rc));
			}
		}

		// Show data
		dump_data(output, dump_status);

		// Close
		hv_close();
	}

	// Free
	fclose(output);

	free(dump_status);

	free(harvestids);

	free(sum_pagerank);
	free(sum_wlrank);
	free(sum_hubrank);
	free(sum_authrank);
	free(sum_liverank);

	free(sum_in_degree);
	free(sum_depth);
	free(sum_ok);
}

//
// Name: thread_function_analyze_reading_harvest
//
// Description:
//   Called from analyze 
//
// Input: pointer to void
// 
// Output:
//

void *Harvest::thread_function_analyze_reading_harvest(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;
    unsigned int nharvests = arguments->nharvests;

	assert(nharvests > 0);

	// disable the cancel of thread because deleting after barrier is more appropriate
	// assert(pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL) == 0);

	// sync_threads(obj->barrier);
	//

	// Read list of documents
	obj->read_list_doc_only(inst);

	// set for each docid the last harvest that have visit it
	for(unsigned int i = 0; i < obj->distributed[inst].count; i++)
	{
		doc_t *doc	= &((obj->distributed[inst].doc_list)[i]);
		obj->harvestids[doc->docid] = obj->global_id;
	}

	return NULL;
}

//
// Name: thread_function_analyze_analyzing_docs 
//
// Description:
//   Called from analyze 
//
// Input: pointer to void
// 
// Output:
//

void *Harvest::thread_function_analyze_analyzing_docs(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;
	Meta* meta = arguments->meta;

	// disable the cancel of thread because deleting after barrier is more appropriate
	assert(pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL) == 0);

	assert(obj->mutex_analyze_statistics);

	docid_t ndocs_div_50    = (meta->doc_count() / 50);

	doc_t doc;

	for (docid_t docid = (inst + 1); docid <= meta->doc_count(); docid += CONF_COLLECTION_DISTRIBUTED)
	{
		doc.docid       = docid;
		meta->doc_retrieve(&(doc));
        assert(doc.docid == docid);

		if (ndocs_div_50 > 0 && (docid % ndocs_div_50) == 0)
			cerr << ".";

		// if(HTTP_IS_OK(doc.http_status) || HTTP_IS_REDIRECT(doc.http_status)) // original
		// Note: this data is not saved into harvests
		if(obj->harvestids[doc.docid] > 0 && (HTTP_IS_OK(doc.http_status) || HTTP_IS_REDIRECT(doc.http_status)))
		{
        	int rc = 0;

			if ((rc = pthread_mutex_lock(&(obj->mutex_analyze_statistics[obj->harvestids[doc.docid]]))) != 0)
				die("error locking mutex %s", CBoterr(rc));

			obj->sum_pagerank[obj->harvestids[doc.docid]] += (internal_long_double_t)(doc.pagerank);
			obj->sum_wlrank[obj->harvestids[doc.docid]]  += (internal_long_double_t)(doc.wlrank);
			obj->sum_hubrank[obj->harvestids[doc.docid]] += (internal_long_double_t)(doc.hubrank);
			obj->sum_authrank[obj->harvestids[doc.docid]] += (internal_long_double_t)(doc.authrank);
			obj->sum_liverank[obj->harvestids[doc.docid]] += (internal_long_double_t)(doc.liverank);
			obj->sum_in_degree[obj->harvestids[doc.docid]] += (internal_long_uint_t)doc.in_degree;
			obj->sum_depth[obj->harvestids[doc.docid]] += (internal_long_uint_t)(doc.depth);
			obj->sum_ok[obj->harvestids[doc.docid]]++;

			if ((rc = pthread_mutex_unlock(&(obj->mutex_analyze_statistics[obj->harvestids[doc.docid]]))) != 0)
				die("error locking mutex %s", CBoterr(rc));
		}
	}
	cerr << " ok." << endl;

	return NULL;
}

//
// Name: thread_function_analyze_analyzing_docs 
//
// Description:
//   Called from analyze 
//
// Input: pointer to void
// 
// Output:
//

void *Harvest::thread_function_analyze_write_data(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;
	Meta* meta = arguments->meta;
	harvest_volatile_status_t *dump = arguments->dump;

	dump->count += obj->distributed[inst].count;
	dump->count_site += obj->distributed[inst].count_site;
	dump->count_ok += obj->distributed[inst].count_ok;
	dump->raw_size += obj->distributed[inst].raw_size;
	dump->size += obj->distributed[inst].size;
	dump->link_total += obj->distributed[inst].link_total;
	dump->link_new_sites += obj->distributed[inst].link_new_sites;
	dump->link_old_pages += obj->distributed[inst].link_old_pages;
	dump->link_new_pages += obj->distributed[inst].link_new_pages;
	dump->bytes_in += obj->distributed[inst].bytes_in;
	dump->bytes_out += obj->distributed[inst].bytes_out;

	return NULL;
}

//
// Name: extract
//
// Description:
//   Extract data from harvesting without including summary statistics (eg: sum_pagerank)
//
// Input:
//   output - descriptor
//

void Harvest::extract(void)
{
	assert(readonly == true);

	if (thread_alarm != THREADS_OK)
		return;

	int rc;
	pthread_mutexattr_t attr;

	//
	// dump data
	//

	// Dump harvest data
	dump_data_header_brief(stdout);

	harvest_volatile_status_t *dump_status = CBALLOC(harvest_volatile_status_t, CALLOC, 1);

	unsigned int harvest_id	= 1;

	while(is_found(harvest_id))
	{
		memset(dump_status, 0, sizeof(harvest_volatile_status_t));

		// Open in read-only mode
		harvest_status_t harvest_status = hv_open(harvest_id, readonly);

		if (harvest_status == STATUS_HARVEST_SEEDED)
		{
			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

				barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

				pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

				if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
					die("error setting mutex type %s", CBoterr(rc));

				if ((rc = pthread_mutexattr_init(&attr)) != 0)
					die("error creating mutex with attributes object %s", CBoterr(rc));
			}

			for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
			{
				Harvest::thread_args_t *args = CBALLOC(Harvest::thread_args_t, MALLOC, 1);
			    args->inst = inst;
				args->obj = this;
				args->id = global_id;
				args->f = HARVEST_EXTRACT_DUMP_DATA;
				args->dump = dump_status;

				if (CONF_COLLECTION_DISTRIBUTED > 1)
				{
					if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
						die("error creating thread!");
				}
				else
					thread_function_extract_dump_data((void *) args); // only one distribution, function is call without thread 
			}

			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

				free(threads);

				pthread_barrier_destroy(barrier);

				free(barrier); barrier = NULL;

				if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
					die("error destroying mutex with attributes object %s", CBoterr(rc));
			}
		}

		// Show data
		dump_data_brief(stdout, dump_status);

		// Close
		hv_close();

		// Next
		harvest_id++;
	}

	// Free
	free(dump_status);
}

//
// Name: thread_function_extract_dump_data
//
// Description:
//   Called from analyze 
//
// Input: pointer to void
// 
// Output:
//

void *Harvest::thread_function_extract_dump_data(void *args)
{
	cpu_set_t system_cpus;

    Harvest::thread_args_t *arguments = (Harvest::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Harvest *obj = arguments->obj;
	Meta* meta = arguments->meta;
	harvest_volatile_status_t *dump = arguments->dump;

	dump->count += obj->distributed[inst].count;
	dump->count_site += obj->distributed[inst].count_site;
	dump->count_ok += obj->distributed[inst].count_ok;
	dump->raw_size += obj->distributed[inst].raw_size;
	dump->size += obj->distributed[inst].size;
	dump->link_total += obj->distributed[inst].link_total;
	dump->link_new_sites += obj->distributed[inst].link_new_sites;
	dump->link_old_pages += obj->distributed[inst].link_old_pages;
	dump->link_new_pages += obj->distributed[inst].link_new_pages;
	dump->bytes_in += obj->distributed[inst].bytes_in;
	dump->bytes_out += obj->distributed[inst].bytes_out;

	return NULL;
}

//
// Name: dump_data_header
//
// Description:
//   Dump the data header for analysis, MUST have fields
//   in the SAME order
//

void Harvest::dump_data_header(FILE *output) const
{
	assert(output != NULL);
	fprintf(output, "1id,");
	fprintf(output, "2count,");
	fprintf(output, "3count_ok,");
	fprintf(output, "4count_site,");
	fprintf(output, "5raw_size,");
	fprintf(output, "6size,");
	fprintf(output, "7link_total,");
	fprintf(output, "8link_old_pages,");
	fprintf(output, "9link_new_pages,");
	fprintf(output, "10link_new_sites,");
	fprintf(output, "11creationtime,");
	fprintf(output, "12begintime,");
	fprintf(output, "13endtime,");
	fprintf(output, "14status,");
	fprintf(output, "15sum_pagerank,");
	fprintf(output, "16sum_wlrank,");
	fprintf(output, "17sum_hubrank,");
	fprintf(output, "18sum_authrank,");
	fprintf(output, "19sum_liverank,");
	fprintf(output, "20sum_in_degree,");
	fprintf(output, "21sum_depth,");
	fprintf(output, "22sum_ok,");
	fprintf(output, "23speed_ok,");
	fprintf(output, "24links_ratio,");
	fprintf(output, "25bytes_in,");
	fprintf(output, "26bytes_out,");
	fprintf(output, "27hostname\n");
}

//
// Name: dump_data_header
//
// Description:
//   Dump the data header for analysis, MUST have fields
//   in the SAME order
//

void Harvest::dump_data_header_brief(FILE *output) const
{
	assert(output != NULL);
	fprintf(output, "1id,");
	fprintf(output, "2count,");
	fprintf(output, "3count_ok,");
	fprintf(output, "4count_site,");
	fprintf(output, "5raw_size,");
	fprintf(output, "6size,");
	fprintf(output, "7link_total,");
	fprintf(output, "8link_old_pages,");
	fprintf(output, "9link_new_pages,");
	fprintf(output, "10link_new_sites,");
	fprintf(output, "11creationtime,");
	fprintf(output, "12begintime,");
	fprintf(output, "13endtime,");
	fprintf(output, "14status,");
	fprintf(output, "15speed_ok,");
	fprintf(output, "16links_ratio,");
	fprintf(output, "17bytes_in,");
	fprintf(output, "18bytes_out,");
	fprintf(output, "19hostname\n");
}

//
// Name: harvest_dump_data
//
// Description:
//   Dumps the status of a harvest to a text-only database, for analysis.
//
// Input:
//   harvest - structure
//
void Harvest::dump_data(FILE *output, harvest_volatile_status_t *dump) const
{
	assert(output != NULL);

	fprintf(output, "%u,", this->global_id);
	fprintf(output, "%u,", (unsigned int)dump->count);
	fprintf(output, "%u,", (unsigned int)dump->count_ok);
	fprintf(output, "%u,", (unsigned int)dump->count_site);
	fprintf(output, "%lu,", (long unsigned int)(dump->raw_size));
	fprintf(output, "%lu,", (long unsigned int)(dump->size));
	fprintf(output, "%u,", (unsigned int)dump->link_total);
	fprintf(output, "%u,", (unsigned int)dump->link_old_pages);
	fprintf(output, "%u,", (unsigned int)dump->link_new_pages);
	fprintf(output, "%u,", (unsigned int)dump->link_new_sites);
	fprintf(output, "%d,", (int)(this->global_creationtime));

	time_t btime = (time_t)(NULL);
	time_t etime = (time_t)(NULL);

	// calculate dynamic media of begintime and endtime
	if (CONF_COLLECTION_DISTRIBUTED > 0)
	{
		// Average snapshop (media istantanea)
		// la media èsempre aggiornata all'aggiunta di un nuovo elemento.
		double media_btime = (double)0;
		double media_etime = (double)0;

		for (instance_t offset = 0; offset < CONF_COLLECTION_DISTRIBUTED; offset++)
		{
			media_btime = (((media_btime / (offset + 1)) * offset) + (this->distributed[offset].begintime / (double)(offset + 1)));
			media_etime = (((media_etime / (offset + 1)) * offset) + (this->distributed[offset].endtime / (double)(offset + 1)));
		}

		btime = (time_t)(media_btime);
		etime = (time_t)(media_etime);

		fprintf(output, "%d,", (int)(btime));
		fprintf(output, "%d,", (int)(etime));
	}
	else
	{
		btime = this->distributed[0].begintime;
		etime = this->distributed[0].endtime;
		
		fprintf(output, "%d,", (int)(btime));
		fprintf(output, "%d,", (int)(etime));
	}

	fprintf(output, "%s,", HARVEST_STATUS_STR(this->global_status));
	fprintf(output, "%lle,", this->sum_pagerank[this->global_id]);
	fprintf(output, "%lle,", this->sum_wlrank[this->global_id]);
	fprintf(output, "%lle,", this->sum_hubrank[this->global_id]);
	fprintf(output, "%lle,", this->sum_authrank[this->global_id]);
	fprintf(output, "%lle,", this->sum_liverank[this->global_id]);
	fprintf(output, "%llu,", this->sum_in_degree[this->global_id]);
	fprintf(output, "%llu,", this->sum_depth[this->global_id]);
	fprintf(output, "%llu,", this->sum_ok[this->global_id]);

	// speed_ok
	if (dump->count_ok > 0)
		fprintf(output, "%e,", ((double)dump->count_ok / (etime - btime)));
	else
		fprintf(output, "%e,", (double)0);

	// links_ratio
	if (dump->link_new_pages > 0)
		fprintf(output, "%e,", ((double)dump->link_new_pages / (double)(dump->link_new_pages + dump->link_old_pages)));
	else
		fprintf(output, "%e,", (double)0);

	fprintf(output, "%lu,", (long unsigned int)(dump->bytes_in));
	fprintf(output, "%lu,", (long unsigned int)(dump->bytes_out));
	fprintf(output, "%s\n", this->global_hostname);
}

//
// Name: harvest_dump_data
//
// Description:
//   Dumps the status of a harvest to a text-only database, for analysis.
//
// Input:
//   harvest - structure
//
void Harvest::dump_data_brief(FILE *output, harvest_volatile_status_t *dump) const
{
	assert(output != NULL);

	fprintf(output, "%u,", this->global_id);
	fprintf(output, "%u,", (unsigned int)dump->count);
	fprintf(output, "%u,", (unsigned int)dump->count_ok);
	fprintf(output, "%u,", (unsigned int)dump->count_site);
	fprintf(output, "%lu,", (long unsigned int)(dump->raw_size));
	fprintf(output, "%lu,", (long unsigned int)(dump->size));
	fprintf(output, "%u,", (unsigned int)dump->link_total);
	fprintf(output, "%u,", (unsigned int)dump->link_old_pages);
	fprintf(output, "%u,", (unsigned int)dump->link_new_pages);
	fprintf(output, "%u,", (unsigned int)dump->link_new_sites);
	fprintf(output, "%d,", (int)(this->global_creationtime));

	time_t btime = (time_t)(NULL);
	time_t etime = (time_t)(NULL);

	// calculate dynamic media of begintime and endtime
	if (CONF_COLLECTION_DISTRIBUTED > 0)
	{
		// Average snapshop (media istantanea)
		// la media èsempre aggiornata all'aggiunta di un nuovo elemento.
		double media_btime = (double)0;
		double media_etime = (double)0;

		for (instance_t offset = 0; offset < CONF_COLLECTION_DISTRIBUTED; offset++)
		{
			media_btime = (((media_btime / (offset + 1)) * offset) + (this->distributed[offset].begintime / (double)(offset + 1)));
			media_etime = (((media_etime / (offset + 1)) * offset) + (this->distributed[offset].endtime / (double)(offset + 1)));
		}

		btime = (time_t)(media_btime);
		etime = (time_t)(media_etime);

		fprintf(output, "%d,", (int)(btime));
		fprintf(output, "%d,", (int)(etime));
	}
	else
	{
		btime = this->distributed[0].begintime;
		etime = this->distributed[0].endtime;
		
		fprintf(output, "%d,", (int)(btime));
		fprintf(output, "%d,", (int)(etime));
	}

	fprintf(output, "%s,", HARVEST_STATUS_STR(this->global_status));

	// speed_ok
	if (dump->count_ok > 0)
		fprintf(output, "%e,", ((double)dump->count_ok / (etime - btime)));
	else
		fprintf(output, "%e,", (double)0);

	// links_ratio
	if (dump->link_new_pages > 0)
		fprintf(output, "%e,", ((double)dump->link_new_pages / (double)(dump->link_new_pages + dump->link_old_pages)));
	else
		fprintf(output, "%e,", (double)0);

	fprintf(output, "%lu,", (long unsigned int)(dump->bytes_in));
	fprintf(output, "%lu,", (long unsigned int)(dump->bytes_out));
	fprintf(output, "%s\n", this->global_hostname);
}
