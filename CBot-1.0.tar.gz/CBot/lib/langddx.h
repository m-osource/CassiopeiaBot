/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _LANGDDX_H_INCLUDED_
#define _LANGDDX_H_INCLUDED_

#include <config.h>

// System libraries

#include <features.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <iostream>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/stat.h>

#include <atomic>
#include <math.h>
#include <errno.h>
#include <queue>
#include <string>
#include <map>

using namespace std;

// Local libraries

#include "const.h"
#include "http_codes.h"
#include "xmlconf.h"
#include "die.h"
#include "utils.h"
#include "Url.h"
#include "http_charset.h"

// File names

#define LANGDDX_FILENAME_WORD	"langddx.word"
#define INSTANCE_MAXWORD (CONF_COLLECTION_MAXWORD / CONF_COLLECTION_DISTRIBUTED + 1)

// Meta index status

enum langddx_status_t {
	LANGDDX_OK         = 0,
	LANGDDX_ERROR,
	LANGDDX_EOF
};

// Type for a metaindex
// The word count is stored in word[0].wordid

typedef struct {
	int file_word; // fd
	char dirname[MAX_STR_LEN];
	wordid_t count_word;
	// bool readonly;
} lddx_t;

typedef struct {
	lddx_t *distributed;
	std::atomic<wordid_t> count_word; // Counter reliable only in readonly mode true (share data)
	bool readonly;
} langddx_t;

// Use this struct only words that have his stemming
typedef struct {
	wordid_t			wordid;
   	Stemming			language;
	// unsigned long long int doc_attendance; // numero di documenti in cui la parola è presente (uso statistico)
} word_t;

// need to passing arguments to threads functions
typedef struct {
    unsigned int i;
    langddx_t *m;
    char *d;
} langddx_thread_function_args_t;

// Functions

// Open langddx
langddx_t *langddx_open( const char *dirname, bool readonly );

// Function required by langddx_open (pthread use)
void *langddx_thread_function_open(void *args);

// Close langddx
langddx_status_t langddx_close( langddx_t *m );

// Function required by langddx_close (pthread use)
void *langddx_thread_function_close(void *args);
void *langddx_thread_function_ronly_close(void *args);

// Remove langddx
void langddx_remove( const char *dirname );

// Function required by langddx_remove (pthread use)
void *langddx_thread_function_remove(void *args);

// Blank records
void langddx_word_default( word_t *word );

// Retrieve and store
langddx_status_t langddx_word_retrieve( langddx_t *m, word_t *word );
langddx_status_t langddx_word_store( langddx_t *m, word_t *word );

// Dump

void langddx_dump_word_status( word_t *word );
void langddx_dump_word_short_status( word_t *word );
void langddx_dump_status( langddx_t *langddx );

void langddx_dump_word_header( FILE *out );
void langddx_dump_word( word_t *word, FILE *out );

#endif
