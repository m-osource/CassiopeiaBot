/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _UTILS_H_INCLUDED_
#define _UTILS_H_INCLUDED_

#include <config.h>

// System libraries

#include <regex.h>
#include <map>
#include <iostream>
#include <string>
#include <syslog.h>
#include <cleanup.h>
#include <ctype.h>
#include <time.h>
#include <errno.h>
#include <math.h>
#include <unistd.h>
//#define __GNU_SOURCE
#include <fcntl.h>
#include <arpa/inet.h>

// Local libraries

#include "xmlconf.h"
#include "perfect_hash.h"

// Constants

#define MAX_TOKENS	255

// Globals

extern SemaphorePrint *sp;
extern bool *symshown;
extern pthread_mutex_t *console_lock;


// External functions

using namespace std;

extern void xmlconf_load();
extern void cleanup_enable();
extern void cleanup();
extern void cleanup_disable();

typedef struct {
	char *handled;
	size_t mbslen; // numero di caratteri tipo char (byte nella string)
	size_t wcslen; // numero caratteri 'wide char' (quelli visibili su stringa utf8) // se 0 la stringa contiene solo caratteri ascii NON estesi
	bool have_noalpha; // true se all'interno della stringa è presente uno o più caratteri NON alfabetici
} str_handler_t;

typedef struct {
    robots_txt_rule_t rule;
    char *rulename;
    unsigned int vote;
} robots_txt_matched_t;

// Functions

namespace DataRetention
{
	enum drdir_t : uint8_t {
		REMDR = 0, // normal traditional disk storages
		LOCDR = 1, // local ssd storages
		NOT_DEFINED
	};

	// make partial path relative to instance
	char *make( drdir_t, instance_t );

	// make path relative to instance
	char *make( drdir_t, const char *, instance_t );

	// Convert drdir_t to const string
	const char *drdir ( drdir_t );
}

str_handler_t *str_handler( const char *mbsinput, bool str_tolower );
void get_extension( char *examined, char *extension );
void unescape_url( char *url );
void normalize_percent_encoding( char *url );
ssize_t parse_hex_char(char character);
ssize_t parse_hex_string(char *what, size_t max_length, off64_t *value, bool *is_quoted_string, bool *is_chunked_extension);
void url_encode(char *c);
void tokenizeToMap( char *str, map<string,bool> &theMap );
char **tokenizeToTable( char *str, int *ntokens_out );
void tokenizeToRegex(char *str, regex_t *regex );
bool has_nonprintable_characters( char *str );
void timestamp( char *str );
void createdir( const char *dirname );
void replace_all( char *, const char *, const char * );
size_t read_file( char *, char *, size_t );
float timer_delta( struct timeval *, struct timeval * );
void utc_timezone_setup( void );
time_t get_time( const char *, const char * );
bool get_addr( struct sockaddr_storage *, char * );
int url_has_protocol( char * );
void url_adjust_path( char * );
void fqdn_to_domain( perfhash_t, char *, char *&, char *& );
char *siteToDomain( perfhash_t, char * ); // deprecated
double logarithm( double, double );
char *digits_to_ascii( off64_t w );
void robots_txt_display( char *, size_t );
void robots_txt_syntax( const char *, size_t, char *, size_t & );
robots_txt_matched_t *robots_txt_match( char *, size_t, char * );
bool file_lock( FILE *, bool );
bool fd_lock( int, bool );
bool file_unlock( FILE * );
bool fd_unlock( int );
pes_t *htmlSplit( char * );
pes_t *pdfSplit( char * );

void cbot_start( const char * );
void cbot_stop( int );
bool cbot_stats( bool );

#endif
