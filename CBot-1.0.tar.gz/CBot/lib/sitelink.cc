/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "sitelink.h"

//
// Name: thread_function_caller
//
// Description:
//   A proxy function to pass non-static function at pthread_create
//   Note: function called by thread_function_caller need to have real class object passed through args
//
// Input:
//   args - void arguments
//
// Return:
//   pointer to void
//

void *Sitelink::thread_function_caller(void *args)
{
	assert(args);

	Sitelink::thread_args_t *arguments = (Sitelink::thread_args_t *)args;
try
{
	Sitelink *newObj = NULL; // Note function called work to 'this' temporary object and need to be deleted at the end of the same.

	try
	{
		newObj = new Sitelink (NULL, true); // Note function called work to 'this' temporary object and need to be deleted at the end of the same.
	}
	catch (std::bad_alloc &ba)
	{
		die("Harvest thread_function_caller: bad_alloc caught %s", ba.what());
	}

	switch (arguments->f)
	{
		case SITELINK_CREATE:
			newObj->thread_function_create(args);
			break;
		case SITELINK_LOAD:
			newObj->thread_function_load(args);
			break;
		case SITELINK_UNLOAD:
			newObj->thread_function_unload(args);
			break;
		case SITELINK_ANALYSIS_SITERANK:
			newObj->thread_function_analysis_siterank(args);
			break;
		case SITELINK_DLFSTS:
			newObj->thread_function_dump_links_from_sitenames_to_sitename(args);
			break;
		default:
			break;
	}

	delete newObj;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(arguments->obj->barrier); 
}

	// Each thread must exit with 'pthread_barrier_wait'
	// in normal condition
	if (arguments->obj->barrier)
	{
		int rc = pthread_barrier_wait(arguments->obj->barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	free(args);
	args = NULL;

	return NULL;
}

// threads sync
void Sitelink::sync_threads(pthread_barrier_t *barrier)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc = pthread_barrier_wait(barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
		pthread_exit(NULL);
}

// 
// Name: sl_create
//
// Description: call relative thread function
//
// Input:
//   lidx - structure of links between pages
//   meta - structure of metadata
// 
// Output:
//   file containing link structure between sites is created
//   metadata of sites is updated to reflect internal and external links
//

void Sitelink::sl_create(Storage *lidx, Meta *meta)
{
	assert(dirname != NULL);
	assert(readonly == false);
	assert(lidx != NULL);
	assert(meta != NULL);

	int rc = 0;
	pthread_mutexattr_t attr;

	ndocs	= meta->doc_count();
	assert(ndocs > 0);
	nsites = meta->site_count();
	assert(nsites > 0);

	assert(SITELINK_MAX_OUTDEGREE < USHRT_MAX);

	nactive = CBALLOC(siteid_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	site_is_active = CBALLOC(bool *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	siteid	 = CBALLOC(siteid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	doc_is_ignored	 = CBALLOC(bool *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	adjacency_list_length = CBALLOC(unsigned short *, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	slocks = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));

	// Create the storage
	sidx = new Storage (COLLECTION_SITELINK, false);
	sidx->st_create();

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			slocks[i] = PTHREAD_MUTEX_INITIALIZER;

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Sitelink::thread_args_t *args = CBALLOC(Sitelink::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->lidx = lidx;
		args->meta = meta;
		args->url = NULL;
		args->f = SITELINK_CREATE;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_create((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			if ((rc = pthread_mutex_destroy(&slocks[i])) != 0)
				die("error destroying mutexes %s", CBoterr(rc));

		free(slocks); slocks = NULL;

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	// Close storage
	sidx->st_close();
	delete sidx;

	free(adjacency_list_length);
	free(doc_is_ignored);
	free(site_is_active);
	free(nactive);
	free(siteid);
}

// 
// Name: thread_function_create
//
// Description:
//   Generates a sitelink structure
//   - Read all the links from the page link structure
//   - Collapse links to inter-site links
//   - Write to disk
//
// Input: pointer to void
// 
// Output:
//   file containing link structure between sites is created
//   metadata of sites is updated to reflect internal and external links
//
void *Sitelink::thread_function_create(void *args)
{
	cpu_set_t system_cpus;

    Sitelink::thread_args_t *arguments = (Sitelink::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Sitelink *obj = arguments->obj;
    Storage *lidx = arguments->lidx;
    Meta *meta = arguments->meta;

	obj->adjacency_list_length[inst] = CBALLOC(unsigned short, MALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
	obj->distributed[inst].ndests = 0;
    obj->distributed[inst].dests = CBALLOC(out_link_t, CALLOC, (SITELINK_MAX_OUTDEGREE + 1));
	obj->distributed[inst].links = CBALLOC(sitelink_t *, MALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
	obj->distributed[inst].revlinks = NULL;
	obj->distributed[inst].internal_links = CBALLOC(docid_t, MALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
	obj->site_is_active[inst] = CBALLOC(bool, MALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	// Init vars of the sitelinkidx
	obj->nactive[inst] = 0;

	// Check which sites are site_is_active
	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		site_t site;
		site.siteid = siteid;

		// Load the site metadata
		siteid_t sitenum = site.siteid;
		meta->site_retrieve(&(site));
		assert(site.siteid == sitenum);

		off64_t offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		// Check if it has documents
		if (site.count_doc_ok > 0)
		{
			obj->site_is_active[inst][offset]	= true;
			obj->nactive[inst]++;
		}
		else
			obj->site_is_active[inst][offset]	= false;

		obj->distributed[inst].links[offset] = NULL;
		obj->distributed[inst].internal_links[offset] = 0;
	}

	sync_threads(obj->barrier);

	bool notany = true;

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (obj->nactive[i] > 0)
			notany = false;

	if (notany == true)
	{
		if (sp->go_ahead(inst) == true)
		{
			cerr << "** Warning! Couldn't found any site_is_active site." << endl;
			cerr << "Either 1) the crawler has not collected yet documents from any site -or- 2) you have not run the analysis program on site statistics" << endl;
		}

		// Free
		free(obj->adjacency_list_length[inst]);
		free(obj->distributed[inst].dests);

		for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
			free(obj->distributed[inst].links[((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)]);

		free(obj->distributed[inst].internal_links);
		free(obj->distributed[inst].links);
		free(obj->site_is_active[inst]);

		arguments->meta = NULL;

			return NULL;
	}

	// Read the siteids of docids
	ccerr << "Reading siteids    |--------------------------------------------------|" << endl << "                   ";

	sync_threads(obj->barrier);

	obj->siteid[inst] = CBALLOC(siteid_t, CALLOC, ((obj->ndocs + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
	obj->doc_is_ignored[inst] = CBALLOC(bool, MALLOC, ((obj->ndocs + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	// Go through the list of docs
	docid_t ndocs_div_50 = obj->ndocs / 50;

	doc_t doc;

	for (doc.docid = (inst + 1); doc.docid <= obj->ndocs; doc.docid += CONF_COLLECTION_DISTRIBUTED)
	{
		if (ndocs_div_50 > 0 && doc.docid % ndocs_div_50 == 0)
			cerr << ".";

		docid_t docnum = doc.docid;
		meta->doc_retrieve(&(doc));
		assert(doc.docid == docnum && doc.siteid > 0);

		off64_t offset = ((doc.docid - 1) / CONF_COLLECTION_DISTRIBUTED);

		// For each docid assign its source siteid (for fast searches)
		obj->siteid[inst][offset] = doc.siteid;

		// Mark ignored documents
		if (doc.status == STATUS_DOC_IGNORED)
			obj->doc_is_ignored[inst][offset] = true;
		else
			obj->doc_is_ignored[inst][offset] = false;
	}

	sync_threads(obj->barrier);

	// Start to read the page links
	ccerr << endl << "Reading links      |--------------------------------------------------|" << endl << "                   ";

	sync_threads(obj->barrier);

	linkidx_prepare_sequential_read(lidx, inst);

	// Iterate through all the source docid into storage of links in the instance
	// Because it is not possible known at prior what is the siteid_src or siteid_dst
	// there are not way to avoid use of mutex or atomic data (weight)
	for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
	{
		internal_long_uint_t expected = (docid / 10) * 10;
		internal_long_uint_t next = expected + 10;

		// Read the links and we retreive only the adiacency with destination docs relative to instance to avoid write collisions
		linkidx_sequential_read(lidx, inst, obj->distributed[inst].dests, &(obj->distributed[inst].ndests));

		// Show progress bar
		// if (sp->go_ahead(inst) == true && ndocs_div_50 > 0 && docid % ndocs_div_50 == 0)
		if (ndocs_div_50 > 0 && (docid % ndocs_div_50 == 0) && this->print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
			cerr << ".";
		
		// Skip ignored documents (this must be done AFTER reading their links!)
		if (obj->doc_is_ignored[((docid - 1) % CONF_COLLECTION_DISTRIBUTED)][((docid - 1) / CONF_COLLECTION_DISTRIBUTED)] == true)
			continue;

		siteid_t siteid_src	= obj->siteid[((docid - 1) % CONF_COLLECTION_DISTRIBUTED)][((docid - 1) / CONF_COLLECTION_DISTRIBUTED)];
		instance_t sis_inst = ((siteid_src - 1) % CONF_COLLECTION_DISTRIBUTED);
		off64_t sis_offset = ((siteid_src - 1) / CONF_COLLECTION_DISTRIBUTED);

		// Skip inactive sites. This must be done AFTER the links
		// are read, because the read is sequential.
		if (obj->site_is_active[sis_inst][sis_offset] == false)
			continue;

		out_link_t *dest = obj->distributed[inst].dests;

		unsigned short adjacency_list_length = 0;

		if (obj->distributed[inst].ndests > 0)
		{
			instance_t c = 0;
			instance_t b = inst;

			// Mark pointed pages as with more depth
			while (c < CONF_COLLECTION_DISTRIBUTED)
			{
				obj->lock(b, obj->slocks);

				// Check the destinations of this link
				for (unsigned int j = 0; j < obj->distributed[inst].ndests; j++)
				{
//				if (dest[j].dest > obj->ndocs)
//					continue;

					assert(dest[j].dest > 0 && dest[j].dest <= obj->ndocs);

					siteid_t siteid_dest = obj->siteid[((dest[j].dest - 1) % CONF_COLLECTION_DISTRIBUTED)][((dest[j].dest - 1) / CONF_COLLECTION_DISTRIBUTED)];

					assert(siteid_dest > 0 && siteid_dest <= obj->nsites);

					// Skip dest. sites that are inactive, with 0 pages gathered ok
					if (obj->site_is_active[((siteid_dest - 1) % CONF_COLLECTION_DISTRIBUTED)][((siteid_dest - 1) / CONF_COLLECTION_DISTRIBUTED)] == false)
						continue;

					// Skip links to ignored documents
					if (obj->doc_is_ignored[((dest[j].dest - 1) % CONF_COLLECTION_DISTRIBUTED)][((dest[j].dest - 1) / CONF_COLLECTION_DISTRIBUTED)] == true)
						continue;

					if (sis_inst == b)
					{
						// If the site is not the same add the link in linked list
						if (siteid_dest != siteid_src)
						{
							sitelink_t *ptr = obj->distributed[sis_inst].links[sis_offset];

							// Check if this link have been seen
							bool seen = false;

							while (ptr)
							{
								if (ptr->siteid == siteid_dest)
								{
									ptr->weight++;
									seen = true;
									break;
								}

								adjacency_list_length++;
								ptr = ptr->next;
							}
							// New node
							if (seen == false && adjacency_list_length < SITELINK_MAX_OUTDEGREE)
							{
								sitelink_t *newlink	= CBALLOC(sitelink_t, MALLOC, 1);
								newlink->siteid	= siteid_dest;
								newlink->weight	= 1;
								// Insert at the beginning of linked list
								newlink->next = obj->distributed[sis_inst].links[sis_offset];
								obj->distributed[sis_inst].links[sis_offset] = newlink;
							}
							else
								continue;
						}
						else
							obj->distributed[sis_inst].internal_links[sis_offset]++;
					}
				}

				obj->unlock(b, obj->slocks);

				c++;
				b = ((b + 1) % CONF_COLLECTION_DISTRIBUTED);
			}
		}
	}

	// linkidx_prepare_sequential_read(lidx, inst);

	/* Iterate through all the source docid into storage of links in the instance
	// Because it is not possible known at prior what is the siteid_src or siteid_dst
	// there are not way to avoid use of mutex or atomic data (weight)
	for (docid_t docid = 1; docid <= obj->ndocs; docid++)
	{
		// Read the links and we retreive only the adiacency with destination docs relative to instance to avoid write collisions
		linkidx_sequential_read(lidx, inst, obj->distributed[inst].dests[(docid % 2)], &(obj->distributed[inst].ndests[(docid % 2)]));

		sync_threads(obj->barrier);

		// Show progress bar
		if (sp->go_ahead(inst) == true && ndocs_div_50 > 0 && docid % ndocs_div_50 == 0)
			cerr << ".";
		
		// Skip ignored documents (this must be done AFTER reading their links!)
		if (obj->doc_is_ignored[((docid - 1) % CONF_COLLECTION_DISTRIBUTED)][((docid - 1) / CONF_COLLECTION_DISTRIBUTED)] == true)
			continue;

		siteid_t siteid_src	= obj->siteid[((docid - 1) % CONF_COLLECTION_DISTRIBUTED)][((docid - 1) / CONF_COLLECTION_DISTRIBUTED)];
		instance_t sis_inst = ((siteid_src - 1) % CONF_COLLECTION_DISTRIBUTED);
		off64_t sis_offset = ((siteid_src - 1) / CONF_COLLECTION_DISTRIBUTED);
		
		// Skip inactive sites. This must be done AFTER the links
		// are read, because the read is sequential.
		if (obj->site_is_active[sis_inst][sis_offset] == false)
			continue;

		unsigned short adjacency_list_length = 0;

		// Check for dests where relative siteid reminder is equal to instance, and add the link
		for (instance_t r = 0; r < CONF_COLLECTION_DISTRIBUTED; r++)
		{
			out_link_t *dest = obj->distributed[r].dests[(docid % 2)];

			for (unsigned int j = 0; j < obj->distributed[r].ndests[(docid % 2)]; j++)
			{
				assert(dest[j].dest > 0 && dest[j].dest <= obj->ndocs);

				siteid_t siteid_dest = obj->siteid[((dest[j].dest - 1) % CONF_COLLECTION_DISTRIBUTED)][((dest[j].dest - 1) / CONF_COLLECTION_DISTRIBUTED)];

				assert(siteid_dest > 0 && siteid_dest <= obj->nsites);

				// Skip if siteid_dest remainder is not equal to instance. NEEDED to work with (MS) algorithm
				if (((siteid_dest - 1) % CONF_COLLECTION_DISTRIBUTED) != inst)
					continue;

				// Skip dest. sites that are inactive, with 0 pages gathered ok
				if (obj->site_is_active[inst][((siteid_dest - 1) / CONF_COLLECTION_DISTRIBUTED)] == false)
					continue;

				// Skip links to ignored documents
				if (obj->doc_is_ignored[((dest[j].dest - 1) % CONF_COLLECTION_DISTRIBUTED)][((dest[j].dest - 1) / CONF_COLLECTION_DISTRIBUTED)] == true)
					continue;

				// If the site is not the same add the link in linked list
				if (siteid_dest != siteid_src)
				{
					sitelink_t *ptr = obj->distributed[sis_inst].links[sis_offset][inst];

					// Check if this link have been seen
					bool seen = false;

					while (ptr != NULL)
					{
						if (ptr->siteid == siteid_dest)
						{
							ptr->weight++;
							seen = true;
							break;
						}

						ptr = ptr->next;
					}
					// New node
					if (seen == false && adjacency_list_length < SITELINK_MAX_OUTDEGREE)
					{
						sitelink_t *newlink	= CBALLOC(sitelink_t, MALLOC, 1);
						newlink->siteid	= siteid_dest;
						newlink->weight	= 1;
						// Insert at the beginning of linked list
						newlink->next = obj->distributed[sis_inst].links[sis_offset][inst];
						obj->distributed[sis_inst].links[sis_offset][inst] = newlink;
						adjacency_list_length++;
					}
					else
						continue;
				}
				else
					obj->distributed[sis_inst].internal_links[sis_offset][inst]++;
			}
		}
	} */

	sync_threads(obj->barrier);

	// Report
	ccerr << endl << "Saving sitelinks   |--------------------------------------------------|" << endl << "                   ";

	sync_threads(obj->barrier);

	// Save link structure for instance
	obj->sl_save(inst);

	// Save number of internal links of the site
	site_t site;

	// TODO using buffer if possible
	for (site.siteid = (inst + 1); site.siteid <= obj->nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		siteid_t sitenum = site.siteid;
		meta->site_retrieve(&(site));
		assert(site.siteid == sitenum);

		site.internal_links = obj->distributed[inst].internal_links[((site.siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];

		meta->site_store(&(site));
	}

	sync_threads(obj->barrier);

	// Free
	free(obj->distributed[inst].internal_links);
	free(obj->site_is_active[inst]);
	free(obj->distributed[inst].dests);
	free(obj->adjacency_list_length[inst]);
	free(obj->siteid[inst]);
	free(obj->doc_is_ignored[inst]);
	arguments->lidx = NULL;
	arguments->meta = NULL;

	return NULL;
}

// 
// Name: sl_save
//
// Description:
//   Saves the sitelink structure for to disk
//
// Input:
//   inst - the instance where save adjacency_lists
//
void Sitelink::sl_save(instance_t &inst)
{
	assert(distributed[inst].links != NULL);

	// Adjacency list, for saving
	saved_sitelink_t adjacency_list[SITELINK_MAX_OUTDEGREE];

	site_t site;
	siteid_t nsites_div_50	= nsites / 50;

	for (site.siteid = (inst + 1); site.siteid <= nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		internal_long_uint_t expected = (site.siteid / 10) * 10;
		internal_long_uint_t next = expected + 10;

		// Report
		// if (sp->go_ahead(inst) == true && ndocs_div_50 > 0 && docid % ndocs_div_50 == 0)
		if (nsites_div_50 > 0 && (site.siteid % nsites_div_50 == 0) && this->print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
			cerr << ".";

		sitelink_t *ptr = distributed[inst].links[((site.siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];

		unsigned short adjacency_list_length = 0;

		// Copy adjacency list to structure, for saving
		while (ptr != NULL)
		{
			sitelink_t *old_ptr = ptr;

			// Copy data
			if (adjacency_list_length < (SITELINK_MAX_OUTDEGREE - 1))
			{
				adjacency_list[adjacency_list_length].siteid = ptr->siteid;
				adjacency_list[adjacency_list_length].weight = ptr->weight;
				adjacency_list_length++;
			}

			ptr = ptr->next; // Continue
			free(old_ptr); // free uneeded node
		}

		// Store adjancency list in the storage file
		if (adjacency_list_length > 0)
		{
			siteid_t pos = ((site.siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

			// pass a virtual_id (as docid) at storage because it work with docid_t type and,
			// must be major of 0 like valid docid
			docid_t virtual_id = (docid_t)(pos + 1);

			sidx->st_idx_write(inst, virtual_id, (char *)(adjacency_list), (adjacency_list_length * sizeof(saved_sitelink_t)));
		}
	}

	free(distributed[inst].links);
	distributed[inst].links	= NULL;
//	free(sitelinkidx);
}

// 
// Name: sl_load
//
// Description: call relative thread function
//
// Input:
//   lidx - Storage class for link index
//   meta - Meta class
// 
void Sitelink::sl_load(Storage *lidx, Meta *meta)
{
	assert(dirname != NULL);
	//assert(readonly == false);

	assert(lidx != NULL);
	assert(meta != NULL);

	int rc = 0;
	pthread_mutexattr_t attr;

	if (ndocs == 0)
	{
		ndocs	= meta->doc_count();
		assert(ndocs > 0);
	}


	if (nsites == 0)
	{
		nsites = meta->site_count();
		assert(nsites > 0);
	}

	assert(SITELINK_MAX_OUTDEGREE < USHRT_MAX);

	// Open the storage in read only mode
	sidx = new Storage (COLLECTION_SITELINK, true);
	sidx->st_open();

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Sitelink::thread_args_t *args = CBALLOC(Sitelink::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->meta = NULL;
		args->url = NULL;
		args->f = SITELINK_LOAD;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_load((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	// Close storage
	sidx->st_close();
	delete sidx;
}

//
// 
// Name: thread_function_load
//
// Description:
//   Read the sitelink structure from disk
//
// Input: pointer to void
//
// Return:
//   structure of links between sites
//
void *Sitelink::thread_function_load(void *args)
{
	cpu_set_t system_cpus;

    Sitelink::thread_args_t *arguments = (Sitelink::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Sitelink *obj = arguments->obj;

	// Sequential read is to speed up the process of reading
	storage_record_t rec;
	storage_status_t rc;
	unsigned int ndest = 0;
	saved_sitelink_t adjacency_list[SITELINK_MAX_OUTDEGREE];

	obj->distributed[inst].links = CBALLOC(sitelink_t *, MALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
	obj->distributed[inst].revlinks = NULL;
	obj->distributed[inst].count_site = obj->nsites;

	// Blank the position in the sitelink list 
	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
		obj->distributed[inst].links[((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)] = NULL;

	sync_threads(obj->barrier);

	obj->sidx->prepare_sequential_read(inst);

	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		off64_t offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		// Do sequential read
		rc = obj->sidx->sequential_read(inst, &(rec), (char *)(adjacency_list));

		// Check if something was read
		if (rc == STORAGE_OK && rec.size > 0)
		{
			ndest	= rec.size/sizeof(saved_sitelink_t);

			// Add to the adjacency 
			for (siteid_t i = 0; i < ndest; i++)
			{
				sitelink_t *item	= CBALLOC(sitelink_t, MALLOC, 1);
				item->siteid		= adjacency_list[i].siteid;
				item->weight		= adjacency_list[i].weight;
				item->next			= obj->distributed[inst].links[offset];
				obj->distributed[inst].links[offset] = item;
			}

			// obj->adjacency_list_length[inst][offset] = ndest; TODO testing
		}
	}

	return NULL;
}

// 
// Name: sl_unload
//
// Description: call relative thread function
//
// Input:
// 
// Output:
//
void Sitelink::sl_unload(void)
{
	assert(dirname != NULL);
	//assert(readonly == false);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Sitelink::thread_args_t *args = CBALLOC(Sitelink::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->meta = NULL;
		args->url = NULL;
		args->f = SITELINK_UNLOAD;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_unload((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;
	}
}

// 
// Name: thread_function_unload
//
// Description:
//   Dealloc linked list
//
// Input: pointer to void
//
void *Sitelink::thread_function_unload(void *args)
{
	cpu_set_t system_cpus;

    Sitelink::thread_args_t *arguments = (Sitelink::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Sitelink *obj = arguments->obj;

	assert(obj->distributed[inst].links || obj->distributed[inst].revlinks);

	sync_threads(obj->barrier);

	// free all linked list siteid by siteid
	if (obj->distributed[inst].links)
		for (siteid_t i = 0; i < ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED); i++)
		{
			if ((i * CONF_COLLECTION_DISTRIBUTED + (inst + 1))  > obj->nsites)
				continue;

			sitelink_t *ptr = obj->distributed[inst].links[i];

			while (ptr != NULL)
			{
				sitelink_t *old_ptr = ptr;
				ptr = ptr->next; // Continue
				free(old_ptr);
			}
		}

	if (obj->distributed[inst].revlinks)
		for (siteid_t i = 0; i < ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED); i++)
		{
			if ((i * CONF_COLLECTION_DISTRIBUTED + (inst + 1))  > obj->nsites)
				continue;

			sitelink_t *ptr = obj->distributed[inst].revlinks[i];

			while (ptr != NULL)
			{
				sitelink_t *old_ptr = ptr;
				ptr = ptr->next; // Continue
				free(old_ptr);
			}
		}

	free(obj->distributed[inst].links);

	return NULL;
}

// 
// Name: sitelink_dump_structure
//
// Description:
//   Shows the site structure to screen
//
// Input:
//   sitelinkidx - the structure
//
void Sitelink::dump_structure(void)
{
	assert(readonly == true);

	for (siteid_t siteid = 1; siteid <= nsites; siteid++)
		dump_links(siteid);

	sl_unload();
}

// 
// Name: sitelink_dump_structure
//
// Description:
//   Shows the site structure to screen
//
// Input:
//   sitelinkidx - the structure
//

void Sitelink::dump_revstructure(void)
{
	assert(readonly == true);

	for (siteid_t siteid = 1; siteid <= nsites; siteid++)
		dump_revlinks(siteid);

//	sl_unload();
}

//
// Name: dump_links
//
// Description:
//   Shows all the links from a sites
//
// Input:
//   siteid - siteid to inspect
//
void Sitelink::dump_links(siteid_t &siteid)
{
	assert(siteid > 0);

	cerr << siteid;

	instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	off64_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);
	assert(distributed[s_inst].links != NULL);
	sitelink_t *ptr = distributed[s_inst].links[s_offset];

	// Show out_degree list
	while (ptr != NULL)
	{
		cerr << ' ' << ptr->siteid << '(' << ptr->weight << ')';
		ptr = ptr->next;
	}

	cerr << endl;
}

//
// Name: dump_revlinks
//
// Description:
//   Shows all the links from a sites
//
// Input:
//   siteid - siteid to inspect
//
void Sitelink::dump_revlinks(siteid_t &siteid)
{
	assert(siteid > 0);

	cerr << siteid;

	instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	off64_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);
	assert(distributed[s_inst].revlinks != NULL);
	sitelink_t *ptr = distributed[s_inst].revlinks[s_offset];

	// Show in_degree list
	while (ptr != NULL)
	{
		cerr << ' ' << ptr->siteid << '(' << ptr->weight << ')';
		ptr = ptr->next;
	}

	cerr << endl;
}

//
// Name: dump_links_with_sitename
//
// Description:
//   Shows all the links from a sites
//   includes names of the dest. sites
//
// Input:
//   urlddx - index of urls
//   siteid - siteid to inspect
//
void Sitelink::dump_links_from_sitename_to_others(Url *url, siteid_t siteid)
{
	assert(readonly == true);
	assert(url != NULL);
	assert(siteid > 0);

	char sitename[MAX_STR_LEN]	= "";

	cout << siteid << endl;
	unsigned int nlinks_in_site	= 0;

	// Iterate through the linked list
	siteid_t sum_weight	= 0;

	instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	off64_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);
	assert(distributed[s_inst].links != NULL);
	sitelink_t *ptr = distributed[s_inst].links[s_offset];

	while (ptr != NULL)
	{
		url->site_by_siteid(ptr->siteid, sitename);
		cout << ptr->siteid << '(' << ptr->weight << ") ";
		cout << sitename << endl;
		sum_weight += ptr->weight;
		ptr = ptr->next;
		nlinks_in_site++;
	}

	sl_unload();

	// Report number of links
	if (nlinks_in_site == 0)
		cout << "No links" << endl;
	else
		cout << "Total: " << sum_weight <<  " links to " << nlinks_in_site << " sites" << endl;
}

// 
// Name: dump_links_from_sitenames_to_sitename
//
// Description:
//
// Input:
// 
// Output:
//
void Sitelink::dump_links_from_sitenames_to_sitename(Url *url, siteid_t siteid)
{
	assert(dirname != NULL);
	assert(readonly == true);

	int rc = 0;
	pthread_mutexattr_t attr;

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

		if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Sitelink::thread_args_t *args = CBALLOC(Sitelink::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->meta = NULL;
		args->url = url;
		args->f = SITELINK_DLFSTS;
		args->siteid = siteid;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_dump_links_from_sitenames_to_sitename((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}
}

// 
// Name: dump_links_from_sitenames_to_sitename
//
// Description:
//   Dealloc linked list
//
// Input:
//   metaddx - structure of metadata
//
// Return:
//   structure of links between sites
//
void *Sitelink::thread_function_dump_links_from_sitenames_to_sitename(void *args)
{
	cpu_set_t system_cpus;

    Sitelink::thread_args_t *arguments = (Sitelink::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Sitelink *obj = arguments->obj;
	Url *url = arguments->url;
	siteid_t siteid_dst = arguments->siteid;

    
	assert(obj->distributed[inst].links != NULL);

	char sitename[MAX_STR_LEN]	= "";

	sync_threads(obj->barrier);

	// iterate all linked list siteid by siteid
	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
		off64_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		sitelink_t *ptr = obj->distributed[s_inst].links[s_offset];

		while (ptr != NULL)
		{
			if (ptr->siteid == siteid_dst)
			{
				url->site_by_siteid(siteid, sitename);
				mcerr << siteid << ' ' << siteid << '(' << ptr->weight << ") " << sitename << mendl;
			}

			ptr = ptr->next;
		}
	}

	sync_threads(obj->barrier);

	// free all linked list siteid by siteid
	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		sitelink_t *ptr = obj->distributed[((siteid - 1) % CONF_COLLECTION_DISTRIBUTED)].links[((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];

		while (ptr != NULL)
		{
			sitelink_t *old_ptr = ptr;
			ptr = ptr->next; // Continue
			free(old_ptr);
		}
	}

	sync_threads(obj->barrier);

	free(obj->distributed[inst].links);

	return NULL;
}

//
// Name: reverse_structure
//
// Description:
//   Reverses an adjacency list
//
// Input: instance
//
// Returns:
//   reversed adjacency list
//
void Sitelink::reverse_structure(instance_t &inst)
{
	assert(inst < CONF_COLLECTION_DISTRIBUTED);
/*
	// Allocate memory
	distributed[inst].revlinks = CBALLOC(sitelink_t *, MALLOC, ((nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	// Blank the position in the sitelink list 
	for (siteid_t siteid = (inst + 1); siteid <= nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
		distributed[inst].revlinks[((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)] = NULL;

	if (sync_threads(barrier) == false)
*/
	// This reverses the adjacency list
	// the new list cannot be saved to disk: it may have more than
	// the maximum number of outgoing links

	for (siteid_t siteid = 1; siteid <= nsites; siteid++)
	{
		sitelink_t *ptr = distributed[((siteid - 1) % CONF_COLLECTION_DISTRIBUTED)].links[((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];

		while (ptr)
		{
			instance_t s_inst = ((ptr->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t s_offset = ((ptr->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

			if (s_inst == inst)
			{
				Sitelink::sitelink_t *newlink	= CBALLOC(Sitelink::sitelink_t, MALLOC, 1);
				newlink->siteid	= siteid;
				newlink->next	= distributed[s_inst].revlinks[s_offset];
				distributed[s_inst].revlinks[s_offset] = newlink;
			}
			
			ptr 	= ptr->next;
		}
	}
}


//
// Strongly connected components calculations
//

//
// Name: dfs_decreasing
//
// Description: On revlinks, following the scc_vec_order numerate each graph and saving on scc_vec_component as 'root of tree'.
//
// input:
//	v - the siteid indicated from 'scc_vec_order'
//	root - the candidate root of the tree
//
void SCC::dfs_decreasing(const siteid_t v, const siteid_t root)
{
	bool complete = true;

	size_t size[2] = {1, 0};
	siteid_t *list[2] = {NULL, NULL};
	unsigned long long int it_count = 0;

	if (scc_vec_challenge<siteid_t, const siteid_t, atomic<siteid_t>> (v, root, scc_vec_component) == true)
	{
		list[(it_count % 2)] = (siteid_t *) calloc (size[(it_count % 2)], sizeof(siteid_t));
		list[(it_count % 2)][0] = v;

		// begin iteration
		do
		{
			complete = true;

			// get next size
			for (siteid_t i = 0; i < size[(it_count % 2)]; i++)
			{
				siteid_t s = list[(it_count % 2)][i];

				assert(s <= sl->nsites);

				if (s == 0)
					continue;

				instance_t s_inst = ((s - 1) % CONF_COLLECTION_DISTRIBUTED);
				siteid_t s_offset = ((s - 1) / CONF_COLLECTION_DISTRIBUTED);

				if (root == scc_vec_component[s_inst][s_offset])
				{
					Sitelink::sitelink_t *ptr	= sl->distributed[s_inst].revlinks[s_offset];

					while (ptr)
					{
						instance_t s_inst = ((ptr->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
						siteid_t s_offset = ((ptr->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

						if (root < scc_vec_component[s_inst][s_offset])
							size[((it_count + 1) % 2)]++;

						ptr = ptr->next;
					}
				}
			}

			assert(list[((it_count + 1) % 2)] == NULL);

			list[((it_count + 1) % 2)] = (siteid_t *) calloc (size[((it_count + 1) % 2)], sizeof(siteid_t));

			for (siteid_t i = 0; i < size[(it_count % 2)]; i++)
			{
				siteid_t s = list[(it_count % 2)][i];

				assert(s <= sl->nsites);

				if (s == 0)
					continue;

				instance_t s_inst = ((s - 1) % CONF_COLLECTION_DISTRIBUTED);
				siteid_t s_offset = ((s - 1) / CONF_COLLECTION_DISTRIBUTED);

				if (root == scc_vec_component[s_inst][s_offset])
				{
					Sitelink::sitelink_t *ptr	= sl->distributed[s_inst].revlinks[s_offset];

					while (ptr)
					{
						if (scc_vec_challenge<siteid_t, const siteid_t, atomic<siteid_t>> (ptr->siteid, root, scc_vec_component) == true)
						{
							size_t c = 0;
							bool found = false;

							while (list[((it_count + 1) % 2)][c] > 0)
							{
								if (ptr->siteid == list[((it_count + 1) % 2)][c])
								{
									found = true;
									break;
								}

								c++;
							}

							if (found == true)
							{
								ptr = ptr->next;
								continue;
							}

							assert(c < size[((it_count + 1) % 2)]);

							list[((it_count + 1) % 2)][c] = ptr->siteid;

							complete = false;
						}

						ptr = ptr->next;
					}
				}
			}

			size[(it_count % 2)] = 0;

			free(list[(it_count % 2)]); list[(it_count % 2)] = NULL;

			it_count++;
		}
		while (complete == false);

		free(list[(it_count % 2)]); list[(it_count % 2)] = NULL;
	}
}

//
// Name: mark_reachable
//
// Description:
//   Marks all the sites that are reachable from a site in the graph of site links.
//   It receives an old_component_name, new_component_name and
//   mark vertices in the graph, only of those that match the old_component_name
//
// Input:
//   siteid - the source vertex
//   old_component_name - the component name that must match
//   new_component_name - the component name to assign to reachable vertices
//   iterative - if true, mark iterativatly (iteration only in marked nodes!)
//
// Output:
//   components - contains marked elements with the new component name
//
void SCC::mark_reachable(siteid_t v, component_t old_component_name, component_t new_component_name, bool iterative)
{
	assert( v >= 1 );
	assert( v <= sl->nsites );

	component_t new_component = new_component_name;

	if (iterative == false)
	{
		Sitelink::sitelink_t *ptr	= sl->distributed[((v - 1) % CONF_COLLECTION_DISTRIBUTED)].links[((v - 1) / CONF_COLLECTION_DISTRIBUTED)];

		while (ptr)
		{
			component_t cache = old_component_name;

			instance_t s_inst = ((ptr->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t s_offset = ((ptr->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

			component[s_inst][s_offset].compare_exchange_strong(cache, new_component);

			ptr = ptr->next;
		}

		return;
	}

	bool complete = true;

	size_t size[2] = {1, 0};
	siteid_t *list[2] = {NULL, NULL};
	unsigned long long int it_count = 0;

	list[(it_count % 2)] = (siteid_t *) calloc (size[(it_count % 2)], sizeof(siteid_t));
	list[(it_count % 2)][0] = v;

	// begin iteration
	do
	{
		complete = true;

		// get next size
		for (siteid_t i = 0; i < size[(it_count % 2)]; i++)
		{
			siteid_t s = list[(it_count % 2)][i];

			if (s == 0)
				break;

			instance_t s_inst = ((s - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t s_offset = ((s - 1) / CONF_COLLECTION_DISTRIBUTED);

			if (sl->adjacency_list_length)
				size[((it_count + 1) % 2)] += sl->adjacency_list_length[s_inst][s_offset];
			else
			{
				Sitelink::sitelink_t *ptr	= sl->distributed[s_inst].links[s_offset];

				while (ptr)
				{
					instance_t s_inst = ((ptr->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
					siteid_t s_offset = ((ptr->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

					if (old_component_name == component[s_inst][s_offset])
						size[((it_count + 1) % 2)]++;

					ptr = ptr->next;
				}
			}
		}

		assert(list[((it_count + 1) % 2)] == NULL);

		list[((it_count + 1) % 2)] = (siteid_t *) calloc (size[((it_count + 1) % 2)], sizeof(siteid_t));

		for (siteid_t i = 0; i < size[(it_count % 2)]; i++)
		{
			siteid_t s = list[(it_count % 2)][i];

			if (s == 0)
				break;

			instance_t s_inst = ((s - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t s_offset = ((s - 1) / CONF_COLLECTION_DISTRIBUTED);

			Sitelink::sitelink_t *ptr	= sl->distributed[s_inst].links[s_offset];

			while (ptr)
			{
				component_t cache = old_component_name;

				instance_t s_inst = ((ptr->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
				siteid_t s_offset = ((ptr->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

				if (component[s_inst][s_offset].compare_exchange_strong(cache, new_component) == true)
				{
					size_t c = 0;
					bool visited = false;

					while (list[((it_count + 1) % 2)][c] > 0)
					{
						if (ptr->siteid == list[((it_count + 1) % 2)][c])
						{
							visited = true;
							break;
						}

						c++;
					}

					if (visited == true)
					{
						ptr = ptr->next;
						continue;
					}

					assert(c < size[((it_count + 1) % 2)]);

					list[((it_count + 1) % 2)][c] = ptr->siteid;

					complete = false;
				}

				ptr = ptr->next;
			}
		}

		size[(it_count % 2)] = 0;

		free(list[(it_count % 2)]); list[(it_count % 2)] = NULL;

		it_count++;
	}
	while (complete == false);

	free(list[(it_count % 2)]); list[(it_count % 2)] = NULL;
}

//
// Name: mark_reachable_rev
//
// Description:
//   Marks all the sites that are reachable from a site in the graph of reverse site links.
//   It receives an old_component_name, new_component_name and
//   mark vertices in the graph, only of those that match the old_component_name
//
// Input:
//   siteid - the source vertex
//   old_component_name - the component name that must match
//   new_component_name - the component name to assign to reachable vertices
//   iterative - if true, mark iterativatly (iteration only in marked nodes!)
//
// Output:
//   components - contains marked elements with the new component name
//
void SCC::mark_reachable_rev(siteid_t v, component_t old_component_name, component_t new_component_name, bool iterative)
{
	assert( v >= 1 );
	assert( v <= sl->nsites );

	component_t new_component = new_component_name;

	if (iterative == false)
	{
		Sitelink::sitelink_t *ptr	= sl->distributed[((v - 1) % CONF_COLLECTION_DISTRIBUTED)].revlinks[((v - 1) / CONF_COLLECTION_DISTRIBUTED)];

		while (ptr)
		{
			component_t cache = old_component_name;

			instance_t s_inst = ((ptr->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t s_offset = ((ptr->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

			component[s_inst][s_offset].compare_exchange_strong(cache, new_component);

			ptr = ptr->next;
		}

		return;
	}

	bool complete = true;

	size_t size[2] = {1, 0};
	siteid_t *list[2] = {NULL, NULL};
	unsigned long long int it_count = 0;

	list[(it_count % 2)] = (siteid_t *) calloc (size[(it_count % 2)], sizeof(siteid_t));
	list[(it_count % 2)][0] = v;

	// begin iteration
	do
	{
		complete = true;

		// get next size
		for (siteid_t i = 0; i < size[(it_count % 2)]; i++)
		{
			siteid_t s = list[(it_count % 2)][i];

			if (s == 0)
				break;

			instance_t s_inst = ((s - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t s_offset = ((s - 1) / CONF_COLLECTION_DISTRIBUTED);

			Sitelink::sitelink_t *ptr	= sl->distributed[s_inst].revlinks[s_offset];

			while (ptr)
			{
				instance_t s_inst = ((ptr->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
				siteid_t s_offset = ((ptr->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

				if (old_component_name == component[s_inst][s_offset])
					size[((it_count + 1) % 2)]++;

				ptr = ptr->next;
			}
		}

		assert(list[((it_count + 1) % 2)] == NULL);

		list[((it_count + 1) % 2)] = (siteid_t *) calloc (size[((it_count + 1) % 2)], sizeof(siteid_t));

		for (siteid_t i = 0; i < size[(it_count % 2)]; i++)
		{
			siteid_t s = list[(it_count % 2)][i];

			if (s == 0)
				break;

			instance_t s_inst = ((s - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t s_offset = ((s - 1) / CONF_COLLECTION_DISTRIBUTED);

			Sitelink::sitelink_t *ptr	= sl->distributed[s_inst].revlinks[s_offset];

			while (ptr)
			{
				component_t cache = old_component_name;

				instance_t s_inst = ((ptr->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
				siteid_t s_offset = ((ptr->siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

				if (component[s_inst][s_offset].compare_exchange_strong(cache, new_component) == true)
				{
					size_t c = 0;
					bool visited = false;

					while (list[((it_count + 1) % 2)][c] > 0)
					{
						if (ptr->siteid == list[((it_count + 1) % 2)][c])
						{
							visited = true;
							break;
						}

						c++;
					}

					if (visited == true)
					{
						ptr = ptr->next;
						continue;
					}

					assert(c < size[((it_count + 1) % 2)]);

					list[((it_count + 1) % 2)][c] = ptr->siteid;

					complete = false;
				}

				ptr = ptr->next;
			}
		}

		size[(it_count % 2)] = 0;

		free(list[(it_count % 2)]); list[(it_count % 2)] = NULL;

		it_count++;
	}
	while (complete == false);

	free(list[(it_count % 2)]); list[(it_count % 2)] = NULL;
}

//
// Name: dfs_set_id
//
// Description: On links, numerate each graph and saving on 'scc_vec_id' as 'root of tree'.
//	Consente di assegnare iterativamente e non ricorsivamente, un identificativo univoco ad ogni gruppo di nodi collegati tra loro es:
//	2 20
//	5 19 20 6
//	6 3 17 16
//	8 1 11
//	9 16 8 14
//	11 14 17 12 2
//	13 19 10
//	16 10 8 7 19 17
//	^
//	|__(main nodes)
//
//	si otterrebbe la seguente assegnazione numerica:
//	1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 (offset)
//	1  2  3  4  5  5  5  5  9  5  5  5 13  5 15  5  5 18  5  2 (id)
//	Ogni thread esegue le iterazioni indipendentemente dagli altri.
//
// input:
//	v - il siteid che sarà assegnato come identificativo
//
void SCC::dfs_set_id(const siteid_t v)
{
	bool complete = true;

	size_t size[2] = {1, 0};
	siteid_t *list[2] = {NULL, NULL};
	unsigned long long int it_count = 0;

	if (scc_vec_challenge<siteid_t, const siteid_t, atomic<siteid_t>> (v, v, scc_vec_id) == true)
	{
		list[(it_count % 2)] = (siteid_t *) calloc (size[(it_count % 2)], sizeof(siteid_t));
		list[(it_count % 2)][0] = v;

		// begin iteration
		do
		{
			complete = true;

			// get next size
			for (siteid_t i = 0; i < size[(it_count % 2)]; i++)
			{
				siteid_t s = list[(it_count % 2)][i];

				if (s == 0)
					break;

				instance_t s_inst = ((s - 1) % CONF_COLLECTION_DISTRIBUTED);
				siteid_t s_offset = ((s - 1) / CONF_COLLECTION_DISTRIBUTED);

				if (v == scc_vec_id[s_inst][s_offset])
				{	// la soluzione di calcolare in anticipo le dimensioni di ogni linked list
					// potrebbe essere utile in caso di collisioni (e riletture) con un alto numero di processori
					// altrimenti potrebbe bastare la soluzione commentata appena sotto che permette di
					// occupare meno memoria evitando l'utilizzo l'array 'sl->adjacency_list_length'.
					// In ogni caso se non si dimostra l'efficacia di 'sl->adjacency_list_length' meglio escluderlo...
					size[((it_count + 1) % 2)] += sl->adjacency_list_length[s_inst][s_offset];
/*
					sitelink_t *ptr	= sitelinks[s_inst][s_offset];

					while (ptr)
					{
						size[((it_count + 1) % 2)]++;

						ptr = ptr->next;
					} */
				}
			}

			assert(list[((it_count + 1) % 2)] == NULL);

			list[((it_count + 1) % 2)] = (siteid_t *) calloc (size[((it_count + 1) % 2)], sizeof(siteid_t));

			for (siteid_t i = 0; i < size[(it_count % 2)]; i++)
			{
				siteid_t s = list[(it_count % 2)][i];

				if (s == 0)
					break;

				instance_t s_inst = ((s - 1) % CONF_COLLECTION_DISTRIBUTED);
				siteid_t s_offset = ((s - 1) / CONF_COLLECTION_DISTRIBUTED);

				if (v == scc_vec_id[s_inst][s_offset])
				{
					Sitelink::sitelink_t *ptr	= sl->distributed[s_inst].links[s_offset];

					while (ptr)
					{
						if (scc_vec_challenge<siteid_t, const siteid_t, atomic<siteid_t>> (ptr->siteid, v, scc_vec_id) == true)
						{
							size_t c = 0;
							bool visited = false;

							while (list[((it_count + 1) % 2)][c] > 0)
							{
								if (ptr->siteid == list[((it_count + 1) % 2)][c])
								{
									visited = true;
									break;
								}

								c++;
							}

							if (visited == true)
							{
								ptr = ptr->next;
								continue;
							}

							assert(c < size[((it_count + 1) % 2)]);

							list[((it_count + 1) % 2)][c] = ptr->siteid;

							complete = false;
						}

						ptr = ptr->next;
					}
				}
			}

			size[(it_count % 2)] = 0;

			free(list[(it_count % 2)]); list[(it_count % 2)] = NULL;

			it_count++;

			assert(it_count < (internal_long_uint_t)~0);
		}
		while (complete == false);

		free(list[(it_count % 2)]); list[(it_count % 2)] = NULL;
	}
}

//
// Name: dfs_compute_relative_finish
//
// Description: On links, assign a relative counter of node for each graph.
//	Emulando la ricorsione consente numerare iterativamente (relativamente al proprio identificativo) ogni nodo visitato, esempio:
//	2 20
//	5 19 20 6
//	6 3 17 16
//	8 1 11
//	9 16 8 14
//	11 14 17 12 2
//	13 19 10
//	16 10 8 7 19 17
//	^
//	|__(main nodes)
//
//	si otterrebbe la seguente assegnazione numerica:
//	1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 (offset)
//	1  2  3  4  5  5  5  5  9  5  5  5 13  5 15  5  5 18  5  2 (id)
//	1  3  4  5 16 15 13 12 17  8 11 10 18  9 19 14  7 20  6  2 (numerazione assoluta ottenuta con il metodo ricorsivo)
//	1  2  1  1 11 10  8  7  1  3  6  5  1  4  1  9  2  1  1  1 (numerazione relativa ottenuta con il metodo iterativo)
//
// Input:
//

void SCC::dfs_compute_relative_finish(const siteid_t v)
{
	assert( v >= 1 );
	assert( v <= sl->nsites );

	siteid_t _nsites = sl->nsites; // declaration needed for some defines

	instance_t v_inst = ((v - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t v_offset = ((v - 1) / CONF_COLLECTION_DISTRIBUTED);

	assert(scc_vec_relative_finish[v_inst][v_offset] > 0);

	const Sitelink::sitelink_t *_ptr = sl->distributed[v_inst].links[v_offset];
	Sitelink::sitelink_t *ptr = sl->distributed[v_inst].links[v_offset];

	siteid_t scc_relative_finish_time = 0;

	if (scc_vec_relative_finish[v_inst][v_offset] == 1 || ptr == NULL)
		return;

	siteid_t calling_id = v;
	siteid_t vsize = (scc_vec_relative_finish[v_inst][v_offset] - 1);

	siteid_t *visited_list = (siteid_t *) calloc (vsize, sizeof(siteid_t));
	assert(visited_list != NULL);

	// Iterating...
	while (_ptr)
	{	// Clear array of visited nodes
		for (siteid_t c = 0; c < vsize; c++)
		{
			if (visited_list[c] == 0)
				break;

			siteid_t o = visited_list[c];

			instance_t o_inst = ((o - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t o_offset = ((o - 1) / CONF_COLLECTION_DISTRIBUTED);

			if (scc_vec_relative_finish[o_inst][o_offset] == VISITED)
				scc_vec_relative_finish[o_inst][o_offset] = 0;

			visited_list[c] = 0;
		}

		siteid_t w = v;

		ptr = (Sitelink::sitelink_t *)_ptr;

		while (ptr)
		{
			calling_id = w;

			w	= ptr->siteid;

			instance_t w_inst = ((w - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t w_offset = ((w - 1) / CONF_COLLECTION_DISTRIBUTED);

			if (v == scc_vec_id[w_inst][w_offset].ALMOR)
			{
				if (w != v && w != calling_id && scc_vec_relative_finish[w_inst][w_offset] == 0)
				{
					if (sl->distributed[w_inst].links[w_offset] == NULL)
					{
						// Mark relative finish time
   						scc_vec_relative_finish[w_inst][w_offset] = ++scc_relative_finish_time;
						ptr = sl->distributed[((calling_id - 1) % CONF_COLLECTION_DISTRIBUTED)].links[((calling_id - 1) / CONF_COLLECTION_DISTRIBUTED)]->next;
						w = calling_id;
					}
					else if (scc_vec_relative_finish[w_inst][w_offset] == 0)
					{
						scc_vec_relative_finish[w_inst][w_offset] = VISITED;

						siteid_t c = 0;

						while (visited_list[c] > 0)
							c++;

						assert(c < vsize);

						visited_list[c] = w;

						ptr = sl->distributed[w_inst].links[w_offset];
					}
					else
					{
						ptr = ptr->next;
						w = calling_id;
					}
				}
				else
				{
					ptr = ptr->next;
					w = calling_id;
				}
			}
			else
			{
				ptr = ptr->next;
				w = calling_id;
			}
    	}

		if (ptr == NULL)
		{
			instance_t o_inst = ((calling_id - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t o_offset = ((calling_id - 1) / CONF_COLLECTION_DISTRIBUTED);

			// Mark relative finish time
			if (calling_id == v)
			{
				assert(scc_vec_relative_finish[o_inst][o_offset] == (scc_relative_finish_time + 1));
			
				break;
			}
			else
   				scc_vec_relative_finish[o_inst][o_offset] = ++scc_relative_finish_time;
		}
	}

	free(visited_list);
}

//
// Name: thread_function_caller
//
// Description:
//   A proxy function to pass non-static function at pthread_create
//   Note: function called by thread_function_caller need to have real class object passed through args
//
// Input:
//   args - void arguments
//
// Return:
//   pointer to void
//
void* SCC::thread_function_caller(void *args)
{
	if (args == NULL)
		return NULL;

	SCC::thread_args_t *arguments = (SCC::thread_args_t *)args;

	SCC *newObj = new SCC (NULL); // Note function called work to 'this' temporary object and need to be deleted at the end of the same.

	switch (arguments->f)
	{
		case SITELINK_ANALYSIS_COMPONENTS:
			newObj->thread_function_analysis_components(args);
			break;
		default:
			return NULL;
	}

	delete newObj;

	return NULL;
}

//
// Name: analysis_components
//
// Description:
//   Generates the list of strongly connected components
//   Calculates the component for each site
//
// Input:
//   nsites - the number of sites
//   sitelink - the structure with the links
//
void SCC::analysis_components(Meta *meta, bool &opt_sitelinks_siterank)
{

	assert(sl != NULL);
	assert(sl->dirname != NULL);
//	assert(readonly == false);
	assert(meta != NULL);

	//srand(50); // debug

	int rc = 0;
	pthread_mutexattr_t attr;

	assert(sl->ndocs > 0);
	assert(sl->nsites > 0);

	assert(SITELINK_MAX_OUTDEGREE < USHRT_MAX);
	sl->nactive = CBALLOC(siteid_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	sl->site_is_active = CBALLOC(bool *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	sl->adjacency_list_length = CBALLOC(unsigned short *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	scc_vec_id = CBALLOC(atomic<siteid_t> *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	scc_vec_relative_finish = CBALLOC(atomic<siteid_t> *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	scc_vec_order = CBALLOC(siteid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	scc_base_count = CBALLOC(siteid_t *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	scc_vec_component = CBALLOC(atomic<siteid_t> *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	scc_size = CBALLOC(atomic<siteid_t> *, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	component = CBALLOC(atomic<component_t> *, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	// The connected components were calculated, locate the largest
	scc_giant_component = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	scc_giant_component_size = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	scc_singletons = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	scc_no_outlinks = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	scc_no_inlinks = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	nsites_not_undef = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	count_component = CBALLOC(siteid_t *, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	// scc_size_histogram = CBALLOC(map<siteid_t, siteid_t>, NEW, CONF_COLLECTION_DISTRIBUTED);
	scc_size_histogram = new map<siteid_t, siteid_t> [CONF_COLLECTION_DISTRIBUTED];
    assert(scc_size_histogram != NULL);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		sl->barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(sl->barrier, NULL, CONF_COLLECTION_DISTRIBUTED);
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		SCC::thread_args_t *args = CBALLOC(SCC::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->lidx = NULL;
		args->meta = meta;
		args->opt_sitelinks_siterank = opt_sitelinks_siterank;
		args->f = SITELINK_ANALYSIS_COMPONENTS;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, SCC::thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_analysis_components((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(sl->slocks); sl->slocks = NULL;

		free(threads);

		pthread_barrier_destroy(sl->barrier);

		free(sl->barrier); sl->barrier = NULL;
	}

	free(sl->adjacency_list_length);
	free(sl->site_is_active);
	free(sl->nactive);
    free(scc_vec_id);
    free(scc_vec_relative_finish);
    free(scc_vec_order);
    free(scc_base_count);
    free(scc_vec_component);
    free(scc_size);
    free(scc_giant_component);
    free(scc_giant_component_size);
    free(scc_singletons);
    free(scc_no_outlinks);
    free(scc_no_inlinks);
    free(nsites_not_undef);
    free(count_component);
    delete [] scc_size_histogram;
    free(component);

	// Close
//	if (opt_sitelinks_siterank == false)
//		delete [] sl->distributed;
}

//
// Name: thread_function_analysis_components
//
// Description:  
//	Richiamando due funzioni multithread riesce ad assegnare il time finish assoluto, esempio:
//	2 20
//	5 19 20 6
//	6 3 17 16
//	8 1 11
//	9 16 8 14
//	11 14 17 12 2
//	13 19 10
//	16 10 8 7 19 17
//	^
//	|__(main nodes)
//
//	si otterrebbe la seguente assegnazione numerica:
//	1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 (offset)
//	1  2  3  4  5  5  5  5  9  5  5  5 13  5 15  5  5 18  5  2 (id)
//	1  3  4  5 16 15 13 12 17  8 11 10 18  9 19 14  7 20  6  2 (numerazione assoluta ottenuta con il metodo ricorsivo)
//	1  2  1  1 11 10  8  7  1  3  6  5  1  4  1  9  2  1  1  1 (numerazione relativa ottenuta con il metodo iterativo)
// 18 15 13  9  5  6 16  7  8 11 12 14 10 17 19  4  3  2 20  1 (time finish assoluto!)
//
// Per sua natura l'algoritmo 'SCC Strongly Connected Component' dovrebbe essere calcolato con funzioni ricorsive, dunque
// seppur multithread il sistema di calcolo con funzioni iterativo risulta comunque molto più lento ma molto meno 'affamato'
// di memoria HEAP. Il sistema tradizionale infatti potrebbe mandare in crash il programma a causa appunto dell'altissima quantità
// di memoria HEAP richiesta.
//
// Description:
//   Generates the list of strongly connected components
//   Calculates the component for each site
//
// Input: pointer to void
//
void *SCC::thread_function_analysis_components(void *args)
{
	cpu_set_t system_cpus;

    SCC::thread_args_t *arguments = (SCC::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    SCC *obj = arguments->obj;
    Meta *meta = arguments->meta;
	bool opt_sitelinks_siterank = arguments->opt_sitelinks_siterank;

	assert(obj->sl->distributed[inst].links != NULL);

	siteid_t _nsites = obj->sl->nsites; // declaration needed for some defines

	obj->sl->distributed[inst].revlinks = NULL;
	obj->sl->adjacency_list_length[inst] = CBALLOC(unsigned short, MALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
	obj->sl->site_is_active[inst] = CBALLOC(bool, MALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	obj->sl->sync_threads(obj->sl->barrier);

	//obj->locks[inst] = CBALLOC(pthread_mutex_t, CALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	ccerr << "Reading list of active sites ... ";

	// Init vars of the sitelinkidx
	obj->sl->nactive[inst] = 0;

	// Check which sites are site_is_active
	for (siteid_t siteid = (inst + 1); siteid <= obj->sl->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		site_t site;
		site.siteid = siteid;

		// Load the site metadata
		siteid_t sitenum = site.siteid;
		meta->site_retrieve(&(site));
		assert(site.siteid == sitenum);

		off64_t offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		// Check if it has documents
		if (site.count_doc_ok > 0)
		{
			obj->sl->site_is_active[inst][offset]	= true;
			obj->sl->nactive[inst]++;
		}
		else
			obj->sl->site_is_active[inst][offset]	= false;

		// get out_degree for site
		Sitelink::sitelink_t *ptr	= obj->sl->distributed[inst].links[offset];

		obj->sl->adjacency_list_length[inst][offset] = 0;

		while (ptr)
		{
			obj->sl->adjacency_list_length[inst][offset]++;

			ptr = ptr->next;
		}
	}

	obj->scc_vec_id[inst] = CBALLOC(atomic<siteid_t>, MALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	for (siteid_t i = 0; i < ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED); i++)
		obj->scc_vec_id[inst][i] = UNDEFINED_ID; 

	obj->sl->sync_threads(obj->sl->barrier);

	bool notany = true;

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		if (obj->sl->nactive[i] > 0)
			notany = false;

	if (notany == true)
	{
		if (sp->go_ahead(inst) == true)
		{
			cerr << "** Warning! Couldn't found any site_is_active site." << endl;
			cerr << "Either 1) the crawler has not collected yet documents from any site -or- 2) you have not run the analysis program on site statistics" << endl;
		}

		// Free
		free(obj->scc_vec_id[inst]);
		free(obj->sl->adjacency_list_length[inst]);
		free(obj->sl->site_is_active[inst]);

		arguments->lidx = NULL;
		arguments->meta = NULL;

			return NULL;
	}

	siteid_t _nactive = 0;

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		_nactive += obj->sl->nactive[i];

	if (sp->go_ahead(inst) == true)
	{
		cerr << _nactive << " sites done." << endl;

		// Compute finish times
		cerr << "Computing finish times ... ";
	}

	// First step; write group membership of the outdegree links on obj->scc_vec_id
	// Slow then recursive function but NOT recursive (good)
	for (siteid_t v = (inst + 1); v <= obj->sl->nsites; v += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t v_inst = ((v - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t v_offset = ((v - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (v < obj->scc_vec_id[v_inst][v_offset])
			obj->dfs_set_id((const siteid_t)v);
	}

	obj->scc_vec_relative_finish[inst] = CBALLOC(atomic<siteid_t>, CALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	obj->sl->sync_threads(obj->sl->barrier);

	// Second step: get size of each id and set it to begin of 'obj->scc_vec_relative_finish'
	for (siteid_t v = (inst + 1); v <= obj->sl->nsites; v += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t v_inst = ((v - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t v_offset = ((v - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (obj->sl->distributed[v_inst].links[v_offset] == NULL && obj->scc_vec_id[v_inst][v_offset].ALMOR == v) // Mark relative finish time to '1'
   			obj->scc_vec_relative_finish[v_inst][v_offset] = 1;
		else
		{
			siteid_t o = obj->scc_vec_id[v_inst][v_offset].ALMOR;

			instance_t o_inst = ((o - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t o_offset = ((o - 1) / CONF_COLLECTION_DISTRIBUTED);


			obj->scc_vec_relative_finish[o_inst][o_offset]++;
		}
	}

	obj->scc_base_count[inst] = CBALLOC(siteid_t, CALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	obj->sl->sync_threads(obj->sl->barrier);

	// Thirdy step: iterate group by group and increment relative counter
	for (siteid_t v = (inst + 1); v <= obj->sl->nsites; v += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t v_inst = ((v - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t v_offset = ((v - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (v == obj->scc_vec_id[v_inst][v_offset].ALMOR)
			obj->dfs_compute_relative_finish((const siteid_t)v);
	}

	unsigned char cache = 0;

	// Fourty step:
	// First thread free set obj->scc_base_count needed to obtain absolute finish from relative finish
	// It can be only executed from one thread but executed when other threads have not yet ended.
	if (obj->act_challenge.compare_exchange_strong(cache, (unsigned char)1) == true)
	{
		obj->scc_base_count[0][0] = 0;

		siteid_t last = 1;

		// Setting base count
		for (siteid_t v = 2; v <= obj->sl->nsites; v++)
		{
			instance_t v_inst = ((v - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t v_offset = ((v - 1) / CONF_COLLECTION_DISTRIBUTED);

			if (v == obj->scc_vec_id[v_inst][v_offset].ALMOR)
			{
				instance_t l_inst = ((last - 1) % CONF_COLLECTION_DISTRIBUTED);
				siteid_t l_offset = ((last - 1) / CONF_COLLECTION_DISTRIBUTED);

				obj->scc_base_count[v_inst][v_offset] = (obj->scc_base_count[l_inst][l_offset] + obj->scc_vec_relative_finish[l_inst][l_offset].ALMOR);

				last = v;
			}
		}
	}

	obj->sl->distributed[inst].revlinks = CBALLOC(Sitelink::sitelink_t *, MALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	for (siteid_t i = 0; i < ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED); i++)
		obj->sl->distributed[inst].revlinks[i] = NULL;

	obj->scc_vec_order[inst] = CBALLOC(siteid_t, CALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	obj->sl->sync_threads(obj->sl->barrier);

	// Finally:
	// Determine the order (decreasing finish) with same results like traditional method.
	for (siteid_t v = (inst + 1); v <= obj->sl->nsites; v += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t v_inst = ((v - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t v_offset = ((v - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (v == obj->scc_vec_id[v_inst][v_offset].ALMOR)
		{
			siteid_t o = (obj->sl->nsites - (obj->scc_base_count[v_inst][v_offset] + obj->scc_vec_relative_finish[v_inst][v_offset].ALMOR) + 1);

			obj->scc_vec_order[((o - 1) % CONF_COLLECTION_DISTRIBUTED)][((o - 1) / CONF_COLLECTION_DISTRIBUTED)] = v;
		}
		else
		{
			siteid_t o = obj->scc_vec_id[v_inst][v_offset].ALMOR;

			instance_t o_inst = ((o - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t o_offset = ((o - 1) / CONF_COLLECTION_DISTRIBUTED);

			o = (obj->sl->nsites - (obj->scc_base_count[o_inst][o_offset] + obj->scc_vec_relative_finish[v_inst][v_offset].ALMOR) + 1);

			obj->scc_vec_order[((o - 1) % CONF_COLLECTION_DISTRIBUTED)][((o - 1) / CONF_COLLECTION_DISTRIBUTED)] = v;
		}
	}

	// Reversing adjacency list. Note that revlinks is already allocated.
	obj->sl->reverse_structure(inst);

	obj->scc_vec_component[inst] = CBALLOC(atomic<siteid_t>, CALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	for (siteid_t i = 0; i < ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED); i++)
		obj->scc_vec_component[inst][i] = UNMARKED; 

	obj->sl->sync_threads(obj->sl->barrier);

	free(obj->scc_vec_relative_finish[inst]);
	free(obj->scc_vec_id[inst]);
	free(obj->scc_base_count[inst]);

	for (siteid_t i = (inst + 1); i <= obj->sl->nsites; i += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t i_inst = ((i - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t i_offset = ((i - 1) / CONF_COLLECTION_DISTRIBUTED);

		// Get the node that is going to be visited now
		siteid_t v	= obj->scc_vec_order[i_inst][i_offset];

		if (i < obj->scc_vec_component[((v - 1) % CONF_COLLECTION_DISTRIBUTED)][((v - 1) / CONF_COLLECTION_DISTRIBUTED)])
			obj->dfs_decreasing(v, i); 
	}

	obj->scc_size[inst] = CBALLOC(atomic<siteid_t>, CALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	obj->sl->sync_threads(obj->sl->barrier);

	for (siteid_t v = (inst + 1); v <= obj->sl->nsites; v += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t v_inst = ((v - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t v_offset = ((v - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (obj->sl->site_is_active[v_inst][v_offset] == false)
			continue;

		siteid_t o = obj->scc_vec_component[v_inst][v_offset];

		instance_t o_inst = ((o - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t o_offset = ((o - 1) / CONF_COLLECTION_DISTRIBUTED);

		obj->scc_size[o_inst][o_offset]++;

		if (obj->sl->distributed[v_inst].links[v_offset] == NULL)
			obj->scc_no_outlinks[inst]++;

		if (obj->sl->distributed[v_inst].revlinks[v_offset] == NULL)
			obj->scc_no_inlinks[inst]++;
	}

	obj->sl->sync_threads(obj->sl->barrier);

	// get scc_giants on instance
	for (siteid_t i = (inst + 1); i <= obj->sl->nsites; i += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t i_inst = ((i - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t i_offset = ((i - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (obj->scc_size[i_inst][i_offset] > obj->scc_giant_component_size[inst])
		{
			obj->scc_giant_component_size[inst] = obj->scc_size[i_inst][i_offset];
			obj->scc_giant_component[inst] = i;
		}

		if (obj->scc_size[i_inst][i_offset] == 1)
			obj->scc_singletons[inst]++;

		siteid_t o = obj->scc_vec_order[i_inst][i_offset];

		instance_t o_inst = ((o - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t o_offset = ((o - 1) / CONF_COLLECTION_DISTRIBUTED);

		// if root node sum histogram
		if (i == obj->scc_vec_component[o_inst][o_offset])
		{
			obj->scc_count++;

			obj->scc_size_histogram[inst][obj->scc_size[i_inst][i_offset]]++;
		}
	}

	obj->sl->sync_threads(obj->sl->barrier);

	free(obj->scc_size[inst]);
	free(obj->scc_vec_order[inst]);

	siteid_t _scc_giant_component_size = 0;
	siteid_t _scc_giant_component = 0;

	// each thread calculate the sum of 'giant components' variable. This sum is equal for each thread
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		if (obj->scc_giant_component_size[i] > _scc_giant_component_size)
		{
			_scc_giant_component_size = obj->scc_giant_component_size[i];
			_scc_giant_component = obj->scc_giant_component[i];
		}
		else if (obj->scc_giant_component_size[i] == _scc_giant_component_size && obj->scc_giant_component[i] < _scc_giant_component)
			_scc_giant_component = obj->scc_giant_component[i];
	}

	obj->component[inst] = CBALLOC(atomic<component_t>, MALLOC, ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));

	for (siteid_t i = 0; i < ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED); i++)
	{
		if ((i * CONF_COLLECTION_DISTRIBUTED + (inst + 1))  > obj->sl->nsites)
			continue;

		if (obj->scc_vec_component[inst][i] == _scc_giant_component)
			obj->component[inst][i]	= COMPONENT_MAIN_NORM;
		else if (obj->sl->site_is_active[inst][i])
			obj->component[inst][i]	= COMPONENT_ISLAND;
		else
			obj->component[inst][i]	= COMPONENT_UNDEF;
	}

	obj->sl->sync_threads(obj->sl->barrier);

	free(obj->sl->site_is_active[inst]);

	// Mark all the sites in OUT: can be reached from IN
	for (siteid_t siteid = (inst + 1); siteid <= obj->sl->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (obj->component[s_inst][s_offset] == COMPONENT_MAIN_NORM)
			obj->mark_reachable(siteid, COMPONENT_ISLAND, COMPONENT_OUT, true);
	}

	obj->sl->sync_threads(obj->sl->barrier);

	// Mark all the sites in IN: can reach MAIN_NORM
	for (siteid_t siteid = (inst + 1); siteid <= obj->sl->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (obj->component[s_inst][s_offset] == COMPONENT_MAIN_NORM)
			obj->mark_reachable_rev(siteid, COMPONENT_ISLAND, COMPONENT_IN, true);
	}

	obj->sl->sync_threads(obj->sl->barrier);

	// Mark all the sites in MAIN_IN: are directly reached from IN and are MAIN
	// Mark all the sites in TIN: can be reached from IN, but are not in MAIN
	for (siteid_t siteid = (inst + 1); siteid <= obj->sl->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (obj->component[s_inst][s_offset] == COMPONENT_IN)
		{
			obj->mark_reachable(siteid, COMPONENT_MAIN_NORM, COMPONENT_MAIN_IN, false);
			obj->mark_reachable(siteid, COMPONENT_ISLAND, COMPONENT_TIN, true);
		}
	}

	obj->sl->sync_threads(obj->sl->barrier);

	free(obj->sl->adjacency_list_length[inst]);

	// Mark all the sites in MAIN_OUT: can directly reach OUT and are MAIN
	// Mark all the sites in MAIN_MAIN: can directly reach OUT and are MAIN_IN
	// Mark all the sites in TOUT: can reach OUT, but are not in MAIN
	for (siteid_t siteid = (inst + 1); siteid <= obj->sl->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
		siteid_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		if (obj->component[s_inst][s_offset] == COMPONENT_OUT)
		{
			obj->mark_reachable_rev(siteid, COMPONENT_MAIN_NORM, COMPONENT_MAIN_OUT, false);
			obj->mark_reachable_rev(siteid, COMPONENT_ISLAND, COMPONENT_TOUT, true);
			obj->mark_reachable_rev(siteid, COMPONENT_TIN, COMPONENT_TUNNEL, true);
			obj->mark_reachable_rev(siteid, COMPONENT_MAIN_IN, COMPONENT_MAIN_MAIN, false);
		}
	}

	obj->count_component[inst] = CBALLOC(siteid_t, CALLOC, COMPONENT_COUNT);

	obj->sl->sync_threads(obj->sl->barrier);

	//
	// Save component type on meta index
	//

	site_t site;

	// Generate statistics
	for (siteid_t siteid = (inst + 1); siteid <= obj->sl->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		siteid_t offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		// Write component to metadata
		site.siteid = siteid;
		meta->site_retrieve(&(site));
		assert(site.siteid == siteid);
		site.component = obj->component[inst][offset];
		meta->site_store(&(site));

		// Get obj->component size
		if (obj->component[inst][offset].ALMOR != COMPONENT_UNDEF)
			obj->nsites_not_undef[inst]++;
		
		// Count
		obj->count_component[inst][obj->component[inst][offset].ALMOR]++;
	}

	// free all linked list siteid by siteid only if not used by function 'analysis_siterank'
	for (siteid_t i = 0; i < ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED); i++)
	{
		if ((i * CONF_COLLECTION_DISTRIBUTED + (inst + 1))  > obj->sl->nsites)
			continue;

		Sitelink::sitelink_t *ptr = obj->sl->distributed[inst].revlinks[i];

		while (ptr)
		{
			Sitelink::sitelink_t *old_ptr = ptr;
			ptr = ptr->next;
			free(old_ptr);
		}
	}

	free(obj->sl->distributed[inst].revlinks);

	// free all linked list siteid by siteid only if not used by function 'analysis_siterank'
	if (opt_sitelinks_siterank == false)
	{
		for (siteid_t i = 0; i < ((obj->sl->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED); i++)
		{
			if ((i * CONF_COLLECTION_DISTRIBUTED + (inst + 1))  > obj->sl->nsites)
				continue;

			Sitelink::sitelink_t *ptr = obj->sl->distributed[inst].links[i];

			while (ptr != NULL)
			{
				Sitelink::sitelink_t *old_ptr = ptr;
				ptr = ptr->next; // Continue
				free(old_ptr);
			}
		}

		free(obj->sl->distributed[inst].links);
	}

	// 
	// Save statistic to file preserving disks
	//
	char basename[MAX_STR_LEN];
	char filename[MAX_STR_LEN];
	FILE *output;

	strcpy(basename, "sitelink");

	sprintf(filename, "%s/%s", COLLECTION_ANALYSIS, basename);

	// Create directory
	createdir(filename);

	ccerr << "* Siteid and component -> " << filename << " ... ";

	obj->sl->sync_threads(obj->sl->barrier);

	siteid_t chunk_size = (obj->sl->nsites / CONF_COLLECTION_DISTRIBUTED);
	size_t line_len = 60;
	int written = 0;
	size_t space_left = ((chunk_size * line_len) + 50);
	char *pbuffer = CBALLOC(char, MALLOC, ((chunk_size * line_len) + 50));
	pbuffer[0] = '\0';

	sprintf(filename, "%s/%s/%s", COLLECTION_ANALYSIS, basename, "siteid_sccid_component.csv");

	if (inst == 0)
	{
		written = snprintf(pbuffer, space_left, "Siteid,Strongly connected component id,Component\n");
		space_left -= written;

		for (siteid_t siteid = ((chunk_size * inst) + 1); siteid <= ((chunk_size * inst) + chunk_size); siteid++)
		{
			instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

			string component_name = (string)COMPONENT_STR(obj->component[s_inst][s_offset]);

			if (written >= 0 && (space_left - written) > (line_len * 2))
				written += snprintf(pbuffer + written, space_left - written, "%lu,%lu,%s\n", (unsigned long int)siteid, (unsigned long int)obj->scc_vec_component[s_inst][s_offset], component_name.c_str());
		}

		// write sequentially inside unique file (sync 'like barrier' but order by instance)
		while (obj->sequence < inst)
			usleep(5);

		output = fopen64(filename, "w");
		assert(output != NULL);
		fprintf(output, pbuffer);
		fclose(output);
		obj->sequence++;
	}
	else if (inst == (CONF_COLLECTION_DISTRIBUTED - 1))
	{
		for (siteid_t siteid = ((chunk_size * inst) + 1); siteid <= obj->sl->nsites; siteid++)
		{
			instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

			string component_name = (string)COMPONENT_STR(obj->component[s_inst][s_offset]);

			if (written >= 0 && (space_left - written) > (line_len * 2))
				written += snprintf(pbuffer + written, space_left - written, "%lu,%lu,%s\n", (unsigned long int)siteid, (unsigned long int)obj->scc_vec_component[s_inst][s_offset], component_name.c_str());
		}

		// write sequentially inside unique file (sync 'like barrier' but order by instance)
		while (obj->sequence < inst)
			usleep(5);

		output = fopen64(filename, "a");
		assert(output != NULL);
		fprintf(output, pbuffer);
		fclose(output);
		obj->sequence++;
	}
	else
	{
		for (siteid_t siteid = ((chunk_size * inst) + 1); siteid <= ((chunk_size * inst) + chunk_size); siteid++)
		{
			instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
			siteid_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

			string component_name = (string)COMPONENT_STR(obj->component[s_inst][s_offset]);

			if (written >= 0 && (space_left - written) > (line_len * 2))
				written += snprintf(pbuffer + written, space_left - written, "%lu,%lu,%s\n", (unsigned long int)siteid, (unsigned long int)obj->scc_vec_component[s_inst][s_offset], component_name.c_str());
		}

		// write sequentially inside unique file (sync 'like barrier' but order by instance)
		while (obj->sequence < inst)
			usleep(5);

		output = fopen64(filename, "a");
		assert(output != NULL);
		fprintf(output, pbuffer);
		fclose(output);
		obj->sequence++;
	}

	free(pbuffer);

	obj->sl->sync_threads(obj->sl->barrier);

	free(obj->component[inst]);
	free(obj->scc_vec_component[inst]);

	ccerr << "done." << endl;

	cache = 1;

	if (obj->act_challenge.compare_exchange_strong(cache, (unsigned char)2) == true)
	{
		siteid_t _scc_singletons = 0;
		siteid_t _scc_no_inlinks = 0;
		siteid_t _scc_no_outlinks = 0;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			_scc_singletons += obj->scc_singletons[i];
			_scc_no_inlinks += obj->scc_no_inlinks[i];
			_scc_no_outlinks += obj->scc_no_outlinks[i];
		}

		// Write general statistics
		int written = 0;
		size_t space_left = MAX_STR_LEN;
		char *pbuffer = CBALLOC(char, MALLOC, MAX_STR_LEN);

		sprintf(filename, "%s/%s/%s", COLLECTION_ANALYSIS, basename, "stats.csv");
		output = fopen64(filename, "w");
		assert(output != NULL);

		// cerr << "* Writing stats to " << filename << " ... ";

		written = snprintf(pbuffer, space_left, "Total number of site names known,%lu\n", (unsigned long int)obj->sl->nsites);

		if (written >= 0 && (space_left - written) > 100)
			written += snprintf(pbuffer + written, space_left - written, "Sites with at least one page ok,%lu\n", (unsigned long int)_nactive);

		if (written >= 0 && (space_left - written) > 100)
			written += snprintf(pbuffer + written, space_left - written, "Sites without in links (but at least one page ok),%lu\n", (unsigned long int)_scc_no_inlinks);

		if (written >= 0 && (space_left - written) > 100)
			written += snprintf(pbuffer + written, space_left - written, "Sites without out links (but at least one page ok),%lu\n", (unsigned long int)_scc_no_outlinks);

		if (written >= 0 && (space_left - written) > 100)
			written += snprintf(pbuffer + written, space_left - written, "Size of largest SCC,%lu\n", (unsigned long int)_scc_giant_component_size);

		if (written >= 0 && (space_left - written) > 100)
			written += snprintf(pbuffer + written, space_left - written, "SCC-id of largest SCC,%lu\n", (unsigned long int)_scc_giant_component);

		if (written >= 0 && (space_left - written) > 100)
			written += snprintf(pbuffer + written, space_left - written, "Number of SCCs with one site only (singletons),%lu\n", (unsigned long int)_scc_singletons);

		fprintf(output, pbuffer);

		fclose(output);
		free(pbuffer);

		mcerr << "* Writing stats to " << filename << " ... done." << mendl;
	}

	cache = 2;

	if (obj->act_challenge.compare_exchange_strong(cache, (unsigned char)3) == true)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Size of each strongly-connected-component
		sprintf(filename, "%s/%s/%s", COLLECTION_ANALYSIS, basename, "scc_sizes.csv");
		output = fopen64(filename, "w+");
		assert(output != NULL);

		// cerr << "* Strongly connected component sizes -> " << filename << " ... ";

		map<siteid_t, siteid_t> _scc_size_histogram;
		map<siteid_t, siteid_t>::iterator scc_size_histogram_it;

        for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
        {   
			for (scc_size_histogram_it = obj->scc_size_histogram[i].begin(); scc_size_histogram_it != obj->scc_size_histogram[i].end(); scc_size_histogram_it++)
                _scc_size_histogram[(*scc_size_histogram_it).first] += (*scc_size_histogram_it).second;
            
            obj->scc_size_histogram[i].clear();
        }

		written = snprintf(pbuffer, space_left, "SCC size,Number of SCC components for each size,Fraction of Number of SCC components for each size to Number of SCC components with size major of zero\n");

		// There are some SCC that were created but never used,
		// remember that at the beginning each site starts in its
		// own SCC
		for (scc_size_histogram_it = _scc_size_histogram.begin(); scc_size_histogram_it != _scc_size_histogram.end(); scc_size_histogram_it++)
			if ((*scc_size_histogram_it).first > 0)
			{
				siteid_t SCC_size = (*scc_size_histogram_it).first;
				siteid_t SCC_amount = (*scc_size_histogram_it).second;
				double Fraction = ((double)SCC_amount / ((double)obj->scc_count - (double)_scc_size_histogram[0]));

				size_t line_len = 17; // max length of 'Fraction' in chars is twelve (with scientific output)

				while (SCC_size > 1 && (SCC_size /= 10))
					line_len++;

				while (SCC_amount > 1 && (SCC_amount /= 10))
					line_len++;

				SCC_size = (*scc_size_histogram_it).first;
				SCC_amount = (*scc_size_histogram_it).second;

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left, "%lu,%lu,%e\n", (unsigned long int)SCC_size, (unsigned long int)SCC_amount, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written, "%lu,%lu,%e\n", (unsigned long int)SCC_size, (unsigned long int)SCC_amount, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

        _scc_size_histogram.clear();

		fclose(output);
		free(pbuffer);

		mcerr << "* Strongly connected component sizes -> " << filename << " ... done." << mendl;
	}

	cache = 3;

	// Sizes of strongly-connected-component
	if (obj->act_challenge.compare_exchange_strong(cache, (unsigned char)4) == true)
	{
		int written = 0;
		size_t space_left = (MAX_STR_LEN * 50);
		pbuffer = CBALLOC(char, MALLOC, (MAX_STR_LEN * 50));
		pbuffer[0] = '\0';

		// Size of each strongly-connected-component
		sprintf(filename, "%s/%s/%s", COLLECTION_ANALYSIS, basename, "graph_component_sizes.csv");
		output = fopen64(filename, "w+");
		assert(output != NULL);

		siteid_t _nsites_not_undef = 0;
		siteid_t *_count_component = CBALLOC(siteid_t, CALLOC, COMPONENT_COUNT);

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			_nsites_not_undef += obj->nsites_not_undef[i];

			for (instance_t c = 0; c < COMPONENT_COUNT; c++)
				_count_component[c] += obj->count_component[i][c];
		}

		// cerr << "* Graph component sizes -> " << filename << " ... ";

		written = snprintf(pbuffer, space_left, "Component name,Number of sites in the component,Fraction of Number of sites to Number of sites not undef\n");

		for (size_t c = 0; c < (size_t)COMPONENT_COUNT; c++)
			if ((component_t)c != COMPONENT_UNDEF)
			{
				string component_name = (string)COMPONENT_STR((component_t)c);
				siteid_t sites_amount = _count_component[c];
				double Fraction = (double)(sites_amount) / (double)_nsites_not_undef;

				size_t line_len = 16; // max length of 'Fraction' in chars is twelve (with scientific output)

				line_len += component_name.size();

				while (sites_amount > 1 && (sites_amount /= 10))
					line_len++;

				sites_amount = _count_component[c];

				while (true)
				{
					if (written == 0)
						written += snprintf(pbuffer, space_left, "%s,%lu,%e\n", component_name.c_str(), (unsigned long int)sites_amount, Fraction);
					else if (written >= 0)
					{
						if (space_left > (written + line_len))
							written += snprintf(pbuffer + written, space_left - written, "%s,%lu,%e\n", component_name.c_str(), (unsigned long int)sites_amount, Fraction);
						else
						{
							fprintf(output, pbuffer);
							written = 0;
							pbuffer[written] = '\0';
							continue;
						}
					}

					break;
				}
			}

		if (written > 0)
			fprintf(output, pbuffer);

		fclose(output);
		free(_count_component);
		free(pbuffer);

		mcerr << "* Graph component sizes -> " << filename << " ... done." << mendl;
	}

	obj->sl->sync_threads(obj->sl->barrier);

	free(obj->count_component[inst]);

	arguments->lidx = NULL;
	arguments->meta = NULL;

	return NULL;
}

// 
// Name: analysis_siterank
//
// Description: run function 
//   Generates a sitelink structure
//   - Read all the links from the page link structure
//   - Collapse links to inter-site links
//   - Write to disk
//
// Input:
//   linkidx - structure of links between pages
//   metaddx - structure of metadata
// 
// Output:
//   file containing link structure between sites is created
//   metadata of sites is updated to reflect internal and external links
//
void Sitelink::analysis_siterank(Meta *meta, bool use_internal_links, bool use_site_size, bool linearize)
{
	assert(dirname != NULL);
	//assert(readonly == false);
	assert(meta != NULL);

	int rc = 0;
	pthread_mutexattr_t attr;

	if (ndocs == 0)
	{
		ndocs	= meta->doc_count();
		assert(ndocs > 0);
	}


	if (nsites == 0)
	{
		nsites = meta->site_count();
		assert(nsites > 0);
	}

	assert(SITELINK_MAX_OUTDEGREE < USHRT_MAX);

	nsites_active = CBALLOC(siteid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	ndocs_total = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	siterank = CBALLOC(siterank_t, MALLOC, (nsites + 1));
	siterankTmp = CBALLOC(siterank_t, MALLOC, (nsites + 1));
//	testrank = CBALLOC(siterank_t, MALLOC, (800000 + 1));
//	testrankTmp = CBALLOC(siterank_t, MALLOC, (800000 + 1));
	count_doc_ok = CBALLOC(docid_t, MALLOC, (nsites + 1));
	in_degree = CBALLOC(atomic<siteid_t>, MALLOC, (nsites + 1));
	out_degree = CBALLOC(siteid_t, MALLOC, (nsites + 1));
	sum_weight = CBALLOC(siterank_t, MALLOC, (nsites + 1));
	sum_siteranks = CBALLOC(siterank_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	siterank_delta = CBALLOC(siterank_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	linearize_order = CBALLOC(siteid_t, CALLOC, (nsites + 1));
//	linearize_test_order = CBALLOC(siteid_t, CALLOC, (800000 + 1));
	internal_links = CBALLOC(docid_t *, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	slocks = CBALLOC(pthread_mutex_t, CALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));

/*
	for (siteid_t i = 1; i <= 800000; i++)
		testrank[i] = ((siterank_t)(rand() % 8000000) / 8000000);

		const siteid_t _skip_count = 1;

		for (siteid_t i = 0; i < _skip_count; i++)
		{
			testrank[i] = (siterank_t)0;
			linearize_test_order[i] = (siteid_t)0;
		}

		sortt = new CBotSort<siterank_t, siteid_t> (siterank, linearize_order, nsites, 0, skip_count, NULL, false, true, true);
		sortt->barrier_init();
*/
	// WARNING: linearize can be applied only if siterank_t is double type
	if (linearize == true)
	{
		// Note: we move offset ahead to one because siteid == 0 DO NOT EXIST
		const siteid_t skip_count = 1;

		for (siteid_t i = 0; i < skip_count; i++)
		{
			siterank[i] = (siterank_t)0;
			linearize_order[i] = (siteid_t)0;
		}

		sortr = new CBotSort<siterank_t, siteid_t> (siterank, linearize_order, nsites, 0, skip_count, NULL, false, true, true);
		sortr->barrier_init();
	}

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			slocks[i] = PTHREAD_MUTEX_INITIALIZER;

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Sitelink::thread_args_t *args = CBALLOC(Sitelink::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = SITELINK_ANALYSIS_SITERANK;
		args->meta = meta;
		args->url = NULL;
		args->use_internal_links = use_internal_links;
		args->use_site_size = use_site_size;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_analysis_siterank((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			if ((rc = pthread_mutex_destroy(&slocks[i])) != 0)
				die("error destroying mutexes %s", CBoterr(rc));

		free(slocks); slocks = NULL;

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;
	}

	cerr << "done." << endl;

	// report (simple operation) multi thread is not need
	siteid_t _nsites_active = 0;

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		_nsites_active += nsites_active[i];
/*
	bool test = false;

	for (siteid_t i = 1; i <= 800000; i++)
	{
		if (linearize_test_order[i] == 800000)
			test = true;

		assert(linearize_test_order[i] < (800000 + 1));

		if (testrankTmp[linearize_test_order[i]] > 0)
			assert(testrankTmp[linearize_test_order[i]] >= testrankTmp[linearize_test_order[i - 1]]);
	}

	assert(test == true);
*/
/*
	bool test = false;

	for (siteid_t i = 1; i <= nsites; i++)
	{
		if (linearize_order[i] == nsites)
			test = true;

		if (siterankTmp[linearize_order[i]] > 0)
		{
			cout << i << ' ' << linearize_order[i] << ' ' << siterankTmp[linearize_order[i]] << ' ' << siterank[linearize_order[i]] << endl;
			assert(siterankTmp[linearize_order[i]] >= siterankTmp[linearize_order[i - 1]]);
		}
	}

	assert(test == true);
*/

	free(internal_links);
	free(siterank_delta);
	free(sum_siteranks);
	free(sum_weight);
	free(count_doc_ok);
	free(siterankTmp);
	free(ndocs_total);
	free(nsites_active);

	if (linearize == true)
		delete sortr;

//	delete sortt;

	free(linearize_order);
	free(out_degree);
	free(in_degree);
	free(siterank);
}

// 
// Name: thread_function_analysis_siterank
//
// Description:
//   Generates a sitelink structure
//   - Read all the links from the page link structure
//   - Collapse links to inter-site links
//   - Write to disk
//
// Input: pointer to void
// 
// Output:
//   file containing link structure between sites is created
//   metadata of sites is updated to reflect internal and external links
//
void *Sitelink::thread_function_analysis_siterank(void *args)
{
	cpu_set_t system_cpus;

    Sitelink::thread_args_t *arguments = (Sitelink::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Sitelink *obj = arguments->obj;
    Meta *meta = arguments->meta;
    bool use_internal_links = arguments->use_internal_links;
    bool use_site_size = arguments->use_site_size;

	site_t site;

	obj->internal_links[inst] = CBALLOC(docid_t, CALLOC, ((obj->nsites + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED));
/*
	// Cleans the siterank vector
	// Cleans the in_degree vector
	// Loads the number of internal links for each site
	for (site.siteid = (inst + 1); site.siteid <= obj->nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		siteid_t sitenum = site.siteid;
		meta->site_retrieve(&(site));
		assert(site.siteid == sitenum);

		obj->internal_links[inst][((site.siteid - 1) / CONF_COLLECTION_DISTRIBUTED)] = site.internal_links;
		obj->count_doc_ok[site.siteid]		= site.count_doc_ok;

		atomic_init<siteid_t>(&obj->in_degree[site.siteid], 0); // no thread safe
		obj->out_degree[site.siteid] = 0;

		obj->sum_weight[site.siteid] = 0;

		if (obj->count_doc_ok[site.siteid] > 0)
		{
			obj->nsites_active[inst]++;
			obj->ndocs_total[inst] += site.count_doc_ok;
		}
	} */

#ifndef META_MAX_BUFFERING_SIZE
	for (site.siteid = (inst + 1); site.siteid <= obj->nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		siteid_t sitenum = site.siteid;
		meta->site_retrieve(&(site));
		assert(site.siteid == sitenum);

		obj->internal_links[inst][((site.siteid - 1) / CONF_COLLECTION_DISTRIBUTED)] = site.internal_links;
		obj->count_doc_ok[site.siteid]		= site.count_doc_ok;

		atomic_init<siteid_t>(&obj->in_degree[site.siteid], 0); // no thread safe
		obj->out_degree[site.siteid] = 0;

		obj->sum_weight[site.siteid] = 0;

		if (obj->count_doc_ok[site.siteid] > 0)
		{
			obj->nsites_active[inst]++;
			obj->ndocs_total[inst] += site.count_doc_ok;
		}
	}
#else
	size_t size = (META_MAX_BUFFERING_SIZE > sizeof(site_t)) ? (META_MAX_BUFFERING_SIZE / sizeof(site_t)) : META_MIN_BUFFERING_SIZE;

	site_t *sites = CBALLOC(site_t, MALLOC, size);

	size_t o = 0;

	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		siteid_t expected = (siteid / 10) * 10;
		siteid_t next = expected + 10;

		// Report
		// if (nsites_div_50 > 0 && (site.siteid % nsites_div_50 == 0) && this->print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
		//	cerr << ".";

		sites[o].siteid = siteid;
		o++;

		if (o == size)
		{
			if (o > 1)
				assert(meta->site_retrieve_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_retrieve(&sites[0]) == METADDX_OK);

			for (size_t i = 0; i < o; i++)
			{
				assert(sites[i].siteid > 0);
				assert(sites[i].siteid <= obj->nsites);

				obj->internal_links[inst][((sites[i].siteid - 1) / CONF_COLLECTION_DISTRIBUTED)] = sites[i].internal_links;
				obj->count_doc_ok[sites[i].siteid]		= sites[i].count_doc_ok;

				atomic_init<siteid_t>(&obj->in_degree[sites[i].siteid], 0); // no thread safe
				obj->out_degree[sites[i].siteid] = 0;

				obj->sum_weight[sites[i].siteid] = 0;

				if (obj->count_doc_ok[sites[i].siteid] > 0)
				{
					obj->nsites_active[inst]++;
					obj->ndocs_total[inst] += sites[i].count_doc_ok;
				}
			}

			o = 0;
		}
		else if ((siteid + CONF_COLLECTION_DISTRIBUTED) > obj->nsites)
		{
			if (o > 1)
				assert(meta->site_retrieve_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_retrieve(&sites[0]) == METADDX_OK);

			for (size_t i = 0; i < o; i++)
			{
				assert(sites[i].siteid > 0);
				assert(sites[i].siteid <= obj->nsites);

				obj->internal_links[inst][((sites[i].siteid - 1) / CONF_COLLECTION_DISTRIBUTED)] = sites[i].internal_links;
				obj->count_doc_ok[sites[i].siteid]		= sites[i].count_doc_ok;

				atomic_init<siteid_t>(&obj->in_degree[sites[i].siteid], 0); // no thread safe
				obj->out_degree[sites[i].siteid] = 0;

				obj->sum_weight[sites[i].siteid] = 0;

				if (obj->count_doc_ok[sites[i].siteid] > 0)
				{
					obj->nsites_active[inst]++;
					obj->ndocs_total[inst] += sites[i].count_doc_ok;
				}
			}

			o = 0;
		}

	}

	free(sites);
#endif

	sync_threads(obj->barrier);

	docid_t _ndocs_total = 0;

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		_ndocs_total += obj->ndocs_total[i];

	siteid_t _nsites_active = 0;

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		_nsites_active += obj->nsites_active[i];

	// there is no active sites, stop
	if (_nsites_active == 0)
	{
		free(obj->internal_links[inst]);

		// free all linked list siteid by siteid
		for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
		{
			sitelink_t *ptr = obj->distributed[((siteid - 1) % CONF_COLLECTION_DISTRIBUTED)].links[((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];

			while (ptr != NULL)
			{
				sitelink_t *old_ptr = ptr;
				ptr = ptr->next; // Continue
				free(old_ptr);
			}
		}

		sync_threads(obj->barrier);

		free(obj->distributed[inst].links);

		arguments->meta = NULL;

	        return NULL;
	}

	for (site.siteid = (inst + 1); site.siteid <= obj->nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		if (obj->count_doc_ok[site.siteid] > 0)
			obj->siterank[site.siteid] = ((siterank_t)1 / (siterank_t)_nsites_active);
		else
			obj->siterank[site.siteid] = 0;
	}

	// Calculates the in_degree of sites
	for (site.siteid = (inst + 1); site.siteid <= obj->nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		sitelink_t *ptr = obj->distributed[((site.siteid - 1) % CONF_COLLECTION_DISTRIBUTED)].links[((site.siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];

		while (ptr)
		{
			obj->out_degree[site.siteid]++;
			obj->in_degree[ptr->siteid]++;
			obj->sum_weight[site.siteid] += ptr->weight;
			ptr = ptr->next;
		}
	}

	double omq	= (double)CONF_MANAGER_SCORE_PAGERANK_DAMPENING;
	double q	= (double)1 - omq;
	unsigned int iteration;

	// syncronized cycle with thread
	for (iteration = 0; iteration < SITELINK_MAX_ITERATIONS; iteration++)
	{
	//	obj->iteration++;

		// Clear TMP
		for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
			obj->siterankTmp[siteid] = (siterank_t)0;

		obj->sum_siteranks[inst] = 0;

		sync_threads(obj->barrier);

		// In this step, we add to a site the siterank of all the sites
		// with links to it, but considering that each site confers
		// only a fraction of its siterank:
		//   1 / (out_degree + internal_links)
		// on each link.
		if (use_internal_links) // Internal links will keep the random surfer in the same site, so the probability of jumping outside is less
		{
			for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
			{
				instance_t c = 0;
				instance_t b = inst;

				siterank_t ilinks = obj->internal_links[((siteid - 1) % CONF_COLLECTION_DISTRIBUTED)][((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];

				const sitelink_t *start_ptr = obj->distributed[((siteid - 1) % CONF_COLLECTION_DISTRIBUTED)].links[((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];

				if (start_ptr)
				{
					while (c < CONF_COLLECTION_DISTRIBUTED)
					{
						obj->lock(b, obj->slocks);

						sitelink_t *ptr = (sitelink_t *)start_ptr;

						while (ptr)
						{
							if (((ptr->siteid - 1) % CONF_COLLECTION_DISTRIBUTED) == b)
								obj->siterankTmp[ptr->siteid] += (obj->siterank[siteid] * (siterank_t)(ptr->weight)) / ((siterank_t)obj->sum_weight[siteid] + ilinks);

							ptr = ptr->next;
						}

						obj->unlock(b, obj->slocks);

						c++;
						b = ((b + 1) % CONF_COLLECTION_DISTRIBUTED);
					}
				}
			}
		}
		else // If we don't use internal links, we just care about the weight of the site
		{
			for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
			{
				instance_t c = 0;
				instance_t b = inst;

				const sitelink_t *start_ptr = obj->distributed[((siteid - 1) % CONF_COLLECTION_DISTRIBUTED)].links[((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];

				if (start_ptr)
				{
					while (c < CONF_COLLECTION_DISTRIBUTED)
					{
						obj->lock(b, obj->slocks);

						sitelink_t *ptr = (sitelink_t *)start_ptr;

						while (ptr)
						{
							if (((ptr->siteid - 1) % CONF_COLLECTION_DISTRIBUTED) == b)
								obj->siterankTmp[ptr->siteid] += (obj->siterank[siteid] * (siterank_t)(ptr->weight)) / ((siterank_t)obj->sum_weight[siteid]);

							ptr = ptr->next;
						}

						obj->unlock(b, obj->slocks);

						c++;
						b = ((b + 1) % CONF_COLLECTION_DISTRIBUTED);
					}
				}
			}
		}

		sync_threads(obj->barrier);

		/* MS algo semaphore to avoid write's collisions in 'siterankTmp'
		// In this step, we add to a site the siterank of all the sites
		// with links to it, but considering that each site confers
		// only a fraction of its siterank:
		//   1 / (out_degree + internal_links)
		// on each link.

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			siteid_t start = (((inst + i) % CONF_COLLECTION_DISTRIBUTED) + 1);

			for (siteid_t siteid = start; siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
			{
				instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
				off64_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);
				ptr = obj->distributed[s_inst].links[s_offset][inst];

				while (ptr != NULL)
				{
					if (use_internal_links) // Internal links will keep the random surfer in the same site, so the probability of jumping outside is less
					{
						siterank_t ilinks = obj->internal_links[((siteid - 1) % CONF_COLLECTION_DISTRIBUTED)][((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];
						obj->siterankTmp[ptr->siteid] += (obj->siterank[siteid] * (siterank_t)(ptr->weight)) / ((siterank_t)obj->sum_weight[siteid] + ilinks);
					}
					else // If we don't use internal links, we just care about the weight of the site
						obj->siterankTmp[ptr->siteid] += (obj->siterank[siteid] * (siterank_t)(ptr->weight)) / ((siterank_t)obj->sum_weight[siteid]);

					ptr = ptr->next;
				}

				sync_threads(obj->barrier);
			}

			if (((inst + i) % CONF_COLLECTION_DISTRIBUTED) != 0 && sync_threads(obj->barrier) == false) // linearize barrier calls outside the preview function
		}
*/

		// Now we complete the calculus, we will add the siterank
		// added by the links betweeen all sites (with probability q)
		// and the siterank added by auto-links (with probabilith 1-q=omq)
		for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
		{
			if	(obj->count_doc_ok[siteid] > 0)
			{
				siterank_t contribution_random_links	= 0;

				// Check if we must use site size
				// When we use site size, larger sites will 
				// have an advantage.
				if (use_site_size)
				{
					// Probability of getting here by a random
					// link, proportional to the number of documents
					// in this website. We will divide the number of documents
					// in this website by the average documents.
					contribution_random_links = ((double)obj->count_doc_ok[siteid] /  (double)_ndocs_total);
				}
				else // Probability of getting here by a random link, constant for all sites
					contribution_random_links = (double)1 / (double)_nsites_active;
				
				//  Calculate
				obj->siterankTmp[siteid] = (q*contribution_random_links) + (omq * obj->siterankTmp[siteid]);

				// If we are using internal links, add the
				// probability of staying in the same node
				if	(use_internal_links)
				{
					siterank_t ilinks = obj->internal_links[((siteid - 1) % CONF_COLLECTION_DISTRIBUTED)][((siteid - 1) / CONF_COLLECTION_DISTRIBUTED)];
			
					if (ilinks + obj->out_degree[siteid] > 0)
						obj->siterankTmp[siteid] += omq * obj->siterank[siteid] * (ilinks / (ilinks + (siterank_t)obj->sum_weight[siteid]));
				}

				// Sum, this is to normalize at the end
				obj->sum_siteranks[inst] += obj->siterankTmp[siteid];
			}
		}

		sync_threads(obj->barrier);

		sp->reset(inst);

		siterank_t _sum_siteranks = 0;
		obj->siterank_delta[inst] = 0;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			_sum_siteranks += obj->sum_siteranks[i];

		for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
		{
			// Calculate change in siterank = new/old value
			siterank_t siterank_aux = (obj->siterankTmp[siteid] / _sum_siteranks);

			// Check variation of siterank
			obj->siterank_delta[inst] += linkidx_calc_delta(siterank_aux, obj->siterank[siteid]);

			// Normalize to avoid overflow
			obj->siterank[siteid] = siterank_aux;
		}

		sync_threads(obj->barrier);

		siterank_t _siterank_delta = 0;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			_siterank_delta += obj->siterank_delta[i];

		_siterank_delta	/= _nsites_active;

		if (sp->go_ahead(inst) == true)
		{
			cerr << "- Iteration " << iteration << endl;

			cerr << "  siterank average error = " << _siterank_delta << endl;
    	    cerr << "  siterank sum values    = " << _sum_siteranks << endl;

			if (_siterank_delta < CONF_MANAGER_SCORE_SITERANK_MAX_ERROR)
			{
				cerr << "OK, target average error reached " << CONF_MANAGER_SCORE_SITERANK_MAX_ERROR << endl;
			}
			else if (_sum_siteranks == 0)
			{
				cerr << "Warning: no site has a positive score, maybe the collection process is just starting." << endl;
			}
		}

		if (_siterank_delta < CONF_MANAGER_SCORE_SITERANK_MAX_ERROR || _sum_siteranks == 0)
			break;
	}

	// memcpy(obj->siterankTmp, obj->siterank, obj->nsites); // for order check use
//	memcpy(obj->testrankTmp, obj->testrank, (800000 + 1) * sizeof(siterank_t)); // for order check use

	sync_threads(obj->barrier);

	if (iteration == SITELINK_MAX_ITERATIONS)
	{
		if (sp->go_ahead(inst) == true)
			die("Maximum limit of iterations reached without the desired convergence");
		else
			exit(1);
	}


	free(obj->internal_links[inst]);

	// free all linked list siteid by siteid
	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		instance_t s_inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
		off64_t s_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

		sitelink_t *ptr = obj->distributed[s_inst].links[s_offset];

		while (ptr != NULL)
		{
			sitelink_t *old_ptr = ptr;
			ptr = ptr->next; // Continue
			free(old_ptr);
		}
	}

//	if (obj->sortt != NULL)
//		obj->sortt->order(inst);

	// Prepare linearize process (Generate base order)
	if (obj->sortr != NULL)
	{
		ccerr << "Linearizing ... ";

		obj->sortr->order(inst);
	}

	sync_threads(obj->barrier);

	free(obj->distributed[inst].links);

	// Saves date
	ccerr << "Saving ... ";

	/* TODO using buffer if possible
	for (site.siteid = (inst + 1); site.siteid <= obj->nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		siteid_t sitenum = site.siteid;
		meta->site_retrieve(&(site));
		assert(site.siteid == sitenum);

		site.in_degree		= obj->in_degree[site.siteid].load(memory_order_relaxed);
		site.out_degree		= obj->out_degree[site.siteid];
		site.siterank		= obj->siterank[site.siteid];

		meta->site_store(&(site));
	} */

#ifndef META_MAX_BUFFERING_SIZE
	for (site.siteid = (inst + 1); site.siteid <= obj->nsites; site.siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		siteid_t sitenum = site.siteid;
		meta->site_retrieve(&(site));
		assert(site.siteid == sitenum);

		site.in_degree		= obj->in_degree[site.siteid].load(memory_order_relaxed);
		site.out_degree		= obj->out_degree[site.siteid];
		site.siterank		= obj->siterank[site.siteid];

		meta->site_store(&(site));
	}
#else
//	size = (META_MAX_BUFFERING_SIZE > sizeof(site_t)) ? (META_MAX_BUFFERING_SIZE / sizeof(site_t)) : META_MIN_BUFFERING_SIZE;

	sites = CBALLOC(site_t, MALLOC, size);

	o = 0;

	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		sites[o].siteid = siteid;
		o++;

		if (o == size)
		{
			if (o > 1)
				assert(meta->site_retrieve_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_retrieve(&sites[0]) == METADDX_OK);

			for (size_t i = 0; i < o; i++)
			{
				assert(sites[i].siteid > 0);
				assert(sites[i].siteid <= obj->nsites);
		
				sites[i].in_degree		= obj->in_degree[sites[i].siteid].load(memory_order_relaxed);
				sites[i].out_degree		= obj->out_degree[sites[i].siteid];
				sites[i].siterank		= obj->siterank[sites[i].siteid];
			}

			// store full buffer
			if (o > 1)
				assert(meta->site_store_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_store(&sites[0]) == METADDX_OK);

			o = 0;
		}
		else if ((siteid + CONF_COLLECTION_DISTRIBUTED) > obj->nsites)
		{
			if (o > 1)
				assert(meta->site_retrieve_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_retrieve(&sites[0]) == METADDX_OK);

			for (size_t i = 0; i < o; i++)
			{
				assert(sites[i].siteid > 0);
				assert(sites[i].siteid <= obj->nsites);
		
				sites[i].in_degree		= obj->in_degree[sites[i].siteid].load(memory_order_relaxed);
				sites[i].out_degree		= obj->out_degree[sites[i].siteid];
				sites[i].siterank		= obj->siterank[sites[i].siteid];
			}

			// store full buffer or last chunck
			if (o > 1)
				assert(meta->site_store_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_store(&sites[0]) == METADDX_OK);

			o = 0;
		}

	}

	free(sites);
#endif

	sync_threads(obj->barrier);

	arguments->meta = NULL;

	return NULL;
}
