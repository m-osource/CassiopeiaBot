/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
/* This is a simple program which uses libstemmer to provide a command
 * line interface for stemming using any of the algorithms provided.
 */

#include "dymddx.h"

// This basic class must be only used inside dymddx.cc
// This is the reason because is declared inside!
class DymLock {

	int rc;

public:

	// ctor
	DymLock(void)
		:rc	(0)
	{
	}

	//
	// Neme: locka_word
	//
	// Description: Allocate memory and create mutex
	//
	// Input:
	//   dymddx - the url index structure
	//   id_instance - id instance
	//
	// Return:
	//
	void a_word(dymddx_t *u, instance_t &id_instance)
	{
		if (u->wlock != NULL && (rc = pthread_mutex_lock(&(u->wlock->locka[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
	void b_word(dymddx_t *u, instance_t &instance)
	{
		if (u->wlock != NULL && (rc = pthread_mutex_lock(&(u->wlock->lockb[instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
	void c_word(dymddx_t *u, instance_t &id_instance)
	{
		if (u->wlock != NULL && (rc = pthread_mutex_lock(&(u->wlock->lockc[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
	void a_stem(dymddx_t *u, instance_t &id_instance)
	{
		if (u->slock != NULL && (rc = pthread_mutex_lock(&(u->slock->locka[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
	void b_stem(dymddx_t *u, instance_t &instance)
	{
		if (u->slock != NULL && (rc = pthread_mutex_lock(&(u->slock->lockb[instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
	void a_gram(dymddx_t *u, instance_t &id_instance)
	{
		if (u->glock != NULL && (rc = pthread_mutex_lock(&(u->glock->locka[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
	void b_gram(dymddx_t *u, instance_t &instance)
	{
		if (u->glock != NULL && (rc = pthread_mutex_lock(&(u->glock->lockb[instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	                                            
	void c_gram(dymddx_t *u, instance_t &id_instance)
	{
		if (u->glock != NULL && (rc = pthread_mutex_lock(&(u->glock->lockc[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
} lock;

// This basic class must be only used inside dymddx.cc
// This is the reason because is declared inside!
class DymUnlock {

	int rc;

public:

	// ctor
	DymUnlock(void)
		:rc	(0)
	{
	}

	//
	// Neme: unlocka_word
	//
	// Description: Allocate memory and create mutex
	//
	// Input:
	//   dymddx - the url index structure
	//   id_instance - id instance
	//
	// Return:
	//
	void a_word(dymddx_t *u, instance_t &id_instance)
	{
		if (u->wlock != NULL && (rc = pthread_mutex_unlock(&(u->wlock->locka[id_instance]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
	}
	                                            
	void b_word(dymddx_t *u, instance_t &instance)
	{
		if (u->wlock != NULL && (rc = pthread_mutex_unlock(&(u->wlock->lockb[instance]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
	}
	                                            
	void c_word(dymddx_t *u, instance_t &id_instance)
	{
		if (u->wlock != NULL && (rc = pthread_mutex_unlock(&(u->wlock->lockc[id_instance]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
	}
	                                            
	void a_stem(dymddx_t *u, instance_t &id_instance)
	{
		if (u->slock != NULL && (rc = pthread_mutex_unlock(&(u->slock->locka[id_instance]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
	}
	                                            
	void b_stem(dymddx_t *u, instance_t &instance)
	{
		if (u->slock != NULL && (rc = pthread_mutex_unlock(&(u->slock->lockb[instance]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
	}
	                                            
	void a_gram(dymddx_t *u, instance_t &id_instance)
	{
		if (u->glock != NULL && (rc = pthread_mutex_unlock(&(u->glock->locka[id_instance]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
	}
	                                            
	void b_gram(dymddx_t *u, instance_t &instance)
	{
		if (u->glock != NULL && (rc = pthread_mutex_unlock(&(u->glock->lockb[instance]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
	}
	                                            
	void c_gram(dymddx_t *u, instance_t &id_instance)
	{
		if (u->glock != NULL && (rc = pthread_mutex_unlock(&(u->glock->lockc[id_instance]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
	}
} unlock;
     
off64_t DYMDDX_WORD_SIZE;
off64_t DYMDDX_STEM_SIZE;
off64_t DYMDDX_GRAM_SIZE;

using namespace std;

//
// Name: dymddx_new
//
// Description:
//   Creates a new url index in the given directory
//
// Input:
//   dirname - directory to create url index
//
// Return:
//   urlindex structure
//
dymddx_t *dymddx_new(const char *dirname)
{
	// Allocate memory
	dymddx_t *u = CBALLOC(dymddx_t, MALLOC, 1);

	assert(CONF_OK);

	u->threads_word_count = 0;
	u->threads_stem_count = 0;
	u->threads_gram_count = 0;
	u->word_count = 0;
	u->stem_count = 0;
	u->gram_count = 0;
	u->wlock = NULL;
	u->slock = NULL;
	u->glock = NULL;

	// Set readonlymode false
	u->readonly	= false;

	// Allocate memory
	u->distributed = CBALLOC(wddx_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		dymddx_thread_function_args_t *args = CBALLOC(dymddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->u = u;
		args->d = (char *)dirname;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[i], NULL, dymddx_thread_function_new, (void *) args))
				die("error creating thread!");
		}
		else
			dymddx_thread_function_new((void *) args); // only one distribution, function is call without thread
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}

	// Return
	return u;	
} 

//
// Name: dymddx_thread_function_new
//
// Description: invoked by 'dymddx_new' as thread
//
// Arguments: a void pointer to dymddx_thread_function_args_t type structure that contain instance and char* directory 
//
// Return: NULL
//
void *dymddx_thread_function_new(void *args)
{
try
{
	cpu_set_t system_cpus;

	dymddx_thread_function_args_t *arguments = (dymddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	dymddx_t *u = arguments->u;
	char *dirname = arguments->d;

	u->distributed[inst].word_hash = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXWORD);
	u->distributed[inst].stem_hash = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXSTEM);
	u->distributed[inst].gram_hash = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXGRAM);

	// Set default values
	u->distributed[inst].word_count = 0;
	u->distributed[inst].word_next_char = 1; // start in 1
	u->distributed[inst].stem_count = 0;
	u->distributed[inst].stem_next_char = 1; // start in 1
	u->distributed[inst].gram_count = 0;
	u->distributed[inst].gram_next_char = 1; // start in 1

	// Work dir
	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
	strcpy(u->distributed[inst].dirname, relative_rem_path);
	free(relative_rem_path);

	// Open files
	char filename[MAX_STR_LEN];

	// word_list
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_WORD_LIST);
	u->distributed[inst].word_list = fopen64(filename, "w+");
	// stem_list
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_STEM_LIST);
	u->distributed[inst].stem_list = fopen64(filename, "w+");
	// gram_list
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_GRAM_LIST);
	u->distributed[inst].gram_list = fopen64(filename, "w+");

	// Create memory area for word names
	DYMDDX_WORD_SIZE = DYMDDX_EXPECTED_WORD_SIZE * CONF_COLLECTION_MAXWORD;
	u->distributed[inst].word = CBALLOC(char, MALLOC, DYMDDX_WORD_SIZE);
	u->distributed[inst].word[0] = '\0';

	// Create memory area for stemming names
	DYMDDX_STEM_SIZE = DYMDDX_EXPECTED_STEM_SIZE * CONF_COLLECTION_MAXSTEM;
	u->distributed[inst].stem = CBALLOC(char, MALLOC, DYMDDX_STEM_SIZE);
	u->distributed[inst].stem[0] = '\0';

	// Create memory area for n-gram names
	DYMDDX_GRAM_SIZE = DYMDDX_EXPECTED_GRAM_SIZE * CONF_COLLECTION_MAXGRAM;
	u->distributed[inst].gram = CBALLOC(char, MALLOC, DYMDDX_GRAM_SIZE);
	u->distributed[inst].gram[0] = '\0';

	// sourceid hash
	u->distributed[inst].sourceid_hash_src = NULL;

	// sourceid_list (source file not needed)
	sprintf(filename, "%s/%s.%s", u->distributed[inst].dirname, DYMDDX_FILENAME_SOURCEID_LIST, "tmp");
	u->distributed[inst].sourceid_list_dst = fopen64(filename, "w+");

	if(u->readonly == false)
	{
		// volatile w_seqs of id
		u->distributed[inst].w_seqs = CBALLOC(sequence_t, CALLOC, 1); 
		u->distributed[inst].w_seqs->next_pad = NULL; // Linked List
		u->distributed[inst].w_seqs->hash = CBALLOC(off64_t, MALLOC, DYMDDX_LANGID_LIST_SIZE);
		memset(u->distributed[inst].w_seqs->hash, -1, DYMDDX_LANGID_LIST_SIZE);
		u->distributed[inst].w_seqs->seq = CBALLOC(w_seq_t, CALLOC, DYMDDX_LANGID_LIST_SIZE);

		// volatile g_seqs of id
		u->distributed[inst].g_seqs = CBALLOC(sequence_t, CALLOC, 1);
		u->distributed[inst].g_seqs->next_pad = NULL; // Linked List
		u->distributed[inst].g_seqs->hash = CBALLOC(off64_t, MALLOC, DYMDDX_WORDID_LIST_SIZE);
		memset(u->distributed[inst].g_seqs->hash, -1, DYMDDX_WORDID_LIST_SIZE);
		u->distributed[inst].g_seqs->seq = CBALLOC(g_seq_t, CALLOC, DYMDDX_WORDID_LIST_SIZE);
	}

	arguments->d = NULL;
	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}
                                            
//
// Name: dymddx_open
//
// Description:
//   Opens a url index in the given directory, or
//   create a new one if necessary.
//
// Input:
//   dirname - directory in which the url index is located
//   readonly - flag for readonly mode
//
// Return:
//   urlindex structure
//
dymddx_t *dymddx_open(const char *dirname, bool readonly)
{
	assert(CONF_COLLECTION_DISTRIBUTED < UCHAR_MAX); // if not, change type

	// The configuration file has to be open
	//assert(CONF_OK);

	bool mainmissing = false;

	for (instance_t instance = 0; instance < CONF_COLLECTION_DISTRIBUTED; instance++)
	{
		// Open the main file
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, instance);
		assert(strlen(relative_rem_path) < MAX_STR_LEN);
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, DYMDDX_FILENAME_ALL);
		free(relative_rem_path);
		FILE *file_all = fopen64(filename, "r");

		// Check if main file is found
		if(file_all == NULL)
		{
			mainmissing = true;
			break;
		}
		else
			fclose(file_all);
	}

	if(mainmissing == true)
	{
		if (readonly == true)
		{
			perror("Opening words index, one or more main files are missing");
			die("Failed to open words index");
		}
		else
		{
			cerr << "Removing old words indexes ... " << endl;
			dymddx_remove(dirname);
			return dymddx_new(dirname);
		}
	}

	// Allocate memory
	dymddx_t *u = CBALLOC(dymddx_t, MALLOC, 1);

	u->word_count = 0;
	u->stem_count = 0;
	u->gram_count = 0;
	u->wlock = NULL;
	u->slock = NULL;
	u->glock = NULL;
	u->readonly	= readonly;

	// Allocate memory
	u->distributed = CBALLOC(wddx_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		dymddx_thread_function_args_t *args = CBALLOC(dymddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->u = u;
		args->d = (char *)dirname;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[i], NULL, dymddx_thread_function_open, (void *) args))
				die("error creating thread!");
		}
		else
			dymddx_thread_function_open((void *) args); // only one distribution, function is call without thread
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		// Update words master counter
		u->word_count += u->distributed[i].word_count;
		// Update stemmings master counter
		u->stem_count += u->distributed[i].stem_count;
		// Update words master counter
		u->gram_count += u->distributed[i].gram_count;
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		// atomic cannot copy to atomic
		// and in open/new function mutex is not needed
		unsigned long long int count = u->word_count;
		u->threads_word_count = (wordid_t)count;

		count = u->stem_count;
		u->threads_stem_count = (stemid_t)count;

		count = u->gram_count;
		u->threads_gram_count = (gramid_t)count;
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		free(threads);

	// Return
	return u;
}

//
// Name: dymddx_thread_function_open
//
// Description: invoked by 'dymddx_open' as thread
//
// Arguments: a void pointer to dymddx_thread_function_args_t type structure 
//
// Return: NULL
//
void *dymddx_thread_function_open(void *args)
{
try
{
	cpu_set_t system_cpus;

	dymddx_thread_function_args_t *arguments = (dymddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	dymddx_t *u = arguments->u;
	char *dirname = arguments->d;

	// Make directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);

	// Open the main file
	char filename[MAX_STR_LEN];
	sprintf(filename, "%s/%s", relative_rem_path, DYMDDX_FILENAME_ALL);
	FILE *file_all = fopen64(filename, "r");

	// Read the main file
	size_t count = fread(&(u->distributed[inst]), sizeof(wddx_t), 1, file_all);

	assert(count == 1);
	fclose(file_all);

	// Copy dir
	strcpy(u->distributed[inst].dirname, relative_rem_path);
	free(relative_rem_path);

	// Open the other files
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_WORD_LIST);

	if(u->readonly)
		u->distributed[inst].word_list = fopen64(filename, "r");
	else
		u->distributed[inst].word_list = fopen64(filename, "a+");

	if(u->distributed[inst].word_list == NULL)
	{
		perror("Opening words index, word list");
		die("Failed to open words index");
	}

	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_STEM_LIST);

	if(u->readonly)
		u->distributed[inst].stem_list = fopen64(filename, "r");
	else
		u->distributed[inst].stem_list = fopen64(filename, "a+");

	if(u->distributed[inst].stem_list == NULL)
	{
		perror("Opening stemmings index, stem list");
		die("Failed to open stemmings index");
	}

	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_GRAM_LIST);

	if(u->readonly)
		u->distributed[inst].gram_list = fopen64(filename, "r");
	else
		u->distributed[inst].gram_list = fopen64(filename, "a+");

	if(u->distributed[inst].gram_list == NULL)
	{
		perror("Opening n-grams index, gram list");
		die("Failed to open n-grams index");
	}

	// Read word names
	DYMDDX_WORD_SIZE = DYMDDX_EXPECTED_WORD_SIZE * CONF_COLLECTION_MAXWORD;

	// Open word's file
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_WORD);
	FILE *word_file = fopen64(filename, "r");

	// Get word's file size
	off64_t file_word_length;
	fseeko(word_file, 0, SEEK_END);
	file_word_length = ftello(word_file);
	assert(file_word_length > 0);
	fseeko(word_file, 0, SEEK_SET);
	if(file_word_length >= DYMDDX_WORD_SIZE)
	{
		perror("The DYMDDX_WORD_SIZE is too small, increase CONF_COLLECTION_MAXWORD or EXPECTED_WORD_SIZE");
		die("Failed to open words index");
	}

	// Allocate memory
	u->distributed[inst].word = CBALLOC(char, MALLOC, DYMDDX_WORD_SIZE);

	// Read
	count = fread(u->distributed[inst].word, file_word_length, 1, word_file);
	assert(count == 1);

	// Close
	fclose(word_file);

	// Read stem names
	DYMDDX_STEM_SIZE = DYMDDX_EXPECTED_STEM_SIZE * CONF_COLLECTION_MAXSTEM;

	// Open stem's file
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_STEM);
	FILE *stem_file = fopen64(filename, "r");

	// Get stemming's file size
	off64_t file_stem_length;
	fseeko(stem_file, 0, SEEK_END);
	file_stem_length = ftello(stem_file);
	assert(file_stem_length > 0);
	fseeko(stem_file, 0, SEEK_SET);
	if(file_stem_length >= DYMDDX_STEM_SIZE)
	{
		perror("The DYMDDX_STEM_SIZE is too small, increase CONF_COLLECTION_MAXSTEM or EXPECTED_STEM_SIZE");
		die("Failed to open stemmings index");
	}

	// Allocate memory
	u->distributed[inst].stem = CBALLOC(char, MALLOC, DYMDDX_STEM_SIZE);

	// Read
	count = fread(u->distributed[inst].stem, file_stem_length, 1, stem_file);
	assert(count == 1);

	// Close
	fclose(stem_file);

	// Read n-gram names
	DYMDDX_GRAM_SIZE = DYMDDX_EXPECTED_GRAM_SIZE * CONF_COLLECTION_MAXGRAM;

	// Open n-gram's file
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_GRAM);
	FILE *gram_file = fopen64(filename, "r");

	// Get gram's file size
	off64_t file_gram_length;
	fseeko(gram_file, 0, SEEK_END);
	file_gram_length = ftello(gram_file);
	assert(file_gram_length > 0);
	fseeko(gram_file, 0, SEEK_SET);
	if(file_gram_length >= DYMDDX_GRAM_SIZE)
	{
		perror("The DYMDDX_GRAM_SIZE is too small, increase CONF_COLLECTION_MAXGRAM or EXPECTED_GRAM_SIZE");
		die("Failed to open n-grams index");
	}

	// Allocate memory
	u->distributed[inst].gram = CBALLOC(char, MALLOC, DYMDDX_GRAM_SIZE);

	// Read
	count = fread(u->distributed[inst].gram, file_gram_length, 1, gram_file);
	assert(count == 1);

	// Close
	fclose(gram_file);

	// Read WORD hash table
	u->distributed[inst].word_hash = CBALLOC(off64_t, MALLOC, CONF_COLLECTION_MAXWORD);

	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_WORD_HASH);

	// Open
	FILE *file_word_hash = fopen64(filename, "r");
	assert(file_word_hash != NULL);

	// Read
	wordid_t words_readed = fread(u->distributed[inst].word_hash, sizeof(off64_t), CONF_COLLECTION_MAXWORD, file_word_hash);
	assert(words_readed == CONF_COLLECTION_MAXWORD);

	// Close
	fclose(file_word_hash);

	// Read STEM hash table
	u->distributed[inst].stem_hash = CBALLOC(off64_t, MALLOC, CONF_COLLECTION_MAXSTEM);

	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_STEM_HASH);

	// Open
	FILE *file_stem_hash = fopen64(filename, "r");
	assert(file_stem_hash != NULL);

	// Read
	stemid_t stems_readed = fread(u->distributed[inst].stem_hash, sizeof(off64_t), CONF_COLLECTION_MAXSTEM, file_stem_hash);
	assert(stems_readed == CONF_COLLECTION_MAXSTEM);

	// Close
	fclose(file_stem_hash);

	// Read GRAM hash table
	u->distributed[inst].gram_hash = CBALLOC(off64_t, MALLOC, CONF_COLLECTION_MAXGRAM);

	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_GRAM_HASH);

	// Open
	FILE *file_gram_hash = fopen64(filename, "r");
	assert(file_gram_hash != NULL);

	// Read
	gramid_t grams_readed = fread(u->distributed[inst].gram_hash, sizeof(off64_t), CONF_COLLECTION_MAXGRAM, file_gram_hash);
	assert(grams_readed == CONF_COLLECTION_MAXGRAM);

	// Close
	fclose(file_gram_hash);

	// Read SOURCEID hash table
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_SOURCEID_HASH);

	// Open
	FILE *file_sourceid_hash = fopen64(filename, "r");

	if (file_sourceid_hash != NULL)
	{
		// Get sourceidhash's file size
		off64_t file_sourceid_hash_src_length;
		fseeko(file_sourceid_hash, 0, SEEK_END);
		file_sourceid_hash_src_length = (ftello(file_sourceid_hash) / sizeof(off64_t));
		assert(file_sourceid_hash_src_length > 0);
		fseeko(file_sourceid_hash, 0, SEEK_SET);

		if(file_sourceid_hash_src_length >= (long long int)(DYMDDX_WORDID_LIST_SIZE * DYMDDX_MAX_WORDID_LIST))
		{
			perror("The DYMDDX_WORDID_LIST_SIZE or DYMDDX_MAX_WORDID_LIST is too small");
			die("Failed to open n-grams index");
		}

		u->distributed[inst].sourceid_hash_src = CBALLOC(off64_t, MALLOC, (file_sourceid_hash_src_length + 1));

		// Read
		sid_t sourceid_readed = fread(u->distributed[inst].sourceid_hash_src, sizeof(off64_t), file_sourceid_hash_src_length, file_sourceid_hash);
		assert(sourceid_readed == (sid_t)file_sourceid_hash_src_length);

		u->distributed[inst].sourceid_hash_src[sourceid_readed] = 0;

		// Close
		fclose(file_sourceid_hash);

		// Other files
		sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_SOURCEID_LIST);
		u->distributed[inst].sourceid_list_src = fopen64(filename, "r");
	}

	if (u->readonly == false)
	{	// open temporary destination file of sourceid (sourceid of a n-gram is wordid)
		sprintf(filename, "%s/%s.%s", u->distributed[inst].dirname, DYMDDX_FILENAME_SOURCEID_LIST, "tmp");
		u->distributed[inst].sourceid_list_dst = fopen64(filename, "a+");

		// Set default values
		u->distributed[inst].w_seq_count = 0;

		// volatile w_seqs of id
		u->distributed[inst].w_seqs = CBALLOC(sequence_t, CALLOC, 1); 
		u->distributed[inst].w_seqs->next_pad = NULL; // Linked List
		u->distributed[inst].w_seqs->hash = CBALLOC(off64_t, MALLOC, DYMDDX_LANGID_LIST_SIZE);
		memset(u->distributed[inst].w_seqs->hash, -1, DYMDDX_LANGID_LIST_SIZE);
		u->distributed[inst].w_seqs->seq = CBALLOC(w_seq_t, CALLOC, DYMDDX_LANGID_LIST_SIZE);

		// Set default values
		u->distributed[inst].g_seq_count = 0;

		// volatile g_seqs of id
		u->distributed[inst].g_seqs = CBALLOC(sequence_t, CALLOC, 1);
		u->distributed[inst].g_seqs->next_pad = NULL; // Linked List
		u->distributed[inst].g_seqs->hash = CBALLOC(off64_t, MALLOC, DYMDDX_WORDID_LIST_SIZE);
		memset(u->distributed[inst].g_seqs->hash, -1, DYMDDX_WORDID_LIST_SIZE);
		u->distributed[inst].g_seqs->seq = CBALLOC(g_seq_t, CALLOC, DYMDDX_WORDID_LIST_SIZE);
	}
	else
	{
		u->distributed[inst].w_seqs = NULL;
		u->distributed[inst].g_seqs = NULL;
	}

	arguments->d = NULL;
	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}
                                            
//
// Name: dymddx_setmutex
//
// Description: Allocate memory and create mutex
//
// Input:
//   dymddx - the url index structure
//   dymmutex_t structure pointer to wlock
//   dymmutex_t structure pointer to slock
//   dymmutex_t structure pointer to glock
//
// Return:
//
void dymddx_setmutex(dymddx_t *u, dymmutex_t **wlock, dymmutex_t **slock, dymmutex_t **glock)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1 && u->readonly == false)
	{
		*wlock = CBALLOC(dymmutex_t, MALLOC, 1);
		(*wlock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		(*wlock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		(*wlock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		*slock = CBALLOC(dymmutex_t, MALLOC, 1);
		(*slock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		(*slock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		(*slock)->lockc = NULL;
		*glock = CBALLOC(dymmutex_t, MALLOC, 1);
		(*glock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		(*glock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		(*glock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
		{
			(*wlock)->locka[i] = PTHREAD_MUTEX_INITIALIZER;
			(*wlock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
			(*wlock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER;
			(*slock)->locka[i] = PTHREAD_MUTEX_INITIALIZER;
			(*slock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
			(*glock)->locka[i] = PTHREAD_MUTEX_INITIALIZER;
			(*glock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
			(*glock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER;
		}

		u->wlock = *wlock;
		u->slock = *slock;
		u->glock = *glock;
	}
}
                                            
//
// Name: dymddx_resolve_word
//
// Description:
//   Verify a word name and add it if necessary.
//
// Input:
//   dymddx - the url index structure
//   word - the word to check
//   wordid - the word id to return
//   langid - the source id lang of word
//   readonly - do not write anything if function (even in the case algorithm has been to write to disk)
//
// Output:
//   wordid - wordid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   DYMDDX_EXISTENT - the word existed
//   DYMDDX_CREATED_WORD - the word was added
//   DYMDDX_NOT_FOUND - the word is not known and was not created
//   DYMDDX_BUSY - with mutex use
//   DYMDDX_CREATED_STEM_SLOW_DOWN - tell calling program to increase wait to call this function (needed for multithread)
//
dymddx_status_t dymddx_resolve_word(dymddx_t *u, const char *word, wordid_t *wordid, Stemming *language, bool readonly)
{
	assert(u != NULL);
//	assert((u->readonly == false && u->wlock != NULL) || (u->readonly == true && u->wlock == NULL));

	if(language == NULL)
		return DYMDDX_NOT_FOUND;

	size_t wlen = strlen(word);
	assert(wlen > 0);

	wordid_t bucket = 0;
	wordid_t wordid_check = 0;

	// Check if the word exists
	wordid_check = dymddx_check_word(u, word, &(bucket));

	instance_t instance = (bucket % CONF_COLLECTION_DISTRIBUTED);

	if(wordid_check > 0)
	{
		if(wordid != NULL)
		{
			*wordid	= wordid_check;

			instance_t id_instance = ((*wordid - 1) % CONF_COLLECTION_DISTRIBUTED);

			// append w_seqs
			if ((u->readonly == false && readonly == false) && language != NULL)
			{
				lock.c_word(u, id_instance);
				dymddx_create_lang_element(u, wordid, language);
				unlock.c_word(u, id_instance);

				if((u->distributed[id_instance].w_seq_count + 1) > (off64_t)(DYMDDX_LANGID_LIST_SIZE * DYMDDX_MAX_LANGID_LIST))
				{
					cerr << "Distributed volatile list of langid is small. Increase DYMDDX_LANGID_LIST_SIZE or DYMDDX_MAX_LANGID_LIST!" << endl;
					return(DYMDDX_ERROR);
				}

				return DYMDDX_EXISTENT;
			}
		}

		return DYMDDX_EXISTENT;
	}

	if (u->readonly == true || readonly == true || wordid == NULL)
	{
		unlock.b_word(u, instance);
		return DYMDDX_NOT_FOUND;
	}
	else // new id to insert
	{
		instance_t id_instance;

		// We calculate id_instance and get the next wordid
		if (u->wlock != NULL)
			*wordid = (++u->threads_word_count);
		else
			*wordid = (u->word_count + 1);

		id_instance = ((*wordid - 1) % CONF_COLLECTION_DISTRIBUTED);

		// Locking needed mutex
		lock.a_word(u, id_instance);

		if((u->distributed[id_instance].word_count + 1) > CONF_COLLECTION_MAXWORD)
		{
			unlock.a_word(u, id_instance);
			unlock.b_word(u, instance);
			cerr << "Distributed Index is small. Increase CONF_COLLECTION_MAXWORD!" << endl;
			return(DYMDDX_ERROR);
		}

		// Get position in word_hash
		stemid_t hash_pos = (bucket / CONF_COLLECTION_DISTRIBUTED);

		// Increment local word count
		++(u->distributed[id_instance].word_count);

		// FIRST: Store string
		memcpy(u->distributed[instance].word + u->distributed[instance].word_next_char, word, wlen + 1);

		// Store wordid
		memcpy(u->distributed[instance].word + u->distributed[instance].word_next_char + wlen + 1, wordid, sizeof(wordid_t));

		// Put in bucket
		u->distributed[instance].word_hash[hash_pos] = u->distributed[instance].word_next_char;

		// Save in list of words
		dymlist_word_t *position = CBALLOC(dymlist_word_t, CALLOC, 1);
		position->hash_pos = hash_pos;
		position->bucket_instance = instance;
		fwrite(position, sizeof(dymlist_word_t), 1, u->distributed[id_instance].word_list);
		free(position);

		// Unlocking unneeded mutex
		unlock.a_word(u, id_instance);

		// Move char pointer
		u->distributed[instance].word_next_char = u->distributed[instance].word_next_char + wlen + 1 + sizeof(wordid_t);

		if(u->distributed[instance].word_next_char > DYMDDX_WORD_SIZE)
		{
			unlock.b_word(u, instance);
			cerr << "Words memory area full on index " << instance << " !" << endl;
			cerr << "Increase CONF_COLLECTION_MAXWORD or EXPECTED_WORD_SIZE" << endl;
			return(DYMDDX_ERROR);
		}

		// Unlocking unneeded mutex
		unlock.b_word(u, instance);

		// Increase counter
		u->word_count++;

		// put first data seq
		if (language != NULL)
		{
			lock.c_word(u, id_instance);
			dymddx_create_lang_element(u, wordid, language);
			unlock.c_word(u, id_instance);

			if((u->distributed[id_instance].w_seq_count + 1) > (off64_t)(DYMDDX_LANGID_LIST_SIZE * DYMDDX_MAX_LANGID_LIST))
			{
				cerr << "Distributed volatile list of langid is small. Increase DYMDDX_LANGID_LIST_SIZE or DYMDDX_MAX_LANGID_LIST!" << endl;
				return(DYMDDX_ERROR);
			}
		}
	}

	// Return
	return DYMDDX_CREATED_WORD;
}

//
// Name: dymddx_resolve_stem
//
// Description:
//   Verify a stemming name and add it if necessary (basic version of algorithm but multithread)
//
// Input:
//   dymddx - the url index structure
//   stem - the stemming to check
//   stemid - the stem id to return
//   readonly - do not write anything if function (even in the case algorithm has been to write to disk)
//
// Output:
//   stemid - stemid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   DYMDDX_EXISTENT - the stem existed
//   DYMDDX_CREATED_STEM - the stem was added
//   DYMDDX_NOT_FOUND - the stem is not known and was not created
//   DYMDDX_BUSY - with mutex use
//   DYMDDX_CREATED_STEM_SLOW_DOWN - tell calling program to increase wait to call this function (needed for multithread)
//
dymddx_status_t dymddx_resolve_stem(dymddx_t *u, const char *stem, stemid_t *stemid, bool readonly)
{
	assert(u != NULL);
//	assert((u->readonly == false && u->slock != NULL) || (u->readonly == true && u->slock == NULL));

	size_t slen = strlen(stem);
	assert(slen > 0);

	stemid_t bucket = 0;
	stemid_t stemid_check = 0;

	// Check if the stem exists
	stemid_check = dymddx_check_stem(u, stem, &(bucket));

	instance_t instance = (bucket % CONF_COLLECTION_DISTRIBUTED);

	if(stemid_check > 0)
	{
		if(stemid != NULL)
			*stemid	= stemid_check;

		return DYMDDX_EXISTENT;
	}

	if (u->readonly == true || readonly == true || stemid == NULL)
	{
		unlock.b_stem(u, instance);
		return DYMDDX_NOT_FOUND;
	}
	else // new id to insert
	{
		instance_t id_instance;

		// We calculate id_instance and get the next stemid
		if (u->slock != NULL)
			*stemid = (++u->threads_stem_count);
		else
			*stemid = (u->stem_count + 1);

		id_instance = ((*stemid - 1) % CONF_COLLECTION_DISTRIBUTED);

		// Locking needed mutex
		lock.a_stem(u, id_instance);

		if((u->distributed[id_instance].stem_count + 1) > CONF_COLLECTION_MAXSTEM)
		{
			unlock.a_stem(u, id_instance);
			unlock.b_stem(u, instance);
			cerr << "Distributed Index is small. Increase CONF_COLLECTION_MAXSTEM!" << endl;
			return(DYMDDX_ERROR);
		}

		// Get position in stem_hash
		stemid_t hash_pos = (bucket / CONF_COLLECTION_DISTRIBUTED);

		// Increment local stem count
		++(u->distributed[id_instance].stem_count);

		// FIRST: Store string
		memcpy(u->distributed[instance].stem + u->distributed[instance].stem_next_char, stem, slen + 1);

		// Store stemid
		memcpy(u->distributed[instance].stem + u->distributed[instance].stem_next_char + slen + 1, stemid, sizeof(stemid_t));

		// Put in bucket
		u->distributed[instance].stem_hash[hash_pos] = u->distributed[instance].stem_next_char;

		// Save in list of stems
		dymlist_stem_t *position = CBALLOC(dymlist_stem_t, CALLOC, 1);
		position->hash_pos = hash_pos;
		position->bucket_instance = instance;
		fwrite(position, sizeof(dymlist_stem_t), 1, u->distributed[id_instance].stem_list);
		free(position);

		// Unlocking unneeded mutex
		unlock.a_stem(u, id_instance);

		// Move char pointer
		u->distributed[instance].stem_next_char = u->distributed[instance].stem_next_char + slen + 1 + sizeof(stemid_t);

		if(u->distributed[instance].stem_next_char > DYMDDX_STEM_SIZE)
		{
			unlock.b_stem(u, instance);
			cerr << "Stemmings memory area full on index " << instance << " !" << endl;
			cerr << "Increase CONF_COLLECTION_MAXSTEM or EXPECTED_STEM_SIZE" << endl;
			return(DYMDDX_ERROR);
		}

		// Increase counter
		u->stem_count++;

		unlock.b_stem(u, instance);

	}

	// Return
	return DYMDDX_CREATED_STEM;
}

//
// Name: dymddx_resolve_gram
//
// Description:
//   Verify a n-gram name and add it if necessary.
//
// Input:
//   dymddx - the url index structure
//   gram - the n-gram to check
//   gramid - the n-gram id to return
//   wordid - the source id word of n-gram
//   readonly - do not write anything if function (even in the case algorithm has been to write to disk)
//
// Output:
//   gramid - gramid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   DYMDDX_EXISTENT - the n-gram existed
//   DYMDDX_CREATED_GRAM - the n-gram was added
//   DYMDDX_NOT_FOUND - the n-gram is not known and was not created
//   DYMDDX_BUSY - with mutex use
//   DYMDDX_CREATED_STEM_SLOW_DOWN - tell calling program to increase wait to call this function (needed for multithread)
//
dymddx_status_t dymddx_resolve_gram(dymddx_t *u, const char *gram, gramid_t *gramid, wordid_t *wordid, bool readonly)
{
	assert(u != NULL);
//	assert((u->readonly == false && u->glock != NULL) || (u->readonly == true && u->glock == NULL));

	if(gramid == NULL || wordid == NULL)
		return DYMDDX_NOT_FOUND;

	size_t glen = strlen(gram);
	assert(glen > 0);

	gramid_t bucket = 0;
	gramid_t gramid_check = 0;

	// Check if the gram exists
	gramid_check = dymddx_check_gram(u, gram, &(bucket));

	instance_t instance = (bucket % CONF_COLLECTION_DISTRIBUTED);

	if(gramid_check > 0)
	{
		if(gramid != NULL)
		{
			*gramid	= gramid_check;

			instance_t id_instance = ((*gramid - 1) % CONF_COLLECTION_DISTRIBUTED);

			// append g_seqs
			if ((u->readonly == false && readonly == false) && wordid != NULL)
			{
				lock.c_gram(u, id_instance);
				dymddx_create_word_element(u, gramid, wordid);
				unlock.c_gram(u, id_instance);

				if((u->distributed[id_instance].g_seq_count + 1) > (off64_t)(DYMDDX_WORDID_LIST_SIZE * DYMDDX_MAX_WORDID_LIST))
				{
					cerr << "Distributed volatile list of langid is small. Increase DYMDDX_WORDID_LIST_SIZE or DYMDDX_MAX_WORDID_LIST!" << endl;
					return(DYMDDX_ERROR);
				}

				return DYMDDX_EXISTENT;
			}
		}

		return DYMDDX_EXISTENT;
	}

	if (u->readonly == true || readonly == true || gramid == NULL)
	{
		unlock.b_gram(u, instance);
		return DYMDDX_NOT_FOUND;
	}
	else // new id to insert
	{
		instance_t id_instance;

		// We calculate id_instance and get the next gramid
		if (u->glock != NULL)
			*gramid = (++u->threads_gram_count);
		else
			*gramid = (u->gram_count + 1);

		id_instance = ((*gramid - 1) % CONF_COLLECTION_DISTRIBUTED);

		// Locking needed mutex
		lock.a_gram(u, id_instance);

		if((u->distributed[id_instance].gram_count + 1) > CONF_COLLECTION_MAXGRAM)
		{
			unlock.a_gram(u, id_instance);
			unlock.b_gram(u, instance);
			cerr << "Distributed Index is small. Increase CONF_COLLECTION_MAXGRAM!" << endl;
			return(DYMDDX_ERROR);
		}

		// Get position in stem_hash
		stemid_t hash_pos = (bucket / CONF_COLLECTION_DISTRIBUTED);

		// Increment local gram count
		++(u->distributed[id_instance].gram_count);

		// FIRST: Store string
		memcpy(u->distributed[instance].gram + u->distributed[instance].gram_next_char, gram, glen + 1);

		// Store gramid
		memcpy(u->distributed[instance].gram + u->distributed[instance].gram_next_char + glen + 1, gramid, sizeof(gramid_t));

		// Put in bucket
		u->distributed[instance].gram_hash[hash_pos] = u->distributed[instance].gram_next_char;

		// Save in list of grams
		dymlist_gram_t *position = CBALLOC(dymlist_gram_t, CALLOC, 1);
		position->hash_pos = hash_pos;
		position->bucket_instance = instance;
		fwrite(position, sizeof(dymlist_gram_t), 1, u->distributed[id_instance].gram_list);
		free(position);

		// Unlocking unneeded mutex
		unlock.a_gram(u, id_instance);

		// Move char pointer
		u->distributed[instance].gram_next_char = u->distributed[instance].gram_next_char + glen + 1 + sizeof(gramid_t);

		if(u->distributed[instance].gram_next_char > DYMDDX_GRAM_SIZE)
		{
			unlock.b_gram(u, instance);
			cerr << "N-grams memory area full on index " << instance << " !" << endl;
			cerr << "Increase CONF_COLLECTION_MAXGRAM or EXPECTED_GRAM_SIZE" << endl;
			return(DYMDDX_ERROR);
		}

		// Unlocking unneeded mutex
		unlock.b_gram(u, instance);

		// Increase counter
		u->gram_count++;

		// put first data seq
		if (wordid != NULL)
		{
			lock.c_gram(u, id_instance);
			dymddx_create_word_element(u, gramid, wordid);
			unlock.c_gram(u, id_instance);

			if((u->distributed[id_instance].g_seq_count + 1) > (off64_t)(DYMDDX_WORDID_LIST_SIZE * DYMDDX_MAX_WORDID_LIST))
			{
				cerr << "Distributed volatile list of langid is small. Increase DYMDDX_WORDID_LIST_SIZE or DYMDDX_MAX_WORDID_LIST!" << endl;
				return(DYMDDX_ERROR);
			}
		}
	}

	// Return
	return DYMDDX_CREATED_GRAM;
}

//
// Name: dymddx_create_lang_element
//
// Description:
//   Create or modify element of already existing or new sequence
//
// Input:
//   dymddx - the url index structure
//   wordid - the word id to return
//   language - the id lang of word
//
// Output:
//
// Return:
//
void dymddx_create_lang_element(dymddx_t *u, wordid_t *wordid, Stemming *language)
{
	assert(u != NULL);
	assert (*wordid > 0);

	instance_t id_instance = ((*wordid - 1) % CONF_COLLECTION_DISTRIBUTED);
	wordid_t hash_pos = ((*wordid - 1) / CONF_COLLECTION_DISTRIBUTED); // N.B. hash_pos resta immutato
	wordid_t pad_hash_pos = (hash_pos % DYMDDX_LANGID_LIST_SIZE); // N.B. pad_hash_pos resta immutato
	unsigned short pad = 0;
	off64_t reloff = 0;
	w_seq_t data;

	off64_t *hash_pad = NULL; // pad in cui si trova l'hash con l'offset relativo alla prima sequenza
	bool allocated = false;

	// fix the start of sequences
	sequence_t *pad_of_w_seqs = u->distributed[id_instance].w_seqs;
	assert(pad_of_w_seqs != NULL);

	// FIRST step, go through Linked List until stop pad of hash and ...
	for (pad = 0; pad < (hash_pos / DYMDDX_LANGID_LIST_SIZE); pad++)
	{
		sequence_t *temp_ptr = pad_of_w_seqs;
		pad_of_w_seqs = pad_of_w_seqs->next_pad;

		if (pad_of_w_seqs == NULL)
		{
			sequence_t *next_ptr = CBALLOC(sequence_t, CALLOC, 1);
			next_ptr->next_pad = NULL; // Linked List
			next_ptr->hash = CBALLOC(off64_t, MALLOC, DYMDDX_LANGID_LIST_SIZE); 
			memset(next_ptr->hash, -1, DYMDDX_LANGID_LIST_SIZE);
			next_ptr->seq = CBALLOC(w_seq_t, CALLOC, DYMDDX_LANGID_LIST_SIZE);
			temp_ptr->next_pad = next_ptr; // before move pointer create link to new
			pad_of_w_seqs = next_ptr;
			allocated = true;
		}
		else if (pad_of_w_seqs->hash == NULL)
		{
			pad_of_w_seqs->hash = CBALLOC(off64_t, MALLOC, DYMDDX_LANGID_LIST_SIZE); 
			memset(pad_of_w_seqs->hash, -1, DYMDDX_LANGID_LIST_SIZE);
		}
	}

	// ... link hash to correct pad
	hash_pad = pad_of_w_seqs->hash; // found pad of first sequence
	assert(hash_pad != NULL);

	if (hash_pad[pad_hash_pos] > -1) // relative hash position have a value
		goto append_element_to_sequence;

	// Create new element for new sequence

	hash_pad[pad_hash_pos] = u->distributed[id_instance].w_seq_count; // assign start offset to hash
	reloff = (hash_pad[pad_hash_pos] % DYMDDX_LANGID_LIST_SIZE); // relative first sequence's offset at current pad

	// SECOND step, go through Linked List until stop to last pad to start of first sequence (that can be the same pad of hash) and ...
	while (pad_of_w_seqs->next_pad != NULL)
	{
		pad_of_w_seqs = pad_of_w_seqs->next_pad;
		pad++;
	}

	if (pad > 0 && reloff == 0 && allocated == false)
	{
		sequence_t *next_ptr = CBALLOC(sequence_t, CALLOC, 1);
		next_ptr->next_pad = NULL; // Linked List
		next_ptr->seq = CBALLOC(w_seq_t, CALLOC, DYMDDX_LANGID_LIST_SIZE);
		pad_of_w_seqs->next_pad = next_ptr; // before move pointer create link to new
		pad_of_w_seqs = next_ptr;
		pad++;
	}

	data.lang = *language;
//	data.wordid = *wordid;
	data.next_offset = 0;
	data.count = 1; // how many times word is present with language
	assert(pad_of_w_seqs != NULL);
	static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff] = data;
	u->distributed[id_instance].w_seq_count++;

	return; // sequence (with one element) created

	append_element_to_sequence: // append element to existant sequence

	// ... link hash to correct pad
	reloff = (hash_pad[pad_hash_pos] % DYMDDX_LANGID_LIST_SIZE); // relative first sequence's offset at current pad
	bool end_of_search = false;

	// SECOND step, go through Linked List until stop pad of start of first sequence (that can be the same pad of hash) and ...
	while (pad < (hash_pad[pad_hash_pos] / DYMDDX_LANGID_LIST_SIZE))
	{
		pad_of_w_seqs = pad_of_w_seqs->next_pad;
		assert(pad_of_w_seqs != NULL);
		pad++;
	}

	sequence_t *temp_ptr = pad_of_w_seqs;

	// THIRD step, go through Linked List and iterate trougth sequences
	while (end_of_search == false) // iterate trougth sequences in same pad to find correct language
	{
//		if (pad_of_w_seqs->seq[reloff].wordid != *wordid)
//			cout << "alarm wordid " << pad_of_w_seqs->seq[reloff].wordid << endl;

//		assert(pad_of_w_seqs->seq[reloff].wordid == *wordid); // uso debug

		if (static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].lang == *language)
		{
			if (static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].count < ULLONG_MAX)
				static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].count++;

			return;
		}

		// search completed and language not found
		if (static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].next_offset == 0)
		{
			static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].next_offset = u->distributed[id_instance].w_seq_count;
			end_of_search = true;
			break;
		}

		// next offset is in one of the following pad
		if ((static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].next_offset / DYMDDX_LANGID_LIST_SIZE) > pad)
		{
			off64_t next_count = static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].next_offset;

			reloff = (next_count % DYMDDX_LANGID_LIST_SIZE);

			// skip to rigth pad
			while (pad < (next_count / DYMDDX_LANGID_LIST_SIZE))
			{
				pad_of_w_seqs = pad_of_w_seqs->next_pad; // next pad
				pad++;
			}

			continue;
		}

		reloff = (static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].next_offset % DYMDDX_LANGID_LIST_SIZE);
	}

	// skip to rigth pad before append element
	while (pad < (u->distributed[id_instance].w_seq_count / DYMDDX_LANGID_LIST_SIZE))
	{
		temp_ptr = pad_of_w_seqs;
		pad_of_w_seqs = pad_of_w_seqs->next_pad; // next pad
		pad++;
	}

	// new sequence need of new pad and it must be allocated
	if (pad_of_w_seqs == NULL)
	{
		sequence_t *next_ptr = CBALLOC(sequence_t, CALLOC, 1);
		next_ptr->next_pad = NULL; // Linked List
		next_ptr->seq = CBALLOC(w_seq_t, CALLOC, DYMDDX_LANGID_LIST_SIZE);
		temp_ptr->next_pad = next_ptr; // before move pointer create link to new
		pad_of_w_seqs = next_ptr;
	}

	// write new sequence in rigth pad
	data.lang = *language;
//	data.wordid = *wordid;
	data.next_offset = 0;
	data.count = 1; // ++; // how many times word is present with language
	assert(pad_of_w_seqs != NULL);
	static_cast<w_seq_t *>(pad_of_w_seqs->seq)[(u->distributed[id_instance].w_seq_count % DYMDDX_LANGID_LIST_SIZE)] = data;
	u->distributed[id_instance].w_seq_count++;
}

//
// Name: dymddx_create_word_element
//
// Description:
//   Create or modify element of already existing or new sequence
//
// Input:
//   dymddx - the url index structure
//   gramid - the word id to return
//   word - the source id word of gram
//
// Output:
//
// Return:
//
void dymddx_create_word_element(dymddx_t *u, gramid_t *gramid, wordid_t *wordid)
{
	assert(u != NULL);
	assert (*gramid > 0);
	assert (*wordid > 0);

	instance_t id_instance = ((*gramid - 1) % CONF_COLLECTION_DISTRIBUTED);

	gramid_t hash_pos = ((*gramid - 1) / CONF_COLLECTION_DISTRIBUTED); // N.B. hash_pos resta immutato
	gramid_t pad_hash_pos = (hash_pos % DYMDDX_WORDID_LIST_SIZE); // N.B. pad_hash_pos resta immutato
	unsigned short pad = 0;
	off64_t reloff = 0;
	g_seq_t data;

	off64_t *hash_pad = NULL; // pad in cui si trova l'hash con l'offset relativo alla prima sequenza
	bool allocated = false;

	// fix the start of sequences
	sequence_t *pad_of_g_seqs = u->distributed[id_instance].g_seqs;
	assert(pad_of_g_seqs != NULL);

	// FIRST step, go through Linked List until stop pad of hash and ...
	for (pad = 0; pad < (hash_pos / DYMDDX_WORDID_LIST_SIZE); pad++)
	{
		sequence_t *temp_ptr = pad_of_g_seqs;
		pad_of_g_seqs = pad_of_g_seqs->next_pad;

		if (pad_of_g_seqs == NULL)
		{
			sequence_t *next_ptr = CBALLOC(sequence_t, CALLOC, 1);
			next_ptr->next_pad = NULL; // Linked List
			next_ptr->hash = CBALLOC(off64_t, MALLOC, DYMDDX_WORDID_LIST_SIZE); 
			memset(next_ptr->hash, -1, DYMDDX_WORDID_LIST_SIZE);
			next_ptr->seq = CBALLOC(g_seq_t, CALLOC, DYMDDX_WORDID_LIST_SIZE);
			temp_ptr->next_pad = next_ptr; // before move pointer create link to new
			pad_of_g_seqs = next_ptr;
			allocated = true;
		}
		else if (pad_of_g_seqs->hash == NULL)
		{
			pad_of_g_seqs->hash = CBALLOC(off64_t, MALLOC, DYMDDX_WORDID_LIST_SIZE); 
			memset(pad_of_g_seqs->hash, -1, DYMDDX_WORDID_LIST_SIZE);
		}
	}

	// ... link hash to correct pad
	hash_pad = pad_of_g_seqs->hash; // found pad of first sequence
	assert(hash_pad != NULL);

	if (hash_pad[pad_hash_pos] > -1) // relative hash position have a value
		goto append_element_to_sequence;

	// Create new element for new sequence
	hash_pad[pad_hash_pos] = u->distributed[id_instance].g_seq_count; // assign start offset to hash
	reloff = (hash_pad[pad_hash_pos] % DYMDDX_WORDID_LIST_SIZE); // relative first sequence's offset at current pad

	// SECOND step, go through Linked List until stop to last pad to start of first sequence (that can be the same pad of hash) and ...
	while (pad_of_g_seqs->next_pad != NULL)
	{
		pad_of_g_seqs = pad_of_g_seqs->next_pad;
		pad++;
	}

	if (pad > 0 && reloff == 0 && allocated == false)
	{
		sequence_t *next_ptr = CBALLOC(sequence_t, CALLOC, 1);
		next_ptr->next_pad = NULL; // Linked List
		next_ptr->seq = CBALLOC(g_seq_t, CALLOC, DYMDDX_WORDID_LIST_SIZE);
		pad_of_g_seqs->next_pad = next_ptr; // before move pointer create link to new
		pad_of_g_seqs = next_ptr;
		pad++;
	}

	data.id = (sid_t)*wordid;
//	data.gramid = *gramid; // uso debug
	data.next_offset = 0;
//	data.count = 1; // how many times gram is present with wordid
	assert(pad_of_g_seqs != NULL);
	static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff] = data;
	u->distributed[id_instance].g_seq_count++;

	return; // sequence (with one element) created

	append_element_to_sequence: // append element to existant sequence

	// ... link hash to correct pad
	reloff = (hash_pad[pad_hash_pos] % DYMDDX_WORDID_LIST_SIZE); // relative first sequence's offset at current pad
	bool end_of_search = false;

	// SECOND step, go through Linked List until stop pad of start of first sequence (that can be the same pad of hash) and ...
	while (pad < (hash_pad[pad_hash_pos] / DYMDDX_WORDID_LIST_SIZE))
	{
		pad_of_g_seqs = pad_of_g_seqs->next_pad;
		assert(pad_of_g_seqs != NULL);
		pad++;
	}

	sequence_t *temp_ptr = pad_of_g_seqs;

	// THIRD step, go through Linked List and iterate trougth sequences
	while (end_of_search == false) // iterate trougth sequences in same pad to find correct wordid
	{
		// if (static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].gramid != *gramid)
		//	cout << "alarm gramid " << static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].gramid << endl;

		// assert(static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].gramid == *gramid); // uso debug

		if (static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].id == *wordid)
		{
//			if (static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].count < ULLONG_MAX)
//				static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].count++;

			return;
		}

		// search completed and wordid not found
		if (static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset == 0)
		{
			static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset = u->distributed[id_instance].g_seq_count;
			end_of_search = true;
			break;
		}

		// next offset is in one of the following pad
		if ((static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset / DYMDDX_WORDID_LIST_SIZE) > pad)
		{
			off64_t next_count = static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset;

			reloff = (next_count % DYMDDX_WORDID_LIST_SIZE);

			// skip to rigth pad
			while (pad < (next_count / DYMDDX_WORDID_LIST_SIZE))
			{
				pad_of_g_seqs = pad_of_g_seqs->next_pad; // next pad
				pad++;
			}

			continue;
		}

		reloff = (static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset % DYMDDX_WORDID_LIST_SIZE);
	}

	// skip to rigth pad before append element
	while (pad < (u->distributed[id_instance].g_seq_count / DYMDDX_WORDID_LIST_SIZE))
	{
		temp_ptr = pad_of_g_seqs;
		pad_of_g_seqs = pad_of_g_seqs->next_pad; // next pad
		pad++;
	}

	// new sequence need of new pad and it must be allocated
	if (pad_of_g_seqs == NULL)
	{
		sequence_t *next_ptr = CBALLOC(sequence_t, CALLOC, 1);
		next_ptr->next_pad = NULL; // Linked List
		next_ptr->seq = CBALLOC(g_seq_t, CALLOC, DYMDDX_WORDID_LIST_SIZE);
		temp_ptr->next_pad = next_ptr; // before move pointer create link to new
		pad_of_g_seqs = next_ptr;
	}

	// write new sequence in rigth pad
	data.id = (sid_t)*wordid;
//	data.gramid = *gramid; //
	data.next_offset = 0;
//	data.count = 1; // ++; // how many times gram is present with wordid
	assert(pad_of_g_seqs != NULL);
	static_cast<g_seq_t *>(pad_of_g_seqs->seq)[(u->distributed[id_instance].g_seq_count % DYMDDX_WORDID_LIST_SIZE)] = data;
	u->distributed[id_instance].g_seq_count++;
}

//
// Name: dymddx_get_candidate_lang
//
// Description:
//   Verify a word name and add it if necessary.
//
// Input:
//   dymddx - the url index structure
//   wordid - the word id to return
//
// Output:
//   Stemming - language with major ranking
//
// Return:
//   the supported stemming language
//
Stemming dymddx_get_candidate_lang(dymddx_t *u, wordid_t *wordid)
{
	assert(u != NULL);
	assert (*wordid > 0);

	instance_t id_instance = ((*wordid - 1) % CONF_COLLECTION_DISTRIBUTED);
	wordid_t hash_pos = ((*wordid - 1) / CONF_COLLECTION_DISTRIBUTED); // N.B. hash_pos resta immutato
	wordid_t pad_hash_pos = (hash_pos % DYMDDX_LANGID_LIST_SIZE); // N.B. pad_hash_pos resta immutato
	off64_t *hash_pad = NULL; // pad in cui si trova l'hash con l'offset relativo alla prima sequenza
	unsigned short pad = 0;
	bool end_of_search = false;
	unsigned long long int sum_lang[SUPPORTED_STEM_LANGUAGES + 1];
	memset(sum_lang, 0, sizeof(unsigned long long int) * (SUPPORTED_STEM_LANGUAGES + 1));

	// fix the start of sequences
	sequence_t *pad_of_w_seqs = u->distributed[id_instance].w_seqs;
	assert(pad_of_w_seqs != NULL);

	// FIRST step, go through Linked List until stop pad of hash and ...
	while (pad < (hash_pos / DYMDDX_LANGID_LIST_SIZE))
	{
		pad_of_w_seqs = pad_of_w_seqs->next_pad;
		assert(pad_of_w_seqs != NULL);
		pad++;
	}

	// ... link hash to correct pad
	hash_pad = pad_of_w_seqs->hash;
	assert(hash_pad != NULL);
	off64_t reloff = (hash_pad[pad_hash_pos] % DYMDDX_LANGID_LIST_SIZE); // relative first sequence's offset at current pad

	// SECOND step, go through Linked List until stop pad of start of first sequence (that can be the same pad of hash) and ...
	while (pad < (hash_pad[pad_hash_pos] / DYMDDX_LANGID_LIST_SIZE))
	{
		pad_of_w_seqs = pad_of_w_seqs->next_pad;
		assert(pad_of_w_seqs != NULL);
		pad++;
	}

	// THIRD step, go through Linked List and iterate trougth sequences
	while (end_of_search == false) // iterate trougth sequences in same pad to find correct language
	{
//		if (static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].wordid != *wordid)
//			cout << "alarm wordid " << static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].wordid << endl;

//		assert(static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].wordid == *wordid); // uso debug

		sum_lang[(unsigned char)(static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].lang)] = static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].count; // FIXME

		// search completed and language not found
		if (static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].next_offset == 0)
		{
			end_of_search = true;
			break;
		}

		// next offset is in one of the following pad
		if ((static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].next_offset / DYMDDX_LANGID_LIST_SIZE) > pad)
		{
			off64_t next_count = static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].next_offset;

			reloff = (next_count % DYMDDX_LANGID_LIST_SIZE);

			// skip to rigth pad
			while (pad < (next_count / DYMDDX_LANGID_LIST_SIZE))
			{
				pad_of_w_seqs = pad_of_w_seqs->next_pad; // next pad
				pad++;
			}

			continue;
		}

		reloff = (static_cast<w_seq_t *>(pad_of_w_seqs->seq)[reloff].next_offset % DYMDDX_LANGID_LIST_SIZE);
	}

	Stemming        language = Stemming::UNKNOWN;

	unsigned long long int max_value = 0;
	for (unsigned char h = 0; h < (SUPPORTED_STEM_LANGUAGES  + 1); h++)
	{
		if (sum_lang[h] > max_value)
		{
			max_value = sum_lang[h];
			language = (Stemming)h;
		}
	}

//	cout << *wordid;
//	for (unsigned char h = 0; h < (SUPPORTED_STEM_LANGUAGES  + 1); h++)
//		cout << ' ' << sum_lang[h];
//	cout << endl;

	return language;
}

//
// Name: dymddx_check_word
//
// Description:
//   Check if a word exists
//
// Input:
//   dymddx - the word index structure
//   word - the word name to check
//   bucket - the bucket in which this was found
//   offset - offset where bucket was found in hash file
//
// Return
//   a wordid if resolved
//   0 if not found
//
wordid_t dymddx_check_word(dymddx_t *u, const char *word, wordid_t *bucket)
{
	#define MAXWORDS (CONF_COLLECTION_MAXWORD * CONF_COLLECTION_DISTRIBUTED)
	assert(u != NULL);
	assert(word != NULL);
	assert(strlen(word) > 0);

	// First attempt to find bucket (debug purpose)
	//wordid_t test = dymddx_hashing_word(word);
	//cout << "DOMAIN " << word << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = dymddx_hashing_word(word);

	instance_t instance = (*bucket % CONF_COLLECTION_DISTRIBUTED);
	wordid_t pos = (*bucket / CONF_COLLECTION_DISTRIBUTED);

	lock.b_word(u, instance);

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while(u->distributed[instance].word_hash[pos] > 0)
	{
		char *pddx = u->distributed[instance].word + u->distributed[instance].word_hash[pos]; // puntatore all'offset indicato dall'hash

		const char *input = word;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pddx) != '\0' && *(input) != '\0' && *(pddx) == *(input) && *(pddx++) && *(input++));

		if (*pddx++ == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
		{
			unlock.b_word(u, instance);
			return *((wordid_t *)pddx); // restituisce l'id
		}

		(*bucket) = (((*bucket) + CONF_COLLECTION_DISTRIBUTED) % MAXWORDS);
		pos = ((pos + 1) % MAXWORDS);
	}

	return (wordid_t)0;
}

//
// Name: dymddx_check_stem
//
// Description:
//   Check if a stemming exists
//
// Input:
//   dymddx - the stemming index structure
//   stem - the stemming name to check
//   bucket - the bucket in which this was found
//   offset - offset where bucket was found in hash file
//
// Return
//   a stemid if resolved
//   0 if not found
//
stemid_t dymddx_check_stem(dymddx_t *u, const char *stem, stemid_t *bucket)
{
	#define MAXSTEMS (CONF_COLLECTION_MAXSTEM * CONF_COLLECTION_DISTRIBUTED)
	assert(u != NULL);
	assert(stem != NULL);
	assert(strlen(stem) > 0);

	// First attempt to find bucket (debug purpose)
	//stemid_t test = dymddx_hashing_stem(stem);
	//cout << "DOMAIN " << stem << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = dymddx_hashing_stem(stem);

	instance_t instance = (*bucket % CONF_COLLECTION_DISTRIBUTED);
	stemid_t pos = (*bucket / CONF_COLLECTION_DISTRIBUTED);

	lock.b_stem(u, instance);

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while(u->distributed[instance].stem_hash[pos] > 0)
	{
		char *pddx = u->distributed[instance].stem + u->distributed[instance].stem_hash[pos]; // puntatore all'offset indicato dall'hash

		const char *input = stem;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pddx) != '\0' && *(input) != '\0' && *(pddx) == *(input) && *(pddx++) && *(input++));

		if (*pddx++ == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
		{
			unlock.b_stem(u, instance);
			return *((stemid_t *)pddx); // restituisce l'id
		}

		(*bucket) = (((*bucket) + CONF_COLLECTION_DISTRIBUTED) % MAXSTEMS);
		pos = ((pos + 1) % MAXSTEMS);
	}

	return (stemid_t)0;
}

//
// Name: dymddx_check_gram
//
// Description:
//   Check if a n-gram exists
//
// Input:
//   dymddx - the n-gram index structure
//   gram - the n-gram name to check
//   bucket - the bucket in which this was found
//   offset - offset where bucket was found in hash file
//
// Return
//   a gramid if resolved
//   0 if not found
//
gramid_t dymddx_check_gram(dymddx_t *u, const char *gram, gramid_t *bucket)
{
	#define MAXGRAMS (CONF_COLLECTION_MAXGRAM * CONF_COLLECTION_DISTRIBUTED)
	assert(u != NULL);
	assert(gram != NULL);
	assert(strlen(gram) > 0);

	// First attempt to find bucket (debug purpose)
	//gramid_t test = dymddx_hashing_gram(gram);
	//cout << "DOMAIN " << gram << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = dymddx_hashing_gram(gram);

	instance_t instance = (*bucket % CONF_COLLECTION_DISTRIBUTED);
	gramid_t pos = (*bucket / CONF_COLLECTION_DISTRIBUTED);

	lock.b_gram(u, instance);

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while(u->distributed[instance].gram_hash[pos] > 0)
	{
		char *pddx = u->distributed[instance].gram + u->distributed[instance].gram_hash[pos]; // puntatore all'offset indicato dall'hash

		const char *input = gram;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pddx) != '\0' && *(input) != '\0' && *(pddx) == *(input) && *(pddx++) && *(input++));

		if (*pddx++ == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
		{
			unlock.b_gram(u, instance);
			return *((gramid_t *)pddx); // restituisce l'id
		}

		(*bucket) = (((*bucket) + CONF_COLLECTION_DISTRIBUTED) % MAXGRAMS);
		pos = ((pos + 1) % MAXGRAMS);
	}

	return (gramid_t)0;
}

// Hashing Functions for words
wordid_t dymddx_hashing_word(const char *text)
{
	#define MAXWORDS (CONF_COLLECTION_MAXWORD * CONF_COLLECTION_DISTRIBUTED)
	wordid_t val;
	for(val=0; *text; text++)
		val = ((131 * (val == 0 ? 1 : val) + *text) % MAXWORDS);

	return val;
}

// Hashing Functions for stemmings
stemid_t dymddx_hashing_stem(const char *text)
{
	#define MAXSTEMS (CONF_COLLECTION_MAXSTEM * CONF_COLLECTION_DISTRIBUTED)
	stemid_t val;
	for(val=0; *text; text++)
		val = ((131 * (val == 0 ? 1 : val) + *text) % MAXSTEMS);

	return val;
}

// Hashing Functions for n-grams
gramid_t dymddx_hashing_gram(const char *text)
{
	#define MAXGRAMS (CONF_COLLECTION_MAXGRAM * CONF_COLLECTION_DISTRIBUTED)
	gramid_t val;
	for(val=0; *text; text++)
		val = ((131 * (val == 0 ? 1 : val) + *text) % MAXGRAMS);

	return val;
}

//
// Name: dymddx_close
//
// Description:
//   Closes the url index, saving data to disk. Work with threads only if we have more the one distribution
//
// Input:
//   dymddx - the url index structure
//
void dymddx_close(dymddx_t *u)
{
	assert(CONF_OK);

	// Check what i'm going to close
	assert(u != NULL);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		assert(u->threads_word_count == u->word_count);
		assert(u->threads_stem_count == u->stem_count);
		assert(u->threads_gram_count == u->gram_count);
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		dymddx_thread_function_args_t *args = CBALLOC(dymddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->u = u;
		args->d = NULL;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[i], NULL, dymddx_thread_function_close, (void *) args))
				die("error creating thread!");
		}
		else
			dymddx_thread_function_close((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		free(threads);

	// Nullify to avoid re-closing
	free(u->distributed);

	// Nullify to avoid re-closing
	free(u);
}

//
// Name: dymddx_thread_function_close
//
// Description: invoked by 'dymddx_close' as thread
//
// Arguments: a void pointer to dymddx_thread_function_args_t type structure that contain instance and dymddx_t type structure 
//
// Return: NULL
//
void *dymddx_thread_function_close(void *args)
{
try
{
	cpu_set_t system_cpus;

	dymddx_thread_function_args_t *arguments = (dymddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	dymddx_t *u = arguments->u;

	char filename[MAX_STR_LEN];

	// save n-grams sequences of wordid to disk
	if(u->readonly == false)
	{
		if(u->distributed[inst].g_seq_count > 1)
		{
			off64_t offset_of_sourceidlist = 0;

			u->distributed[inst].sourceid_hash_dst = CBALLOC(off64_t, CALLOC, (u->distributed[inst].gram_count + 1)); // occorre termini con 0

			// Save on disk n-grams followed by the corresponding sourceid (in this case wordid)
			// populate sourceid_hash/list of destination
			// note that sourceid_list_dst is a temporary file
			for (gramid_t hash_pos = 0; hash_pos < u->distributed[inst].gram_count; hash_pos++)
			{
				gramid_t pad_hash_pos = (hash_pos % DYMDDX_WORDID_LIST_SIZE); // N.B. pad_hash_pos resta immutato
				off64_t *hash_pad = NULL; // pad in cui si trova l'hash con l'offset relativo alla prima sequenza
				unsigned short pad = 0;
				bool end_of_search = false;
				off64_t hops = 0; // hops inside of sequences buffer

				u->distributed[inst].sourceid_hash_dst[hash_pos] = offset_of_sourceidlist;

				// fix the start of sequences
				sequence_t *pad_of_g_seqs = u->distributed[inst].g_seqs;
				assert(pad_of_g_seqs != NULL);

				// FIRST step, go through Linked List until stop pad of hash and ...
				while (pad < (hash_pos / DYMDDX_WORDID_LIST_SIZE))
				{
					pad_of_g_seqs = pad_of_g_seqs->next_pad;
					assert(pad_of_g_seqs != NULL);
					pad++;
				}

				// ... link hash to correct pad
				hash_pad = pad_of_g_seqs->hash;
				assert(hash_pad != NULL);

				// skip if no data in sequences
				if (hash_pad[pad_hash_pos] == -1)
					continue;

				off64_t reloff = (hash_pad[pad_hash_pos] % DYMDDX_WORDID_LIST_SIZE); // relative first sequence's offset at current pad

				// SECOND step, go through Linked List until stop pad of start of first sequence (that can be the same pad of hash) and ...
				while (pad < (hash_pad[pad_hash_pos] / DYMDDX_WORDID_LIST_SIZE))
				{
					pad_of_g_seqs = pad_of_g_seqs->next_pad;
					assert(pad_of_g_seqs != NULL);
					pad++;
				}

				// keep the start of sequences in new temporary pointer and reloff needed for next 'while'
				sequence_t *_pad_of_g_seqs = pad_of_g_seqs;
				assert(_pad_of_g_seqs != NULL);
				off64_t _reloff = reloff;
				unsigned short _pad = pad;

				// THIRD step, go through Linked List, iterate trougth sequences and get hops of sourceids memory
				while (end_of_search == false) // iterate trougth sequences in same pad to find correct language
				{
					hops++;

					// search completed
					if (static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset == 0)
					{
						end_of_search = true;
						break;
					}

					// next offset is in one of the following pad
					if ((static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset / DYMDDX_WORDID_LIST_SIZE) > pad)
					{
						off64_t next_count = static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset;

						reloff = (next_count % DYMDDX_WORDID_LIST_SIZE);

						// skip to rigth pad
						while (pad < (next_count / DYMDDX_WORDID_LIST_SIZE))
						{
							pad_of_g_seqs = pad_of_g_seqs->next_pad; // next pad
							pad++;
						}

						continue;
					}

					reloff = (static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset % DYMDDX_WORDID_LIST_SIZE);
				}

				end_of_search = false;

				offset_of_sourceidlist += hops;

				sid_t *sourceids = CBALLOC(sid_t, CALLOC, hops);

				// now we use values create before
				reloff = _reloff;
				pad_of_g_seqs = _pad_of_g_seqs;
				pad = _pad;

				hops = 0;

				// FOURTH step, go through Linked List and iterate trougth sequences
				while (end_of_search == false) // iterate trougth sequences in same pad to find correct language
				{
					sourceids[hops++] = static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].id;

					// search completed and language not found
					if (static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset == 0)
					{
						end_of_search = true;
						break;
					}

					// next offset is in one of the following pad
					if ((static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset / DYMDDX_WORDID_LIST_SIZE) > pad)
					{
						off64_t next_count = static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset;

						reloff = (next_count % DYMDDX_WORDID_LIST_SIZE);

						// skip to rigth pad
						while (pad < (next_count / DYMDDX_WORDID_LIST_SIZE))
						{
							pad_of_g_seqs = pad_of_g_seqs->next_pad; // next pad
							pad++;
						}

						continue;
					}

					reloff = (static_cast<g_seq_t *>(pad_of_g_seqs->seq)[reloff].next_offset % DYMDDX_WORDID_LIST_SIZE);
				}

				fwrite(sourceids, sizeof(sid_t), hops, u->distributed[inst].sourceid_list_dst);
				free(sourceids); sourceids = NULL;
			}

			if (u->distributed[inst].sourceid_hash_src != NULL)
			{
				fclose(u->distributed[inst].sourceid_list_src); u->distributed[inst].sourceid_list_src = NULL;
				free(u->distributed[inst].sourceid_hash_src); u->distributed[inst].sourceid_hash_src = NULL;
			}

			fclose(u->distributed[inst].sourceid_list_dst); u->distributed[inst].sourceid_list_dst = NULL;

			char filename_tmp[MAX_STR_LEN];
			sprintf(filename_tmp, "%s/%s.%s", u->distributed[inst].dirname, DYMDDX_FILENAME_SOURCEID_LIST, "tmp");

			if (u->distributed[inst].word_count == 0)
			{
				fclose(u->distributed[inst].sourceid_list_dst); u->distributed[inst].sourceid_list_dst = NULL;

				int rc = unlink(filename_tmp);

				if(rc != 0 && errno != ENOENT)
				{
					perror(filename_tmp);
					die("Couldn't unlink file");
				}

				unlink(filename_tmp);
			}
			else
			{
				sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_SOURCEID_LIST);
				rename(filename_tmp, filename);
			}

			// Save the SOURCEID hash tables
			if (u->distributed[inst].sourceid_hash_dst != NULL)
			{
				sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_SOURCEID_HASH);

				// Open
				FILE *file_sourceid_hash = fopen64(filename, "w");
				assert(file_sourceid_hash != NULL);

				// Write
				sid_t sourceid_hash_dst_size = 1;

				while (u->distributed[inst].sourceid_hash_dst[sourceid_hash_dst_size] != (off64_t)0)
					sourceid_hash_dst_size++;

				sid_t sourceids_writed = fwrite(u->distributed[inst].sourceid_hash_dst, sizeof(off64_t), sourceid_hash_dst_size, file_sourceid_hash);
				assert(sourceids_writed == sourceid_hash_dst_size);

				// Close
				fclose(file_sourceid_hash);
				free(u->distributed[inst].sourceid_hash_dst);
				u->distributed[inst].sourceid_hash_dst = NULL;
			}
		}
		else // unchanged status
		{
			if (u->distributed[inst].sourceid_hash_src != NULL)
			{
				fclose(u->distributed[inst].sourceid_list_src); u->distributed[inst].sourceid_list_src = NULL;
				free(u->distributed[inst].sourceid_hash_src); u->distributed[inst].sourceid_hash_src = NULL;
			}

			fclose(u->distributed[inst].sourceid_list_dst); u->distributed[inst].sourceid_list_dst = NULL;

			char filename_tmp[MAX_STR_LEN];
			sprintf(filename_tmp, "%s/%s.%s", u->distributed[inst].dirname, DYMDDX_FILENAME_SOURCEID_LIST, "tmp");

			int rc = unlink(filename_tmp);

			if(rc != 0 && errno != ENOENT)
			{
				perror(filename_tmp);
				die("Couldn't unlink file");
			}

			unlink(filename_tmp);
		}

		// free volatile Linked List data of sequences of languages
		sequence_t *ptr = u->distributed[inst].w_seqs;
		sequence_t *keep_ptr = u->distributed[inst].w_seqs;

		while(ptr != NULL)
		{
			keep_ptr = ptr->next_pad;

			if (ptr->hash != NULL)
				free(ptr->hash);

			free(ptr->seq);
			free(ptr);
			ptr = keep_ptr;
		}

		// free volatile Linked List data of sequences of words
		ptr = u->distributed[inst].g_seqs;
		keep_ptr = u->distributed[inst].g_seqs;

		while(ptr != NULL)
		{
			keep_ptr = ptr->next_pad;

			if (ptr->hash != NULL)
				free(ptr->hash);

			free(ptr->seq);
			free(ptr);
			ptr = keep_ptr;
		}
	}
	else
	{
		if (u->distributed[inst].sourceid_hash_src != NULL)
		{
			fclose(u->distributed[inst].sourceid_list_src); u->distributed[inst].sourceid_list_src = NULL;
			free(u->distributed[inst].sourceid_hash_src); u->distributed[inst].sourceid_hash_src = NULL;
		}
	}

	size_t count;

	// Close and nullify all the filehandlers
	fclose(u->distributed[inst].word_list); u->distributed[inst].word_list = NULL;
	fclose(u->distributed[inst].stem_list); u->distributed[inst].stem_list = NULL;
	fclose(u->distributed[inst].gram_list); u->distributed[inst].gram_list = NULL;

	// If readonly mode, bail out, do not write anything
	if(u->readonly == true)
	{
		free(u->distributed[inst].word);
		free(u->distributed[inst].word_hash);
		free(u->distributed[inst].stem);
		free(u->distributed[inst].stem_hash);
		free(u->distributed[inst].gram);
		free(u->distributed[inst].gram_hash);
		free(args);
		return NULL;
	}

	// Save the word names 
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_WORD);

	// Open
	FILE *word_file = fopen64(filename, "w");
	assert(word_file != NULL);

	// Write
	count = fwrite(u->distributed[inst].word, u->distributed[inst].word_next_char, 1, word_file);
	assert(count == 1);

	// Close
	fclose(word_file);
	free(u->distributed[inst].word);
	u->distributed[inst].word = NULL;

	// Save the stemming names 
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_STEM);

	// Open
	FILE *stem_file = fopen64(filename, "w");
	assert(stem_file != NULL);

	// Write
	count = fwrite(u->distributed[inst].stem, u->distributed[inst].stem_next_char, 1, stem_file);
	assert(count == 1);

	// Close
	fclose(stem_file);
	free(u->distributed[inst].stem);
	u->distributed[inst].stem = NULL;

	// Save the n-grams names 
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_GRAM);

	// Open
	FILE *gram_file = fopen64(filename, "w");
	assert(gram_file != NULL);

	// Write
	count = fwrite(u->distributed[inst].gram, u->distributed[inst].gram_next_char, 1, gram_file);
	assert(count == 1);

	// Close
	fclose(gram_file);
	free(u->distributed[inst].gram);
	u->distributed[inst].gram = NULL;

	// Save the WORD hash tables
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_WORD_HASH);

	// Open
	FILE *file_word_hash = fopen64(filename, "w");
	assert(file_word_hash != NULL);

	// Write
	wordid_t words_writed = fwrite(u->distributed[inst].word_hash, sizeof(off64_t), CONF_COLLECTION_MAXWORD, file_word_hash);
	assert(words_writed == CONF_COLLECTION_MAXWORD);

	// Close
	fclose(file_word_hash);
	free(u->distributed[inst].word_hash);
	u->distributed[inst].word_hash = NULL;

	// Save the STEM hash tables
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_STEM_HASH);

	// Open
	FILE *file_stem_hash = fopen64(filename, "w");
	assert(file_stem_hash != NULL);

	// Write
	stemid_t stemmings_writed = fwrite(u->distributed[inst].stem_hash, sizeof(off64_t), CONF_COLLECTION_MAXSTEM, file_stem_hash);
	assert(stemmings_writed == CONF_COLLECTION_MAXSTEM);

	// Close
	fclose(file_stem_hash);
	free(u->distributed[inst].stem_hash);
	u->distributed[inst].stem_hash = NULL;

	// Save the GRAM hash tables
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_GRAM_HASH);

	// Open
	FILE *file_gram_hash = fopen64(filename, "w");
	assert(file_gram_hash != NULL);

	// Write
	gramid_t ngrams_writed = fwrite(u->distributed[inst].gram_hash, sizeof(off64_t), CONF_COLLECTION_MAXGRAM, file_gram_hash);
	assert(ngrams_writed == CONF_COLLECTION_MAXGRAM);

	// Close
	fclose(file_gram_hash);
	free(u->distributed[inst].gram_hash);
	u->distributed[inst].gram_hash = NULL;

	// Write the whole structure to disk
	sprintf(filename, "%s/%s", u->distributed[inst].dirname, DYMDDX_FILENAME_ALL);

	// Open
	FILE *file_all = fopen64(filename, "w");
	assert(file_all != NULL);

	// Write
	count = fwrite(&(u->distributed[inst]), sizeof(wddx_t), 1, file_all);
	assert(count == 1);

	// Close
	fclose(file_all);

	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}
                                            
//
// Name: dymddx_destroymutex
//
// Description: Free memory and destroy mutex
//
// Input:
//   dymddx - the url index structure
//
// Return:
//
void dymddx_destroymutex(dymddx_t *u)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1 && u->readonly == false)
	{
		// now, we ensure that all mutex are unused and destroyed
		int rc = 0;

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
		{
			if ((rc = pthread_mutex_destroy(&(u->wlock->locka[i]))) != 0)
				die("error destroying mutex %s", CBoterr(rc));

			if ((rc = pthread_mutex_destroy(&(u->wlock->lockb[i]))) != 0)
				die("error destroying mutex %s", CBoterr(rc));

			if ((rc = pthread_mutex_destroy(&(u->wlock->lockc[i]))) != 0)
				die("error destroying mutex %s", CBoterr(rc));

			if ((rc = pthread_mutex_destroy(&(u->slock->locka[i]))) != 0)
				die("error destroying mutex %s", CBoterr(rc));

			if ((rc = pthread_mutex_destroy(&(u->slock->lockb[i]))) != 0)
				die("error destroying mutex %s", CBoterr(rc));

			if ((rc = pthread_mutex_destroy(&(u->glock->locka[i]))) != 0)
				die("error destroying mutex %s", CBoterr(rc));

			if ((rc = pthread_mutex_destroy(&(u->glock->lockb[i]))) != 0)
				die("error destroying mutex %s", CBoterr(rc));

			if ((rc = pthread_mutex_destroy(&(u->glock->lockc[i]))) != 0)
				die("error destroying mutex %s", CBoterr(rc));
		}

		free(u->wlock->locka); u->wlock->locka = NULL;
		free(u->wlock->lockb); u->wlock->lockb = NULL;
		free(u->wlock->lockc); u->wlock->lockc = NULL;
		free(u->slock->locka); u->slock->locka = NULL;
		free(u->slock->lockb); u->slock->lockb = NULL;
		free(u->glock->locka); u->glock->locka = NULL;
		free(u->glock->lockb); u->glock->lockb = NULL;
		free(u->glock->lockc); u->glock->lockc = NULL;
		free(u->wlock);
		free(u->slock);
		free(u->glock);
	}
}
                                            
//
// Name: dymddx_word_by_wordid
//
// Description:
//   Get the name of a word based on its id
//
// Return:
//
void dymddx_word_by_wordid(dymddx_t *u, wordid_t &wordid, char *name)
{
	// Check if 'id' is in overflow
	if (wordid > u->word_count)
	{
		name[0] = '\0';
		return;
	}

	// Obtain id instance
	instance_t id_instance = ((wordid - 1) % CONF_COLLECTION_DISTRIBUTED);

	// Locking needed mutex
	//lock.a_word(u, id_instance);
	lock.a_word(u, id_instance);

	// Seek
	fseeko(u->distributed[id_instance].word_list, ((wordid - 1) / CONF_COLLECTION_DISTRIBUTED) * sizeof(dymlist_word_t), SEEK_SET);

	// Read offset
	dymlist_word_t *position = CBALLOC(dymlist_word_t, CALLOC, 1);
	fread(position, sizeof(dymlist_word_t), 1, u->distributed[id_instance].word_list);

	// Put at end
	fseeko(u->distributed[id_instance].word_list, 0, SEEK_END);

	// Unlocking unneeded mutex
	unlock.a_word(u, id_instance);

	// Locking needed mutex
	lock.b_word(u, position->bucket_instance);

	// Check if 'id' is not valid
	if (u->distributed[position->bucket_instance].word_hash[position->hash_pos] == 0)
		name[0] = '\0';
	else
	{	// Copy to 'name'
		assert(strlen((u->distributed[position->bucket_instance].word) + u->distributed[position->bucket_instance].word_hash[position->hash_pos]) < MAX_STR_LEN);
		strcpy(name, (u->distributed[position->bucket_instance].word) + u->distributed[position->bucket_instance].word_hash[position->hash_pos]);
	}

	// Unlocking unneeded mutex
	unlock.b_word(u, position->bucket_instance);
	free(position);
}

//
// Name: dymddx_stem_by_stemid
//
// Description:
//   Get the name of a stemming based on its id
//
// Return:
//
void dymddx_stem_by_stemid(dymddx_t *u, stemid_t &stemid, char *name)
{
	// Check if 'id' is in overflow
	if (stemid > u->stem_count)
	{
		name[0] = '\0';
		return;
	}

	// Obtain id instance
	instance_t id_instance = ((stemid - 1) % CONF_COLLECTION_DISTRIBUTED);

	// Locking needed mutex
	lock.a_stem(u, id_instance);

	// Seek
	fseeko(u->distributed[id_instance].stem_list, ((stemid - 1) / CONF_COLLECTION_DISTRIBUTED) * sizeof(dymlist_stem_t), SEEK_SET);

	// Read offset
	dymlist_stem_t *position = CBALLOC(dymlist_stem_t, CALLOC, 1);
	fread(position, sizeof(dymlist_stem_t), 1, u->distributed[id_instance].stem_list);

	// Put at end
	fseeko(u->distributed[id_instance].stem_list, 0, SEEK_END);

	// Unlocking unneeded mutex
	unlock.a_stem(u, id_instance);

	// Locking needed mutex
	lock.b_stem(u, position->bucket_instance);

	// Check if 'id' is not valid
	if (u->distributed[position->bucket_instance].stem_hash[position->hash_pos] == 0)
		name[0] = '\0';
	else
	{	// Copy to 'name'
		assert(strlen((u->distributed[position->bucket_instance].stem) + u->distributed[position->bucket_instance].stem_hash[position->hash_pos]) < MAX_STR_LEN);
		strcpy(name, (u->distributed[position->bucket_instance].stem) + u->distributed[position->bucket_instance].stem_hash[position->hash_pos]);
	}

	// Unlocking unneeded mutex
	unlock.b_stem(u, position->bucket_instance);
	free(position);
}

//
// Name: dymddx_gram_by_gramid
//
// Description:
//   Get the name of a n-gram based on its id
//
// Return:
//
void dymddx_gram_by_gramid(dymddx_t *u, gramid_t &gramid, char *name)
{
	// Check if 'id' is in overflow
	if (gramid > u->gram_count)
	{
		name[0] = '\0';
		return;
	}

	// Obtain id instance
	instance_t id_instance = ((gramid - 1) % CONF_COLLECTION_DISTRIBUTED);

	// Locking needed mutex
	lock.a_gram(u, id_instance);

	// Seek
	fseeko(u->distributed[id_instance].gram_list, ((gramid - 1) / CONF_COLLECTION_DISTRIBUTED) * sizeof(dymlist_gram_t), SEEK_SET);

	// Read offset
	dymlist_gram_t *position = CBALLOC(dymlist_gram_t, CALLOC, 1);
	fread(position, sizeof(dymlist_gram_t), 1, u->distributed[id_instance].gram_list);

	// Put at end
	fseeko(u->distributed[id_instance].gram_list, 0, SEEK_END);

	// Unlocking unneeded mutex
	unlock.a_gram(u, id_instance);

	// Locking needed mutex
	lock.b_gram(u, position->bucket_instance);

	// Check if 'id' is not valid
	if (u->distributed[position->bucket_instance].gram_hash[position->hash_pos] == 0)
		name[0] = '\0';
	else
	{ // Copy to 'name'
		assert(strlen((u->distributed[position->bucket_instance].gram) + u->distributed[position->bucket_instance].gram_hash[position->hash_pos]) < MAX_STR_LEN);
		strcpy(name, (u->distributed[position->bucket_instance].gram) + u->distributed[position->bucket_instance].gram_hash[position->hash_pos]);
	}

	// Unlocking unneeded mutex
	unlock.b_gram(u, position->bucket_instance);
	free(position);
}

//
// Name: dymddx_remove
//
// Description:
//   Deletes all files for an dymddx
//
// Input:
//   dirname - the directory to clean
//
void dymddx_remove(const char *dirname)
{
	struct stat64 statbuf;

	pthread_t *threads = NULL;

	instance_t max_instances = 0;

	// check how many directory contain data to delete
	for (instance_t i = 0; i < ((instance_t)(~0)); i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, i);

		if (stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
			max_instances++;
		else
		{
			free(relative_rem_path);
			break;
		}

		free(relative_rem_path);
	}

	if (max_instances > 1)
		threads = CBALLOC(pthread_t, MALLOC, max_instances);

	for (instance_t i = 0; i < max_instances; i++)
	{
		dymddx_thread_function_args_t *args = CBALLOC(dymddx_thread_function_args_t, MALLOC, 1);
	    args->i = i;
    	args->u = NULL;
		args->d = (char *)dirname;

		if (max_instances > 1)
		{
			if (pthread_create(&threads[i], NULL, dymddx_thread_function_remove, (void *) args))
				die("error creating thread!");
		}
		else
			dymddx_thread_function_remove((void *) args); // only one distribution, function is call without thread 
	}

	if (max_instances > 1)
	{
		CBotjoin(threads, max_instances);

		free(threads);
	}
}

//
// Name: dymddx_thread_function_remove
//
// Description: invoked by 'dymddx_remove' as thread
//
// Arguments: a void pointer to dymddx_thread_function_args_t type structure 
//
// Return: NULL
//
void *dymddx_thread_function_remove(void *args)
{
try
{
	cpu_set_t system_cpus;

	dymddx_thread_function_args_t *arguments = (dymddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	char *dirname = arguments->d;
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);

	queue<string> files;

	// Push files
	files.push(DYMDDX_FILENAME_WORD_LIST);
	files.push(DYMDDX_FILENAME_WORD);
	files.push(DYMDDX_FILENAME_WORD_HASH);
	files.push(DYMDDX_FILENAME_STEM_LIST);
	files.push(DYMDDX_FILENAME_STEM);
	files.push(DYMDDX_FILENAME_STEM_HASH);
	files.push(DYMDDX_FILENAME_SOURCEID_LIST);
	files.push(DYMDDX_FILENAME_SOURCEID_HASH);
	files.push(DYMDDX_FILENAME_GRAM_LIST);
	files.push(DYMDDX_FILENAME_GRAM);
	files.push(DYMDDX_FILENAME_GRAM_HASH);
	files.push(DYMDDX_FILENAME_ALL);

	// Delete
	while(! files.empty())
	{
		// Create filename
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, files.front().c_str());

		// Delete file
		int rc = unlink(filename);
		if(rc != 0 && errno != ENOENT)
		{
			perror(files.front().c_str());
			die("Couldn't unlink file");
		}

		// Remove file from queue
		files.pop();
	}

	if (inst >= CONF_COLLECTION_DISTRIBUTED)
	{
		// Delete dir (rimuove la directory dym ...)
		int rc = remove(relative_rem_path);
		if(rc != 0 && errno != ENOENT)
		{
			perror(relative_rem_path); 
			die("Couldn't remove directory");
		}
	}

	free(relative_rem_path);

	arguments->d = NULL;
	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}

//
// Name: dymddx_dump_status
//
// Description:
//   Shows the status of the words language association index
//
// Input:
//   urlddx - the url index structure
//
void dymddx_dump_status(dymddx_t *u)
{
	for (instance_t instance = 0; instance < CONF_COLLECTION_DISTRIBUTED; instance++)
	{
		cerr << "Status dump of instance     " << (int)instance << ":" << endl;
		cerr << "- dirname                   " << u->distributed[instance].dirname << endl;
		cerr << "- word_count                " << u->distributed[instance].word_count << endl;
		cerr << "- Disk used by words        " << u->distributed[instance].word_next_char << endl;
		cerr << "- stem_count                " << u->distributed[instance].stem_count << endl;
		cerr << "- Disk used by stemmings    " << u->distributed[instance].stem_next_char << endl;
		cerr << "- gram_count                " << u->distributed[instance].gram_count << endl;
		cerr << "- Disk used by n-grams      " << u->distributed[instance].gram_next_char << endl;
	}
}
