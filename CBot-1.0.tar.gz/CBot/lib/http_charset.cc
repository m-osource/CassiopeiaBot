/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "http_charset.h"

//
// Name: http_charset
//
// Descriptions: Checks the charset name and assigns a charset_t element to the charset string
//
// Input: charset_str - charset string returned by the web server
//
// Return: charset_t identifier of the charset
//
charset_t http_charset(char * charset_str) {
    int len;

    if (charset_str == NULL) {
        return CHARSET_UNKNOWN;
    }
    
    len = strlen(charset_str);

    if (len >= 10 && !strncasecmp(charset_str, "ISO-8859-1", 10)) {
        return CHARSET_ISO_8859_1;
    }
    else if (len >= 5 && !strncasecmp(charset_str, "UTF-8", 5)) {
        return CHARSET_UTF_8;
    }
    else if (len >= 6 && (!strncasecmp(charset_str, "EUC-KR", 6) || !strncasecmp(charset_str, "EUC_KR", 6))) {
        return CHARSET_EUC_KR;
    }
    else if (len >= 5 && !strncasecmp(charset_str, "EUCKR", 5)) {
        return CHARSET_EUC_KR;
    }
    else if (len >= 11 && !strncasecmp(charset_str, "ISO-8859-15", 11)) {
        return CHARSET_ISO_8859_15;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "windows-1252", 12)) {
        return CHARSET_WINDOWS_1252;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "UTF-16", 6)) {
        return CHARSET_UTF_16;
    }
    else if (len >= 6 && (!strncasecmp(charset_str, "EUC_JP", 6) || !strncasecmp(charset_str, "EUC-JP", 6))) {
        return CHARSET_EUC_JP;
    }
    else if (len >= 5 && !strncasecmp(charset_str, "EUCJP", 5)) {
        return CHARSET_EUC_JP;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "KOI8-R", 6)) {
        return CHARSET_KOI8_R;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "KOI8-U", 6)) {
        return CHARSET_KOI8_U;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "ISO-8859-2", 10)) {
        return CHARSET_ISO_8859_2;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "ISO-8859-3", 10)) {
        return CHARSET_ISO_8859_3;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "ISO-8859-4", 10)) {
        return CHARSET_ISO_8859_4;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "ISO-8859-5", 10)) {
        return CHARSET_ISO_8859_5;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "ISO-8859-6", 10)) {
        return CHARSET_ISO_8859_6;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "ISO-8859-6-I", 12)) {
        return CHARSET_ISO_8859_6_I;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "ISO-8859-6-E", 12)) {
        return CHARSET_ISO_8859_6_E;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "ISO-8859-7", 10)) {
        return CHARSET_ISO_8859_7;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "ISO-8859-8", 10)) {
        return CHARSET_ISO_8859_8;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "ISO-8859-8-I", 12)) {
        return CHARSET_ISO_8859_8_I;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "ISO-8859-8-E", 12)) {
        return CHARSET_ISO_8859_8_E;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "ISO-8859-9", 10)) {
        return CHARSET_ISO_8859_9;
    }
    else if (len >= 11 && !strncasecmp(charset_str, "ISO-8859-10", 11)) {
        return CHARSET_ISO_8859_10;
    }
    else if (len >= 11 && !strncasecmp(charset_str, "ISO-8859-11", 11)) {
        return CHARSET_ISO_8859_11;
    }
    else if (len >= 11 && !strncasecmp(charset_str, "ISO-8859-13", 11)) {
        return CHARSET_ISO_8859_13;
    }
    else if (len >= 11 && !strncasecmp(charset_str, "ISO-8859-14", 11)) {
        return CHARSET_ISO_8859_14;
    }
    else if (len >= 11 && !strncasecmp(charset_str, "ISO-8859-16", 11)) {
        return CHARSET_ISO_8859_16;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "ISO-IR-111", 10)) {
        return CHARSET_ISO_IR_111;
    }
    else if (len >= 11 && !strncasecmp(charset_str, "ISO-2022-CN", 11)) {
        return CHARSET_ISO_2022_CN;
    }
    else if (len >= 11 && !strncasecmp(charset_str, "ISO-2022-CN", 11)) {
        return CHARSET_ISO_2022_CN;
    }
    else if (len >= 11 && !strncasecmp(charset_str, "ISO-2022-KR", 11)) {
        return CHARSET_ISO_2022_KR;
    }
    else if (len >= 11 && !strncasecmp(charset_str, "ISO-2022-JP", 11)) {
        return CHARSET_ISO_2022_JP;
    }
    else if (len >= 8 && !strncasecmp(charset_str, "us-ascii", 8)) {
        return CHARSET_US_ASCII;
    }
    else if (len >= 8 && !strncasecmp(charset_str, "UTF-32BE", 8)) {
        return CHARSET_UTF_32BE;
    }
    else if (len >= 8 && !strncasecmp(charset_str, "UTF-32LE", 8)) {
        return CHARSET_UTF_32LE;
    }
    else if (len >= 8 && !strncasecmp(charset_str, "UTF-16BE", 8)) {
        return CHARSET_UTF_16BE;
    }
    else if (len >= 8 && !strncasecmp(charset_str, "UTF-16LE", 8)) {
        return CHARSET_UTF_16LE;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "windows-1250", 12)) {
        return CHARSET_WINDOWS_1250;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "windows-1251", 12)) {
        return CHARSET_WINDOWS_1251;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "windows-1253", 12)) {
        return CHARSET_WINDOWS_1253;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "windows-1254", 12)) {
        return CHARSET_WINDOWS_1254;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "windows-1255", 12)) {
        return CHARSET_WINDOWS_1255;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "windows-1256", 12)) {
        return CHARSET_WINDOWS_1256;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "windows-1257", 12)) {
        return CHARSET_WINDOWS_1257;
    }
    else if (len >= 12 && !strncasecmp(charset_str, "windows-1258", 12)) {
        return CHARSET_WINDOWS_1258;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "IBM866", 6)) {
        return CHARSET_IBM866;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "IBM850", 6)) {
        return CHARSET_IBM850;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "IBM852", 6)) {
        return CHARSET_IBM852;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "IBM855", 6)) {
        return CHARSET_IBM855;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "IBM857", 6)) {
        return CHARSET_IBM857;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "IBM862", 6)) {
        return CHARSET_IBM862;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "IBM864", 6)) {
        return CHARSET_IBM864;
    }
    else if (len >= 7 && !strncasecmp(charset_str, "IBM864i", 7)) {
        return CHARSET_IBM864I;
    }
    else if (len >= 5 && !strncasecmp(charset_str, "UTF-7", 5)) {
        return CHARSET_UTF_7;
    }
    else if (len >= 9 && !strncasecmp(charset_str, "Shift_JIS", 9)) {
        return CHARSET_SHIFT_JIS;
    }
    else if (len >= 4 && !strncasecmp(charset_str, "Big5", 4)) {
        return CHARSET_BIG5;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "GB2312", 6)) {
        return CHARSET_GB2312;
    }
    else if (len >= 7 && !strncasecmp(charset_str, "gb18030", 7)) {
        return CHARSET_GB18030;
    }
    else if (len >= 6 && !strncasecmp(charset_str, "VISCII", 6)) {
        return CHARSET_VISCII;
    }
    else if (len >= 7 && !strncasecmp(charset_str, "TIS-620", 7)) {
        return CHARSET_TIS_620;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "HZ-GB-2312", 10)) {
        return CHARSET_HZ_GB_2312;
    }
    else if (len >= 10 && !strncasecmp(charset_str, "Big5-HKSCS", 10)) {
        return CHARSET_BIG5_HKSCS;
    }
    else if (len >= 5 && !strncasecmp(charset_str, "x-gbk", 5)) {
        return CHARSET_X_GBK;
    }
    else if (len >= 8 && !strncasecmp(charset_str, "x-euc-tw", 8)) {
        return CHARSET_X_EUC_TW;
    }
    else {
        // cerr << "[CHARSET '" << charset_str << "' UNKNOWN]";
        return CHARSET_UNKNOWN;
    }
}


//
// Name: http_language
//
// Descriptions: Checks the language name and assigns a language_t element to the language string
//
// Input: language_str - language string returned by the web server
//
// Return: language_t identifier of the language
//
Language http_language(char * language_str) {
    int len;

    if (language_str == NULL) {
        return Language::UNKNOWN;
    }
    
    len = strlen(language_str);

	if (len >= 2 && !strncasecmp(language_str, "AB", 2)) {
		return Language::AB;
	}
	else if (len >= 2 && !strncasecmp(language_str, "AA", 2)) {
		return Language::AA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "AF", 2)) {
		return Language::AF;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SQ", 2)) {
		return Language::SQ;
	}
	else if (len >= 2 && !strncasecmp(language_str, "AM", 2)) {
		return Language::AM;
	}
	else if (len >= 2 && !strncasecmp(language_str, "AR", 2)) {
		return Language::AR;
	}
	else if (len >= 2 && !strncasecmp(language_str, "HY", 2)) {
		return Language::HY;
	}
	else if (len >= 2 && !strncasecmp(language_str, "AS", 2)) {
		return Language::AS;
	}
	else if (len >= 2 && !strncasecmp(language_str, "AY", 2)) {
		return Language::AY;
	}
	else if (len >= 2 && !strncasecmp(language_str, "AZ", 2)) {
		return Language::AZ;
	}
	else if (len >= 2 && !strncasecmp(language_str, "BA", 2)) {
		return Language::BA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "EU", 2)) {
		return Language::EU;
	}
	else if (len >= 2 && !strncasecmp(language_str, "BN", 2)) {
		return Language::BN;
	}
	else if (len >= 2 && !strncasecmp(language_str, "DZ", 2)) {
		return Language::DZ;
	}
	else if (len >= 2 && !strncasecmp(language_str, "BH", 2)) {
		return Language::BH;
	}
	else if (len >= 2 && !strncasecmp(language_str, "BI", 2)) {
		return Language::BI;
	}
	else if (len >= 2 && !strncasecmp(language_str, "BR", 2)) {
		return Language::BR;
	}
	else if (len >= 2 && !strncasecmp(language_str, "BG", 2)) {
		return Language::BG;
	}
	else if (len >= 2 && !strncasecmp(language_str, "MY", 2)) {
		return Language::MY;
	}
	else if (len >= 2 && !strncasecmp(language_str, "BE", 2)) {
		return Language::BE;
	}
	else if (len >= 2 && !strncasecmp(language_str, "KM", 2)) {
		return Language::KM;
	}
	else if (len >= 2 && !strncasecmp(language_str, "CA", 2)) {
		return Language::CA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "ZH", 2)) {
		return Language::ZH;
	}
	else if (len >= 2 && !strncasecmp(language_str, "CO", 2)) {
		return Language::CO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "HR", 2)) {
		return Language::HR;
	}
	else if (len >= 2 && !strncasecmp(language_str, "CS", 2)) {
		return Language::CS;
	}
	else if (len >= 2 && !strncasecmp(language_str, "DA", 2)) {
		return Language::DA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "NL", 2)) {
		return Language::NL;
	}
	else if (len >= 2 && !strncasecmp(language_str, "EN", 2)) {
		return Language::EN;
	}
	else if (len >= 2 && !strncasecmp(language_str, "EO", 2)) {
		return Language::EO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "ET", 2)) {
		return Language::ET;
	}
	else if (len >= 2 && !strncasecmp(language_str, "FO", 2)) {
		return Language::FO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "FJ", 2)) {
		return Language::FJ;
	}
	else if (len >= 2 && !strncasecmp(language_str, "FI", 2)) {
		return Language::FI;
	}
	else if (len >= 2 && !strncasecmp(language_str, "FR", 2)) {
		return Language::FR;
	}
	else if (len >= 2 && !strncasecmp(language_str, "FY", 2)) {
		return Language::FY;
	}
	else if (len >= 2 && !strncasecmp(language_str, "GD", 2)) {
		return Language::GD;
	}
	else if (len >= 2 && !strncasecmp(language_str, "GL", 2)) {
		return Language::GL;
	}
	else if (len >= 2 && !strncasecmp(language_str, "KA", 2)) {
		return Language::KA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "DE", 2)) {
		return Language::DE;
	}
	else if (len >= 2 && !strncasecmp(language_str, "EL", 2)) {
		return Language::EL;
	}
	else if (len >= 2 && !strncasecmp(language_str, "KL", 2)) {
		return Language::KL;
	}
	else if (len >= 2 && !strncasecmp(language_str, "GN", 2)) {
		return Language::GN;
	}
	else if (len >= 2 && !strncasecmp(language_str, "GU", 2)) {
		return Language::GU;
	}
	else if (len >= 2 && !strncasecmp(language_str, "HA", 2)) {
		return Language::HA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "IW", 2)) {
		return Language::IW;
	}
	else if (len >= 2 && !strncasecmp(language_str, "HI", 2)) {
		return Language::HI;
	}
	else if (len >= 2 && !strncasecmp(language_str, "HU", 2)) {
		return Language::HU;
	}
	else if (len >= 2 && !strncasecmp(language_str, "IS", 2)) {
		return Language::IS;
	}
	else if (len >= 2 && !strncasecmp(language_str, "IN", 2)) {
		return Language::IN;
	}
	else if (len >= 2 && !strncasecmp(language_str, "IA", 2)) {
		return Language::IA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "IE", 2)) {
		return Language::IE;
	}
	else if (len >= 2 && !strncasecmp(language_str, "IK", 2)) {
		return Language::IK;
	}
	else if (len >= 2 && !strncasecmp(language_str, "GA", 2)) {
		return Language::GA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "IT", 2)) {
		return Language::IT;
	}
	else if (len >= 2 && !strncasecmp(language_str, "JA", 2)) {
		return Language::JA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "JW", 2)) {
		return Language::JW;
	}
	else if (len >= 2 && !strncasecmp(language_str, "KN", 2)) {
		return Language::KN;
	}
	else if (len >= 2 && !strncasecmp(language_str, "KS", 2)) {
		return Language::KS;
	}
	else if (len >= 2 && !strncasecmp(language_str, "KK", 2)) {
		return Language::KK;
	}
	else if (len >= 2 && !strncasecmp(language_str, "RW", 2)) {
		return Language::RW;
	}
	else if (len >= 2 && !strncasecmp(language_str, "KY", 2)) {
		return Language::KY;
	}
	else if (len >= 2 && !strncasecmp(language_str, "RN", 2)) {
		return Language::RN;
	}
	else if (len >= 2 && !strncasecmp(language_str, "KO", 2)) {
		return Language::KO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "KU", 2)) {
		return Language::KU;
	}
	else if (len >= 2 && !strncasecmp(language_str, "LO", 2)) {
		return Language::LO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "LA", 2)) {
		return Language::LA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "LV", 2)) {
		return Language::LV;
	}
	else if (len >= 2 && !strncasecmp(language_str, "LN", 2)) {
		return Language::LN;
	}
	else if (len >= 2 && !strncasecmp(language_str, "LT", 2)) {
		return Language::LT;
	}
	else if (len >= 2 && !strncasecmp(language_str, "MK", 2)) {
		return Language::MK;
	}
	else if (len >= 2 && !strncasecmp(language_str, "MG", 2)) {
		return Language::MG;
	}
	else if (len >= 2 && !strncasecmp(language_str, "MS", 2)) {
		return Language::MS;
	}
	else if (len >= 2 && !strncasecmp(language_str, "ML", 2)) {
		return Language::ML;
	}
	else if (len >= 2 && !strncasecmp(language_str, "MT", 2)) {
		return Language::MT;
	}
	else if (len >= 2 && !strncasecmp(language_str, "MI", 2)) {
		return Language::MI;
	}
	else if (len >= 2 && !strncasecmp(language_str, "MR", 2)) {
		return Language::MR;
	}
	else if (len >= 2 && !strncasecmp(language_str, "MO", 2)) {
		return Language::MO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "MN", 2)) {
		return Language::MN;
	}
	else if (len >= 2 && !strncasecmp(language_str, "NA", 2)) {
		return Language::NA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "NE", 2)) {
		return Language::NE;
	}
	else if (len >= 2 && !strncasecmp(language_str, "NO", 2)) {
		return Language::NO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "OC", 2)) {
		return Language::OC;
	}
	else if (len >= 2 && !strncasecmp(language_str, "OR", 2)) {
		return Language::OR;
	}
	else if (len >= 2 && !strncasecmp(language_str, "OM", 2)) {
		return Language::OM;
	}
	else if (len >= 2 && !strncasecmp(language_str, "PS", 2)) {
		return Language::PS;
	}
	else if (len >= 2 && !strncasecmp(language_str, "FA", 2)) {
		return Language::FA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "PL", 2)) {
		return Language::PL;
	}
	else if (len >= 2 && !strncasecmp(language_str, "PT", 2)) {
		return Language::PT;
	}
	else if (len >= 2 && !strncasecmp(language_str, "PA", 2)) {
		return Language::PA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "QU", 2)) {
		return Language::QU;
	}
	else if (len >= 2 && !strncasecmp(language_str, "RM", 2)) {
		return Language::RM;
	}
	else if (len >= 2 && !strncasecmp(language_str, "RO", 2)) {
		return Language::RO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "RU", 2)) {
		return Language::RU;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SM", 2)) {
		return Language::SM;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SG", 2)) {
		return Language::SG;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SA", 2)) {
		return Language::SA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SR", 2)) {
		return Language::SR;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SH", 2)) {
		return Language::SH;
	}
	else if (len >= 2 && !strncasecmp(language_str, "ST", 2)) {
		return Language::ST;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TN", 2)) {
		return Language::TN;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SN", 2)) {
		return Language::SN;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SD", 2)) {
		return Language::SD;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SI", 2)) {
		return Language::SI;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SS", 2)) {
		return Language::SS;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SK", 2)) {
		return Language::SK;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SL", 2)) {
		return Language::SL;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SO", 2)) {
		return Language::SO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "ES", 2)) {
		return Language::ES;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SU", 2)) {
		return Language::SU;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SW", 2)) {
		return Language::SW;
	}
	else if (len >= 2 && !strncasecmp(language_str, "SV", 2)) {
		return Language::SV;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TL", 2)) {
		return Language::TL;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TG", 2)) {
		return Language::TG;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TA", 2)) {
		return Language::TA;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TT", 2)) {
		return Language::TT;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TE", 2)) {
		return Language::TE;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TH", 2)) {
		return Language::TH;
	}
	else if (len >= 2 && !strncasecmp(language_str, "BO", 2)) {
		return Language::BO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TI", 2)) {
		return Language::TI;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TO", 2)) {
		return Language::TO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TS", 2)) {
		return Language::TS;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TR", 2)) {
		return Language::TR;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TK", 2)) {
		return Language::TK;
	}
	else if (len >= 2 && !strncasecmp(language_str, "TW", 2)) {
		return Language::TW;
	}
	else if (len >= 2 && !strncasecmp(language_str, "UK", 2)) {
		return Language::UK;
	}
	else if (len >= 2 && !strncasecmp(language_str, "UR", 2)) {
		return Language::UR;
	}
	else if (len >= 2 && !strncasecmp(language_str, "UZ", 2)) {
		return Language::UZ;
	}
	else if (len >= 2 && !strncasecmp(language_str, "VI", 2)) {
		return Language::VI;
	}
	else if (len >= 2 && !strncasecmp(language_str, "VO", 2)) {
		return Language::VO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "CY", 2)) {
		return Language::CY;
	}
	else if (len >= 2 && !strncasecmp(language_str, "WO", 2)) {
		return Language::WO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "XH", 2)) {
		return Language::XH;
	}
	else if (len >= 2 && !strncasecmp(language_str, "JI", 2)) {
		return Language::JI;
	}
	else if (len >= 2 && !strncasecmp(language_str, "YO", 2)) {
		return Language::YO;
	}
	else if (len >= 2 && !strncasecmp(language_str, "ZU", 2)) {
		return Language::ZU;
	}
    else {
        cerr << "[Language::LANGUAGE '" << language_str << "' UNKNOWN]";
        return Language::UNKNOWN;
    }
}

//
// Name: http_charset_convert
//
// Descriptions: Converts the src text written in the charset from charset into the charset_to charset and leaves the result in the dst string
//
// Input:
//   charset_from - charset of the source text
//   charset_to   - charset of the target text
//   src          - source text
//   dst          - target variable
//
// Return: Size of the target text
//
off64_t http_charset_convert(charset_t charset_from, charset_t charset_to, char *src, char *dst, off64_t dstmaxsize) {
    size_t srclen;
    size_t dstlen;
    size_t inleftsize, outleftsize;
    size_t res;				/* report of iconv */
    iconv_t cd = (iconv_t)-1;

    const char *from;
    const char *to;

    char *inptr;
    char *outptr;

    from = CHARSET_STR(charset_from);
    to   = CHARSET_STR(charset_to);


    /* open iconv */
    cd = iconv_open(to, from);
    if (cd==(iconv_t)(-1)) {
        return (off64_t)cd;
    }

    if (!strcasecmp(from, "UCS-2")) {
        inleftsize=2;
    }
    else {
        srclen = (size_t)strlen(src);
        inleftsize = srclen;
    }
    //outleftsize = inleftsize * 4;
    outleftsize = inleftsize * 4 >= (size_t)dstmaxsize ? (size_t)dstmaxsize - 1: inleftsize * 4;
    dstlen  = outleftsize;
    inptr   = src;
    outptr  = dst;

    while(1) {
        res = iconv(cd, &inptr, &inleftsize, &outptr, &outleftsize);
        if (res == (size_t)(-1)) {
            if (errno == EILSEQ) { /* An invalid multibyte sequence has been encountered in the input. */
                /* cerr << "[CHARSET CONVERT: CAN'T CONVERT FROM " << from <<  "]" << endl; */
                /* for 2-byte code incompleteness */
                inptr++;
                inleftsize--;
            }
            else if (errno == EINVAL) { /* An  incomplete  multibyte  sequence  has been encountered in the input. */
                /* cerr << "[CHARSET CONVERT: INCOMPLETE CHAR OR SHIFT SEQUENCE]" << endl; */
                if (inleftsize <= 2) {
                    *outptr = '?';
                    outleftsize--;
                    break;
                }
            }
            else if (errno == E2BIG) {
                /* cerr << "[OUTPUT TOO BIG]" << endl; */
                break;
            }
            *outptr='?';
            outptr++;
            outleftsize--;
            inptr++;
            inleftsize--;
        }
        else break;
    }
    
    dst[dstlen - outleftsize] = '\0';
    /* close iconv */
    iconv_close(cd);
    return (dstlen - outleftsize);
}

/**
 * Definicion de la clase cbotUniversalDetector
 **/

cbotUniversalDetector::cbotUniversalDetector():nsUniversalDetector((PRUint32)0)
{
    ready = 0;
    detectedCharset = CHARSET_UNKNOWN;
}

cbotUniversalDetector::~cbotUniversalDetector()
{
}
    
void cbotUniversalDetector::Report(const char * aCharset)
{
    detectedCharset = http_charset((char *)aCharset);
    ready = 1;
}

charset_t cbotUniversalDetector::GetCharset(const char * aBuf, PRUint32 aLen)
{
    HandleData(aBuf, aLen);
    DataEnd();

    if (ready) return detectedCharset;

    //could't find a confident charset
    return CHARSET_UNKNOWN;
}
