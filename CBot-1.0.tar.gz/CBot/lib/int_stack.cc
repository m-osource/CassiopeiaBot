/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "int_stack.h"


void int_stack_init(int_stack_t *s){
	s->pos = 0;
	for(int i=0; i<MAX_STACK_SIZE; i++)
		s->data[i]=0;
}


void int_stack_push(int_stack_t *s, int val){
	s->pos = (s->pos<MAX_STACK_SIZE-1?s->pos+1:0);
	s->data[s->pos]=val;
}


int int_stack_pop(int_stack_t *s){
	int ret = s->data[s->pos];
	s->pos = (s->pos>1?s->pos-1:MAX_STACK_SIZE-1);
	return ret;
}

int int_stack_peek(int_stack_t *s){
	return s->data[s->pos];
}
