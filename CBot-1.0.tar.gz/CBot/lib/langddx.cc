/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "langddx.h"

langddx_t *langddx_open(const char *dirname, bool readonly)
{

	// Request memory for the structure
	langddx_t *m = (langddx_t *)malloc(sizeof(langddx_t));
	assert(m != NULL);
	m->count_word = 0;
	m->readonly = readonly;

	m->distributed = (lddx_t *) malloc (sizeof(lddx_t) * CONF_COLLECTION_DISTRIBUTED);
	assert(m->distributed != NULL);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = (pthread_t *) malloc (CONF_COLLECTION_DISTRIBUTED * sizeof(pthread_t));

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		langddx_thread_function_args_t *args = (langddx_thread_function_args_t *) malloc (sizeof(langddx_thread_function_args_t));
		args->i = i;
		args->m = m;
		args->d = (char *)dirname;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[i], NULL, langddx_thread_function_open, (void *) args))
				die("error creating thread!");
		}
		else
			langddx_thread_function_open((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

			// Update word master counter
		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			m->count_word += m->distributed[i].count_word;

		free(threads);
	}
	else
	{
			instance_t i = (CONF_COLLECTION_DISTRIBUTED - 1);

			// Update word master counter
			m->count_word += m->distributed[i].count_word;
	}

	if (m->count_word > 0)
		cerr << endl << "Found " << m->count_word << " words." << endl;

	return m;
}

//
// Name: langddx_thread_function_open
//
// Description: invoked by 'langddx_open' as thread
//
// Arguments: a void pointer to langddx_thread_function_args_t type structure 
//
// Return: NULL
//
void *langddx_thread_function_open(void *args)
{
try
{
	cpu_set_t system_cpus;

	langddx_thread_function_args_t *arguments = (langddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	langddx_t *m = arguments->m;
	char *dirname = arguments->d;
	
	char filename[MAX_STR_LEN];
	struct stat64 statbuf;

	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
	strcpy(m->distributed[inst].dirname, relative_rem_path);
	free(relative_rem_path);
	m->distributed[inst].count_word = 0;

	// Go ahead to words .... Create or open filename
	sprintf(filename, "%s/%s", m->distributed[inst].dirname, LANGDDX_FILENAME_WORD);

	errno = 0; // errno is thread-local

	// Check if file exists
	if (stat64(filename, &statbuf) == 0)
	{
		// Verify file size
		if((unsigned long int)(statbuf.st_size) != (sizeof(word_t) * INSTANCE_MAXWORD))
		{
//			if((unsigned long int)(statbuf.st_size) != (sizeof(word_old_t) * INSTANCE_MAXWORD))
//			{
				cerr << "Inconsistency in word_t:" << endl;
				cerr << "- Distributed          : " << inst << endl;
				cerr << "- Sizeof(word_t)        : " << sizeof(word_t) << endl;
//				cerr << "- Sizeof(word_old_t)    : " << sizeof(word_old_t) << endl;
				cerr << "- Maxwords              : " << INSTANCE_MAXWORD << endl;
				cerr << "- Size of current file : " << (unsigned long int)(statbuf.st_size) << endl;
				cerr << "- Expected size        : " << sizeof(word_t) * INSTANCE_MAXWORD << endl;
				die("Inconsistency in word_t");
				// cerr << "The size of the file of metadata of words is wrong" << endl;
				// cerr << "Probably you changed maxword in the configuration" << endl;
				// cerr << "Or the version of CBOT is wrong" << endl;
				// die("Inconsistency in the size of word_t");
//			}
//			else
//				langddx_convert_old_word_file(filename);
		}

		if(m->readonly)
			m->distributed[inst].file_word = open(filename, O_RDONLY|O_LARGEFILE);
		else
			m->distributed[inst].file_word = open(filename, O_RDWR|O_LARGEFILE, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (errno != 0)
			die("langddx_open: couldn't open file %s on %s\n", cberr(), filename);

		// Read the header word document
		assert(lseek(m->distributed[inst].file_word, (off64_t)0, SEEK_SET) == 0);

		if (errno != 0)
			die("langddx_open: couldn't seek file %s on %s\n", cberr(), filename);

		word_t word_header;
		assert(read(m->distributed[inst].file_word, &word_header, sizeof(word_t)) == sizeof(word_t));

		if (errno != 0)
			die("connddx_open: couldn't read file %s on %s\n", cberr(), filename);

		// Read data from it
		m->distributed[inst].count_word = word_header.wordid;
	}
	else
	{

		// Check readonly
		if(m->readonly)
			die("Couldn't create index: readonly mode enabled");

		// Create file
		m->distributed[inst].file_word = open(filename, O_RDWR|O_LARGEFILE|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		word_t word;
		memset(&word, 0, sizeof(word_t));

		for(wordid_t is = 0; is < INSTANCE_MAXWORD; is++)
			write(m->distributed[inst].file_word, &word, sizeof(word_t));

		// Initialize data
		m->distributed[inst].count_word = 0;
	}

	//if(m->distributed[inst].file_word == NULL)
	if(m->distributed[inst].file_word == 0)
	{
		sprintf(filename, "%s/%s", m->distributed[inst].dirname, LANGDDX_FILENAME_WORD);
		die("missing file %s on %s", cberr(), filename);
	}
	
	// assert(m->distributed[inst].file_word != NULL);
	assert(m->distributed[inst].file_word != 0);

	arguments->d = NULL;
	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}

//

//
// Name: langddx_close
//
// Description:
//   Closes a structure. Writes data to disk.
//
// Input:
//   langddx - the langddx structure
//
// Return: 
//   status code
//

langddx_status_t langddx_close(langddx_t *m)
{

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = (pthread_t *) malloc (CONF_COLLECTION_DISTRIBUTED * sizeof(pthread_t));

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		langddx_thread_function_args_t *args = (langddx_thread_function_args_t *) malloc (sizeof(langddx_thread_function_args_t));
		args->i = i;
		args->m = m;
		args->d = NULL;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if(m->readonly == false)
			{
				if (pthread_create(&threads[i], NULL, langddx_thread_function_close, (void *) args))
					die("error creating thread!");
			}
			else
			{
				if (pthread_create(&threads[i], NULL, langddx_thread_function_ronly_close, (void *) args))
					die("error creating thread!");
			}

		}
		else
		{
			if(m->readonly == false)
				langddx_thread_function_close((void *) args); // if only one distribution, function is call without thread
			else
				langddx_thread_function_ronly_close((void *) args); // if only one distribution, function is call without thread 
		}
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}

	// Free
	free(m->distributed);
	free(m);

	return LANGDDX_OK;
}

//
// Name: langddx_thread_function_close
//
// Description: invoked by 'langddx_close' as thread
//
// Arguments: a void pointer to langddx_thread_function_args_t type structure that contain instance and langddx_t type structure 
//
// Return: NULL
//
void *langddx_thread_function_close(void *args)
{
try
{
	cpu_set_t system_cpus;

	langddx_thread_function_args_t *arguments = (langddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	langddx_t *m = arguments->m;

	int rc;

	errno = 0; // errno is thread_local

	// check if file descriptors are valid
	assert(fcntl(m->distributed[inst].file_word, F_GETFL) != 1);

	if (errno != 0)
		die("langddx close: do not have a valid word file descriptor %s\n", cberr());

	word_t word_header;
	memset(&word_header, 0, sizeof(word_t));

	// Generate data for headers
	word_header.wordid = m->distributed[inst].count_word;

	// Write headers
	assert(lseek(m->distributed[inst].file_word, (off64_t)0, SEEK_SET) == 0);

	if (errno != 0)
		die("langddx close: couldn't seek word file %s\n", cberr());

	assert(write(m->distributed[inst].file_word, &word_header, sizeof(word_t)) == sizeof(word_t));

	if (errno != 0)
		die("langddx close: couldn't write word file %s\n", cberr());

	// Test if there is corruption
	if (m->distributed[inst].count_word > 1)
	{
		word_t test;
		test.wordid = (wordid_t)(inst + 1);
		int rc = langddx_word_retrieve(m, &(test));

		if (rc != LANGDDX_OK)
			die("langddx close: corruption at closing time, the langddx has more than 1 wordid but metadata of word 1 can not be read!");

		if (test.wordid != (wordid_t)(inst + 1))
			die("langddx close: corruption at closing time, word 1 was read but had the wrong wordid!");
	}
/*
	rc = fsync(m->distributed[inst].file_word);

	if (errno != 0)
		die("langddx close: error syncing site file descriptor %s\n", cberr());

	assert(rc == 0);
*/
	rc = close(m->distributed[inst].file_word);

	if (errno != 0)
		die("langddx close: error closing word file descriptor %s\n", cberr());

	if (rc != 0)
		die("connddx close: couldn't close word file because return invalid status\n");

	m->distributed[inst].file_word = 0;

	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}

//
// Name: langddx_thread_function_ronly_close
//
// Description: invoked by 'langddx_close' as thread
//
// Arguments: a void pointer to langddx_thread_function_args_t type structure that contain instance and langddx_t type structure 
//
// Return: NULL
//
void *langddx_thread_function_ronly_close(void *args)
{
try
{
	cpu_set_t system_cpus;

	word_t word_header;
	memset(&word_header, 0, sizeof(word_t));

	langddx_thread_function_args_t *arguments = (langddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	langddx_t *m = arguments->m;

	errno = 0; // errno is thread_local

	int rc = close(m->distributed[inst].file_word);

	if (errno != 0)
		die("langddx close: error closing word file descriptor %s\n", cberr());

	if (rc != 0)
		die("connddx close: couldn't close word file because return invalid status\n");

	m->distributed[inst].file_word = 0;

	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}



//
// Name: langddx_remove
//
// Description:
//   Removes files into directories langddx0, langddx1... and optionally langddx0, langddx1... (unneeded)
//
// Input:
//   dirname - the directory
//   

void langddx_remove(const char *dirname)
{
	struct stat64 statbuf;

	pthread_t *threads = NULL;

	instance_t max_instances = 0;

	// check how many directory contain data to delete
	for (instance_t i = 0; i < ((instance_t)(~0)); i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, i);

		if (stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
			max_instances++;
		else
		{
			free(relative_rem_path);
			break;
		}

		free(relative_rem_path);
	}

	if (max_instances > 1)
		threads = (pthread_t *) malloc (max_instances * sizeof(pthread_t));

	for (instance_t i = 0; i < max_instances; i++)
	{
		langddx_thread_function_args_t *args = (langddx_thread_function_args_t *) malloc (sizeof(langddx_thread_function_args_t));
		args->i = i;
		args->m = NULL;
		args->d = (char *)dirname;

		if (max_instances > 1)
		{
			if (pthread_create(&threads[i], NULL, langddx_thread_function_remove, (void *) args))
				die("error creating thread!");
		}
		else
			langddx_thread_function_remove((void *) args); // only one distribution, function is call without thread 
	}

	if (max_instances > 1)
	{
		CBotjoin(threads, max_instances);

		free(threads);
	}
}

//
// Name: langddx_thread_function_remove
//
// Description: invoked by 'langddx_remove' as thread
//
// Arguments: a void pointer to langddx_thread_function_args_t type structure 
//
// Return: NULL
//
void *langddx_thread_function_remove(void *args)
{
try
{
	cpu_set_t system_cpus;

	langddx_thread_function_args_t *arguments = (langddx_thread_function_args_t *)args;

	instance_t inst = arguments->i;

	CPU_OPTIMIZE;

	char *dirname = arguments->d;
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);

	errno = 0; // errno is thread local

	queue<string> files;

	// Push files
	files.push(LANGDDX_FILENAME_WORD);

	// Delete
	while(! files.empty())
	{

		// Create filename
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, files.front().c_str());

		// Delete file
		int rc = unlink(filename);

		if(rc != 0 && errno != ENOENT)
			die("Couldn't unlink file %s on %s", cberr(), files.front().c_str());

		// Remove file from queue
		files.pop();
	}

	if (inst >= CONF_COLLECTION_DISTRIBUTED)
	{
		// Delete dir (rimuove le directory metadata0, metadata1 ecc..)
		int rc = remove(relative_rem_path);

		if(rc != 0 && errno != ENOENT)
			die("Couldn't remove directory %s on %s", cberr(), relative_rem_path);
	}

	free(relative_rem_path);

	arguments->d = NULL;
	free(args);

	return NULL;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL);
}
}

//
// Name: langddx_word_store
//
// Description:
//   Stores information about a word in MULTITHREAD!
//   With 'old_word' it compare byte to byte struct before write to disk (performances reasons).
//
// Input:
//    langddx - the langddx structure
//    word - the word to be stored
//    old_word - the 'old_word' to be compared with the new (only update)
// 
// Return:
//    status code
//
langddx_status_t langddx_word_store(langddx_t *m, word_t *word)
{
	assert(word->wordid > 0);
	assert(word->wordid < CONF_COLLECTION_MAXWORD);
	assert(!m->readonly);

	instance_t instance =	((word->wordid - 1) % CONF_COLLECTION_DISTRIBUTED);
	wordid_t id_offset = (((word->wordid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	errno = 0; // errno is thread_local

	off64_t address = ((off64_t)sizeof(word_t)) * id_offset;

	// Store
	ssize_t wr = pwrite64(m->distributed[instance].file_word, &word, sizeof(word_t), address);

	if (errno != 0)
		die("langddx_word_store: for wordid %llu couldn't write file (address %llu) %s\n", word->wordid, (unsigned long long int)address, cberr());

	assert(wr == (ssize_t)(sizeof(word_t)));

	// Update distributed count
	if (id_offset > m->distributed[instance].count_word)
		m->distributed[instance].count_word = id_offset;

	return LANGDDX_OK;
}

// 
// Name: langddx_word_retrieve
//
// Description:
//   Retrieves information about a wordument
//
// Input:
//   langddx - metaindex holding the information
//   word.wordid - word id of the retrieved word
//
// Output:
//   word - wordument
//
// Return:
//   LANGDDX_OK - success
//   LANGDDX_EOF - wordid out of range
//
langddx_status_t langddx_word_retrieve(langddx_t *m, word_t *word)
{
	assert(word->wordid > 0);

	wordid_t real_wordid = word->wordid;
	instance_t instance =	((word->wordid - 1) % CONF_COLLECTION_DISTRIBUTED);
	word->wordid = (((word->wordid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// See if it's inside the range
	if(word->wordid > m->distributed[instance].count_word)
	{
		word->wordid = real_wordid;
		return LANGDDX_EOF;
	}

	errno = 0; // errno is thread_local

	// Retrieve
	ssize_t wr = pread64(m->distributed[instance].file_word, &word, sizeof(word_t), (off64_t)(sizeof(word_t) * word->wordid));

	if (errno != 0)
		die("langddx_word_retreive: for wordid %llu couldn't read file %s\n", word->wordid, cberr());

	assert(wr == (ssize_t)(sizeof(word_t)));

	if (word->wordid == 0)
		return LANGDDX_EOF;
	else
	{
		word->wordid = real_wordid;
		return LANGDDX_OK;
	}
}

// 
// Name: langddx_dump_word_status
//
// Description:
//   Prints the status of a word
//
// Input:
//   word - word
//

void langddx_dump_word_status(word_t *word)
{
	// Main variables
	cerr << "wordid                 " << word->wordid << endl;

	if (word->language == Stemming::UNKNOWN)
		cerr << "language              " << "UNSUPPORTED by stemming library" << endl;
	else
		cerr << "language              " << STEMMING_STR(word->language) << " (supported by stemming library)" << endl;
}

// 
// Name: langddx_dump_word_header
//
// Description:
//   Prints a line with the header data
//   for langddx_dump_word
//
// Input:
//   out - the output file handler
//
void langddx_dump_word_header(FILE *out)
{
	assert(out != NULL);
	
	// The order is very important. It must be consistent with
	// langddx_dump_word

//	fprintf(out, "1wordid,");
	fprintf(out, "1wordid\n");
//	fprintf(out, "37sitemap priority\n");
}

// 
// Name: langddx_dump_word
//
// Description:
//   Prints a line with the data about a word
//
// Input:
//   word - word
//   out - the output file handler
//

void langddx_dump_word(word_t *word, FILE *out)
{
	assert(word != NULL);
	assert(out != NULL);

	// The order is very important. It must be consistent with
	// langddx_dump_word_header

	// fprintf(out, "%lu,",  	word->wordid);
	fprintf(out, "%lu\n",  	(unsigned long int)word->wordid);
//	fprintf(out, "%d\n",  	doc->sitemap_prio);
}

// 
// Name: langddx_dump_word_short_status
//
// Description:
//   Prints the status of a word in one line
//
// Input:
//   word - word
//

void langddx_dump_word_short_status(word_t *word)
{
/*
	// Status
	cerr << DOC_STATUS_STR(doc->status) << " ";
	cerr << MIME_TYPE_STR(doc->mime_type) << " ";
	cerr << HTTP_STR(doc->http_status) << ":"
		<<	HTTP_IS_STR(doc->http_status) << " ";

	// Scores
	cerr << "in " << doc->in_degree << " ";
	cerr << "out " << doc->out_degree << " ";
	cerr << "pr " << doc->pagerank;
	cerr << "wl " << doc->wlrank;
	cerr << "lr " << doc->liverank;
*/
}

//
// Name: langddx_word_default
//
// Description:
//   Fills all the default data about a word
//
// Input:
//   word - empty word object
//
// Output:
//   word - fill word object
//
void langddx_word_default(word_t *word)
{

	memset(word, 0, sizeof(word_t)); // to prevent valdrind warning set all (but really all) bytes to 0 in structure

	word->wordid			= (wordid_t)0;
	word->language			= Stemming::UNKNOWN;
}

//
// Name: langddx_dump_status
// 
// Description:
//   Dumps the status of the langddx
//

void langddx_dump_status(langddx_t *langddx)
{
	cerr << "Begin status dump for langddx" << endl;

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		cerr << "- dirname on distributed   " << i << " is " << langddx->distributed[i].dirname << endl;
		cerr << "- count_word  on distributed " << i << " is " << langddx->distributed[i].count_word << endl;
	}

	cerr << "- count_word      " << langddx->count_word << endl;
	cerr << "- bytes per word   " << sizeof(word_t) << endl;
	cerr << "End status dump for langddx" << endl;
}

