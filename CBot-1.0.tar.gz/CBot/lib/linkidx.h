/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _LINKIDX_H_INCLUDED_
#define _LINKIDX_H_INCLUDED_

#include <config.h>

// System libraries

#include <stdlib.h>
#include <assert.h>
#include <fstream>
#include <pthread.h>

// Local libraries

#include <const.h>
#include <Meta.h>
#include <Storage.h>
#include <Url.h>

// Filenames

#define FILENAME_LINKS_DOWNLOAD		"links_download.txt"
#define FILENAME_LINKS_LOG			"links_log.txt"
#define FILENAME_LINKS_STAT			"links_stat.txt"
#define FILENAME_RESOLVED_LINKS		"links_download_resolved.txt"
#define DEPTH_UNDEFINED				(200)

// Constants

#define LINK_MAX_OUTDEGREE				350
#define LINK_CAPTION_BASE_URL			"<BASE-URL>" // base url
#define LINK_CAPTION_FORBIDDEN			"<FORB>" // forbidden
#define LINK_CAPTION_SITEMAP			"<SMAP>" // sitemap.xml
#define LINK_CAPTION_LAST_MODIFIED		"<LMOD>" // per sitemap rdf
#define LINK_CAPTION_NEWS_LAST_MODIFIED	"<NLMOD>" // per sitemap e feed xml
#define LINK_CAPTION_CHANGEFREQ			"<CFREQ>" // per sitemap xml
#define LINK_CAPTION_PRIORITY			"<PRIO>" // per sitemap xml
#define LINK_CAPTION_RSS_FEED			"<RSSF>" // rss+xml feed url
#define LINK_CAPTION_ATOM_FEED			"<ATOF>" // atom+xml feed url

#define LINK_SCORE_MAX_ITERATIONS		(500)
#define LINK_ANALYSIS_CALC_PAGERANK		(1<<0)
#define LINK_ANALYSIS_CALC_CBOTSCORE	(1<<1)
#define LINK_ANALYSIS_CALC_HITS			(1<<2)

// Enumeration for the emphasis tags
enum em_tag_t {
    TAG_UNDEF	= 0,
    TAG_H1		= 1,
    TAG_H2		= 2,
    TAG_H3		= 3,
    TAG_H4		= 4,
    TAG_H5		= 5,
    TAG_H6		= 6,
    TAG_B		= 7,
    TAG_FONT	= 8,
    TAG_STRONG	= 9
};

#define TAG_STR(x) (\
		(x == TAG_UNDEF)	? "TAG_UNDEF"	:\
		(x == TAG_H1)		? "TAG_H1"		:\
		(x == TAG_H2)		? "TAG_H2"		:\
		(x == TAG_H3)		? "TAG_H3"		:\
		(x == TAG_H4)		? "TAG_H4"		:\
		(x == TAG_H5)		? "TAG_H5"		:\
		(x == TAG_H6)		? "TAG_H6"		:\
		(x == TAG_B)		? "TAG_B"		:\
		(x == TAG_FONT)		? "TAG_FONT"	:\
		(x == TAG_STRONG)	? "TAG_STRONG"  :\
		"(invalid)")

// Link index status

enum linkidx_status_t {
	LINKIDX_OK         = 0,
	LINKIDX_ERROR,
	LINKIDX_DUPLICATE
};

// Structures. This contains a storage_t inside
typedef struct {
	char dirname[MAX_STR_LEN-1];
	bool readonly;
} linkidx_t;

// Structure to store a out link used for ranking calculations
typedef struct{
	docid_t dest;
	char rel_pos;
	char tag;
	int anchor_length;

	// Sperimentale per uso futuro
	// bool use_https;
	// bool use_sardex;
	// bool use_semantic;
} out_link_t;

enum doclink_call_t {
    DOCLINK_CREATE                 = 0,
    DOCLINK_LOAD                   = 1,
    DOCLINK_UNLOAD                 = 2,
    DOCLINK_ANALYSIS_DOCRANK      = 3
};

// testing use to compare doubles (con approssimazione)
template<typename S> int  CmpDouble (S a, S b)
{
	return fabs (a - b) >= 0.000001 ? a < b ? -1 : +1 : 0;
}

//
// Name: Doclink
//
// Description: Class that with calling other class execute siterank ranking
//
// Input:
//
// Return: 
//
class Doclink
{
	// Type for link_weight
	typedef double linkweight_t;

	// Structure to store siteid and domainid
	typedef struct{
		siteid_t siteid;
		siteid_t domainid;
	} domains_t;

	// Structure to store siteid and domainid
	typedef struct _site_out_degree_t {
		docid_t count;
		docid_t out_link;
		_site_out_degree_t *next;
	} site_out_degree_t;

	linkidx_t *distributed;
	const char *dirname;
	bool readonly;
	Storage *lidx;
	siteid_t nsites;
	docid_t ndocs;
	docid_t *in_degree;
	docid_t *out_degree;
	docid_t *in_degree_external;
	docid_t *out_degree_external;
	site_out_degree_t *site_out_degree_external;
	domains_t *domainsid;
	pagerank_t *pagerank;
	pagerank_t *pagerankTmp;
	wlrank_t *wlrank;
	wlrank_t *wlrankTmp;
	linkweight_t *sum_out_weight;
	hubrank_t *hub;
	hubrank_t *hubTmp;
	authrank_t *auth;
	authrank_t *authTmp;
	liverank_t *liverank;
//	liverank_t *liverankTmp;
	depth_t *depth;
	unsigned char *last_sketch_gap;
	bool *is_ignored;
	docid_t *ndocs_active;
	atomic<internal_long_uint_t> print_winner;
	atomic<internal_long_uint_t> print_winner2;
	unsigned char *max_gap;
	liverank_t *max_liverank;
	pagerank_t *sum_pageranks;
	wlrank_t *sum_wlranks;
	hubrank_t *sum_hubs;
	authrank_t *sum_auths;
	double *pagerank_delta;
	double *wlrank_delta;
	double *hub_delta;
	double *auth_delta;
	docid_t *hub_gt_zero;
	docid_t *auth_gt_zero;
	docid_t *count_depth_undefined;
	atomic<docid_t> *nmarked;
	const unsigned char nmarked_size = 3;

	pthread_barrier_t *barrier;
	pthread_mutex_t *slocks;
	pthread_mutex_t *dlocks;
	instance_t static_random_inst;

	// Function required by analysis_doclink (pthread use)
	void *thread_function_analysis_docrank(void *);

	// Template Function required by order_by_score (single thread)
	template<typename D, typename S> static int sortcmp (const void *a, const void *b, void *arg)
	{
		S *p = (S *)arg;

	    if (p[(*((const D *)a))] < p[(*((const D *)b))])
			return false;

		return true;
	}

	// Function to proxy to non-static function
	static void* thread_function_caller(void *);

	// Syncronize threads with barrier
	void sync_threads(pthread_barrier_t *);

	public:

	Doclink (const char *_X, bool _Y) // ctor
		: distributed (CBALLOC(linkidx_t, NEW, CONF_COLLECTION_DISTRIBUTED)) // Create sitelinkidx structure
		, dirname (_X)
		, readonly (_Y)
		, lidx (NULL)
		, nsites (0)
		, ndocs (0)
		, in_degree (NULL)
		, out_degree (NULL)
		, in_degree_external (NULL)
		, out_degree_external (NULL)
		, site_out_degree_external (NULL)
		, domainsid (NULL)
		, pagerank  (NULL)
		, pagerankTmp  (NULL)
		, wlrank	 (NULL)
		, wlrankTmp	 (NULL)
		, sum_out_weight  (NULL)
		, hub (NULL)
		, hubTmp (NULL)
		, auth (NULL)
		, authTmp (NULL)
		, liverank (NULL)
//		, liverankTmp  (NULL)
		, depth (NULL)
		, last_sketch_gap (NULL)
		, is_ignored (NULL)
		, ndocs_active (NULL)
		, print_winner (0)
		, print_winner2 (0)
		, max_gap (NULL)
		, max_liverank (NULL)
		, sum_pageranks (NULL)
		, sum_wlranks (NULL)
		, sum_hubs (NULL)
		, sum_auths (NULL)
		, pagerank_delta (NULL)
		, wlrank_delta (NULL)
		, hub_delta (NULL)
		, auth_delta (NULL)
		, hub_gt_zero (NULL)
		, auth_gt_zero (NULL)
		, count_depth_undefined (NULL)
		, nmarked (NULL)
		, barrier (NULL)
		, slocks (NULL)
		, dlocks (NULL)
		, static_random_inst (rand() % CONF_COLLECTION_DISTRIBUTED)
	{
	}

	~Doclink () // dtor
	{
		if (distributed != NULL)
		{
			delete [] distributed;
			distributed = NULL;
		}
	}

	// need to passing arguments to threads functions
	// Because function call by pthread_create need to be pass first through 'thread_function_caller', these works with other temporary object
	typedef struct {
		instance_t inst;
		Doclink *obj;
		doclink_call_t f; // corrisponde alla chiamata di determinate funzioni fatta da pthread_create
		Meta *meta; // only for analysis
		Url *url; // only for fixing depths
		Storage *strg; // only for analysis
		Storage *lidx; // only for fixing depths
		perfhash_t *extensions_dynamic;
		bool first_harvest_exist;
        bool opt_calc_pagerank;
        bool opt_calc_wlrank;
        bool opt_calc_hits;
        bool opt_calc_liverank;
        bool opt_linearize;
        bool opt_fix_depths;
        bool opt_mark_dynamic;
        bool opt_mark_ignored;
		atomic<docid_t> *ndocs_marked_dynamic_static;
		atomic<docid_t> *ndocs_marked_static_dynamic;
		atomic<docid_t> *ndocs_marked_depth_static;
		atomic<docid_t> *ndocs_marked_depth_dynamic;
		atomic<docid_t> *ndocs_marked_too_many;
	} thread_args_t;

	// Connect external pointer of index to pointer inside class
	void idx_connect(Storage *);

	// Calculates the link-based statistics for all the documents
	void analysis_docrank(Meta *, Url *, Storage *, Storage *, bool, bool, bool, bool, bool, bool, bool, bool);

	// Sort array of scores by order array and linearize
	template<typename D, typename S> void order_by_score(D *order, S *scores, D ndocs, D fract, bool *is_ignored, bool check_zero) const
	{
		assert(order != NULL);
		assert(scores != NULL);
		assert(is_ignored != NULL);
	
		unsigned char offset = 1;
	
		for (unsigned char o = 0; o < offset; o++)
			order[o] = 0;
	
		// Prepare array for linearization
		for (docid_t i = offset; i <= ndocs; i++)
			order[i] = (D)i; // Warning: note this assigment, it's essential to make sorting with 'stable_sort'
	
		D *pstart = order;
	
		order = (&order[offset]);
	
		// Quick sort
		qsort_r(order, ndocs, sizeof(docid_t), sortcmp<D, S>, scores);
	
		// Shift, so newly the order starts from 0 offset
		order = pstart;
	
		// cerr << "assigning, ";
		S step = (S)1/(S)(fract);
		S current_value = step;
	
		// linearize
		if (check_zero == false)
			for (docid_t i = offset; i <= ndocs; i++)
				if (is_ignored[order[i]] == true)
					scores[order[i]] = (S)0;
				else
				{
					scores[order[i]] = current_value;
					current_value += step;
				}
		else
			for (docid_t i = offset; i <= ndocs; i++)
				if (is_ignored[order[i]] == true)
					scores[order[i]] = (S)0;
				else if (scores[order[i]] > 0)
				{
					scores[order[i]] = current_value;
					current_value += step;
				}
	}

	// lock a mutex
	void lock(instance_t &id_instance, pthread_mutex_t *locks)
    {
		int rc = 0;

        if (locks != NULL && (rc = pthread_mutex_lock(&(locks[id_instance]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
    }

	// lock a mutex
	void unlock(instance_t &id_instance, pthread_mutex_t *locks)
    {
		int rc = 0;

        if (locks != NULL && (rc = pthread_mutex_unlock(&(locks[id_instance]))) != 0)
			die("error unlocking mutex %s", CBoterr(rc));
    }
};

// Type for link_weight
typedef double linkweight_t;

// Functions

linkweight_t calculate_link_weight(out_link_t link);

Storage *linkidx_open( const char *, bool );

linkidx_status_t linkidx_store( Storage *, docid_t, out_link_t [], unsigned int );
linkidx_status_t linkidx_retrieve( Storage *, instance_t, docid_t, out_link_t [], unsigned int * );
linkidx_status_t linkidx_retrieve_using_buffer( Storage *, instance_t, char *, docid_t, out_link_t [], unsigned int * );

void linkidx_prepare_sequential_read( Storage *, instance_t & );

void linkidx_dump_links( Storage *, docid_t );
void linkidx_dump_links_checking( Storage *, docid_t, char * );
void linkidx_dump_links_with_url( Storage *, Url *, docid_t );
void linkidx_show_links( Storage *, docid_t );

// need to passing arguments to threads functions
typedef struct {
    instance_t inst;
	pthread_barrier_t *barrier; // barrier declared inside calling function
	Storage *lidx;
	Meta *meta;
	Url *url;
	depth_t *depth;
	docid_t *count_depth_undefined;
} linkidx_thread_args_t;

// INLINED functions (used by sitelink)

//
// Name: linkidx_sequential_read
//
// Description:
//   Reads the links for the next document
//
// Input:
//   linkidx - the structure
//   buffer - a buffer
//
// Output:
//   dest[] - destinations of links
//   outdegree - out degree
//

inline void linkidx_sequential_read(Storage *lidx, instance_t &inst, out_link_t dest[], uint *out_degree)
{
	storage_record_t rec;
	storage_status_t rc;

	rc = lidx->sequential_read(inst, &(rec), (char *)(dest));

	if (rc == STORAGE_NOT_FOUND)
		*out_degree = 0;
	else // Get out_degree
		*out_degree = rec.size/sizeof(out_link_t);


}

// 
// Name: linkidx_sequential_skip
//
// Description:
//   Skips a number of records, this is useful to skip
//   several documents with zero out-degree
//
// Input:
//   linkidx - the structure
//   skip - the number of records to skip
//

inline void linkidx_sequential_skip(Storage *lidx, instance_t &inst, uint skip)
{
	lidx->sequential_skip(inst, skip);
}

// 
// Name: linkidx_calc_delta
//
// Description:
//   Returns the ratio between the larger and the smaller value
//   minus one.
//
// Input:
//   a, b - numbers to divide
//

inline double linkidx_calc_delta(double a, double b)
{
	if (a > b && b > 0)
		return (a/b) - (double)1;
	else if (a < b && a > 0)
		return (b/a) - (double)1;
	else
		return 0;
}

#endif
