/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _DYMDDX_H_
#define _DYMDDX_H_

#include <config.h>

// System libraries

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <iostream>
#include <string.h>
#include <queue>
#include <string>
#include <errno.h>
#include <sys/time.h>
#include <atomic>

using namespace std;

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "utils.h"
#include "http_charset.h"

// Constants

/*
	N.B.
	- idx sta per: index
	- ddx sta per: distributed index
*/

/*
	N.B.
	- gram o ngram sta per: n-gram (unigram, bigram, trigram, ecc...)
*/

/*
	N.B.
	- il prerequisito fondamentale per l'algoritmo per la gestione delle sequenze a memoria volatile dinamica, è quello
	  di essere avviato una sola volta!
*/

// Filenames
#define DYMDDX_FILENAME_WORD_LIST		"dymddx.wordlist"
#define DYMDDX_FILENAME_WORD			"dymddx.word"
#define DYMDDX_FILENAME_WORD_HASH		"dymddx.wordhash"

#define DYMDDX_FILENAME_STEM_LIST		"dymddx.stemlist"
#define DYMDDX_FILENAME_STEM			"dymddx.stem"
#define DYMDDX_FILENAME_STEM_HASH		"dymddx.stemhash"

#define DYMDDX_FILENAME_SOURCEID_LIST	"dymddx.sourceidlist"
#define DYMDDX_FILENAME_SOURCEID_HASH	"dymddx.sourceidhash"
#define DYMDDX_FILENAME_GRAM_LIST		"dymddx.gramlist"
#define DYMDDX_FILENAME_GRAM			"dymddx.gram"
#define DYMDDX_FILENAME_GRAM_HASH		"dymddx.gramhash"
#define DYMDDX_FILENAME_ALL         	"dymddx.main"

#define DYMDDX_MAX_OCCUPANCY			((float)0.8)

// Status

enum dymddx_status_t { 
	DYMDDX_ERROR 					= 0,
	DYMDDX_CREATED_WORD				= 1,
	DYMDDX_CREATED_STEM				= 2,
	DYMDDX_CREATED_GRAM				= 3,
	DYMDDX_EXISTENT					= 4,
	DYMDDX_NOT_FOUND				= 5
};

// Constants

#define DYMDDX_LANGID_LIST_SIZE 131072L // must be minor of wordid_t ('L' serve per evitare avvisi del compilatore del tipo 'integer overflow in expression')
#define DYMDDX_MAX_LANGID_LIST 768L // massimo numero di allocazioni di memoria (pad (< USHRT_MAX))
#define DYMDDX_WORDID_LIST_SIZE 131072L // must be minor of wordid_t ('L' serve per evitare avvisi del compilatore del tipo 'integer overflow in expression')
#define DYMDDX_MAX_WORDID_LIST 768L // massimo numero di allocazioni di memoria (pad (< USHRT_MAX))


const off64_t EXPECTED_WORD_SIZE = 8; // in bytes 
const off64_t DYMDDX_EXPECTED_WORD_SIZE = (EXPECTED_WORD_SIZE + 1 + sizeof(wordid_t));
const off64_t EXPECTED_STEM_SIZE = 8; // in bytes 
const off64_t DYMDDX_EXPECTED_STEM_SIZE = (EXPECTED_STEM_SIZE + 1 + sizeof(stemid_t));
const off64_t EXPECTED_GRAM_SIZE = 8; // in bytes 
const off64_t DYMDDX_EXPECTED_GRAM_SIZE = (EXPECTED_GRAM_SIZE + 1 + sizeof(gramid_t));
const off64_t DYMDDX_NGRAM_LEN = 3; // number of "byte/multibyte characters" in n-grams

// dymlist_word_t structures
// needed from 'by_wordid' function
typedef struct {
	wordid_t hash_pos;
	instance_t bucket_instance;
//	dymrank_t rank;
} dymlist_word_t;

// dymlist_stem_t structures
// needed from 'by_stemid' function
typedef struct {
	stemid_t hash_pos;
	instance_t bucket_instance;
//	dymrank_t rank;
} dymlist_stem_t;

// dymlist_gram_t structures
// needed from 'by_gramid' function
typedef struct {
	gramid_t hash_pos;
	instance_t bucket_instance;
//	dymrank_t rank;
} dymlist_gram_t;

typedef struct {
	pthread_mutex_t *locka; // id instance locks
	pthread_mutex_t *lockb; // bucket instance locks
	pthread_mutex_t *lockc; // sequence locks
} dymmutex_t;

typedef wordid_t sid_t;

// w_seq_t structure
// used on volatile memory, to find languages provenience
typedef struct {
	Stemming lang;
//	wordid_t wordid; // uso debug
	off64_t next_offset;
	unsigned long long int count;
} w_seq_t;

// seq_t structure
// used on volatile memory, to find words provenience
typedef struct {
	sid_t id;
//	gramid_t gramid; // uso debug
	off64_t next_offset;
} g_seq_t;

// Linked List for sequence
typedef struct seq_ptr {
	off64_t *hash;
	void *seq; // per assegnare un valore ad esso occorre sempre prima effettuare uno static cast e in questo caso può essere tipo (g_seq_t *) o (w_seq_t *)
	seq_ptr *next_pad;
} sequence_t;

// ddx structure
// Note that this is saved "as-is" to disk, so if you change it,
// it will misbehave.

typedef struct {
	// Words vs Language
	char *word;					// Strings    [memory]
	std::atomic<off64_t *> word_hash;			// Hash table [memory] (share data)
	std::atomic<wordid_t> word_count;		// Count      [memory] (share data)
	off64_t word_next_char;		// String Pos [memory]
	FILE *word_list;			// List       [disk]
	sequence_t *w_seqs;			// Volatile sequents of id [memory]
	off64_t w_seq_count;		// Volatile count      [memory]
	// Stemming
	char *stem;					// Strings    [memory]
	std::atomic<off64_t *> stem_hash;			// Hash table [memory] (share data)
	std::atomic<stemid_t> stem_count;		// Count      [memory] (share data)
	off64_t stem_next_char;		// String Pos [memory]
	FILE *stem_list;			// List       [disk]
	// Trigram
	char *gram;					// Strings    [memory]
	std::atomic<off64_t *> gram_hash;			// Hash table [memory] (share data)
	std::atomic<gramid_t> gram_count;		// Count      [memory] (share data)
	off64_t gram_next_char;		// String Pos [memory]
	FILE *gram_list;			// List       [disk]
	off64_t *sourceid_hash_src;		// Start of first sourceid [memory]
	FILE *sourceid_list_src;		// List       [disk]
	off64_t *sourceid_hash_dst;		// Start of first sourceid [memory]
	FILE *sourceid_list_dst;		// List       [disk]
	off64_t *seqs_hash;	// Volatile start of first sourceid [memory] 
	sequence_t *g_seqs;		// Volatile sequences of id [memory]
	off64_t g_seq_count;		// Volatile count      [memory]

	// Info
	char dirname[MAX_STR_LEN];
	// bool readonly;
} wddx_t;

// dymddx_t words container ddx work
typedef struct {
	wddx_t *distributed;
	dymmutex_t *wlock; // mutex must be declared inside function that create threads
	dymmutex_t *slock; // and pointed here
	dymmutex_t *glock; // ...
	std::atomic<wordid_t> threads_word_count; // *
	std::atomic<stemid_t> threads_stem_count; // *
	std::atomic<gramid_t> threads_gram_count; // *
	std::atomic<wordid_t> word_count; // (share data) in caso di multithread questi contatori devo essere poter letti durante la fase di scrittura di nuovi id
	std::atomic<stemid_t> stem_count; // (grazie ad 'atomic' è garantita la coerenza del dato in lettura) e vengono bloccati solo
	std::atomic<gramid_t> gram_count; // durante il loro incremento. Quelli che saranno bloccati durante tutta la scrittura sono sopra evidenziati con *.
	bool readonly;
} dymddx_t;

typedef struct {
	sid_t id;
	unsigned int rank;
} ranking_t;

// need to passing arguments to threads functions
typedef struct {
    instance_t i;
    dymddx_t *u;
    char *d;
} dymddx_thread_function_args_t;

// Functions

// Create a new index
dymddx_t *dymddx_new( const char * );

// Function required by dymddx_new (pthread use)
void *dymddx_thread_function_new( void * );

// Open a URL index
dymddx_t *dymddx_open( const char *, bool );

// Function for allocate memory and create mutex
void dymddx_setmutex( dymddx_t *, dymmutex_t **, dymmutex_t **, dymmutex_t ** );

// Function required by dymddx_open (pthread use)
void *dymddx_thread_function_open( void * );

// Removes a URL index
void dymddx_remove( const char * );

// Function required by dymddx_remove (pthread use)
void *dymddx_thread_function_remove( void * );

// Dumps the words language associations index status
void dymddx_dump_status( dymddx_t *u );

// Close an URL index
void dymddx_close( dymddx_t *u );

// Function required by dymddx_close (pthread use)
void *dymddx_thread_function_close( void * );

// Function for free memory and destroy mutex
void dymddx_destroymutex( dymddx_t *u );

// Get the wordid for a word (multithread)
dymddx_status_t dymddx_resolve_word( dymddx_t *,const char *, wordid_t *, Stemming *, bool );

// Get the stemid for a stemming (multithread)
dymddx_status_t dymddx_resolve_stem( dymddx_t *,const char *, wordid_t *, bool );

// Get the gramid for a n-gram (multithread)
dymddx_status_t dymddx_resolve_gram( dymddx_t *,const char *, gramid_t *, wordid_t *, bool );

// Get the candidate language for a wordid
Stemming dymddx_get_candidate_lang( dymddx_t *,wordid_t * );

// Create or modify element of sequence of languages
void dymddx_create_lang_element( dymddx_t *, wordid_t *, Stemming * );

// Create element of sequence of n-grams
void dymddx_create_word_element( dymddx_t *, gramid_t *, wordid_t * );

// Get the wordid for a word
wordid_t dymddx_check_word( dymddx_t *, const char *, wordid_t * );

// Get the stemid for a stemming
stemid_t dymddx_check_stem( dymddx_t *, const char *, wordid_t * );

// Get the gramid for a n-gram
wordid_t dymddx_check_gram( dymddx_t *, const char *, wordid_t * );

// Get a word from a wordid
void dymddx_word_by_wordid( dymddx_t *, wordid_t &, char * );

// Get a stemming from a stemid
void dymddx_stem_by_stemid( dymddx_t *, stemid_t &, char * );

// Get a n-grams from a gramid
void dymddx_gram_by_gramid( dymddx_t *, gramid_t &, char * );

// Hash functions
wordid_t dymddx_hashing_word( const char * );

// Hash functions
wordid_t dymddx_hashing_stem( const char * );

// Hash functions
wordid_t dymddx_hashing_gram( const char * );

#endif
