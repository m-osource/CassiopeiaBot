/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _HTTP_CHARSET_H_INCLUDED_
#define _HTTP_CHARSET_H_INCLUDED_

#include <config.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iconv.h>
#include <errno.h>
#include <iostream>

#include "const.h"

//Para charset detection
#include "nscore.h"
#include "nsUniversalDetector.h"

using namespace std;

//Charset Types
enum charset_t {
    CHARSET_UNKNOWN      = 0,
    CHARSET_ISO_8859_1   = 1,
    CHARSET_UTF_8        = 2,
    CHARSET_EUC_KR       = 3,
    CHARSET_ISO_8859_15  = 4,
    CHARSET_WINDOWS_1252 = 5,
    CHARSET_UTF_16       = 6,
    CHARSET_EUC_JP       = 7,
    CHARSET_KOI8_R       = 8,
    CHARSET_KOI8_U       = 9,
    CHARSET_ISO_8859_2   = 10,
    CHARSET_ISO_8859_3   = 11,
    CHARSET_ISO_8859_4   = 12,
    CHARSET_ISO_8859_5   = 13,
    CHARSET_ISO_8859_6   = 14,
    CHARSET_ISO_8859_6_I = 15,
    CHARSET_ISO_8859_6_E = 16,
    CHARSET_ISO_8859_7   = 17,
    CHARSET_ISO_8859_8   = 18,
    CHARSET_ISO_8859_8_I = 19,
    CHARSET_ISO_8859_8_E = 20,
    CHARSET_ISO_8859_9   = 21,
    CHARSET_ISO_8859_10  = 22,
    CHARSET_ISO_8859_11  = 23,
    CHARSET_ISO_8859_13  = 24,
    CHARSET_ISO_8859_14  = 25,
    CHARSET_ISO_8859_16  = 26,
    CHARSET_ISO_IR_111   = 27,
    CHARSET_ISO_2022_CN  = 29,
    CHARSET_ISO_2022_KR  = 30,
    CHARSET_ISO_2022_JP  = 31,
    CHARSET_US_ASCII     = 32,
    CHARSET_UTF_32BE     = 33,
    CHARSET_UTF_32LE     = 34,
    CHARSET_UTF_16BE     = 35,
    CHARSET_UTF_16LE     = 36,
    CHARSET_WINDOWS_1250 = 37,
    CHARSET_WINDOWS_1251 = 38,
    CHARSET_WINDOWS_1253 = 39,
    CHARSET_WINDOWS_1254 = 40,
    CHARSET_WINDOWS_1255 = 41,
    CHARSET_WINDOWS_1256 = 42,
    CHARSET_WINDOWS_1257 = 43,
    CHARSET_WINDOWS_1258 = 44,
    CHARSET_IBM866       = 45,
    CHARSET_IBM850       = 46,
    CHARSET_IBM852       = 47,
    CHARSET_IBM855       = 48,
    CHARSET_IBM857       = 49,
    CHARSET_IBM862       = 50,
    CHARSET_IBM864       = 51,
    CHARSET_IBM864I      = 52,
    CHARSET_UTF_7        = 53,
    CHARSET_SHIFT_JIS    = 54,
    CHARSET_BIG5         = 55,
    CHARSET_GB2312       = 56,
    CHARSET_GB18030      = 57,
    CHARSET_VISCII       = 58,
    CHARSET_TIS_620      = 59,
    CHARSET_HZ_GB_2312   = 61,
    CHARSET_BIG5_HKSCS   = 62,
    CHARSET_X_GBK        = 63,
    CHARSET_X_EUC_TW     = 64
};

#define CHARSET_STR(x) (\
    (x==CHARSET_ISO_8859_1) ? "ISO-8859-1" :\
    (x==CHARSET_UTF_8) ? "UTF-8" :\
    (x==CHARSET_EUC_KR) ? "EUC-KR" :\
    (x==CHARSET_ISO_8859_15) ? "ISO-8859-15" :\
    (x==CHARSET_WINDOWS_1252) ? "windows-1252" :\
    (x==CHARSET_UTF_16) ? "UTF-16" :\
    (x==CHARSET_EUC_JP) ? "EUC-JP" :\
    (x==CHARSET_KOI8_R) ? "KOI8-R" :\
    (x==CHARSET_KOI8_U) ? "KOI8-U" :\
    (x==CHARSET_ISO_8859_2) ? "ISO-8859-2" :\
    (x==CHARSET_ISO_8859_3) ? "ISO-8859-3" :\
    (x==CHARSET_ISO_8859_4) ? "ISO-8859-4" :\
    (x==CHARSET_ISO_8859_5) ? "ISO-8859-5" :\
    (x==CHARSET_ISO_8859_6) ? "ISO-8859-6" :\
    (x==CHARSET_ISO_8859_6_I) ? "ISO-8859-6-I" :\
    (x==CHARSET_ISO_8859_6_E) ? "ISO-8859-6-E" :\
    (x==CHARSET_ISO_8859_7) ? "ISO-8859-7" :\
    (x==CHARSET_ISO_8859_8) ? "ISO-8859-8" :\
    (x==CHARSET_ISO_8859_8_I) ? "ISO-8859-8-I" :\
    (x==CHARSET_ISO_8859_8_E) ? "ISO-8859-8-E" :\
    (x==CHARSET_ISO_8859_9) ? "ISO-8859-9" :\
    (x==CHARSET_ISO_8859_10) ? "ISO-8859-10" :\
    (x==CHARSET_ISO_8859_11) ? "ISO-8859-11" :\
    (x==CHARSET_ISO_8859_13) ? "ISO-8859-13" :\
    (x==CHARSET_ISO_8859_14) ? "ISO-8859-14" :\
    (x==CHARSET_ISO_8859_16) ? "ISO-8859-16" :\
    (x==CHARSET_ISO_IR_111) ? "ISO-IR-111" :\
    (x==CHARSET_ISO_2022_CN) ? "ISO-2022-CN" :\
    (x==CHARSET_ISO_2022_CN) ? "ISO-2022-CN" :\
    (x==CHARSET_ISO_2022_KR) ? "ISO-2022-KR" :\
    (x==CHARSET_ISO_2022_JP) ? "ISO-2022-JP" :\
    (x==CHARSET_US_ASCII) ? "us-ascii" :\
    (x==CHARSET_UTF_32BE) ? "UTF-32BE" :\
    (x==CHARSET_UTF_32LE) ? "UTF-32LE" :\
    (x==CHARSET_UTF_16BE) ? "UTF-16BE" :\
    (x==CHARSET_UTF_16LE) ? "UTF-16LE" :\
    (x==CHARSET_WINDOWS_1250) ? "windows-1250" :\
    (x==CHARSET_WINDOWS_1251) ? "windows-1251" :\
    (x==CHARSET_WINDOWS_1253) ? "windows-1253" :\
    (x==CHARSET_WINDOWS_1254) ? "windows-1254" :\
    (x==CHARSET_WINDOWS_1255) ? "windows-1255" :\
    (x==CHARSET_WINDOWS_1256) ? "windows-1256" :\
    (x==CHARSET_WINDOWS_1257) ? "windows-1257" :\
    (x==CHARSET_WINDOWS_1258) ? "windows-1258" :\
    (x==CHARSET_IBM866) ? "IBM866" :\
    (x==CHARSET_IBM850) ? "IBM850" :\
    (x==CHARSET_IBM852) ? "IBM852" :\
    (x==CHARSET_IBM855) ? "IBM855" :\
    (x==CHARSET_IBM857) ? "IBM857" :\
    (x==CHARSET_IBM862) ? "IBM862" :\
    (x==CHARSET_IBM864) ? "IBM864" :\
    (x==CHARSET_IBM864I) ? "IBM864i" :\
    (x==CHARSET_UTF_7) ? "UTF-7" :\
    (x==CHARSET_SHIFT_JIS) ? "Shift_JIS" :\
    (x==CHARSET_BIG5) ? "Big5" :\
    (x==CHARSET_GB2312) ? "GB2312" :\
    (x==CHARSET_GB18030) ? "gb18030" :\
    (x==CHARSET_VISCII) ? "VISCII" :\
    (x==CHARSET_TIS_620) ? "TIS-620" :\
    (x==CHARSET_HZ_GB_2312) ? "HZ-GB-2312" :\
    (x==CHARSET_BIG5_HKSCS) ? "Big5-HKSCS" :\
    (x==CHARSET_X_GBK) ? "x-gbk" :\
    (x==CHARSET_X_EUC_TW) ? "x-euc-tw" : "(undefined)" )

//Language Types (grazie a class è possibile utilizzare gli stessi nomi di elementi per classi diverse)
enum class Language : unsigned char {
	UNKNOWN     = 0,
	AB			= 1,
	AA			= 2,
	AF			= 3,
	SQ			= 4,
	AM			= 5,
	AR			= 6,
	HY			= 7,
	AS			= 8,
	AY			= 9,
	AZ			= 10,
	BA			= 11,
	EU			= 12,
	BN			= 13,
	DZ			= 14,
	BH			= 15,
	BI			= 16,
	BR			= 17,
	BG			= 18,
	MY			= 19,
	BE			= 20,
	KM			= 21,
	CA			= 22,
	ZH			= 23,
	CO			= 24,
	HR			= 25,
	CS			= 26,
	DA			= 27,
	NL			= 28,
	EN			= 29,
	EO			= 30,
	ET			= 31,
	FO			= 32,
	FJ			= 33,
	FI			= 34,
	FR			= 35,
	FY			= 36,
	GD			= 37,
	GL			= 38,
	KA			= 39,
	DE			= 40,
	EL			= 41,
	KL			= 42,
	GN			= 43,
	GU			= 44,
	HA			= 45,
	IW			= 46,
	HI			= 47,
	HU			= 48,
	IS			= 49,
	IN			= 50,
	IA			= 51,
	IE			= 52,
	IK			= 53,
	GA			= 54,
	IT			= 55,
	JA			= 56,
	JW			= 57,
	KN			= 58,
	KS			= 59,
	KK			= 60,
	RW			= 61,
	KY			= 62,
	RN			= 63,
	KO			= 64,
	KU			= 65,
	LO			= 66,
	LA			= 67,
	LV			= 68,
	LN			= 69,
	LT			= 70,
	MK			= 71,
	MG			= 72,
	MS			= 73,
	ML			= 74,
	MT			= 75,
	MI			= 76,
	MR			= 77,
	MO			= 78,
	MN			= 79,
	NA			= 80,
	NE			= 81,
	NO			= 82,
	OC			= 83,
	OR			= 84,
	OM			= 85,
	PS			= 86,
	FA			= 87,
	PL			= 88,
	PT			= 89,
	PA			= 90,
	QU			= 91,
	RM			= 92,
	RO			= 93,
	RU			= 94,
	SM			= 95,
	SG			= 96,
	SA			= 97,
	SC			= 98, // Sardu - Sardo
	SR			= 99,
	SH			= 100,
	ST			= 101,
	TN			= 102,
	SN			= 103,
	SD			= 104,
	SI			= 105,
	SS			= 106,
	SK			= 107,
	SL			= 108,
	SO			= 109,
	ES			= 110,
	SU			= 111,
	SW			= 112,
	SV			= 113,
	TL			= 114,
	TG			= 115,
	TA			= 116,
	TT			= 117,
	TE			= 118,
	TH			= 119,
	BO			= 120,
	TI			= 121,
	TO			= 122,
	TS			= 123,
	TR			= 124,
	TK			= 125,
	TW			= 126,
	UK			= 127,
	UR			= 128,
	UZ			= 129,
	VI			= 130,
	VO			= 131,
	CY			= 132,
	WO			= 133,
	XH			= 134,
	JI			= 135,
	YO			= 136,
	ZU			= 137
};

#define LANGUAGE_STR(x) (\
	(x==Language::AB)		? "AB" :\
	(x==Language::AA)		? "AA" :\
	(x==Language::AF)		? "AF" :\
	(x==Language::SQ)		? "SQ" :\
	(x==Language::AM)		? "AM" :\
	(x==Language::AR)		? "AR" :\
	(x==Language::HY)		? "HY" :\
	(x==Language::AS)		? "AS" :\
	(x==Language::AY)		? "AY" :\
	(x==Language::AZ)		? "AZ" :\
	(x==Language::BA)		? "BA" :\
	(x==Language::EU)		? "EU" :\
	(x==Language::BN)		? "BN" :\
	(x==Language::DZ)		? "DZ" :\
	(x==Language::BH)		? "BH" :\
	(x==Language::BI)		? "BI" :\
	(x==Language::BR)		? "BR" :\
	(x==Language::BG)		? "BG" :\
	(x==Language::MY)		? "MY" :\
	(x==Language::BE)		? "BE" :\
	(x==Language::KM)		? "KM" :\
	(x==Language::CA)		? "CA" :\
	(x==Language::ZH)		? "ZH" :\
	(x==Language::CO)		? "CO" :\
	(x==Language::HR)		? "HR" :\
	(x==Language::CS)		? "CS" :\
	(x==Language::DA)		? "DA" :\
	(x==Language::NL)		? "NL" :\
	(x==Language::EN)		? "EN" :\
	(x==Language::EO)		? "EO" :\
	(x==Language::ET)		? "ET" :\
	(x==Language::FO)		? "FO" :\
	(x==Language::FJ)		? "FJ" :\
	(x==Language::FI)		? "FI" :\
	(x==Language::FR)		? "FR" :\
	(x==Language::FY)		? "FY" :\
	(x==Language::GD)		? "GD" :\
	(x==Language::GL)		? "GL" :\
	(x==Language::KA)		? "KA" :\
	(x==Language::DE)		? "DE" :\
	(x==Language::EL)		? "EL" :\
	(x==Language::KL)		? "KL" :\
	(x==Language::GN)		? "GN" :\
	(x==Language::GU)		? "GU" :\
	(x==Language::HA)		? "HA" :\
	(x==Language::IW)		? "IW" :\
	(x==Language::HI)		? "HI" :\
	(x==Language::HU)		? "HU" :\
	(x==Language::IS)		? "IS" :\
	(x==Language::IN)		? "IN" :\
	(x==Language::IA)		? "IA" :\
	(x==Language::IE)		? "IE" :\
	(x==Language::IK)		? "IK" :\
	(x==Language::GA)		? "GA" :\
	(x==Language::IT)		? "IT" :\
	(x==Language::JA)		? "JA" :\
	(x==Language::JW)		? "JW" :\
	(x==Language::KN)		? "KN" :\
	(x==Language::KS)		? "KS" :\
	(x==Language::KK)		? "KK" :\
	(x==Language::RW)		? "RW" :\
	(x==Language::KY)		? "KY" :\
	(x==Language::RN)		? "RN" :\
	(x==Language::KO)		? "KO" :\
	(x==Language::KU)		? "KU" :\
	(x==Language::LO)		? "LO" :\
	(x==Language::LA)		? "LA" :\
	(x==Language::LV)		? "LV" :\
	(x==Language::LN)		? "LN" :\
	(x==Language::LT)		? "LT" :\
	(x==Language::MK)		? "MK" :\
	(x==Language::MG)		? "MG" :\
	(x==Language::MS)		? "MS" :\
	(x==Language::ML)		? "ML" :\
	(x==Language::MT)		? "MT" :\
	(x==Language::MI)		? "MI" :\
	(x==Language::MR)		? "MR" :\
	(x==Language::MO)		? "MO" :\
	(x==Language::MN)		? "MN" :\
	(x==Language::NA)		? "NA" :\
	(x==Language::NE)		? "NE" :\
	(x==Language::NO)		? "NO" :\
	(x==Language::OC)		? "OC" :\
	(x==Language::OR)		? "OR" :\
	(x==Language::OM)		? "OM" :\
	(x==Language::PS)		? "PS" :\
	(x==Language::FA)		? "FA" :\
	(x==Language::PL)		? "PL" :\
	(x==Language::PT)		? "PT" :\
	(x==Language::PA)		? "PA" :\
	(x==Language::QU)		? "QU" :\
	(x==Language::RM)		? "RM" :\
	(x==Language::RO)		? "RO" :\
	(x==Language::RU)		? "RU" :\
	(x==Language::SM)		? "SM" :\
	(x==Language::SG)		? "SG" :\
	(x==Language::SA)		? "SA" :\
	(x==Language::SC)		? "SC" :\
	(x==Language::SR)		? "SR" :\
	(x==Language::SH)		? "SH" :\
	(x==Language::ST)		? "ST" :\
	(x==Language::TN)		? "TN" :\
	(x==Language::SN)		? "SN" :\
	(x==Language::SD)		? "SD" :\
	(x==Language::SI)		? "SI" :\
	(x==Language::SS)		? "SS" :\
	(x==Language::SK)		? "SK" :\
	(x==Language::SL)		? "SL" :\
	(x==Language::SO)		? "SO" :\
	(x==Language::ES)		? "ES" :\
	(x==Language::SU)		? "SU" :\
	(x==Language::SW)		? "SW" :\
	(x==Language::SV)		? "SV" :\
	(x==Language::TL)		? "TL" :\
	(x==Language::TG)		? "TG" :\
	(x==Language::TA)		? "TA" :\
	(x==Language::TT)		? "TT" :\
	(x==Language::TE)		? "TE" :\
	(x==Language::TH)		? "TH" :\
	(x==Language::BO)		? "BO" :\
	(x==Language::TI)		? "TI" :\
	(x==Language::TO)		? "TO" :\
	(x==Language::TS)		? "TS" :\
	(x==Language::TR)		? "TR" :\
	(x==Language::TK)		? "TK" :\
	(x==Language::TW)		? "TW" :\
	(x==Language::UK)		? "UK" :\
	(x==Language::UR)		? "UR" :\
	(x==Language::UZ)		? "UZ" :\
	(x==Language::VI)		? "VI" :\
	(x==Language::VO)		? "VO" :\
	(x==Language::CY)		? "CY" :\
	(x==Language::WO)		? "WO" :\
	(x==Language::XH)		? "XH" :\
	(x==Language::JI)		? "JI" :\
	(x==Language::YO)		? "YO" :\
	(x==Language::ZU)		? "ZU" : "(undefined)" )

#define SUPPORTED_STEM_LANGUAGES 15

//Stemming Types // Warning must be same number of language_t
enum class Stemming : unsigned char {
	UNKNOWN		= 0,
	DA			= 1, // Danish
	NL			= 2, // Dutch
	EN			= 3, // English
	FI			= 4, // Finnish
	FR			= 5, // French
	DE			= 6, // German
	HU			= 7, // Hungarian
	IT			= 8, // Italian
	NO			= 9, // Norwegian
	PT			= 10, // Portuguese
	RO			= 11, // Romanian
	RU			= 12, // Russian
	ES			= 13, // Spanish
	SV			= 14, // Swedish
	TR			= 15 // Turkish
};

#define STEMMING_STR(x) (\
	(x==Stemming::DA)		? "DA" :\
	(x==Stemming::NL)		? "NL" :\
	(x==Stemming::EN)		? "EN" :\
	(x==Stemming::FI)		? "FI" :\
	(x==Stemming::FR)		? "FR" :\
	(x==Stemming::DE)		? "DE" :\
	(x==Stemming::HU)		? "HU" :\
	(x==Stemming::IT)		? "IT" :\
	(x==Stemming::NO)		? "NO" :\
	(x==Stemming::PT)		? "PT" :\
	(x==Stemming::RO)		? "RO" :\
	(x==Stemming::RU)		? "RU" :\
	(x==Stemming::ES)		? "ES" :\
	(x==Stemming::SV)		? "SV" :\
	(x==Stemming::TR)		? "TR" : "(undefined)" )

#define LANGUAGE_TO_STEMMING(x) (\
	(x==Language::DA)			? Stemming::DA :\
	(x==Language::NL)			? Stemming::NL :\
	(x==Language::EN)			? Stemming::EN :\
	(x==Language::FI)			? Stemming::FI :\
	(x==Language::FR)			? Stemming::FR :\
	(x==Language::DE)			? Stemming::DE :\
	(x==Language::HU)			? Stemming::HU :\
	(x==Language::IT)			? Stemming::IT :\
	(x==Language::NO)			? Stemming::NO :\
	(x==Language::PT)			? Stemming::PT :\
	(x==Language::RO)			? Stemming::RO :\
	(x==Language::RU)			? Stemming::RU :\
	(x==Language::ES)			? Stemming::ES :\
	(x==Language::SV)			? Stemming::SV :\
	(x==Language::TR)			? Stemming::TR : Stemming::UNKNOWN )

#define STEMMING_TO_LANGUAGE(x) (\
	(x==Stemming::DA)			? Language::DA :\
	(x==Stemming::NL)			? Language::NL :\
	(x==Stemming::EN)			? Language::EN :\
	(x==Stemming::FI)			? Language::FI :\
	(x==Stemming::FR)			? Language::FR :\
	(x==Stemming::DE)			? Language::DE :\
	(x==Stemming::HU)			? Language::HU :\
	(x==Stemming::IT)			? Language::IT :\
	(x==Stemming::NO)			? Language::NO :\
	(x==Stemming::PT)			? Language::PT :\
	(x==Stemming::RO)			? Language::RO :\
	(x==Stemming::RU)			? Language::RU :\
	(x==Stemming::ES)			? Language::ES :\
	(x==Stemming::SV)			? Language::SV :\
	(x==Stemming::TR)			? Language::TR : Language::UNKNOWN )

//Stemming Types // Warning must 
/*
const int increment_stem[] = { static_cast<const int>(PureStemming::DA), static_cast<const int>(PureStemming::NL), static_cast<const int>(PureStemming::EN), static_cast<const int>(PureStemming::FI), static_cast<const int>(PureStemming::FR), static_cast<const int>(PureStemming::DE), static_cast<const int>(PureStemming::HU), static_cast<const int>(PureStemming::IT), static_cast<const int>(PureStemming::NO), static_cast<const int>(PureStemming::PT), static_cast<const int>(PureStemming::RO), static_cast<const int>(PureStemming::RU), static_cast<const int>(PureStemming::ES), static_cast<const int>(PureStemming::SV), static_cast<const int>(PureStemming::TR) };
*/

charset_t http_charset(char *charset_str);
Language http_language(char *language_str);
off64_t http_charset_convert(charset_t charset_from, charset_t charset_to, char *src, char *dst, off64_t dstmaxsize);

class cbotUniversalDetector : public nsUniversalDetector 
{
    public: 
        cbotUniversalDetector();
        ~cbotUniversalDetector();
        void Report(const char * aCharset);
        charset_t GetCharset(const char * aBuf, PRUint32 aLen);
    protected:
        charset_t detectedCharset;
        int ready;
};
#endif
