/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _MONITOR_H_INCLUDED_
#define _MONITOR_H_INCLUDED_

#include <config.h>

// System libraries

#include <features.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <iostream>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/stat.h>


#include <math.h>
#include <errno.h>
#include <queue>
#include <string>
#include <map>

using namespace std;

// Local libraries

#include "const.h"
#include "http_codes.h"
#include "xmlconf.h"
#include "die.h"
#include "utils.h"
#include "Meta.h"
#include "Url.h"
#include "http_charset.h"

// File names

#define MONITOR_FILENAME_MASTER			"monitor_master.bin"
#define MONITOR_FILENAME_REMOTE			"monitor_remote.bin"

// Monitor index status

enum monitor_status_t {
	MONITOR_OK         = 0,
	MONITOR_KO, // used only for commands checking
	MONITOR_ERROR,
	MONITOR_EOF
};

// prepare postponed command bitmask at 64 bits
enum monitor_comask_t : uint64_t {
        MON_COM_FALSE			= 0, // can be use as "virtual negative value", or to set to 0 full command mask
        MON_COM_FIX_DEPTHS		= 1,
        MON_COM_MARK_DYNAMIC	= 2,
        MON_COM_MARK_IGNORED	= 4,
        MON_FIX_UNUSED			= 8
};

enum monitor_call_t {
    MONITOR_OPEN      = 0,
    MONITOR_CLOSE     = 1,
    MONITOR_REMOVE    = 2
};

class Monitor
{
	// Types for a monitor
	typedef struct {
		// Monitor parameters
		instance_t instance;
		uint64_t commands;
	
		unsigned char reserved[256];
	
	} monmaster_old_t;
	
	typedef struct {
		// Monitor parameters
		instance_t		instance;
		uint64_t commands;
	
		unsigned char reserved[256];
	
	} monmaster_t;
	
	typedef struct {
		// Monitor parameters
		instance_t instance;
	
		unsigned char reserved[256];
	
	} monremote_old_t;
	
	typedef struct {
		// Monitor parameters
		instance_t		instance;
		site_options_t	options;
		off64_t			meta_old_sizeof_sites;
		off64_t			meta_sizeof_sites;
		off64_t			meta_old_sizeof_optmask_sites;
		off64_t			meta_sizeof_optmask_sites;
		off64_t			meta_old_sizeof_docs;
		off64_t			meta_sizeof_docs;
	
		unsigned char reserved[256];
	
	} monremote_t;

	typedef struct {
		int file_monitor_master; // fd
		char dirname[MAX_STR_LEN];
		// bool readonly;
	} mon_master_t;

	typedef struct {
		int file_monitor_remote; // fd
		char dirname[MAX_STR_LEN];
		monremote_t *m_cache;
		monremote_t *m_cache2;
		// bool readonly;
	} mon_t;

	typedef struct {
		mon_t *distributed;
		bool readonly;
	} monitor_t;

	// need to passing arguments to threads functions
	typedef struct {
		instance_t inst;
		Monitor *obj;
		monitor_call_t f; // per determinate lettere corrisponde la chiamata a determinate funzioni fatta da pthread_create
	} thread_args_t;

	// monitor structure
	monitor_t *m;
	mon_master_t *mm;
	monmaster_t *mm_cache;
	monmaster_t *mm_cache2;
	bool readonly;

	// Function required by monitor_open (pthread use)
	void *thread_function_open(void *args);

	// Function required by monitor_close (pthread use)
	void *thread_function_close( void * );

	// Function required by monitor_remove (pthread use)
	void *thread_function_remove( void * );

	// Function to proxy to non-static function
	static void* thread_function_caller( void * );
/*
	// Retreive doc_t (the passage of the structure monitor_t is required to skip the default work on special object 'this')
	monitor_status_t doc_retrieve( monitoridx_t *, doc_t * );
*/
	// Convert old monitor master struct to new
    void convert_old_monmaster_file( char *, bool );

	// Convert old monitor remote struct to new
    void convert_old_monremote_file( char *, bool );

	public:

	Monitor (bool _Y) // ctor
		: m (NULL)
		, mm (NULL)
		, mm_cache (NULL)
		, readonly (_Y)
	{
	}

	~Monitor () // dtor
	{
	}

	// Open monitor
	//void mon_open( const char *, bool );
	void open( void );

	// Close monitor
	monitor_status_t close( void );

	// Remove monitor
	void remove( void );

	// Store monitor_comask_t
	monitor_status_t command_set(monitor_comask_t, bool );

	// Read monitor_comask_t
	monitor_status_t command_get(monitor_comask_t, bool );

/*
	// Blank doc records
	void doc_default( doc_t * );

	// Retreive status_t
	monitor_status_t status_retrieve( doc_t * );

	// Store doc_t
	monitor_status_t doc_store( doc_t * );

	// Dump doc short status
	void dump_doc_short_status( doc_t * );

	// Dump status
	void dump_status( void );

	// Dump doc header
	void dump_doc_header( FILE * );

	// Dump doc
	void dump_doc( doc_t *, FILE * );

	// Convert old doc struct to new
	void convert_old_doc_file( char *, bool );
*/
};

#endif
