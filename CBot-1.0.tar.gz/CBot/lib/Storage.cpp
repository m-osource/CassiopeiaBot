/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "Storage.h"

//
// Name: thread_function_caller
//
// Description:
//   A proxy function to pass non-static function at pthread_create
//   Note: function called by thread_function_caller need to have real class object passed through args
//
// Input:
//   args - void arguments
//
// Return:
//   pointer to void
//

void *Storage::thread_function_caller(void *args)
{
	assert(args);
try
{
	Storage::thread_args_t *arguments = (Storage::thread_args_t *)args;

	Storage *newObj = NULL;

	try
	{
		newObj = new Storage (NULL, true); // Note function called work to 'this' temporary object and need to be deleted at the end of the same.
	}
	catch (std::bad_alloc& ba)
	{
		die("thread_function_caller bad_alloc caught: %s", ba.what());
	}

	switch (arguments->f)
	{
		case STORAGE_CREATE:
			newObj->thread_function_create(args);
			break;
		case STORAGE_OPEN:
			newObj->thread_function_open(args);
			break;
		case STORAGE_CLOSE:
			newObj->thread_function_close(args);
			break;
		case STORAGE_REMOVE:
			newObj->thread_function_remove(args);
			break;
		default:
			break;
	}

	delete newObj;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL); 
}

	free(args);
	args = NULL;

	return NULL;
}
                                            
//
// Name: setmutex
//
// Description: Allocate memory and create mutex
//
// Input:
//
// Return:
//
void Storage::setmutex(strgmutex_t **lock)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		if (readonly == false)
		{
			*lock = CBALLOC(strgmutex_t, MALLOC, 1);
			(*lock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->rwlocka = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->rwlockb = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->rwlockc = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));

			for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			{
				(*lock)->locka[i] = PTHREAD_MUTEX_INITIALIZER;
				(*lock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
				(*lock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER;
				(*lock)->rwlocka[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*lock)->rwlockb[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*lock)->rwlockc[i] = PTHREAD_RWLOCK_INITIALIZER;
			}

			this->lock = *lock;
		}
		else
		{
			*lock = CBALLOC(strgmutex_t, MALLOC, 1);
			(*lock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*lock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));

			for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			{
				(*lock)->locka[i] = PTHREAD_MUTEX_INITIALIZER;
				(*lock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
				(*lock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER;
			}

			this->lock = *lock;
		}
	}
}
                                            
//
// Name: destroymutex
//
// Description: Free memory and destroy mutex
//
// Input:
//
// Return:
//
void Storage::destroymutex(void)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		if (readonly == false)
		{
			// now, we ensure that all mutex are unused and destroyed
			int rc = 0;
	
			for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			{
				if ((rc = pthread_mutex_destroy(&(lock->locka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(lock->lockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(lock->lockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));

				if ((rc = pthread_rwlock_destroy(&(lock->rwlocka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_rwlock_destroy(&(lock->rwlockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_rwlock_destroy(&(lock->rwlockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
			}
	
			free(lock->locka); lock->locka = NULL;
			free(lock->lockb); lock->lockb = NULL;
			free(lock->lockc); lock->lockc = NULL;
			free(lock->rwlocka); lock->rwlocka = NULL;
			free(lock->rwlockb); lock->rwlockb = NULL;
			free(lock->rwlockc); lock->rwlockc = NULL;
			free(lock);
		}
		else
		{
			// now, we ensure that all mutex are unused and destroyed
			int rc = 0;
	
			for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			{
				if ((rc = pthread_mutex_destroy(&(lock->locka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(lock->lockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(lock->lockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
			}
	
			free(lock->locka); lock->locka = NULL;
			free(lock->lockb); lock->lockb = NULL;
			free(lock->lockc); lock->lockc = NULL;
			free(lock);
		}
	}
}

//
// Name: prepare_sequential_read
//
// Description:
//   Prepares the storage file for sequential reading
//   THIS WORKS only if there are no deletions
//
// Input:
//   st - the storage object
//

storage_status_t Storage::prepare_sequential_read(instance_t &inst)
{
	errno = 0; // errno is thread-local

	// Look for the associated storage record
	if (lseek64(distributed[inst].index_file, (off64_t)(1 * sizeof(storage_record_t)), SEEK_SET) < (off64_t)0)
		die ("Storage prepare_sequential_read: couldn't seek to the beginning of index_file %s\n", cberr());

	// Go to the content file address for that document
	if (lseek64(distributed[inst].content_file, (off64_t)0, SEEK_SET) != (off64_t)0)
		die ("Storage prepare_sequential_read: couldn't seek to the beginning of content_file %s\n", cberr());

	return STORAGE_OK;
}

//
// Name: read_document
// 
// Description:
//   Reads a document from a filesystem
//
// Input:
//   docid - document id to retrieve
//
// Output:
//   buf - the readed object
//   len - the length
//
// Return:
//   status
// 

storage_status_t Storage::read_document(doc_t *doc, char *buf)
{
	assert(doc->docid > 0);

	// Ensure a consistent buffer on output
	buf[0] = '\0';

	// Check if the storage file is large enough
	if (doc->docid > max_docid) {
		return STORAGE_NOT_FOUND;
	}

	string content_path = (find_path(doc->docid));

	FILE *content_file = fopen(content_path.c_str(), "rb");

	if (content_file == NULL)
		return STORAGE_NOT_FOUND;
	else
	{
			if (doc->content_length == 0)
			{
				fclose(content_file);

				// Delete file
				int rc = unlink(content_path.c_str()); // TODO see comment on header file on 'delete_document'

				if (rc != 0 && errno != ENOENT) die("Storage read_document: couldn't unlink file %s on %s\n", cberr(), content_path.c_str());

				return STORAGE_NOT_FOUND;
			}

			errno = 0; // errno is thread-local

			// Compare doc->content_lengths
			if (fread (buf,1,MAX_DOC_LEN,content_file) == (size_t)doc->content_length)
				buf[doc->content_length] = '\0'; // Append a '\0' at the end of the readed content
			else
				die("Storage read_document: couldn't read to content file %s on %s\n", cberr(), content_path.c_str());
	}

	fclose(content_file);
	
	return STORAGE_OK;
}

//
// Name: st_idx_read
// 
// Description:
//   Reads a document from a storage
//
// Input:
//   instance - instance where write content
//   docid - document id to read
//   buf - content of the document
//   size - number of bytes to write
//
// Output:
//   buf - the readed object
//   len - the length
//
// Return:
//   status
// 

storage_status_t Storage::st_idx_read(instance_t &inst, docid_t docid, char *buf, off64_t &len)
{
	assert(inst < CONF_COLLECTION_DISTRIBUTED);
	assert(docid > 0);

	storage_record_t rec;

	errno = 0; // errno is thread-local

	// Ensure a consistent buffer on output
	buf[0] = '\0';

	// Check if the storage file is large enough
	if (docid >= distributed[inst].max_docid) return STORAGE_NOT_FOUND;

	// Look for the associated storage record
	if (lseek64(distributed[inst].index_file, (off64_t)(docid * sizeof(storage_record_t)), SEEK_SET) < (off64_t)0)
		die("Storage st_idx_read: couldn't seek on index %s\n", cberr());

	// Read the storage record
	if (read(distributed[inst].index_file, &(rec), sizeof(storage_record_t)) != sizeof(storage_record_t))
		die("Storage st_idx_read: couldn't read from index %s when reading id\n", cberr());

	// Check record size if empty
	if (rec.size == -1) return STORAGE_NOT_FOUND;

	assert((rec.size + 1) <= MAX_DOC_LEN);

	// Go to the content file address for that document
	if (lseek64(distributed[inst].content_file, rec.offset, SEEK_SET) != rec.offset)
		die("Storage st_idx_read: couldn't seek in content file %s\n", cberr());

	// Read the content into the buffer
	if (read(distributed[inst].content_file, buf, rec.size) != rec.size)
		die("Storage st_idx_read: failed to read content file %s\n", cberr());

	// Copy the size
	len = rec.size;

	// Append a '\0' at the end of the readed content
	buf[rec.size] = '\0';
	
	return STORAGE_OK;
}

//
// Name: st_idx_write
//
// Description:
//   Writes a document to storage
//
// Input:
//   instance - instance where write content
//   docid - document id to write
//   buf - content of the document
//   size - number of bytes to write
//
// Return:
//   status

storage_status_t Storage::st_idx_write(instance_t &inst, docid_t docid, char *buf, off64_t size)
{
	assert(docid > 0);

	// Check if it's necessary to grow the index
	if (docid >= distributed[inst].max_docid) grow(inst, docid);

	// Look for an free place in the free list
	// First-fit
	storage_free_list_t *current = distributed[inst].free_list;

	assert(current != NULL);

	while (current->rec.size < size)
	{
		current = current->next;

		if (current == NULL)
		{
			die("Storage st_idx_write: On instance %lu couldn't find a free place in the file\n", (unsigned long int)inst);

			return STORAGE_ERROR;
		}
	}

	// Seek in disk that place in the content file
	if (lseek64(distributed[inst].content_file, current->rec.offset, SEEK_SET) != current->rec.offset)
	{
		die("Storage st_idx_write: On instance %lu couldn't seek in content file %s", (unsigned long int)inst, cberr());

		return STORAGE_ERROR;
	}

	// Write to disk
	if (write(distributed[inst].content_file, buf, size) != size)
	{
		if (errno == EFBIG)
			die("Storage st_idx_write: On instance %lu File too big! Either the filesystem or the operating system don't support large files: try 1) moving to another filesystem 2) upgrading kernel", (unsigned long int)inst);
		else
			die("Storage st_idx_write: On instance %lu couldn't write in content file %s", (unsigned long int)inst, cberr());

		return STORAGE_ERROR;
	}

	// Update the index file

	storage_record_t rec;
	rec.offset = current->rec.offset;
	rec.size   = size;

	write_index_record(inst, docid, &(rec));

	// Update the free list
	assert(current->rec.size >= size);
	if (current->rec.size == size)
	{	// Delete the free block size

		// Check if start of list
		if (current == distributed[inst].free_list)
		{

			// Delete first element of list
			distributed[inst].free_list = distributed[inst].free_list->next;
			free(current);

		}
		else
		{
			// Delete another element of list
			storage_free_list_t *ptr = distributed[inst].free_list;

			while (ptr->next != current) ptr = ptr->next;

			ptr->next = ptr->next->next;
			free(current);
		}

	}
	else
	{	// Update the free block size
		current->rec.size -= size;
		current->rec.offset += size;
	}

	return STORAGE_OK;
}

//
// Name: st_idx_delete
//
// Description:
//   Deletes an object from the storage
//
// Input:
//   inst - the instance where storage is found
//   docid - the document id to delete
//
// Return:
//   status
//
storage_status_t Storage::st_idx_delete(instance_t &inst, docid_t docid)
{
	if (exists(inst, docid) != STORAGE_OK) return STORAGE_NOT_FOUND;

	// Load the current index record
	storage_record_t rec;
	read_index_record(inst, docid, &(rec));
	assert(rec.size != -1);

	// Create a new free record for that file
	storage_free_list_t *newfree =  CBALLOC(storage_free_list_t, MALLOC, 1);
	newfree->rec.offset	= rec.offset;
	newfree->rec.size	= rec.size;

	// Search for the place for this new free record

	storage_free_list_t *current	= distributed[inst].free_list;
	assert(current != NULL);

	if (current->rec.offset >= newfree->rec.offset)
	{
		// Must insert in the beginning
		distributed[inst].free_list	 = newfree;
		newfree->next	 = current;

		// Merge if necessary (new + next)
		if ((newfree->rec.offset + newfree->rec.size) == current->rec.offset)
		{
			newfree->rec.size += current->rec.size;
			newfree->next	= current->next;
			free(current);
		}
	}
	else
	{
		// Must insert somewhere else
		while (current->next != NULL)
		{
			if (current->next->rec.offset >= newfree->rec.offset)
				break;
			else
				current = current->next;
		}

		if (current->next == NULL)
		{
			die("Inserting at the end of the free list ? Free list is corrupted");

			return STORAGE_ERROR;
		}

		newfree->next	= current->next;
		current->next	= newfree;

		// Merge if necessary (new + previous)
		if ((current->rec.offset + current->rec.size) == newfree->rec.offset) {
			current->rec.size += newfree->rec.size;
			current->next	= newfree->next;
			free(newfree);
			newfree = current; // so you can test and merge forward
		}

		// Merge if necessary (new + next)
		if (newfree->next != NULL) {
			storage_free_list_t *next = newfree->next;

			if ((newfree->rec.offset + newfree->rec.size) == next->rec.offset) {
				newfree->rec.size += next->rec.size;
				newfree->next	   = next->next;
				free(next);
			}

		}
	}

	// Mark in the index as deleted.
	rec.size = -1;
	write_index_record(inst, docid, &(rec));
	
	return STORAGE_OK;
}

//
// Name: linear_probe_resolve
//
// Description:
//   Exec a linear probing on same instance's storage to find if document have a duplicate
//   Hash file not locked because once lock duplicate instance, relative hashs cannot interference with other hash from other instances.
//
// Input:
//   doc - document where docid is found
//   buf - content of the document
//
// Output:
//
// Return:
//   status

linear_probe_status_t Storage::linear_probe_resolve(doc_t *doc, char *buf, doc_hash_t &hash)
{
	assert (doc->docid > 0);
#ifdef STORAGE_HASH_TEST
	assert(buf == NULL);
#else
	assert(buf != NULL);
#endif

//#ifdef STORAGE_HASH_TEST
	assert(hash < CONF_HASH_DOC_MAX_DEFINITIVE);
//#endif

	// Find hash instance (must unchange inside of function)
	instance_t hinst = (hash % CONF_COLLECTION_DISTRIBUTED);

#ifndef STORAGE_HASH_TEST
	doc_hash_t pos = ((hash % (STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED)) / CONF_COLLECTION_DISTRIBUTED);
#else
	doc_hash_t pos = ((hash % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED)) / CONF_COLLECTION_DISTRIBUTED);
#endif

	// lock duplicates
	lock_a_dupl(hinst);

	docid_t duplicate_docid = 0;

	duplicate_docid = distributed[hinst].duplicates[pos];

#ifdef STORAGE_HASH_TEST
	if (duplicate_docid != (docid_t)0 && duplicate_docid == doc->docid)
	{
			// unlock duplicates
			unlock_a_dupl(hinst);

			return PROBE_EXISTENT;
	}
#endif

	// read only lock hashs without instance because during function doc_hash can be readed on different instances
//	rdlock_hashs();

	// Linear Probing
	while (duplicate_docid != (docid_t)0 && duplicate_docid != doc->docid)
	{
#ifndef STORAGE_HASH_TEST
		if (distributed[((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED)].doc_hash[((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED)] == hash)
		{
			// Check if it's duplicate by content
			bool is_duplicate = true;

			errno = 0; // errno is thread-local

			// Read potential duplicate
			string content_path = find_path(duplicate_docid);

			FILE *duplicate_file = fopen(content_path.c_str(), "rb");

			if (duplicate_file == NULL)
			{
				mcerr << RED << "Storage test_linear_probe_resolve: failed to read document " << duplicate_docid << " while checking duplicates of " << doc->docid << NOR << mendl;
				is_duplicate = false;
				break;
			}
			else
			{
				// Ask for memory to load temporary files and compare
				char *tmpbuf = CBALLOC(char, MALLOC, MAX_DOC_LEN);

				// Compare doc->content_lengths and after this compare content byte to byte
				size_t readed = fread(tmpbuf, 1, MAX_DOC_LEN, duplicate_file);

				if (errno != 0)
				{
					mcerr << RED << "Storage test_linear_probe_resolve: couldn't read content file "<< cberr() << " on "  << content_path.c_str() << NOR << mendl;
					is_duplicate = false;
				}

				if (readed == (size_t)doc->content_length)
				{
					if (memcmp(tmpbuf, buf, doc->content_length) != 0)
						is_duplicate = false;
				}
				else
					is_duplicate = false;

				int rc = fclose(duplicate_file);

				if (errno != 0)
				{
					mcerr << "Storage test_linear_probe_resolve: couldn't close file "<< cberr() << " on "  << content_path.c_str() << mendl;
					is_duplicate = false;
				}

				assert(rc == 0);
				free(tmpbuf);

				if (is_duplicate)
				{
					// document must be saved as duplicate_of ...
					doc->duplicate_of = duplicate_docid;

					// unlock ro mutex for hash
					// unlock_hashs();

					// unlock duplicates
					unlock_a_dupl(hinst);

					return PROBE_EXISTENT;
				}
			}

			// unlock ro mutex for hash
			// unlock_hashs();

			// unlock duplicates
			unlock_a_dupl(hinst);

			return PROBE_EXISTENT;
		}
#else 
		if (distributed[((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED)].doc_hash[((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED)] == hash)
		{
			// unlock ro mutex for hash
			// unlock_hashs();

			// unlock duplicates
			unlock_a_dupl(hinst);

			return PROBE_EXISTENT;
		}
#endif

		// Go ahead until condition
#ifdef STORAGE_HASH_TEST
		pos = ((pos + 1) % TEST_STORAGE_HASH_MAX);
#else
		pos = ((pos + 1) % STORAGE_HASH_MAX);
#endif

		duplicate_docid = distributed[hinst].duplicates[pos];
	}

#ifdef STORAGE_HASH_TEST
	if (duplicate_docid != (docid_t)0 && duplicate_docid == doc->docid)
	{
		// unlock ro mutex for hash
		// unlock_hashs();

		// unlock duplicates
		unlock_a_dupl(hinst);

		return PROBE_EXISTENT;
	}
#endif

	// unlock ro mutex for hash
	// unlock_hashs();

	distributed[hinst].duplicates[pos] = doc->docid;
	distributed[hinst].count_hash++;

	// Find instance and offset of docid
	instance_t doc_inst = ((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t doc_offset = ((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED);

	// write lock hashs
//	wrlock_hashs();

	// Save hash value (ready for query
	distributed[doc_inst].doc_hash[doc_offset] = hash;

	// unlock hashs
//	unlock_hashs();

	// unlock duplicates
	unlock_a_dupl(hinst);

	return PROBE_CREATED;
}

//
// Name: linear_probe_delete
//
// Description:
//   Exec a linear probing on same instance's storage for shift offset at left and fill
//   empty position
//   Hash file not locked because once lock duplicate instance, relative hashs cannot interference with other hash from other instances.
//
// Input:
//   doc - document where docid is found
//
// Output:
//
// Return:
//   status

linear_probe_status_t Storage::linear_probe_delete(doc_t *doc)
{
	assert (doc->docid > 0);

	// Find instance and offset of docid
	instance_t doc_inst = ((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t doc_offset = ((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED);

	// Find real hash
	doc_hash_t hash = distributed[doc_inst].doc_hash[doc_offset];

	// Return because document not found inside storage
	if (hash == CONF_HASH_DOC_MAX_DEFINITIVE) return PROBE_NOT_FOUND;

	// Find hash instance (must unchange inside of function)
	instance_t hinst = (hash % CONF_COLLECTION_DISTRIBUTED);

#ifndef STORAGE_HASH_TEST
	hash %= (STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED);
#else
	hash %= (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED);
#endif

	// Find hash position
	doc_hash_t chain_start = (hash / CONF_COLLECTION_DISTRIBUTED);

#ifdef STORAGE_HASH_TEST
	instance_t remove_instance = hinst;
	doc_hash_t remove_offset = chain_start;
#endif

	bool probe_ok = false;

	// lock duplicates
	lock_a_dupl(hinst);

	assert(distributed[hinst].duplicates[chain_start] > 0); // TODO solo uso debug

	// Return error because document must be inside storage
	if (distributed[hinst].duplicates[chain_start] == 0)
	{
		// unlock duplicates
		unlock_a_dupl(hinst);

		return PROBE_ERROR;
	}

	//find position where docid is found with Linear Probe and set chain_start
	while (distributed[hinst].duplicates[chain_start] > 0)
	{
		if (distributed[hinst].duplicates[chain_start] == doc->docid)
		{
			probe_ok = true;
			break;
		}

		// Linear Probing
#ifdef STORAGE_HASH_TEST
		chain_start = ((chain_start + 1) % TEST_STORAGE_HASH_MAX);
#else
		chain_start = ((chain_start + 1) % STORAGE_HASH_MAX);
#endif
	}

	if (probe_ok == false)
	{
		// unlock duplicates
		unlock_a_dupl(hinst);

#ifdef STORAGE_HASH_TEST
		mcout << NOR << "buckets err  ";

		for (instance_t hinst = 0; hinst < CONF_COLLECTION_DISTRIBUTED; hinst++)
		{
			for (doc_hash_t pos = 0; pos < TEST_STORAGE_HASH_MAX; pos++)
			{
				doc_hash_t hash = 0;

				docid_t	duplicate_docid = distributed[hinst].duplicates[pos];

				if (duplicate_docid == 0) cout << GRE;

				if (duplicate_docid > 0)
				{
					// Find instance
					instance_t doc_inst = ((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED);
					docid_t doc_offset = ((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED);

#ifndef STORAGE_HASH_TEST
					hash = (distributed[doc_inst].doc_hash[doc_offset] % (STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));
#else
					hash = (distributed[doc_inst].doc_hash[doc_offset] % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));
#endif

					if (hash < 10) cout << ' ' << hash << ' ';
					else cout << hash << ' ';
				}
				else cout << ' ' << hash << ' ';

				if (duplicate_docid == 0)
				{
					cout << NOR;

					continue;
				}
			}
		}

		cout << NOR << mendl;
#endif
		return PROBE_ERROR;
	}

	// now chain_start indicates where docid is found
	doc_hash_t chain_end = chain_start; // become relative end of chain
	doc_hash_t empty_offset = chain_start; // where offset become empty
	doc_hash_t hash_offset = chain_start; 

	while (distributed[hinst].duplicates[chain_end] > 0)
	{
#ifdef STORAGE_HASH_TEST
		chain_end = ((chain_end + 1) % TEST_STORAGE_HASH_MAX);
#else
		chain_end = ((chain_end + 1) % STORAGE_HASH_MAX);
#endif
	}

	// read only lock hashs without instance because during function doc_hash can be readed on different instances
	// rdlock_hashs();

	// Linear UnProbe algo by MS
	// Shift offset to left
	while (distributed[hinst].duplicates[hash_offset] > 0)
	{
		// Get next_docid only to find the value of the hash
		docid_t next_docid = distributed[hinst].duplicates[hash_offset];

		doc_hash_t hash_value = distributed[((next_docid - 1) % CONF_COLLECTION_DISTRIBUTED)].doc_hash[((next_docid - 1) / CONF_COLLECTION_DISTRIBUTED)];

#ifndef STORAGE_HASH_TEST
		hash_value %= (STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED);
#else
		hash_value %= (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED);
#endif

		doc_hash_t hash_value_offset = (hash_value / CONF_COLLECTION_DISTRIBUTED);

		if (hash_value_offset < hash_offset)
		{
			if (hash_value_offset <= empty_offset && hash_offset > empty_offset)
			{	// shift hash_value
				distributed[hinst].duplicates[empty_offset] = distributed[hinst].duplicates[hash_offset];
				empty_offset = hash_offset;
			}
		}
		else if (hash_value_offset > hash_offset)
		{
			if ((empty_offset >= 0 && empty_offset < chain_end && hash_value_offset > chain_end) || hash_value_offset <= empty_offset)
			{	// shift hash_value
				distributed[hinst].duplicates[empty_offset] = distributed[hinst].duplicates[hash_offset];
				empty_offset = hash_offset;
			}
		}

		// goto next position on same instance
#ifdef STORAGE_HASH_TEST
		hash_offset = ((hash_offset + 1) % TEST_STORAGE_HASH_MAX);
#else
		hash_offset = ((hash_offset + 1) % STORAGE_HASH_MAX);
#endif
	}

	// Linear UnProbe

	// unlock ro mutex for hash
	// unlock_hashs();

	// Empty end of chain
	if (empty_offset != chain_start)
	{
		distributed[doc_inst].doc_hash[doc_offset] = CONF_HASH_DOC_MAX_DEFINITIVE;

		distributed[hinst].duplicates[empty_offset] = 0;

		distributed[hinst].count_hash--;

		// unlock duplicates
		unlock_a_dupl(hinst);

#ifdef STORAGE_HASH_TEST
		if (TEST_CONF_COLLECTION_MAXDOC <= MAXSHOW)
		{
			mcout << NOR << "buckets " << doc->docid;

			if (doc->docid < 10) cout << "    ";
			else cout << "   ";

			for (instance_t hinst = 0; hinst < CONF_COLLECTION_DISTRIBUTED; hinst++)
			{
				for (doc_hash_t pos = 0; pos < TEST_STORAGE_HASH_MAX; pos++)
				{
					doc_hash_t hash = 0;

					docid_t	duplicate_docid = distributed[hinst].duplicates[pos];

					if (duplicate_docid == 0) cout << GRE;

					if (hinst == remove_instance && pos == remove_offset) cout << BRO;

					if (duplicate_docid > 0)
					{
						// Find instance
						instance_t doc_inst = ((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED);
						docid_t doc_offset = ((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED);

						hash = (distributed[doc_inst].doc_hash[doc_offset] % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));

						if (hash < 10) cout << ' ' << hash << NOR << ' ';
						else cout << hash << NOR << ' ';
					}
					else cout << ' ' << hash << NOR << ' ';


					if (duplicate_docid == 0)
					{
						cout << NOR;

						continue;
					}
				}
			}

			cout << NOR << mendl;
		}

		duplicates_occupation--;
#endif
		return PROBE_DELETE;
	}
	else if (distributed[hinst].duplicates[chain_start] > 0) // deletion on perfect offset
	{
		distributed[doc_inst].doc_hash[doc_offset] = CONF_HASH_DOC_MAX_DEFINITIVE;

		distributed[hinst].duplicates[chain_start] = 0;

		distributed[hinst].count_hash--;

		// unlock duplicates
		unlock_a_dupl(hinst);

#ifdef STORAGE_HASH_TEST
		if (TEST_CONF_COLLECTION_MAXDOC <= MAXSHOW)
		{
			mcout << NOR << "buckets " << doc->docid;

			if (doc->docid < 10) cout << "    ";
			else cout << "   ";

			for (instance_t hinst = 0; hinst < CONF_COLLECTION_DISTRIBUTED; hinst++)
			{
				for (doc_hash_t pos = 0; pos < TEST_STORAGE_HASH_MAX; pos++)
				{
					doc_hash_t hash = 0;

					docid_t	duplicate_docid = distributed[hinst].duplicates[pos];

					if (duplicate_docid == 0) cout << GRE;

					if (hinst == remove_instance && pos == remove_offset) cout << BRO;

					if (duplicate_docid > 0)
					{
						// Find instance
						instance_t doc_inst = ((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED);
						docid_t doc_offset = ((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED);

						hash = (distributed[doc_inst].doc_hash[doc_offset] % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));

						if (hash < 10) cout << ' ' << hash << NOR << ' ';
						else cout << hash << NOR << ' ';
					}
					else cout << ' ' << hash << NOR << ' ';

					if (duplicate_docid == 0)
					{
						cout << NOR;

						continue;
					}
				}
			}

			cout << NOR << mendl;
		}

		duplicates_occupation--;
#endif
		return PROBE_DELETE;
	}

	// unlock duplicates
	unlock_a_dupl(hinst);

#ifdef STORAGE_HASH_TEST
	if (TEST_CONF_COLLECTION_MAXDOC <= MAXSHOW)
	{
		mcout << NOR << "buckets err  ";

		for (instance_t hinst = 0; hinst < CONF_COLLECTION_DISTRIBUTED; hinst++)
		{
			for (doc_hash_t pos = 0; pos < TEST_STORAGE_HASH_MAX; pos++)
			{
				doc_hash_t hash = 0;

				docid_t	duplicate_docid = distributed[hinst].duplicates[pos];

				if (duplicate_docid == 0) cout << GRE;

				if (duplicate_docid > 0)
				{
					// Find instance
					instance_t doc_inst = ((duplicate_docid - 1) % CONF_COLLECTION_DISTRIBUTED);
					docid_t doc_offset = ((duplicate_docid - 1) / CONF_COLLECTION_DISTRIBUTED);


#ifndef STORAGE_HASH_TEST
					hash = (distributed[doc_inst].doc_hash[doc_offset] % (STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));
#else
					hash = (distributed[doc_inst].doc_hash[doc_offset] % (TEST_STORAGE_HASH_MAX * CONF_COLLECTION_DISTRIBUTED));
#endif

					if (hash < 10) cout << ' ' << hash << ' ';
					else cout << hash << ' ';
				}
				else cout << ' ' << hash << ' ';

				if (duplicate_docid == 0)
				{
					cout << NOR;

					continue;
				}
			}
		}

		cout << NOR << mendl;
	}
#endif

	return PROBE_ERROR;
}

//
// Name: write_document
//
// Description:
//   Write a document to filesystem
//
// Input:
//   docid - document id to write
//   buf - content of the document
//
// Output:
//   hash - the hash value calculated while writing
//   duplicate_of - if it's a duplicate, return docid of duplicate source
//
// Return:
//   status

storage_status_t Storage::write_document(doc_t *doc, char *buf)
{
	assert(doc->docid > 0);
	assert(doc->content_length > 0);
	assert(readonly == false);
	off64_t rc;

	errno = 0; // errno is thread-local

	string content_path = (find_path(doc->docid));

	FILE *content_file = fopen(content_path.c_str(), "rb");

	if (doc->duplicate_of > 0)
		doc->duplicate_of = (docid_t)0;

	// Find instance
	instance_t doc_inst = ((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t doc_offset = ((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED);

	// Calculate hash function
	doc_hash_t newhash = hashsum(doc->content_length, buf);

	// Check if the doc was already written
	if (content_file != NULL)
	{
		// Find hash function
		// We are sure that inside 'write_document' keep same instance and it is not needed lock in read only
		// because writing operations for docid are called in same time 'write_document' is called
		// and at most once during harvesting
		doc_hash_t oldhash = distributed[doc_inst].doc_hash[doc_offset];

		bool has_changed = true;

		// Check if the doc has changed. First step is comparing newhash with oldhash.
		if (newhash == oldhash)
		{
			// Same hash value, check content
			has_changed = false;

			// Load the old document
			char *tmpbuf = CBALLOC(char, MALLOC, MAX_DOC_LEN);

			// Compare doc->content_lengths and after this compare content byte to byte
			size_t readed = fread (tmpbuf, 1, MAX_DOC_LEN, content_file);

			if (errno != 0)
			{
				mcerr << RED << "Storage write_document: couldn't read content file "<< cberr() << " on "  << content_path.c_str() << NOR << mendl;
				has_changed = true;
			}

			if (readed == (size_t)doc->content_length)
			{
				if (memcmp(tmpbuf, buf, doc->content_length) != 0)
					has_changed = true;
			}
			else
				has_changed = true;

			free(tmpbuf);

			if (has_changed == false)
			{
				rc = fclose(content_file);

				if (errno != 0) assert(rc == 0);

				return STORAGE_UNCHANGED;
			}
		}

		// It has changed
		// Delete old record from hash table
		// Check hash table for duplicates

		linear_probe_status_t lp_status = linear_probe_delete(doc);

		if (lp_status == PROBE_NOT_FOUND)
		{
			mcerr << RED << "Storage write_document: for docid " << doc->docid << " old hash (" << oldhash << ") not found for docid " << doc->docid << '.' << NOR << mendl;
		}
		else if (lp_status == PROBE_ERROR)
		{
			mcerr << RED << "Storage write_document: for docid " << doc->docid << " error while deleting old hash (" << oldhash << ") for docid " << doc->docid << '.' << NOR << mendl;
		}

		assert(lp_status == PROBE_DELETE);
	}

	// It's a new document, or a document that has changed

	// Note: this may be the source for a mirror (ie.: many pages
	// are copies of this one, and this page changed).
	// Hence, // those pages are no longer mirrors of this. 
	// To account for this case, mirrors should be visited,
	// with low priority.

	// Save hash value

	// Check if document have duplicates
	if (linear_probe_resolve(doc, buf, newhash) == PROBE_EXISTENT)
	{
		if (content_file != NULL)
		{
			rc = fclose(content_file);

			if (errno != 0)
				assert(rc == 0);
		}

		return STORAGE_DUPLICATE;
	}

	if (content_file != NULL)
	{
		rc = fclose(content_file);

		if (errno != 0)
			assert(rc == 0);
	}

	// Write to disk
	content_file = fopen(content_path.c_str(), "wb");

	if (errno != 0 && errno != ENOENT)
		die("write_document: for docid %llu couldn't open content file %s on %s\n", doc->docid, cberr(), content_path.c_str());
	else if (errno == ENOENT)
			errno = 0;

	assert(content_file != NULL);

	// protect file from reading from other programs during this writing
	if (file_lock(content_file, false) == true)
	{
		size_t written = fwrite(buf, sizeof(char), doc->content_length, content_file);

		if (errno != 0)
			die("write_document: for docid %llu couldn't write to content file %s on %s\n", doc->docid, cberr(), content_path.c_str());

		assert(written == (size_t)doc->content_length); 
	}
	else
		die("write_document: for docid %llu couldn't not lock file %s\n", doc->docid, content_path.c_str());


	if (file_unlock(content_file) == false)
		die ("write_document: for docid %llu couldn't not unlock file %s\n", doc->docid, content_path.c_str());

	rc = fclose(content_file);
	assert(rc == 0);

	return STORAGE_OK;
}

//
// Name: st_create
//
// Description:
//   Create a new storage
//
// Input:
//
// Output:
//
// Return:
//
 
void Storage::st_create(void)
{
	if (thread_alarm != THREADS_OK)
		return;

	assert(dirname != NULL);
	assert(readonly == false);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Storage::thread_args_t *args = CBALLOC(Storage::thread_args_t, MALLOC, 1);
	    args->inst = inst;
    	args->obj = this;
		args->f = STORAGE_CREATE;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_create((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}
}

//
// Name: thread_function_create
//
// Description:
//   Creates and return a storage object
//
// Input:
//   basedir - directory
//   check_distributed - if it's necessary to create a duplicate check file
//
// Return:
//

void *Storage::thread_function_create(void *args)
{
	cpu_set_t system_cpus;

	Storage::thread_args_t *arguments = (Storage::thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	Storage *obj = arguments->obj;

	// max_docid at first time must be set to zero
	obj->distributed[inst].max_docid = 0;

	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
	strcpy(obj->distributed[inst].basedir, relative_rem_path);
	free(relative_rem_path);

	// Filename
	char filename[MAX_STR_LEN];

	errno = 0; // errno is thread-local

	if (strlen(obj->dirname) == strlen(COLLECTION_TEXT) && strncmp(obj->dirname, COLLECTION_TEXT, strlen(COLLECTION_TEXT)) == 0)
	{
			// Create hierarchy of directories for each istance
			make_hierarchy (inst, obj->dirname);

			obj->distributed[inst].max_offset = 0;

			// Create sketch file
			obj->distributed[inst].sketch_file = 0;
			sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_SKETCH);
			obj->distributed[inst].sketch_file = open(filename, O_RDWR|O_LARGEFILE|O_CREAT|O_TRUNC, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);

			if (obj->distributed[inst].sketch_file <= 0)
				die("storage_create: couldn't create sketch file", cberr());

			// Create the sketch_gap file (this is slow)
			// The sketch_gap file is an in-disk hash table, initially
			// set to zero
			obj->distributed[inst].sketch_gap_file = 0;
			sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_SKETCH_GAP);
			obj->distributed[inst].sketch_gap_file = open(filename, O_RDWR|O_LARGEFILE|O_CREAT|O_TRUNC, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);

			if (obj->distributed[inst].sketch_gap_file <= 0)
				die("storage_create: couldn't create sketch_gap file", cberr());

			// Iterate to fill the hash table with zero
			const unsigned char gap_zero = 0;
			for (doc_hash_t v = 0; v <= (CONF_COLLECTION_MAXDOC + 1); v++) {
				size_t written = write(obj->distributed[inst].sketch_gap_file, &(gap_zero), sizeof(unsigned char));
				assert(written == sizeof(unsigned char));
			}

			obj->distributed[inst].index_file		= 0;
			obj->distributed[inst].content_file		= 0;
			obj->distributed[inst].doc_hash			= NULL;
			obj->distributed[inst].duplicates		= NULL;
			obj->distributed[inst].free_list		= NULL;
	}
	else
	{
			obj->distributed[inst].free_list = NULL;

			// Nullify files
			obj->distributed[inst].content_file = 0;
			obj->distributed[inst].index_file = 0;
			// Create index
			sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_INDEX);
			obj->distributed[inst].index_file = open(filename, O_RDWR|O_LARGEFILE|O_CREAT|O_TRUNC, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);

			// Check sizeof(offset type)
			assert(sizeof(off64_t) == 8);

			if (obj->distributed[inst].index_file <= 0)
				die("storage_create: couldn't create index", cberr());

			// Grow
			obj->grow(inst, (docid_t)1);

			// Create the content file
			sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_CONTENT);
			obj->distributed[inst].content_file = open(filename, O_RDWR|O_LARGEFILE|O_CREAT|O_TRUNC, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);
			assert(obj->distributed[inst].content_file > 0);

			// Create the free pointers structure
			obj->distributed[inst].free_list = CBALLOC(storage_free_list_t, MALLOC, 1);
			obj->distributed[inst].free_list->rec.offset = 0;
			obj->distributed[inst].free_list->rec.size   = (off64_t)1 << 62;  // max offset
			obj->distributed[inst].free_list->next		= NULL;

			obj->distributed[inst].doc_hash			= NULL;
			obj->distributed[inst].duplicates		= NULL;
			obj->distributed[inst].sketch_file		= 0;
			obj->distributed[inst].sketch_gap_file	= 0;
	}

	return NULL;
}

//
// Name: st_open
//
// Description:
//   Open an existing storage
//
// Input:
//
// Output:
//
// Return:
//

void Storage::st_open(void)
{
	if (thread_alarm != THREADS_OK)
		return;

	assert(dirname != NULL);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Storage::thread_args_t *args = CBALLOC(Storage::thread_args_t, MALLOC, 1);
	    args->inst = inst;
    	args->obj = this;
		args->f = STORAGE_OPEN;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_open((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
    	{
	        // Update master counter
    	    max_docid += distributed[inst].max_docid;
		}

		free(threads);
	}
}

//
// Name: thread_function_open
//
// Description:
//   Opens the storage in the specified directory,
//   creates if necessary
//
// Input:
//   basedir - directory
//
// Return:
//   the opened storage object
//

void *Storage::thread_function_open(void *args)
{
	cpu_set_t system_cpus;

	Storage::thread_args_t *arguments = (Storage::thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	Storage *obj = arguments->obj;

	// Setting to 0 max_docid for documents. Will be increased in this function
	obj->distributed[inst].max_docid = 0;

	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
	strcpy(obj->distributed[inst].basedir, relative_rem_path);
	free(relative_rem_path);

	char filename[MAX_STR_LEN];

	errno = 0; // errno is thread-local

	// Try to open the main file
	sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_MAIN);
	FILE *file_main = fopen64(filename, "r");

	if (strlen(obj->dirname) != strlen(COLLECTION_TEXT) || strncmp(obj->dirname, COLLECTION_TEXT, strlen(COLLECTION_TEXT)) != 0)
	{
		if (file_main == NULL)
		{

			if (obj->readonly)
				die("Storage does not exist. Can't create file in readonly mode");

			// Create storage
			cerr << "(storage_create) ";
			obj->st_create();

			return NULL;
		}
	}

	// Read from disk
	if (fread(&obj->distributed[inst], sizeof(storage_t), 1, file_main) < 1)
		die("couldn't read main file for storage");

	fclose(file_main);

	if (errno != 0)
		die("Storage st_open: couldn't close file %s on %s", cberr(), filename);

	// Get memory for the storage object
	if (strlen(obj->dirname) == strlen(COLLECTION_TEXT) && strncmp(obj->dirname, COLLECTION_TEXT, strlen(COLLECTION_TEXT)) == 0)
	{
			// hash of docs to needed for reduce readings of content from disk
    		obj->distributed[inst].doc_hash = CBALLOC(doc_hash_t, CALLOC, CONF_COLLECTION_MAXDOC);

			// all values must have hashs set to CONF_HASH_DOC_MAX_DEFINITIVE
			for (docid_t d = 0; d < CONF_COLLECTION_MAXDOC; d++) obj->distributed[inst].doc_hash[d] = CONF_HASH_DOC_MAX_DEFINITIVE;

			// Open the file of hashing of contents of documents
			sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_DOC_HASH);
			FILE *file_doc_hash = fopen64(filename, "r");

			if (file_doc_hash != NULL)
			{
            	// Read
				doc_hash_t doc_hash_readed = fread(obj->distributed[inst].doc_hash, sizeof(doc_hash_t), CONF_COLLECTION_MAXDOC, file_doc_hash);
				assert(doc_hash_readed == CONF_COLLECTION_MAXDOC);

				// Close
				fclose(file_doc_hash);
			}
			
			// hash of duplicates
    		obj->distributed[inst].duplicates = CBALLOC(docid_t, CALLOC, STORAGE_HASH_MAX);

			// Open the duplicates file
			sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_DUPLICATES);
			FILE *file_duplicates_hash = fopen64(filename, "r");

			if (file_duplicates_hash != NULL)
			{
            	// Read
				doc_hash_t duplicates_readed = fread(obj->distributed[inst].duplicates, sizeof(docid_t), STORAGE_HASH_MAX, file_duplicates_hash);
				assert(duplicates_readed == STORAGE_HASH_MAX);

				// Close
				fclose(file_duplicates_hash);
			}
			
			// Open the sketchfiles
			sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_SKETCH);

			struct stat64 statbuf;

			if (stat64(filename, &statbuf) == 0)
			{
				obj->distributed[inst].max_offset = (statbuf.st_size / (sizeof(irudiko_t) * IRUDIKO_SKETCHSIZE));

				docid_t docid = ((obj->distributed[inst].max_offset - 1) + inst + 1);

				if (docid > obj->distributed[inst].max_docid)
					obj->distributed[inst].max_docid = docid;
			}
			else
				die("storage_open: couldn't open read sketch file statistics %s", cberr());

			if (obj->readonly)
				obj->distributed[inst].sketch_file = open(filename, O_RDONLY|O_LARGEFILE);
			else
				obj->distributed[inst].sketch_file = open(filename, O_RDWR|O_LARGEFILE|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);

			if (obj->distributed[inst].sketch_file <= 0)
				die("storage_open: couldn't open sketch file %s", cberr());

			// Open the sketch_gap_files
			sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_SKETCH_GAP);

			if (obj->readonly)
				obj->distributed[inst].sketch_gap_file = open(filename, O_RDONLY|O_LARGEFILE);
			else
				obj->distributed[inst].sketch_gap_file = open(filename, O_RDWR|O_LARGEFILE|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);

			if (obj->distributed[inst].sketch_gap_file <= 0)
				die("storage_open: couldn't open sketch gap file %s", cberr());

			obj->distributed[inst].index_file	= 0;
			obj->distributed[inst].content_file	= 0;
			obj->distributed[inst].free_list	= NULL;
	}
	else
	{
		// Open the index
		sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_INDEX);

		if (obj->readonly)
			obj->distributed[inst].index_file = open(filename, O_RDONLY|O_LARGEFILE);
		else
			obj->distributed[inst].index_file = open(filename, O_RDWR|O_LARGEFILE|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);

		if (obj->distributed[inst].index_file <= 0)
			die("storage_open: couldn't open index file %s", cberr());

		off64_t indexsize = lseek64(obj->distributed[inst].index_file, (off64_t)0, SEEK_END);
		assert(indexsize > 0);

		// Check max_docid
		if (readonly == false && obj->distributed[inst].max_docid != (indexsize/sizeof(storage_record_t)))
		{
			cerr << " obj->distributed[" << inst << "].max_docid = " << obj->distributed[inst].max_docid << ", " << indexsize << ", " << indexsize/sizeof(storage_record_t) << endl;
			die("storage open: obj->distributed[%lu].max_docid inconsistent", (unsigned long int)inst);
		}

		// Open the free pointers file
		sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_FREE);
		int free_file;
		
		if (obj->readonly)
			free_file = open(filename, O_RDONLY|O_LARGEFILE);
		else
			free_file = open(filename, O_RDWR|O_LARGEFILE|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);

		if (free_file <= 0)
			die("storage_open: couldn't open free file %s", cberr());

		// Check the free pointers file size
		off64_t rc = lseek64(free_file, (off64_t)0, SEEK_SET);
		assert(rc == 0);

		// Read the free pointers file
		storage_record_t freerec;
		obj->distributed[inst].free_list = NULL;
		storage_free_list_t *current = NULL;

		while (read(free_file, &(freerec), sizeof(freerec)) == sizeof(freerec))
		{
			storage_free_list_t *item = (storage_free_list_t *)malloc(sizeof(storage_free_list_t));
			assert(item != NULL);
			item->rec.offset = freerec.offset;
			item->rec.size	= freerec.size;
			item->next	= NULL;

			if (current == NULL)
				obj->distributed[inst].free_list = item;
			else
				current->next = item;

			current = item;
		}

		close(free_file);

		// Open the content file
		sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_CONTENT);

		if (obj->readonly)
			obj->distributed[inst].content_file = open(filename, O_RDONLY|O_LARGEFILE);
		else
			obj->distributed[inst].content_file = open(filename, O_RDWR|O_LARGEFILE, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);

		if (obj->distributed[inst].content_file <= 0)
			die("storage_open: couldn't open content file %s", cberr());

		// Try to re-create free pointers file if it was lost
		if (obj->distributed[inst].free_list == NULL)
		{
			cerr << "***********************************************" << endl;
			cerr << "WARNING! Had to create again free pointers file" << endl;
			cerr << "         directory " << obj->distributed[inst].basedir << endl;
			cerr << "**********************************************" << endl;
			storage_free_list_t *item = CBALLOC(storage_free_list_t, MALLOC, 1);

			// Create a blank record
			item->rec.offset	= 0;
			item->rec.size   	= (off64_t)1 << 62;  // max offset

			struct stat64 buf;
			fstat64(obj->distributed[inst].content_file, &(buf));

			// Modify record to mark all the data entered
			// as not-free
			item->rec.offset 	+= buf.st_size;
			item->rec.size		-= buf.st_size;

			// Store the item
			item->next	= NULL;
			obj->distributed[inst].free_list	= item;
		}

		obj->distributed[inst].doc_hash			= NULL;
		obj->distributed[inst].duplicates		= NULL;
		obj->distributed[inst].sketch_file		= 0;
		obj->distributed[inst].sketch_gap_file	= 0;
	}

	// Returns the readed object
	return NULL;
}

//
// Name: st_close
//
// Description:
//   Close an existing storage
//
// Input:
//
// Output:
//
// Return:
//

void Storage::st_close(void)
{
	if (thread_alarm != THREADS_OK)
		return;

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Storage::thread_args_t *args = CBALLOC(Storage::thread_args_t, MALLOC, 1);
	    args->inst = inst;
    	args->obj = this;
		args->f = STORAGE_CLOSE;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_close((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}
}

//
// Name: thread_function_close
//
// Description:
//   Closes the storage in basedir, frees memory
//
// Input:
//   st - the storage object
// 

void *Storage::thread_function_close(void *args)
{
	cpu_set_t system_cpus;

	Storage::thread_args_t *arguments = (Storage::thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	Storage *obj = arguments->obj;
	
	int rc;
	char filename[MAX_STR_LEN];

	errno = 0; // errno is thread-local

	if (strlen(obj->dirname) == strlen(COLLECTION_TEXT) && strncmp(obj->dirname, COLLECTION_TEXT, strlen(COLLECTION_TEXT)) == 0)
	{
		if (obj->readonly == false)
		{
			if (obj->distributed[inst].doc_hash != NULL)
			{
				// Open the file of hashing of contents of documents
				sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_DOC_HASH);

				// Open
				FILE *file_doc_hash = fopen64(filename, "w");
				assert(file_doc_hash != NULL);

            	// Read
				doc_hash_t doc_hash_writed = fwrite(obj->distributed[inst].doc_hash, sizeof(doc_hash_t), CONF_COLLECTION_MAXDOC, file_doc_hash);
				assert(doc_hash_writed == CONF_COLLECTION_MAXDOC);

				// Close
				fclose(file_doc_hash);
			}
			
			if (obj->distributed[inst].duplicates != NULL)
			{
				// Save the duplicates hash tables
				sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_DUPLICATES);

				// Open
				FILE *file_duplicates_hash = fopen64(filename, "w");
				assert(file_duplicates_hash != NULL);

				// Write
				doc_hash_t duplicates_writed = fwrite(obj->distributed[inst].duplicates, sizeof(docid_t), STORAGE_HASH_MAX, file_duplicates_hash);
				assert(duplicates_writed == STORAGE_HASH_MAX);

				// Close
				fclose(file_duplicates_hash);
			}
		}

		if (obj->distributed[inst].doc_hash != NULL)
		{
			free(obj->distributed[inst].doc_hash);
			obj->distributed[inst].doc_hash = NULL;
		}

		if (obj->distributed[inst].duplicates != NULL)
		{
			free(obj->distributed[inst].duplicates);
			obj->distributed[inst].duplicates = NULL;
		}
 
		// Close sketch storage
		rc = close(obj->distributed[inst].sketch_file);

		if (errno != 0)
			die("Storage close: error closing sketch file descriptor %s\n", cberr());

		assert(rc == 0);
		obj->distributed[inst].sketch_file = 0;

		rc = close(obj->distributed[inst].sketch_gap_file);

		if (errno != 0)
			die("Storage close: error closing sketch file descriptor %s\n", cberr());

		assert(rc == 0);
		obj->distributed[inst].sketch_gap_file = 0;

		// Write main file to disk

		// Nullify all pointers
		obj->distributed[inst].index_file		= 0;
		obj->distributed[inst].content_file		= 0;
		obj->distributed[inst].free_list		= NULL;

		// Open main file
		sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_MAIN); 
		FILE *file_main = fopen64(filename, "w");
		assert(file_main != NULL);

		if (fwrite(&obj->distributed[inst], sizeof(storage_t), 1, file_main) < 1) {
			die("Couldn't write file_main"); 
		}

		int rc = fclose(file_main);

		if (errno != 0)
			mcerr << "Storage st_close: couldn't close file "<< cberr() << " on "  << filename << mendl;

		assert(rc == 0);
	}
	else
	{
		// Close index st
		rc = close(obj->distributed[inst].index_file);
		assert(rc == 0);

		// Close content st
		rc = close(obj->distributed[inst].content_file);
		assert(rc == 0);

		// If readonly mode, bail out
		if (obj->readonly == true)
		{
			// Open free_file
			int free_file;
			sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_FREE);
			free_file = open(filename, O_RDONLY|O_LARGEFILE);
			assert(free_file > 0);

			// Write free_file
			storage_free_list_t *current = obj->distributed[inst].free_list;
			storage_free_list_t *last;
			
			while (current != NULL)
			{
				last = current;
				current = current->next;
				free(last);
			}

			// Close free and duplicates file
			rc = close(free_file);
			assert(rc == 0);

			obj->distributed[inst].free_list = NULL;

			return NULL;
		}

		// Open free_file
		int free_file;
		sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_FREE);
		free_file = open(filename, O_RDWR|O_LARGEFILE|O_TRUNC|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);
		assert(free_file > 0);

		// Write free_file
		storage_free_list_t *current = obj->distributed[inst].free_list;
		storage_free_list_t *last;
		
		while (current != NULL)
		{
			if (write(free_file, &(current->rec), sizeof(storage_record_t)) != sizeof(storage_record_t))
				die("Storage st_close: couldn't write to free st %s\n", cberr());

			last = current;
			current = current->next;
			free(last);
		}

		// Close free files
		rc = close(free_file);
		assert(rc == 0);

		// Write main file to disk

		// Nullify all pointers
		obj->distributed[inst].index_file		= 0;
		obj->distributed[inst].content_file	= 0;
		obj->distributed[inst].free_list = NULL;

		// Open main file
		sprintf(filename, "%s/%s", obj->distributed[inst].basedir, STORAGE_FILENAME_MAIN); 
		FILE *file_main = fopen64(filename, "w");
		assert(file_main != NULL);

		if (fwrite(&obj->distributed[inst], sizeof(storage_t), 1, file_main) < 1) {
			die("Couldn't write file_main"); 
		}

		int rc = fclose(file_main);

		if (errno != 0)
			mcerr << "Storage st_close: couldn't close file "<< cberr() << " on "  << filename << mendl;

		assert(rc == 0);
	}

	return NULL;
}

// Name: st_remove
//
// Description:
//   Remove existing storage
//
// Input:
//   st - the storage object
// 

void Storage::st_remove(void)
{
	assert(dirname != NULL);

	pthread_t *threads = NULL;

	instance_t max_instances = 0;

	struct stat64 statbuf;

	// check how many directory contain data to delete
	for (instance_t inst = 0; inst < ((instance_t)(~0)); inst++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);

		if (stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
			max_instances++;
		else
		{
			free(relative_rem_path);
			break;
		}

		free(relative_rem_path);
	}

	if (max_instances > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, max_instances);

		for (instance_t inst = 0; inst < max_instances; inst++)
		{
			Storage::thread_args_t *args = CBALLOC(Storage::thread_args_t, MALLOC, 1);
		    args->inst = inst;
	    	args->obj = this;
			args->f = STORAGE_REMOVE;

			if (CONF_COLLECTION_DISTRIBUTED > 1)
			{
				if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
					die("error creating thread!");
			}
			else
				thread_function_remove((void *) args); // only one distribution, function is call without thread 
		}

		CBotjoin(threads, max_instances);

		free(threads);
	}
}

//
// Name: thread_function_remove
//
// Description:
//   Removes files in a storage
//
// Input:
//   dirname - the directory
//   

void *Storage::thread_function_remove(void *args)
{
	cpu_set_t system_cpus;

	Storage::thread_args_t *arguments = (Storage::thread_args_t *)args;

	instance_t inst = arguments->inst;

//	CPU_OPTIMIZE;

	Storage *obj = arguments->obj;

	const char *dirname = obj->dirname;

	queue<string> files;

	// Push files
	if (strlen(dirname) == strlen(COLLECTION_TEXT) && strncmp(dirname, COLLECTION_TEXT, strlen(COLLECTION_TEXT)) == 0)
	{
		files.push(STORAGE_FILENAME_SKETCH);
		files.push(STORAGE_FILENAME_SKETCH_GAP);
		files.push(STORAGE_FILENAME_DUPLICATES);
	}
	else
	{
		files.push(STORAGE_FILENAME_MAIN);
		files.push(STORAGE_FILENAME_INDEX);
		files.push(STORAGE_FILENAME_CONTENT);
		files.push(STORAGE_FILENAME_FREE);
	}

	//if (strlen(dirname) == strlen(COLLECTION_TEXT) && strncmp(dirname, COLLECTION_TEXT, strlen(COLLECTION_TEXT)) == 0)
	//	files.push(STORAGE_FILENAME_DUPLICATES);

	errno = 0; // errno is thread-local

	// Delete
	while (! files.empty())
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);

		// Create filename
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, files.front().c_str());

		// Delete file
		int rc = unlink(filename);

		if (rc != 0 && errno != ENOENT)
			die("Couldn't unlink file %s %s", cberr(), filename);

		// Remove file from queue
		files.pop();

		free(relative_rem_path);
	}

	// Remove content of documents downloaded from web
	if (strlen(dirname) == strlen(COLLECTION_TEXT) && strncmp(dirname, COLLECTION_TEXT, strlen(COLLECTION_TEXT)) == 0)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);

		//remove all files
		char command[MAX_STR_LEN] = "rm -rf ";
		strcat(command, relative_rem_path);
		strcat(command, "/*");
		system (command); // 'system' should not create problem with multithread because it work on different path according to instance

		errno = 0; // errno is thread-local

		if (inst >= CONF_COLLECTION_DISTRIBUTED)
		{
			// Delete dir (rimuove le presunte directory vuote 'remdr/distr25/text', 'remdr/distr26/text',  ecc..)
			int rc = remove(relative_rem_path);

			if (rc != 0 && errno != ENOENT)
				die("Couldn't remove directory %s %s", cberr(), relative_rem_path);
		}

		free(relative_rem_path);
	}
	else if (inst >= CONF_COLLECTION_DISTRIBUTED)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);

		errno = 0; // errno is thread-local

		// Delete dir (rimuove le presunte directory vuote 'remdr/distr25/text', 'remdr/distr26/text',  ecc..)
		int rc = remove(relative_rem_path);

		if (rc != 0 && errno != ENOENT)
			die("Couldn't remove directory %s %s", cberr(), relative_rem_path);
	}

	return NULL;
}

//
//
// Name: Storage::dump_status
//
// Description:
//   Dumps the structure status to stderr
//
// Input:
//

void Storage::dump_status()
{
	assert(dirname != NULL);

	bool is_text = false;

	if (strlen(dirname) == strlen(COLLECTION_TEXT) && strncmp(dirname, COLLECTION_TEXT, strlen(COLLECTION_TEXT)) == 0)
	{
		is_text = true;
		cerr << "For disk stats refer to system commands." << endl << endl;
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		cerr << "* Status report of storage in " << distributed[inst].basedir << endl;

		if (is_text == false)
		{
			off64_t total = 0;
			int nfree = 0;
			off64_t maxsize = 0;
			off64_t fragmented = 0;
			storage_free_list_t *current = distributed[inst].free_list;
			off64_t lastoffset = 0;

			while (current != NULL)
			{
				if (current->rec.size > maxsize)
				{
					fragmented += maxsize;
					maxsize = current->rec.size;
				}
				else
					fragmented += current->rec.size;

				total += current->rec.size;
				nfree++;
				lastoffset = current->rec.offset;
				current = current->next;
			}

			cerr << "Disk space used:                  " << lastoffset << endl;

			if (lastoffset > 0)
				cerr << "Fragmented:                       " << fragmented << " (" << (int)((fragmented*100/lastoffset)) << "%) in " << nfree << " blocks" << endl;

			cerr << "Available size:                   " << total << endl;
		}
		else
		{
			cerr << "Files documents on instance:      " << distributed[inst].max_docid << endl;

			doc_hash_t security_treshold = ((STORAGE_HASH_MAX - CONF_COLLECTION_MAXDOC) / 10);

			if (distributed[inst].count_hash > (CONF_COLLECTION_MAXDOC + security_treshold))
				cerr << "Duplicated hash degrading status: " << RED << distributed[inst].count_hash << NOR << '/' << STORAGE_HASH_MAX << endl;
			else if (distributed[inst].count_hash > (CONF_COLLECTION_MAXDOC - security_treshold))
				cerr << "Duplicated hash degrading status: " << BRO << distributed[inst].count_hash << NOR << '/' << STORAGE_HASH_MAX << endl;
			else
				cerr << "Duplicated hash degrading status: " << GRE << distributed[inst].count_hash << NOR << '/' << STORAGE_HASH_MAX << endl;
		}
	}
}

//
// Name: exists
//
// Description:
//   Returns the status of existente of an object
//
// Input:
//   st - the storage object
//   docid - the document id requested
//
// Returns:
//   status
//

storage_status_t Storage::exists(instance_t &inst, docid_t docid)
{
	// Verify that the docid is covered
	if (docid > distributed[inst].max_docid) grow(inst, docid);

	storage_record_t rec;

	// Load the index record
	if (read_index_record(inst, docid, &(rec)) == STORAGE_NOT_FOUND)
		return STORAGE_NOT_FOUND;

	// See if the record contains any information
	if (rec.size == -1)
		return STORAGE_NOT_FOUND;
	else
		return STORAGE_OK;
}

//
// Name: delete_document
// 
// Description:
//   Delete a document from a filesystem
//
// Input:
//   docid - document id to delete
//
// Output:
//
// Return:
//   status
// 

storage_status_t Storage::delete_document(doc_t *doc)
{

	assert(doc->docid > 0);

	// Check if the storage file is large enough
	if (doc->docid > max_docid)
		return STORAGE_NOT_FOUND;

	// Delete old record from hash table
	if (linear_probe_delete(doc) != PROBE_DELETE) return STORAGE_UNCHANGED;

	string content_path = (find_path(doc->docid));

	FILE *content_file = fopen(content_path.c_str(), "rb");

	if (content_file == NULL)
		return STORAGE_NOT_FOUND;
	else
	{
		fclose(content_file);

		errno = 0; // errno is thread-local

		// Delete file
		int rc = unlink(content_path.c_str()); // TODO see comment on header file on 'delete_document'

		if (rc != 0 && errno != ENOENT)
			die("Storage delete_document: couldn't unlink file %s on %s\n", cberr(), content_path.c_str());
	}
	
	return STORAGE_OK;
}

//
// Name: read_index_record
//
// Description:
//   Read an index record to index_file
//
// Input:
//   st - the storage object
//   docid - the record number
//   rec - the record to be written
//

storage_status_t Storage::read_index_record(instance_t &inst, docid_t docid, storage_record_t *rec)
{
	seek_index_record(inst, docid);

	size_t s = sizeof(storage_record_t);

	errno = 0; // errno is thread-local

	ssize_t ret = read(distributed[inst].index_file, rec, s);

	if (ret == 0) // already id do not exists
		return STORAGE_NOT_FOUND;
	else if (ret == (ssize_t)s)
		return STORAGE_OK;
	else
		die("storage read_index_record: couldn't read from index %s\n", cberr());

	return STORAGE_ERROR;
}

//
// Name: write_index_record
//
// Description:
//   Writes an index record to index_file
//
// Input:
//   st - the storage object
//   docid - the record number
//   rec - the record to be written
//

void Storage::write_index_record(instance_t &inst, docid_t docid, storage_record_t *rec)
{
	seek_index_record(inst, docid);

	errno = 0; // errno is thread-local

	if (write(distributed[inst].index_file, rec, sizeof(storage_record_t)) != sizeof(storage_record_t))
		die("storage write_index_record: couldn't write to index %s on %s\n", cberr(), distributed[inst].index_file);
}

//
// Name: seek_index_record
//
// Description:
//   Seeks the position of an index record in index_file
//
// Input:
//   i - the instance
//   docid - the record number
//

void Storage::seek_index_record(instance_t &inst, docid_t docid)
{
	errno = 0; // errno is thread-local

	if (lseek64(distributed[inst].index_file, (off64_t)(docid * sizeof(storage_record_t)), SEEK_SET) < (off64_t)0)
		die("Storage seek_index_record: couldn't seek on index %s\n", cberr());
}

//
// Name: grow
//
// Description:
//   Grows the index to allow at least docid
//
// Input:
//   s - the storage object
//   docid - the docid to allocate

void Storage::grow(instance_t &inst, docid_t docid)
{
	assert(dirname != NULL);

//    docid = (((docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	docid_t old_max = distributed[inst].max_docid;

	pthread_mutex_lock(console_lock);

	if (old_max > 0)
		cerr << "[index grows on instance " << (unsigned long int)inst << ", current=" << distributed[inst].max_docid << ", needed=" << docid << ']';

	pthread_mutex_unlock(console_lock);

	// Empty record
	storage_record_t rec;
	rec.offset = (~0);
	rec.size = (~0);

	// Go to the end of the index
	off64_t indexsize = lseek64(distributed[inst].index_file, (off64_t)0, SEEK_END);

	if (indexsize < 0)
		die("Storage grow: On instance %lu lseek64 in index", (unsigned long int)inst);

	// Check max_docid
	if (distributed[inst].max_docid != (indexsize/sizeof(storage_record_t)))
	{
		die("Storage grow: On instance %lu distributed[inst].max_docid=%llu, %llu, %f inconsistent", (unsigned long int)inst, distributed[inst].max_docid, indexsize, indexsize/sizeof(storage_record_t));
	}

	// See how much it's necessary to grow
	docid_t new_max = distributed[inst].max_docid;

	if (new_max == 0)
		new_max = 1;
	else
		while (new_max <= docid)
			new_max = new_max * STORAGE_GROW_FACTOR;

//	if (old_max > 0)
//		cerr << " to " << new_max;


	// Grow
	for (docid_t i = distributed[inst].max_docid; i < new_max; i++)
		if ((write(distributed[inst].index_file,&(rec),sizeof(storage_record_t))) < 0)
		{
			die("Storage grow: On instance %lu couldn't write to index file %s", (unsigned long int)inst, cberr());
		}

//	docid_t old_max_docid = distributed[inst].max_docid;
	
	// Update max_docid
	distributed[inst].max_docid = new_max;

	if (old_max > 0)
	{
		pthread_mutex_lock(console_lock);

		cerr << "[grown to " << new_max << " (instance " << (unsigned long int)inst << ") done] ";

		pthread_mutex_unlock(console_lock);
	}
}

//
// Name: docid_count
//
// Description:
//   Give the max_docid
//
// Input:
//

docid_t Storage::docid_count(void) const
{
	return max_docid;
}

//
// Name: hashsum
//
// Description:
//   Calculates a hash function for a document
//
// Input:
//   length - the document length
//   content - the document content
// 
// Return:
//   the hash funcion value, between 0 and doc_hash_t max value
//

doc_hash_t Storage::hashsum(off64_t length, char *content) const
{
	doc_hash_t hash_value;
	off64_t count = 0;

	for (hash_value = 0; count++ <= length; content++)
		hash_value = ((131 * (hash_value == 0 ? 1 : hash_value) + (*content)) % CONF_HASH_DOC_MAX_DEFINITIVE); // MS patch

	return hash_value; 
}

//
// Funzione che crea la gerarchia delle directory necessarie per contenere i documenti del motore di ricerca
//
// Riceve come argomento il numero massimo di documenti che deve contenere
//
void Storage::make_hierarchy (instance_t &inst, const char *dirname) const
{
	assert((CONF_COLLECTION_SITES_PER_FOLDER > CONF_COLLECTION_DISTRIBUTED) && (CONF_COLLECTION_SITES_PER_FOLDER % CONF_COLLECTION_DISTRIBUTED) == 0);

	unsigned int base = (CONF_COLLECTION_SITES_PER_FOLDER / CONF_COLLECTION_DISTRIBUTED);
	unsigned int docsinfolder = (CONF_COLLECTION_SITES_PER_FOLDER / CONF_COLLECTION_DISTRIBUTED);
	unsigned int oldbase = 0;
	unsigned int depth = 0;

	assert((base > 0) && (base < CONF_COLLECTION_MAXDOC));
	assert((docsinfolder > 0) && (docsinfolder < CONF_COLLECTION_MAXDOC));

	// ciclo che permette di calcolare la profondità delle struttura delle directory
	// e il numero totale di directory
	while (base < CONF_COLLECTION_MAXDOC)
	{
		oldbase = base;
		base = base * docsinfolder;
		depth++;
	}

	assert(depth > 0);

	depth--;

	assert(depth > 0);

	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);
	assert(strlen(relative_rem_path) < (MAX_STR_LEN - 1));

	char temparray[23] = {'\0'};
	char _dirname[MAX_STR_LEN] = {'\0'};
	sprintf(_dirname, "%s/", relative_rem_path);
	free(relative_rem_path);

	unsigned int oldstate [MAX_STR_LEN];

	unsigned int z = depth;

	for (z = depth; z > 0; z--)
		oldstate [z] = 0;

	oldstate[z] = '\0';

	for (unsigned int o = 0; o < oldbase; o++)
	{
		string dirpath;
		string mkdir_a = _dirname;

		for (unsigned int i = depth; i > 0; i--)
		{
			unsigned int to_convert = (static_cast<unsigned int>(o/(pow((double)docsinfolder, i))) % docsinfolder);
			char *dir = digits_to_ascii(to_convert);
			size_t ldir = strlen(dir);
			strncpy(temparray, dir, ldir);
			free(dir);
			temparray[ldir++] = ASCII_US;
			temparray[ldir++] = ASCII_SL;
			temparray[ldir] = '\0';
			mkdir_a = mkdir_a + temparray;

			if (o == 0)
				mkdir(mkdir_a.c_str(), 0777);
			else if (o % docsinfolder == 0 && to_convert != oldstate [i])
				mkdir(mkdir_a.c_str(), 0777);

			oldstate [i] = to_convert;
		}

		char *dir = digits_to_ascii((o % docsinfolder));
		size_t ldir = strlen(dir);
		strncpy(temparray, dir, ldir);
		free(dir);
		temparray[ldir++] = ASCII_US;
		temparray[ldir++] = ASCII_SL;
		temparray[ldir] = '\0';
		mkdir((mkdir_a + temparray).c_str(), 0777);
		dirpath = "";
	}
}

//
// Funzione che restituisce il percorso dove collocare un documento per il motore di ricerca
//
// Riceve come argomento il numero di documento
//
// Restituisce il percorso
//
string Storage::find_path(docid_t docid) const
{
	unsigned int base = (CONF_COLLECTION_SITES_PER_FOLDER / CONF_COLLECTION_DISTRIBUTED);
	unsigned int docsinfolder = (CONF_COLLECTION_SITES_PER_FOLDER / CONF_COLLECTION_DISTRIBUTED);
	unsigned int depth = 0;

	// ciclo che permette di calcolare la profondità delle struttura delle directory
	// e il numero totale di directory
	while (base < CONF_COLLECTION_MAXDOC)
	{
		base = base * docsinfolder;
		depth++;
	}

	instance_t inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);

	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_TEXT, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);

	char temparray[23] = {'\0'};
	string dirname = ((string)relative_rem_path + "/");
	free(relative_rem_path);
	string content_path = (string)CONF_COLLECTION_BASE + "/";
	content_path.append(dirname);

	for (unsigned int i = depth; i > 0; i--)
	{
		unsigned int to_convert = (static_cast<unsigned int>((((docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1)/(pow((double)docsinfolder, i))) % docsinfolder);
		char *dir = digits_to_ascii(to_convert);
		size_t ldir = strlen(dir);
		strncpy(temparray, dir, ldir);
		free(dir);
		temparray[ldir++] = ASCII_US;
		temparray[ldir++] = ASCII_SL;
		temparray[ldir] = '\0';
		content_path.append(temparray);
	}

	char *sdocid = digits_to_ascii(docid);
	content_path.append(sdocid);
	free(sdocid);

	return content_path;
}

// StorageWriteSketch

storage_status_t Storage::write_sketch(docid_t docid, irudiko_t *sketch)
{
	assert(docid > 0);
	assert(sketch!=NULL);
	assert(!readonly);

	instance_t inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);
    docid_t id_offset = ((docid - 1) / CONF_COLLECTION_DISTRIBUTED);

	/*	
	cout << "SKETCH: " << (*sketch).sketch[0];
	for (uint h = 1; h < IRUDIKO_SKETCHSIZE; ++h)
	  cout << ", " << (*sketch).sketch[h];
	cout << "." << endl;
	*/

	errno = 0; // errno is thread-local

	// check if file descriptors are valid
	assert(fcntl(distributed[inst].sketch_file, F_GETFL) != 1);

	if (errno != 0)
		die("storage write_sketch: %s\n", cberr());

	size_t size = (size_t)(sizeof(irudiko_t) * IRUDIKO_SKETCHSIZE);
	off64_t address = (off64_t)(id_offset * sizeof(irudiko_t) * IRUDIKO_SKETCHSIZE);

	ssize_t wr = pwrite64(distributed[inst].sketch_file, sketch, size, address);

	if (errno != 0)
		die("storage write_sketch: for docid %llu couldn't write file (address %llu) %s\n", docid, address, cberr());

	assert(wr == (ssize_t)size);

	// Update distributed count
	if (id_offset > distributed[inst].max_offset)
		distributed[inst].max_offset = id_offset;

	// Update document atomic count
	while (docid > max_docid)
		max_docid = docid;
	
	return STORAGE_OK;
}

//StorageReadSketch

storage_status_t Storage::read_sketch(docid_t docid, irudiko_t *sketch)
{
	assert(docid > 0);
	assert(sketch!=NULL);

	instance_t inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);
    docid_t id_offset = ((docid - 1) / CONF_COLLECTION_DISTRIBUTED);
	
	if	(id_offset > distributed[inst].max_offset)
		return STORAGE_NOT_FOUND; ///////////

	errno = 0; // errno is thread-local

	// check if file descriptors are valid
	assert(fcntl(distributed[inst].sketch_file, F_GETFL) != 1);

	if (errno != 0)
		die("storage read_sketch: %s\n", cberr());

	size_t size = (size_t)(sizeof(irudiko_t) * IRUDIKO_SKETCHSIZE);
	off64_t address = (off64_t)(id_offset * sizeof(irudiko_t) * IRUDIKO_SKETCHSIZE);

	ssize_t wr = pread64(distributed[inst].sketch_file, sketch, size, address);

	if (errno != 0)
		die("storage read_sketch: for docid %llu couldn't read file (address %llu) %s\n", docid, address, cberr());

	assert(wr == (ssize_t)size);
	
	return STORAGE_OK;
}

// StorageWriteSketchGap

storage_status_t Storage::write_sketch_gap(docid_t docid, unsigned char *gap)
{
	assert(docid > 0);
	assert(gap!=NULL);
	assert(!readonly);

	instance_t inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);
    docid_t id_offset = ((docid - 1) / CONF_COLLECTION_DISTRIBUTED);

	errno = 0; // errno is thread-local

	// check if file descriptors are valid
	assert(fcntl(distributed[inst].sketch_gap_file, F_GETFL) != 1);

	if (errno != 0)
		die("storage write_sketch_gap: %s\n", cberr());

	size_t size = (size_t)(sizeof(unsigned char));
	off64_t address = (off64_t)(id_offset * sizeof(unsigned char));

	ssize_t wr = pwrite64(distributed[inst].sketch_gap_file, gap, size, address);

	if (errno != 0)
		die("storage write_sketch_gap: for docid %llu couldn't write file (address %llu) %s\n", docid, address, cberr());

	assert(wr == (ssize_t)size);
	
	return STORAGE_OK;
}

//StorageReadSketchGap

storage_status_t Storage::read_sketch_gap(docid_t docid, unsigned char *gap)
{
	assert(docid > 0);
	assert(gap!=NULL);

	instance_t inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);
    docid_t id_offset = ((docid - 1) / CONF_COLLECTION_DISTRIBUTED);
	
	if (id_offset > distributed[inst].max_offset)
		return STORAGE_NOT_FOUND;

	errno = 0; // errno is thread-local

	// check if file descriptors are valid
	assert(fcntl(distributed[inst].sketch_gap_file, F_GETFL) != 1);

	if (errno != 0)
		die("storage read_sketch_gap: %s\n", cberr());

	size_t size = (size_t)(sizeof(unsigned char));
	off64_t address = (off64_t)(id_offset * sizeof(unsigned char));

	ssize_t wr = pread64(distributed[inst].sketch_gap_file, gap, size, address);

	if (errno != 0)
		die("storage read_sketch_gap: for docid %llu couldn't read file (address %llu) %s\n", docid, address, cberr());

	assert(wr == (ssize_t)size);

	return STORAGE_OK;
}

// Functions to lock/unlock mutexes

//
// Description: lock mutex
//
// Input: The instance of duplicates
//
// Return:
//
void Storage::lock_a_dupl(instance_t &inst) const
{
	int rc = 0;

	if (lock != NULL && lock->locka != NULL)
		if ((rc = pthread_mutex_lock(&(lock->locka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
//
// Description: lock mutex for read only operations
//
// Input: The instance of hashes
//
// Return:
//
void Storage::wrlock_hashs(void) const
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_wrlock(&(lock->rwlocka[CONF_COLLECTION_DISTRIBUTED]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
//
// Description: lock mutex for read only operations
//
// Input: The instance of hashes
//
// Return:
//
void Storage::rdlock_hashs(void) const
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_rdlock(&(lock->rwlocka[CONF_COLLECTION_DISTRIBUTED]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
//
// Description: lock mutex for read only operations
//
// Input: The instance of hashes
//
// Return:
//
void Storage::rdlock_a_hash(instance_t &inst) const
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_rdlock(&(lock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
//
// Description: lock mutex for read write operations
//
// Input: The instance of hashes
//
// Return:
//
void Storage::wrlock_a_hash(instance_t &binst) const
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_wrlock(&(lock->rwlocka[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
/*
void Storage::lock_b_site(instance_t &binst)
{
	int rc = 0;

	if (slock != NULL && slock->lockb != NULL)
		if ((rc = pthread_mutex_lock(&(slock->lockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Storage::lock_c_site(instance_t &inst)
{
	int rc = 0;

	if (slock != NULL && slock->lockc != NULL)
		if ((rc = pthread_mutex_lock(&(slock->lockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Storage::lock_a_domain(instance_t &inst)
{
	int rc = 0;

	if (dlock != NULL && dlock->locka != NULL)
		if ((rc = pthread_mutex_lock(&(dlock->locka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Storage::lock_b_domain(instance_t &binst)
{
	int rc = 0;

	if (dlock != NULL && dlock->lockb != NULL)
		if ((rc = pthread_mutex_lock(&(dlock->lockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Storage::lock_c_domain(instance_t &inst)
{
	int rc = 0;

	if (dlock != NULL && dlock->lockc != NULL)
		if ((rc = pthread_mutex_lock(&(dlock->lockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Storage::lock_a_path(instance_t &inst)
{
	int rc = 0;

	if (plock != NULL && plock->locka != NULL)
		if ((rc = pthread_mutex_lock(&(plock->locka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Storage::lock_b_path(instance_t &binst) const
{
	int rc = 0;

	if (plock != NULL && plock->lockb != NULL)
		if ((rc = pthread_mutex_lock(&(plock->lockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Storage::lock_c_path(instance_t &inst) const
{
	int rc = 0;

	if (plock != NULL && plock->lockc != NULL)
		if ((rc = pthread_mutex_lock(&(plock->lockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::wrlock_a_site(instance_t &inst) const
{
	int rc = 0;

	if (slock != NULL && slock->rwlocka != NULL)
		if ((rc = pthread_rwlock_wrlock(&(slock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::wrlock_b_site(instance_t &binst) const
{
	int rc = 0;

	if (slock != NULL && slock->rwlockb != NULL)
		if ((rc = pthread_rwlock_wrlock(&(slock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::wrlock_c_site(instance_t &inst) const
{
	int rc = 0;

	if (slock != NULL && slock->rwlockc != NULL)
		if ((rc = pthread_rwlock_wrlock(&(slock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::wrlock_a_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock != NULL && dlock->rwlocka != NULL)
		if ((rc = pthread_rwlock_wrlock(&(dlock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::wrlock_b_domain(instance_t &binst) const
{
	int rc = 0;

	if (dlock != NULL && dlock->rwlockb != NULL)
		if ((rc = pthread_rwlock_wrlock(&(dlock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::wrlock_c_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock != NULL && dlock->rwlockc != NULL)
		if ((rc = pthread_rwlock_wrlock(&(dlock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::wrlock_a_path(instance_t &inst) const
{
	int rc = 0;

	if (plock != NULL && plock->rwlocka != NULL)
		if ((rc = pthread_rwlock_wrlock(&(plock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::wrlock_b_path(instance_t &binst) const
{
	int rc = 0;

	if (plock != NULL && plock->rwlockb != NULL)
		if ((rc = pthread_rwlock_wrlock(&(plock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::wrlock_c_path(instance_t &inst) const
{
	int rc = 0;

	if (plock != NULL && plock->rwlockc != NULL)
		if ((rc = pthread_rwlock_wrlock(&(plock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Storage::rdlock_a_site(instance_t &inst) const
{
	int rc = 0;

	if (slock != NULL && slock->rwlocka != NULL)
		if ((rc = pthread_rwlock_rdlock(&(slock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::rdlock_b_site(instance_t &binst) const
{
	int rc = 0;

	if (slock != NULL && slock->rwlockb != NULL)
		if ((rc = pthread_rwlock_rdlock(&(slock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::rdlock_c_site(instance_t &inst) const
{
	int rc = 0;

	if (slock != NULL && slock->rwlockc != NULL)
		if ((rc = pthread_rwlock_rdlock(&(slock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::rdlock_a_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock != NULL && dlock->rwlocka != NULL)
		if ((rc = pthread_rwlock_rdlock(&(dlock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::rdlock_b_domain(instance_t &binst) const
{
	int rc = 0;

	if (dlock != NULL && dlock->rwlockb != NULL)
		if ((rc = pthread_rwlock_rdlock(&(dlock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::rdlock_c_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock != NULL && dlock->rwlockc != NULL)
		if ((rc = pthread_rwlock_rdlock(&(dlock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::rdlock_a_path(instance_t &inst) const
{
	int rc = 0;

	if (plock != NULL && plock->rwlocka != NULL)
		if ((rc = pthread_rwlock_rdlock(&(plock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::rdlock_b_path(instance_t &binst) const
{
	int rc = 0;

	if (plock != NULL && plock->rwlockb != NULL)
		if ((rc = pthread_rwlock_rdlock(&(plock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::rdlock_c_path(instance_t &inst) const
{
	int rc = 0;

	if (plock != NULL && plock->rwlockc != NULL)
		if ((rc = pthread_rwlock_rdlock(&(plock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
*/
void Storage::unlock_a_dupl(instance_t &inst) const
{
	int rc = 0;

	if (lock != NULL && lock->locka != NULL)
		if ((rc = pthread_mutex_unlock(&(lock->locka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Storage::unlock_hashs(void) const
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_unlock(&(lock->rwlocka[CONF_COLLECTION_DISTRIBUTED]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Storage::unlock_a_hash(instance_t &binst) const
{
	int rc = 0;

	if (lock != NULL && lock->rwlocka != NULL)
		if ((rc = pthread_rwlock_unlock(&(lock->rwlocka[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
/*                                            
void Storage::unlock_c_site(instance_t &inst) const
{
	int rc = 0;

	if (slock != NULL && slock->rwlockc != NULL)
		if ((rc = pthread_rwlock_unlock(&(slock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Storage::unlock_a_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock != NULL && dlock->rwlocka != NULL)
		if ((rc = pthread_rwlock_unlock(&(dlock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::unlock_b_domain(instance_t &binst) const
{
	int rc = 0;

	if (dlock != NULL && dlock->rwlockb != NULL)
		if ((rc = pthread_rwlock_unlock(&(dlock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Storage::unlock_c_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock != NULL && dlock->rwlockc != NULL)
		if ((rc = pthread_rwlock_unlock(&(dlock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Storage::unlock_a_path(instance_t &inst) const
{
	int rc = 0;

	if (plock != NULL && plock->rwlocka != NULL)
		if ((rc = pthread_rwlock_unlock(&(plock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Storage::unlock_b_path(instance_t &binst, bool is_mutual_exclusion_mutex) const
{
	int rc = 0;

	if (is_mutual_exclusion_mutex == true)
	{
		if (plock != NULL && plock->lockb != NULL)
		if ((rc = pthread_mutex_unlock(&(plock->lockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	else if (plock != NULL && plock->rwlockb != NULL)
		if ((rc = pthread_rwlock_unlock(&(plock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Storage::unlock_c_path(instance_t &inst) const
{
	int rc = 0;

	if (plock != NULL && plock->rwlockc != NULL)
		if ((rc = pthread_rwlock_unlock(&(plock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
*/
