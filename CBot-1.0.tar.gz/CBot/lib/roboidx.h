/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _ROBOIDX_H_INCLUDED_
#define _ROBOIDX_H_INCLUDED_

#include <config.h>

// System libraries

#include <stdlib.h>
#include <assert.h>
#include <fstream>
#include <pthread.h>

// Local libraries

#include <const.h>
#include <Meta.h>
#include <Storage.h>
#include <Url.h>
#include <cmd5.h>

// Robots index status

enum roboidx_status_t {
		ROBOIDX_OK   = 0,
		ROBOIDX_ERROR,
	};


// Filenames

// Constants

//#define ROBO_MAX_OUTDEGREE				350

// Robo index status

// Type 

// Functions



Storage *roboidx_open( const char *, bool );

// INLINED functions (used by siterobo)

//
// Name: roboidx_sequential_read
//
// Description:
//   Reads the robos for the next document
//
// Input:
//   roboidx - the structure
//   buffer - a buffer
//
// Output:
//   dest[] - destinations of robos
//   outdegree - out degree
//

inline void roboidx_sequential_read( Storage *ridx, instance_t &inst, char *buf, off64_t &size ) {
	storage_record_t rec;
	storage_status_t rc;

	rc = ridx->sequential_read( inst, &(rec), buf );

	if (rc == STORAGE_NOT_FOUND)
		size = 0;
	else
		size = rec.size;


}

// 
// Name: roboidx_sequential_skip
//
// Description:
//   Skips a number of records, this is useful to skip
//   several documents with zero out-degree
//
// Input:
//   roboidx - the structure
//   skip - the number of records to skip
//

inline void roboidx_sequential_skip( Storage *ridx, instance_t &inst, uint skip ) {
	ridx->sequential_skip( inst, skip );
}

#endif
