/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "Url.h"

//
// Name: thread_function_caller
//
// Description:
//   A proxy function to pass non-static function at pthread_create
//   Note: function called by thread_function_caller need to have real class object passed through args
//
// Input:
//   args - void arguments
//
// Return:
//   pointer to void
//

void *Url::thread_function_caller(void *args)
{
	assert(args);

try
{
	Url::thread_args_t *arguments = (Url::thread_args_t *)args;

	Url *newObj = NULL;

	try
	{
		newObj = new Url (NULL, RO); // Note function called work to 'this' temporary object and need to be deleted at the end of the same.
	}
	catch (std::bad_alloc& ba)
	{
		die("thread_function_caller bad_alloc caught: %s", ba.what());
	}

	switch (arguments->f)
	{
		case URL_NEW:
			newObj->thread_function_new(args);
			break;
		case URL_OPEN:
			newObj->thread_function_open(args);
			break;
		case URL_CLOSE:
			newObj->thread_function_close(args);
			break;
		case URL_REMOVE:
			newObj->thread_function_remove(args);
			break;
		default:
			break;
	}

	delete newObj;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL); 
}

	free(args);
	args = NULL;

	return NULL;
}

void Url::ddx_new(void)
{
	if (thread_alarm != THREADS_OK)
		return;

	assert(dirname);
	assert(openmode == WR);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Url::thread_args_t *args = CBALLOC(Url::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = URL_NEW;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_new((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}
}

void *Url::thread_function_new(void *args)
{
	cpu_set_t system_cpus;

	Url::thread_args_t *arguments = (Url::thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	Url *obj = arguments->obj;

	memset(&obj->distributed[inst], 0, sizeof(urlddx_t));

	// hash of buckets
	obj->distributed[inst].site_hash = CBALLOC(off64_t, CALLOC, URLDDX_SITE_HASH_SIZE);
	obj->distributed[inst].domain_hash = CBALLOC(domain_hash_t, CALLOC, URLDDX_SITE_HASH_SIZE);
	obj->distributed[inst].path_hash = CBALLOC(off64_t, CALLOC, URLDDX_PATH_HASH_SIZE);

	// Set default values
	obj->distributed[inst].domain_hash_count = 0;
	obj->distributed[inst].site_hash_count = 0;
	obj->distributed[inst].path_hash_count = 0;
	obj->distributed[inst].domain_count = 0;
	obj->distributed[inst].sdomain_count = CONF_MAX_TWOLEVELDOMAINID;
	obj->distributed[inst].site_count = 0;
	obj->distributed[inst].path_count = 0;
	obj->distributed[inst].domain_next_char = 1; // start in 1
	obj->distributed[inst].sdomain_next_char = 1; // start in 1
	obj->distributed[inst].site_next_char = 1; // start in 1
	obj->distributed[inst].path_next_char = 1; // start in 1

	// Work dir
	// Copy locale dataretention pathname
	char *relative_loc_path = DataRetention::make(DataRetention::LOCDR, obj->dirname, inst);
	assert(strlen(relative_loc_path) < (MAX_STR_LEN - 1));
	strcpy(obj->distributed[inst].locdrpathname, relative_loc_path);
	free(relative_loc_path);

	// Copy remote dataretention pathname
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < (MAX_STR_LEN - 1));
	strcpy(obj->distributed[inst].remdrpathname, relative_rem_path);
	free(relative_rem_path);

	// Open files
	char filename[MAX_STR_LEN];

	// domain_file.
	sprintf(filename, "%s/%s", obj->distributed[inst].locdrpathname, URLDDX_FILENAME_DOMAIN);
	obj->distributed[inst].domain_file = open64(filename, O_RDWR|O_LARGEFILE|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);
	assert(obj->distributed[inst].domain_file > 0);
	write(obj->distributed[inst].domain_file, "\0", 1);   // Write 1 char (starts in position 1)

	// special domain_file.
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SDOMAIN);
	obj->distributed[inst].sdomain_file = open64(filename, O_RDWR|O_LARGEFILE|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);
	assert(obj->distributed[inst].sdomain_file > 0);
	write(obj->distributed[inst].sdomain_file, "\0", 1);   // Write 1 char (starts in position 1)

	// site_file.
	sprintf(filename, "%s/%s", obj->distributed[inst].locdrpathname, URLDDX_FILENAME_SITE);
	obj->distributed[inst].site_file = open64(filename, O_RDWR|O_LARGEFILE|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);
	assert(obj->distributed[inst].site_file > 0);
	write(obj->distributed[inst].site_file, "\0", 1);   // Write 1 char (starts in position 1)

	// path_file.
	sprintf(filename, "%s/%s", obj->distributed[inst].locdrpathname, URLDDX_FILENAME_PATH);
	obj->distributed[inst].path_file = open64(filename, O_RDWR|O_LARGEFILE|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);
	assert(obj->distributed[inst].path_file > 0);
	write(obj->distributed[inst].path_file, "\0", 1);   // Write 1 char (starts in position 1)

	// list of offsets
	obj->distributed[inst].site_list = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXSITE);
	obj->distributed[inst].domain_list = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXDOMAIN);
	obj->distributed[inst].path_list = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXDOC);

	// bucket_instance
	obj->distributed[inst].site_bucket_instance = CBALLOC(instance_t, CALLOC, CONF_COLLECTION_MAXSITE);
	obj->distributed[inst].domain_bucket_instance = CBALLOC(instance_t, CALLOC, CONF_COLLECTION_MAXDOMAIN);
	obj->distributed[inst].path_bucket_instance = CBALLOC(instance_t, CALLOC, CONF_COLLECTION_MAXDOC);

	obj->distributed[inst].path_homepage = CBALLOC(uint8_t, CALLOC, URLDDX_HOMEPAGE_SIZE);

	return NULL;
}

void Url::ddx_open(void)
{
	if (thread_alarm != THREADS_OK)
		return;

	assert(dirname);

	// The configuration file has to be open
	assert(CONF_OK);
	assert(CONF_COLLECTION_DISTRIBUTED < UCHAR_MAX); // if not, change type

	if (openmode == RW)
		assert(curl_global_init(CURL_GLOBAL_ALL) == 0);

	bool mainmissing = false;

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		// Open the main file
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);
		assert(strlen(relative_rem_path) < (MAX_STR_LEN - 1));
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, URLDDX_FILENAME_ALL);
		free(relative_rem_path);
		FILE *file_all = fopen64(filename, "r");

		// Check if main file is found
		if (file_all == NULL)
		{
			mainmissing = true;
			break;
		}
		else
			fclose(file_all);
	}

	if (mainmissing == true)
	{
		if (openmode == WR)
		{
			cerr << "Creating urls indexes ... " << endl;
//			ddx_remove();
			return ddx_new();
		}
		else
		{
			perror("Opening urls index, one or more main files are missing");
			die("Failed to open urls index");
		}
	}

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Url::thread_args_t *args = CBALLOC(Url::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = URL_OPEN;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_open((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		// Update domain master counter
		domain_count += distributed[inst].domain_count;
		// Update site master counter
		site_count += distributed[inst].site_count;
		// Update site master counter
		path_count += distributed[inst].path_count;
	}
}

void *Url::thread_function_open(void *args)
{
	cpu_set_t system_cpus;

	Url::thread_args_t *arguments = (Url::thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	Url *obj = arguments->obj;

	// Make locale dataretention pathname
	char *relative_loc_path = DataRetention::make(DataRetention::LOCDR, obj->dirname, inst);
	assert(strlen(relative_loc_path) < (MAX_STR_LEN - 1));

	// Make remote dataretention pathname
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < (MAX_STR_LEN - 1));

	// Open the main file
	char filename[MAX_STR_LEN];
	sprintf(filename, "%s/%s", relative_rem_path, URLDDX_FILENAME_ALL);
	FILE *file_all = fopen64(filename, "r");

	// Read the main file
	size_t count = fread(&(obj->distributed[inst]), sizeof(urlddx_t), 1, file_all);

	assert(count == 1);
	fclose(file_all);

	// Copy locale dataretention pathname
	strcpy(obj->distributed[inst].locdrpathname, relative_loc_path);
	free(relative_loc_path);

	// Copy remote dataretention pathname
	strcpy(obj->distributed[inst].remdrpathname, relative_rem_path);
	free(relative_rem_path);

	// Open the other files
	siteid_t domains_readed = 0;
	siteid_t sdomains_readed = 0;
	siteid_t sites_readed = 0;
	docid_t paths_readed = 0;

	// Read DOMAIN list table
	obj->distributed[inst].domain_list = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXDOMAIN);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_DOMAIN_LIST);
	FILE *file_domain_list = fopen64(filename, "r");
	assert(file_domain_list);

	// Read
	domains_readed = fread(obj->distributed[inst].domain_list, sizeof(off64_t), CONF_COLLECTION_MAXDOMAIN, file_domain_list);
	assert(domains_readed == CONF_COLLECTION_MAXDOMAIN);

	// Close
	fclose(file_domain_list);
/*
	// Read SPECIAL DOMAIN list table
	obj->distributed[inst].sdomain_list = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXSDOMAIN);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SDOMAIN_LIST);
	FILE *file_sdomain_list = fopen64(filename, "r");
	assert(file_sdomain_list);

	// Read
	sdomains_readed = fread(obj->distributed[inst].domain_list, sizeof(off64_t), CONF_COLLECTION_MAXSDOMAIN, file_domain_list);
	assert(sdomains_readed == CONF_COLLECTION_MAXSDOMAIN);

	// Close
	fclose(file_sdomain_list);
*/
	// Read SITE list table
	obj->distributed[inst].site_list = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXSITE);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SITE_LIST);
	FILE *file_site_list = fopen64(filename, "r");
	assert(file_site_list);

	// Read
	sites_readed = fread(obj->distributed[inst].site_list, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_site_list);
	assert(sites_readed == CONF_COLLECTION_MAXSITE);

	// Close
	fclose(file_site_list);

	// Read PATH list table
	obj->distributed[inst].path_list = CBALLOC(off64_t, CALLOC, CONF_COLLECTION_MAXDOC);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_PATH_LIST);
	FILE *file_path_list = fopen64(filename, "r");
	assert(file_path_list);

	// Read
	paths_readed = fread(obj->distributed[inst].path_list, sizeof(off64_t), CONF_COLLECTION_MAXDOC, file_path_list);
	assert(paths_readed == CONF_COLLECTION_MAXDOC);

	// Close
	fclose(file_path_list);

	// Read path names
	sprintf(filename, "%s/%s", obj->distributed[inst].locdrpathname, URLDDX_FILENAME_PATH);

	errno = 0; // errno is thread-local

	// Read domain names
	sprintf(filename, "%s/%s", obj->distributed[inst].locdrpathname, URLDDX_FILENAME_DOMAIN);

	errno = 0; // errno is thread-local

	if (obj->openmode == WR || obj->openmode == RW)
		obj->distributed[inst].domain_file = open64(filename, O_RDWR|O_LARGEFILE, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);
	else
		obj->distributed[inst].domain_file = open64(filename, O_RDONLY|O_LARGEFILE);

	if (errno != 0)
		die("url ddx_open: couldn't open domain file %s on %s\n", cberr(), filename);

	// Read special domain names
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SDOMAIN);

	errno = 0; // errno is thread-local

	if (obj->openmode == WR || obj->openmode == RW)
		obj->distributed[inst].sdomain_file = open64(filename, O_RDWR|O_LARGEFILE, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);
	else
		obj->distributed[inst].sdomain_file = -1;

	if (errno != 0)
		die("url ddx_open: couldn't open special domain file %s on %s\n", cberr(), filename);

	// Read site names and copy on memory if read only
	if (obj->openmode == WR || obj->openmode == RW)
	{	// Read site names
		sprintf(filename, "%s/%s", obj->distributed[inst].locdrpathname, URLDDX_FILENAME_SITE);

		errno = 0; // errno is thread-local

		obj->distributed[inst].site_file = open64(filename, O_RDWR|O_LARGEFILE, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);

		if (errno != 0)
			die("url ddx_open: couldn't open site file %s on %s\n", cberr(), filename);
	}
	else if (obj->openmode == RO)
	{	// Read site names
		sprintf(filename, "%s/%s", obj->distributed[inst].locdrpathname, URLDDX_FILENAME_SITE);

		errno = 0; // errno is thread-local

		obj->distributed[inst].site_file = open64(filename, O_RDONLY|O_LARGEFILE);

		if (errno != 0)
			die("url ddx_open: couldn't open site file %s on %s\n", cberr(), filename);
	}
	else if (obj->openmode == RO_MEMORY) // Read site names on volatile data if read only memory
	{	// Open site's file
		sprintf(filename, "%s/%s", obj->distributed[inst].locdrpathname, URLDDX_FILENAME_SITE);
		FILE *site_file = fopen64(filename, "r");

		// Get site's file size
		off64_t file_site_length;
		fseeko64(site_file, 0, SEEK_END);
		file_site_length = ftello(site_file);
		assert(file_site_length > 0);
		fseeko64(site_file, 0, SEEK_SET);

		// Allocate memory
		obj->distributed[inst].site = CBALLOC(char, MALLOC, file_site_length);

		// If CBALLOC don't assert, force here
		assert(obj->distributed[inst].site);

		// Read
		count = fread(obj->distributed[inst].site, file_site_length, 1, site_file);
		assert(count == 1);

		// Close
		fclose(site_file);
	}
	else
		die("url ddx_open: couldn't open site file %s (openmode unknown)\n", filename);

	// Read path names
	sprintf(filename, "%s/%s", obj->distributed[inst].locdrpathname, URLDDX_FILENAME_PATH);

	errno = 0; // errno is thread-local

	if (obj->openmode == WR || obj->openmode == RW)
		obj->distributed[inst].path_file = open64(filename, O_RDWR|O_LARGEFILE, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH);
	else
		obj->distributed[inst].path_file = open64(filename, O_RDONLY|O_LARGEFILE);

	if (errno != 0)
		die("url ddx_open: couldn't open path file %s on %s\n", cberr(), filename);

	// Read DOMAIN hash table
	obj->distributed[inst].domain_hash = CBALLOC(domain_hash_t, CALLOC, URLDDX_SITE_HASH_SIZE);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_DOMAIN_HASH);
	FILE *file_domain_hash = fopen64(filename, "r");
	assert(file_domain_hash);

	// Read
	domains_readed = fread(obj->distributed[inst].domain_hash, sizeof(domain_hash_t), URLDDX_SITE_HASH_SIZE, file_domain_hash);
	assert(domains_readed == URLDDX_SITE_HASH_SIZE);

	// Close
	fclose(file_domain_hash);
/*
	// Read SDOMAIN hash table
	obj->distributed[inst].sdomain_hash = CBALLOC(domain_hash_t, CALLOC, URLDDX_SITE_HASH_SIZE);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SDOMAIN_HASH);
	FILE *file_sdomain_hash = fopen64(filename, "r");
	assert(file_sdomain_hash);

	// Read
	sdomains_readed = fread(obj->distributed[inst].sdomain_hash, sizeof(domain_hash_t), URLDDX_SITE_HASH_SIZE, file_sdomain_hash);
	assert(sdomains_readed == URLDDX_SITE_HASH_SIZE);

	// Close
	fclose(file_sdomain_hash);
*/
	// Read SITE hash table
	obj->distributed[inst].site_hash = CBALLOC(off64_t, CALLOC, URLDDX_SITE_HASH_SIZE);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SITE_HASH);
	FILE *file_site_hash = fopen64(filename, "r");
	assert(file_site_hash);

	// Read
	sites_readed = fread(obj->distributed[inst].site_hash, sizeof(off64_t), URLDDX_SITE_HASH_SIZE, file_site_hash);
	assert(sites_readed == URLDDX_SITE_HASH_SIZE);

	// Close
	fclose(file_site_hash);

	// Read PATH hash table
	obj->distributed[inst].path_hash = CBALLOC(off64_t, CALLOC, URLDDX_PATH_HASH_SIZE);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_PATH_HASH);
	FILE *file_path_hash = fopen64(filename, "r");
	assert(file_path_hash);

	// Read
	paths_readed = fread(obj->distributed[inst].path_hash, sizeof(off64_t), URLDDX_PATH_HASH_SIZE, file_path_hash);
	assert(paths_readed == URLDDX_PATH_HASH_SIZE);

	// Close
	fclose(file_path_hash);

	// Read DOMAIN bucket inst table
	obj->distributed[inst].domain_bucket_instance = CBALLOC(instance_t, CALLOC, CONF_COLLECTION_MAXDOMAIN);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_DOMAIN_BINST);
	FILE *file_domain_bucket_instance = fopen64(filename, "r");
	assert(file_domain_bucket_instance);

	// Read
	siteid_t domain_binstance_readed = fread(obj->distributed[inst].domain_bucket_instance, sizeof(instance_t), CONF_COLLECTION_MAXSITE, file_domain_bucket_instance);
	assert(domain_binstance_readed == CONF_COLLECTION_MAXSITE);

	// Close
	fclose(file_domain_bucket_instance);
/*
	// Read SDOMAIN bucket inst table
	obj->distributed[inst].sdomain_bucket_instance = CBALLOC(instance_t, CALLOC, CONF_COLLECTION_MAXSDOMAIN);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SDOMAIN_BINST);
	FILE *file_sdomain_bucket_instance = fopen64(filename, "r");
	assert(file_sdomain_bucket_instance);

	// Read
	siteid_t sdomain_binstance_readed = fread(obj->distributed[inst].sdomain_bucket_instance, sizeof(instance_t), CONF_COLLECTION_MAXSDOMAIN, file_sdomain_bucket_instance);
	assert(sdomain_binstance_readed == CONF_COLLECTION_MAXSDOMAIN);

	// Close
	fclose(file_sdomain_bucket_instance);
*/
	// Read SITE bucket inst table
	obj->distributed[inst].site_bucket_instance = CBALLOC(instance_t, CALLOC, CONF_COLLECTION_MAXSITE);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SITE_BINST);
	FILE *file_site_bucket_instance = fopen64(filename, "r");
	assert(file_site_bucket_instance);

	// Read
	siteid_t site_binstance_readed = fread(obj->distributed[inst].site_bucket_instance, sizeof(instance_t), CONF_COLLECTION_MAXSITE, file_site_bucket_instance);
	assert(site_binstance_readed == CONF_COLLECTION_MAXSITE);

	// Close
	fclose(file_site_bucket_instance);

	// Read PATH bucket inst table
	obj->distributed[inst].path_bucket_instance = CBALLOC(instance_t, CALLOC, CONF_COLLECTION_MAXDOC);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_PATH_BINST);
	FILE *file_path_bucket_instance = fopen64(filename, "r");
	assert(file_path_bucket_instance);

	// Read
	docid_t path_binstance_readed = fread(obj->distributed[inst].path_bucket_instance, sizeof(instance_t), CONF_COLLECTION_MAXDOC, file_path_bucket_instance);
	assert(path_binstance_readed == CONF_COLLECTION_MAXDOC);

	// Close
	fclose(file_path_bucket_instance);

	// Read PATH bucket inst table
	obj->distributed[inst].path_homepage = CBALLOC(uint8_t, CALLOC, URLDDX_HOMEPAGE_SIZE);

	// Open
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_PATH_HPAGE);
	FILE *file_path_homepage = fopen64(filename, "r");
	assert(file_path_homepage);

	// Read
	docid_t path_hpage_readed = fread(obj->distributed[inst].path_homepage, sizeof(uint8_t), URLDDX_HOMEPAGE_SIZE, file_path_homepage);
	assert(path_hpage_readed == URLDDX_HOMEPAGE_SIZE);

	// Close
	fclose(file_path_homepage);

	return NULL;
}
                                            
//
// Name: setmutex
//
// Description: Allocate memory and create mutex
//
// Input:
//   urlddx - the url index structure
//   ifxmutex_t structure pointer to klock
//
// Return:
//
void Url::setmutex(urlmutex_t **_slock, urlmutex_t **_dlock, urlmutex_t **_plock)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		if (openmode == WR || openmode == RW)
		{
			*_slock = CBALLOC(urlmutex_t, MALLOC, 1);
			*_dlock = CBALLOC(urlmutex_t, MALLOC, 1);
			*_plock = CBALLOC(urlmutex_t, MALLOC, 1);
		/*	(*_slock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_slock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_slock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_dlock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_dlock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_dlock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_plock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1)); */
			(*_plock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		/*	(*_plock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1)); */
			(*_slock)->rwlocka = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_slock)->rwlockb = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_slock)->rwlockc = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_dlock)->rwlocka = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_dlock)->rwlockb = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_dlock)->rwlockc = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_plock)->rwlocka = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_plock)->rwlockb = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_plock)->rwlockc = CBALLOC(pthread_rwlock_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));

			for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			{
			/*	(*_slock)->locka[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_slock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_slock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_dlock)->locka[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_dlock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_dlock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_plock)->locka[i] = PTHREAD_MUTEX_INITIALIZER; */
				(*_plock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
			/*	(*_plock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER; */
				(*_slock)->rwlocka[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*_slock)->rwlockb[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*_slock)->rwlockc[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*_dlock)->rwlocka[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*_dlock)->rwlockb[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*_dlock)->rwlockc[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*_plock)->rwlocka[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*_plock)->rwlockb[i] = PTHREAD_RWLOCK_INITIALIZER;
				(*_plock)->rwlockc[i] = PTHREAD_RWLOCK_INITIALIZER;
			}

			slock = *_slock;
			dlock = *_dlock;
			plock = *_plock;
		}
		else
		{
		/*	*_slock = CBALLOC(urlmutex_t, MALLOC, 1);
			*_dlock = CBALLOC(urlmutex_t, MALLOC, 1); */
			*_plock = CBALLOC(urlmutex_t, MALLOC, 1);
		/*	(*_slock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_slock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_slock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_dlock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_dlock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_dlock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
			(*_plock)->locka = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1)); */
			(*_plock)->lockb = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
		/*	(*_plock)->lockc = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1)); */

			for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			{
			/*	(*_slock)->locka[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_slock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_slock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_dlock)->locka[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_dlock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_dlock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER;
				(*_plock)->locka[i] = PTHREAD_MUTEX_INITIALIZER; */
				(*_plock)->lockb[i] = PTHREAD_MUTEX_INITIALIZER;
			/*	(*_plock)->lockc[i] = PTHREAD_MUTEX_INITIALIZER; */
			}

		/*	slock = *_slock;
			dlock = *_dlock; */
			plock = *_plock;
		}
	}
}
                                            
//
// Name: destroymutex
//
// Description: Free memory and destroy mutex
//
// Input:
//
// Return:
//
void Url::destroymutex(void)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		if (openmode == WR || openmode == RW)
		{
			// now, we ensure that all mutex are unused and destroyed
			int rc = 0;
	
			for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			{
			/*	if ((rc = pthread_mutex_destroy(&(slock->locka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(slock->lockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(slock->lockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));

				if ((rc = pthread_mutex_destroy(&(dlock->locka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(dlock->lockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(dlock->lockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));

				if ((rc = pthread_mutex_destroy(&(plock->locka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc)); */
	
				if ((rc = pthread_mutex_destroy(&(plock->lockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
			/*	if ((rc = pthread_mutex_destroy(&(plock->lockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc)); */

				if ((rc = pthread_rwlock_destroy(&(slock->rwlocka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_rwlock_destroy(&(slock->rwlockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_rwlock_destroy(&(slock->rwlockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));

				if ((rc = pthread_rwlock_destroy(&(dlock->rwlocka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_rwlock_destroy(&(dlock->rwlockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_rwlock_destroy(&(dlock->rwlockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));

				if ((rc = pthread_rwlock_destroy(&(plock->rwlocka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_rwlock_destroy(&(plock->rwlockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_rwlock_destroy(&(plock->rwlockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
			}
	
		/*	free(slock->locka); slock->locka = NULL;
			free(slock->lockb); slock->lockb = NULL;
			free(slock->lockc); slock->lockc = NULL;
			free(dlock->locka); dlock->locka = NULL;
			free(dlock->lockb); dlock->lockb = NULL;
			free(dlock->lockc); dlock->lockc = NULL;
			free(plock->locka); plock->locka = NULL; */
			free(plock->lockb); plock->lockb = NULL;
		/*	free(plock->lockc); plock->lockc = NULL; */
			free(slock->rwlocka); slock->rwlocka = NULL;
			free(slock->rwlockb); slock->rwlockb = NULL;
			free(slock->rwlockc); slock->rwlockc = NULL;
			free(dlock->rwlocka); dlock->rwlocka = NULL;
			free(dlock->rwlockb); dlock->rwlockb = NULL;
			free(dlock->rwlockc); dlock->rwlockc = NULL;
			free(plock->rwlocka); plock->rwlocka = NULL;
			free(plock->rwlockb); plock->rwlockb = NULL;
			free(plock->rwlockc); plock->rwlockc = NULL;
			free(slock);
			free(dlock);
			free(plock);
		}
		else
		{
			// now, we ensure that all mutex are unused and destroyed
			int rc = 0;
	
			for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			{
			/*	if ((rc = pthread_mutex_destroy(&(slock->locka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(slock->lockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(slock->lockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));

				if ((rc = pthread_mutex_destroy(&(dlock->locka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(dlock->lockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
				if ((rc = pthread_mutex_destroy(&(dlock->lockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));

				if ((rc = pthread_mutex_destroy(&(plock->locka[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc)); */
	
				if ((rc = pthread_mutex_destroy(&(plock->lockb[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc));
	
			/*	if ((rc = pthread_mutex_destroy(&(plock->lockc[i]))) != 0)
					die("error destroying mutex %s", CBoterr(rc)); */
			}
	
		/*	free(slock->locka); slock->locka = NULL;
			free(slock->lockb); slock->lockb = NULL;
			free(slock->lockc); slock->lockc = NULL;
			free(dlock->locka); dlock->locka = NULL;
			free(dlock->lockb); dlock->lockb = NULL;
			free(dlock->lockc); dlock->lockc = NULL;
			free(plock->locka); plock->locka = NULL; */
			free(plock->lockb); plock->lockb = NULL;
		/*	free(plock->lockc); plock->lockc = NULL; */
		/*	free(slock);
			free(dlock); */
			free(plock);
		}
	}
}

//
// Name: ddx_close
//
// Description:
//   Closes the url index, saving data to disk
//
// Input:
//   urlddx - the url index structure
//
void Url::ddx_close(void)
{
	if (thread_alarm != THREADS_OK)
		return;

	assert(dirname);
	assert(CONF_OK);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Url::thread_args_t *args = CBALLOC(Url::thread_args_t, MALLOC, 1);
	    args->inst = inst;
    	args->obj = this;
		args->f = URL_CLOSE;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_close((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}

	if (openmode == RW)
		curl_global_cleanup();
}

//
// Name: thread_function_close
//
// Description: invoked by 'ddx_close' as thread
//
// Arguments: a void pointer to Url::thread_args_t type structure that contain binst and urlddx_t type structure 
//
// Return: NULL
//
void *Url::thread_function_close(void *args)
{
	cpu_set_t system_cpus;

	Url::thread_args_t *arguments = (Url::thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	Url *obj = arguments->obj;

	int rc;

	errno = 0; // errno is thread-local

	// check if file descriptors are valid
	assert(fcntl(obj->distributed[inst].domain_file, F_GETFL) != 1);

	if (errno != 0)
		die("Url ddx_close: domains do not have a valid file descriptor %s\n", cberr());

	// check if file descriptors are valid
	if (obj->openmode == RW)
	{
		assert(fcntl(obj->distributed[inst].sdomain_file, F_GETFL) != 1);

		if (errno != 0)
			die("Url ddx_close: special domains do not have a valid file descriptor %s\n", cberr());
	}

	// check if file descriptors are valid
	assert(fcntl(obj->distributed[inst].path_file, F_GETFL) != 1);

	if (errno != 0)
		die("Url ddx_close: paths do not have a valid file descriptor %s\n", cberr());

	// If readonly mode, bail out, do not write anything
	if (obj->openmode == RO || obj->openmode == RO_MEMORY)
	{
		// Close and nullify domains filehandler
		rc = close(obj->distributed[inst].domain_file);

		if (errno != 0)
			die("Url ddx_close: error closing domain file descriptor %s\n", cberr());

		assert(rc == 0);
		obj->distributed[inst].domain_file = 0;

		if (obj->openmode == RO)
		{
			// Close and nullify sites filehandler
			rc = close(obj->distributed[inst].site_file);

			if (errno != 0)
				die("Url ddx_close: error closing site file descriptor %s\n", cberr());

			assert(rc == 0);
			obj->distributed[inst].site_file = 0;
		}
		else if (obj->openmode == RO_MEMORY)
			free(obj->distributed[inst].site); // free site names loaded in memory for readonly operations

		// Close and nullify paths filehandler
		rc = close(obj->distributed[inst].path_file);

		if (errno != 0)
			die("Url ddx_close: error closing path file descriptor %s\n", cberr());

		assert(rc == 0);
		obj->distributed[inst].path_file = 0;

		free(obj->distributed[inst].domain_hash);
		free(obj->distributed[inst].domain_list);
		free(obj->distributed[inst].domain_bucket_instance);
		free(obj->distributed[inst].site_hash);
		free(obj->distributed[inst].site_list);
		free(obj->distributed[inst].site_bucket_instance);
		free(obj->distributed[inst].path_hash);
		free(obj->distributed[inst].path_list);
		free(obj->distributed[inst].path_bucket_instance);
		free(obj->distributed[inst].path_homepage);
			return NULL;
	}

	siteid_t domains_writed = 0;
	siteid_t sites_writed = 0;
	docid_t paths_writed = 0;

	char filename[MAX_STR_LEN];

	// Close and nullify paths filehandler
	rc = fsync(obj->distributed[inst].path_file);

	if (errno != 0)
		die("Url ddx_close: error syncing path file descriptor %s\n", cberr());

	assert(rc == 0);

	rc = close(obj->distributed[inst].path_file);

	if (errno != 0)
		die("Url ddx_close: error closing path file descriptor %s\n", cberr());

	assert(rc == 0);
	obj->distributed[inst].path_file = 0;

	// Close and nullify sites filehandler
	rc = fsync(obj->distributed[inst].site_file);

	if (errno != 0)
		die("Url ddx_close: error syncing site file descriptor %s\n", cberr());

	assert(rc == 0);

	rc = close(obj->distributed[inst].site_file);

	if (errno != 0)
		die("Url ddx_close: error closing site file descriptor %s\n", cberr());

	assert(rc == 0);
	obj->distributed[inst].site_file = 0;

	// Close and nullify domains filehandler
	rc = fsync(obj->distributed[inst].domain_file);

	if (errno != 0)
		die("Url ddx_close: error syncing domain file descriptor %s\n", cberr());

	assert(rc == 0);

	rc = close(obj->distributed[inst].domain_file);

	if (errno != 0)
		die("Url ddx_close: error closing domain file descriptor %s\n", cberr());

	assert(rc == 0);
	obj->distributed[inst].domain_file = 0;

	// Save the DOMAIN hash tables
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_DOMAIN_HASH);

	// Open
	FILE *file_domain_hash = fopen64(filename, "w");
	assert(file_domain_hash);

	// Write
	domains_writed = fwrite(obj->distributed[inst].domain_hash, sizeof(domain_hash_t), URLDDX_SITE_HASH_SIZE, file_domain_hash);
	assert(domains_writed == URLDDX_SITE_HASH_SIZE);

	// Close
	fclose(file_domain_hash);
	free(obj->distributed[inst].domain_hash);
	obj->distributed[inst].domain_hash = NULL;

	// Save the SITE hash tables
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SITE_HASH);

	// Open
	FILE *file_site_hash = fopen64(filename, "w");
	assert(file_site_hash);

	// Write
	sites_writed = fwrite(obj->distributed[inst].site_hash, sizeof(off64_t), URLDDX_SITE_HASH_SIZE, file_site_hash);
	assert(sites_writed == URLDDX_SITE_HASH_SIZE);

	// Close
	fclose(file_site_hash);
	free(obj->distributed[inst].site_hash);
	obj->distributed[inst].site_hash = NULL;

	// Save the PATH hash tables
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_PATH_HASH);

	// Open
	FILE *file_path_hash = fopen64(filename, "w");
	assert(file_path_hash);

	// Write
	paths_writed = fwrite(obj->distributed[inst].path_hash, sizeof(off64_t), URLDDX_PATH_HASH_SIZE, file_path_hash);
	assert(paths_writed == URLDDX_PATH_HASH_SIZE);

	// Close
	fclose(file_path_hash);
	free(obj->distributed[inst].path_hash);
	obj->distributed[inst].path_hash = NULL;

	// Save the DOMAIN list 
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_DOMAIN_LIST);

	// Open
	FILE *file_domain_list = fopen64(filename, "w");
	assert(file_domain_list);

	// Write
	domains_writed = fwrite(obj->distributed[inst].domain_list, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_domain_list);
	assert(domains_writed == CONF_COLLECTION_MAXSITE);

	// Close
	fclose(file_domain_list);
	free(obj->distributed[inst].domain_list);	obj->distributed[inst].domain_list = NULL;

	// Save the SITE list 
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SITE_LIST);

	// Open
	FILE *file_site_list = fopen64(filename, "w");
	assert(file_site_list);

	// Write
	sites_writed = fwrite(obj->distributed[inst].site_list, sizeof(off64_t), CONF_COLLECTION_MAXSITE, file_site_list);
	assert(sites_writed == CONF_COLLECTION_MAXSITE);

	// Close
	fclose(file_site_list);
	free(obj->distributed[inst].site_list);	obj->distributed[inst].site_list = NULL;

	// Save the PATH list 
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_PATH_LIST);

	// Open
	FILE *file_path_list = fopen64(filename, "w");
	assert(file_path_list);

	// Write
	paths_writed = fwrite(obj->distributed[inst].path_list, sizeof(off64_t), CONF_COLLECTION_MAXDOC, file_path_list);
	assert(paths_writed == CONF_COLLECTION_MAXDOC);

	// Close
	fclose(file_path_list);
	free(obj->distributed[inst].path_list);	obj->distributed[inst].path_list = NULL;

	// Save the DOMAIN bucket inst tables
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_DOMAIN_BINST);

	// Open
	FILE *file_domain_bucket_instance = fopen64(filename, "w");
	assert(file_domain_bucket_instance);

	// Write
	siteid_t domain_binstance_writed = fwrite(obj->distributed[inst].domain_bucket_instance, sizeof(instance_t), CONF_COLLECTION_MAXSITE, file_domain_bucket_instance);
	assert(domain_binstance_writed == CONF_COLLECTION_MAXSITE);

	// Close
	fclose(file_domain_bucket_instance);
	free(obj->distributed[inst].domain_bucket_instance);
	obj->distributed[inst].domain_bucket_instance = NULL;

	// Save the SITE bucket inst tables
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_SITE_BINST);

	// Open
	FILE *file_site_bucket_instance = fopen64(filename, "w");
	assert(file_site_bucket_instance);

	// Write
	siteid_t site_binstance_writed = fwrite(obj->distributed[inst].site_bucket_instance, sizeof(instance_t), CONF_COLLECTION_MAXSITE, file_site_bucket_instance);
	assert(site_binstance_writed == CONF_COLLECTION_MAXSITE);

	// Close
	fclose(file_site_bucket_instance);
	free(obj->distributed[inst].site_bucket_instance);
	obj->distributed[inst].site_bucket_instance = NULL;

	// Save the PATH bucket inst tables
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_PATH_BINST);

	// Open
	FILE *file_path_bucket_instance = fopen64(filename, "w");
	assert(file_path_bucket_instance);

	// Write
	docid_t path_binstance_writed = fwrite(obj->distributed[inst].path_bucket_instance, sizeof(instance_t), CONF_COLLECTION_MAXDOC, file_path_bucket_instance);
	assert(path_binstance_writed == CONF_COLLECTION_MAXDOC);

	// Close
	fclose(file_path_bucket_instance);
	free(obj->distributed[inst].path_bucket_instance);
	obj->distributed[inst].path_bucket_instance = NULL;

	// Save the PATH homepages list
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_PATH_HPAGE);

	// Open
	FILE *file_path_homepage = fopen64(filename, "w");
	assert(file_path_homepage);

	// Write
	docid_t path_hpage_writed = fwrite(obj->distributed[inst].path_homepage, sizeof(uint8_t), URLDDX_HOMEPAGE_SIZE, file_path_homepage);
	assert(path_hpage_writed == URLDDX_HOMEPAGE_SIZE);

	// Close
	fclose(file_path_homepage);
	free(obj->distributed[inst].path_homepage);
	obj->distributed[inst].path_homepage = NULL;

	// Write the whole structure to disk
	sprintf(filename, "%s/%s", obj->distributed[inst].remdrpathname, URLDDX_FILENAME_ALL);

	// Open
	FILE *file_all = fopen64(filename, "w");
	assert(file_all);

	// Write
	int count = fwrite(&(obj->distributed[inst]), sizeof(urlddx_t), 1, file_all);
	assert(count == 1);

	// Close
	fclose(file_all);

	return NULL;
}

//
// Name: ddx_remove
//
// Description:
//   Deletes all files for an urlddx
//
// Input:
//   dirname - the directory to clean
//

void Url::ddx_remove(void)
{
	assert(dirname);

	struct stat64 statbuf;

	pthread_t *threads = NULL;

	instance_t max_instances = 0;

	// check how many directory contain data to delete
	for (instance_t inst = 0; inst < ((instance_t)(~0)); inst++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);
		assert(strlen(relative_rem_path) < (MAX_STR_LEN - 1));

		if (stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
			max_instances++;
		else
		{
			free(relative_rem_path);
			break;
		}

		free(relative_rem_path);
	}

	if (max_instances > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, max_instances);

		for (instance_t inst = 0; inst < max_instances; inst++)
		{
			Url::thread_args_t *args = CBALLOC(Url::thread_args_t, MALLOC, 1);
		    args->inst = inst;
			args->obj = this;
			args->f = URL_REMOVE;

			if (max_instances > 1)
			{
				if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
					die("error creating thread!");
			}
			else
				thread_function_remove((void *) args); // only one distribution, function is call without thread 
		}

		CBotjoin(threads, max_instances);

		free(threads);
	}
}

//
// Name: thread_function_remove
//
// Description: invoked by 'ddx_remove' as thread
//
// Arguments: a void pointer to Url::thread_args_t type structure 
//
// Return: NULL
//
void *Url::thread_function_remove(void *args)
{
	cpu_set_t system_cpus;

	Url::thread_args_t *arguments = (Url::thread_args_t *)args;

	instance_t inst = arguments->inst;

	// CPU_OPTIMIZE;

	Url *obj = arguments->obj;

	char *relative_loc_path = DataRetention::make(DataRetention::LOCDR, obj->dirname, inst);
	assert(strlen(relative_loc_path) < (MAX_STR_LEN - 1));

	queue<string> locale_files;

	// Push locale_files
	locale_files.push(URLDDX_FILENAME_DOMAIN);
	locale_files.push(URLDDX_FILENAME_SITE);
	locale_files.push(URLDDX_FILENAME_PATH);

	// Delete
	while (! locale_files.empty())
	{

		// Create filename
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_loc_path, locale_files.front().c_str());

		// Delete file
		int rc = unlink(filename);
		if (rc != 0 && errno != ENOENT)
		{
			perror(locale_files.front().c_str());
			die("Couldn't unlink file");
		}

		// Remove file from queue
		locale_files.pop();
	}

	// Delete dir (rimuove la directory url ...)
	int rc = remove(relative_loc_path);

	if (rc != 0 && errno != ENOENT)
		die("Couldn't remove directory %s on %s", cberr(), relative_loc_path);

	free(relative_loc_path);

	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, obj->dirname, inst);
	assert(strlen(relative_rem_path) < (MAX_STR_LEN - 1));

	queue<string> remote_files;

	// Push remote_files
	remote_files.push(URLDDX_FILENAME_SDOMAIN); // note that this file is on remote
	remote_files.push(URLDDX_FILENAME_DOMAIN_LIST);
	remote_files.push(URLDDX_FILENAME_SITE_LIST);
	remote_files.push(URLDDX_FILENAME_PATH_LIST);
	remote_files.push(URLDDX_FILENAME_DOMAIN_BINST);
    remote_files.push(URLDDX_FILENAME_SITE_BINST);
    remote_files.push(URLDDX_FILENAME_PATH_BINST);
    remote_files.push(URLDDX_FILENAME_PATH_HPAGE);
	remote_files.push(URLDDX_FILENAME_DOMAIN_HASH);
	remote_files.push(URLDDX_FILENAME_SITE_HASH);
	remote_files.push(URLDDX_FILENAME_PATH_HASH);
	remote_files.push(URLDDX_FILENAME_ALL);

	// Delete
	while (! remote_files.empty())
	{

		// Create filename
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, remote_files.front().c_str());

		// Delete file
		int rc = unlink(filename);
		if (rc != 0 && errno != ENOENT)
		{
			perror(remote_files.front().c_str());
			die("Couldn't unlink file");
		}

		// Remove file from queue
		remote_files.pop();
	}

	// Delete dir
	rc = remove(relative_rem_path);

	if (rc != 0 && errno != ENOENT)
		die("Couldn't remove directory %s on %s", cberr(), relative_rem_path);

	free(relative_rem_path);

	return NULL;
}

//
// Name: dump_status
//
// Description:
//   Shows the status of the url index
//
// Input:
//   urlddx - the url index structure
//
void Url::dump_status(void)
{
	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		cerr << "Status dump of inst " << (unsigned long int)inst << ":" << endl;
		cerr << "- locale data retention pathname    " << distributed[inst].locdrpathname << endl;
		cerr << "- remote data retention pathname    " << distributed[inst].remdrpathname << endl;
		cerr << "- domain_count                      " << distributed[inst].domain_count << endl;
		cerr << "- special domain_count              " << distributed[inst].sdomain_count << endl;
		cerr << "- site_count                        " << distributed[inst].site_count << endl;
		cerr << "- path_count                        " << distributed[inst].path_count << endl;
		cerr << "- Disk used by domain names         " << distributed[inst].domain_next_char << endl;
		cerr << "- Disk used by special domain names " << distributed[inst].sdomain_next_char << endl;
		cerr << "- Disk used by sitenames            " << distributed[inst].site_next_char << endl;
		cerr << "- Disk used by paths                " << distributed[inst].path_next_char << endl;

		site_hash_t site_security_treshold = ((URLDDX_SITE_HASH_SIZE - CONF_COLLECTION_MAXSITE) / 10);

		if (distributed[inst].site_hash_count > (CONF_COLLECTION_MAXSITE - site_security_treshold))
			cerr << "- Site hash degrading status   " << RED << distributed[inst].site_hash_count << NOR << (char)ASCII_SL << URLDDX_SITE_HASH_SIZE << endl;
		else
			cerr << "- Site hash degrading status   " << GRE << distributed[inst].site_hash_count << NOR << (char)ASCII_SL << URLDDX_SITE_HASH_SIZE << endl;

		if (distributed[inst].domain_hash_count > (CONF_COLLECTION_MAXSITE - site_security_treshold))
			cerr << "- Domain hash degrading status " << RED << distributed[inst].domain_hash_count << NOR << (char)ASCII_SL << URLDDX_SITE_HASH_SIZE << endl;
		else
			cerr << "- Domain hash degrading status " << GRE << distributed[inst].domain_hash_count << NOR << (char)ASCII_SL << URLDDX_SITE_HASH_SIZE << endl;

		doc_hash_t path_security_treshold = ((URLDDX_PATH_HASH_SIZE - CONF_COLLECTION_MAXDOC) / 10);

		if (distributed[inst].path_hash_count > (CONF_COLLECTION_MAXDOC - path_security_treshold))
			cerr << "- Path hash degrading status   " << RED << distributed[inst].path_hash_count << NOR << (char)ASCII_SL << URLDDX_PATH_HASH_SIZE << endl;
		else
			cerr << "- Path hash degrading status   " << GRE << distributed[inst].path_hash_count << NOR << (char)ASCII_SL << URLDDX_PATH_HASH_SIZE << endl;
	}

		cerr << BLU << "----------------------------------------------------------------" << NOR << endl;
		cerr << BLU << "  Important: Domain hash include also hashes of special domains." << NOR << endl;
}

//
// Name: check_sdomain
//
// Description:
//   Check if a special domain exists like 'domain.gov.it' exist
//
// Input:
//   urlddx - the url index structure
//   text - string with domainid and name of special domain to check
//   size - size of string to check
//   bucket - the bucket in which this was found
//
// Return
//   a siteid if resolved
//   0 if not found
//

siteid_t Url::check_sdomain(const char *input, size_t size, instance_t &binst, siteid_t &boffset, bool readonly) const
{
	assert(dirname);
	assert(input);
	assert(size > 0);

	// First attempt to find bucket (debug purpose)
	//siteid_t test = hashing_sdomain(input, size, binst);
	//cout << "DOMAIN " << &input[sizeof(siteid_t)] << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;

	// First attempt to find bucket
	// Note: if secure mode active bucket was not changed
	if (readonly == true)
		boffset = hashing_sdomain(input, size, binst);

	if (this->openmode == RW)
	{
		if (readonly == true)
			rdlock_b_domain(binst);
		else
			wrlock_b_domain(binst);
	}

	size_t sizeof_domainid = sizeof(siteid_t);

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while (distributed[binst].domain_hash[boffset].offset > 0)
	{
		char found[MAX_DOMAIN_LEN];

		errno = 0; // errno is thread-local

		// Read the position of this path in disk
		// Read from disk (dunno where the end is, so read a chunk)
		pread64(distributed[binst].sdomain_file, found, MAX_DOMAIN_LEN, distributed[binst].domain_hash[boffset].offset);

		if (errno != 0)
			die("Url resolve_domain: couldn't read to domain_file %s\n", cberr());

		// N.B. Entrambi gli url in 'pddx' e 'input' hanno come prefisso il loro siteid di provenienza
		const char *pddx = &(found[0]);
		const size_t ilen = strlen(input);

		// verifica se almeno la lunghezza dei due url "potrebbe" essere uguale
		if (strnlen(found, (ilen + 1)) == ilen)
		{
			unsigned char o = 0;

			// check the domainid of belonging
			for (; o < sizeof_domainid; o++)
				if (*(pddx++) != *(input++))
					break;

			// una volta che i siteid nei buffer sono stati scavalcati si inizia con il confronto passo-passo del termine originale con quello fornito come argomento
			if (o == sizeof_domainid)
			{
				// confronta passo-passo il termine originale con quello fornito come argomento
				while (*(pddx) != ASCII_NUL && *(input) != ASCII_NUL && *(pddx) == *(input) && *(pddx++) && *(input++));

				if (*pddx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
					return distributed[binst].domain_hash[boffset].domainid;
			}
		}

		boffset = ((boffset + 1) % URLDDX_SITE_HASH_SIZE);
	}

	return (siteid_t)0;
}

//
// Name: check_site
//
// Description:
//   Check if a sitename exists
//
// Input:
//   urlddx - the url index structure
//   site - the site name to check
//   bucket - the bucket in which this was found
//
// Return
//   a siteid if resolved
//   0 if not found
//

siteid_t Url::check_site(const char *input, instance_t &binst, siteid_t &boffset, bool readonly) const
{
	assert(dirname);
	assert(input);
	assert(strlen(input) > 0);

	// First attempt to find bucket (debug purpose)
	//siteid_t test = hashing_site(site);
	//cout << "DOMAIN " << site << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;

	// First attempt to find bucket
	boffset = hashing_site(input, binst);

	if (this->openmode == RW || this->openmode == RO)
	{
		if (this->openmode == RW)
		{
			if (readonly == true)
				rdlock_b_site(binst);
			else
				wrlock_b_site(binst);
		}

		// Linear probing
		// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
		while (distributed[binst].site_hash[boffset] > 0)
		{
			char found[URLDDX_SITE_LEN];

			errno = 0; // errno is thread-local

			// Read the position of this path in disk
			// Read from disk (dunno where the end is, so read a chunk)
			pread64(distributed[binst].site_file, found, URLDDX_SITE_LEN, distributed[binst].site_hash[boffset]);

			if (errno != 0)
				die("Url resolve_site: couldn't read to site_file %s\n", cberr());

			// N.B. Entrambi gli url in 'pddx' e 'input' hanno come prefisso il loro siteid di provenienza
			const char *pddx = &(found[0]);
			const size_t ilen = strlen(input);

			// verifica se almeno la lunghezza dei due url "potrebbe" essere uguale
			if (strnlen(found, (ilen + 1)) == ilen)
			{
				// confronta passo-passo il termine originale con quello fornito come argomento
				while (*(pddx) != ASCII_NUL && *(input) != ASCII_NUL && *(pddx) == *(input) && *(pddx++) && *(input++));

				if (*pddx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
					return *((siteid_t *)pddx); // restituisce l'id
			}

			boffset = ((boffset + 1) % URLDDX_SITE_HASH_SIZE);
		}

		return (siteid_t)0;
	}

	assert(this->openmode == RO_MEMORY);

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while (distributed[binst].site_hash[boffset] > 0)
	{
		char *pddx = distributed[binst].site + distributed[binst].site_hash[boffset]; // puntatore all'offset indicato dall'hash

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pddx) != ASCII_NUL && *(input) != ASCII_NUL && *(pddx) == *(input) && *(pddx++) && *(input++));

		if (*pddx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			return *((siteid_t *)pddx); // restituisce il siteid

		boffset = ((boffset + 1) % CONF_COLLECTION_MAXSITE);
	}

	return (siteid_t)0;
}

//
// Name: check_site
//
// Description:
//   Check if a sitename exists
//
// Input:
//   urlddx - the url index structure
//   site - the site name to check
//   bucket - the bucket in which this was found
//
// Return
//   a siteid if resolved
//   0 if not found
//

siteid_t Url::check_site(const char *input, size_t size, instance_t &binst, siteid_t &boffset, bool readonly) const
{
	assert(dirname);
	assert(input);
	assert(size > 0);

	// First attempt to find bucket (debug purpose)
	//siteid_t test = hashing_site(site);
	//cout << "DOMAIN " << site << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;

	// First attempt to find bucket
	boffset = hashing_site(input, size, binst);

	size_t sizeof_domainid = sizeof(siteid_t);

	if (this->openmode == RW || this->openmode == RO)
	{
		if (this->openmode == RW)
		{
			if (readonly == true)
				rdlock_b_site(binst);
			else
				wrlock_b_site(binst);
		}

		// Linear probing
		// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
		while (distributed[binst].site_hash[boffset] > 0)
		{
			char found[URLDDX_SITE_LEN];

			errno = 0; // errno is thread-local

			// Read the position of this path in disk
			// Read from disk (dunno where the end is, so read a chunk)
			pread64(distributed[binst].site_file, found, URLDDX_SITE_LEN, distributed[binst].site_hash[boffset]);

			if (errno != 0)
				die("Url resolve_site: couldn't read to site_file %s\n", cberr());

			// N.B. Entrambi gli url in 'pddx' e 'input' hanno come prefisso il loro siteid di provenienza
			const char *pddx = &(found[0]);
			const size_t ilen = strlen(input);

			// verifica se almeno la lunghezza dei due url "potrebbe" essere uguale
			if (strnlen(found, (ilen + 1)) == ilen)
			{
				unsigned char o = 0;

				// check the domainid of belonging
				for (; o < sizeof_domainid; o++)
					if (*(pddx++) != *(input++))
						break;

				// una volta che i siteid nei buffer sono stati scavalcati si inizia con il confronto passo-passo del termine originale con quello fornito come argomento
				if (o == sizeof_domainid)
				{
					// confronta passo-passo il termine originale con quello fornito come argomento
					while (*(pddx) != ASCII_NUL && *(input) != ASCII_NUL && *(pddx) == *(input) && *(pddx++) && *(input++));

					if (*pddx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
						return *((siteid_t *)pddx); // restituisce l'id
				}
			}

			boffset = ((boffset + 1) % URLDDX_SITE_HASH_SIZE);
		}

		return (siteid_t)0;
	}

	assert(this->openmode == RO_MEMORY);

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while (distributed[binst].site_hash[boffset] > 0)
	{
		char *pddx = distributed[binst].site + distributed[binst].site_hash[boffset]; // puntatore all'offset indicato dall'hash
		unsigned char o = 0;

		// check the domainid of belonging
		for (; o < sizeof_domainid; o++)
			if (*(pddx++) != *(input++))
				break;

		// una volta che i siteid nei buffer sono stati scavalcati si inizia con il confronto passo-passo del termine originale con quello fornito come argomento
		if (o == sizeof_domainid)
		{
			// confronta passo-passo il termine originale con quello fornito come argomento
			while (*(pddx) != ASCII_NUL && *(input) != ASCII_NUL && *(pddx) == *(input) && *(pddx++) && *(input++));

			if (*pddx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
				return *((siteid_t *)pddx); // restituisce il siteid
		}

		boffset = ((boffset + 1) % CONF_COLLECTION_MAXSITE);
	}

	return (siteid_t)0;
}

//
// Name: check_domain
//
// Description:
//   Check if a domain exists
//
// Input:
//   urlddx - the url index structure
//   domain - the domain name to check
//   boffset - the bucket offset in which this was found
//   readonly - true if readonly operation
//
// Return
//   a domainid if resolved
//   0 if not found
//

siteid_t Url::check_domain(const char *domain, instance_t &binst, siteid_t &boffset, bool readonly) const
{
	assert(dirname);
	assert(domain);
	assert(strlen(domain) > 0);

	// First attempt to find bucket (debug purpose)
	//siteid_t test = hashing_domain(domain);
	//cout << "DOMAIN " << domain << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;

	// First attempt to find bucket
	// Note: if secure mode active bucket was not changed
	if (readonly == true)
		boffset = hashing_site(domain, binst);

	if (this->openmode == RW)
	{
		if (readonly == true)
			rdlock_b_domain(binst);
		else
			wrlock_b_domain(binst);
	}

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while (distributed[binst].domain_hash[boffset].offset > 0)
	{
		char found[MAX_DOMAIN_LEN];

		errno = 0; // errno is thread-local

		// Read the position of this path in disk
		// Read from disk (dunno where the end is, so read a chunk)
		pread64(distributed[binst].domain_file, found, MAX_DOMAIN_LEN, distributed[binst].domain_hash[boffset].offset);

		if (errno != 0)
			die("Url resolve_domain: couldn't read to domain_file %s\n", cberr());

		// N.B. Entrambi gli url in 'pddx' e 'input' hanno come prefisso il loro siteid di provenienza
		const char *pddx = &(found[0]);
		const char *input = domain;
		const size_t ilen = strlen(input);

		// verifica se almeno la lunghezza dei due url "potrebbe" essere uguale
		if (strnlen(found, (ilen + 1)) == ilen)
		{
			// confronta passo-passo il termine originale con quello fornito come argomento
			while (*(pddx) != ASCII_NUL && *(input) != ASCII_NUL && *(pddx) == *(input) && *(pddx++) && *(input++));

			if (*pddx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
				return distributed[binst].domain_hash[boffset].domainid;
		//		return *((siteid_t *)pddx); // restituisce l'id
		}

		boffset = ((boffset + 1) % URLDDX_SITE_HASH_SIZE);
	}

	return (siteid_t)0;
}

/*
int compare_files(char *filename1, char *filename2) {
  FILE *fp1, *fp2;
  char ch1, ch2, same;
  unsigned long l;

  // open first file
  if ((fp1 = fopen(filename1, "rb"))==NULL) {
    return 0;
  }

  // open second file
  if ((fp2 = fopen(filename2, "rb"))==NULL) {
    return 0;
  }

  l = 0;
  same = 1;

  // compare the files
  while (!feof(fp1)) {
    ch1 = fgetc(fp1);
    if (ferror(fp1)) {
      return 0;
    }
    ch2 = fgetc(fp2);
    if (ferror(fp2)) {
      return 0;
    }
    if (ch1 != ch2) {
      same = 0;
      break;
    }
    l++;
  }


  if (fclose(fp1) == EOF) {
    cerr << "Error closing first file.\n" << endl;
  }

  if (fclose(fp2) == EOF) {
	cerr << "Error closing first file.\n" << endl;
  }

  return same;
}
*/


// 
// Name: resolve_www_prefix // TODO occorre verificare i codici di redirezione (es www.costadelsinis.it)
//
// Description: Indica se usare il sito originale o il suo alternativo (li distingue il prefisso 'www.')
// 		Nel caso occorra migrare dal protocollo http ad https se ne occuperà il ciclo di harvesting.
//
// Input: sito originale, sito alternativo (vuoto), protocollo
//
// Return: numero che indica se usare il sito originale o il suo alternativo creato all'interno
//
int Url::resolve_www_prefix(const char *original_site, char *alternative_site, protocols_t proto) const
{
	int result = 0;
	CURL *curl_original, *curl_alternative;
	CURLcode res_original, res_alternative;
	char errbuf_original[CURL_ERROR_SIZE];
	char errbuf_alternative[CURL_ERROR_SIZE];

//	char bodyfilename_original[MAX_STR_LEN];
//	sprintf(bodyfilename_original, "%s/%s",  CONF_COLLECTION_BASE, "body_original.out");
//	FILE *bodyfile_original;
//
//	char bodyfilename_alternative[MAX_STR_LEN];
//	sprintf(bodyfilename_alternative, "%s/%s",  CONF_COLLECTION_BASE, "body_alternative.out");
//	FILE *bodyfile_alternative;

	//make the url with the original sitename
	char url_original[MAX_STR_LEN];

	if (proto == HTTP)
		strcpy(url_original, "http://");
	if (proto == HTTPS)
		strcpy(url_original, "https://");

	strcat(url_original, original_site);
	strcat(url_original, "/");
	assert(strlen(url_original) < MAX_STR_LEN);
	// cerr << "url originale: " << url_original << endl;

	//make the url with sitename with www if there wasn't this prefix
	//or without www if the site already had this prefix
	char url_alternative[MAX_STR_LEN];
	if (strncasecmp(original_site, "www." , 4) != 0)
	{
		if (strnlen(alternative_site, (MAX_DOMAIN_LEN - 4)) == (MAX_DOMAIN_LEN - 4))
			return 0; // consider only original sitename because alternative sitename is too long
		
		strcpy(alternative_site, "www.");
		strcat(alternative_site, original_site);
	}
	else if (strlen(original_site) > 4 && strncasecmp(original_site, "www." , 4) == 0)
		strcpy(alternative_site, (original_site + 4));

	if (proto == HTTP)
		strcpy(url_alternative, "http://");
	if (proto == HTTPS)
		strcpy(url_alternative, "https://");

	strcat(url_alternative, alternative_site);
	strcat(url_alternative, "/");
	assert(strlen(url_alternative) < MAX_STR_LEN);
	//cerr << "url alternativa: " << url_alternative << endl;



	//initialization of the decision process
	curl_original = curl_easy_init();
	curl_alternative = curl_easy_init();

	if (curl_original && curl_alternative)
	{

		//tries to download bolth pages.
//		bodyfile_original = fopen(bodyfilename_original, "w");
//		if (bodyfile_original) {
//			curl_easy_setopt(curl_original, CURLOPT_WRITEDATA, bodyfile_original);
//		}
//

		if (proto == HTTPS)
		{
			curl_easy_setopt(curl_original, CURLOPT_SSL_VERIFYPEER , 1);
			curl_easy_setopt(curl_original, CURLOPT_SSL_VERIFYHOST , 0);
		}

		curl_easy_setopt(curl_original, CURLOPT_USERAGENT, "Mozilla/5.0");
		curl_easy_setopt(curl_original, CURLOPT_NOBODY, 1);
		curl_easy_setopt(curl_original, CURLOPT_FOLLOWLOCATION, 0);
		curl_easy_setopt(curl_original, CURLOPT_URL, url_original);
		curl_easy_setopt(curl_original, CURLOPT_TIMEOUT, 30 + CONF_HARVESTER_DNSTIMEOUT);
		curl_easy_setopt(curl_original, CURLOPT_CONNECTTIMEOUT, CONF_CONNECTION_TIMEOUT);
		curl_easy_setopt(curl_original, CURLOPT_ERRORBUFFER, errbuf_original);
		errbuf_original[0] = ASCII_NUL;
		res_original = curl_easy_perform(curl_original);

//		fclose(bodyfile_original);


//		bodyfile_alternative = fopen(bodyfilename_alternative, "w");
//		if (bodyfile_alternative) {
//			curl_easy_setopt(curl_alternative, CURLOPT_WRITEDATA, bodyfile_alternative);
//		}

		if (proto == HTTPS)
		{
			curl_easy_setopt(curl_alternative, CURLOPT_SSL_VERIFYPEER , 1);
			curl_easy_setopt(curl_alternative, CURLOPT_SSL_VERIFYHOST , 0);
		}

		curl_easy_setopt(curl_alternative, CURLOPT_USERAGENT, "Mozilla/5.0");
		curl_easy_setopt(curl_alternative, CURLOPT_NOBODY, 1);
		curl_easy_setopt(curl_alternative, CURLOPT_FOLLOWLOCATION, 0);
		curl_easy_setopt(curl_alternative, CURLOPT_URL, url_alternative);
		curl_easy_setopt(curl_alternative, CURLOPT_TIMEOUT, 30 + CONF_HARVESTER_DNSTIMEOUT);
		curl_easy_setopt(curl_alternative, CURLOPT_CONNECTTIMEOUT, CONF_CONNECTION_TIMEOUT);
		curl_easy_setopt(curl_alternative, CURLOPT_ERRORBUFFER, errbuf_alternative);
		errbuf_alternative[0] = ASCII_NUL;
		res_alternative = curl_easy_perform(curl_alternative);
//		fclose(bodyfile_alternative);

		if (res_original != CURLE_OK && res_alternative != CURLE_OK)
		{
			result = 0;

			size_t elen_orig = strlen(errbuf_original);
			size_t elen_alt = strlen(errbuf_alternative);

			if (elen_orig > 0 && elen_alt > 0)
			{
				mcerr << endl << url_original << " or his alternative name, can not be accessed,\n orig err code "
				<< errbuf_original << " (" << res_original << "), alternative err code "
				<< errbuf_alternative << " (" << res_alternative << ')' << mendl;
			}
			else if (elen_orig > 0)
			{
				mcerr << endl << url_original << " or his alternative name, can not be accessed,\n orig err code "
				<< errbuf_original << " (" << res_original << "), alternative err code "
				<< curl_easy_strerror(res_alternative) << " (" << res_alternative << ')' << mendl;
			}
			else if (elen_alt > 0)
			{
				mcerr << endl << url_original << " or his alternative name, can not be accessed,\n orig err code "
				<< curl_easy_strerror(res_original) << " (" << res_original << "), alternative err code "
				<< errbuf_alternative << " (" << res_alternative << ')' << mendl;
			}
			else
			{
				mcerr << endl << url_original << " or his alternative name, can not be accessed,\n orig err code "
				<< curl_easy_strerror(res_original) << " (" << res_original << "), alternative err code "
				<< curl_easy_strerror(res_alternative) << " (" << res_alternative << ')' << mendl;
			}
		}
		else
		{
			long http_status_original = 0l;

			if (res_original == CURLE_OK)
				curl_easy_getinfo(curl_original, CURLINFO_RESPONSE_CODE, &http_status_original);

			long http_status_alternative = 0l;

			if (res_alternative == CURLE_OK)
				curl_easy_getinfo(curl_alternative, CURLINFO_RESPONSE_CODE, &http_status_alternative);

			if (res_original != CURLE_OK && res_alternative == CURLE_OK)
			{
				if (http_status_alternative >= 300 && http_status_alternative < 400)
				{
					char *url_redirect = NULL;
					CURLcode ret = curl_easy_getinfo(curl_alternative, CURLINFO_REDIRECT_URL, &url_redirect);

					if (ret != CURLE_OK || url_redirect == NULL) 
						result = 1; // redirect interno (link locale (assunto arbitrariamente tale quando '(ret != CURLE_OK)'))
					else
					{
						char *purl_redirect = strstr(url_redirect, "://");
						purl_redirect = &(purl_redirect[3]); // protocollo escluso

						if (purl_redirect == NULL) 
							result = 1; // redirect interno (link locale (assunto arbitrariamente tale quando '(ret != CURLE_OK)'))
						else
						{
							if (strncasecmp(alternative_site, purl_redirect, strlen(alternative_site)) == 0)
								result = 1; // redirect interno
							else
							{
								if (strncasecmp(original_site, purl_redirect, strlen(original_site)) == 0) // il nome sito 'alternative' ha un
									result = 0; // redirect verso il nome 'original' che al momento del test poteva essere fuori servizio
								else
									result = 2; // il nome sito 'alternative' ha un redirect verso altri siti
							}
						}
					}
				}

				curl_easy_cleanup(curl_original);
				curl_easy_cleanup(curl_alternative);
				return 1; // il sito 'original' da errore e potrebbe funzionare solo il sito 'alternative' visto che almeno risponde
			}

			//if (res_alternative != CURLE_OK && res_original == CURLE_OK && (http_status_original < 200 || http_status_original >= 300))
			if (res_alternative != CURLE_OK && res_original == CURLE_OK)
			{
				if (http_status_original >= 300 && http_status_original < 400){
					char *url_redirect = NULL;
					CURLcode ret = curl_easy_getinfo(curl_original, CURLINFO_REDIRECT_URL, &url_redirect);

					if (ret != CURLE_OK || url_redirect == NULL) 
						result = 0; // redirect interno (link locale (assunto arbitrariamente tale quando '(ret != CURLE_OK)'))
					else
					{
						char *purl_redirect = strstr(url_redirect, "://");
						purl_redirect = &(purl_redirect[3]); // protocollo escluso

						if (purl_redirect == NULL) 
							result = 0; // redirect interno (link locale (assunto arbitrariamente tale quando '(ret != CURLE_OK)'))
						else
						{
							if (strncasecmp(original_site, purl_redirect, strlen(original_site)) == 0)
								result = 0; // redirect interno
							else
							{
								if (strncasecmp(alternative_site, purl_redirect, strlen(alternative_site)) == 0)// il nome sito 'original' ha
									result = 1; // un redirect verso il nome 'alternative' che al momento del test poteva essere fuori servizio
								else
									result = 2; // il nome sito 'original' ha un redirect verso altri siti
							}
						}
					}
				}
				curl_easy_cleanup(curl_original);
				curl_easy_cleanup(curl_alternative);
				return 0; // il sito 'alternative' da errore e potrebbe funzionare solo il sito 'original' visto che almeno risponde
			}

			if ((http_status_original >= 200 && http_status_original < 300) && (http_status_alternative < 200 || http_status_alternative >= 300)){
				if (http_status_alternative >= 300 && http_status_alternative < 400){
					char *url_redirect = NULL;
					CURLcode ret = curl_easy_getinfo(curl_alternative, CURLINFO_REDIRECT_URL, &url_redirect);

					if (ret != CURLE_OK || url_redirect == NULL) 
						result = 1; // redirect interno (link locale (assunto arbitrariamente tale quando '(ret != CURLE_OK)'))
					else
					{
						char *purl_redirect = strstr(url_redirect, "://");
						purl_redirect = &(purl_redirect[3]); // protocollo escluso

						if (purl_redirect == NULL) 
							result = 1; // redirect interno (link locale (assunto arbitrariamente tale quando '(ret != CURLE_OK)'))
						else
						{
							if (strncasecmp(alternative_site, purl_redirect, strlen(alternative_site)) == 0)
								result = 1; // redirect interno
							else
							{
								if (strncasecmp(original_site, purl_redirect, strlen(original_site)) == 0){
									result = 0; // il nome sito 'alternative' ha un redirect verso il nome 'original'
								}
								else
									result = 2; // il nome sito 'alternative' ha un redirect verso altri siti
							}
						}
					}
				}
				else
					result = 0; // funziona solo il sito 'original'
			}
			else 
			{
				if ((http_status_alternative >= 200 && http_status_alternative < 300) && (http_status_original < 200 || http_status_original >= 300))
				{
					if (http_status_original >= 300 && http_status_original < 400)
					{
						char *url_redirect = NULL;
						CURLcode ret = curl_easy_getinfo(curl_original, CURLINFO_REDIRECT_URL, &url_redirect);

						if (ret != CURLE_OK || url_redirect == NULL) 
							result = 0; // redirect interno (link locale (assunto arbitrariamente tale quando '(ret != CURLE_OK)'))
						else
						{
							char *purl_redirect = strstr(url_redirect, "://");
							purl_redirect = &(purl_redirect[3]); // protocollo escluso

							if (purl_redirect == NULL) 
								result = 0; // redirect interno (link locale (assunto arbitrariamente tale quando '(ret != CURLE_OK)'))
							else
							{
								if (strncasecmp(original_site, purl_redirect, strlen(original_site)) == 0)
									result = 0; // redirect interno
								else
								{
									if (strncasecmp(alternative_site, purl_redirect, strlen(alternative_site)) == 0){
										result = 1; // il nome sito 'original' ha un redirect verso il nome 'alternative'
									}
									else
										result = 2; // il nome sito 'original' ha un redirect verso altri siti
								}
							}
						}
					}
					else
						result = 1; // funziona solo il sito 'alternative'
				}
				else
				{
					if ((http_status_alternative < 200 || http_status_alternative >= 300) && (http_status_original < 200 || http_status_original >= 300))
					{
						if ((http_status_original >= 300 && http_status_original < 400) && (http_status_alternative >= 300 && http_status_alternative < 400))
						{ // gestisce migrazioni https
							char *ourl_redirect = NULL;
							CURLcode oret = curl_easy_getinfo(curl_original, CURLINFO_REDIRECT_URL, &ourl_redirect);

							char *aurl_redirect = NULL;
							CURLcode aret = curl_easy_getinfo(curl_alternative, CURLINFO_REDIRECT_URL, &aurl_redirect);

							if (oret == CURLE_OK && ourl_redirect)
							{
								char *pourl_redirect = NULL;

								pourl_redirect = strstr(ourl_redirect, "://");

								if (pourl_redirect == NULL)
									result = 0;
								else
								{
									pourl_redirect = &(pourl_redirect[3]); // protocollo escluso

									if (pourl_redirect && strncasecmp(original_site, pourl_redirect, strlen(original_site)) == 0)
										result = 0;
									else
										result = 2;
								}
							
							}

							if (result == 2 && aret == CURLE_OK && aurl_redirect)
							{
								char *paurl_redirect = NULL;

								paurl_redirect = strstr(aurl_redirect, "://");

								if (paurl_redirect == NULL)
									result = 1;
								else
								{
									paurl_redirect = &(paurl_redirect[3]); // protocollo escluso

									if (paurl_redirect && strncasecmp(alternative_site, paurl_redirect, strlen(alternative_site)) == 0)
										result = 1;
									else
										result = 2;
								}
							}
						}
						else
							result = 0;

//							cerr << "nessuno dei siti sembra funzionare" << endl;
					}
					else
					{
//						cerr << "entrambi sono funzionanti" << endl;

						result = 0;
						/*if (compare_files(bodyfilename_original, bodyfilename_alternative)){
							cerr << "são iguais" << endl;
							result = 0;
						}
						else {
							cerr << "são diferentes" << endl;
							result = 2;
						}
						*/

					}
				}
			}
		}
	}
	/* always cleanup */
	curl_easy_cleanup(curl_original);
	curl_easy_cleanup(curl_alternative);
	return result;
}

//
// Name: resolve_domain
//
// Description:
//   Verify a FQDN domain name and add it as second level domain name if necessary
//
// Input:
//   urlddx - the url index structure
//   domain - the FQDN to check
//
// Output:
//   domainid - domainid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   URLDDX_EXISTENT - the site existed
//   URLDDX_CREATED_DOMAIN - the second level domain was added
//   URLDDX_NOT_FOUND - the second level domain is not known and was not created
//

urlddx_status_t Url::resolve_domain(const char *fqdn, siteid_t *domainid, siteid_t *sdomainid, perfhash_t keep_special)
{
	assert(dirname);
	assert(fqdn);

	size_t fqdnlen = strnlen(fqdn, MAX_DOMAIN_LEN);

	assert(fqdnlen > 0 && fqdnlen < MAX_DOMAIN_LEN);

	instance_t binst;
	siteid_t boffset;
	siteid_t domainid_check;
	siteid_t sdomainid_check;

	char *domain = NULL;
	char *special_domain = NULL;

	// estraggo il dominio di secondo livello ed eventualmente il dominio speciale
	fqdn_to_domain(keep_special, (char *)fqdn, domain, special_domain);

	// Brackets needed
	{
		// Check if the standard domain exists
		domainid_check = check_domain(domain, binst, boffset, true);

		if (openmode == RW)
			unlock_b_domain(binst); // Unlocking unneeded mutex

		if (domainid_check > 0)
		{
			if (domainid)
				*domainid = domainid_check;

			free(domain);

			if (openmode == RO || openmode == RO_MEMORY)
				return URLDDX_EXISTENT;
			else if (special_domain)
				goto check_special_domain;
			else
				return URLDDX_EXISTENT;
		}

		if (openmode == RO || openmode == RO_MEMORY || domainid == NULL)
		{
			free(domain);

			if (special_domain)
				free(special_domain);

			return URLDDX_NOT_FOUND;
		}

		// The second level domain was not found and now must be saved

		// Check if the standard domain exists
		domainid_check = check_domain(domain, binst, boffset, false);

		// test domainid_check because in the same time another process can haved find site
		if (domainid_check > 0)
		{
			if (domainid)
				*domainid = domainid_check;

			// Unlocking unneeded mutex
			unlock_b_domain(binst);

			free(domain);

			if (openmode == RO || openmode == RO_MEMORY)
				return URLDDX_EXISTENT;
			else if (special_domain)
				goto check_special_domain;
			else
				return URLDDX_EXISTENT;
		}

		if (openmode == RO || openmode == RO_MEMORY || domainid == NULL)
		{
			// Unlocking unneeded mutex
			unlock_b_domain(binst);

			free(domain);

			if (special_domain)
				free(special_domain);

			return URLDDX_NOT_FOUND;
		}

		// Check if hash is full
		if ((distributed[binst].domain_hash_count + 1) > CONF_COLLECTION_MAXDOMAIN)
		{
			// Unlocking unneeded mutexes
			unlock_b_domain(binst);

			free(domain);

			if (special_domain)
				free(special_domain);

			*domainid = 0; // set to invalid

			die("Url resolve_domain: On Instance %lu Distributed Index of buckets is full. Increase CONF_COLLECTION_MAXDOMAIN!\n", (unsigned long int)binst);

			return URLDDX_HASH_FULL;
		}
		
		// Get domainid
		*domainid = ++domain_count;

		instance_t inst = ((*domainid - 1) % CONF_COLLECTION_DISTRIBUTED);

		// Locking needed mutex
		wrlock_a_domain(inst);

		// Check
		if ((distributed[inst].domain_count + 1) > CONF_COLLECTION_MAXDOMAIN)
		{
			// Unlocking unneeded mutexes
			unlock_a_domain(inst);
			unlock_b_domain(binst);

			free(domain);

			if (special_domain)
				free(special_domain);

			*domainid = 0; // set to invalid

			die("Url resolve_domain: On Instance %lu Distributed Index is small. Increase CONF_COLLECTION_MAXDOMAIN!\n", (unsigned long int)inst);

			return URLDDX_FULL;
		}

		siteid_t id_offset = distributed[inst].domain_count++;

		// Get the second level domain length to store
		size_t domainlen = strlen(domain);

		// Put next_char in offset element of domain_hash_t structure
		distributed[binst].domain_hash[boffset].offset = (distributed[binst].domain_next_char);

		// Store domainid in domainid element of domain_hash_t structure
		distributed[binst].domain_hash[boffset].domainid = *domainid;

		// Increase bucket counter
		distributed[binst].domain_hash_count++;
//
		// Put next_char at end of domain list
		distributed[inst].domain_list[id_offset] = distributed[binst].domain_next_char;

		// Save binst where find domain string by id
		distributed[inst].domain_bucket_instance[id_offset] = binst;

		// Unlocking unneeded mutex
		unlock_a_domain(inst);
//
		errno = 0; // errno is thread-local

		size_t size = size_t(domainlen + 1);

		// Store string
		ssize_t wr = pwrite64(distributed[binst].domain_file, domain, size, distributed[binst].domain_next_char);

		if (errno != 0)
			die("Url resolve_domain: On Instance %lu couldn't write to domain_file %s\n", (unsigned long int)binst, cberr());

		assert(wr == (ssize_t)size);

		// Move char pointer
		distributed[binst].domain_next_char = distributed[binst].domain_next_char + size;

		// Unlocking unneeded mutex
		unlock_b_domain(binst);

		free(domain);
	}

	check_special_domain:

	// Check if the special domain exists only for read-write or write operations
	if (special_domain && (openmode == WR || openmode == RW))
	{
		size_t special_domain_len = 0;

		// get size of third level domain
		while (special_domain[special_domain_len++] != ASCII_DT);
		special_domain_len--;

		// On disk, the path will be a bit larger
		char sdomain[URLDDX_SDOMAIN_LEN];

		int sizeof_domainid = (int)sizeof(siteid_t);
		memcpy(sdomain, domainid, sizeof_domainid);
		memcpy(sdomain + sizeof_domainid, special_domain, special_domain_len);
		sdomain[(sizeof_domainid + special_domain_len)] = ASCII_NUL;

		sdomainid_check = check_sdomain(sdomain, (sizeof_domainid + special_domain_len), binst, boffset, true);

		if (openmode == RW)
			unlock_b_domain(binst); // Unlocking unneeded mutex

		if (sdomainid_check > 0)
		{
			if (sdomainid)
				*sdomainid = sdomainid_check;

			free(special_domain);

			return URLDDX_EXISTENT;
		}

		if (openmode == RO || openmode == RO_MEMORY || sdomainid == NULL)
		{
			free(special_domain);

			return URLDDX_NOT_FOUND;
		}

		// The second level sdomain was not found and
		// now must be saved

		// Check if the standard sdomain exists
		sdomainid_check = check_sdomain(sdomain, (sizeof_domainid + special_domain_len), binst, boffset, false);

		// test sdomainid_check because in the same time another process can haved find site
		if (sdomainid_check > 0)
		{
			if (sdomainid)
				*sdomainid = sdomainid_check;

			// Unlocking unneeded mutex
			unlock_b_domain(binst);

			free(special_domain);

			return URLDDX_EXISTENT;
		}

		if (openmode == RO || openmode == RO_MEMORY || sdomainid == NULL)
		{
			// Unlocking unneeded mutex
			unlock_b_domain(binst);

			free(special_domain);

			return URLDDX_NOT_FOUND;
		}

		// Check if hash is full
		if ((distributed[binst].domain_hash_count + 1) > CONF_COLLECTION_MAXDOMAIN)
		{
			// Unlocking unneeded mutexes
			unlock_b_domain(binst);

			*sdomainid = 0; // set to invalid

			die("Url resolve_domain: On Instance %lu Distributed Index of buckets is full. Increase CONF_COLLECTION_MAXDOMAIN!\n", (unsigned long int)binst);

			return URLDDX_HASH_FULL;
		}
		
		// Get sdomainid
		*sdomainid = ++sdomain_count;

		instance_t inst = ((*sdomainid - 1) % CONF_COLLECTION_DISTRIBUTED);

		// Locking needed mutex
		wrlock_a_domain(inst);
/*
		// Check
		if ((distributed[inst].sdomain_count + 1) > CONF_COLLECTION_MAXDOMAIN)
		{
			// Unlocking unneeded mutexes
			unlock_a_domain(inst);
			unlock_b_domain(binst);

			*sdomainid = 0; // set to invalid

			die("Url resolve_domain: On Instance %lu Distributed Index is small. Increase CONF_COLLECTION_MAXDOMAIN!\n", (unsigned long int)inst);

			return URLDDX_FULL;
		}

		siteid_t id_offset = distributed[inst].sdomain_count++;
*/

		distributed[inst].sdomain_count++;

		// Unlocking unneeded mutex
		unlock_a_domain(inst);

		// Get the second level sdomain length to store
		size_t sdomainlen = strlen(special_domain);

		// Put next_char in offset element of domain_hash_t structure
		distributed[binst].domain_hash[boffset].offset = (distributed[binst].sdomain_next_char);

		// Store sdomainid in sdomainid element of domain_hash_t structure
		distributed[binst].domain_hash[boffset].domainid = *sdomainid;

		// Increase bucket counter
		distributed[binst].domain_hash_count++;
/*
		// Put next_char at end of sdomain list
		distributed[inst].sdomain_list[id_offset] = distributed[binst].sdomain_next_char;

		// Save binst where find sdomain string by id
		distributed[inst].sdomain_bucket_instance[id_offset] = binst;

		// Unlocking unneeded mutex
		unlock_a_domain(inst);
*/
		errno = 0; // errno is thread-local

		size_t size = size_t(sizeof_domainid + special_domain_len + 1);

		// Store string
		ssize_t wr = pwrite64(distributed[binst].sdomain_file, sdomain, size, distributed[binst].sdomain_next_char);

		if (errno != 0)
			die("Url resolve_domain: On Instance %lu couldn't write to sdomain_file %s\n", (unsigned long int)binst, cberr());

		assert(wr == (ssize_t)size);

		// Move char pointer
		distributed[binst].sdomain_next_char = distributed[binst].sdomain_next_char + size;

		// Unlocking unneeded mutex
		unlock_b_domain(binst);

		free(special_domain);
	}

	// Return
	return URLDDX_CREATED_DOMAIN;
}

//
// Name: resolve_site
//
// Description:
//   Verify a sitename and add if necessary - used only for seeder -
//
// Input:
//   urlddx - the url index structure
//   site - the site name to check
//   proto - if NEW site give right protocol for curl http request
//
// Output:
//   siteid - siteid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   URLDDX_EXISTENT - the site existed
//   URLDDX_CREATED_SITE - the site was added
//   URLDDX_NOT_FOUND - the site is not known and was not created
//
urlddx_status_t Url::resolve_site(const char *site, siteid_t domainid, siteid_t *siteid, protocols_t proto)
{
	assert(dirname);
	assert(site);
	assert(openmode == WR || openmode == RW);

	size_t sitelen = strnlen(site, MAX_DOMAIN_LEN);

	assert(sitelen > 0 && sitelen < MAX_DOMAIN_LEN);

	// On disk, the space will be a bit larger
	size_t csitelen = 0;
	char csite[URLDDX_SITE_LEN];
	char csite_alt[URLDDX_SITE_LEN];
	csite[0] = ASCII_NUL;
	csite_alt[0] = ASCII_NUL;

	int sizeof_domainid = (int)sizeof(siteid_t);
	memcpy(csite, &domainid, sizeof_domainid);
	memcpy(csite + sizeof_domainid, site, sitelen);
	csite[(sizeof_domainid + sitelen)] = ASCII_NUL;

	char *pch = NULL;
	pch = strrchr(&csite[sizeof_domainid], (int)ASCII_DT); // home.box.example.cxm -> home.box.example

	// Truncate the site for check and saving
	if (pch)
	{
		*pch = ASCII_NUL; // home.box.example.cxm -> home.box.example TLD skipped
		pch = NULL;

		pch = strrchr(&csite[sizeof_domainid], (int)ASCII_DT);

		if (pch)
			*pch = ASCII_NUL; // home.box.example.cxm -> home.box Second Level Domain skipped
		else
			die("Url resolve_site: Bad fqdn %s!\n", site);

		csitelen = strlen(&csite[sizeof_domainid]);
	}
	else
		die("Url resolve_site: Bad fqdn %s!\n", site);
		
	instance_t binst;
	siteid_t boffset; 
	siteid_t siteid_check;

	// Check if the site exists
	siteid_check = check_site(csite, (sizeof_domainid + csitelen), binst, boffset, true);

	if (openmode == RW)
		unlock_b_site(binst); // unlock mutex because we want that 'libcurl' must not use mutex

	if (siteid_check > 0)
	{
		if (siteid)
			*siteid = siteid_check;

		return URLDDX_EXISTENT;
	}

	if (openmode == RO || openmode == RO_MEMORY || siteid == NULL)
		return URLDDX_NOT_FOUND;

	///////
	
	char site_alt[MAX_DOMAIN_LEN];

	int result = resolve_www_prefix(site, site_alt, proto);

//	if (exist_alternative_url == true && result != 2){
//		return URLDDX_EXISTENT;
//	}

	///////

	if (result == 0 || result == 2)
	{
		siteid_t boffset_new;
		siteid_check = check_site(csite, (sizeof_domainid + csitelen), binst, boffset_new, true); // same sitename give always same 'bucket instance', no need lock other mutex...

		if (siteid_check > 0)
		{
			if (siteid)
				*siteid = siteid_check;

			unlock_b_site(binst);
			return URLDDX_EXISTENT;
		}

		boffset = boffset_new;
	}
	else if (result == 1)
	{
		sitelen = strnlen(site_alt, MAX_DOMAIN_LEN);

		assert(sitelen > 0 && sitelen < MAX_DOMAIN_LEN);

		csite[sizeof_domainid] = ASCII_NUL;
		memcpy(csite + sizeof_domainid, site_alt, sitelen);
		csite[(sizeof_domainid + sitelen)] = ASCII_NUL;

		char *pch = NULL;
		pch = strrchr(&csite[sizeof_domainid], (int)ASCII_DT); // home.box.example.cxm -> home.box.example

		// Truncate the site
		if (pch)
		{
			*pch = ASCII_NUL; // home.box.example.cxm -> home.box.example TLD skipped
			pch = NULL;

			pch = strrchr(&csite[sizeof_domainid], (int)ASCII_DT);

			if (pch)
				*pch = ASCII_NUL; // home.box.example.cxm -> home.box Second Level Domain skipped
		}

		csitelen = strlen(&csite[sizeof_domainid]);

		siteid_t boffset_new;
		siteid_check = check_site(csite, (sizeof_domainid + csitelen), binst, boffset_new, true);

		if (siteid_check > 0)
		{
			if (siteid)
				*siteid = siteid_check;

			unlock_b_site(binst);
			return URLDDX_EXISTENT;
		}

		boffset = boffset_new;
	}

	// Unlocking unneeded mutex
	unlock_b_site(binst);

	// Check if the site exists
	siteid_check = check_site(csite, (sizeof_domainid + csitelen), binst, boffset, false); // if bucket was changed but now continue in secure mode

	// test siteid_check because in the same time another process can haved find site
	if (siteid_check > 0)
	{
		if (siteid)
			*siteid = siteid_check;

		// Unlocking unneeded mutex
		unlock_b_site(binst);

		return URLDDX_EXISTENT;
	}

	if (openmode == RO || openmode == RO_MEMORY || siteid == NULL)
	{
		// Unlocking unneeded mutex
		unlock_b_site(binst);

		return URLDDX_NOT_FOUND;
	}

	// If I was not given a valid siteid space to return
	// a siteid, then the user don't want me to create
	// a new siteid slot for this site, so I just
	// return hash full.

	// Check if hash is full
	if	((distributed[binst].site_hash_count + 1) > CONF_COLLECTION_MAXSITE)
	{
		// Unlocking unneeded mutexes
		unlock_b_site(binst);

		*siteid = 0; // set to invalid

		die("Url resolve_site: On Instance %lu Distributed Index of buckets is full. Increase CONF_COLLECTION_MAXSITE!\n", (unsigned long int)binst);

		return URLDDX_HASH_FULL;
	}

	*siteid = ++site_count;

	instance_t inst = ((*siteid - 1) % CONF_COLLECTION_DISTRIBUTED);

	// Locking needed mutex
	wrlock_a_site(inst);

	// Check
	if ((distributed[inst].site_count + 1) > CONF_COLLECTION_MAXSITE)
	{
		// Unlocking unneeded mutexes
		unlock_a_site(inst);
		unlock_b_site(binst);

		*siteid = 0; // set to invalid
		mcerr << "On Instance " << inst << ": Distributed Index is small. Increase CONF_COLLECTION_MAXSITE!" << mendl;
		return URLDDX_ERROR;
	}

	siteid_t id_offset = distributed[inst].site_count++;

	// Put next_char in hash offset
	distributed[binst].site_hash[boffset] = (distributed[binst].site_next_char);

	// Increase bucket counter
	distributed[binst].site_hash_count++;

	// Put next_char at end of site list
	distributed[inst].site_list[id_offset] = distributed[binst].site_next_char;
		
	// Save binst where find site word by id
	distributed[inst].site_bucket_instance[id_offset] = binst;

	// Unlocking unneeded mutex
	unlock_a_site(inst);

	size_t size = size_t(sizeof_domainid + csitelen + 1);

	errno = 0; // errno is thread-local

	// Store string
	size_t wr = pwrite64(distributed[binst].site_file, csite, size, distributed[binst].site_next_char);

	if (errno != 0)
		die("Url resolve_site: On Instance %lu couldn't write to site_file %s\n", (unsigned long int)binst, cberr());

	assert(wr == (ssize_t)size);

	// Move char pointer
	distributed[binst].site_next_char = (distributed[binst].site_next_char + size);

	// Unlocking unneeded mutex
	unlock_b_site(binst);

	// Return
	return URLDDX_CREATED_SITE;
}

//
// Name: resolve_site
//
// Description:
//   Verify a sitename and add if necessary
//
// Input:
//   urlddx - the url index structure
//   site - the site name to check
//   proto - if NEW site give right protocol for curl http request
//
// Output:
//   siteid - siteid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   URLDDX_EXISTENT - the site existed
//   URLDDX_CREATED_SITE - the site was added
//   URLDDX_NOT_FOUND - the site is not known and was not created
//
urlddx_status_t Url::resolve_site(const char *site, siteid_t *siteid, protocols_t proto)
{
	assert(dirname);
	assert(site);

	size_t sitelen = strnlen(site, MAX_DOMAIN_LEN);

	assert(sitelen > 0 && sitelen < MAX_DOMAIN_LEN);

	instance_t binst;
	siteid_t boffset; 
	siteid_t siteid_check;

	// Check if the site exists
	siteid_check = check_site(site, binst, boffset, true);

	if (openmode == RW)
		unlock_b_site(binst); // unlock mutex because we want that 'libcurl' must not use mutex

	if (siteid_check > 0)
	{
		if (siteid)
			*siteid = siteid_check;

		return URLDDX_EXISTENT;
	}

	if (openmode == RO || openmode == RO_MEMORY || siteid == NULL)
		return URLDDX_NOT_FOUND;

	///////
	
	char site_alt[MAX_DOMAIN_LEN];

	int result = resolve_www_prefix(site, site_alt, proto);

//	if (exist_alternative_url == true && result != 2){
//		return URLDDX_EXISTENT;
//	}

	///////

	if (result == 0 || result == 2)
	{
		siteid_t boffset_new;
		siteid_check = check_site(site, binst, boffset_new, true); // same sitename give always same 'bucket instance', no need lock other mutex...

		if (siteid_check > 0)
		{
			if (siteid)
				*siteid = siteid_check;

			unlock_b_site(binst);
			return URLDDX_EXISTENT;
		}

		boffset = boffset_new;
	}
	else if (result == 1)
	{
		siteid_t boffset_new;
		siteid_check = check_site(site_alt, binst, boffset_new, true);

		if (siteid_check > 0)
		{
			if (siteid)
				*siteid = siteid_check;

			unlock_b_site(binst);
			return URLDDX_EXISTENT;
		}

		boffset = boffset_new;
	}

	// Unlocking unneeded mutex
	unlock_b_site(binst);

	// Check if the site exists
	if (result == 1)
		siteid_check = check_site(site_alt, binst, boffset, false); // if bucket was changed but now continue in secure mode
	else
		siteid_check = check_site(site, binst, boffset, false); // if bucket was changed but now continue in secure mode

	// test siteid_check because in the same time another process can haved find site
	if (siteid_check > 0)
	{
		if (siteid)
			*siteid = siteid_check;

		// Unlocking unneeded mutex
		unlock_b_site(binst);

		return URLDDX_EXISTENT;
	}

	if (openmode == RO || openmode == RO_MEMORY || siteid == NULL)
	{
		// Unlocking unneeded mutex
		unlock_b_site(binst);

		return URLDDX_NOT_FOUND;
	}

	// If I was not given a valid siteid space to return
	// a siteid, then the user don't want me to create
	// a new siteid slot for this site, so I just
	// return hash full.

	// Check if hash is full
	if	((distributed[binst].site_hash_count + 1) > CONF_COLLECTION_MAXSITE)
	{
		// Unlocking unneeded mutexes
		unlock_b_site(binst);

		*siteid = 0; // set to invalid

		die("Url resolve_site: On Instance %lu Distributed Index of buckets is full. Increase CONF_COLLECTION_MAXSITE!\n", (unsigned long int)binst);

		return URLDDX_HASH_FULL;
	}

	*siteid = ++site_count;

	instance_t inst = ((*siteid - 1) % CONF_COLLECTION_DISTRIBUTED);

	// Locking needed mutex
	wrlock_a_site(inst);

	// Check
	if ((distributed[inst].site_count + 1) > CONF_COLLECTION_MAXSITE)
	{
		// Unlocking unneeded mutexes
		unlock_a_site(inst);
		unlock_b_site(binst);

		*siteid = 0; // set to invalid
		mcerr << "On Instance " << inst << ": Distributed Index is small. Increase CONF_COLLECTION_MAXSITE!" << mendl;
		return URLDDX_ERROR;
	}

	siteid_t id_offset = distributed[inst].site_count++;

	sitelen = 0;

	if (result == 1)
		sitelen = strlen(site_alt);
	else
		sitelen = strlen(site);

	// Put next_char in hash offset
	distributed[binst].site_hash[boffset] = (distributed[binst].site_next_char);

	// Increase bucket counter
	distributed[binst].site_hash_count++;

	// Put next_char at end of site list
	distributed[inst].site_list[id_offset] = distributed[binst].site_next_char;
		
	// Save binst where find site word by id
	distributed[inst].site_bucket_instance[id_offset] = binst;

	// Unlocking unneeded mutex
	unlock_a_site(inst);

	char urlddx_data[URLDDX_SITE_LEN];

	// Store string
	if (result == 1)
		memcpy(&urlddx_data, site_alt, sitelen + 1);
	else
		memcpy(&urlddx_data, site, sitelen + 1);

	// Store siteid
	memcpy(&urlddx_data[(sitelen + 1)], siteid, sizeof(siteid_t));

	// Get total size to save to disk
	size_t size = (size_t)(sitelen + 1 + sizeof(siteid_t));

	errno = 0; // errno is thread-local

	// Store string
	ssize_t wr = pwrite64(distributed[binst].site_file, urlddx_data, size, distributed[binst].site_next_char);

	if (errno != 0)
		die("Url resolve_site: On Instance %lu couldn't write to site_file %s\n", (unsigned long int)binst, cberr());


	assert(wr == (ssize_t)size);

	// Move char pointer
	distributed[binst].site_next_char = (distributed[binst].site_next_char + size);

	// Unlocking unneeded mutex
	unlock_b_site(binst);

	// Return
	return URLDDX_CREATED_SITE;
}

// 
// Name: resolve_path
//
// Description:
//   Check if path is saved for a siteid, and store it if not
//
// Input:
//   urlddx - the url index structure
//   siteid - the siteid in which this path was found
//   path - the path; it MUST NOT begin with a ASCII_SL
//
// Output:
//   docid - the corresponding document id
//
//
// Return:
//   URLDDX_EXISTENT - the path existed in that site
//   URLDDX_CREATED_PATH - the path was added
//

urlddx_status_t Url::resolve_path(siteid_t siteid, const char *inpath, docid_t *docid)
{
	assert(dirname);
	// Check the path
	assert(inpath && inpath[0] != ASCII_SL);
	assert(!strchr(inpath,'\r'));
	assert(!strchr(inpath,'\n'));

	// On disk, the path will be a bit larger
	char path[URLDDX_PATH_LEN];

	// Copy inpath to path. Append the siteid at the start.
	bool bsa = false;
	size_t inpath_len = strlen(inpath);
	int sizeof_siteid_t = (int)sizeof(siteid_t);
	int pathlen = sizeof_siteid_t + inpath_len;
	memcpy(path, &siteid, sizeof_siteid_t);
	memcpy(path + sizeof_siteid_t, inpath, strlen(inpath) + 1);

	// Try to find it in the hash table
	instance_t binst = 0;

	docid_t pos = hashing_path(path, pathlen, binst);

	if (openmode == RW)
		rdlock_b_path(binst); // Locking needed mutex in read only mode to start

	retry:

	// Linear probing
	while (distributed[binst].path_hash[pos] > 0)
	{
		char found[URLDDX_PATH_LEN];

		errno = 0; // errno is thread-local
	   
		// Read the position of this path in disk
		// Read from disk (dunno where the end is, so read a chunk)
		pread64(distributed[binst].path_file, found, URLDDX_PATH_LEN, distributed[binst].path_hash[pos]);

		if (errno != 0) 	
        	die("Url resolve_path: couldn't read to path_file %s\n", cberr());

		// N.B. Entrambi gli url in 'pddx' e 'input' hanno come prefisso il loro siteid di provenienza
		const char *pddx = &(found[0]);
		const char *input = path;
		const size_t ilen = strlen(input);

		// verifica se almeno la lunghezza dei due url "potrebbe" essere uguale 
		if (strnlen(found, (ilen + 1)) == ilen)
		{
			unsigned char o = 0;

			// verifica che i due path appartengano allo stesso sito attraverso la comparazione del prefisso (siteid)
			for (; o < sizeof_siteid_t; o++)
				if (*(pddx++) != *(input++))
					break;

			// una volta che i siteid nei buffer sono stati scavalcati si inizia con il confronto passo-passo del termine originale con quello fornito come argomento
			if (o == sizeof_siteid_t)
			{
				while (*(pddx) != ASCII_NUL && *(input) != ASCII_NUL && *(pddx) == *(input) && *(pddx++) && *(input++));

				if (*pddx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
				{
					// If it's, save the docid
					*docid = *((docid_t *)pddx);

					if (openmode == RW)
						unlock_b_path(binst, false); // Unlocking unneeded mutex

					// Return
					return URLDDX_EXISTENT;
				}
			}
		}

		pos = ((pos + 1) % URLDDX_PATH_HASH_SIZE);
	}

	if (openmode == RO || openmode == RO_MEMORY)
		return URLDDX_NOT_FOUND;

	// It's a new element, insert in single mode (write mode)
	if (bsa == false)
	{
		bsa = true;
		unlock_b_path(binst, false);
		wrlock_b_path(binst); // We need to change lock type of rwlockb mutex
		goto retry;
	}

	// Check if hash is full
	if	((distributed[binst].path_hash_count + 1) > CONF_COLLECTION_MAXDOC)
	{
		// Unlocking unneeded mutexes
		unlock_b_path(binst, false);

		*docid = 0; // set to invalid

		die("Url resolve_path: On Instance %lu Distributed Index of buckets is full. Increase CONF_COLLECTION_MAXDOC!\n", (unsigned long int)binst);

		return URLDDX_HASH_FULL;
	}

	// Get docid. Note that this structure has its own
	// count of object, and this could be inconsistent with
	// the metaddx if something nasty happens with it.

	// The idea with the metaddx is that whenever it's asked
	// to store a docid, if this docid is larger than its current
	// number of documents, it increases its number of documents

	*docid = ++path_count;

	instance_t inst = ((*docid - 1) % CONF_COLLECTION_DISTRIBUTED);

	// Locking needed mutex
	wrlock_a_path(inst);

	// Check
	if ((distributed[inst].path_count + 1) > CONF_COLLECTION_MAXDOC)
	{
		unlock_a_path(inst);
		unlock_b_path(binst, false);

		*docid = 0; // set to invalid

		die("Url resolve_path: On Instance %lu Distributed Index is small. Increase CONF_COLLECTION_MAXDOC!\n", (unsigned long int)inst);

		return URLDDX_FULL;
	}

	docid_t id_offset = distributed[inst].path_count++;

	// Put next_char in hash offset
	distributed[binst].path_hash[pos] = (distributed[binst].path_next_char);

	// Increase bucket counter
	distributed[binst].path_hash_count++;

	// Put next_char at end of path list
	distributed[inst].path_list[id_offset] = distributed[binst].path_next_char;

	// Save binst where find path string by id
	distributed[inst].path_bucket_instance[id_offset] = binst;

	// Save true if is homepage
	if (inpath_len == 0)
		setbit_true(inst, id_offset);

	// Unlocking unneeded mutex
	unlock_a_path(inst);

	// Append to path for store also the docid at the end
	memcpy(path + (pathlen + 1), docid, sizeof(docid_t));

	// Get total size to save to disk
	size_t size = (size_t)(pathlen + 1 + sizeof(docid_t));

	errno = 0; // errno is thread-local

	// Store string
	ssize_t wr = pwrite64(distributed[binst].path_file, path, size, distributed[binst].path_next_char);

	if (errno != 0)
		die("Url resolve_path: On Instance %lu couldn't write to path_file %s\n", (unsigned long int)binst, cberr());

	assert(wr == (ssize_t)size);

	// Move char pointer
	distributed[binst].path_next_char = (distributed[binst].path_next_char + size);

	// Unlocking unneeded mutex
	unlock_b_path(binst, false);

	// Return
	return URLDDX_CREATED_PATH;
}


//
// Name: contains_path
//
// Description:
//   Only check if path is saved for a siteid
//
// Input:
//   urlddx - the url index structure
//   siteid - the siteid in which this path was found
//   path - the path; it MUST NOT begin with a ASCII_SL
//
// Output:
//   docid - the corresponding document id
//
//
// Return:
//   URLDDX_EXISTENT - the path existed in that site
//   URLDDX_NOT_FOUND - the path was not found
//

urlddx_status_t Url::contains_path(siteid_t siteid, const char *inpath, docid_t *docid) const
{
	assert(dirname);
	// Check the path
	assert(inpath[0] != ASCII_SL);
	assert(!strchr(inpath,'\r'));
	assert(!strchr(inpath,'\n'));

	// On disk, the path will be a bit larger
	char path[URLDDX_PATH_LEN];

	// Copy inpath to path. Append the siteid at the start.
	int sizeof_siteid_t = (int)sizeof(siteid_t);
	int pathlen = sizeof_siteid_t + strlen(inpath);
	memcpy(path, &siteid, sizeof_siteid_t);
	memcpy(path + sizeof_siteid_t, inpath, strlen(inpath) + 1);

	// Try to find it in the hash table
	instance_t binst = 0;

	docid_t pos = hashing_path(path, pathlen, binst);

	if (openmode == RW)
		rdlock_b_path(binst); // Locking needed mutex

	// Linear probing
	while (distributed[binst].path_hash[pos] > 0)
	{
		char found[URLDDX_PATH_LEN];

		errno = 0; // errno is thread-local
	   
		// Read the position of this path in disk
		// Read from disk (dunno where the end is, so read a chunk)
		pread64(distributed[binst].path_file, found, URLDDX_PATH_LEN, distributed[binst].path_hash[pos]);

		if (errno != 0) 	
        	die("Url contains_path: couldn't read path_file %s\n", cberr());

		// N.B. Entrambi gli url in 'pddx' e 'input' hanno come prefisso il loro siteid di provenienza
		const char *pddx = &(found[0]);
		const char *input = path;

		// verifica se almeno la lunghezza dei due url "potrebbe" essere uguale 
		if (found[pathlen] == ASCII_NUL)
		{
			unsigned char o = 0;

			// verifica che i due path appartengano allo stesso sito attraverso la comparazione del prefisso (siteid)
			for (; o < sizeof_siteid_t; o++)
				if (*(pddx++) != *(input++))
					break;

			// una volta che i siteid nei buffer sono stati scavalcati si inizia con il confronto passo-passo del termine originale con quello fornito come argomento
			if (o == sizeof_siteid_t)
			{
				while (*(pddx) != ASCII_NUL && *(input) != ASCII_NUL && *(pddx) == *(input) && *(pddx++) && *(input++));

				if (*pddx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
				{
					// If it's, save the docid
					*docid = *((docid_t *)pddx);

					if (openmode == RW)
						unlock_b_path(binst, false); // Unlocking unneeded mutex

					// Return
					return URLDDX_EXISTENT;
				}
			}
		}

		pos = ((pos + 1) % URLDDX_PATH_HASH_SIZE);
	}

	if (openmode == RW)
		unlock_b_path(binst, false); // Unlocking unneeded mutex

	return URLDDX_NOT_FOUND;
}

//
// Name: resolve_url
//
// Description:
//   Gets the docid for a "sitename/path" string
//
// Input:
//   urlddx - url index structure
//   url - string, in the form "sitename/path"
//
// Output:
//   siteid - siteid for sitename
//   docid - docid for path
//
// Return:
//   URLDDX_CREATED_SITE - created site and path entry
//   URLDDX_CREATED_PATH - site existed, created path
//   URLDDX_OK - everything is ok
//

urlddx_status_t Url::resolve_url(char *url, siteid_t *siteid, docid_t *docid, protocols_t proto)
{
	assert(dirname);
	char site[MAX_STR_LEN];
	char path[MAX_STR_LEN];

	// Copy the site name
	int i = 0;
	for (i = 0; url[i] != ASCII_SL && url[i] != ASCII_NUL; i++) site[i] = url[i];

	site[i] = ASCII_NUL;

	// Check if no ASCII_SL
	assert(url[i] != ASCII_NUL);

	// Skip the ASCII_SL
	i++;

	// Copy the path
	int j = 0;

	while (url[i] != ASCII_NUL)
	{
		path[j++] = url[i];
		i++;
	}

	path[j] = ASCII_NUL;

	// Resolve
	if	(resolve_site(site, siteid, proto) == URLDDX_CREATED_SITE)
	{
		resolve_path(*siteid, path, docid);

		return URLDDX_CREATED_SITE;
	}
	
	return resolve_path(*siteid, path, docid);
}

/* 
	urlddx_site_by_siteid
	Get the name of a site based on its id
	TODO: This function must fail in an error condition.
*/

void Url::site_by_siteid(siteid_t siteid, char *sitename) const
{
	assert(dirname);
	assert(openmode == RW || openmode == RO || openmode == RO_MEMORY);

	instance_t inst = ((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t id_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

	if (openmode == RW)
		rdlock_a_site(inst); // Locking needed mutex

	instance_t binst = distributed[inst].site_bucket_instance[id_offset]; 

	// Read offset
	off64_t char_offset = distributed[inst].site_list[id_offset];

	if (openmode == RW || openmode == RO)
	{
		if (openmode == RW)
			unlock_a_site(inst); // Unlocking unneeded mutex

		errno = 0; // errno is thread-local

		// Read the path
		char site[MAX_DOMAIN_LEN];

		pread64(distributed[binst].site_file, site, MAX_DOMAIN_LEN, char_offset);

		if (errno != 0) 	
    	   	die("Url site_by_siteid: couldn't read site_file %s\n", cberr());

		// Copy
		assert(strlen(site) < MAX_DOMAIN_LEN);
		strcpy(sitename, site);
	}
	else if (openmode == RO_MEMORY)
	{	// Copy
		assert(strlen((distributed[binst].site) + char_offset) <= MAX_DOMAIN_LEN);
		strcpy(sitename, (distributed[binst].site) + char_offset);
	}
}

/*
	url_by_docid(docid, url)
	Returns the url of a docid in "url" in the form "site/path".
	This is important! because we don't need to locate the
    siteid in the metaddx to retrieve it. the siteid is stored
    here also.
*/

void Url::url_by_docid(docid_t docid, char *url)
{
	assert(dirname);

	instance_t inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = ((docid - 1) / CONF_COLLECTION_DISTRIBUTED); 

	if (openmode == RW)
		rdlock_a_path(inst); // Locking needed mutex

	instance_t binst = distributed[inst].path_bucket_instance[id_offset]; 

	// Read offset
	off64_t char_offset = distributed[inst].path_list[id_offset];

	if (openmode == RW)
		unlock_a_path(inst); // Unlocking unneeded mutex

	errno = 0; // errno is thread-local

	// Read the path
	char path[URLDDX_PATH_LEN];

	pread64(distributed[binst].path_file, path, (MAX_STR_LEN + 1 + sizeof(docid_t)), char_offset);

	if (errno != 0) 	
       	die("Url url_by_docid: couldn't read path_file %s\n", cberr());

	// Get the siteid and skip it
	siteid_t siteid = 0;
	memcpy(&(siteid), &(path), sizeof(siteid));

	// Get the Site Name
	site_by_siteid(siteid, url);

	// Append a slash
	strcat(url, "/");

	// Append the path
	strcat(url, (path + sizeof(siteid_t)));
}

//
// Name: siteid_by_docid
//
// Description:
//   Returns the stored siteid for a document
//
// Input:
//   urlddx - the structure
//   docid - the document id
//
// Returns:
//   the siteid of the docid
//

siteid_t Url::siteid_by_docid(docid_t docid) const
{
	assert(dirname);

	instance_t inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = ((docid - 1) / CONF_COLLECTION_DISTRIBUTED);

	if (openmode == RW)
		rdlock_a_path(inst); // Locking needed mutex

	instance_t binst = distributed[inst].path_bucket_instance[id_offset]; 

	// Read offset
	off64_t char_offset = distributed[inst].path_list[id_offset];

	if (openmode == RW)
		unlock_a_path(inst); // Unlocking unneeded mutex

	errno = 0; // errno is thread-local

	// Read the path
	char path[URLDDX_PATH_LEN];

	pread64(distributed[binst].path_file, path, (MAX_STR_LEN + 1 + sizeof(docid_t)), char_offset);

	if (errno != 0) 	
       	die("Url siteid_by_docid: couldn't read path_file %s\n", cberr());

	// Get the siteid
	siteid_t siteid = 0;
	memcpy(&(siteid), &(path), sizeof(siteid));

	return siteid;
}

//
// urlddx_path_by_docid
// Returns the path of a URL
//
void Url::path_by_docid(docid_t docid, char *_path) const
{
	assert(dirname);

	instance_t inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = ((docid - 1) / CONF_COLLECTION_DISTRIBUTED); 

	if (openmode == RW)
		rdlock_a_path(inst); // Locking needed mutex

	instance_t binst = distributed[inst].path_bucket_instance[id_offset]; 

	// Read offset
	off64_t char_offset = distributed[inst].path_list[id_offset];

	if (openmode == RW)
		unlock_a_path(inst); // Unlocking needed mutex

	errno = 0; // errno is thread-local

	// Read the path
	char path[(URLDDX_PATH_LEN - sizeof(docid_t))];

	pread64(distributed[binst].path_file, path, (URLDDX_PATH_LEN - sizeof(docid_t)), char_offset);

	if (errno != 0) 	
       	die("Url path_by_docid: couldn't read path_file %s\n", cberr());

	// Return
	assert(strlen(path + sizeof(siteid_t)) <= MAX_STR_LEN);
	strcpy(_path, (path + sizeof(siteid_t))); // save skipping the siteid
}

//
// Name: site_count
//
// Description: Get number of sites in urlddx
//   
// Input:
//
// Return: Number of sites in urlddx
//

siteid_t Url::sitecount (void) const
{
	return site_count;
}

//
// Name: domain_count
//
// Description: Get number of second level domains in urlddx
//   
// Input:
//
// Return: Number of domains in urlddx
//

siteid_t Url::domaincount (void) const
{
	return domain_count;
}


//
// Name: path_count
//
// Description: Get number of paths in urlddx
//   
// Input:
//
// Return: Number of paths in urlddx
//

siteid_t Url::pathcount (void) const
{
	return path_count;
}

//
// Name: setbit_true
//
// Description: Work on unsigned byte char element as buffer of bits and set single bit to 'true'
//   
// Input:
//   urlddx - the structure
//   inst - binst where find id_offset
//   id_offset - offset where set bit 'true'
//
// Return:
//

void Url::setbit_true (instance_t &inst, docid_t &id_offset)
{
	size_t byte_offset = id_offset / BYTE_BIT;
	size_t bit_offset = id_offset % BYTE_BIT;

	// bitwise operation 
	distributed[inst].path_homepage[byte_offset] = distributed[inst].path_homepage[byte_offset] | (uint8_t)exp2((double)(bit_offset));
}

//
// Name: setbit_false
//
// Description: Work on unsigned byte char element as buffer of bits and set single bit to 'false'
//   
// Input:
//   urlddx - the structure
//   inst - binst where find id_offset
//   id_offset - offset where set bit 'false'
//
// Return:
//

void Url::setbit_false (instance_t &inst, docid_t &id_offset)
{
	size_t byte_offset = id_offset / BYTE_BIT;
	size_t bit_offset = id_offset % BYTE_BIT;

	// bitwise operation 
	distributed[inst].path_homepage[byte_offset] = distributed[inst].path_homepage[byte_offset] & ((uint8_t)~0 - (uint8_t)exp2((double)(bit_offset)));
}

//
// Name: getbit_value
//
// Description: Work on unsigned byte char element as buffer of bits and get single bit value
// Note: the function return always false if docid is invalid
//   
// Input:
//   urlddx - the structure
//   inst - binst where find id_offset
//   id_offset - offset where get bit value
//
// Return: true or false
//

bool Url::getbit_value (instance_t &inst, docid_t &id_offset) const
{
	size_t byte_offset = id_offset / BYTE_BIT;
	size_t bit_offset = id_offset % BYTE_BIT;

	// bitwise operation 
	if (bit_offset == 0)
		return ((distributed[inst].path_homepage[byte_offset] & (1 << bit_offset)));
	else if (bit_offset == 1)
		return ((distributed[inst].path_homepage[byte_offset] & (1 << bit_offset)) / 2);
	else
		return ((distributed[inst].path_homepage[byte_offset] & (1 << bit_offset)) / exp2 (bit_offset));
}

//
// Name: is_homepage
//
// Description: Used to quickly check if a url points to a home page
// Note: the function return always false if docid is invalid
//
// Input:
//   urlddx - the structure
//   docid - docid to check
//
// Return:
//   1 if path = ''
//   0 if not

bool Url::is_homepage(docid_t &docid) const
{
	assert(dirname);

	if (docid > path_count)
		return false;

	instance_t inst = ((docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = ((docid - 1) / CONF_COLLECTION_DISTRIBUTED); 

	return getbit_value(inst, id_offset);
}

// Hashing Functions for paths names
docid_t Url::hashing_sdomain(const char *text, size_t size, instance_t &binst) const
{
	doc_hash_t hash_value;
	int count = 0;

	for (hash_value = 0; count++ <= size; text++)
		hash_value = ((131 * (hash_value == 0 ? 1 : hash_value) + *text) % CONF_HASH_DOMAIN_MAX_DEFINITIVE);

	// now that we have a definitive bucket and find bucket instance
	binst = (hash_value % CONF_COLLECTION_DISTRIBUTED);

	// return natural offset (inside appropriate bucket instance) where bucket should be placed
	return ((hash_value / CONF_COLLECTION_DISTRIBUTED) % URLDDX_DOMAIN_HASH_SIZE);
}

// Hashing Functions for paths names
docid_t Url::hashing_site(const char *text, size_t size, instance_t &binst) const
{
	doc_hash_t hash_value;
	int count = 0;

	for (hash_value = 0; count++ <= size; text++)
		hash_value = ((131 * (hash_value == 0 ? 1 : hash_value) + *text) % CONF_HASH_SITE_MAX_DEFINITIVE);

	// now that we have a definitive bucket and find bucket instance
	binst = (hash_value % CONF_COLLECTION_DISTRIBUTED);

	// return natural offset (inside appropriate bucket instance) where bucket should be placed
	return ((hash_value / CONF_COLLECTION_DISTRIBUTED) % URLDDX_SITE_HASH_SIZE);
}

// Hashing Functions for sitenames or domain names
siteid_t Url::hashing_site(const char *text, instance_t &binst) const
{
	site_hash_t hash_value;

	for (hash_value=0; *text; text++)
		hash_value = ((131 * (hash_value == 0 ? 1 : hash_value) + *text) % CONF_HASH_SITE_MAX_DEFINITIVE);

	// now that we have a definitive bucket and find bucket instance
	binst = (hash_value % CONF_COLLECTION_DISTRIBUTED);

	// return natural offset (inside appropriate bucket instance) where bucket should be placed
	return ((hash_value / CONF_COLLECTION_DISTRIBUTED) % URLDDX_SITE_HASH_SIZE);
}

// Hashing Functions for paths names
docid_t Url::hashing_path(const char *text, int &size, instance_t &binst) const
{
	doc_hash_t hash_value;
	int count = 0;

	for (hash_value = 0; count++ <= size; text++)
		hash_value = ((131 * (hash_value == 0 ? 1 : hash_value) + *text) % CONF_HASH_DOC_MAX_DEFINITIVE);

	// now that we have a definitive bucket and find bucket instance
	binst = (hash_value % CONF_COLLECTION_DISTRIBUTED);

	// return natural offset (inside appropriate bucket instance) where bucket should be placed
	return ((hash_value / CONF_COLLECTION_DISTRIBUTED) % URLDDX_PATH_HASH_SIZE);
}

//
// Name: canonicalize_path
//
// Description:
//   Put a path in canonical form; eliminate all '/./'
//   and go up in the path if a '/../' is found.
//   Result doesn't have leading '/', BUT represents an absolute path
//
// Input:
//   source - Original path
//
// Output:
//   dest - Result path
//

void Url::canonicalize_path(char *source, char *dest) const
{
	// Iterate for each component of the path
	char component[MAX_STR_LEN];
	uint slash_count = 0;
	uint slash_position[MAX_STR_LEN];
	uint outpos 	= 0;
	uint comppos 	= 0;
	uint inpos		= 0;

	// Check special case
	if (source == NULL)
	{
		dest = NULL;
		return;
	}

	// Copy source

	// Test memory
	for (uint i = 0; i<MAX_STR_LEN; i++)
	{
		dest[i] = ASCII_NUL;
		component[i] = ASCII_NUL;
		slash_position[i] = 0;
	}


	for (inpos = 0; inpos <= strlen(source); inpos++)
	{
		if (source[inpos] == ASCII_SL || source[inpos] == ASCII_NUL)
		{	// Close the component
			component[comppos] = ASCII_NUL;

			// Check for '..'
			if (component[0] == ASCII_DT &&
				component[1] == ASCII_DT &&
				component[2] == ASCII_NUL)
			{
				if (slash_count == 0); // Ignore, this path begins with '..'
				else outpos = slash_position[--slash_count];

				comppos = 0;

			} // Check for ASCII_DT
			else if (component[0] == ASCII_DT && component[1] == ASCII_NUL) // Ignore
				comppos = 0;
			else // It's something else, copy
			{
				slash_position[slash_count++] = outpos;

				if (outpos != 0)
					dest[outpos++] = ASCII_SL;

				for (uint i = 0; i < strlen(component); i++)
					if (outpos < MAX_STR_LEN-1)
						dest[outpos++] = component[i];

				comppos = 0;
			}

		}
		else if (comppos < MAX_STR_LEN-1)
			component[comppos++] = source[inpos];
	}

	// Write the final ASCII_NUL
	dest[outpos] = ASCII_NUL;

	// Return
	return;
}


//
// Name: is_dynamic
//
// Description:
//   Checks if a url is dynamic; checks for cgi parameter separator ('?')
//   Then for extensions, then for cgi- (cgi-bin, cgi-local).
//
// Input:
//   extensions_dynamic - hash table with the known dynamic extensions
//   url - the url
// 
// Return:
//   true iff the url is looks like a dynamic one
//

bool Url::is_dynamic(perfhash_t *extensions_dynamic, char *url) const
{
	assert(extensions_dynamic);
	assert(url);

	// Check for '?' in the url
	if (strchr(url, ASCII_QM))
		return true;

	// Check for ';' in the url
	if (strchr(url, ASCII_SC))
		return true;

	// Check for known dynamic extensions
	char lowercase_extension[MAX_STR_LEN];
	get_lowercase_extension(url, lowercase_extension);

	if (strlen(lowercase_extension) > 0)
	{	// Search
		if (perfhash_check(extensions_dynamic, lowercase_extension))
			return true;
	}

	// Heuristic: check for known directories
	if (strstr(url, "cgi-bin") || strstr(url, "cgi-local"))
		return true;

	// It looks like a static url

	return false;
}

//
// Name: parse_complete_url
//
// Description:
//   Splits an url in its parts.
//
// Input:
//   original_url - The original url to be converted
//
// Output:
//   dest_protocol - The parsed protocol
//   dest_sitename - The parsed site name
//   dest_path     - The parsed path
//
// Return:
//   true - Everything is ok
//   false - original_url was malformed
//

bool Url::parse_complete_url(char *url, char *protocol, char *sitename, char *path) const
{
	int src_pos = 0;
	int dest_pos = 0;

	// Check if url is empty
	if (url[0] == ASCII_NUL)
		return false;

	// Copy protocol
	while (url[src_pos] != ASCII_CO && url[src_pos] != ASCII_NUL)
		protocol[dest_pos++] = url[src_pos++];

	// End protocol string
	protocol[dest_pos] = ASCII_NUL;

	// Check if there is something more besides the protocol
	if (url[src_pos] == ASCII_NUL) 
		return false;

	// Move two chars right, checking that they are slashes
	src_pos++;

	if (url[src_pos] != ASCII_SL || url[src_pos] == ASCII_NUL)
		return false;

	src_pos++;
	if (url[src_pos] != ASCII_SL || url[src_pos] == ASCII_NUL)
		return false;

	// Copy the sitename
	dest_pos = 0;
	src_pos++;

	while (url[src_pos] != ASCII_SL && url[src_pos] != ASCII_NUL)
	{	// fqdn length must respect RFC 1035
		if (dest_pos >= (MAX_DOMAIN_LEN - 1))
			return false;

		sitename[dest_pos++] = url[src_pos++];
	}
	
	// End sitename string
	sitename[dest_pos] = ASCII_NUL;

	// Check if the path is empty

	if (url[src_pos] == ASCII_NUL)
	{
		path[0] = ASCII_NUL;
		return true;
	}

	// Move past the slash
	src_pos++;

	// Path begins with double slash, malformed
	if (url[src_pos] == ASCII_SL)
		return false;

	// Copy the path
	dest_pos = 0;

	while (url[src_pos] != ASCII_NUL)
	{	// path too long
		if (dest_pos >= (MAX_STR_LEN - 1))
			return false;

		path[dest_pos++] = url[src_pos++];
	}

	// End path string
	path[dest_pos] = ASCII_NUL;

	return true;
}

//
// Name: relative_path_to_absolute
//
// Description:
//   Converts a path to absolute
//
// Input:
//   src_path - source path
//   url - destination of the link
//
// Output:
//   path - the resulting path
//

void Url::relative_path_to_absolute(char *src_path, char *url, char *path) const
{
	char complete_path[MAX_STR_LEN];
	uint outpos = 0;

	// If given an absolute path, return immediatly
	if (url[0] == ASCII_SL)
	{
		assert(strlen(url) < MAX_STR_LEN);
		strcpy(path, url);
		return;
	}

	// We have to avoid appending double '?'
	bool seen_question_mark = false;

	// Copy the source url, up to the last slash
	int last_slash = 0;

	for (outpos = 0; outpos < strlen(src_path); outpos++)
	{
		if (src_path[outpos] == ASCII_QM)
		{	// We try to avoid double question marks
			if (seen_question_mark)
				break;
			else
				seen_question_mark = true;
		}
		else if (src_path[outpos] == ASCII_NU) // We don't want to copy hash urls
			break;
		else if (src_path[outpos] == ASCII_SL && !seen_question_mark)
			last_slash = outpos;

		// Copy
		complete_path[outpos] = src_path[outpos];
	}

	outpos = last_slash;
	complete_path[outpos++] = ASCII_SL;
	seen_question_mark = false;
	// Append the given URL
	uint j=0;

	while (j < strlen(url))
	{
		if (url[j] == ASCII_QM)
		{
			if (seen_question_mark)
				break;
			else
				seen_question_mark = true;
		}

		if (outpos < (MAX_STR_LEN - 1))
			complete_path[outpos++] = url[j];

		j++;
	}

	complete_path[outpos] = ASCII_NUL;

	// Canonicalize
	canonicalize_path(complete_path, path);
}

//
// Name: remove_variable
//
// Description:
//   Removes a variable from an URL, useful for deleting
//   session-ids in URLs. Variables can be CGI variables,
//   or portions of the URL separated by ';', e.g.:
//    a/b.cgi?c=1&d=2&PHPSESSID=000000  -> a/b.cgi?c=1&d=2&
//    a/b.html;jsessionid=000000        -> a/b.html
//  
//  Input:
//    url - the original url
//    varname - the variable name
//
//  Output:
//    url - the corrected url
//

#define isalnum_or_underscore(x) (isalnum(x) || x == ASCII_US)

void Url::remove_variable(char *url, const char *varname) const
{
	assert(url);
	assert(varname);

	int varlen	= strlen(varname);
	assert(varlen > 0);

	// Easy test
	if (! strstr(url, varname))
		return;

	// Deleting is very difficult and slow, as a lot
	// of patterns can occur, including the variable
	// at the beginning, end, middle of the CGI portion,
	// or even before, separated by a ';', so we
	// take the easy path.

	// Try to find this pattern in the URL
	char *start_ptr 	= NULL;
	char *end_ptr		= NULL;

	while ((start_ptr = strstr(url, varname)))
	{

		// Check if we are at the beginning of the URL, in this
		// case, we can't be matching OK
		end_ptr	= start_ptr + varlen;

		// Move the start a bit to catch the var as a suffix
		while (start_ptr > url && isalnum_or_underscore(*(start_ptr - 1)))
			start_ptr --;

		if ((*end_ptr) == ASCII_EQ)
		{
			end_ptr++;

			// Now we have the character that start the value
			// of this var, we have to search for the end of it.
			while ((*end_ptr) != ASCII_NUL && isalnum_or_underscore((*end_ptr)))
				end_ptr++;

			// Check if we are also at the end of the string
			while ((*end_ptr) != ASCII_NUL)
				(*(start_ptr++)) = (*(end_ptr++));

			(*start_ptr) = ASCII_NUL;
		}
		// Advance the url
		url ++;
	}

}


//
// Name: remove_sessionids_heuristic
//
// Description:
//   Heuristic to detect other common sessionids in the url
//  

void Url::remove_sessionids_heuristic(char *path) const 
{
	assert(path);

	// Remove s=XXXX..... from .php files (this is an heuristic,
	// because many php files use 's=XXXX....' as a sessionid, so
	// I will be careful and only remove this at the beginning
	if (char *position = strstr(path, "php?s="))
	{	// Check if we have at least 4 hex digit in the variable value
		if (strlen(position) > 12 &&
			isxdigit(position[6]) && isxdigit(position[7]) &&
			isxdigit(position[8]) && isxdigit(position[9]) &&
			isxdigit(position[10]) && isxdigit(position[11]))
			remove_variable(path, "s");
	}

	if (char *position = strstr(path, "sid="))
	{	// Check if we have at least 6 hex digit in the variable value
		if (strlen(position) > 12 &&
			isxdigit(position[4]) && isxdigit(position[5]) &&
			isxdigit(position[6]) && isxdigit(position[7]) &&
			isxdigit(position[8]) && isxdigit(position[9]) &&
			isxdigit(position[10]) && isxdigit(position[11]))
			remove_variable(path, "sid");
	}
}


//
// Name: sanitize_url
//
// Description:
//   Performs a series of replacement in the URL
//

void Url::sanitize_url(char *url) const 
{

	// Replace all '&amp;' by '&'
	replace_all(url, "&amp;", "&");

	// Replace '&&' by '&'
	replace_all(url, "&&", "&");

	// Fix the url, e.g.: a.html;sessid=x?b=1 -> a.html;?b=1 -> a.html?b=1
	// Replace ';?' by '?'
	replace_all(url, ";?", "?");

	// Replace '?&' by '?'
	replace_all(url, "?&", "?");

	// Replace double slash
	replace_all(url, "//", "/");

	size_t ulen = strlen(url);

	// Fix the url, remove trailing ';', '&', ' ' or '?'
	while (ulen > 0 && (url[ulen-1] == ASCII_SC || url[ulen-1] == ASCII_AM || url[ulen-1] == ASCII_SP || url[ulen-1] == ASCII_QM))
	{
		url[ulen-1] = ASCII_NUL;
		ulen = strlen(url);
	}

	// Elimina i pezzi di url anomali, es: ';aaaakl?jjjjdddd?' diventa '?'
	for (size_t i = 0; i < ulen; i++)
	{
	
		if (url[i] == ASCII_SC || url[i] == ASCII_QM)
		{
	
			bool equal_exist = false;
			size_t c = i;
	
			while (url[c] == ASCII_SC || url[c] == ASCII_QM) c++;
	
			size_t replace_pos = (c - 1);
	
			while (url[c] != ASCII_SC && url[c] != ASCII_QM && url[c] != ASCII_NUL)
			{
				if (url[c] == ASCII_EQ)
					equal_exist = true;
	
				c++;
			}
	
			if (equal_exist == false)
			{
				size_t diff_size = (c - replace_pos); 
	
				for (size_t s = replace_pos; url[c] != ASCII_NUL; s++)
				{
					url[s] = url[c];
					c++;
				}
	
				ulen -= diff_size;
				url[ulen] = ASCII_NUL;
				i--;
			}
		}
	}
}

//
// Name: get_lowercase_extension
//
// Description:
//   Gets the lowercased extension of a string, e.g.:
//    example.html?x=1  -> html
//    www.example.CoM   -> com
//
// Input:
//   examined - the string to be examined
//
// Output:
//   extension - the resulting extension, the user must request memory
//               for this
//

void Url::get_lowercase_extension(char *examined, char *extension) const
{
	// Make sure we will return something in the extension
	extension[0] = ASCII_NUL;

	// Go to the end of the string
	int inpos	= strlen(examined) - 1;

	// If the string is empty, or ends in a dot
	if (inpos == -1 || examined[inpos] == ASCII_DT) // There is no extension
		return;

	// Go backwards until a dot is found
	inpos--;
	while (inpos > 0)
	{
		if (examined[inpos] == ASCII_DT)
		{	// We have located the last dot, move one char to the right
			inpos++;

			// Copy, until non-alphanumeric characters appear or we
			// reach the end of the string
			int	outpos	= 0;

			while (examined[inpos] != ASCII_NUL
				&& isalnum_or_underscore(examined[inpos]) 
				&& outpos < (MAX_STR_LEN - 1))
				extension[outpos++]	= tolower(examined[inpos++]);

			// Put a null at the end
			extension[outpos] = ASCII_NUL;

			return;
		}

		inpos--;
	}

	// We didn't find a dot
	return;
}

// Functions to lock/unlock mutexes
/*
void Url::lock_a_site(instance_t &inst)
{
	int rc = 0;

	if (slock && slock->locka)
		if ((rc = pthread_mutex_lock(&(slock->locka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Url::lock_b_site(instance_t &binst)
{
	int rc = 0;

	if (slock && slock->lockb)
		if ((rc = pthread_mutex_lock(&(slock->lockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Url::lock_c_site(instance_t &inst)
{
	int rc = 0;

	if (slock && slock->lockc)
		if ((rc = pthread_mutex_lock(&(slock->lockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Url::lock_a_domain(instance_t &inst)
{
	int rc = 0;

	if (dlock && dlock->locka)
		if ((rc = pthread_mutex_lock(&(dlock->locka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Url::lock_b_domain(instance_t &binst)
{
	int rc = 0;

	if (dlock && dlock->lockb)
		if ((rc = pthread_mutex_lock(&(dlock->lockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Url::lock_c_domain(instance_t &inst)
{
	int rc = 0;

	if (dlock && dlock->lockc)
		if ((rc = pthread_mutex_lock(&(dlock->lockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Url::lock_a_path(instance_t &inst)
{
	int rc = 0;

	if (plock && plock->locka)
		if ((rc = pthread_mutex_lock(&(plock->locka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
*/
void Url::lock_b_path(instance_t &binst) const
{
	int rc = 0;

	if (plock && plock->lockb)
		if ((rc = pthread_mutex_lock(&(plock->lockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
/*
void Url::lock_c_path(instance_t &inst) const
{
	int rc = 0;

	if (plock && plock->lockc)
		if ((rc = pthread_mutex_lock(&(plock->lockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
*/
	
void Url::wrlock_a_site(instance_t &inst) const
{
	int rc = 0;

	if (slock && slock->rwlocka)
		if ((rc = pthread_rwlock_wrlock(&(slock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::wrlock_b_site(instance_t &binst) const
{
	int rc = 0;

	if (slock && slock->rwlockb)
		if ((rc = pthread_rwlock_wrlock(&(slock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::wrlock_c_site(instance_t &inst) const
{
	int rc = 0;

	if (slock && slock->rwlockc)
		if ((rc = pthread_rwlock_wrlock(&(slock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::wrlock_a_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock && dlock->rwlocka)
		if ((rc = pthread_rwlock_wrlock(&(dlock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::wrlock_b_domain(instance_t &binst) const
{
	int rc = 0;

	if (dlock && dlock->rwlockb)
		if ((rc = pthread_rwlock_wrlock(&(dlock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::wrlock_c_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock && dlock->rwlockc)
		if ((rc = pthread_rwlock_wrlock(&(dlock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::wrlock_a_path(instance_t &inst) const
{
	int rc = 0;

	if (plock && plock->rwlocka)
		if ((rc = pthread_rwlock_wrlock(&(plock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::wrlock_b_path(instance_t &binst) const
{
	int rc = 0;

	if (plock && plock->rwlockb)
		if ((rc = pthread_rwlock_wrlock(&(plock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::wrlock_c_path(instance_t &inst) const
{
	int rc = 0;

	if (plock && plock->rwlockc)
		if ((rc = pthread_rwlock_wrlock(&(plock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Url::rdlock_a_site(instance_t &inst) const
{
	int rc = 0;

	if (slock && slock->rwlocka)
		if ((rc = pthread_rwlock_rdlock(&(slock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::rdlock_b_site(instance_t &binst) const
{
	int rc = 0;

	if (slock && slock->rwlockb)
		if ((rc = pthread_rwlock_rdlock(&(slock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::rdlock_c_site(instance_t &inst) const
{
	int rc = 0;

	if (slock && slock->rwlockc)
		if ((rc = pthread_rwlock_rdlock(&(slock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::rdlock_a_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock && dlock->rwlocka)
		if ((rc = pthread_rwlock_rdlock(&(dlock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::rdlock_b_domain(instance_t &binst) const
{
	int rc = 0;

	if (dlock && dlock->rwlockb)
		if ((rc = pthread_rwlock_rdlock(&(dlock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::rdlock_c_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock && dlock->rwlockc)
		if ((rc = pthread_rwlock_rdlock(&(dlock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::rdlock_a_path(instance_t &inst) const
{
	int rc = 0;

	if (plock && plock->rwlocka)
		if ((rc = pthread_rwlock_rdlock(&(plock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::rdlock_b_path(instance_t &binst) const
{
	int rc = 0;

	if (plock && plock->rwlockb)
		if ((rc = pthread_rwlock_rdlock(&(plock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::rdlock_c_path(instance_t &inst) const
{
	int rc = 0;

	if (plock && plock->rwlockc)
		if ((rc = pthread_rwlock_rdlock(&(plock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Url::unlock_a_site(instance_t &inst) const
{
	int rc = 0;

	if (slock && slock->rwlocka)
		if ((rc = pthread_rwlock_unlock(&(slock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}

void Url::unlock_b_site(instance_t &binst) const
{
	int rc = 0;

	if (slock && slock->rwlockb)
		if ((rc = pthread_rwlock_unlock(&(slock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Url::unlock_c_site(instance_t &inst) const
{
	int rc = 0;

	if (slock && slock->rwlockc)
		if ((rc = pthread_rwlock_unlock(&(slock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Url::unlock_a_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock && dlock->rwlocka)
		if ((rc = pthread_rwlock_unlock(&(dlock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::unlock_b_domain(instance_t &binst) const
{
	int rc = 0;

	if (dlock && dlock->rwlockb)
		if ((rc = pthread_rwlock_unlock(&(dlock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Url::unlock_c_domain(instance_t &inst) const
{
	int rc = 0;

	if (dlock && dlock->rwlockc)
		if ((rc = pthread_rwlock_unlock(&(dlock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Url::unlock_a_path(instance_t &inst) const
{
	int rc = 0;

	if (plock && plock->rwlocka)
		if ((rc = pthread_rwlock_unlock(&(plock->rwlocka[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
	
void Url::unlock_b_path(instance_t &binst, bool is_mutual_exclusion_mutex) const
{
	int rc = 0;

	if (is_mutual_exclusion_mutex == true)
	{
		if (plock && plock->lockb)
		if ((rc = pthread_mutex_unlock(&(plock->lockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
	}
	else if (plock && plock->rwlockb)
		if ((rc = pthread_rwlock_unlock(&(plock->rwlockb[binst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
                                            
void Url::unlock_c_path(instance_t &inst) const
{
	int rc = 0;

	if (plock && plock->rwlockc)
		if ((rc = pthread_rwlock_unlock(&(plock->rwlockc[inst]))) != 0)
			die("error locking mutex %s", CBoterr(rc));
}
