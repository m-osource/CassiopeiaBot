/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _CONNDDX_H_INCLUDED_
#define _CONNDDX_H_INCLUDED_

#include <config.h>

// System libraries

#include <features.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <iostream>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/stat.h>

#include <atomic>
#include <math.h>
#include <errno.h>
#include <queue>
#include <string>
#include <map>

using namespace std;

// Local libraries

#include "const.h"
//#include "http_codes.h"
#include "xmlconf.h"
#include "die.h"
//#include "utils.h"
#include "Meta.h"
//#include "http_charset.h"

// File names

#define CONNDDX_FILENAME_NVC	"connddx.nvc"
#define INSTANCE_MAXDOC (CONF_COLLECTION_MAXDOC / CONF_COLLECTION_DISTRIBUTED + 1)

// Meta index status

enum connddx_status_t {
	CONNDDX_OK         = 0,
	CONNDDX_ERROR,
	CONNDDX_EOF
};

// Type for a metaindex
// The nvc count is stored in nvc[0].nvcid

typedef struct {
	int file_nvc; // fd
	char dirname[MAX_STR_LEN];
	docid_t count_nvc;
	// bool readonly;
} cddx_t;

typedef struct {
	cddx_t *distributed;
	std::atomic<docid_t> count_nvc; // Counter reliable only in readonly mode true (share data)
	bool readonly;
} connddx_t;

typedef struct {
	docid_t		docid;
	siterank_t	siterank;
	pagerank_t	pagerank;
	wlrank_t	wlrank;
	liverank_t	liverank;
	priority_t	cscore;
	priority_t	uscore;
	unsigned int	number_visits_changed;
	int		http_status;
} nvc_t;

// need to passing arguments to threads functions
typedef struct {
    unsigned int i;
    connddx_t *n;
    char *d;
} connddx_thread_function_args_t;

// Functions

// Open connddx
connddx_t *connddx_open( const char *dirname, bool readonly );

// Function required by connddx_open (pthread use)
void *connddx_thread_function_open(void *args);

// Close connddx
connddx_status_t connddx_close( connddx_t *m );

// Function required by connddx_close (pthread use)
void *connddx_thread_function_close(void *args);
void *connddx_thread_function_ronly_close(void *args);

// Remove connddx
void connddx_remove( const char *dirname );

// Function required by connddx_remove (pthread use)
void *connddx_thread_function_remove(void *args);

// Blank records
void connddx_nvc_default( nvc_t *nvc );

// Retrieve and store
connddx_status_t connddx_nvc_retrieve( connddx_t *m, nvc_t *nvc );
connddx_status_t connddx_nvc_store( connddx_t *m, nvc_t *nvc );

// Dump

void connddx_dump_nvc_status( nvc_t *nvc );
void connddx_dump_nvc_short_status( nvc_t *nvc );
void connddx_dump_status( connddx_t *connddx );

void connddx_dump_nvc_header( FILE *out );
void connddx_dump_nvc( nvc_t *nvc, FILE *out );

#endif
