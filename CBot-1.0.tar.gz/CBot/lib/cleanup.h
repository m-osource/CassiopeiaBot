/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _CLEANUP_H_INCLUDED_
#define _CLEANUP_H_INCLUDED_

#include <config.h>

// System libraries

#include <stdlib.h>
#include <signal.h>
#include <assert.h>
#include <string.h>
#include <syslog.h>
#include <stdio.h>
#include <stdarg.h>
#include <limits.h>
#include <unistd.h>
#include <fcntl.h>

using namespace std;

// Local libraries
#include "const.h"
#include "die.h"

// Preprocessor macros
#ifdef DEBUG
#define CBALLOC(type, am, size) CBotAllocator<type>(am, size, (const char *)__FILE__, __LINE__)
#define CBREALLOC(type, type2, oldbuf, oldsize, newsize, delta) CBotReAllocator<type, type2>(oldbuf, oldsize, newsize, delta, (const char *)__FILE__, __LINE__)
#else
#define CBALLOC(type, am, size) CBotAllocator<type>(am, size)
#define CBREALLOC(type, type2, oldbuf, oldsize, newsize, delta) CBotReAllocator<type, type2>(oldbuf, oldsize, newsize, delta)
#endif

#define TALARM if (thread_alarm != THREADS_OK) cbot_stop(1)

// Globals
extern struct sigaction action;
extern bool *symshown;
extern pthread_mutex_t *console_lock;
extern atomic<thread_alarm_t> thread_alarm;


// External functions

extern void cleanup();

// Classes

// Functions
void cleanup_enable();
void cleanup_disable();

void CBotjoin( pthread_t *, instance_t );

// Low level
void enable_signal_handler( void (*sighandler)(int));
void disable_signal_handler();
void signal_handler( int signum );

enum am_t { // alloc method enum
	NEW		= 0,
	MALLOC	= 1,
	CALLOC	= 2
};

#ifdef DEBUG

//
// Name: CBotAllocator
//
// Description:
//   Invoked by 'preprocessor macro' 'CBalloc'
//   Alloc memory at pointer declared inside of function
//   N.B. i template se compilati attraverso moduli devono SEMPRE essere presenti nel file header
//
// Input:
//   method - enum 'am_t' allocation method
//   size - size of memory area
//   file - filename where function is called
//   line - line in the filename where function is called
//
// Return:
//   T *pointer 
//
template <typename T> T *CBotAllocator (const am_t &method, const int &size, const char *file, const int &line)
{
	if (size <= 0)
		CBotdie(__DATE__, __TIME__, file, line, "CBALLOC: size %d of memory allocation is invalid!", size);

	T *allocated = NULL;

	bool bad_alloc_method = false;

try
{
	switch (method)
	{
		case(NEW):
			allocated = new T [size];
			break;
		case(MALLOC):
			allocated = (T *) malloc (size * sizeof(T));
			break;
		case(CALLOC):
			allocated = (T *) calloc (size, sizeof(T));
			break;
		default:
			bad_alloc_method = true;
			break;
	}
}
catch (std::bad_alloc &ba)
{
	CBotdie(__DATE__, __TIME__, file, line, "CBALLOC: bad_alloc caught %s!", ba.what());
}

	if (bad_alloc_method == true)
		CBotdie(__DATE__, __TIME__, file, line, "CBALLOC: unsupported memory allocation method!");

	if (allocated == NULL)
		CBotdie(__DATE__, __TIME__, file, line, "CBALLOC: allocation failed!");

	return allocated;
}

//
// Name: CBotReAllocator
//
// Description:
//   Invoked by 'preprocessor macro' 'CBalloc'
//   Realloc memory for required new size
//
// Input:
//   oldbuf - the buffer to increase size
//   oldsize - the size of oldbuf
//   newsize - the needed size
//   delta - the delta size used to increase size
//   file - filename where function is called
//   line - line in the filename where function is called
//
// Output:
//   size set to new size
//
// Return:
//   T *pointer to rellocated buffer
//
template <typename T, typename P> T *CBotReAllocator (T *oldbuf, P &size, const ssize_t &required_size, const size_t &delta, const char *file, const int &line)
{
	if (oldbuf == NULL)
		CBotdie(__DATE__, __TIME__, file, line, "CBREALLOC: memory (re)allocation is required for NULL pointer file %s and line %d!", file, line);

	T *newbuf = NULL;
	P newsize = size;

	unsigned short err_count = 0;
	const unsigned short max_realloc = 5;
	bool undefined_retries = false;

try
{
	if (required_size > size)
	{
		// Inizio processo assegnazione memoria al puntatore 'base' ...
		while (newsize < required_size) newsize += delta;

		do
		{
			err_count++;
			newbuf = (T*) realloc (oldbuf, (newsize * sizeof(T)));

			if (newbuf == NULL && err_count > max_realloc)
				undefined_retries = true;
		}
		while (newbuf == NULL); // ... fine processo assegnazione memoria puntatore 'base'
	}
}
catch (std::bad_alloc &ba)
{
	CBotdie(__DATE__, __TIME__, file, line, "CBREALLOC: bad_alloc caught %s at source file %s and line %d!", ba.what(), file, line);
}

	if (undefined_retries == true)
	{
		// CBotdie("__DATE__, __TIME__, file, line, CBREALLOC: Error (re)allocating memory for %u times!", err_count);
		fprintf(stderr, "CBREALLOC: Error (re)allocating memory for %u times at file %s and line %s!", err_count, file, line);

		return NULL;
	}

	size = newsize;

	return newbuf;
}

#else

//
// Name: CBotAllocator
//
// Description:
//   Invoked by 'preprocessor macro' 'CBalloc'
//   Alloc memory at pointer declared inside of function
//   N.B. i template se compilati attraverso moduli devono SEMPRE essere presenti nel file header
//
// Input:
//   method - enum 'am_t' allocation method
//   size - size of memory area
//
// Return:
//   T *pointer 
//
template <typename T> T *CBotAllocator (const am_t &method, const int &size)
{
	if (size <= 0)
		die("CBALLOC: size %d of memory allocation is invalid!", size);

	T *allocated = NULL;

	bool bad_alloc_method = false;

try
{

	switch (method)
	{
		case(NEW):
			allocated = new T [size];
			break;
		case(MALLOC):
			allocated = (T *) malloc (size * sizeof(T));
			break;
		case(CALLOC):
			allocated = (T *) calloc (size, sizeof(T));
			break;
		default:
			bad_alloc_method = true;
			break;
	}
}
catch (std::bad_alloc &ba)
{
	die("CBALLOC: bad_alloc caught %s!", ba.what());
}

	if (bad_alloc_method == true)
		die("CBALLOC: unsupported memory allocation method!");

	if (allocated == NULL)
		die("CBALLOC: allocation failed");

	return allocated;
}

//
// Name: CBotReAllocator
//
// Description:
//   Invoked by 'preprocessor macro' 'CBalloc'
//   Realloc memory for required new size
//
// Input:
//   oldbuf - the buffer to increase size
//   size - the size of oldbuf
//   required_size - the needed size
//   delta - the delta size used to increase size
//
// Output:
//   size set to new size
//
// Return:
//   T *pointer to rellocated buffer
//
template <typename T, typename P> T *CBotReAllocator (T *oldbuf, P &size, const ssize_t &required_size, const size_t &delta)
{
	if (oldbuf == NULL)
		die("memory (re)allocation is required!");

	T *newbuf = NULL;
	P newsize = size;

	unsigned short err_count = 0;
	const unsigned short max_realloc = 5;
	bool undefined_retries = false;

try
{

	if (required_size > size)
	{
		// Inizio processo assegnazione memoria al puntatore 'base' ...
		while (newsize < required_size) newsize += delta;

		do
		{
			err_count++;
			newbuf = (T*) realloc (oldbuf, (newsize * sizeof(T)));

			if (newbuf == NULL && err_count > max_realloc)
				undefined_retries = true;
		}
		while (newbuf == NULL); // ... fine processo assegnazione memoria puntatore 'base'
	}
}
catch (std::bad_alloc &ba)
{
	die("CBREALLOC: bad_alloc caught %s!", ba.what());
}

	if (undefined_retries == true)
	{
		// die("CBREALLOC: Error (re)allocating memory for %u times!", err_count);
		fprintf(stderr, "CBREALLOC: Error (re)allocating memory for %u times!", err_count);

		return NULL;
	}

	size = newsize;

	return newbuf;
}

#endif

// Classes

class SemaphorePrint {
	// class support 256 outputs for process
	// after this limit -> assert!
	atomic<bool> *mprint;
	unsigned char *counts;

	public:

	SemaphorePrint (unsigned char *_X) // ctor
		: mprint (CBALLOC(atomic<bool>, CALLOC, UCHAR_MAX))
		, counts (_X)
	{
		assert(_X != NULL);
	}

	~SemaphorePrint() // dtor
	{
		free(counts);
		counts = NULL;
		free(mprint);
		mprint = NULL;
	}

	// chooses the first thread ready for print same output
	bool go_ahead ( instance_t & );

	// reset counts for next reuse
	void reset ( instance_t & );
};

// Globals
extern SemaphorePrint *sp;
extern bool *symshown;
extern pthread_mutex_t *console_lock;

#endif
