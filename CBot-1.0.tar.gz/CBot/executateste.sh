#!/bin/bash
# arquivo que executa os comandos de inicio de uma sequencia do crwaler.
# O endereço do arquivo de configuração deve ser alterado para a posição real do arquivo.

export CBOT_CONF=/incluir/aqui/o/endereço/do/arquivo/de/configuração

	if [ -z "$CBOT_CONF" ]; then
		echo "CBOT_CONF not defined"
		exit 1
	fi

	if [ ! -f "$CBOT_CONF" ]; then
		echo "$CBOT_CONF not found"
		exit 1
	fi

	BASEDIR=`grep '<base>' $CBOT_CONF | sed 's/<\/\?base>//g' | awk '{print $1}'`
	if [ -z "$BASEDIR" ]; then
		echo "Couldn't find base dir in $CBOT_CONF"
		exit 1
	fi
	if [ ! -d "$BASEDIR" ]; then
		echo "Base dir $BASEDIR specified in $CBOT_CONF is not a dir"
		exit 1
	fi
cbot-reset
cbot-seeder --start /home/heitor/CBOT/Arquivo/listainicial.txt
cbot-manager
cbot-harvester
cbot-gatherer
	arqname=`ls -t "$BASEDIR/link/" | grep '.*download\.' -m1`
	if [ -z "$BASEDIR/link/$arqname" ]; then
		echo "coudn't shuffle the download list"
	else 
		java -Xmx512m -jar "$BASEDIR/fileshuffler.jar" "$BASEDIR/link/$arqname"
		echo "download list shuffled"
	fi
cbot-seeder
cbot-manager
cbot-harvester
cbot-gatherer
	arqname=`ls -t "$BASEDIR/link/" | grep '.*download\.' -m1`
	if [ -z "$BASEDIR/link/$arqname" ]; then
		echo "coudn't shuffle the download list"
	else 
		java -Xmx512m -jar "$BASEDIR/fileshuffler.jar" "$BASEDIR/link/$arqname"
		echo "download list shuffled"
	fi
cbot-seeder
