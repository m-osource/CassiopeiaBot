/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

/*
 * Preferibile caricare i siti e gli url con il metodo tradizionale perchè
 * mai testato con tutte le nuove modifiche
 */

#include "import.h"

// 
// Name: main
//
// Description:
//   Main program for the import
//

int main( int argc, char **argv )
{
try
{
	cbot_start("info-import" );

	// Parse options
	bool opt_import_date	= false;
	char opt_filename_date[MAX_STR_LEN];

	bool opt_import_link	= false;
	char opt_filename_link[MAX_STR_LEN];

	bool opt_import_content_length	= false;
	char opt_filename_content_length[MAX_STR_LEN];

	bool opt_import_url	= false;
	char opt_filename_url[MAX_STR_LEN];

	while(1) {
		int option_index = 0;

		static struct option long_options[] = {
			{"help", 0, 0, 0},
			{"date", 1, 0, 0},
			{"link", 1, 0, 0},
			{"content_length", 1, 0, 0},
			{"url", 1, 0, 0},
			{0, 0, 0, 0}
		};

		char c = getopt_long (argc, argv, "h",
			long_options, &option_index);

		if (c == -1)
			break;

		switch (c) {
			case 0:
				if( !strcmp( long_options[option_index].name, "date" ) ) {
					opt_import_date = true;
					strcpy( opt_filename_date, optarg );

				} else if( !strcmp( long_options[option_index].name, "link" ) ) {
					opt_import_link = true;
					strcpy( opt_filename_link, optarg );

				} else if( !strcmp( long_options[option_index].name, "content_length" ) ) {
					opt_import_content_length = true;
					strcpy( opt_filename_content_length, optarg );

				} else if( !strcmp( long_options[option_index].name, "url" ) ) {
					opt_import_url = true;
					strcpy( opt_filename_url, optarg );

				} else if( !strcmp( long_options[option_index].name,
							"help" ) ) {
					import_usage();
				}
				break;
			case 'h':
				import_usage();
				break;
		}
	}

	if( !(opt_import_link||opt_import_url) ) {
		import_usage();
	}

	// Input files
	ifstream input_url;
	ifstream input_link;
	ifstream input_date;
	ifstream input_content_length;

	// Open input files and indices
	meta = new Meta( COLLECTION_METADATA, false );
	meta->ddx_open();

	// Failed to open index
	if (thread_alarm != THREADS_OK) cbot_stop(1);

	if( meta->doc_count() > 0 ) {
		cerr << "Metaidx must be empty for importing data" << endl;
		cbot_stop(1);
	}

	// Filename of URLs
	if( opt_import_url ) {
		url = new Url ( COLLECTION_URL, Url::RW );
		url->ddx_open();

		// Failed to open index
		if (thread_alarm != THREADS_OK) cbot_stop(1);

		input_url.open( opt_filename_url );
		if( ! input_url.is_open() ) {
			perror( opt_filename_url );
			die( "Opening input file of URLs" );
		}
	}

	// Filename of dates
	if( opt_import_date ) {
		if( ! opt_import_url ) {
			die( "Importing dates requires import url" );
		}
		input_date.open( opt_filename_date );
		if( ! input_date.is_open() ) {
			perror( opt_filename_date );
			die( "Opening input file of dates" );
		}
	}

	// Content length
	if( opt_import_content_length ) {
		if( ! opt_import_url ) {
			die( "Importing content length requires import url" );
		}
		input_content_length.open( opt_filename_content_length );
		if( ! input_content_length.is_open() ) {
			perror( opt_filename_content_length );
			die( "Opening input file of content_length" );
		}
	}

	// Filename of links
	if( opt_import_link )
	{
		lidx = linkidx_open ( COLLECTION_LINK, false );

		// Failed to open index
		if (thread_alarm != THREADS_OK) cbot_stop(1);

		input_link.open( opt_filename_link );
		if( ! input_link.is_open() ) {
			perror( opt_filename_link );
			die( "Opening input file of links" );
		}
	}

	if( opt_import_url ) {

		doc_t doc;
		doc.docid = 1;
		docid_t docid = doc.docid;
//		doc.docid = (meta->doc_count() + (docid_t)1);
//		docid_t docid = doc.docid;
		site_t site;
		siteid_t siteid;
		siteid_t domainid;
		char line[(MAX_STR_LEN * 2) + 1];
		char _url[MAX_STR_LEN];
		char protocol[MAX_STR_LEN];
		char sitename[MAX_STR_LEN];
		char path[MAX_STR_LEN];
		urlddx_status_t urlddx_rc;
		urlddx_status_t urlddx_drc;

		// create perfect hash for domainid
		perfhash_t keep_special;

		keep_special.check_matches = true;
		perfhash_create( &(keep_special), CONF_COLLECTION_IT_SPECIAL_DOMAINS );

		while( !input_url.eof() && input_url.getline( line, MAX_STR_LEN ) ) {

			// Copy url
			strcpy( _url, line );

			if( docid % 10000 == 0 ) {
				cerr << docid << " " << _url << " ";
			}

			// Check relative URL
			if( ! strchr( _url, ':' ) ) {
				cerr << _url << endl;
				die( "Relative URLs not allowed while importing" );
			}

			// Parse URL
			if( ! url->parse_complete_url( _url, protocol, sitename, path ) ) {
				cerr << _url << endl;
				die( "Problem while parsing URL" );
			}

			// Sitename to lowercase
			for( uint i = 0; i < strlen(sitename); i++ ) {
				sitename[i] = tolower( sitename[i] );

				// Check port numbers
				if( sitename[i] == ':' ) {
					// Strip port number
					sitename[i] = '\0';
					continue;
				}

				// Check other chars
				if( !isalnum(sitename[i]) && sitename[i] != '.' && sitename[i] != '-' && sitename[i] != '_' ) {

					// Site name not acceptable
					die( "Site name not acceptable" );
				}
			}

			// Now in need check also for new special domain
			siteid_t sdomainid = 0;

			// Get the domainid or create the domain
			urlddx_drc = url->resolve_domain( sitename, &(domainid), &(sdomainid), keep_special );

			// Get the site
			urlddx_rc = url->resolve_site( sitename, &(siteid), NOT_DEFINED );

			if( urlddx_rc == URLDDX_CREATED_SITE && (urlddx_drc == URLDDX_CREATED_DOMAIN || urlddx_drc == URLDDX_EXISTENT)) {
				assert( siteid > 0 );
				meta->site_default( &(site) );
				site.siteid = siteid;
				site.domainid = domainid;
				site.count_doc	= 0;

				// Store
				if (meta->site_store(&(site)) != METADDX_OK)
					die("metaddx site_store for siteid %llu", site.siteid);

				// Mark site as visited 
				if (meta->site_option_set(site.siteid, SITE_OPT_NEW, false) != METADDX_OK)
					die("metaddx site_option_set for siteid %llu", site.siteid);
			}

			// No post-processing is done to urls
			docid_t urlddx_docid;
			urlddx_rc = url->resolve_path( siteid, path, &(urlddx_docid) );
			if( urlddx_rc == URLDDX_CREATED_PATH ||
				urlddx_rc == URLDDX_EXISTENT ) {

				// If it is new
				if( urlddx_rc == URLDDX_CREATED_PATH && urlddx_docid != docid ) {
					// Check correlative docids
					cerr << "urlddx_docid : " << urlddx_docid << endl;
					cerr << "docid        : " << docid << endl;
					die( "Wrong correlative docid" );
				}

				meta->doc_default( &(doc) );
				doc.docid		= docid;

				// Set other parameters
				doc.siteid		= siteid;
				doc.domainid		= domainid;
				doc.status		= STATUS_DOC_GATHERED;
				doc.http_status	= HTTP_OK;

				// Check if this was duplicate (e.g.: the site name or path
				// was normalized by URLDDX)
				if( urlddx_rc == URLDDX_EXISTENT ) {

					// Mark as duplicate
					doc.duplicate_of	= urlddx_docid;

					// We still must store something in the URL idx,
					// otherwise the docids will not be correct.
					do {
						// We will try to add '-'s at the end of the path
						// until we store something
						assert( strlen( path ) < MAX_STR_LEN );
						strcat( path, "_" );
						urlddx_rc = url->resolve_path( siteid, path, &(urlddx_docid) );

					} while( urlddx_rc == URLDDX_EXISTENT );
				}

				// Set metadata
				if( opt_import_date && !input_date.eof() ) {
					input_date.getline( line, MAX_STR_LEN );
					doc.last_modified	= atol( line );
				}
				if( opt_import_content_length && !input_content_length.eof() ) {
					input_content_length.getline( line, MAX_STR_LEN );
					doc.content_length	= atol( line );
				}

				// Store
				meta->doc_store(&(doc));

			} else {
				cerr << "Problem with line " << line << endl;
				die( "Problem with url->resolve_path" );
			}

			// Increase docid
			if( docid % 10000 == 0 ) {
				cerr << "OK" << endl;
			}
			docid++;

			// Check limits
			assert( url->sitecount() < (siteid_t)((float)CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));
			assert( url->pathcount() < (docid_t)((float)CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));
		}

		for( unsigned int i=0; i < keep_special.count; i++ )
			free( keep_special.keywords[i] );
	}

	// Read links
	if( opt_import_link ) {
		cerr << endl << "Importing links" << endl;

		char line[MAX_STR_LEN];
		char c = '\0';
		uint adjacency_list_length;
		out_link_t adjacency_list[LINK_MAX_OUTDEGREE];
		uint linelen;
		docid_t src_docid;
		docid_t lineno = 0;

		while( !input_link.eof() ) {
			adjacency_list_length = 0;
			line[0] = '\0';
			linelen	= 0;
			src_docid = 0;
			lineno++;

			// Read character by character, we do this because
			// lines can be very long
			do {

				// Read one character
				input_link.get( c );

				// If this is a space, then it is a next token
				if( c == ' ' || c == '\n' ) {
					// Next token
					line[linelen]	= '\0';

					if( src_docid == 0 ) {
						src_docid	= atol( line );
					} else {
						if( adjacency_list_length < ( LINK_MAX_OUTDEGREE - 2) ) {
							adjacency_list[adjacency_list_length].dest	= (docid_t)(atol(line));
							adjacency_list[adjacency_list_length].tag	= TAG_UNDEF;
							adjacency_list[adjacency_list_length].rel_pos	= 0;
							adjacency_list[adjacency_list_length].anchor_length	= 0;

							adjacency_list_length ++;
						}
					}
					line[0] = '\0';
					linelen	= 0;
				} else {
					// Append to the current token
					line[linelen++]	= c;
				}
			} while( c != '\n' && !input_link.eof() );

			// Store
			if( adjacency_list_length > 0 )
			{ // TODO se interessati a far funzionare il programma, copiare da seeder
//				linkidx_status_t rc = linkidx_store( linkidx, src_docid, adjacency_list, adjacency_list_length );
//				assert( rc == LINKIDX_OK );
			}
			if( lineno % 10000 == 0 ) {
				cerr << src_docid << " " << adjacency_list_length << " lnk " << endl;
			}
		}
	}

	// Final message
	cerr << "Import OK ***NEXT STEPS: MANDATORY*** " << endl;
	cerr << "% cbot-info-analysis --mark-dynamic" << endl;
	cerr << "  For marking static/dynamic URLs" << endl;
	cerr << "% cbot-info-analysis --recalculate-depth" << endl;
	cerr << "  For fixing page depths" << endl;
	cerr << "% cbot-info-analysis --site-statistics" << endl;
	cerr << "  For fixing site counts" << endl;

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}
}

//
// Name: cleanup
//
// Description: 
//   Closes files, indexes
//

void cleanup() {
	if( meta != NULL ) {
		meta->ddx_close();
		delete meta;
		cerr << "[metaddx] ";
	}
	if( url != NULL ) {
		url->ddx_close();
		delete url;
		cerr << "[urlddx] ";
	}
	if( lidx != NULL ) {
		lidx->st_close();
		cerr << "[linkidx] ";
	}
}

//
// Name: import_usage
//
// Description:
//   Prints an usage message, then stops
//

void import_usage() {
	cerr << "Usage: program [OPTION]" << endl;
	cerr << "Imports data and create a collection of doc from scratch" << endl;
	cerr << "Data is in different files, one URL per file, starting with id=1" << endl;
	cerr << "You must import at least URLs or links" << endl;
	cerr << endl;
	cerr << " --url FILENAME    containing urls, one per line" << endl;
	cerr << " --date FILENAME   containing date, one per line" << endl;
	cerr << " --link FILENAME   containing links, one per line, format:" << endl;
	cerr << "                   src dest1 dest2 dest3 ..." << endl;
	cerr << " --content_length FILENAME   containing size length" << endl;
	cerr << " --help, -h           this help message" << endl;
	cerr << endl;
	cbot_stop(0);
}
