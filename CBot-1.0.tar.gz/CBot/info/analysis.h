/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _ANALYSIS_H_INCLUDED_
#define _ANALYSIS_H_INCLUDED_

#include <config.h>

// System libraries

#include <features.h>
#include <map>
#include <fstream>
#include <assert.h>
#include <getopt.h>

using namespace std;

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "xmlconf-main.h"
#include "utils.h"
#include "Meta.h"
#include "Monitor.h"
#include "metaddx_analysis.h"
#include "harvestidx.h"
#include "Storage.h"
#include "linkidx.h"
#include "Url.h"
#include "cleanup.h"
#include "sitelink.h"
#include "lang.h"

// Globals

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

Monitor *monitor		= NULL;
Meta *meta				= NULL;
Url *url				= NULL;
Storage *lidx			= NULL;
Storage *strg			= NULL;
Harvest *harv			= NULL;

// Functions

void analysis_usage();

#endif
