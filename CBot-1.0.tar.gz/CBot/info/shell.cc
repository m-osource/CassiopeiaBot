/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "shell.h"

// 
// Name: main
//
// Description:
//   Main program for extracting information

int main( int argc, char **argv )
{
try
{
	// Check arguments
	if( argc != 1 ) {
		cout << "Usage: " << argv[0] << endl;
		die("Parameters");
	}

	// Init
	cbot_start("info-shell" );

	// Open url index
	cerr << "Opening indices in read-only mode: ";
	
	cerr << "urlindex ... ";
	url = new Url ( COLLECTION_URL, Url::RO );
	url->ddx_open();

	// Failed to open index
	if (thread_alarm != THREADS_OK)
		cbot_stop(1);

	// Open metaindex
	cerr << "metaindex ...";
	meta = new Meta ( COLLECTION_METADATA, true );
	meta->ddx_open();

	// Failed to open index
	if (thread_alarm != THREADS_OK)
		cbot_stop(1);

	// Open storage
	cerr << "storage ... ";
	strg = new Storage( COLLECTION_TEXT, true );
	strg->st_open();

	// Failed to open index
	if (thread_alarm != THREADS_OK)
		cbot_stop(1);

	// Open linkidx
	cerr << "linkidx ... ";
	lidx = new Storage( COLLECTION_LINK, true );
	lidx->st_open();

	// Failed to open index
	if (thread_alarm != THREADS_OK)
		cbot_stop(1);

	// Open roboidx
	cerr << "roboidx ... ";
	ridx = new Storage( COLLECTION_ROBOTS, true );
	ridx->st_open();

	// Open harvest
	cerr << "harvest ... ";
	harv = new Harvest( COLLECTION_HARVEST, true );


	// Failed to open index
	if (thread_alarm != THREADS_OK)
		cbot_stop(1);

	// Open langindex
	cerr << "words language association index ...";
	dymddx = dymddx_open( COLLECTION_DYM, true );
	assert( dymddx != NULL );

	// Failed to open index
	if (thread_alarm != THREADS_OK)
		cbot_stop(1);

	// Open langindex
	cerr << "langindex ...";
	langddx = langddx_open( COLLECTION_LANGDATA, true );
	assert( langddx != NULL );

	// Failed to open index
	if (thread_alarm != THREADS_OK)
		cbot_stop(1);

	cerr << "ok." << endl;
	// Help
	cout << endl;
	shell_help();

	// Standard Input Version
	// To avoid valgrind warning from readline library
	// use this code instead of readline code
	/*
	while( !cin.eof() ) {
		char cmdline[MAX_STR_LEN];
		cout << endl << "(info) ";
		cin.getline( cmdline, MAX_STR_LEN );
		if( !strcmp(cmdline, "quit" ) ) {
			break;
		} else if(cmdline != NULL) {
			shell_parser(cmdline);
		}
	}
	*/

	// Start of readline code
	// for hystory commands and auto completion
	rl_attempted_completion_function = shell_completion;

	while(true)
	{
		char *cmdline = readline("(info) ");

		if (cmdline == NULL)
			break;

		//enable auto-complete
		rl_bind_key('\t', rl_complete);

		size_t blen = strlen(cmdline);
		size_t rlen = blen;

		// remove spaces at least
		while (cmdline[(rlen - 1)] == ASCII_SP)
		{
			rlen--;
			cmdline[rlen] = '\0';
		}

		if (rlen == 4 && strncmp(cmdline, "quit", 4) == 0)
		{
			free(cmdline);
			break;
		}
		else if (cmdline != NULL && strlen(cmdline) < MAX_STR_LEN)
		{
			char *cmdbkp = CBALLOC(char, MALLOC, MAX_STR_LEN);
			strcpy(cmdbkp, cmdline);

			if (shell_parser(cmdline) == true)
				add_history(cmdbkp);

			free(cmdbkp);
		}

		free(cmdline);
	}
	// End of readline code

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}
}

//
// Name: shell_parser
//
// Description:
//   Parses a commandline
//
// Input:
//   cmdline - Command line
//

bool shell_parser(char *cmdline)
{
	char *cmd = NULL;
	
	cmd = strtok(cmdline, " " );

	if (cmd == NULL || strlen(cmd) == 0)
		return false;

	// Check the command
	if (!strcmp(cmd, "?") || !strcmp(cmd, "help" ))
	{
		// Help
		cout << "Help:" << endl;
		shell_help();

	}
	else if (!strcmp(cmd, "urlddx"))
	{
		// Url index

		cout << "Url index info:" << endl;
		url->dump_status();


	}
	else if (!strcmp(cmd, "dymddx"))
	{
		// Url index

		cout << "Word languages association index info:" << endl;
		dymddx_dump_status(dymddx);

	}
	else if (!strcmp(cmd, "harvest"))
	{
		// Harvest


		char *fieldstr	= strtok(NULL, " ");

		if (fieldstr == NULL)
		{
			cout << "Empty field" << endl;
			cout << "Use: harvest (numeric id)" << endl;
			return false;
		}

		// Get docid
		unsigned int harvestid = atol(fieldstr);

		if (harvestid == 0)
		{
			cout << "Invalid field" << endl;
			cout << "Use: harvest (id > 0)" << endl;
			return false;
		}
		cout << "Harvest info:" << endl;

		if (harv->is_found(harvestid))
		{
			harvest_status_t harvest_status = harv->hv_open(harvestid, true);

			// Failed to open harvest
		    if (harvest_status == STATUS_HARVEST_ABORTED || thread_alarm != THREADS_OK)
				cout << "Failed to open harvest" << endl;
			else
			{
				harv->dump_status(false);
				harv->hv_close();
			}
		}
		else
			cout << "No such harvest" << endl;
	}
	else if (!strcmp(cmd, "read"))
	{
		// Content of document

		char *fieldstr	= strtok(NULL, " ");

		if (fieldstr == NULL)
		{
			cout << "Empty field" << endl;
			cout << "Use: read (numeric id)" << endl;
			return false;
		}

		// Get docid
		doc_t doc;
		doc.docid = atol(fieldstr);

		if (doc.docid == 0)
		{
			cout << "Invalid field" << endl;
			cout << "Use: read (id > 0)" << endl;
			return false;
		}

		// Retrieve info
		metaddx_status_t rc;
		rc = meta->doc_retrieve(&(doc));

		if (rc == METADDX_OK)
		{
				storage_status_t rc;
				char *buf = NULL;

				if (doc.mime_type == MIME_ROBOTS_TXT)
				{
					buf = CBALLOC(char, MALLOC, (doc.content_length + 1));
					off64_t len;

					instance_t inst = ((doc.siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
					docid_t virtual_id = (docid_t)(((doc.siteid - 1) + CONF_COLLECTION_DISTRIBUTED) / CONF_COLLECTION_DISTRIBUTED);

					rc = ridx->st_idx_read(inst, virtual_id, buf, len);

					if (rc != STORAGE_OK)
						cout << "Not found" << endl;
					else
					{
						assert(len == doc.content_length);

				        robots_txt_display(buf, (size_t)len);
					}
				}
				else
				{
					buf = CBALLOC(char, MALLOC, (doc.content_length + 1));

					rc = strg->read_document(&(doc), buf);

					if (rc != STORAGE_OK)
						cout << "Not found" << endl;
					else
						show_content(doc.mime_type, doc.docid, buf, doc.content_length);
				}

				if (buf != NULL)
					free(buf);
		}
	}
	else if (!strcmp(cmd, "linkidx"))
	{
		// Linkidx info
		cout << "Linkidx info:" << endl;
		lidx->dump_status();
	}
	else if (!strcmp(cmd, "roboidx"))
	{
		// Linkidx info
		cout << "Roboidx info:" << endl;
		ridx->dump_status();
	}
	else if (!strcmp(cmd, "metaddx"))
	{
		// Metaidx info
		cout << "Metaidx info:" << endl;
		meta->dump_status();
	}
	else if (!strcmp(cmd, "langddx"))
	{
		// Metaidx info
		cout << "Langddx info:" << endl;
		langddx_dump_status(langddx);
	}
	else if (!strcmp(cmd, "summary"))
	{
		// Metaidx summary

		cout << "Sites known          : " << meta->site_count() << endl;
		cout << "Documents known      : " << meta->doc_count() << endl;
		cout << "Words known          : " << langddx->count_word << endl;

		cbot_stats(false);

		TALARM;

		unsigned int harvestid = 1;
		internal_long_uint_t count_ok			= 0;
		internal_long_uint_t count_gathered		= 0;

		while (harv->is_found(harvestid))
		{
			harvest_status_t harvest_status = harv->hv_open(harvestid, true);

			if (harvest_status == STATUS_HARVEST_SEEDED || harvest_status == STATUS_HARVEST_DONE)
			{
				for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				{
					count_ok += harv->hv_doc_count_ok(i);
					count_gathered += harv->hv_doc_count(i);
				}
			}

			harv->hv_close();

			harvestid++;
		}

		cout << "Number of downloads in the life of collection: " << count_gathered			<< endl;
		cout << "Number of downloads OK in the life of collection: " << count_ok 	<< endl;

	}
	else if (!strcmp(cmd, "links"))
	{
		// Links

		docid_t docid = atol(strtok(NULL, " ") );
		assert(docid > 0);

		linkidx_dump_links_with_url(lidx, url, docid);
	}
	else if (!strcmp(cmd, "storage"))
	{
		// Storage info

		cout << "Storage info:" << endl;
		strg->dump_status();
	}
	else if (!strcmp(cmd, "doc"))
	{
		// Info for a document

		char *fieldstr	= strtok(NULL, " ");

		if (fieldstr == NULL)
		{
			cout << "Empty field" << endl;
			cout << "Use: doc (numeric id)" << endl;
			return false;
		}

		// Get docid
		doc_t doc;
		doc.docid = atol(fieldstr);

		if (doc.docid == 0)
		{
			cout << "Invalid field" << endl;
			cout << "Use: doc (id > 0)" << endl;
			return false;
		}
			
		cout << "Info for document: " << endl;

		// Retrieve info
		metaddx_status_t rc;
		rc = meta->doc_retrieve(&(doc));

		if (rc == METADDX_OK)
		{
			// Dump the doc info
			meta->dump_doc_status(&(doc));

			// Retrieve the path and sitename
			char _url[MAX_STR_LEN];
			url->url_by_docid(doc.docid, _url);
			cout << "Url: " << _url << endl;

		}
		else
			cout << "Couldn't retrieve document " << doc.docid << endl;
	}
	else if (!strcmp(cmd, "word"))
	{
		// Info for a wordument

		char *fieldstr	= strtok(NULL, " ");

		if (fieldstr == NULL)
		{
			cout << "Empty field" << endl;
			cout << "Use: word (numeric id)" << endl;
			return false;
		}

		// Get wordid
		word_t word;
		word.wordid = atol(fieldstr);

		if (word.wordid == 0)
		{
			cout << "Invalid field" << endl;
			cout << "Use: word (id > 0)" << endl;
			return false;
		}
			
		cout << "Info for word: " << endl;

		// Retrieve info
		langddx_status_t rc;
		rc = langddx_word_retrieve(langddx, &(word));

		if (rc == LANGDDX_OK)
		{
			// Dump the word info
			langddx_dump_word_status(&(word));

			// Retrieve the path and sitename
			char parola[MAX_STR_LEN];
			dymddx_word_by_wordid(dymddx, word.wordid, parola);
			cout << "Word: " << parola << endl;

		}
		else
			cout << "Couldn't retrieve word " << word.wordid << endl;
	}
	else if (!strcmp(cmd, "find"))
	{
		// Search a document
		doc_field_t 	thefield	= DOC_FIELD_UNDEF;

		char *fieldstr	= strtok(NULL, " ");

		if (fieldstr == NULL)
		{
			cout << "Empty field" << endl;
			cout << "Use: depth (value), in_degree (value), out_degree (value), http_status (value), feeds (yes|no)" << endl;
			return false;
		}

		if (!strcmp(fieldstr, "depth"))
			thefield	= DOC_FIELD_DEPTH;
		else if (!strcmp(fieldstr, "in_degree"))
			thefield	= DOC_FIELD_IN_DEGREE;
		else if (!strcmp(fieldstr, "out_degree"))
			thefield	= DOC_FIELD_OUT_DEGREE;
		else if (!strcmp(fieldstr, "http_status"))
			thefield	= DOC_FIELD_HTTP_STATUS;
		else if (!strcmp(fieldstr, "feeds"))
			thefield	= DOC_FIELD_FEEDS;
		else
		{
			cout << "Unrecognized field" << endl;
			cout << "Use: depth (value), in_degree (value), out_degree (value), http_status (value), feeds (yes|no)" << endl;
			return false;
		}

		uint thevalue = 0;
		char *thevaluestr = strtok(NULL, " ");

		if (thefield == DOC_FIELD_FEEDS)
		{
			if (strncmp(thevaluestr, "yes", 3) == 0)
				thevalue = 1;
			else if (strncmp(thevaluestr, "no", 2) == 0)
				thevalue = 0;
			else
			{
				cout << "Unrecognized value for field 'feeds'" << endl;
				cout << "Use: feeds (yes|no)" << endl;
				return false;
			}
		}
		else
			thevalue = atol(thevaluestr);

		doc_t doc;

		cout << "Searching documents:" << endl;

		char _url[MAX_STR_LEN];	
		for (doc.docid=1; doc.docid <= meta->doc_count(); doc.docid++)
		{
			meta->doc_retrieve(&(doc));
			if (
				(thefield == DOC_FIELD_DEPTH && (doc.depth == thevalue)) ||
			  	(thefield == DOC_FIELD_IN_DEGREE && (doc.in_degree == thevalue)) ||
				(thefield == DOC_FIELD_OUT_DEGREE && (doc.out_degree == thevalue)) ||
				(thefield == DOC_FIELD_HTTP_STATUS && (doc.http_status == (int)thevalue)) ||
				(thefield == DOC_FIELD_FEEDS && (doc.from_feed == (bool)thevalue)))
			{
				url->url_by_docid(doc.docid, _url);
				cout << " " << doc.docid << " " << _url << endl;
			}
		}

	}
	else if (!strcmp(cmd, "sitedocs"))
	{

		char *fieldstr	= strtok(NULL, " ");

		if (fieldstr == NULL)
		{
			cout << "Empty field" << endl;
			cout << "Use: sitedocs (numeric id)" << endl;
			return false;
		}

		// Docs for a site
		site_t site;
		site.siteid = shell_get_siteid(fieldstr);

		if (site.siteid > 0)
		{

			cout << "Documents in site " << site.siteid << " (press Ctrl-C to abort):" << endl;

			char _url[MAX_STR_LEN];	
			doc_t doc;

			for (docid_t docid=1; docid <= meta->doc_count(); docid++)
			{
				doc.docid	= docid;
				meta->doc_retrieve(&(doc));
				assert(doc.docid == docid);

				if (doc.siteid == site.siteid)
				{
					url->url_by_docid(doc.docid, _url);
					cout << " " << doc.docid << " " << _url << endl;
				}
			}

		}

	}
	else if (!strcmp(cmd, "sitelinks"))
	{

		char *fieldstr	= strtok(NULL, " ");

		if (fieldstr == NULL)
		{
			cout << "Empty field" << endl;
			cout << "Use: sitelinks (numeric id)" << endl;
			return false;
		}

		// Docs for a site
		siteid_t siteid = shell_get_siteid(fieldstr);

		cout << "Links from siteid ";

		if (siteid > 0 && siteid <= url->sitecount())
		{
			Sitelink *slink = new Sitelink (COLLECTION_SITELINK, true);

			slink->sl_load(lidx, meta);
			slink->dump_links_from_sitename_to_others(url, siteid);

			if (slink != NULL)
				delete slink;
		}

	}
	else if (!strcmp(cmd, "siterevlinks"))
	{

		char *fieldstr	= strtok(NULL, " ");

		if (fieldstr == NULL)
		{
			cout << "Empty field" << endl;
			cout << "Use: siterevlinks (numeric id)" << endl;
			return false;
		}

		// Docs for a site
		siteid_t siteid = shell_get_siteid(fieldstr);

		cout << "Links pointing to siteid ";
		cout << siteid << endl;

		if (siteid > 0)
		{
			Sitelink *slink = new Sitelink (COLLECTION_SITELINK, true);

			slink->sl_load(lidx, meta);
			slink->dump_links_from_sitenames_to_sitename(url, siteid);

			if (slink != NULL)
				delete slink;
		}

	}
	else if (!strcmp(cmd, "site"))
	{

		char *fieldstr	= strtok( NULL, " " );

		if (fieldstr == NULL)
		{
			cout << "Empty field" << endl;
			cout << "Use: site (numeric id)" << endl;
			return false;
		}

		// Docs for a site
		site_t site;
		site.siteid = shell_get_siteid( fieldstr );

		// Info for a site
		cout << "Info for site: " << endl;

		if (site.siteid > 0)
		{

			// Retrieve info
			metaddx_status_t rc;
			rc = meta->site_retrieve( &(site) );

			if (rc == METADDX_OK)
			{
				// Dump the site info
				meta->dump_site_status( &(site) );

				// Retrieve the sitename
				char sitename[MAX_STR_LEN];
				url->site_by_siteid( site.siteid, sitename );
				cout << "Site name: " << sitename << endl;

			}
			else
				cout << "Couldn't retrieve site " << site.siteid << endl;
		}
	}
	else
	{
		cout << "Undefined command: \"" << cmd << "\". Try \"help\"." << endl;
		return false;
	}

	return true;
}

//
// Name: shell_get_siteid
//
// Description:
//   Gets a siteid based on a sitename,
//   or converts a siteid from string to siteid_t
//
// Input:
//   sitename - name of the site or siteid as string
//
// Returns:
//   siteid, or 0 if error
//

siteid_t shell_get_siteid( char *sitename ) {
	if( sitename == NULL ) {
		return (siteid_t)0;
	}

	// Get siteid from the string
	siteid_t siteid = atol( sitename );

	// Check
	if( siteid == 0 ) {

		// The string was not a number, resolve
		urlddx_status_t rc = url->resolve_site( sitename, NULL, NOT_DEFINED );
		if( rc == URLDDX_NOT_FOUND ) {
			cerr << "Site unknown" << endl;
			return (siteid_t)0;

		} else {
			rc = url->resolve_site( sitename, &(siteid), NOT_DEFINED );
			assert( rc == URLDDX_EXISTENT );
			return siteid;
		}

	} else {
		return siteid;
	}
}

//
// Name: shell_help
//
// Description:
//   Prints the help message
//

void shell_help() {
	cout << "? -- this message" << endl;
	cout << "help -- this message" << endl;
	cout << "summary -- summary information" << endl;
	cout << "urlddx -- info of url index" << endl;
	cout << "dymddx -- info of word language association index" << endl;
	cout << "harvest <harvestid> -- info of harvest index" << endl;
	cout << "linkidx -- info of link index" << endl;
	cout << "roboidx -- info of robots.txt rules on index" << endl;
	cout << "metaddx -- info of metadata index" << endl;
	cout << "langddx -- info of langdata index" << endl;
	cout << "storage -- info of storage" << endl;
	cout << "doc <docid> -- info for a document" << endl;
	cout << "read <docid> -- content of a document" << endl;
	cout << "word <wordid> -- info for a word - needed if crawler want apply a correct stemming to single word" << endl;
	cout << "find <depth | in_degree | out_degree | http_status> value | <feeds> (yes|no) -- find docs" << endl;
	cout << "site <siteid | hostname> -- info for a site" << endl;
	cout << "sitedocs <siteid> -- documents on a site" << endl;
	cout << "links <docid> -- links from document" << endl;
	cout << "sitelinks <siteid> -- links from a website" << endl;
	cout << "siterevlinks <siteid> -- links to a website" << endl;
	cout << "quit -- exit this program" << endl;
}
	
//
// Name: cleanup
//
// Description: 
//   Closes files, indexes
//

void cleanup() {
	if( meta != NULL ) {
		meta->ddx_close();
		delete meta;
		cerr << "[metaddx] ";
	}
	if( url != NULL ) {
		url->ddx_close();
		delete url;
		cerr << "[urlddx] ";
	}
	if( strg != NULL ) {
		strg->st_close();
		delete strg;
		cerr << "[storage] ";
	}
	if( lidx != NULL ) {
		lidx->st_close();
		delete lidx;
		cerr << "[linkidx] ";
	}
	if( ridx != NULL ) {
		ridx->st_close();
		delete ridx;
		cerr << "[roboidx] ";
	}
	if( ridx != NULL ) {
		// harv->hv_close(); already close if open
		delete harv;
		cerr << "[harvest] ";
	}
	if( dymddx != NULL ) {
		dymddx_close( dymddx );
		cerr << "[dymddx] ";
	}
	if( langddx != NULL ) {
		langddx_close( langddx );
		cerr << "[langddx] ";
	}
}
 
static char **shell_completion( const char *text , int start,  int end)
{
    char **matches = NULL;
 
    if (start == 0)
        matches = rl_completion_matches((char*)text, &shell_generator);
    else
        rl_bind_key('\t',rl_abort);
 
    return (matches);
 
}

// readline use
char *shell_generator(const char* text, int state)
{
	static int list_index, len;
	char *name;
 
	if (!state)
	{
		list_index = 0;
		len = strlen (text);
	}

	while ((name = (char *)cmd[list_index]) != NULL)
	{
     	list_index++;
 
		if (strncmp (name, text, len) == 0)
			return (shell_dupstr(name));
    }

	/* If no names matched, then return NULL. */
	return ((char *)NULL);
}

// readline use
char *shell_dupstr (char* s)
{
	char *r = CBALLOC(char, MALLOC, (strlen (s) + 1));
	 
  	strcpy (r, s);

	return (r);
}
