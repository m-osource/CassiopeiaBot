/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "show.h"

//
// Name: show_content
//
// Description: 
//   Show preformatted content of document
//

void show_content( mime_type_t mime_type, docid_t docid, char *inbuf, off64_t len )
{
	if (mime_type == MIME_TEXT_HTML)
	{
		cout << "Content of document #" << docid << ", " << len << " bytes" << endl;
		cout << "---START-HTML-METADATA---" << endl;

		unsigned short offset = HTMLMETAPREFIXSIZE;

		if (((int)inbuf[0] + SCHAR_MAX) > 0)
		{
			cout << "Title: ";

			for (unsigned short i = offset; i <= (offset + (int)inbuf[0] + SCHAR_MAX - 1); i++)
				cout << inbuf[i];

			cout << endl;
		}

		offset += ((int)inbuf[0] + SCHAR_MAX);

		if (((int)inbuf[1] + SCHAR_MAX) > 0)
		{
			cout << "Description: ";

			for (unsigned short i = offset; i <= (offset + (int)inbuf[1] + SCHAR_MAX - 1); i++)
				cout << inbuf[i];

			cout << endl;
		}

		offset += ((int)inbuf[1] + SCHAR_MAX);

		if (((int)inbuf[2] + SCHAR_MAX) > 0)
		{
			cout << "Keywords: ";

			for (unsigned short i = offset; i <= (offset + (int)inbuf[2] + SCHAR_MAX - 1); i++)
				cout << inbuf[i];

			cout << endl;
		}

		offset += ((int)inbuf[2] + SCHAR_MAX);

		if (((int)inbuf[3] + SCHAR_MAX) > 0)
		{
			cout << "Headings: ";

			for (unsigned short i = offset; i <= (offset + (int)inbuf[3] + SCHAR_MAX - 1); i++)
				cout << inbuf[i];

			cout << endl;
		}

		offset += ((int)inbuf[3] + SCHAR_MAX);

		while (inbuf[offset] == ' ') // hide initial spaces
			offset++; 

		cout << "---END-HTML-METADATA---" << endl << endl << "---START-HTML-BODY---" << &(inbuf[offset]) << "---END-HTML-BODY---" << endl;
	}
	else if (mime_type == MIME_APPLICATION_PDF)
	{
		cout << "Content of document #" << docid << ", " << len << " bytes" << endl;
		cout << "---START-PDF-METADATA---" << endl;

		unsigned short offset = PDFMETAPREFIXSIZE;

		if (((int)inbuf[0] + SCHAR_MAX) > 0)
		{
			cout << "Author: ";

			for (unsigned short i = offset; i <= (offset + (int)inbuf[0] + SCHAR_MAX - 1); i++)
				cout << inbuf[i];

			cout << endl;
		}

		offset += ((int)inbuf[0] + SCHAR_MAX);

		if (((int)inbuf[1] + SCHAR_MAX) > 0)
		{
			cout << "Subject: ";

			for (unsigned short i = offset; i <= (offset + (int)inbuf[1] + SCHAR_MAX - 1); i++)
				cout << inbuf[i];

			cout << endl;
		}

		offset += ((int)inbuf[1] + SCHAR_MAX);

		if (((int)inbuf[2] + SCHAR_MAX) > 0)
		{
			cout << "Title: ";

			for (unsigned short i = offset; i <= (offset + (int)inbuf[2] + SCHAR_MAX - 1); i++)
				cout << inbuf[i];

			cout << endl;
		}

		offset += ((int)inbuf[2] + SCHAR_MAX);

		if (((int)inbuf[3] + SCHAR_MAX) > 0)
		{
			cout << "Keywords: ";

			for (unsigned short i = offset; i <= (offset + (int)inbuf[3] + SCHAR_MAX - 1); i++)
				cout << inbuf[i];

			cout << endl;
		}

		offset += ((int)inbuf[3] + SCHAR_MAX);

		while (inbuf[offset] == ' ') // hide initial spaces
			offset++; 

		cout << "---END-PDF-METADATA---" << endl << endl << "---START-PDF-BODY---" << &(inbuf[offset]) << "---END-PDF-BODY---" << endl;
	}
	else
	{
			cout << "Content of document #" << docid << ", " << len << " bytes" << endl;
			cout << "---START---" << inbuf << "---END---" << endl;
	}
}
