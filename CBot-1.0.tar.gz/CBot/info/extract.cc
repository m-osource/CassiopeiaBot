/***************************************************************************
 *		  (C) Copyright 2011 - Nic.br									*
 ***************************************************************************
 ***************************************************************************
 *		  (C) Copyright 2011 - Center for Web Research				   *
 ***************************************************************************
 *																		 *
 *  This file is part of CBot.										 *
 *																		 *
 *  CBot is free software: you can redistribute it and/or modify	   *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or	  *
 *  any later version.													 *
 *																		 *
 *  CBot is distributed in the hope that it will be useful,			*
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of		 *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the		  *
 *  GNU General Public License for more details.						   *
 *																		 *
 *  You should have received a copy of the GNU General Public License	  *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.	  *
 *																		 *
 **************************************************************************/
#include "extract.h"

void dump_doc_header_plus_url( FILE *out ) {
	assert( out != NULL );

	// The order is very important. It must be consistent with
	// metaddx_dump_doc
	fprintf( out, "0url," );
	fprintf( out, "1docid," );
	fprintf( out, "2siteid," );
	fprintf( out, "3status," );
	fprintf( out, "4mime_type," );
	fprintf( out, "5http_status," );
	fprintf( out, "6raw_content_length," );
	fprintf( out, "7effective_speed," );
	fprintf( out, "8latency," );
	fprintf( out, "9latency_connect," );
	fprintf( out, "10number_visits," );
	fprintf( out, "11number_visits_changed," );
	fprintf( out, "12time_unchanged," );
	fprintf( out, "13first_visit," );
	fprintf( out, "14last_visit," );
	fprintf( out, "15last_modified," );
	fprintf( out, "15content_length," );
	fprintf( out, "17hash_value," );
	fprintf( out, "18duplicate_of," );
	fprintf( out, "19depth," );
	fprintf( out, "20is_dynamic," );
	fprintf( out, "21in_degree," );
	fprintf( out, "22out_degree," );
	fprintf( out, "23pagerank," );
	fprintf( out, "24wlrank," );
	fprintf( out, "25hubrank," );
	fprintf( out, "26authrank," );
	fprintf( out, "27freshness," );
	fprintf( out, "28current_score," );
	fprintf( out, "29future_score\n" );

}

// 
// Name: main
//
// Description:
//   Main program for the extract
//

int main( int argc, char **argv )
{
try
{
	cbot_start("info-extract" );

	// Parse options
	bool opt_dump_doc			= false; bool opt_url_depth		= false;
										 bool opt_url			= false;
										 bool opt_doc_url		= false;
	bool opt_dump_links			= false;
	bool opt_dump_logged_links	= false; uint opt_depth		   = 0;
										 bool opt_with_source_doc	= false;
										 bool opt_with_caption		= false;
	bool opt_dump_site			= false;
	bool opt_dump_seeds			= false;
	bool opt_dump_sitelinks		= false;
	bool opt_dump_harvest		= false;
	bool opt_dump_docs_harvest	= false; uint opt_harvester_id = 0;
	bool opt_dump_text			= false;
	bool opt_dump_texts			= false;
	docid_t opt_from			= 0;
	docid_t opt_to				= 0;
	bool opt_dump_sketch			= false;
	bool opt_dump_sketchall		 = false;
	char filename_docids[MAX_STR_LEN];
	uint opt_dump_sketch_docid = 0;
	while(1) {
		int option_index = 0;

		static struct option long_options[] = {
			{"help", 0, 0, 0},
			{"harvest", 0, 0, 0},
			{"docs-harvest", 1, 0, 0},
			{"logged-links", 0, 0, 0},
			{"depth", 1, 0, 0},
			{"url-depth", 0, 0, 0},
			{"url", 0, 0, 0},
			{"doc-url", 0, 0, 0},
			{"with-source-doc", 0, 0, 0},
			{"with-caption", 0, 0, 0},
			{"links", 0, 0, 0},
			{"site", 0, 0, 0},
			{"seeds", 0, 0, 0},
			{"sketch", 1, 0, 0},
			{"sketches", 0, 0, 0},
			{"sitelinks", 0, 0, 0},
			{"doc", 0, 0, 0},
			{"text", 1, 0, 0},
			{"texts", 0, 0, 0},
			{"from", 1, 0, 0},
			{"to", 1, 0, 0},
			{0, 0, 0, 0}
		};

		char c = getopt_long (argc, argv, "htdls",
			long_options, &option_index);

		if (c == -1)
			break;

		switch (c) {
			case 0:
				if( !strcmp( long_options[option_index].name, "harvest" ) ) {
					opt_dump_harvest = true;
				} else if( !strcmp( long_options[option_index].name, "docs-harvest" ) ) {
					opt_dump_docs_harvest	= true;
					opt_harvester_id		= atol( optarg );
				} else if( !strcmp( long_options[option_index].name, "logged-links" ) ) {
					opt_dump_logged_links = true;
				} else if( !strcmp( long_options[option_index].name, "depth" ) ) {
					opt_depth		= atoi( optarg );
				} else if( !strcmp( long_options[option_index].name, "url" ) ) {
					opt_url			= true;
				} else if( !strcmp( long_options[option_index].name, "url-depth" ) ) {
					opt_url_depth		= true;
				} else if( !strcmp( long_options[option_index].name, "doc-url" ) ) {
					opt_doc_url		= true;
				} else if( !strcmp( long_options[option_index].name, "with-source-doc" ) ) {
					opt_with_source_doc	= true;
				} else if( !strcmp( long_options[option_index].name, "with-caption" ) ) {
					opt_with_caption	= true;
				} else if( !strcmp( long_options[option_index].name, "links" ) ) {
					opt_dump_links = true;
				} else if( !strcmp( long_options[option_index].name, "site" ) ) {
					opt_dump_site = true;
				} else if( !strcmp( long_options[option_index].name, "seeds" ) ) {
					opt_dump_seeds = true;
				} else if( !strcmp( long_options[option_index].name, "sketch" ) ) {
						opt_dump_sketch = true;
					opt_dump_sketch_docid = atol(optarg);
				} else if( !strcmp( long_options[option_index].name, "sketches" ) ) {
						opt_dump_sketchall = true;
				} else if( !strcmp( long_options[option_index].name, "sitelinks" ) ) {
					opt_dump_sitelinks = true;
				} else if( !strcmp( long_options[option_index].name, "doc" ) ) {
					opt_dump_doc = true;
				} else if( !strcmp( long_options[option_index].name, "text" ) ){
					opt_dump_text = true;
					strcpy( filename_docids, optarg );
				} else if( !strcmp( long_options[option_index].name, "texts" ) ){
					opt_dump_texts = true;
				} else if( !strcmp( long_options[option_index].name, "from" ) ) {
					opt_from = atol(optarg);
				} else if( !strcmp( long_options[option_index].name, "to" ) ) {
					opt_to = atol(optarg);
				} else if( !strcmp( long_options[option_index].name,
							"help" ) ) {
					extract_usage();
				}
				break;
			case 'l':
				opt_dump_links = true;
				break;
			case 's':
				opt_dump_site = true;
				break;
			case 'd':
				opt_dump_doc = true;
				break;
		}
	}

	if( !(opt_dump_doc||opt_dump_site||opt_dump_harvest||opt_dump_docs_harvest||opt_dump_links||opt_dump_logged_links||opt_dump_text||opt_dump_texts||opt_dump_sitelinks||opt_dump_seeds||opt_dump_sketch||opt_dump_sketchall) ) {
		extract_usage();
	}


	// Harvest information
	if( opt_dump_harvest )
	{
		harv = new Harvest ( COLLECTION_HARVEST, true );

		// brief dump of all harvests excluding summary statistics (eg: pagerank)
		harv->extract();

		// Failed to open index
		if (thread_alarm != THREADS_OK) cbot_stop(1);

		if ( harv != NULL )
			delete harv;
	}

	// Harvest lists
	if( opt_dump_docs_harvest ) {

		assert( opt_harvester_id > 0 );

		harv = new Harvest ( COLLECTION_HARVEST, true );

		internal_long_uint_t count = 0;

		if (harv->is_found(opt_harvester_id))
		{
			harvest_status_t harvest_status = harv->hv_open(opt_harvester_id, true);

			for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
				count += harv->hv_doc_count(i);

			cerr << "Harvest " << opt_harvester_id << " should have " << count << " documents" << endl;

			// This function is defined in harvestidx
			harv->dump_list();

			harv->hv_close();

			// Failed to open index
			if (thread_alarm != THREADS_OK) cbot_stop(1);

			if ( harv != NULL )
				delete harv;
		}
	}

	// If needed, open metaddx
	if( opt_dump_site || opt_dump_doc || opt_dump_links || opt_dump_logged_links || opt_dump_sitelinks || opt_dump_seeds || opt_dump_sketch || opt_dump_sketchall || opt_dump_texts ) {
		cerr << "Opening metaddx ...";
		meta = new Meta ( COLLECTION_METADATA, true );

		meta->ddx_open();

		// Failed to open index
		if (thread_alarm != THREADS_OK) cbot_stop(1);

		cerr << "done." << endl;
	}

	// If needed, open urlddx
	if( opt_dump_site || opt_dump_logged_links || opt_dump_text || opt_dump_texts || opt_dump_seeds || opt_url_depth || opt_url || opt_doc_url || opt_dump_sketch || opt_dump_sketchall ) {

		cerr << "Opening urlddx ... ";
		url = new Url ( COLLECTION_URL, Url::RO );
		url->ddx_open();

		// Failed to open index
		if (thread_alarm != THREADS_OK) cbot_stop(1);

		cerr << "done." << endl;

	}

	// Sites
	if( opt_dump_site ) {
		meta->dump_sitelist( url, stdout );
	}

	// Seeds
	if( opt_dump_seeds ) {
		char sitename[MAX_STR_LEN];
		site_t site;
		docid_t ndocs	= 0;

		// Create an array of zeros, we will compare this against
		// the structure
		char zeros[sizeof(struct in_addr)];
		memset( zeros, 0, sizeof(struct in_addr) );

		for( site.siteid = 1; site.siteid <= meta->site_count(); site.siteid ++ ) {
			meta->site_retrieve( &(site) );
			if( site.count_doc_ok > 0 ) {
				url->site_by_siteid( site.siteid, sitename );
				cout << "http://" << sitename << "/";
/*
				// Check if the site has a valid IP
				if( memcmp( (void *)zeros, (void *)(&(site.addr)), sizeof(struct in_addr) ) != 0 ) {				
					cout << " IP=" << inet_ntoa(site.addr);
				} */
				cout << endl;

				ndocs++;
			}
		}

		if( ndocs == 0 ) {

			cerr << "*** Warning: no sites to export. Perhaps you must run: " << endl;
			cerr << "	'cbot-info-analysis --site-statistics' first" << endl;
		}
	}

	// Sitelinks
	if( opt_dump_sitelinks )
	{
		Storage *lidx = new Storage( COLLECTION_LINK, true );

		if( lidx != NULL )
		{
		    lidx->st_open();

			// Failed to open index
			if (thread_alarm != THREADS_OK) cbot_stop(1);

			Sitelink *slink = new Sitelink ( COLLECTION_SITELINK, true );

			slink->sl_load( lidx, meta );

			// Failed to open index
			if (thread_alarm != THREADS_OK) cbot_stop(1);

			slink->dump_structure(); 

			// Failed to open index
			if (thread_alarm != THREADS_OK) cbot_stop(1);

			if( slink != NULL )
				delete slink;

			if( lidx != NULL )
			{
				lidx->st_close();
				delete lidx;
			}
		}
	}

	// Documents
	if( opt_dump_doc ) {

		doc_t doc;

		// Show header
		if( ! (opt_url_depth||opt_url) ) {
			if (!opt_doc_url)
				meta->dump_doc_header( stdout );
			else
				dump_doc_header_plus_url( stdout );
		}

		// Iterate through documents
		char _url[MAX_STR_LEN]	= "";
		docid_t from = ( opt_from > 0 ? opt_from : 1 );
		docid_t to   = ( opt_to   > 0 ? opt_to   : meta->doc_count() );

		for( doc.docid = from; doc.docid <= to; doc.docid++ ) {
			if( ! opt_url ) {
				meta->doc_retrieve( &(doc) );
			}

			if( opt_url_depth ) {
				// Show only url and depth
				url->url_by_docid( doc.docid, _url );

				cout << doc.depth << " " << _url << endl;

			} else if( opt_url ) {
				url->url_by_docid( doc.docid, _url );

				cout << doc.docid << " " << _url << endl;

			} else {
				// Check depth
				if( opt_depth == 0 || opt_depth == doc.depth ) {
					if (opt_doc_url){
						url->url_by_docid( doc.docid, _url );
						string s_url = _url;

						//added the url path of the doc at the beginning of the of the
						//dumped information of the doc
						int count = 0, count2 = 0;
						char urlaux[MAX_STR_LEN];

						urlaux[0] = '\0';
						//loop to remove commas form the URL string
						while (_url[count] != '\0' && count2 < MAX_STR_LEN){
							 if (_url[count] != ',') {
								 urlaux[count2] = _url[count];
								 count2++;
							 }
							 else{
								 if (count2 + 7 < MAX_STR_LEN){
									 urlaux[count2] = '[';
									 urlaux[count2 + 1] = 'c';
									 urlaux[count2 + 2] = 'o';
									 urlaux[count2 + 3] = 'm';
									 urlaux[count2 + 4] = 'm';
									 urlaux[count2 + 5] = 'a';
									 urlaux[count2 + 6] = ']';
									 count2 += 7;
								 }
							 }
							 count++;
						}

						urlaux[count2] = '\0';


						//***********
						cout << urlaux << ",";
					}
					meta->dump_doc( &(doc), stdout );
				}
			}
		}
	}

	// Text
	if( opt_dump_text || opt_dump_texts ) {
		char _url[MAX_STR_LEN];
		char *buf;
		buf = (char *)malloc(sizeof(char)*MAX_DOC_LEN);
		assert( buf != NULL );

		strg = new Storage ( COLLECTION_TEXT, true );
		strg->st_open();

		if( opt_dump_text ) {
			ifstream input_file;
			input_file.open( filename_docids );
			assert( input_file.is_open() );
			doc_t doc;
			char line[MAX_STR_LEN];
			while( ! input_file.eof() && input_file.getline(line,MAX_STR_LEN) ) {
				docid_t docid = atol(line);
				meta->doc_retrieve( &(doc) );
				assert( doc.docid == docid );
				extract_dump_document( &(doc), _url, buf );
			}
			input_file.close();
		}

		if( opt_dump_texts ) {
			docid_t from = ( opt_from > 0 ? opt_from : 1 );
			docid_t to   = ( opt_to   > 0 ? opt_to   : meta->doc_count() );
			doc_t doc;
			for( docid_t docid = from; docid <= to; docid++ ) {
				doc.docid = docid;
				meta->doc_retrieve( &(doc) );
				assert( doc.docid == docid );
				if( doc.status == STATUS_DOC_GATHERED && ( HTTP_IS_OK( doc.http_status ) ) ) {
					extract_dump_document( &(doc), _url, buf );
				}
			}
		}
	}
	  
	// Sketch (only if supported)
	
	if( (opt_dump_sketchall || opt_dump_sketch) && CONF_MANAGER_SCORE_LIVERANK_WEIGHT) {  
		char _url[MAX_STR_LEN];
		irudiko_sketch_t ist;
		irudiko_t *sketch = ist.sketch;

		strg = new Storage ( COLLECTION_TEXT, true );
		strg->st_open();
		
		docid_t ndocs = meta->doc_count();
		
		/* Managing both cases (--sketch <id>, and --sketches) */
		docid_t curdocid = (opt_dump_sketchall)?(opt_from > 0 ? opt_from : 1):opt_dump_sketch_docid;
		docid_t docid_end = (opt_dump_sketchall)?(opt_to > 0 ? opt_to : ndocs):opt_dump_sketch_docid;
	  
		/* Loop */
		for(; curdocid <= docid_end; ++curdocid)
		{
			url->url_by_docid( curdocid, _url );
			doc_t doc;
			doc.docid = curdocid;
			meta->doc_retrieve( &(doc) );
		
			/* Is a valid document? */
			if( doc.docid == curdocid && doc.status == STATUS_DOC_GATHERED && ( HTTP_IS_OK( doc.http_status ) ) )
			{
				strg->read_sketch( curdocid, sketch );

				// This is to ensure only significant sketches are returned
				bool is_empty_sketch = true;

				for(uint h = 0; h < IRUDIKO_SKETCHSIZE; ++h)
					if (sketch[h]!=0)
					{
						is_empty_sketch=false;
						break;
					}
		  
				if(!is_empty_sketch)
				{
					// Print docinfo + sketch
					cout << "<!-- DOCID: " << curdocid << " URL: " << _url << " -->" << endl;
					cout << "SKETCH: " << sketch[0];

					for(uint h = 1; h < IRUDIKO_SKETCHSIZE; ++h)
						  cout << ", " << sketch[h];

					cout << "." << endl;
				}
			}
		}
	}
	
	// Links
	if( opt_dump_links )
	{
		lidx = new Storage ( COLLECTION_LINK, true );
		lidx->st_open();

		docid_t ndocs = meta->doc_count();
		docid_t docid;

		char *ok = (char *)malloc(sizeof(char)*(ndocs+1));
		assert( ok != NULL );
		cerr << "Marking ok documents" << endl;
		doc_t doc;

		for( docid = 1; docid <= ndocs; docid++ )
		{
			doc.docid = docid;
			meta->doc_retrieve( &(doc) );

			if( doc.docid == docid && doc.status == STATUS_DOC_GATHERED && ( HTTP_IS_OK( doc.http_status ) || HTTP_IS_REDIRECT( doc.http_status ) ) )
				ok[docid] = 'X';
			else
				ok[docid] = ASCII_NUL; /* Null means omit */
		}

		cerr << "done" << endl;

		for( docid = 1; docid <= ndocs; docid++ )
		{
			if	(ok[docid] != ASCII_NUL)
				linkidx_dump_links_checking(lidx, docid, ok);
		}

		free(ok);
	}

	// Logged links
	if( opt_dump_logged_links ) {
		char input_filename[MAX_STR_LEN];
		char *line;
		line = (char *)malloc(sizeof(char)*MAX_STR_LEN*3);
		assert( line != NULL );

		int harvestid 	= 1;

		while(1) {
			ifstream input_file;
			sprintf( input_filename, "%s/%d%s", COLLECTION_LINK, harvestid, FILENAME_LINKS_LOG );
			cerr << "Opening links from harvest #" << harvestid << " ... ";
			input_file.open( input_filename );
			if( !input_file.is_open() ) {

				// Check for errors
				if( errno != ENOENT ) {
					perror( input_filename );
					die( "Couldn't open file" );
				}	

				// Ok, end
				cerr << "not found (ok)" << endl;
				break;
			}
			cerr << "ok" << endl;

			// Process file
			docid_t src_docid	= 0;
			doc_t src_doc;
			src_doc.docid		= 0;
			int rel_pos			= 0;
			int tag				= 0;
		//	int caption_length	= 0;
			char _url[MAX_STR_LEN];
			char caption[MAX_STR_LEN];
			char src_path[MAX_STR_LEN];
			

			while( ! input_file.eof() && input_file.getline(line,MAX_STR_LEN*2) ) {

				if( !
				   (sscanf( line, "%lu %d %d %s %[^\n]", ((unsigned long int *)(docid_t *)&(src_docid)), &rel_pos, &tag, _url, caption ) == 6 )
				   ) {
					assert( src_docid != 0 );
		//			caption_length = strlen(caption);
					assert( strlen(_url) != 0 );

					// Check if the source docid has changed
					if( src_docid != src_doc.docid ) {
						src_doc.docid	= src_docid;
						meta->doc_retrieve( &(src_doc) );


						// Save time by skipping documents at a 
						// different depth
						if( opt_depth == 0 || src_doc.depth == opt_depth ) {
							url->url_by_docid( src_doc.docid, src_path );
						}
					}

					// Check depth
					if( opt_depth == 0 || src_doc.depth == opt_depth ) {

						// Now we have a src_doc and a src_path
						assert( src_path != NULL );

						// The only think left is to resolve the link
						if( strchr( _url, '%' ) ) {
							unescape_url( _url );
						}

						if( opt_with_source_doc ) {
							cout << src_docid << " http://" << src_path << " -> ";
						}

						// Check if url has protocol
						if( ! strchr( _url, ':' ) ) {

							char absolute_path[MAX_STR_LEN];

							char source_path_cpy[MAX_STR_LEN];
							strcpy( source_path_cpy, src_path );

							// Relative url, fix
							 url->relative_path_to_absolute( source_path_cpy, _url, absolute_path );
							 cout << "http://" << absolute_path;


						} else {

							// Complete url, show
							cout << _url;

						}

						if( opt_with_caption ) {
							cout << " " << caption;
							caption[0] = '\0';
						}

						cout << endl;
					}

				} else {
						cerr << "* UNRECOGNIZED * " << line << endl;
				}
			}
			
			// Next filename
			input_file.close();
			harvestid++;
		}

	}

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}
}

//
// Name: cleanup
//
// Description: 
//   Closes files, indexes
//

void cleanup() {
	if( meta != NULL ) {
		meta->ddx_close();
		delete meta;
		cerr << "[metaddx] ";
	}
	if( url != NULL ) {
		url->ddx_close();
		delete url;
		cerr << "[urlddx] ";
	}
	if( lidx != NULL ) {
		lidx->st_close();
		delete lidx;
		cerr << "[linkidx] ";
	}
	if( strg != NULL ) {
		strg->st_close();
		delete strg;
		cerr << "[storage] ";
	}
}


void extract_dump_document( doc_t *doc, char *_url, char *buf ) {
	url->url_by_docid( doc->docid, _url );
	storage_status_t rc = strg->read_document( doc, buf );
	if( rc == STORAGE_OK ) {
		cout << "<!-- DOCID:" << doc->docid << " SIZE:" << doc->content_length << " " << _url << " -->" << endl;
		cout << buf << endl;
	}
}

//
// Name: extract_usage
//
// Description:
//   Prints an usage message, then stops
//

void extract_usage()
{
	cerr << "Usage: program [OPTION]" << endl;
	cerr << "Dumps the contents of the indices and structures" << endl;
	cerr << endl;
	cerr << " --doc, -d			dump doc information (slow!)" << endl;
	cerr << "	--from			first doc to show (default 1)" << endl;
	cerr << "	--to			  last doc to show (default last in collection)" << endl;
	cerr << "	--url			 dump list of urls (slow!)" << endl;
	cerr << "	--depth <n>	   only show urls of docs at that depth" << endl;
	cerr << "	--url-depth	   only show url and depth" << endl;
	cerr << "	--doc-url		 show url and dump doc information (slow!)" << endl;
	cerr << " --text <filename>	dump content, filename contains docids, one per line" << endl;
	cerr << " --texts			  dump content of documents specified by --from and --to" << endl;
	cerr << "	--from			first doc to show (default 1)" << endl;
	cerr << "	--to			  last doc to show (default last in collection)" << endl;
	cerr << " --sketch <docid>	 shows Irudiko sketch for document <docid>" << endl;
	cerr << " --sketches		   shows Irudiko sketch for documents" << endl;
	cerr << "	--from			first doc to show (default 1)" << endl;
	cerr << "	--to			  last doc to show (default last in collection)" << endl;
	cerr << endl;
	cerr << " --site, -s		   dump site information" << endl;
	cerr << " --seeds			  dump seeds for next collection" << endl;
	cerr << endl;
	cerr << " --links, -l		  dump links information (slow!)" << endl;
	cerr << " --sitelinks		  dumps the structure of site links" << endl;
	cerr << " --logged-links	   dumps urls of logged documents and statistics about" << endl;
	cerr << "					   the filename extensions (slow!)" << endl;
	cerr << "	--depth <n>	   only dump urls of logged documents with links" << endl;
	cerr << "					  from documents at depth <n>" << endl;
	cerr << "	--with-source-doc include the original url" << endl;
	cerr << "	--with-caption	include the textual caption" << endl;
	cerr << endl;
	cerr << " --harvest			dump information about harvests" << endl;
	cerr << " --docs-harvest <num> shows the url of the documents assigned" << endl;
	cerr << "					  to harvest number <num>" << endl;
	cerr << " --help, -h		   this help message" << endl;
	cerr << endl;
	cbot_stop(0);
}
