/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
/*  Italian stemmer tring to remove inflectional suffixes */
#include "italianstemmer.h"

int ItalianStemmer::do_stem (char * word, int len) {
	
	if (len > 4) {
		removeItalianAccent(word,len);
		if (word[len]=='e') {  /*  ending with -ie or -he  */
			if (word[len-1]=='i' || word[len-1]=='h') {
				word[len-1]='\0';
         		return (len-2);
        	}
      		word[len]='\0';  /*  ending with -e  */
      		return(len-1);
		}
   		if (word[len]=='i') {  /*  ending with -hi or -ii */
      		if ((word[len-1]=='h') || (word[len-1]=='i')) {
				word[len-1]='\0';
         		return (len-2);
        	}
      		word[len]='\0';  /*  ending with -i  */
      		return(len-1);
    	}
   		if (word[len]=='a') {  /*  ending with -ia  */
      		if (word[len-1]=='i') {
				word[len-1]='\0';
         		return (len-2);
        	}
      		word[len]='\0';  /*  ending with -a  */
      		return(len-1);
    	}
   		if (word[len]=='o') {  /*  ending with -io  */
      		if (word[len-1]=='i') {
         		word[len-1]='\0';
         		return (len-2);
        	}
      		word[len]='\0';  /*  ending with -o  */
      		return(len-1);
    	}
	} /* end if (len > 4) */ 
	return len;
}


int ItalianStemmer::removeItalianAccent(char * word, int len) {
	int i;
	
   	for(i=len; i>=0; i--) {
		if ((word[i]=='�') || (word[i]=='�') || (word[i]=='�') || (word[i]=='�')) {
         	word[i] = 'a';
        }
      	if ((word[i]=='�') || (word[i]=='�') || (word[i]=='�') || (word[i]=='�')) {
         	word[i] = 'o';
        }
      	if ((word[i]=='�') || (word[i]=='�') || (word[i]=='�') || (word[i]=='�')) {
         	word[i] = 'e';
        }
      	if ((word[i]=='�') || (word[i]=='�') || (word[i]=='�') || (word[i]=='�')) {
         	word[i] = 'u';
        }
      	if ((word[i]=='�') || (word[i]=='�') || (word[i]=='�') || (word[i]=='�')) {
         	word[i] = 'i';
        }
    }
   	return(0);
}
