/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
/* Default settings for Irudiko (0.5) */
#ifndef _IRUDIKO_H
#define _IRUDIKO_H

#include <config.h>

// Base settings (you can personalize it as far as you want!)
#define IRUDIKO_SKETCHSIZE     100
#define IRUDIKO_SELECTIONTYPE  2   // 1: Min function; 2: Mod function; 3: None
#define IRUDIKO_SELECTIONPARAM 0   // no param

// Header files (you need all of them)
#include "irudikosimplereader.h"

// Type redefinitions (CBOT implementation)
typedef unsigned long irudiko_t;
typedef struct {
  irudiko_t sketch[IRUDIKO_SKETCHSIZE];
} irudiko_sketch_t;

#endif
