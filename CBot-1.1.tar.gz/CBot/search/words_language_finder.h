/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

// Local libraries
#include "commons.h"
#include "xmlconf-main.h"
#include "dymddx.h"
#include "langddx.h"

// Constants
const size_t min_word_len = 1;

// Types
Meta		*meta;
Storage		*strg;
dymddx_t	*openddx;
langddx_t	*langddx;

// Globals

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

//const sequence_t **start_of_sequences = NULL;

docid_t opt_from;
docid_t opt_to;

dymmutex_t *wlock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
dymmutex_t *slock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
dymmutex_t *glock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico



//bool        indexupdate = false;
//bool        updatescores = false;
bool			debugonly = false;
bool			showlanguages = false;

// Functions
void words_language_finder_usage();
void *thread_function_create_dym(void *dummyPtr);
void *thread_function_counters_store(void *dummyPtr);
bool binder(doc_t *doc, char *buf);
void textFinder(doc_t *doc, const size_t min_word_len, pes_t *poutt, size_t content_len);
// Search word in text to elaborate
unsigned short wordFinder(doc_t *doc, char *, const size_t);
