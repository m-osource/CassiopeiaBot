/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

// Local libraries
#include "commons.h"
#include "xmlconf-main.h"
#include "Languages.h" // classe delle lingue, identifica la lingua di un documento.

typedef struct {
	// Duplicated (words of headings and content, without duplicated)
	char *dupl;								// Strings    [memory]
	off64_t *dupl_hash;                       // Hash table [memory]
	duplid_t dupl_count;					// Count      [memory]
	off64_t dupl_next_char;					// String Pos [memory]
	off64_t *dupl_list;                        // List       [memory]

	// Duplicated (words of metatags and url's words, without duplicated)
	char *meta;								// Strings    [memory]
	off64_t *meta_hash;                       // Hash table [memory]
	duplid_t meta_count;					// Count      [memory]
	off64_t meta_next_char;					// String Pos [memory]
	off64_t *meta_list;                        // List       [memory]
} langidx_instance_t;

// Types
Meta		*meta;
Storage		*strg;

docid_t opt_from;
docid_t opt_to;

//typedef struct {
//	unsigned int instance;
//} thread_struct_t;

//thread_struct_t *ts;
//
#define MAXTERMS 16000 // Deve poter contenere tutti i termini univoci presenti in un documento web

// Globals

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

//bool        indexupdate = false;
//bool        updatescores = false;
bool        debugonly = false;
bool        showlanguages = false;

//const char *relative_rem_path_prefix = "dataconnector";
//
// definizione dell'oggetto della clesse delle lingue
Languages la;


// Functions
//void infxidx_close(void);
//void readStaticTerms (termid_t *terms_split_offset, const size_t min_word_len, char *pexcluded, string helpstring);
void doc_language_finder_usage();
void *thread_function(void *dummyPtr);
bool binder(doc_t *doc, char *buf);
