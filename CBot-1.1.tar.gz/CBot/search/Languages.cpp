#include "commons.h"
#include "Languages.h"

off64_t LANGIDX_LANG_SIZE;
off64_t LANGIDX_WORD_SIZE;
off64_t LANGIDX_DUPL_SIZE;
off64_t LANGIDX_META_SIZE;

language_out_t **language_ranking_out;
     
bool Languages::index_setup (const size_t min_word_len, bool showlanguages)
{
	string confpath(CONF_COLLECTION_BASE);

	// inizializzo i valori dichiarati staticamente dentro la classe
	first_word_uid = 0;
	src_word_uid = 0;
	dst_word_uid = 0;
	mcline = 0;
	mcrule = 0;
	msline = 0;

	// apertura degli indici
	index_open();

	string null_string = "null";
	langid_t langid = 0;
	// inserimento stringa lingua fittizia, utile nel caso i termini non siano attribuibili ad una lingua
	langidx_resolve_lang( null_string.c_str(), &(langid), false );

	cerr << "Make languages index ..." << endl;

	string config_filename = (confpath + "/" + "languages.conf");

	if (config_filename.length() > 0)
	{
		unsigned int length;
		char *inbuf;
	
		ifstream inFile;  //input file stream variable
		inFile.open(config_filename); //open the input file

	 	if (inFile)
		{	
		// posiziona in cursore alla fine del file per rilevarne la lunghezza per poi riposizionarlo all'inizio:
			inFile.seekg (0, ios::end);
			length = inFile.tellg();
			inFile.seekg (0, ios::beg);
		
			// alloca la memoria del inbuf:
			inbuf = (char *) malloc ((length + 1) * sizeof(char));
		
			// legge i dati in un unico blocco:
			inFile.read (inbuf,length);
			inbuf[length] = ASCII_NUL;
	
			//cout.write (inbuf,length);
			unsigned short nc = 0;

			unsigned short line = 0;

			languages_counter = 0;

			words_counter = 0;

			terms_count = 0;

			bool language_check = true;
			bool is_language = false;

			size_t lang_buffer_len = 0;

			size_t word_buffer_len = 0;

			// creo gli indici delle tematiche e dei termini (parole) delle lingue (quelli dopo la '|')
			for (size_t i = 0; i < length; i++)
			{

				if (inbuf[i] == ASCII_NU)
				{
					while (inbuf[i] != ASCII_NL && inbuf[i] != ASCII_NUL)
						i++;

					line++;

					continue;
				}

				if (inbuf[i] == ASCII_PP)
				{
					while (inbuf[i] == ASCII_PP || inbuf[i] == ASCII_SP)
						i++;

					language_check = false;
				}

				static char temparray[MAX_STR_LEN] = {ASCII_NUL};


				if (i == (length - 1))
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != ASCII_NUL)
						mcrule++;

						if (language_check == true)
							is_language = true;

						mcline = line;
					}

					if (is_language == true)
					{
						makeContexts(temparray, min_word_len, is_language, false);

						lang_buffer_len += nc;

						is_language = false;

						languages_counter++;
					}
					else
					{
						makeContexts(temparray, min_word_len, is_language, false);

						word_buffer_len += nc;

						words_counter++;
					}

					first_word_uid = 0;

					terms_count++;

					nc = 0;
				}
				else if (inbuf[i] != ASCII_NL && inbuf[i] != ASCII_SP)
				{
					temparray [nc++] = inbuf[i];
				}
				else
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != ASCII_NUL)
						mcrule++;

						if (language_check == true)
							is_language = true;

						mcline = line;
					}

					if (is_language == true)
					{
						makeContexts(temparray, min_word_len, is_language, false);

						lang_buffer_len += nc;

						is_language = false;

						languages_counter++;
					}
					else
					{
						makeContexts(temparray, min_word_len, is_language, false);

						word_buffer_len += nc;

						words_counter++;
					}

					if (inbuf[i] == ASCII_NL)
					{
						if (line >= UINT_MAX)
							die ("Error: Too many lines in configuration file of contexts!");
						else
							line++;

						first_word_uid = 0;
						language_check = true;
					}

					terms_count++;

					nc = 0;
				}
			}

			// ora che si conosce la quantità di regole nel file principale si possono creare le strutture necessarie a ricavare gli offset in main_buffer
			main_structs = (main_t *) malloc (mcrule * sizeof(main_t));

			main_buffer = (context_t *) malloc (terms_count * sizeof(context_t));

			// si impostano i valori iniziali delle strutture 'main_t' puntate da main_struct
			// la prima struttura puntata NON si utilizza in quanto corrisponderebbe al wordid '0'!
			for (unsigned short i = 0; i < mcrule; i++)
			{
				main_structs[i].rule_offset = 0;
				main_structs[i].language = 0;
				main_structs[i].terms = 0;
			}

			line = 0;
			mcline = 0;
			mcrule = 0;

			terms_counter = 0;

			language_check = true;
			is_language = false;

			// popola il buffer principale (main_buffer) che incorpora la configurazione nel formato della struttura tipo context_t
			for (size_t i = 0; i < length; i++)
			{
				if (inbuf[i] == ASCII_NU)
				{
					while (inbuf[i] != ASCII_NL && inbuf[i] != ASCII_NUL)
						i++;

					line++;

					continue;
				}

				if (inbuf[i] == ASCII_PP)
				{
					while (inbuf[i] == ASCII_PP || inbuf[i] == ASCII_SP)
						i++;

					language_check = false;
				}

				static char temparray[MAX_STR_LEN] = {ASCII_NUL};

				// setto la struttura puntata ai valori iniziali
				main_buffer[terms_counter].rule = false;
				main_buffer[terms_counter].is_language = false;
				main_buffer[terms_counter].generic_id = (wordid_t)0;

				if (i == (length - 1))
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != ASCII_NUL)
						{
							mcrule++;
							main_structs[(mcrule - 1)].rule_offset = terms_counter;
						}

						if (language_check == true)
							is_language = true;
						
						mcline = line;
					}

					if (is_language == true)
					{
						makeContexts(temparray, min_word_len, is_language, true);
						is_language = false;

						// Le tematiche non vengono contate come termini (vedi esempio opposto sotto)
					}
					else
					{
						makeContexts(temparray, min_word_len, is_language, true);
						main_structs[(mcrule - 1)].terms++;

						if (main_structs[(mcrule - 1)].terms < USHRT_MAX)
							main_structs[(mcrule - 1)].terms++;
						else
						{
							cerr << "Error: Too many terms in configuration file of contexts at rule ";
							cerr << (mcrule - 1) << " (line " << mcline << ')' << endl;
						}
					}

					first_word_uid = 0;

					nc = 0;
				}
				else if (inbuf[i] != ASCII_NL && inbuf[i] != ASCII_SP)
				{
					temparray [nc++] = inbuf[i];
				}
				else
				{
					temparray [nc] = ASCII_NUL; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != ASCII_NUL)
						{
							mcrule++;
							main_structs[(mcrule - 1)].rule_offset = terms_counter;
						}

						if (language_check == true)
							is_language = true;

						mcline = line;
					}

					if (is_language == true)
					{
						makeContexts(temparray, min_word_len, is_language, true);
						is_language = false;

						// Le tematiche non vengono contate come termini (vedi esempio opposto sotto)
					}
					else
					{
						makeContexts(temparray, min_word_len, is_language, true);

						if (main_structs[(mcrule - 1)].terms < USHRT_MAX)
							main_structs[(mcrule - 1)].terms++;
						else
						{
							cerr << "Error: Too many terms in configuration file of contexts at rule ";
							cerr << (mcrule - 1) << " (line " << mcline << ')' << endl;
						}
					}

					if (inbuf[i] == ASCII_NL)
					{
						if (line >= UINT_MAX)
							die ("Error: Too many lines in configuration file of contexts!");
						else
							line++;

						first_word_uid = 0;
						language_check = true;
					}

					nc = 0;
				}
			}

			inFile.close();
			free (inbuf);

			th_dist_st = (language_vs_main_rules_t *) malloc ((openidx->lang_count + 1) * sizeof(language_vs_main_rules_t));

			th_dist = (unsigned short *) malloc (languages_counter * sizeof(unsigned short));

			languages_counter = 0;

			// il langid '0' non si utilizza
			th_dist_st[0].th_dist_offset = (unsigned int)UINT_MAX;

			// crea lo schema di distribuzione nelle regole (rules) del main_buffer, delle tematiche
			for (langid_t langid = 1; langid <= openidx->lang_count; langid++)
			{
				bool isoffset = true;

				th_dist_st[langid].th_dist_offset = (unsigned int)UINT_MAX;

				unsigned int old_th_dist_offset = (unsigned int)UINT_MAX;

				if (langid > 1)
					old_th_dist_offset = th_dist_st[langid - 1].th_dist_offset;

				for (unsigned long int i = 0; i < terms_counter; i++)
				{
					if (main_buffer[i].is_language == true && main_buffer[i].generic_id == langid)
					{
						if (isoffset == true)
						{
							th_dist_st[langid].th_dist_offset = languages_counter;

							if ((th_dist_st[langid].th_dist_offset - old_th_dist_offset) >= UCHAR_MAX)
							{
								char *language = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));

								langidx_lang_by_langid(langid, language);

								cerr << "Too many rule for tematic " << language << " in main configuration file!" << endl;

								free (language);

								exit(1);
							}

							isoffset = false;
						}

						th_dist[languages_counter] = main_buffer[i].rule;
						languages_counter++;
					}
							
				}	
			}

			wdist_st = (word_vs_main_rules_t *) malloc ((openidx->word_count + 1) * sizeof(word_vs_main_rules_t));

			wdist = (idx_id_vs_rules_t *) malloc (words_counter * sizeof(idx_id_vs_rules_t));

			words_counter = 0;

			// lo wordid '0' non si utilizza
			wdist_st[0].wdist_offset = (unsigned int)UINT_MAX;

			// crea lo schema di distribuzione nelle regole (rules) del main_buffer, dei termini (parole)
			for (wordid_t wordid = 1; wordid <= openidx->word_count; wordid++)
			{
				bool isoffset = true;

				wdist_st[wordid].wdist_offset = (unsigned int)UINT_MAX;

				unsigned int old_wdist_offset = (unsigned int)UINT_MAX;

				if (wordid > 1)
					old_wdist_offset = wdist_st[wordid - 1].wdist_offset;
				else
					old_wdist_offset = 0;

				for (unsigned long int i = 0; i < terms_counter; i++)
				{
					if (main_buffer[i].is_language == false && main_buffer[i].generic_id == wordid)
					{
						if (isoffset == true)
						{
							wdist_st[wordid].wdist_offset = words_counter;

							if ((wdist_st[wordid].wdist_offset - old_wdist_offset) >= UCHAR_MAX)
							{

								char *word = (char *) malloc ((MAX_BYTES_WORD_LEN + 1) * sizeof(char));

								langidx_word_by_wordid(wordid, word);

								cerr << "Too many rule for word " << word << " in main configuration file!" << endl;

								free (word);

								exit(1);
							}

							isoffset = false;
						}

						wdist[words_counter].rule = main_buffer[i].rule;
						words_counter++;
					}
							
				}	
			}

			// calcolo coefficenti distribuzione termini (parole) di lingua
			for (wordid_t wordid = 1; wordid <= openidx->word_count; wordid++)
				if (wdist_st[wordid].wdist_offset < UINT_MAX)
				{
					unsigned char amount_rules = 0;

					if (wordid < openidx->word_count)
						amount_rules = (wdist_st[wordid + 1].wdist_offset - wdist_st[wordid].wdist_offset);
					else
						amount_rules = (words_counter - wdist_st[wordid].wdist_offset);

					struct lang {
						langid_t language;
						unsigned short count;
					} *langs = (lang *) malloc (amount_rules * sizeof(lang));

					bool found = false;

					unsigned char pos = 0;

					for (unsigned char a = 0; a < amount_rules; a++)
						langs[a].language = 0;

					for (unsigned char a = 0; a < amount_rules; a++)
					{
						for (unsigned char b = 0; b < amount_rules; b++)
						{
							if (langs[b].language == main_structs[wdist[(wdist_st[wordid].wdist_offset + a)].rule].language)
							{
								found = true;
								langs[b].count++;
								break;
							}
						}

						if (found == false)
						{
							langs[pos].language = main_structs[wdist[(wdist_st[wordid].wdist_offset + a)].rule].language;

							langs[pos].count = 1;
							pos++;
						}
						else
							found = false;
					}

					unsigned short ttfs = 0; // total languages for wordid

					for (unsigned char a = 0; a < amount_rules && langs[a].language > 0; a++)
						ttfs++;

					for (unsigned char a = 0; a < amount_rules; a++)
					{
						langid_t language = main_structs[wdist[(wdist_st[wordid].wdist_offset + a)].rule].language;

						unsigned char lang_address = 0;

						for (lang_address = 0; lang_address < amount_rules && langs[lang_address].language > 0; lang_address++)
							if (language == langs[lang_address].language)
								break;

						// se la tematica è 'null' non si calcola la distribuzione dentro la tematica nulla
						if (language == (langid_t)1) // null
							wdist[(wdist_st[wordid].wdist_offset + a)].location_coefficient = ttfs;
						else
							wdist[(wdist_st[wordid].wdist_offset + a)].location_coefficient = ttfs * langs[lang_address].count;
					}
/*// uso debug
					//char *ppp = (char *) malloc ((MAX_BYTES_WORD_LEN + 1) * sizeof(char));
					//langsidx_word_by_wordid(wordid, ppp);
					//cout << endl;
					//free (ppp);
*/////
					free (langs);
				}

			/*/// debug
			for (wordid_t wordid = 1; wordid <= openidx->word_count; wordid++)
				if (wdist_st[wordid].wdist_offset < UINT_MAX)
						cout << "Word id " << wordid << " offset of rule start in main_buffer "
						<< wdist_st[wordid].wdist_offset << endl;

			for (langid_t langid = 1; langid <= openidx->lang_count; langid++)
				if (th_dist_st[langid].th_dist_offset < UINT_MAX)
						cout << "Language id " << langid << " offset of rule start in main_buffer "
						<< th_dist_st[langid].th_dist_offset << endl;
			*//// fine debug //
		}
		else
		{
			cerr << "Error: file " << config_filename << " not found!" << endl;
			index_close (false);
			return false;
		}
	}

	// se è stata scelta la relativa opzione in combinazione con 'debugonly' stampa le tematiche ed esce immediatamente
	if (showlanguages == true)
	{
		cerr << "Print languages and exit..." << endl;

		unsigned short oldrule = 0;
		bool is_word = false;

		for (unsigned short s = 0; s < terms_counter; s++)
		{
			if (s == 0)
				cout << "regola 0 ";

			if (main_buffer[s].rule > oldrule)
			{
				cout << endl;
				oldrule = main_buffer[s].rule;
				cout << "regola " << main_buffer[s].rule << ' ';
				is_word = false;
			}

			if (main_buffer[s].is_language == true)
			{
				char *language = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));

				langidx_lang_by_langid(main_buffer[s].generic_id, language);

				cout << language;

				free (language);

				cout << ' ';
			}
			else if (main_buffer[s].is_language == false)
			{
				if (is_word == false)
				{
					cout << '|';
					is_word = true;
				}

				char *wordname = (char *) malloc ((MAX_BYTES_WORD_LEN + 1) * sizeof(char));
				wordname[0] = ASCII_NUL;

				langidx_word_by_wordid(main_buffer[s].generic_id, wordname);

				cout << ' ' << wordname;

				free (wordname);
			}
			//	cout << ' ' << main_buffer[s].generic_id << endl;
		}

		cout << endl;

		return true;
	}

	language_ranking_out = (language_out_t **)malloc(CONF_COLLECTION_DISTRIBUTED * sizeof(language_out_t *));
	assert( language_ranking_out != NULL );

	instidx = (langidx_instance_t **)malloc(CONF_COLLECTION_DISTRIBUTED * sizeof(langidx_instance_t *));
	assert( instidx != NULL );

	// assegno la memoria al buffer del ranking che racchiude 'regole e relativi ranking) posizionati in coppie affiancate
	ranking_buffer = (ranking_t **) malloc (CONF_COLLECTION_DISTRIBUTED * sizeof(ranking_t *));
	assert( ranking_buffer != NULL );

	language_ranking = (unsigned long int **) malloc (CONF_COLLECTION_DISTRIBUTED * sizeof(unsigned long int *));
	assert( language_ranking != NULL );

	return true;
}

//
// Name: Languages::makeContexts 
//
// Description: Riceve i contesti ed eventuali tematiche dal file di configurazione principale contexts.conf e crea la struttura dei contesti
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola, numero linea nel file.
//
void Languages::makeContexts(char *ptext, const size_t min_word_len, bool is_language, bool append_buffer)
{
	const bool str_tolower = true; // convert string to lower char

	str_handler_t *conv = str_handler( (const char *)ptext, str_tolower );

	size_t wordlen = 0;
	size_t reallength = 0;

	if (conv->wcslen == 0)
	{
		wordlen = conv->mbslen;
		reallength = conv->mbslen;
	}
	else
	{
		wordlen = conv->wcslen;
		reallength = conv->mbslen;
	}

	langidx_status_t trc = LANGIDX_ERROR;
	langidx_status_t src = LANGIDX_ERROR;

	langid_t langid = 0;
	wordid_t wordid = 0;

	// quì va salvato tutto
	// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
	// in quanto non si tratta di una parola
//				if ( ! (reallength == 3 && strcmp(conv->handled, "amp") == 0)) // equivale ad unless in perl
	if (conv->handled != NULL && wordlen >= min_word_len && wordlen < MAX_WORD_LEN)
	{
		if (is_language == true)
		{
			if (reallength == 2)
			{
			if (append_buffer == false)
			{
				// Se il programma NON indica che il termine NON è già stato utilizzato allora si può procedere
				langidx_resolve_lang( conv->handled, &(langid), false );
			}
			else
			{
				trc = langidx_resolve_lang( conv->handled, &(langid), true );

				main_structs[(mcrule - 1)].language = langid;

				if (trc == LANGIDX_EXISTENT)
				{
					main_buffer[terms_counter].rule = (mcrule - 1);
					main_buffer[terms_counter].is_language = is_language;
					main_buffer[terms_counter].generic_id = (wordid_t)langid;

					terms_counter++;
				}
			}
			}
			else
				cerr << "Invalid language " << conv->handled << endl;
		}
		else
		{
			src = langidx_resolve_word( conv->handled, &(wordid), false );

			if (append_buffer == true)
			{
				if (src == LANGIDX_EXISTENT)
				{
					main_buffer[terms_counter].rule = (mcrule - 1);
					main_buffer[terms_counter].generic_id = wordid;

					terms_counter++;
				}
			}
		}
	}

	free (conv->handled);
	free (conv);
}

//
// Name: Languages::checkLanguageWord 
//
// Description: Controlla se la parola in input fa parte di una lingua in 'languages.conf' e la inserisce nell'indice temporaneo

//
// Argomenti: puntatore a parola da elaborare, limite minimo lunghezza parola.
//
unsigned short Languages::checkLanguageWord(unsigned int instance, char *ptext, const size_t min_word_len, bool stop_ranking, bool in_domain, bool is_clevel) const
{
	size_t full_length = strlen(ptext);

	unsigned short words_counter = 0; // ad ogni chiamata di funzione viene restituito il numero di parole elaborato

	// rimuove eventuali spazi in coda
	while (isspace(ptext[full_length - 1]) && full_length > 0)
		full_length--;

	size_t pos = 0;
	char *elaborate = (char *) malloc ((MAX_BYTES_WORD_LEN + 1) * sizeof(char));
	// elaborate deve poter contenere un numero di multibyte caratteri pari MAX_BYTES_WORD_LEN + '\0'

	if (full_length > min_word_len)
	do
	{ // ciclo while che estrapola le parole dal testo separato dai caratteri verificati dalla funzione 'isspace(char)'
		while (ptext[pos] != ASCII_NUL && isspace(ptext[pos]) == true)
				pos++;

		size_t c = 0;

		while (ptext[pos] != ASCII_NUL && isspace(ptext[pos]) == false)
		{
			elaborate[c] = ptext[pos];
			c++;
			pos++;
		}

		elaborate[c] = ASCII_NUL;

		const bool str_tolower = true; // convert string to lower char

		str_handler_t *conv = str_handler( (const char *)elaborate, str_tolower );

		size_t wordlen = 0; // indica il numero di caratteri visibili (compresi caratteri UTF8) nella parola
		size_t reallength = 0; // indica il numero di bytes nella parola

		if (conv->wcslen == 0)
		{
			wordlen = conv->mbslen;
			reallength = conv->mbslen;
		}
		else
		{
			wordlen = conv->wcslen;
			reallength = conv->mbslen;
		}

		if (words_counter < (USHRT_MAX - 1))
			words_counter++;

		langidx_status_t mrc = LANGIDX_ERROR;
		langidx_status_t trc = LANGIDX_ERROR;
		langidx_status_t src = LANGIDX_ERROR;
		langidx_status_t drc = LANGIDX_ERROR;

		metaid_t metaid = 0;
		langid_t langid = 0;
		wordid_t wordid = 0;
		duplid_t duplid = 0;

		if (conv->handled != NULL && wordlen < MAX_WORD_LEN && wordlen > min_word_len && reallength < MAX_BYTES_WORD_LEN)
		{
			if (in_domain == true)
				// aggiunge il termine se non presente, all'indice delle meta words
				mrc = langidx_resolve_meta( instance,  conv->handled, &(metaid), false );
			else
				// verifica se il termine è gia stato elaborato
				drc = langidx_resolve_dupl( instance,  conv->handled, &(duplid), false );
							
			// verifica prima se il termine è una lingua
			//if ((reallength == 2) || ((reallength == 4) && (strcmp(conv->handled, "null") != 0)))
			//	trc =  langidx_resolve_lang( conv->handled, &(langid), true );

			src = langidx_resolve_word( conv->handled, &(wordid), true );

			if (in_domain == false)
			{
				if (drc == LANGIDX_CREATED_DUPL && stop_ranking == false)
				{
					// punteggio a headings nel contenuto
					if (duplid < language_ranking_out[instance]->duplicates_split_offset[0])
					{
						if (trc == LANGIDX_EXISTENT)
							rankingAllocation(instance, (wordid_t)langid, true, true);

						if (src == LANGIDX_EXISTENT)
							rankingAllocation(instance, wordid, true, false);
					}
					else
					{
						if (trc == LANGIDX_EXISTENT)
							rankingAllocation(instance, (wordid_t)langid, false, true);

						if (src == LANGIDX_EXISTENT)
							rankingAllocation(instance, wordid, false, false);
					}
				}
			}
			else
			{
				if (mrc == LANGIDX_CREATED_META)
				{
					// punteggio a headings nel contenuto
					if (is_clevel == false) // punteggio trattato come headings nel contenuto
					{
						if (trc == LANGIDX_EXISTENT)
							rankingAllocation(instance, (wordid_t)langid, true, true);

						if (src == LANGIDX_EXISTENT)
							rankingAllocation(instance, wordid, true, false);
					}
					else
					{
						if (trc == LANGIDX_EXISTENT)
							rankingAllocation(instance, (wordid_t)langid, false, true);

						if (src == LANGIDX_EXISTENT)
							rankingAllocation(instance, wordid, false, false);
					}
				}
			}
		}

		free (conv->handled);
		free (conv);
	}
	while (pos++ < (full_length - min_word_len));

	free(elaborate);

	return words_counter;
}

void Languages::rankingAllocation(unsigned int instance, wordid_t id, bool is_heading, bool is_language) const
{
	unsigned int rank_limit = (UINT_MAX - USHRT_MAX);

	unsigned short HEADING_AWARD = 30; // valore aggiunto in percentuale se il termine si trova nel puntatore poutt->headings

	if (is_language == true)
	{
		langid_t langid = id;

		unsigned char amount_rules = 0;

		unsigned int rank = 0;

		if (langid < openidx->lang_count)
			amount_rules = (th_dist_st[langid + 1].th_dist_offset - th_dist_st[langid].th_dist_offset);
		else
			amount_rules = (languages_counter - th_dist_st[langid].th_dist_offset);
			// languages_counter indica la lunghezza del buffer th_dist

		if (amount_rules > 0)
		{
			if (is_heading == true)
				rank = (USHRT_MAX + ((USHRT_MAX / 100) * HEADING_AWARD / 2));
			else
				rank = USHRT_MAX;

			rank_limit = (UINT_MAX - rank); // imposta il valore massimo del ranking
		}

		for (unsigned char a = 0; a < amount_rules; a++)
		{
			unsigned char i;

			bool ranking_assigned = false;

			for (i = 0; i < RBSIZE; i++)
			{
				if (ranking_buffer[instance][i].rule == USHRT_MAX)
					break;
	
				if (ranking_buffer[instance][i].rule == th_dist[(th_dist_st[langid].th_dist_offset + a)])
				{
					// non deve superare il limite del tipo dato
					if (ranking_buffer[instance][i].lang_ranking >= (rank_limit - 1))
						return;

					ranking_buffer[instance][i].lang_ranking += rank;

					ranking_assigned = true;

					break;
				}
			}

			// non è stata trovata la regola nel ranking_buffer[instance] ma esiste lo spazio per inserirla
			if (ranking_assigned == false && i < (RBSIZE - 1))
			{
				// non deve superare il limite del tipo dato
				if (ranking_buffer[instance][i].lang_ranking >= (rank_limit - 1))
					return;

				ranking_buffer[instance][i].lang_ranking += rank;

				ranking_buffer[instance][i].rule = th_dist[(th_dist_st[langid].th_dist_offset + a)];

				language_ranking_out[instance]->ranked_rules++;
			}
		}
		/* debug purpose
		char *language = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));
		langidx_lang_by_langid(langid, language);
		cout << language << '-' << langid << '-' << '-' << is_heading << '-' <<  is_language << endl;
		free(language);
		*/
	}
	else
	{
		wordid_t wordid = id;

		unsigned char amount_rules = 0;

		unsigned int rank_max = 0;

		unsigned int rank = 0;

		if (wordid < openidx->word_count)
			amount_rules = (wdist_st[wordid + 1].wdist_offset - wdist_st[wordid].wdist_offset);
		else
			amount_rules = (words_counter - wdist_st[wordid].wdist_offset);
			// words_counter indica la lunghezza del buffer wdist

		if (amount_rules > 0)
		{
			if (is_heading == true)
				rank_max = (USHRT_MAX + ((USHRT_MAX / 100) * HEADING_AWARD));
			else
				rank_max = USHRT_MAX;
		}

		for (char a = 0; a < amount_rules; a++)
		{
			unsigned char i;

			bool ranking_assigned = false;

			// imposta il valore massimo del ranking. In quante tematiche e in quante regole dentro tali tematiche del file pricipale
			// è presente il termine, in tal caso perde valore
			rank = rank_max / wdist[(wdist_st[wordid].wdist_offset + a)].location_coefficient;

			rank_limit = (UINT_MAX - rank);

			for (i = 0; i < RBSIZE; i++)
			{

				if (ranking_buffer[instance][i].rule == USHRT_MAX)
						break;
	
				if (ranking_buffer[instance][i].rule == wdist[(wdist_st[wordid].wdist_offset + a)].rule)
				{
					// non deve superare il limite del tipo dato
					if (ranking_buffer[instance][i].ranking >= (rank_limit - 1))
						return;

					ranking_buffer[instance][i].ranking += rank;

					ranking_assigned = true;

					break;
				}
			}

			// non è stata trovata la regola nel ranking_buffer[instance] ma esiste lo spazio per inserirla
			if (ranking_assigned == false && i < (RBSIZE - 1))
			{
				// non deve superare il limite del tipo dato
				if (ranking_buffer[instance][i].ranking >= (rank_limit - 1))
					return;

				ranking_buffer[instance][i].rule = wdist[(wdist_st[wordid].wdist_offset + a)].rule;

				ranking_buffer[instance][i].ranking += rank;

				language_ranking_out[instance]->ranked_rules++;
			}
		}
		/* debug purpose
		char *word = (char *) malloc ((MAX_BYTES_WORD_LEN + 1) * sizeof(char));
		langidx_word_by_wordid(wordid, word);
		cout << word << '-' << wordid << endl;
		free(word);
		*/
	}
}

//
// Name: Languages::make_analisys_index
//
// Description: Crea e l'indice temporaneo necessario per contenere gli id numerici dei termini (parole) e ne permette il popolamento
//
// Argomenti: numero instanza, lunghezza minima del termine, struttura poutt, lunghezza di 'poutt->content'
//
// Restituisce: 
//
void Languages::make_analisys_index (unsigned int instance, const size_t min_word_len, pes_t *poutt, size_t content_len) const
{
	language_ranking_out[instance] = (language_out_t *)malloc(sizeof(language_out_t));
	assert( language_ranking_out[instance] != NULL );

	instidx[instance] = (langidx_instance_t *)malloc(sizeof(langidx_instance_t));
	assert( instidx[instance] != NULL );

	ranking_buffer[instance] = (ranking_t *) malloc (RBSIZE * sizeof(ranking_t));
	assert( ranking_buffer[instance] != NULL );

	language_ranking[instance] = (unsigned long int *) malloc ((openidx->lang_count + 1) * sizeof(unsigned long int));
	assert( language_ranking[instance] != NULL );

	// creazione indici con durata limitata all'esecuzione della funzione
	//
	instidx[instance]->dupl_hash = (off64_t *)malloc(sizeof(off64_t)*MAXDUPLICATES);
	assert( instidx[instance]->dupl_hash != NULL );

	// Clean hash tables
	for( duplid_t i=0; i<MAXDUPLICATES; i++ ) {
		instidx[instance]->dupl_hash[i] = (off64_t)0;
	}

	// Set default values
	instidx[instance]->dupl_count = 0;
	instidx[instance]->dupl_next_char = 1; // start in 1

	// dupl_list
	instidx[instance]->dupl_list = (off64_t *) malloc ((MAXDUPLICATES + 1) * sizeof(off64_t));

	// Create memory area for word names
	LANGIDX_DUPL_SIZE = LANGIDX_EXPECTED_DUPL_SIZE * MAXDUPLICATES;
	instidx[instance]->dupl = (char *)malloc((sizeof(char))*LANGIDX_DUPL_SIZE);
	assert( instidx[instance]->dupl != NULL );
	instidx[instance]->dupl[0] = ASCII_NUL;

	// assegna memoria ai puntatori nella struttura che riassume il risultato che restituisce la classe delle tematiche
	language_ranking_out[instance]->language = (char *) malloc ((sizeof("null") + 1) * sizeof(char));
	language_ranking_out[instance]->language[0] = ASCII_NUL;

	language_ranking_out[instance]->ranked_rules = 0;

	language_ranking_out[instance]->ranked_languages = 0;

	language_ranking_out[instance]->ranking = 0;
	// fine assegnazione memoria

	// indica i limiti di numerazione degli id di duplicati
	// (gli id relativi a termini inseriti anche negli headings saranno inferiori a language_ranking_out[instance]->duplicates_split_offset[0])
	language_ranking_out[instance]->duplicates_split_offset[0] = (duplid_t)0;
	language_ranking_out[instance]->duplicates_split_offset[1] = (duplid_t)0;

	// inserisco i valori iniziali nel buffer del ranking
	for (unsigned int i = 0; i < RBSIZE; i++)
	{
		ranking_buffer[instance][i].rule = USHRT_MAX;
		ranking_buffer[instance][i].ranking = 0;
		ranking_buffer[instance][i].lang_ranking = 0;
	}

	for (langid_t langid = 0; langid <= openidx->lang_count; langid++)
		language_ranking[instance][langid] = 0;

	// Inizio lettura stdin
	bool content_readed = false;
	char *elaborate = (char *) malloc ((MAX_BYTES_WORD_LEN + 1) * sizeof(char));
	elaborate[0] = ASCII_NUL;
	size_t elaborate_offset = 0;
	size_t offset = 0;

	bool stop_ranking = false;
	const bool in_domain = false;
	const bool is_clevel = false;

	duplid_t valid_words = ((double)((double)(content_len / PRATICAL_WORD_SIZE) / 100) * TEXTCHUNK); // parole dentro la parte di contenuto da analizzare

	unsigned int words_counter = 0;

	char *buffer = poutt->headings;

	run_again:

	if (buffer != NULL && buffer[0] != ASCII_NUL) // se esistono headings, questi si inseriscono prima nei duplicati
	{
		while(buffer[offset] != ASCII_NUL)
		{
			if (! isspace(buffer[offset]))
			{
				if (elaborate_offset >= MAX_BYTES_WORD_LEN) // skip whole string to next space
				{
					elaborate_offset = 0;
					elaborate[elaborate_offset] = ASCII_NUL;

					while (! (buffer[offset] == ASCII_NUL || isspace(buffer[offset])))
						offset++;

					continue;
				}
				else
				{
					elaborate[elaborate_offset++] = buffer[offset];
					elaborate[elaborate_offset] = ASCII_NUL;
				}

			}
			else
			{
				if (elaborate_offset > 1)
				{
					if (elaborate_offset <= MAX_BYTES_WORD_LEN)
					{
						if (content_readed == false)
							checkLanguageWord(instance, elaborate, min_word_len, stop_ranking, in_domain, is_clevel);
						else
						{
						if (words_counter > valid_words)
							stop_ranking = true;

						if (words_counter < (UINT_MAX - USHRT_MAX)) // USHRT_MAX perchè al massimo la funzione 'checkLanguageWord' restituisce al max USHRT_MAX
							words_counter += checkLanguageWord(instance, elaborate, min_word_len, stop_ranking, in_domain, is_clevel);
						else
							checkLanguageWord(instance, elaborate, min_word_len, stop_ranking, in_domain, is_clevel);
						}

						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
					}
				}
				else
				{
						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
				}
			}

			offset++;
		}

		if (content_readed == true)
			if (words_counter > valid_words)
				stop_ranking = true;

		if (elaborate_offset > min_word_len && elaborate_offset <= MAX_BYTES_WORD_LEN)
			checkLanguageWord(instance, elaborate, min_word_len, stop_ranking, in_domain, is_clevel);

		if (content_readed == false)
			language_ranking_out[instance]->duplicates_split_offset[0] = instidx[instance]->dupl_count; // a tutti i duplicati con id inferiori a questo (headings) verrà assegnato un punteggio maggiore
	}

	if (poutt->content != NULL && poutt->content[0] != ASCII_NUL && content_readed == false) 
	{
		elaborate[0] = ASCII_NUL;
		elaborate_offset = 0;
		offset = 0;
		buffer = poutt->content;
		content_readed = true;
		goto run_again;
	}

	language_ranking_out[instance]->duplicates_split_offset[1] = instidx[instance]->dupl_count;

	free (elaborate);
}

//
// Name: Languages::index_analisys_read 
//
// Description: Analizza l'indice temporaneo allo scopo di restituire la lingua utilizzata nello stesso
//
// Argomenti: numero instanza
//
// Restituisce: la struttura con le statistiche del ranking
//
language_out_t *Languages::index_analisys_read (unsigned int instance) const
{
	// creazione indici con durata limitata all'esecuzione della funzione
	//
	instidx[instance]->meta_hash = (off64_t *)malloc(sizeof(off64_t)*MAXMETA);
	assert( instidx[instance]->meta_hash != NULL );

	// Clean hash tables
	for( metaid_t i=0; i<MAXMETA; i++ ) {
		instidx[instance]->meta_hash[i] = (off64_t)0;
	}

	instidx[instance]->meta_count = 0;
	instidx[instance]->meta_next_char = 1; // start in 1

	// meta_list
	instidx[instance]->meta_list = (off64_t *) malloc ((MAXMETA + 1) * sizeof(off64_t));

	// Create memory area for word names
	LANGIDX_META_SIZE = LANGIDX_EXPECTED_META_SIZE * MAXMETA;
	instidx[instance]->meta = (char *)malloc((sizeof(char))*LANGIDX_META_SIZE);
	assert( instidx[instance]->meta != NULL );
	instidx[instance]->meta[0] = ASCII_NUL;

	duplid_t realmaxduplicates = ((MAXDUPLICATES / 100) * 80); // il numero massimo dei termini negli indici ebbene non superi mai l'80% del teorico (vedi LANGIDX_MAX_OCCUPANCY)

	if (language_ranking_out[instance]->ranked_rules == 0)
	{
		language_ranking_out[instance]->ranking = 0;

        	// Close and nullify all the filehandlers
		free( instidx[instance]->dupl_list ); instidx[instance]->dupl_list = NULL;
		free( instidx[instance]->meta_list ); instidx[instance]->meta_list = NULL;
		free( instidx[instance]->dupl_hash ); instidx[instance]->dupl_hash = NULL;
		free( instidx[instance]->meta_hash ); instidx[instance]->meta_hash = NULL;
		free( instidx[instance]->dupl ); instidx[instance]->dupl = NULL;
		free( instidx[instance]->meta ); instidx[instance]->meta = NULL;

		return language_ranking_out[instance];
	}

	// debug of ranking
	unsigned long int average_rank = 0;
	unsigned long int second_rank = 0;
	unsigned short null_language_count = 0;

	struct null_struct {
		unsigned long int rank;
		unsigned short rule;
		unsigned short terms;
	} top_null_language, second_null_language;

	top_null_language.rank = 0;
	top_null_language.rule = 0;
	top_null_language.terms = 0;
	second_null_language.rank = 0;
	second_null_language.rule = 0;
	second_null_language.terms = 0;

	langid_t top_language = 0;

	unsigned short text_quality = (realmaxduplicates / logarithm(instidx[instance]->dupl_count,(double)2)); // Più e lungo un testo "più è probabile sia vago" 

	// assegna il punteggio alle tematiche
	for (unsigned char c = 0; c < RBSIZE; c++)
		if (ranking_buffer[instance][c].rule < USHRT_MAX)
		{
			unsigned long int rank = (ranking_buffer[instance][c].ranking / logarithm(main_structs[(ranking_buffer[instance][c].rule)].terms,(double)2)) * text_quality;

			if (main_structs[(ranking_buffer[instance][c].rule)].language > 1)
			{
				if (language_ranking[instance][main_structs[(ranking_buffer[instance][c].rule)].language] == 0 && ((rank + ranking_buffer[instance][c].lang_ranking) < UINT_MAX))
					rank = rank + ranking_buffer[instance][c].lang_ranking;
			}
			else
			{
				if ((rank + ranking_buffer[instance][c].ranking) < UINT_MAX)
					rank = rank + ranking_buffer[instance][c].ranking;
			}


			if (rank < UINT_MAX && rank > 0)
			{
				if (language_ranking[instance][main_structs[(ranking_buffer[instance][c].rule)].language] == 0 || main_structs[(ranking_buffer[instance][c].rule)].language == 1)
					language_ranking_out[instance]->ranked_languages++;

				if (main_structs[(ranking_buffer[instance][c].rule)].language > 1)
					language_ranking[instance][main_structs[(ranking_buffer[instance][c].rule)].language] += rank;
				else
				{
					if (rank > top_null_language.rank)
					{
						
						second_null_language.rank = top_null_language.rank;
						second_null_language.rule = top_null_language.rule;
						second_null_language.terms = top_null_language.terms;
						top_null_language.rank = rank;
						top_null_language.rule = ranking_buffer[instance][c].rule;
						top_null_language.terms = main_structs[ranking_buffer[instance][c].rule].terms;
					}
					else if (rank > second_null_language.rank)
					{
						second_null_language.rank = rank;
						second_null_language.rule = ranking_buffer[instance][c].rule;
						second_null_language.terms = main_structs[ranking_buffer[instance][c].rule].terms;
					}
					// Calcola la media in 'tempo reale' per ogni punteggio aggiunto.
					double coefficent = ((double)null_language_count / ((double)null_language_count + 1));

					null_language_count++;

					average_rank = average_rank * coefficent + rank / null_language_count;
				}
			}

		}
		else
			break;

	// Se esistono tematiche nulle che influiscono sulla media occorre ricalcolare la stessa in base al numero totale di tematiche coinvolte nel ranking
	if (null_language_count > 0)
	{
		double coefficent = ((double)null_language_count / ((double)language_ranking_out[instance]->ranked_languages));

		average_rank = average_rank * coefficent;
	}

	// trova la tematica (ad esclusione della nulla) con maggiore punteggio
	if (language_ranking_out[instance]->ranked_languages > 0)
	{
		for (langid_t langid = 2; langid <= openidx->lang_count; langid++)
		{
			average_rank += (language_ranking[instance][langid] / language_ranking_out[instance]->ranked_languages);

			if (language_ranking[instance][langid] > language_ranking_out[instance]->ranking )
			{
				second_rank = language_ranking_out[instance]->ranking;
				language_ranking_out[instance]->ranking = language_ranking[instance][langid];
				top_language = langid;
			}
			else if (language_ranking[instance][langid] > second_rank)
				second_rank = language_ranking[instance][langid];
		}
	}
	else
	{
		language_ranking_out[instance]->ranking = 0;

        	// Close and nullify all the filehandlers
		free( instidx[instance]->dupl_list ); instidx[instance]->dupl_list = NULL;
		free( instidx[instance]->meta_list ); instidx[instance]->meta_list = NULL;
		free( instidx[instance]->dupl_hash ); instidx[instance]->dupl_hash = NULL;
		free( instidx[instance]->meta_hash ); instidx[instance]->meta_hash = NULL;
		free( instidx[instance]->dupl ); instidx[instance]->dupl = NULL;
		free( instidx[instance]->meta ); instidx[instance]->meta = NULL;

		return language_ranking_out[instance];
	}

	unsigned int top_language_terms = 0;

	// confronta le tematiche con eventuali tematiche nulle
	if (top_null_language.rank > language_ranking_out[instance]->ranking)
	{
		top_language_terms = main_structs[top_null_language.rule].terms;
		language_ranking_out[instance]->ranking = top_null_language.rank;
		top_language = 1;
	}
	else
	{
		// se è stata trovata una sola tematica occorre trovare il numero di termini totali utilizzati nella stessa tematica
		if (language_ranking_out[instance]->ranked_languages == 1 && top_null_language.rank == 0)
			for (unsigned char c = 0; c < RBSIZE; c++)
			{
				if (ranking_buffer[instance][c].rule < USHRT_MAX)
				{
					if (main_structs[ranking_buffer[instance][c].rule].language == top_language)
						top_language_terms += main_structs[ranking_buffer[instance][c].rule].terms;
				}
				else
					break;
			}
	}

	// Se sono state trovate tematiche nulle ma nessuna di queste è al top in classifica
	// cerca se eventualmente potrebbe avere il secondo punteggio
	if (top_language > 1 && null_language_count > 1)
	{
		if (top_null_language.rank > second_rank)
			second_rank = top_null_language.rank;
		else if (second_null_language.rank > second_rank)
			second_rank = second_null_language.rank;
	}
///////////////////////////////// da continuare //////////////////////////////////////

	// se è stata trovata più di una tematica la media non deve essere influenzata dal punteggio assegnato a top_language
	unsigned int *ranking = &language_ranking_out[instance]->ranking;
	langid_t *rt = &language_ranking_out[instance]->ranked_languages;

	if (language_ranking_out[instance]->ranked_languages > 1)
		average_rank = (average_rank - (*ranking / *rt)) / (*rt - 1) * (*rt);

	if (top_language > 0 && top_language <= openidx->lang_count && ((*rt > 1 && (*ranking > (second_rank * SR_CONST)) && (*ranking >= (average_rank * FM))) || ((*rt == 1 && (*ranking >= ((USHRT_MAX / logarithm(top_language_terms,(double)2)) * text_quality * FM))))))
	{
		unsigned char amount_rules = 0;

		if (top_language > 1)
		{
			if (top_language < openidx->lang_count)
				amount_rules = (th_dist_st[top_language + 1].th_dist_offset - th_dist_st[top_language].th_dist_offset);
			else
				amount_rules = (languages_counter - th_dist_st[top_language].th_dist_offset);
		}
		else
			amount_rules = 1;

		//cout << "top language " << top_language << " ranking " << *ranking << " languages " << *rt << " second " << second_rank << " average " << average_rank << " amount rules " << (int)amount_rules << endl;

		if (amount_rules > 0)
		{
			if (top_language > 1) // se diversa da null ricava il nome della tematica
				langidx_lang_by_langid(top_language, language_ranking_out[instance]->language);

			size_t storic_size = 0;

			if (top_language > 1)
			{
				for (unsigned char a = 0; a < amount_rules; a++)
				{
					unsigned short rule = th_dist[(th_dist_st[top_language].th_dist_offset + a)];

					storic_size += ((rule < (mcrule - 1)) ? main_structs[(rule + 1)].rule_offset : terms_counter) - main_structs[rule].rule_offset;
				}
			}
			else
				storic_size = top_null_language.terms;
		}

		// DA UN'INDICAZIONE REALE SU QUANTO VALE IL RANKING (questo dato è utile al motore di ricerca)
		// Al ranking finale viene sottratta la media (per capire quanto prevale su di essa) e
		// la differenza tra il ranking e il second_ranking divisa per la radice quadrata del numero delle tematiche totali trovate
		//
		if (language_ranking_out[instance]->ranked_languages > 1)
		{
			unsigned int val = *ranking - ((average_rank + (*ranking - second_rank)) / sqrt(*rt));

			if (val > LANGTHRESHOLD)
				val = LANGTHRESHOLD;

			// pseudo normalizzazione del ranking della tematica riferita appunto a LANGTHRESHOLD
			language_ranking_out[instance]->ranking = ((float)val / (float)LANGTHRESHOLD) * LANGRANK_MAX;
		}
		else
			language_ranking_out[instance]->ranking = ((float)*ranking / (float)LANGTHRESHOLD) * LANGRANK_MAX;
			// pseudo normalizzazione del ranking della tematica riferita appunto a LANGTHRESHOLD
	}
	else
		language_ranking_out[instance]->ranking = 0;

	// Close and nullify all the filehandlers
	free( instidx[instance]->dupl_list ); instidx[instance]->dupl_list = NULL;
	free( instidx[instance]->meta_list ); instidx[instance]->meta_list = NULL;
	free( instidx[instance]->dupl_hash ); instidx[instance]->dupl_hash = NULL;
	free( instidx[instance]->meta_hash ); instidx[instance]->meta_hash = NULL;
	free( instidx[instance]->dupl ); instidx[instance]->dupl = NULL;
	free( instidx[instance]->meta ); instidx[instance]->meta = NULL;

	return language_ranking_out[instance];
}

void Languages::free_analisys_index (unsigned int instance) const
{
	// Close and nullify all memory allocation need for single request ranking usage
	free (language_ranking_out[instance]->language); language_ranking_out[instance]->language = NULL;
	free (language_ranking_out[instance]); language_ranking_out[instance] = NULL;
	free (ranking_buffer[instance]); ranking_buffer[instance] = NULL;
	free (language_ranking[instance]); language_ranking[instance] = NULL;



	// Close and nullify all the filehandlers
	free( instidx[instance]->dupl_list ); instidx[instance]->dupl_list = NULL;
	free( instidx[instance]->dupl_hash ); instidx[instance]->dupl_hash = NULL;
	free( instidx[instance]->dupl ); instidx[instance]->dupl = NULL;
	free( instidx[instance] ); instidx[instance] = NULL;
}

void Languages::index_open (void)
{
	cerr << "Open word indexes for elaboration " << endl;
	langidx_new(); // langidx_open() non necessaria se non si lavora su disco
	assert( openidx != NULL );
}

void Languages::index_close (bool close_all)
{
	cerr << "Close word indexes." << endl;
	langidx_close();

	if (close_all == true)
	{
		free (main_buffer);
		free (main_structs);
		free (th_dist_st);
		free (th_dist);
		free (wdist_st);
		free (wdist);

		// Close and nullify all memory allocation need for ranking usage
		if (ranking_buffer != NULL)
			free (ranking_buffer);

		if (language_ranking != NULL)
			free (language_ranking);

		if (instidx != NULL)
			free (instidx);

		if (language_ranking_out != NULL)
			free (language_ranking_out);
	}
}

//
// Name: langidx_new
//
// Description:
//   Creates a new index in the given directory
//
// Input:
//   dirname - directory to create url index
//
// Return:
//   urlindex structure
//
void Languages::langidx_new( void ) {

	openidx = (langidx_t *)malloc(sizeof(langidx_t));
	assert( openidx != NULL );

	assert( CONF_OK );

	openidx->lang_hash = (off64_t *)malloc(sizeof(off64_t)*MAXLANGUAGES);
	assert( openidx->lang_hash != NULL );

	openidx->word_hash = (off64_t *)malloc(sizeof(off64_t)*MAXWORDS);
	assert( openidx->word_hash != NULL );

	// Clean hash tables
	for( langid_t i=0; i<MAXLANGUAGES; i++ ) {
		openidx->lang_hash[i] = (off64_t)0;
	}

	// Clean hash tables
	for( wordid_t i=0; i<MAXWORDS; i++ ) {
		openidx->word_hash[i] = (off64_t)0;
	}

	// Set default values
	openidx->lang_count = 0;
	openidx->lang_next_char = 1; // start in 1
	openidx->word_count = 0;
	openidx->word_next_char = 1; // start in 1

	// lang_list
	openidx->lang_list = (off64_t *) malloc ((MAXLANGUAGES + 1) * sizeof(off64_t));

	// word_list
	openidx->word_list = (off64_t *) malloc ((MAXWORDS + 1) * sizeof(off64_t));

	// Create memory area for languages word names
	LANGIDX_LANG_SIZE = LANGIDX_EXPECTED_LANG_SIZE * MAXLANGUAGES;
	openidx->lang = (char *)malloc((sizeof(char))*LANGIDX_LANG_SIZE);
	assert( openidx->lang != NULL );
	openidx->lang[0] = ASCII_NUL;

	// Create memory area for word names
	LANGIDX_WORD_SIZE = LANGIDX_EXPECTED_WORD_SIZE * MAXWORDS;
	openidx->word = (char *)malloc((sizeof(char))*LANGIDX_WORD_SIZE);
	assert( openidx->word != NULL );
	openidx->word[0] = ASCII_NUL;
} 
                                            
//
// Name: langidx_resolve_lang
//
// Description:
//   Verify a language name and add it if necessary
//
// Input:
//   langidx - the url index structure
//   lang - the language to check
//
// Output:
//   langid - langid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   LANGIDX_EXISTENT - the language existed
//   LANGIDX_CREATED_LANG - the language word was added
//   LANGIDX_NOT_FOUND - the language word is not known and was not created
//
langidx_status_t Languages:: langidx_resolve_lang( const char *lang, langid_t *langid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( lang != NULL );

	if (lang == NULL)
		return LANGIDX_NOT_FOUND;

	size_t llen = strlen(lang);
	assert( llen > 0 );

	langid_t bucket;
	langid_t langid_check;

	// Check if the lang exists
	langid_check = langidx_check_lang( lang, &(bucket) );

	if( langid_check > 0 ) {
		if( langid != NULL ) {
			*langid	= langid_check;
		}
		return LANGIDX_EXISTENT;
	}

	if( readonly == true )
		return LANGIDX_NOT_FOUND;
	else {
		// Get the next langid
		*langid = ++(openidx->lang_count);

		//cout << "Result 0 o 2, Sito:   " << lang << "       Recupero il primo langid disponibile " << openidx->lang_count << '-' << bucket << endl;
		if( openidx->lang_count > MAXLANGUAGES ) {
			die( "Maximum number of langs exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->lang_hash)[bucket] = (openidx->lang_next_char);
//		cout << "Inserisco " << (openidx->lang_next_char) << " in (openidx->lang_hash)[" << bucket << "]" << " conferma " << (openidx->lang_hash)[bucket] << endl;

		// Save in list of langs
		openidx->lang_list[*langid - 1] = openidx->lang_next_char;

		// Store string
		memcpy( openidx->lang + openidx->lang_next_char, lang, llen + 1 );

		// Store langid
		memcpy( openidx->lang + openidx->lang_next_char + llen + 1, langid, sizeof(langid_t) );

		// Move char pointer
		openidx->lang_next_char = openidx->lang_next_char + llen + 1 + sizeof(langid_t);
		if( openidx->lang_next_char > LANGIDX_LANG_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXLANGUAGES or EXPECTED_LANG_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(LANGIDX_ERROR);
		}
	}

	// Return
	return LANGIDX_CREATED_LANG;
}

//
// Name: langidx_resolve_word
//
// Description:
//   Verify a word name and add it if necessary
//
// Input:
//   langidx - the url index structure
//   word - the word to check
//
// Output:
//   wordid - wordid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   LANGIDX_EXISTENT - the site existed
//   LANGIDX_CREATED_WORD - the word was added
//   LANGIDX_NOT_FOUND - the second level word is not known and was not created
//
langidx_status_t Languages::langidx_resolve_word( const char *word, wordid_t *wordid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( word != NULL );

	if (word == NULL)
		return LANGIDX_NOT_FOUND;

	size_t wlen = strlen(word);
	assert( wlen > 0 );

	wordid_t bucket;
	wordid_t wordid_check;

	// Check if the word exists
	wordid_check = langidx_check_word( word, &(bucket) );

	if( wordid_check > 0 ) {
		if( wordid != NULL ) {
			*wordid	= wordid_check;
		}
		return LANGIDX_EXISTENT;
	}

	if( readonly == true )
		return LANGIDX_NOT_FOUND;
	else {
		// Get the next wordid
		*wordid = ++(openidx->word_count);

		//cout << "Result 0 o 2, Sito:   " << word << "       Recupero il primo wordid disponibile " << openidx->word_count << '-' << bucket << endl;
		if( openidx->word_count > MAXWORDS ) {
			die( "Maximum number of words exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->word_hash)[bucket] = (openidx->word_next_char);
//		cout << "Inserisco " << (openidx->word_next_char) << " in (openidx->word_hash)[" << bucket << "]" << " conferma " << (openidx->word_hash)[bucket] << endl;

		// Save in list of words
		openidx->word_list[*wordid - 1] = openidx->word_next_char;

		// Store string
		memcpy( openidx->word + openidx->word_next_char, word, wlen + 1 );

		// Store wordid
		memcpy( openidx->word + openidx->word_next_char + wlen + 1, wordid, sizeof(wordid_t) );

		// Move char pointer
		openidx->word_next_char = openidx->word_next_char + wlen + 1 + sizeof(wordid_t);
		if( openidx->word_next_char > LANGIDX_WORD_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXWORDS or EXPECTED_WORD_SIZE" << endl;
			return(LANGIDX_ERROR);
		}
	}

	// Return
	return LANGIDX_CREATED_WORD;
}

//
// Name: langidx_resolve_dupl
//
// Description:
//   Verify a dupl name and add it if necessary
//
// Input:
//   langidx - the url index structure
//   dupl - the dupl to check
//
// Output:
//   duplid - duplid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   LANGIDX_EXISTENT - the duplatic existed
//   LANGIDX_CREATED_DUPL - the duplatic dupl was added
//   LANGIDX_NOT_FOUND - the duplatic dupl is not known and was not created
//
langidx_status_t Languages::langidx_resolve_dupl( unsigned int instance, const char *dupl, duplid_t *duplid, bool readonly ) const {
	assert( openidx != NULL );

	if (dupl == NULL)
		return LANGIDX_NOT_FOUND;

	size_t dlen = strlen(dupl);
	assert( dlen > 0 );

	duplid_t bucket;
	duplid_t duplid_check;

	// Check if word exists
	duplid_check = langidx_check_dupl( instance, dupl, &(bucket) );
	
	if( duplid_check > 0 ) {
		if( duplid != NULL ) {
			*duplid	= duplid_check;
		}
		return LANGIDX_EXISTENT;
	}

	if( readonly == true )
		return LANGIDX_NOT_FOUND;
	else {
		// Get the next duplid
		*duplid = ++(instidx[instance]->dupl_count);
		//cout << "Result 0 o 2, Sito:   " << dupl << "       Recupero il primo duplid disponibile " << instidx[instance]->dupl_count << '-' << bucket << endl;
		if( instidx[instance]->dupl_count > MAXDUPLICATES ) {
			die( "Maximum number of duplicates exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(instidx[instance]->dupl_hash)[bucket] = (instidx[instance]->dupl_next_char);
//		cout << "Inserisco " << (instidx[instance]->dupl_next_char) << " in (instidx[instance]->dupl_hash)[" << bucket << "]" << " conferma " << (instidx[instance]->dupl_hash)[bucket] << endl;

		// Save in list of dupls
		instidx[instance]->dupl_list[*duplid - 1] = instidx[instance]->dupl_next_char;

		// Store string
		memcpy( instidx[instance]->dupl + instidx[instance]->dupl_next_char, dupl, dlen + 1 );

		// Store duplid
		memcpy( instidx[instance]->dupl + instidx[instance]->dupl_next_char + dlen + 1, duplid, sizeof(duplid_t) );

		// Move char pointer
		instidx[instance]->dupl_next_char = instidx[instance]->dupl_next_char + dlen + 1 + sizeof(duplid_t);
		if( instidx[instance]->dupl_next_char > LANGIDX_DUPL_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXDUPLICATES or EXPECTED_DUPL_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(LANGIDX_ERROR);
		}
	}

	// Return
	return LANGIDX_CREATED_DUPL;
}

//
// Name: langidx_resolve_meta
//
// Description:
//   Verify a meta name and add it if necessary
//
// Input:
//   langidx - the url index structure
//   meta - the meta to check
//
// Output:
//   metaid - metaid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   LANGIDX_EXISTENT - the meta word existed
//   LANGIDX_CREATED_DUPL - the meta word was added
//   LANGIDX_NOT_FOUND - the meta word is not known and was not created
//
langidx_status_t Languages::langidx_resolve_meta( unsigned int instance, const char *meta, metaid_t *metaid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( meta != NULL );

	if (meta == NULL)
		return LANGIDX_NOT_FOUND;

	size_t mlen = strlen(meta);
	assert( mlen > 0 );

	metaid_t bucket;
	metaid_t metaid_check;

	// Check if the meta exists
	metaid_check = langidx_check_meta( instance, meta, &(bucket) );

	if( metaid_check > 0 ) {
		if( metaid != NULL ) {
			*metaid	= metaid_check;
		}
		return LANGIDX_EXISTENT;
	}

	if( readonly == true )
		return LANGIDX_NOT_FOUND;
	else {
		// Get the next metaid

		// Save in list of metas
		*metaid = ++(instidx[instance]->meta_count);
		//cout << "Result 0 o 2, Sito:   " << meta << "       Recupero il primo metaid disponibile " << instidx[instance]->meta_count << '-' << bucket << endl;
		if( instidx[instance]->meta_count > MAXMETA ) {
			die( "Maximum number of metaicates exceeded, increase in configuration file"  );
		}


		// Save in list of metas
		// Put in bucket
		(instidx[instance]->meta_hash)[bucket] = (instidx[instance]->meta_next_char);
//		cout << "Inserisco " << (instidx[instance]->meta_next_char) << " in (instidx[instance]->meta_hash)[" << bucket << "]" << " conferma " << (instidx[instance]->meta_hash)[bucket] << endl;

		// Save in list of meta words
		instidx[instance]->meta_list[*metaid - 1] = instidx[instance]->meta_next_char;

		// Store string
		memcpy( instidx[instance]->meta + instidx[instance]->meta_next_char, meta, mlen + 1 );

		// Store metaid
		memcpy( instidx[instance]->meta + instidx[instance]->meta_next_char + mlen + 1, metaid, sizeof(metaid_t) );

		// Move char pointer
		instidx[instance]->meta_next_char = instidx[instance]->meta_next_char + mlen + 1 + sizeof(metaid_t);
		if( instidx[instance]->meta_next_char > LANGIDX_META_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXMETA or EXPECTED_META_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(LANGIDX_ERROR);
		}
	}

	// Return
	return LANGIDX_CREATED_META;
}

//
// Name: langidx_check_lang
//
// Description:
//   Check if a word exists
//
// Input:
//   langidx - the language index structure
//   lang - the language name to check
//   bucket - the bucket in which this was found
//
// Return
//   a wordid if resolved
//   0 if not found
//
langid_t Languages::langidx_check_lang( const char *lang, langid_t *bucket ) const {
	assert( openidx != NULL );
	assert( lang != NULL );
	assert( strlen( lang ) > 0 );

	// First attempt to find bucket (debug purpose)
	//langid_t test = urlidx_hashing_lang( lang );
	//cout << "DOMAIN " << lang << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = langidx_hashing_lang( lang );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( openidx->lang_hash[(*bucket)] > 0 ) {

		char *pidx = openidx->lang + openidx->lang_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = lang;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != ASCII_NUL && *(input) != ASCII_NUL && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			return *((langid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % MAXLANGUAGES;
	}

	return (langid_t)0;
}

//
// Name: urlidx_check_word
//
// Description:
//   Check if a word exists
//
// Input:
//   langidx - the word index structure
//   word - the word name to check
//   bucket - the bucket in which this was found
//
// Return
//   a wordid if resolved
//   0 if not found
//
wordid_t Languages::langidx_check_word( const char *word, wordid_t *bucket ) const {
	assert( openidx != NULL );
	assert( word != NULL );
	assert( strlen( word ) > 0 );

	// First attempt to find bucket (debug purpose)
	//wordid_t test = urlidx_hashing_lang( word );
	//cout << "DOMAIN " << word << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = langidx_hashing_word( word );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( openidx->word_hash[(*bucket)] > 0 ) {

		char *pidx = openidx->word + openidx->word_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = word;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != ASCII_NUL && *(input) != ASCII_NUL && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			return *((wordid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % MAXWORDS;
	}

	return (wordid_t)0;
}

//
// Name: urlidx_check_dupl
//
// Description:
//   Check if a word exist
//
// Input:
//   langidx - the word index structure
//   dupl - the duplicate name to check
//   bucket - the bucket in which this was found
//
// Return
//   a duplid if resolved
//   0 if not found
//
duplid_t Languages::langidx_check_dupl( unsigned int instance, const char *dupl, duplid_t *bucket ) const {
	assert( openidx != NULL );
	assert( dupl != NULL );
	assert( strlen( dupl ) > 0 );


	// First attempt to find bucket (debug purpose)
	//duplid_t test = urlidx_hashing_lang( dupl );
	//cout << "DOMAIN " << dupl << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = langidx_hashing_dupl( dupl );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( instidx[instance]->dupl_hash[(*bucket)] > 0 ) {

		char *pidx = instidx[instance]->dupl + instidx[instance]->dupl_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = dupl;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != ASCII_NUL && *(input) != ASCII_NUL && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			return *((duplid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % MAXDUPLICATES;
	}

	return (duplid_t)0;
}

//
// Name: urlidx_check_meta
//
// Description:
//   Check if a word exist
//
// Input:
//   langidx - the word index structure
//   meta - the meta name to check
//   bucket - the bucket in which this was found
//
// Return
//   a metaid if resolved
//   0 if not found
//
metaid_t Languages::langidx_check_meta( unsigned int instance, const char *meta, metaid_t *bucket ) const {
	assert( openidx != NULL );
	assert( meta != NULL );
	assert( strlen( meta ) > 0 );


	// First attempt to find bucket (debug purpose)
	//metaid_t test = urlidx_hashing_lang( meta );
	//cout << "DOMAIN " << meta << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = langidx_hashing_meta( meta );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( instidx[instance]->meta_hash[(*bucket)] > 0 ) {

		char *pidx = instidx[instance]->meta + instidx[instance]->meta_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = meta;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != ASCII_NUL && *(input) != ASCII_NUL && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == ASCII_NUL && *input == ASCII_NUL) // fine del termine dentro il puntatore a caratteri
			return *((metaid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % MAXDUPLICATES;
	}

	return (metaid_t)0;
}

// Hashing Functions for languages
langid_t Languages::langidx_hashing_lang( const char *text ) const {
	langid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXLANGUAGES );
	}
	return val;
}

// Hashing Functions for words
wordid_t Languages::langidx_hashing_word( const char *text ) const {
	wordid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXWORDS );
	}
	return val;
}

// Hashing Functions for duplicated words
duplid_t Languages::langidx_hashing_dupl( const char *text ) const {
	duplid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXDUPLICATES );
	}
	return val;
}

// Hashing Functions for meta words
metaid_t Languages::langidx_hashing_meta( const char *text ) const {
	metaid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXMETA );
	}
	return val;
}

// Name: langidx_lang_by_langid
//
// Description:
//   Get the name of a word based on its id
//
//	TODO: This function must fail in an error condition.
//
void Languages::langidx_lang_by_langid(langid_t langid, char *langname ) const {

	if ( langid > 0 && langid <= openidx->lang_count)
	{
		// Read offset
		off64_t offset;
		offset = openidx->lang_list[(langid - 1)];

		if ((langid - 1) == 0)
			assert( strlen( (openidx->lang) + offset ) == sizeof("null") );
		else
			assert( strlen( (openidx->lang) + offset ) == LANGIDX_EXPECTED_LANG_SIZE ); // perchè le lingue sono espresse in 2 caratteri ascii 7 bits

		// Copy
		strcpy( langname, (openidx->lang) + offset );
	}
	else
		langname[0] = ASCII_NUL;
}

// Name: langidx_word_by_wordid
//
// Description:
//   Get the name of a word based on its id
//
//	TODO: This function must fail in an error condition.
//
void Languages::langidx_word_by_wordid( wordid_t wordid, char *wordname ) const {

	if ( wordid > 0 && wordid <= openidx->word_count)
	{
		// Read offset
		off64_t offset;
		offset = openidx->word_list[(wordid - 1)];

		// Copy
		assert( strlen( (openidx->word) + offset ) < MAX_BYTES_WORD_LEN );
		strcpy( wordname, (openidx->word) + offset );
	}
	else
		wordname[0] = ASCII_NUL;
}

// Name: langidx_dupl_by_duplid
//
// Description:
//   Get the name of a duplicated word in a page based on its id
//
//	TODO: This function must fail in an error condition.
//
void Languages::langidx_dupl_by_duplid( unsigned int instance, duplid_t duplid, char *duplname ) const {

	if ( duplid > 0 && duplid <= instidx[instance]->dupl_count)
	{
		// Read offset
		off64_t offset;
		offset = instidx[instance]->dupl_list[(duplid - 1)];

		// Copy
		assert( strlen( (instidx[instance]->dupl) + offset ) < MAX_BYTES_WORD_LEN );
		strcpy( duplname, (instidx[instance]->dupl) + offset );
	}
	else
		duplname[0] = ASCII_NUL;
}

// Name: langidx_meta_by_metaid
//
// Description:
//   Get the name of a meta word in a page based on its id
//
//	TODO: This function must fail in an error condition.
//
void Languages::langidx_meta_by_metaid( unsigned int instance, metaid_t metaid, char *metaname ) const {

	if ( metaid > 0 && metaid <= instidx[instance]->meta_count)
	{
		// Read offset
		off64_t offset;
		offset = instidx[instance]->meta_list[(metaid - 1)];

		// Copy
		assert( strlen( (instidx[instance]->meta) + offset ) < MAX_BYTES_WORD_LEN );
		strcpy( metaname, (instidx[instance]->meta) + offset );
	}
	else
		metaname[0] = ASCII_NUL;
}

//
// Name: langidx_close
//
// Description:
//   Closes the url index, saving data to disk
//
// Input:
//   langidx - the url index structure
//
void Languages::langidx_close(void) {
	// Check what i'm going to close
	assert( openidx != NULL );

	// Close and nullify all the static filehandlers
	free( openidx->lang_list ); openidx->lang_list = NULL;
	free( openidx->word_list ); openidx->word_list = NULL;
	free( openidx->lang_hash ); openidx->lang_hash = NULL;
	free( openidx->word_hash ); openidx->word_hash = NULL;
	free( openidx->lang ); openidx->lang = NULL;
	free( openidx->word ); openidx->word = NULL;
	free( openidx ); openidx = NULL;
}
