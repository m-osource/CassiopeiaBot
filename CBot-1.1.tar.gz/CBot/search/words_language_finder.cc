/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

// N.B. Il check della variabile http_status servirà (se necessario) come implementazione futura ad indicare al motore di ricerca i docid da cancellare o ripristinare
// al cambiare di tale stato
//if(HTTP_IS_OK(doc.http_status))

#include "words_language_finder.h"

thread_local cpu_set_t system_cpus;

// 
// Name: main
//
// Description:
//   Main program
//

int main( int argc, char **argv ) {

	// sicronizzazione dell'output in multithreading
//	std::ios_base::sync_with_stdio(false);
//	std::cin.tie(nullptr);
//	std::cerr.tie(nullptr);

	int rc = 0;
	pthread_mutexattr_t		attr;

	cbot_start("words-language-finder"); // imposta le constanti

	while(1) {
		int option_index = 0;

		static struct option long_options[] = {
			{"help", 0, 0, 0},
			{"debugonly", 0, 0, 0},
			{"showlanguages", 0, 0, 0},
			{"from", 1, 0, 0},
			{"to", 1, 0, 0},
			{0, 0, 0, 0}
		};

		char c = getopt_long (argc, argv, "h", long_options, &option_index);

		if (c == -1)
			break;

		switch (c) {
			case 0:
				if( !strcmp( long_options[option_index].name, "from" ) ) {
					opt_from = atol( optarg );
					if( opt_from == 0 ) {
						words_language_finder_usage();
					}
				} else if( !strcmp( long_options[option_index].name, "to" ) ) {
					opt_to = atol( optarg );
					if( opt_to == 0 ) {
						words_language_finder_usage();
					}
				} else if( !strcmp( long_options[option_index].name, "debugonly" ) ) {
					debugonly = true;
				} else if( !strcmp( long_options[option_index].name, "showlanguages" ) ) {
					showlanguages = true;
				} else if( !strcmp( long_options[option_index].name, "help" ) ) {
					words_language_finder_usage();
				}
				break;
			case 'h':
				words_language_finder_usage();
				break;
			default:
				words_language_finder_usage();
		}
	}

	// Reading configuration files of languages
	if (! (showlanguages == true && debugonly == true))
		cerr << "Prepare index of languages ... ";

	if (showlanguages == true && debugonly == true)
	{
		cerr << endl << "Closing index of languages ... ";
		cerr << "done" << endl;
		return 0;
	}
	else
		cerr << "done." << endl;

	// Open metaindex
	cerr << "metaindex ... ";
	meta = new Meta ( COLLECTION_METADATA, true );
	meta->ddx_open();

	// Open storage
	cerr << "storage ... ";
	strg = new Storage ( COLLECTION_TEXT, true );
	strg->st_open();

	// Open for writing words index
	cerr << "do_you_mean index ... ";
	openddx = dymddx_open( COLLECTION_DYM, false );
	assert( openddx != NULL );

	// Open langindex
	cerr << "langindex ... ";
	langddx = langddx_open( COLLECTION_LANGDATA, false );
	assert( langddx != NULL );

	cerr << "done." << endl;

	if (openddx->word_count > 0)
	{
//cout << openddx->distributed[i].word_count << endl;
		cerr << "Warning: for start program, 'do_you_mean' index must be empty!" << endl;
		cbot_stop(1);
	}	

	if (CONF_COLLECTION_DISTRIBUTED > 1) // sezione di inizializzazione dei mutex
	{
		pthread_t *threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		// setup mutex of dymddx index
		dymddx_setmutex(openddx, &wlock, &slock, &glock);

		rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK);

		if (rc != 0)
		{
			perror("error setting mutex type");
			exit(1);
		}
		
		rc = pthread_mutexattr_init(&attr);

		if (rc != 0)
		{
			perror("error creating mutex with attributes object");
			exit(1);
		}
		
		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			rc = pthread_create( &(threads[i]), NULL, thread_function_create_dym, &i );

			if (rc != 0)
			{
				perror("error creating threads");
				exit(1);
			}
		}

		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		// AFTER program have terminated to insert word and n-grams, we can update counters of languages	
		for (unsigned int i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
		{
			rc = pthread_create( &(threads[i]), NULL, thread_function_counters_store, &i );

			if (rc != 0)
			{
				perror("error creating threads");
				exit(1);
			}
		}

//	for (unsigned int i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
//		thread_function_create_dym((int *)i);

		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads); 

		rc = pthread_mutexattr_destroy(&(attr));

		// destroy mutex of dymddx index
		dymddx_destroymutex(openddx);
	}
	else
	{
		unsigned int i = 0;
		wlock = NULL;
		slock = NULL;
		glock = NULL;
		thread_function_create_dym(&i);
		thread_function_counters_store(&i);
	}

	cerr << endl << "Closing index of words ... ";
	cerr << "done" << endl;

	cbot_stop(0);
}

void *thread_function_create_dym(void *dummyPtr)
{
try
{
	instance_t *instance = (instance_t *) dummyPtr;

	instance_t inst = *instance;

	CPU_OPTIMIZE;

	char *buffer	= (char *)malloc(sizeof(char)*MAX_DOC_LEN);
	assert( buffer != NULL );
	// Default options
	docid_t start		= (*instance + 1);
	docid_t finish		= ((meta->instance_doc_count(*instance) * CONF_COLLECTION_DISTRIBUTED) + *instance + 1);

	// Limits
	if( opt_from > (CONF_COLLECTION_DISTRIBUTED) ) {
		start = ((((opt_from - 1) / CONF_COLLECTION_DISTRIBUTED) * CONF_COLLECTION_DISTRIBUTED) + *instance);
	}

	if( opt_to > 0 && opt_to < meta->instance_doc_count(*instance) ) {
		finish = opt_to;
	}

	for(docid_t docnum = start; docnum <= finish; docnum += CONF_COLLECTION_DISTRIBUTED)
	{
		metaddx_status_t rc;
		doc_t ddoc;
		ddoc.docid = docnum;

		rc = meta->doc_retrieve( &(ddoc) );

	   	if( rc == METADDX_OK && ddoc.duplicate_of == 0 ) 
		{
			if (binder(&(ddoc), buffer))
			{
				size_t length = 0;
				pes_t *poutt;
 
				if (ddoc.mime_type == MIME_TEXT_HTML)
				{
					poutt = htmlSplit(buffer); // Estrapolazione dei meta tags, contenuto ecc... dal buffer storage
				
					length = strlen(poutt->content);
				}
				else if (ddoc.mime_type == MIME_APPLICATION_PDF)
				{
					poutt = pdfSplit(buffer); // Estrapolazione dei meta informazioni, contenuto ecc... dal buffer storage
				
					length = strlen(poutt->content);
				}
				else if (ddoc.mime_type == MIME_TEXT_PLAIN)
				{
					poutt = (pes_t*) malloc (sizeof(pes_t));
					poutt->content = (char*) malloc (sizeof(char) * MAX_DOC_LEN);
					poutt->content[0] = ASCII_NUL;
					strcpy(poutt->content,buffer);
				
					length = strlen(buffer);
				
					poutt->metakeyw[0] = ASCII_NUL;
					poutt->title[0] = ASCII_NUL;
					poutt->headings[0] = ASCII_NUL;
					poutt->metalmon = pes_t::NO_LOCAL_MONETARY;
				}
				else
				{
					free(buffer);
					return NULL;
				}

				textFinder(&(ddoc), min_word_len, poutt, length);

				// preparo l'indice temporaneo dello stemming delle parole del contenuto (body) del documento
				// utile alla classe delle tematiche e alla ricerca dei termini infissi in map_abbreviated
//				la.make_analisys_index (*instance, min_word_len, poutt, length);

				poutt->title[0] = ASCII_NUL;
				poutt->headings[0] = ASCII_NUL;
				poutt->metadesc[0] = ASCII_NUL;
				poutt->metakeyw[0] = ASCII_NUL;
				poutt->metalmon = pes_t::NO_LOCAL_MONETARY;


				// libera l'area (dealloca) di memoria puntata dal puntatore content anche se di default avviene al termine del programma
				free(poutt->content);
				free(poutt);
			}
		}
	}

	free(buffer);

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(NULL);
}
}

//
// Name: thread_function_counters_store
//
// Description: store metadata languages counters per single word
//
// Arguments: a void pointer to '(unsigned int)(int *)' type that contain instance
//
// Return: NULL
//
void *thread_function_counters_store(void *dummyPtr)
{
try
{
	instance_t *instance = (instance_t *) dummyPtr;

	instance_t inst = *instance;

	CPU_OPTIMIZE;

	// save sequences to disk
	if( openddx->readonly == false)
	{
		if( openddx->distributed[*instance].w_seq_count > 1)
		{
			for (wordid_t hash_pos = 0; hash_pos < openddx->distributed[*instance].word_count; hash_pos++)
			{
				wordid_t wordid = (((hash_pos * CONF_COLLECTION_DISTRIBUTED) + *instance) + 1);
				word_t dword;
				langddx_word_default(&dword);
				dword.wordid = wordid;
				dword.language = dymddx_get_candidate_lang(openddx, &wordid);
				langddx_word_store( langddx, &(dword) );
			}
		}
	}

	return NULL;
}
catch (CBotExitException eex)
{
    // Some  function  indicated  that  we  should  exit  the  thread. 
    eex.DoThreadExit(NULL);
}
}

// Nome: binder
//
// Descrizione: Funzione in cui vengono elaborati definitivamente i documenti prima di essere salvati dalla stessa funzione nell'indice/i
// del motore di ricerca con database 'tipo sql'.
//
// Argomenti: struttura doc_t, input buffer
//
// Restituisce: booleano che indica 'vero' se la funzione ha eseguito con successo
//
bool binder(doc_t *doc, char *buf)
{
	assert(doc->docid > 0);

	if (doc->duplicate_of > 0)
		return 1; // do nothing, but analyse in updatescores sessions

	storage_status_t rc = strg->read_document( doc, buf );

	if(rc != STORAGE_OK)
	{
		if (debugonly == false)
			cerr << "x";

		return false;
	}

	return true;
}

//
// Name: Languages::make_analisys_index
//
// Description: Crea e l'indice temporaneo necessario per contenere gli id numerici dei termini (parole) e ne permette il popolamento
//
// Argomenti: numero instanza, lunghezza minima del termine, struttura poutt, lunghezza di 'poutt->content'
//
// Restituisce: 
//
void textFinder (doc_t *doc, const size_t min_word_len, pes_t *poutt, size_t content_len)
{
	// Inizio lettura stdin
	bool content_readed = false;
	char *elaborate = (char *) malloc ((MAX_BYTES_WORD_LEN + 1) * sizeof(char));
	elaborate[0] = ASCII_NUL;
	size_t elaborate_offset = 0;
	size_t offset = 0;

	unsigned int words_counter = 0;

	char *buffer = poutt->headings;

	run_again:

	if (buffer != NULL && buffer[0] != ASCII_NUL) // se esistono headings, questi si inseriscono prima nei duplicati
	{
		while(buffer[offset] != ASCII_NUL)
		{
			if (! isspace(buffer[offset]))
			{
				if (elaborate_offset >= MAX_BYTES_WORD_LEN) // skip whole string to next space
				{
					elaborate_offset = 0;
					elaborate[elaborate_offset] = ASCII_NUL;

					while (! (buffer[offset] == ASCII_NUL || isspace(buffer[offset])))
						offset++;

					continue;
				}
				else
				{
					elaborate[elaborate_offset++] = buffer[offset];
					elaborate[elaborate_offset] = ASCII_NUL;
				}

			}
			else
			{
				if (elaborate_offset > 1)
				{
					if (elaborate_offset <= MAX_BYTES_WORD_LEN)
					{
						if (content_readed == false)
							wordFinder(doc, elaborate, min_word_len);
						else
						{
							if (words_counter < (UINT_MAX - USHRT_MAX)) // USHRT_MAX perchè al massimo la funzione 'wordFinder' restituisce al max USHRT_MAX
								words_counter += wordFinder(doc, elaborate, min_word_len);
							else
								wordFinder(doc, elaborate, min_word_len);
						}

						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
					}
				}
				else
				{
						elaborate_offset = 0;
						elaborate[elaborate_offset] = ASCII_NUL;
				}
			}

			offset++;
		}

		if (elaborate_offset > min_word_len && elaborate_offset <= MAX_BYTES_WORD_LEN)
			wordFinder(doc, elaborate, min_word_len);
	}

	if (poutt->content != NULL && poutt->content[0] != ASCII_NUL && content_readed == false) 
	{
		elaborate[0] = ASCII_NUL;
		elaborate_offset = 0;
		offset = 0;
		buffer = poutt->content;
		content_readed = true;
		goto run_again;
	}

	free (elaborate);
}

//
// Name:  wordFinder
//
// Description: Estrapola ove possibile parola per parola da un pezzo di testo preparato dalla funzione 'textFinder'

//
// Argomenti: puntatore a parola da elaborare, limite minimo lunghezza parola.
//
unsigned short wordFinder(doc_t *doc, char *ptext, const size_t min_word_len)
{
	size_t full_length = strlen(ptext);

	unsigned short words_counter = 0; // ad ogni chiamata di funzione viene restituito il numero di parole elaborato

	// rimuove eventuali spazi in coda
	while (isspace(ptext[full_length - 1]) && full_length > 0)
		full_length--;

	size_t pos = 0;
	mbstate_t *mbs = (mbstate_t *) calloc (1, sizeof(mbstate_t));
	char *elaborate = (char *) malloc ((MAX_BYTES_WORD_LEN + 1) * sizeof(char));

	// elaborate deve poter contenere un numero di multibyte caratteri pari MAX_BYTES_WORD_LEN + ASCII_NUL

	if (full_length > min_word_len)
	do
	{ // ciclo while che estrapola le parole dal testo separato dai caratteri verificati dalla funzione 'isspace(char)'
		while (ptext[pos] != ASCII_NUL && isspace(ptext[pos]) == true)
				pos++;

		size_t c = 0;

		while (ptext[pos] != ASCII_NUL && isspace(ptext[pos]) == false)
		{
			elaborate[c] = ptext[pos];
			c++;
			pos++;
		}

		elaborate[c] = ASCII_NUL;

		const bool str_tolower = true; // convert string to lower char

		str_handler_t *conv = str_handler( (const char *)elaborate, str_tolower );

		size_t wordlen = 0; // indica il numero di caratteri visibili (compresi caratteri UTF8) nella parola
		size_t reallength = 0; // indica il numero di bytes nella parola

		if (conv->wcslen == 0)
		{
			wordlen = conv->mbslen;
			reallength = conv->mbslen;
		}
		else
		{
			wordlen = conv->wcslen;
			reallength = conv->mbslen;
		}

		if (words_counter < (USHRT_MAX - 1))
			words_counter++;

		if (conv->handled != NULL)
		{
			if (wordlen < MAX_WORD_LEN && wordlen > min_word_len && reallength < MAX_BYTES_WORD_LEN)
			{
				dymddx_status_t wrc = DYMDDX_ERROR;
				dymddx_status_t grc = DYMDDX_ERROR;
				wordid_t wordid = 0;
				gramid_t gramid = 0;

				unsigned char c = 0;

				while (conv->handled[c] != ASCII_NUL)
				{
					if (conv->handled[c] == '_')
					{
						c = UCHAR_MAX;
						break;
					}

					c++;
				}

				if (c == UCHAR_MAX)
				{
					free(conv->handled);
					continue; // skip words with underscore
				}

				/* initialize random seed: */
				// srand (openddx->word_count);

				/* generate secret number between 1 and SUPPORTED_STEM_LANGUAGES: */
				//Stemming language = (Stemming)(rand() % (SUPPORTED_STEM_LANGUAGES + 1));
				Stemming language = LANGUAGE_TO_STEMMING(doc->language);

				//Stemming language = Stemming::IT; // USO SPERIMENTALE e provvisorio perchè occorre risolvere con langid = 0
				//Stemming language = LANGUAGE_TO_STEMMING(Language::IT); // USO SPERIMENTALE e provvisorio perchè occorre risolvere con langid = 0
				wrc = dymddx_resolve_word( openddx, conv->handled, &(wordid), &(language), false );
				//openddx->distributed[((wordid - 1) % CONF_COLLECTION_DISTRIBUTED)].seqs = (sequence_t *)start_of_sequences[((wordid - 1) % CONF_COLLECTION_DISTRIBUTED)]; // ?????????

				if (wrc == DYMDDX_ERROR)
					die("dymddx error!");

				if (wrc == DYMDDX_EXISTENT)
				{
				//	cout << words[v] << " wordid " << wordid << " is existent" << endl;
				}
				else if (wrc == DYMDDX_CREATED_WORD)
				{
					if (conv->wcslen == 0)
					{
						unsigned char steps = 0; // counter of first n-grams (with '_' symbol)
						unsigned char b_offset = 0; // byte offset
						unsigned char next_b_offset = 0; // next byte offset

						while (conv->handled[b_offset] != ASCII_NUL)
						{
							char ngram[(DYMDDX_NGRAM_LEN + 1)]; // ngram len + null char

							if (steps < (DYMDDX_NGRAM_LEN - 1))
							{
								unsigned char o = 0;

								for (unsigned char g = 0; g < DYMDDX_NGRAM_LEN; g++)
								{
									if (g < (DYMDDX_NGRAM_LEN - steps - 1))
										ngram[o++] = '_';
									else
										ngram[o++] = conv->handled[b_offset++];
								}

								b_offset = 0; // in next step we must read same characters
								steps++;
							}
							else// first two ngram was created
							{
								unsigned char o = 0;

								for (unsigned char g = 0; g < DYMDDX_NGRAM_LEN; g++)
								{
										if (g == 0)
										{
											ngram[o++] = conv->handled[b_offset++];
											next_b_offset = b_offset; // keep new char offset
										}
										else
										{
											if (conv->handled[b_offset] == ASCII_NUL)
												ngram[o++] = '_';
											else
												ngram[o++] = conv->handled[b_offset++];
										}
								}

								b_offset = next_b_offset;
							}

							ngram[DYMDDX_NGRAM_LEN] = ASCII_NUL;

							grc = dymddx_resolve_gram( openddx, ngram, &(gramid), &(wordid), false );

							if (grc == DYMDDX_ERROR)
								die("dymddx error!");

//							if (grc == DYMDDX_CREATED_GRAM)
//							{
//								char buffer [50];
//								sprintf (buffer, "n-gram %s from word %s is inserted\n",ngram, conv->handled);
//								cout << buffer;
//							}

//							if (grc == DYMDDX_EXISTENT)
//							{
//								char buffer [50];
//								sprintf (buffer, "n-gram %s from word %s is existent\n",ngram, conv->handled);
//								cout << buffer;
//							}
						}
					}
					else // for multibyte char
					{
						unsigned char steps = 0; // counter of first n-grams (with '_' symbol)
						unsigned char b_offset = 0; // byte offset
						unsigned char next_b_offset = 0; // next byte offset

						while (conv->handled[b_offset] != ASCII_NUL)
						{
							char ngram[((DYMDDX_NGRAM_LEN * 6) + 1)]; // ngram len * multibyte char + null char
							size_t len = 0;

							if (steps < (DYMDDX_NGRAM_LEN - 1))
							{
								unsigned char o = 0;

								for (unsigned char g = 0; g < DYMDDX_NGRAM_LEN; g++)
								{
									if (g < (DYMDDX_NGRAM_LEN - steps - 1))
									{
										ngram[o++] = '_';
										len++;
									}
									else
									{
										if ( !mbsinit(mbs) )
											memset (mbs,0,sizeof(&mbs));  /* set to initial state */

										size_t mclen = mbrlen(&conv->handled[b_offset], sizeof(conv->handled), mbs);
										memcpy ( &ngram[o], &conv->handled[b_offset], mclen );
										len += mclen;
										o += mclen;
										b_offset += mclen;
									}
								}

								ngram[len] = ASCII_NUL;
								b_offset = 0; // in next step we must read same characters
								steps++;
							}
							else// first two ngram was created
							{
								unsigned char o = 0;

								for (unsigned char g = 0; g < DYMDDX_NGRAM_LEN; g++)
								{
									if (g == 0)
									{
										if ( !mbsinit(mbs) )
											memset (mbs,0,sizeof(&mbs));  /* set to initial state */

										size_t mclen = mbrlen(&conv->handled[b_offset], sizeof(conv->handled), mbs);
										memcpy ( &ngram[o], &conv->handled[b_offset], mclen );
										len += mclen;
										o += mclen;
										b_offset += mclen;
										next_b_offset = b_offset; // keep new char offset
									}
									else
									{
										if (conv->handled[b_offset] == ASCII_NUL)
										{
											ngram[o++] = '_';
											len++;
										}
										else
										{
											if ( !mbsinit(mbs) )
												memset (mbs,0,sizeof(&mbs));  /* set to initial state */

											size_t mclen = mbrlen(&conv->handled[b_offset], sizeof(conv->handled), mbs);
											memcpy ( &ngram[o], &conv->handled[b_offset], mclen );
											len += mclen;
											o += mclen;
											b_offset += mclen;
										}
									}
								}

								b_offset = next_b_offset;
							}

							ngram[len] = ASCII_NUL;

							grc = dymddx_resolve_gram( openddx, ngram, &(gramid), &(wordid), false );

							if (grc == DYMDDX_ERROR)
								die("dymddx error!");

//							if (grc == DYMDDX_CREATED_GRAM)
//							{
//								char buffer [50];
//								sprintf (buffer, "n-gram %s from word %s is inserted\n",ngram, conv->handled);
//								cout << buffer;
//							}

//							if (grc == DYMDDX_EXISTENT)
//							{
//								char buffer [50];
//								sprintf (buffer, "n-gram %s from word %s is existent\n",ngram, conv->handled);
//								cout << buffer;
//							}
						}
					}
				}
		//	else if (wrc == DICTDDX_NOT_FOUND)
		//		cout << words[v] << " wordid " << wordid << " is not found" << endl;
			//if (u->word_count >= (wordid_t)((float)MAXWORDS*CONF_COLLECTION_DISTRIBUTED*DICTDDX_MAX_OCCUPANCY))
/*			if (wrc == DYMDDX_EXISTENT || wrc == DYMDDX_CREATED_WORD)
				{
					char buffer [50];
					sprintf (buffer, "%d %s %d %d %s\n",doc->docid, conv->handled, wordid, openddx->word_count, LANGUAGE_STR(doc->language) );
					cout << buffer;
				}
*/
			}

			free (conv->handled);
		}

		free (conv);
	}
	while (pos++ < (full_length - min_word_len));

	free(mbs);
	free(elaborate);

	return words_counter;
}

//
// Name: cleanup
//
// Description: 
//   Closes files, indexes
//
void cleanup() {

	if( openddx != NULL ) {
		dymddx_close( openddx );
		cerr << "[dymddx] ";
	}
	if( meta != NULL ) {
		meta->ddx_close();
		delete meta;
		cerr << "[metaddx] ";
	}
	if( strg != NULL ) {
		strg->st_close();
		delete strg;
		cerr << "[storage] ";
	}
	if( langddx != NULL ) {
		langddx_close( langddx );
		cerr << "[langddx] ";
	}
}

//
// Name: doc_language_finder_usage
//
// Description:
//   Prints an usage message, then stops
//
void words_language_finder_usage() {
	cerr << "Usage: program --filelanguage filename [OPTION]" << endl;
	cerr << "Extract documents to be indexed, this is invoked by" << endl;
	cerr << "the indexer program, you should not run it directly." << endl;
	cerr << endl;
	cerr << " --from [arg]          First docid to index, default 1" << endl;
	cerr << " --to [arg]            Last docid to index, default ndocs" << endl;
	cerr << " --debugonly           DO NOT save site's content to disk or index data. It use /tmp partition for all operation." << endl;
	cerr << "                       Check if /tmp is mounted as tmpfs in /etc/fstab and if it have a large size!!!" << endl;
	cerr << " --showlanguages       If the option 'debugonly' has been selected, print only the languages stopwords and exit." << endl;
	cerr << " --help                This help message" << endl;
	cerr << endl;
	exit (0);
}
