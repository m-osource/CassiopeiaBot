#include "commons.h"
#include "Languages.h"

off64_t THEMIDX_THEM_SIZE;
off64_t THEMIDX_STEM_SIZE;
off64_t THEMIDX_WORD_SIZE;
off64_t THEMIDX_DUPL_SIZE;
off64_t THEMIDX_META_SIZE;

thematic_out_t thematic_ranking_out;
     
bool Languages::index_setup (string language, char *charenc, const size_t min_word_len, bool showthematics)
{
	string confpath(CONF_COLLECTION_BASE);

	// inizializzo i valori dichiarati staticamente dentro la classe
	first_stem_uid = 0;
	src_stem_uid = 0;
	dst_stem_uid = 0;
	left_wordform_uid = 0;
	wordformsmax = 0;
	mcline = 0;
	mcrule = 0;
	msline = 0;

	// apertura degli indici
	index_open();

	string null_string = "null";
	themid_t themid = 0;
	// inserimento stringa tematica fittizia, utile nel caso non si usi la tematica
	themidx_resolve_them( null_string.c_str(), null_string.c_str(), &(themid), false );

	cerr << "Make thematics index ..." << endl;

	// struttura che contiene l'associazione tra i termini wordforms nella colonna a sinistra e quelli della colonna di destra
	wordform_struct = (wordforms_t *) malloc (MAXWORDS * sizeof(wordforms_t));
	for (stemid_t i = 1; i < MAXWORDS; i++)
	{
		wordform_struct[i].master_wordform_uid = 0;
	}

	/* prepare stemming process: */
	stemmer = sb_stemmer_new((const char *)language.c_str(), charenc);

	string wordforms_filename = (confpath + "/" + "wordforms.txt");

	master_wordform = false;

	if (wordforms_filename.length() > 0)
	{
		unsigned int length;
		char *inbuf;
	
		ifstream inFile;  //input file stream variable
		inFile.open(wordforms_filename); //open the input file
	
	 	if (inFile)
		{	
		// posiziona in cursore alla fine del file per rilevarne la lunghezza per poi riposizionarlo all'inizio:
			inFile.seekg (0, ios::end);
			length = inFile.tellg();
			inFile.seekg (0, ios::beg);
		
			// alloca la memoria del inbuf:
			inbuf = (char *) malloc (length * sizeof(char));
		
			// legge i dati in un unico blocco:
			inFile.read (inbuf,length);
	
			//cout.write (inbuf,length);
			unsigned short nc = 0;

			//copio i dati del file ad il puntatore di puntatori pwt
			for (size_t i = 0; i < length; i++)
			{
				if (inbuf[i] == '>')
				{
						i++;

					master_wordform = true;
				}

				static char temparray[MAX_STR_LEN] = {'\0'};

				if (i == (length - 1))
				{
					temparray [nc] = '\0'; // anche se in questo caso non è necessario meglio essere prudenti

					makeWordforms(temparray, min_word_len);

					nc = 0;
				}
				else if (inbuf[i] != '\n' && inbuf[i] != ' ')
				{
					temparray [nc++] = inbuf[i];
				}
				else
				{
					temparray [nc] = '\0'; // anche se in questo caso non è necessario meglio essere prudenti

					makeWordforms(temparray, min_word_len);

					if (inbuf[i] == '\n')
						master_wordform = false;

					nc = 0;
				}
			}
			inFile.close();
			free (inbuf);
		}
		else
		{
			cerr << "Error: file " << wordforms_filename << " not found!" << endl;
			sb_stemmer_delete(stemmer);
			free (wordform_struct);
			index_close (false);
			return false;
		}
	}

	string config_filename = (confpath + "/" + "languages.conf");

	if (config_filename.length() > 0)
	{
		unsigned int length;
		char *inbuf;
	
		ifstream inFile;  //input file stream variable
		inFile.open(config_filename); //open the input file

	 	if (inFile)
		{	
		// posiziona in cursore alla fine del file per rilevarne la lunghezza per poi riposizionarlo all'inizio:
			inFile.seekg (0, ios::end);
			length = inFile.tellg();
			inFile.seekg (0, ios::beg);
		
			// alloca la memoria del inbuf:
			inbuf = (char *) malloc (length * sizeof(char));
		
			// legge i dati in un unico blocco:
			inFile.read (inbuf,length);
	
			//cout.write (inbuf,length);
			unsigned short nc = 0;

			unsigned short line = 0;

			thematics_counter = 0;

			stemming_counter = 0;

			terms_count = 0;

			bool thematic_check = true;
			bool is_thematic = false;

			size_t them_buffer_len = 0;

			size_t stem_buffer_len = 0;

			// creo gli indici delle tematiche e degli stemming dei termini dei contesti (quelli dopo la '|')
			for (size_t i = 0; i < length; i++)
			{

				if (inbuf[i] == '#')
				{
					while (inbuf[i] != '\n' && inbuf[i] != '\0')
						i++;

					line++;

					continue;
				}

				if (inbuf[i] == '|')
				{
					while (inbuf[i] == '|' || inbuf[i] == ' ')
						i++;

					thematic_check = false;
				}

				static char temparray[MAX_STR_LEN] = {'\0'};


				if (i == (length - 1))
				{
					temparray [nc] = '\0'; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != '\0')
						mcrule++;

						if (thematic_check == true)
							is_thematic = true;

						mcline = line;
					}

					if (is_thematic == true)
					{
						makeContexts(temparray, min_word_len, is_thematic, false);

						them_buffer_len += nc;

						is_thematic = false;

						thematics_counter++;
					}
					else
					{
						makeContexts(temparray, min_word_len, is_thematic, false);

						stem_buffer_len += nc;

						stemming_counter++;
					}

					first_stem_uid = 0;

					terms_count++;

					nc = 0;
				}
				else if (inbuf[i] != '\n' && inbuf[i] != ' ')
				{
					temparray [nc++] = inbuf[i];
				}
				else
				{
					temparray [nc] = '\0'; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != '\0')
						mcrule++;

						if (thematic_check == true)
							is_thematic = true;

						mcline = line;
					}

					if (is_thematic == true)
					{
						makeContexts(temparray, min_word_len, is_thematic, false);

						them_buffer_len += nc;

						is_thematic = false;

						thematics_counter++;
					}
					else
					{
						makeContexts(temparray, min_word_len, is_thematic, false);

						stem_buffer_len += nc;

						stemming_counter++;
					}

					if (inbuf[i] == '\n')
					{
						if (line >= UINT_MAX)
							die ("Error: Too many lines in configuration file of contexts!");
						else
							line++;

						first_stem_uid = 0;
						thematic_check = true;
					}

					terms_count++;

					nc = 0;
				}
			}

			// ora che si conosce la quantità di regole nel file principale si possono creare le strutture necessarie a ricavare gli offset in main_buffer
			main_structs = (main_t *) malloc (mcrule * sizeof(main_t));

			main_buffer = (context_t *) malloc (terms_count * sizeof(context_t));

			// si impostano i valori iniziali delle strutture 'main_t' puntate da main_struct
			// la prima struttura puntata NON si utilizza in quanto corrisponderebbe al stemid '0'!
			for (unsigned short i = 0; i < mcrule; i++)
			{
				main_structs[i].rule_offset = 0;
				main_structs[i].thematic = 0;
				main_structs[i].terms = 0;
			}

			line = 0;
			mcline = 0;
			mcrule = 0;

			terms_counter = 0;

			thematic_check = true;
			is_thematic = false;

			// popola il buffer principale (main_buffer) che incorpora la configurazione nel formato della struttura tipo context_t
			for (size_t i = 0; i < length; i++)
			{
				if (inbuf[i] == '#')
				{
					while (inbuf[i] != '\n' && inbuf[i] != '\0')
						i++;

					line++;

					continue;
				}

				if (inbuf[i] == '|')
				{
					while (inbuf[i] == '|' || inbuf[i] == ' ')
						i++;

					thematic_check = false;
				}

				static char temparray[MAX_STR_LEN] = {'\0'};

				// setto la struttura puntata ai valori iniziali
				main_buffer[terms_counter].rule = false;
				main_buffer[terms_counter].is_thematic = false;
				main_buffer[terms_counter].generic_id = (stemid_t)0;

				if (i == (length - 1))
				{
					temparray [nc] = '\0'; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != '\0')
						{
							mcrule++;
							main_structs[(mcrule - 1)].rule_offset = terms_counter;
						}

						if (thematic_check == true)
							is_thematic = true;
						
						mcline = line;
					}

					if (is_thematic == true)
					{
						makeContexts(temparray, min_word_len, is_thematic, true);
						is_thematic = false;

						// Le tematiche non vengono contate come termini (vedi esempio opposto sotto)
					}
					else
					{
						makeContexts(temparray, min_word_len, is_thematic, true);
						main_structs[(mcrule - 1)].terms++;

						if (main_structs[(mcrule - 1)].terms < USHRT_MAX)
							main_structs[(mcrule - 1)].terms++;
						else
						{
							cerr << "Error: Too many terms in configuration file of contexts at rule ";
							cerr << (mcrule - 1) << " (line " << mcline << ')' << endl;
						}
					}

					first_stem_uid = 0;

					nc = 0;
				}
				else if (inbuf[i] != '\n' && inbuf[i] != ' ')
				{
					temparray [nc++] = inbuf[i];
				}
				else
				{
					temparray [nc] = '\0'; // anche se in questo caso non è necessario meglio essere prudenti

					// conta le righe di configurazione valide del file delle tematiche
					if (mcline < line)
					{
						if (temparray[0] != '\0')
						{
							mcrule++;
							main_structs[(mcrule - 1)].rule_offset = terms_counter;
						}

						if (thematic_check == true)
							is_thematic = true;

						mcline = line;
					}

					if (is_thematic == true)
					{
						makeContexts(temparray, min_word_len, is_thematic, true);
						is_thematic = false;

						// Le tematiche non vengono contate come termini (vedi esempio opposto sotto)
					}
					else
					{
						makeContexts(temparray, min_word_len, is_thematic, true);

						if (main_structs[(mcrule - 1)].terms < USHRT_MAX)
							main_structs[(mcrule - 1)].terms++;
						else
						{
							cerr << "Error: Too many terms in configuration file of contexts at rule ";
							cerr << (mcrule - 1) << " (line " << mcline << ')' << endl;
						}
					}

					if (inbuf[i] == '\n')
					{
						if (line >= UINT_MAX)
							die ("Error: Too many lines in configuration file of contexts!");
						else
							line++;

						first_stem_uid = 0;
						thematic_check = true;
					}

					nc = 0;
				}
			}

			inFile.close();
			free (inbuf);

			th_dist_st = (thematic_vs_main_rules_t *) malloc ((openidx->them_count + 1) * sizeof(thematic_vs_main_rules_t));

			th_dist = (unsigned short *) malloc (thematics_counter * sizeof(unsigned short));

			thematics_counter = 0;

			// il themid '0' non si utilizza
			th_dist_st[0].th_dist_offset = (unsigned int)UINT_MAX;

			// crea lo schema di distribuzione nelle regole (rules) del main_buffer, delle tematiche
			for (themid_t themid = 1; themid <= openidx->them_count; themid++)
			{
				bool isoffset = true;

				th_dist_st[themid].th_dist_offset = (unsigned int)UINT_MAX;

				unsigned int old_th_dist_offset = (unsigned int)UINT_MAX;

				if (themid > 1)
					old_th_dist_offset = th_dist_st[themid - 1].th_dist_offset;

				for (unsigned long int i = 0; i < terms_counter; i++)
				{
					if (main_buffer[i].is_thematic == true && main_buffer[i].generic_id == themid)
					{
						if (isoffset == true)
						{
							th_dist_st[themid].th_dist_offset = thematics_counter;

							if ((th_dist_st[themid].th_dist_offset - old_th_dist_offset) >= UCHAR_MAX)
							{
								char *thematic = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));

								themidx_them_by_themid(themid, thematic);

								cerr << "Too many rule for tematic " << thematic << " in main configuration file!" << endl;

								free (thematic);

								exit(1);
							}

							isoffset = false;
						}

						th_dist[thematics_counter] = main_buffer[i].rule;
						thematics_counter++;
					}
							
				}	
			}

			st_dist_st = (stemming_vs_main_rules_t *) malloc ((openidx->stem_count + 1) * sizeof(stemming_vs_main_rules_t));

			st_dist = (idx_id_vs_rules_t *) malloc (stemming_counter * sizeof(idx_id_vs_rules_t));

			stemming_counter = 0;

			// lo stemid '0' non si utilizza
			st_dist_st[0].st_dist_offset = (unsigned int)UINT_MAX;

			// crea lo schema di distribuzione nelle regole (rules) del main_buffer, degli stemming
			for (stemid_t stemid = 1; stemid <= openidx->stem_count; stemid++)
			{
				bool isoffset = true;

				st_dist_st[stemid].st_dist_offset = (unsigned int)UINT_MAX;

				unsigned int old_st_dist_offset = (unsigned int)UINT_MAX;

				if (stemid > 1)
					old_st_dist_offset = st_dist_st[stemid - 1].st_dist_offset;
				else
					old_st_dist_offset = 0;

				for (unsigned long int i = 0; i < terms_counter; i++)
				{
					if (main_buffer[i].is_thematic == false && main_buffer[i].generic_id == stemid)
					{
						if (isoffset == true)
						{
							st_dist_st[stemid].st_dist_offset = stemming_counter;

							if ((st_dist_st[stemid].st_dist_offset - old_st_dist_offset) >= UCHAR_MAX)
							{

								char *stemming = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));

								themidx_stem_by_stemid(stemid, stemming);

								cerr << "Too many rule for stemming " << stemming << " in main configuration file!" << endl;

								free (stemming);

								exit(1);
							}

							isoffset = false;
						}

						st_dist[stemming_counter].rule = main_buffer[i].rule;
						stemming_counter++;
					}
							
				}	
			}

			// calcolo coefficenti distribuzione stemming dei contesti
			for (stemid_t stemid = 1; stemid <= openidx->stem_count; stemid++)
				if (st_dist_st[stemid].st_dist_offset < UINT_MAX)
				{
					unsigned char amount_rules = 0;

					if (stemid < openidx->stem_count)
						amount_rules = (st_dist_st[stemid + 1].st_dist_offset - st_dist_st[stemid].st_dist_offset);
					else
						amount_rules = (stemming_counter - st_dist_st[stemid].st_dist_offset);

					struct them {
						themid_t thematic;
						unsigned short count;
					} *thems = (them *) malloc (amount_rules * sizeof(them));

					bool found = false;

					unsigned char pos = 0;

					for (unsigned char a = 0; a < amount_rules; a++)
						thems[a].thematic = 0;

					for (unsigned char a = 0; a < amount_rules; a++)
					{
						for (unsigned char b = 0; b < amount_rules; b++)
						{
							if (thems[b].thematic == main_structs[st_dist[(st_dist_st[stemid].st_dist_offset + a)].rule].thematic)
							{
								found = true;
								thems[b].count++;
								break;
							}
						}

						if (found == false)
						{
							thems[pos].thematic = main_structs[st_dist[(st_dist_st[stemid].st_dist_offset + a)].rule].thematic;

							thems[pos].count = 1;
							pos++;
						}
						else
							found = false;
					}

					unsigned short ttfs = 0; // total thematics for stemid

					for (unsigned char a = 0; a < amount_rules && thems[a].thematic > 0; a++)
						ttfs++;
						
					for (unsigned char a = 0; a < amount_rules; a++)
					{
						themid_t thematic = main_structs[st_dist[(st_dist_st[stemid].st_dist_offset + a)].rule].thematic;

						unsigned char them_address = 0;

						for (them_address = 0; them_address < amount_rules && thems[them_address].thematic > 0; them_address++)
							if (thematic == thems[them_address].thematic)
								break;

						// se la tematica è 'null' non si calcola la distribuzione dentro la tematica nulla
						if (thematic == (themid_t)1) // null
							st_dist[(st_dist_st[stemid].st_dist_offset + a)].location_coefficient = ttfs;
						else
							st_dist[(st_dist_st[stemid].st_dist_offset + a)].location_coefficient = ttfs * thems[them_address].count;
					}
/*// uso debug
					//char *ppp = (char *) malloc (MAX_WORD_LEN * sizeof(char));
					//themsidx_stem_by_stemid(stemid, ppp);
					//cout << endl;
					//free (ppp);
*/////
					free (thems);
				}

			/*/// debug
			for (stemid_t stemid = 1; stemid <= openidx->stem_count; stemid++)
				if (st_dist_st[stemid].st_dist_offset < UINT_MAX)
						cout << "Stemming id " << stemid << " offset of rule start in main_buffer "
						<< st_dist_st[stemid].st_dist_offset << endl;

			for (themid_t themid = 1; themid <= openidx->them_count; themid++)
				if (th_dist_st[themid].th_dist_offset < UINT_MAX)
						cout << "Thematic id " << themid << " offset of rule start in main_buffer "
						<< th_dist_st[themid].th_dist_offset << endl;
			*//// fine debug //
		}
		else
		{
			cerr << "Error: file " << config_filename << " not found!" << endl;
			sb_stemmer_delete(stemmer);
			free (wordform_struct);
			index_close (false);
			return false;
		}
	}

	// se è stata scelta la relativa opzione in combinazione con 'debugonly' stampa le tematiche ed esce immediatamente
	if (showthematics == true)
	{
		cerr << "Print thematics and exit..." << endl;
		char *stemname = (char *) malloc (sizeof(char)*MAX_WORD_LEN);
		stemname[0] = '\0';
		char *dstname = (char *) malloc (sizeof(char)*MAX_WORD_LEN);
		dstname[0] = '\0';
		char *thematic = (char *) malloc (sizeof(char)*MAX_WORD_LEN);
		thematic[0] = '\0';
		char *wordname = (char *) malloc (sizeof(char)*MAX_WORD_LEN);
		wordname[0] = '\0';

		unsigned short oldrule = 0;
		bool stemming = false;

		for (unsigned short s = 0; s < terms_counter; s++)
		{
			if (s == 0)
				cout << "regola 0 ";

			if (main_buffer[s].rule > oldrule)
			{
				cout << endl;
				oldrule = main_buffer[s].rule;
				cout << "regola " << main_buffer[s].rule << ' ';
				stemming = false;
			}

			if (main_buffer[s].is_thematic == true)
			{
				char *thematic = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));

				themidx_them_by_themid(main_buffer[s].generic_id, thematic);

				cout << thematic;

				free (thematic);

				cout << ' ';
			}
			else if (main_buffer[s].is_thematic == false)
			{
				if (stemming == false)
				{
					cout << '|';
					stemming = true;
				}

				char *original = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));

				themidx_stem_by_stemid(main_buffer[s].generic_id, original);

				cout << ' ' << original;

				free (original);
			}
			//	cout << ' ' << main_buffer[s].generic_id << endl;
		}

		cout << endl;

		free (stemname);
		free (dstname);
		free (thematic);
		free (wordname);

		return true;
	}

	// assegno la memoria al buffer del ranking che racchiude 'regole e relativi ranking) posizionati in coppie affiancate
	ranking_buffer = (ranking_t *) malloc (RBSIZE * sizeof(ranking_t));

	thematic_ranking = (unsigned long int *) malloc ((openidx->them_count + 1) * sizeof(unsigned long int));

	return true;
}

//
// Name: Languages::makeWordforms 
//
// Description: Riceve i termini wordforms dal file wordforms.txt e crea la struttura dei termini wordforms (ai termini wordforms non viene applicato stemming)
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola.
//
void Languages::makeWordforms(char *ptext, const size_t min_word_len)
{
	size_t textlen = strlen(ptext);

	// rimuove eventuali spazi in coda
	while (ptext[textlen - 1] == ' ' && textlen > 0)
		textlen--;

	size_t pos = 0;
	size_t toffstart = 0;
	size_t toffstop = 0;
	bool found = false;
	bool single_char = false;

	if (((int)textlen - (int)min_word_len) >= 0)
	do
	{
		while (isalpha(ptext[pos]) && pos < textlen)
		{
			pos++;

			found = true;
		}

		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(ptext[pos]) == false) && isalpha(ptext[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(ptext[pos]) == false)))
					toffstop = (pos - 1);
				else if (pos == (textlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			char *pword = printWord(ptext, toffstart, (toffstop + 1), true);

			wordid_t wordid = 0;

			themidx_status_t wrc = THEMIDX_ERROR;

			if (((toffstop + 1) - toffstart) < MAX_WORD_LEN && ((toffstop + 1) - toffstart) > min_word_len)
			{
				// quì va salvato tutto
				wrc = themidx_resolve_word( pword, &(wordid), false );

				if ( wrc == THEMIDX_CREATED_WORD )
					wordformsmax++;

				if ( ! (wrc == THEMIDX_CREATED_WORD) && master_wordform == false)
				{
					cerr << "Error: '" << pword << "' is duplicated with id " << wordid << endl;
					die ("Check error in wordforms file!");
					
				}
				else
				{
					if (master_wordform == true)
						wordform_struct[left_wordform_uid].master_wordform_uid = wordid;

					if (master_wordform == true && wrc == THEMIDX_CREATED_WORD)
						wordform_struct[wordid].master_wordform_uid = wordid;

					if (left_wordform_uid == 0)
						left_wordform_uid = wordid;
					else
						left_wordform_uid = 0;
				}
			}
			free (pword);
		}

		while ((isalpha(ptext[pos]) == false) && pos < (textlen - min_word_len))
			pos++;

		toffstart = pos;

		found = false;
		single_char = false;
	}
	while (pos++ < (textlen - min_word_len));
}

//
// Name: Languages::makeContexts 
//
// Description: Riceve i contesti ed eventuali tematiche dal file di configurazione principale contexts.conf e crea la struttura dei contesti
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola, numero linea nel file.
//
void Languages::makeContexts(char *ptext, const size_t min_word_len, bool is_thematic, bool append_buffer)
{
	const bool str_tolower = true; // convert string to lower char

	str_handler_t *conv = str_handler( (const char *)ptext, str_tolower );

	size_t textlen = 0;
	size_t reallength = 0;

	if (conv->wcslen == 0)
	{
		textlen = conv->mbslen;
		reallength = conv->mbslen;
	}
	else
	{
		textlen = conv->wcslen;
		reallength = conv->mbslen;
	}
cout << conv->handled << endl;
	// rimuove eventuali spazi in coda

			themidx_status_t trc = THEMIDX_ERROR;
			themidx_status_t src = THEMIDX_ERROR;
			themidx_status_t wrc = THEMIDX_ERROR;

			wordid_t wordid = 0;
			themid_t themid = 0;
			stemid_t stemid = 0;

			if (textlen < MAX_WORD_LEN && textlen > min_word_len)
			{
				// quì va salvato tutto
				// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
				// in quanto non si tratta di una parola
//				if ( ! (reallength == 3 && strcmp(conv->handled, "amp") == 0)) // equivale ad unless in perl
				if (reallength > min_word_len && reallength < MAX_WORD_LEN)
				{
					if (is_thematic == true)
					{
						if (append_buffer == false)
						{
							wrc = themidx_resolve_word( conv->handled, &(wordid), true );

							if (wrc == THEMIDX_EXISTENT)
							{
								if (wordid <= wordformsmax)
								{
									char *masterwordform = (char *) malloc (sizeof(char)*MAX_WORD_LEN);
									masterwordform[0] = '\0';
	
									themidx_word_by_wordid( wordform_struct[wordid].master_wordform_uid, masterwordform );
	
									// Se il programma NON indica che il termine NON è già stato utilizzato allora si può procedere
									themidx_resolve_them( conv->handled, masterwordform, &(themid), false );

									free (masterwordform);
								}
							}
							else
							{
								char *stemming = doBaseStemming(conv->handled, reallength, ((toffstop + 2) - toffstart));
	
								if (stemming != NULL)
								{
									wrc = themidx_resolve_word( stemming, &(wordid), true );
									// se nell'indice dei wordforms non si è trovato il termine intero può darsi che esista
									// sotto forma di stemming di sinonimi (in questo caso il wordid sarà maggiore di 'wordformsmax'
									if (wrc == THEMIDX_NOT_FOUND)
										src = themidx_resolve_stem( conv->handled, stemming, NULL, true );

									if (wrc == THEMIDX_EXISTENT && src == THEMIDX_ERROR)
									{
										cerr << "Thematic '" << conv->handled << "' is already used in file of synonmys!" << endl;
										exit(1);
									}
								
									// Se il programma NON indica che il termine NON è già stato utilizzato allora si può procedere
									themidx_resolve_them( conv->handled, stemming, &(themid), false );

									free (stemming);
								}
								else
								{
									cerr << "Thematic '" << conv->handled << "' cannot be processed (context term)!" << endl;
									exit(1);
								}
							}
						}
						else
						{
							char *stemming = doStemming(conv->handled, reallength, ((toffstop + 2) - toffstart));

							trc = themidx_resolve_them( NULL, stemming, &(themid), true );

							free (stemming);

							main_structs[(mcrule - 1)].thematic = themid;
	
							if (trc == THEMIDX_EXISTENT)
							{
								main_buffer[terms_counter].rule = (mcrule - 1);
								main_buffer[terms_counter].is_thematic = is_thematic;
								main_buffer[terms_counter].generic_id = (stemid_t)themid;

								terms_counter++;
							}
						}
					}
					else // Quando un termine risulta inserito in wordforms, questi viene escluso dallo stemming.
					// Al suo posto nell'indice dello stemming viene inserito il termine corrispettivo (arbitrariamente chiamato masterwordform)
					// presente nella colonna destra del file di configurazione dei termini wordforms.
					{
						wrc = themidx_resolve_word( conv->handled, &(wordid), true );

						if (wrc == THEMIDX_EXISTENT)
						{
							if (wordid <= wordformsmax)
							{
								char *masterwordform = (char *) malloc (sizeof(char)*MAX_WORD_LEN);
								masterwordform[0] = '\0';
	
								themidx_word_by_wordid( wordform_struct[wordid].master_wordform_uid, masterwordform );
	
								src = themidx_resolve_stem( conv->handled, masterwordform, &(stemid), false );
	
								free (masterwordform);
							}
						}
						else
						{
							// se le condizioni lo permettono estraiamo lo stemming dalla parola
							if (reallength > min_word_len && reallength < MAX_WORD_LEN)
							{
								char *stemming = doBaseStemming(conv->handled, reallength, ((toffstop + 2) - toffstart));
	
								if (stemming != NULL)
								{
									wrc = themidx_resolve_word( stemming, NULL, true );
	
									if (wrc == THEMIDX_NOT_FOUND)
										src = themidx_resolve_stem( conv->handled, stemming, &(stemid), false );
									else
									{
										cerr << "Stemming of '" << conv->handled << "' is already used as synonmys!" << endl;
										exit(1);
									}

									free (stemming);
								}
							}
						}
	
						if (append_buffer == true)
						{
							if (src == THEMIDX_EXISTENT)
							{
								main_buffer[terms_counter].rule = (mcrule - 1);
								main_buffer[terms_counter].generic_id = stemid;
	
								terms_counter++;
							}
						}
					}
				}
			}
			free (conv->handled);
			free (conv);
}

//
// Name: Languages::doStemming 
//
// Description: Converte un termine nel suo stemming dopo aver prima verificato che non abbia un wordform.
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola.
//
char *Languages::doStemming(char *pword, size_t reallength, size_t sb_symbol_size) const
{
	themidx_status_t wrc = THEMIDX_ERROR;

	wordid_t wordid = 0;

	wrc = themidx_resolve_word( pword, &(wordid), true );

	// esiste nel file dei wordform e non si deve estrarre lo stemming	
	if (wrc == THEMIDX_EXISTENT && wordid <= wordformsmax)
	{
		char *stemming = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));
		stemming[0] = '\0';

		themidx_word_by_wordid( wordform_struct[wordid].master_wordform_uid, stemming );

		return stemming;
	}

	sb_symbol *b = (sb_symbol *) malloc(sb_symbol_size * sizeof(sb_symbol));

	for (size_t o = 0; o <= reallength; o++)
	{
		if (o == reallength)
			b[o] = '\0';
		else
        		b[o] = pword[o];
	}

	unsigned short err_count = 0;
	unsigned short max_alloc = 3;

	const sb_symbol *stemmed;

	do
	{
		err_count++;
		stemmed = sb_stemmer_stem(stemmer, b, reallength);

		if (stemmed == NULL && err_count > max_alloc)
		{
			free (b);
			free (pword);
			cerr << "Error allocating stemming memory for " << err_count << " times." << endl;
       			die ("process died");
       		}
	}
        while (stemmed == NULL);

	free(b);

	int lout = sb_stemmer_length(stemmer);

	if (lout > 0)
	{
		char *stemming = (char *) malloc ((lout + 1) * sizeof(char));

		memcpy(stemming, (const char *)stemmed, (lout + 1));

		return stemming;
	}

	return NULL;
}

//
// Name: Languages::doBaseStemming 
//
// Description: Converte un termine nel suo stemming.
//
// Argomenti: puntatore al termine da inserire nella struttura, limite minimo lunghezza parola.
//
char *Languages::doBaseStemming(char *pword, size_t reallength, size_t sb_symbol_size) const
{
	const sb_symbol *stemmed = NULL;

	sb_symbol *b = (sb_symbol *) malloc(sb_symbol_size * sizeof(sb_symbol));

	for (size_t o = 0; o <= reallength; o++)
	{
		if (o == reallength)
			b[o] = '\0';
		else
        		b[o] = pword[o];
	}

	unsigned short err_count = 0;
	unsigned short max_alloc = 3;

	do
	{
		err_count++;
		stemmed = sb_stemmer_stem(stemmer, b, reallength);

		if (stemmed == NULL && err_count > max_alloc)
		{
			free (b);
			free (pword);
			cerr << "Error allocating stemming memory for " << err_count << " times." << endl;
       			die ("process died");
       		}
	}
        while (stemmed == NULL);

	free(b);

	int lout = sb_stemmer_length(stemmer);

	if (lout > 0)
	{
		char *stemming = (char *) malloc ((lout + 1) * sizeof(char));

		memcpy(stemming, (const char *)stemmed, (lout + 1));

		return stemming;
	}

	return NULL;
}

//
// Name: Languages::checkThematicWord 
//
// Description: Controlla se la parola in input è inserita in un contesto...

//
// Argomenti: puntatore a parola da elaborare, limite minimo lunghezza parola.
//
unsigned short Languages::checkThematicWord(char *ptext, const size_t min_word_len, bool stop_ranking, bool in_domain, bool is_clevel) const
{
	size_t textlen = strlen(ptext);

	unsigned short words_counter = 0; // ad ogni chiamata di funzione viene restituito il numero di parole elaborato

	// rimuove eventuali spazi in coda
	while (ptext[textlen - 1] == ' ' && textlen > 0)
		textlen--;

	size_t pos = 0;
	size_t toffstart = 0;
	size_t toffstop = 0;
	bool found = false;
	bool single_char = false;

	if (((int)textlen - (int)min_word_len) >= 0)
	do
	{
		while ((isalpha(ptext[pos]) || convSpecialChar(ptext, textlen, pos) != ' ') && pos < textlen)
		{
			if (convSpecialChar(ptext, textlen, pos) != ' ')
				pos += 2;
			else
				pos++;

			found = true;
		}

		if (pos > 0 && min_word_len == 0 && found == false && (isalpha(ptext[pos]) == false) && isalpha(ptext[toffstart]))
		{
			found = true;
			single_char = true;
		}

		if (found == true)
		{
			if (single_char == false)
			{
				if (((isalpha(ptext[pos]) == false) && convSpecialChar(ptext, textlen, pos) == ' '))
					toffstop = (pos - 1);
				else if (pos == (textlen - 1))
					toffstop = pos;
			}
			else
					toffstop = (pos - 1);

			bool eccezione_carattere = false; // quasi tutte le vocali e consonanti seguite da apostrofo

			char *pword = printWord(ptext, toffstart, (toffstop + 1), true);

			if (words_counter < (USHRT_MAX- 1))
				words_counter++;

			size_t reallength = strlen(pword); // nel caso il termine originale contiene lettere 'conosciute' accentate la lunghezza di pword è minore

			themidx_status_t mrc = THEMIDX_ERROR;
			themidx_status_t trc = THEMIDX_ERROR;
			themidx_status_t src = THEMIDX_ERROR;
			themidx_status_t wrc = THEMIDX_ERROR;
			themidx_status_t drc = THEMIDX_ERROR;

			metaid_t metaid = 0;
			themid_t themid = 0;
			wordid_t wordid = 0;
			stemid_t stemid = 0;
			duplid_t duplid = 0;

			if (((toffstop + 1) - toffstart) <= MIN_WORD_LEN)
			{
				// quì va salvato tutto
				// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
				// in quanto non si tratta di una parola
				if ((reallength == 1 && (pword[0] == 'a' || pword[0] == 'e' || pword[0] == 'i' || pword[0] == 'o' || pword[0] == 'd' || pword[0] == 'l')))
				{
					eccezione_carattere = true;

					wrc = themidx_resolve_word( pword, &(wordid), true );

					if (wrc == THEMIDX_NOT_FOUND)
					{
						char *stemming = doBaseStemming(pword, reallength, ((toffstop + 2) - toffstart));

						wrc = themidx_resolve_word( stemming, &(wordid), true );
						// se nell'indice dei wordforms non si è trovato il termine intero può darsi che esista
						// sotto forma di stemming di sinonimi (in questo caso il wordid sarà maggiore di 'wordformsmax'

						if (in_domain == true)
							// aggiunge il termine se non presente, all'indice delle meta words
							mrc = themidx_resolve_meta( stemming, &(metaid), false );
						else
							// verifica se il termine è gia stato elaborato
							drc = themidx_resolve_dupl( pword, stemming, &(duplid), false );
							
						free (stemming);
					}

					if (wrc == THEMIDX_EXISTENT)
					{
						wordid = wordform_struct[wordid].master_wordform_uid;

						char *masterwordform = (char *) malloc (sizeof(char)*MAX_WORD_LEN);
						masterwordform[0] = '\0';

						themidx_word_by_wordid( wordid, masterwordform );

						if (in_domain == true)
							// aggiunge il termine se non presente, all'indice delle meta words
							mrc = themidx_resolve_meta( masterwordform, &(metaid), false );
						else
							// verifica se il termine è gia stato elaborato
							drc = themidx_resolve_dupl( pword, masterwordform, &(duplid), false );
							
						free (masterwordform);

						// termine non ancora elaborato. Cerco tra gli stemming
						if (mrc == THEMIDX_CREATED_META || drc == THEMIDX_CREATED_DUPL)
						{
							// condizione in teoria non necessaria perchè un wordid > wordformsmax significa
							// che è un termine sinonimo e non può esistere negli stemming (contesti)
							if (wordid > wordformsmax)
							{
								char *stemming = doBaseStemming(pword, reallength, ((toffstop + 2) - toffstart));

								src = themidx_resolve_stem( pword, stemming, &(stemid), true );

								free (stemming);
							}
							else
							{
								char *masterwordform = (char *) malloc (sizeof(char)*MAX_WORD_LEN);
								masterwordform[0] = '\0';
	
								themidx_word_by_wordid( wordid, masterwordform );
	
								// verifica prima se il termine è una tematica
								if (strcmp(masterwordform, "null") != 0)
									trc =  themidx_resolve_them( NULL, masterwordform, &(themid), true );

								src = themidx_resolve_stem( NULL, masterwordform, &(stemid), true );
							
								free (masterwordform);
							}

							if (in_domain == false)
							{
								if (stop_ranking == false)
								{
									// punteggio a headings nel contenuto
									if (duplid < thematic_ranking_out.duplicates_split_offset[0])
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, true, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, true, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, false, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, false, false);
									}
								}
							}
							else
							{
								if (is_clevel == false) // punteggio trattato come headings nel contenuto
								{
									if (trc == THEMIDX_EXISTENT)
										rankingAllocation((stemid_t)themid, true, true);

									if (src == THEMIDX_EXISTENT)
										rankingAllocation(stemid, true, false);
								}
								else	
								{
									if (trc == THEMIDX_EXISTENT)
										rankingAllocation((stemid_t)themid, false, true);

									if (src == THEMIDX_EXISTENT)
										rankingAllocation(stemid, false, false);
								}
							}
						}
					}
					else
					{
						char *stemming = doBaseStemming(pword, reallength, ((toffstop + 2) - toffstart));

						if (stemming != NULL)
						{
							// verifica prima se il termine è una tematica
							if (strcmp(stemming, "null") != 0)
								trc =  themidx_resolve_them( NULL, stemming, &(themid), true );

							src = themidx_resolve_stem( NULL, stemming, &(stemid), true );

							if (in_domain == false)
							{
								if (drc == THEMIDX_CREATED_DUPL && stop_ranking == false)
								{
									// punteggio a headings nel contenuto
									if (duplid < thematic_ranking_out.duplicates_split_offset[0])
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, true, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, true, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, false, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, false, false);
									}
								}
							}
							else
							{
								if (mrc == THEMIDX_CREATED_META)
								{
									// punteggio a headings nel contenuto
									if (is_clevel == false) // punteggio trattato come headings nel contenuto
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, true, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, true, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, false, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, false, false);
									}
								}
							}

							free (stemming);
						}
					}
				}
				else if (reallength == 1)
				{
					eccezione_carattere = true;
				}
			}

			if (((toffstop + 1) - toffstart) < MAX_WORD_LEN && ((toffstop + 1) - toffstart) > min_word_len && eccezione_carattere == false)
			{
				// quì va salvato tutto
				// N.B. la stringa 'amp' viene inserita nei testi in sostituzione della segno di codifica '&amp;' perciò deve essere esclusa
				// in quanto non si tratta di una parola
				if ( ! (reallength == 3 && strcmp(pword, "amp") == 0)) // equivale ad unless in perl
				if (reallength > min_word_len && reallength < MAX_WORD_LEN)
				{
					wrc = themidx_resolve_word( pword, &(wordid), true );

					if (wrc == THEMIDX_NOT_FOUND)
					{
						char *stemming = doBaseStemming(pword, reallength, ((toffstop + 2) - toffstart));

						wrc = themidx_resolve_word( stemming, &(wordid), true );
						// se nell'indice dei wordforms non si è trovato il termine intero può darsi che esista
						// sotto forma di stemming di sinonimi (in questo caso il wordid sarà maggiore di 'wordformsmax'

						if (in_domain == true)
							// aggiunge il termine se non presente, all'indice delle meta words
							mrc = themidx_resolve_meta( stemming, &(metaid), false );
						else
							// verifica se il termine è gia stato elaborato
							drc = themidx_resolve_dupl( pword, stemming, &(duplid), false );
							
						free (stemming);
					}

					if (wrc == THEMIDX_EXISTENT)
					{
						wordid = wordform_struct[wordid].master_wordform_uid;

						char *masterwordform = (char *) malloc (sizeof(char)*MAX_WORD_LEN);
						masterwordform[0] = '\0';

						themidx_word_by_wordid( wordid, masterwordform );

						if (in_domain == true)
							// aggiunge il termine se non presente, all'indice delle meta words
							mrc = themidx_resolve_meta( masterwordform, &(metaid), false );
						else
							// verifica se il termine è gia stato elaborato
							drc = themidx_resolve_dupl( pword, masterwordform, &(duplid), false );
						
						free (masterwordform);

						// termine non presente nel file dei sinonimi e non ancora elaborato. Cerco tra gli stemming
						if (mrc == THEMIDX_CREATED_META || drc == THEMIDX_CREATED_DUPL)
						{
							char *masterwordform = (char *) malloc (sizeof(char)*MAX_WORD_LEN);
							masterwordform[0] = '\0';

							themidx_word_by_wordid( wordid, masterwordform );

							// verifica prima se il termine è una tematica
							if (strcmp(masterwordform, "null") != 0)
								trc =  themidx_resolve_them( NULL, masterwordform, &(themid), true );

							src = themidx_resolve_stem( NULL, masterwordform, &(stemid), true );
						
							free (masterwordform);

							if (in_domain == false)
							{
								if (stop_ranking == false)
								{
									// punteggio a headings nel contenuto
									if (duplid < thematic_ranking_out.duplicates_split_offset[0])
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, true, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, true, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, false, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, false, false);
									}
								}
							}
							else
							{
								if (is_clevel == false) // punteggio trattato come headings nel contenuto
								{
									if (trc == THEMIDX_EXISTENT)
										rankingAllocation((stemid_t)themid, true, true);

									if (src == THEMIDX_EXISTENT)
										rankingAllocation(stemid, true, false);
								}
								else	
								{
									if (trc == THEMIDX_EXISTENT)
										rankingAllocation((stemid_t)themid, false, true);

									if (src == THEMIDX_EXISTENT)
										rankingAllocation(stemid, false, false);
								}
							}
						}
					}
					else
					{
						char *stemming = doBaseStemming(pword, reallength, ((toffstop + 2) - toffstart));

						if (stemming != NULL)
						{
							// verifica prima se il termine è una tematica
							if (strcmp(stemming, "null") != 0)
								trc =  themidx_resolve_them( NULL, stemming, &(themid), true );

							src = themidx_resolve_stem( NULL, stemming, &(stemid), true );

							if (in_domain == false)
							{
								if (drc == THEMIDX_CREATED_DUPL && stop_ranking == false)
								{
									// punteggio a headings nel contenuto
									if (duplid < thematic_ranking_out.duplicates_split_offset[0])
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, true, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, true, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, false, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, false, false);
									}
								}
							}
							else
							{
								if (mrc == THEMIDX_CREATED_META)
								{
									// punteggio a headings nel contenuto
									if (is_clevel == false) // punteggio trattato come headings nel contenuto
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, true, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, true, false);
									}
									else
									{
										if (trc == THEMIDX_EXISTENT)
											rankingAllocation((stemid_t)themid, false, true);

										if (src == THEMIDX_EXISTENT)
											rankingAllocation(stemid, false, false);
									}
								}
							}

							free (stemming);
						}
					}
				}
			}
			free (pword);
		}

		bool testspecial = false;

		while ((isalpha(ptext[pos]) == false) && pos < (textlen - min_word_len))
			if (ptext[pos] != ' ' && (convSpecialChar(ptext, textlen, pos) != ' '))
			{
				testspecial = true;
				pos--;
				break;
			}
			else
				pos++;

		if (testspecial == true)
			toffstart = pos + 1;
		else
			toffstart = pos;

		found = false;
		single_char = false;
	}
	while (pos++ < (textlen - min_word_len));

	return words_counter;
}

void Languages::rankingAllocation(stemid_t id, bool is_heading, bool is_thematic) const
{
	unsigned int rank_limit = (UINT_MAX - USHRT_MAX);

	unsigned short HEADING_AWARD = 30; // valore aggiunto in percentuale se il termine si trova nel puntatore poutt->headings

	if (is_thematic == true)
	{
		themid_t themid = id;

		unsigned char amount_rules = 0;

		unsigned int rank = 0;

		if (themid < openidx->them_count)
			amount_rules = (th_dist_st[themid + 1].th_dist_offset - th_dist_st[themid].th_dist_offset);
		else
			amount_rules = (thematics_counter - th_dist_st[themid].th_dist_offset);
			// thematics_counter indica la lunghezza del buffer th_dist

		if (amount_rules > 0)
		{
			if (is_heading == true)
				rank = (USHRT_MAX + ((USHRT_MAX / 100) * HEADING_AWARD / 2));
			else
				rank = USHRT_MAX;

			rank_limit = (UINT_MAX - rank); // imposta il valore massimo del ranking
		}

		for (unsigned char a = 0; a < amount_rules; a++)
		{
			unsigned char i;

			bool ranking_assigned = false;

			for (i = 0; i < RBSIZE; i++)
			{
				if (ranking_buffer[i].rule == USHRT_MAX)
					break;
	
				if (ranking_buffer[i].rule == th_dist[(th_dist_st[themid].th_dist_offset + a)])
				{
					// non deve superare il limite del tipo dato
					if (ranking_buffer[i].them_ranking >= (rank_limit - 1))
						return;

					ranking_buffer[i].them_ranking += rank;

					ranking_assigned = true;

					break;
				}
			}

			// non è stata trovata la regola nel ranking_buffer ma esiste lo spazio per inserirla
			if (ranking_assigned == false && i < (RBSIZE - 1))
			{
				// non deve superare il limite del tipo dato
				if (ranking_buffer[i].them_ranking >= (rank_limit - 1))
					return;

				ranking_buffer[i].them_ranking += rank;

				ranking_buffer[i].rule = th_dist[(th_dist_st[themid].th_dist_offset + a)];

				thematic_ranking_out.ranked_rules++;
			}
		}
		/* debug purpose
		char *word = (char *) malloc (MAX_WORD_LEN * sizeof(char));
		themidx_them_by_themid(themid, word);
		cout << word << '-' << themid << '-' << is_synonyms << '-' << is_heading << '-' <<  is_thematic << '-' <<  in_sensitive << endl;
		free(word);
		*/
	}
	else
	{
		stemid_t stemid = id;

		unsigned char amount_rules = 0;

		unsigned int rank_max = 0;

		unsigned int rank = 0;

		if (stemid < openidx->stem_count)
			amount_rules = (st_dist_st[stemid + 1].st_dist_offset - st_dist_st[stemid].st_dist_offset);
		else
			amount_rules = (stemming_counter - st_dist_st[stemid].st_dist_offset);
			// stemming_counter indica la lunghezza del buffer st_dist

		if (amount_rules > 0)
		{
			if (is_heading == true)
				rank_max = (USHRT_MAX + ((USHRT_MAX / 100) * HEADING_AWARD));
			else
				rank_max = USHRT_MAX;
		}

		for (char a = 0; a < amount_rules; a++)
		{
			unsigned char i;

			bool ranking_assigned = false;

			// imposta il valore massimo del ranking. In quante tematiche e in quante regole dentro tali tematiche del file pricipale
			// è presente il termine, in tal caso perde valore
			rank = rank_max / st_dist[(st_dist_st[stemid].st_dist_offset + a)].location_coefficient;

			rank_limit = (UINT_MAX - rank);

			for (i = 0; i < RBSIZE; i++)
			{

				if (ranking_buffer[i].rule == USHRT_MAX)
						break;
	
				if (ranking_buffer[i].rule == st_dist[(st_dist_st[stemid].st_dist_offset + a)].rule)
				{
					// non deve superare il limite del tipo dato
					if (ranking_buffer[i].ranking >= (rank_limit - 1))
						return;

					ranking_buffer[i].ranking += rank;

					ranking_assigned = true;

					break;
				}
			}

			// non è stata trovata la regola nel ranking_buffer ma esiste lo spazio per inserirla
			if (ranking_assigned == false && i < (RBSIZE - 1))
			{
				// non deve superare il limite del tipo dato
				if (ranking_buffer[i].ranking >= (rank_limit - 1))
					return;

				ranking_buffer[i].rule = st_dist[(st_dist_st[stemid].st_dist_offset + a)].rule;

				ranking_buffer[i].ranking += rank;

				thematic_ranking_out.ranked_rules++;
			}
		}
		/* debug purpose
		char *word = (char *) malloc (MAX_WORD_LEN * sizeof(char));
		themidx_stem_by_stemid(stemid, word);
		cout << word << '-' << stemid << endl;
		free(word);
		*/
	}
}

void Languages::make_dupl_index (const size_t min_word_len, pes_t *poutt, size_t content_len) const
{
	// creazione indici con durata limitata all'esecuzione della funzione
	//
	openidx->dupl_hash = (off64_t *)malloc(sizeof(off64_t)*MAXDUPLICATES);
	assert( openidx->dupl_hash != NULL );

	// Clean hash tables
	for( duplid_t i=0; i<MAXDUPLICATES; i++ ) {
		openidx->dupl_hash[i] = (off64_t)0;
	}

	// Set default values
	openidx->dupl_count = 0;
	openidx->dupl_next_char = 1; // start in 1

	// dupl_list
	openidx->dupl_list = (off64_t *) malloc ((MAXDUPLICATES + 1) * sizeof(off64_t));

	// Create memory area for word names
	THEMIDX_DUPL_SIZE = THEMIDX_EXPECTED_DUPL_SIZE * MAXDUPLICATES;
	openidx->dupl = (char *)malloc((sizeof(char))*THEMIDX_DUPL_SIZE);
	assert( openidx->dupl != NULL );
	openidx->dupl[0] = '\0';

	// assegna memoria ai puntatori nella struttura che riassume il risultato che restituisce la classe delle tematiche
	thematic_ranking_out.thematic = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));
	thematic_ranking_out.thematic[0] = '\0';

	thematic_ranking_out.ranked_rules = 0;

	thematic_ranking_out.ranked_thematics = 0;

	thematic_ranking_out.ranking = 0;
	// fine assegnazione memoria

	// indica i limiti di numerazione degli id di duplicati
	// (gli id relativi a termini inseriti anche negli headings saranno inferiori a thematic_ranking_out.duplicates_split_offset[0])
	thematic_ranking_out.duplicates_split_offset[0] = (duplid_t)0;
	thematic_ranking_out.duplicates_split_offset[1] = (duplid_t)0;

	// inserisco i valori iniziali nel buffer del ranking
	for (unsigned int i = 0; i < RBSIZE; i++)
	{
		ranking_buffer[i].rule = USHRT_MAX;
		ranking_buffer[i].ranking = 0;
		ranking_buffer[i].them_ranking = 0;
	}

	for (themid_t themid = 0; themid <= openidx->them_count; themid++)
		thematic_ranking[themid] = 0;

	// Inizio lettura stdin
	bool content_readed = false;
	char *elaborate = (char *) malloc ((MAX_WORD_LEN + 1) * sizeof(char));
	elaborate[0] = '\0';
	size_t elaborate_offset = 0;
	size_t offset = 0;

	bool stop_ranking = false;
	const bool in_domain = false;
	const bool is_clevel = false;

	duplid_t valid_words = ((double)((double)(content_len / PRATICAL_WORD_SIZE) / 100) * TEXTCHUNK); // parole dentro la parte di contenuto da analizzare

	unsigned int words_counter = 0;

	char *buffer = poutt->headings;

	run_again:

	if (buffer != NULL && buffer[0] != '\0') // se esistono headings, questi si inseriscono prima nei duplicati
	{
		while(buffer[offset] != '\0')
		{
			if (buffer[offset] != ASCII_SP)
			{
				if (elaborate_offset >= MAX_WORD_LEN) // skip whole string to next space
				{
					elaborate_offset = 0;
					elaborate[elaborate_offset] = '\0';

					while (! (buffer[offset] == '\0' || buffer[offset] == ASCII_SP))
						offset++;

					continue;
				}
				else
				{
					elaborate[elaborate_offset++] = buffer[offset];
					elaborate[elaborate_offset] = '\0';
				}

			}
			else
			{
				if (elaborate_offset > 1)
				{
					if (elaborate_offset <= MAX_WORD_LEN)
					{
						if (content_readed == false)
							checkThematicWord(elaborate, min_word_len, stop_ranking, in_domain, is_clevel);
						else
						{
						if (words_counter > valid_words)
							stop_ranking = true;

						if (words_counter < (UINT_MAX - USHRT_MAX)) // USHRT_MAX perchè al massimo la funzione 'checkThematicWord' restituisce al max USHRT_MAX
							words_counter += checkThematicWord(elaborate, min_word_len, stop_ranking, in_domain, is_clevel);
						else
							checkThematicWord(elaborate, min_word_len, stop_ranking, in_domain, is_clevel);
						}

						elaborate_offset = 0;
						elaborate[elaborate_offset] = '\0';
					}
				}
				else
				{
						elaborate_offset = 0;
						elaborate[elaborate_offset] = '\0';
				}
			}

			offset++;
		}

		if (content_readed == true)
			if (words_counter > valid_words)
				stop_ranking = true;

		if (elaborate_offset > min_word_len && elaborate_offset <= MAX_WORD_LEN)
			checkThematicWord(elaborate, min_word_len, stop_ranking, in_domain, is_clevel);

		if (content_readed == false)
			thematic_ranking_out.duplicates_split_offset[0] = openidx->dupl_count; // a tutti i duplicati con id inferiori a questo (headings) verrà assegnato un punteggio maggiore
	}

	if (poutt->content != NULL && poutt->content[0] != '\0' && content_readed == false) 
	{
		elaborate[0] = '\0';
		elaborate_offset = 0;
		offset = 0;
		buffer = poutt->content;
		content_readed = true;
		goto run_again;
	}

	thematic_ranking_out.duplicates_split_offset[1] = openidx->dupl_count;

	free (elaborate);
}

thematic_out_t Languages::index_read (const size_t min_word_len, pes_t *poutt, size_t content_len) const
{
	// creazione indici con durata limitata all'esecuzione della funzione
	//
	openidx->meta_hash = (off64_t *)malloc(sizeof(off64_t)*MAXMETA);
	assert( openidx->meta_hash != NULL );

	// Clean hash tables
	for( metaid_t i=0; i<MAXMETA; i++ ) {
		openidx->meta_hash[i] = (off64_t)0;
	}

	openidx->meta_count = 0;
	openidx->meta_next_char = 1; // start in 1

	// meta_list
	openidx->meta_list = (off64_t *) malloc ((MAXMETA + 1) * sizeof(off64_t));

	// Create memory area for word names
	THEMIDX_META_SIZE = THEMIDX_EXPECTED_META_SIZE * MAXMETA;
	openidx->meta = (char *)malloc((sizeof(char))*THEMIDX_META_SIZE);
	assert( openidx->meta != NULL );
	openidx->meta[0] = '\0';

	duplid_t realmaxduplicates = ((MAXDUPLICATES / 100) * 80); // il numero massimo dei termini negli indici ebbene non superi mai l'80% del teorico (vedi THEMIDX_MAX_OCCUPANCY)

	/////////////////////////////////////////////// inizio ricerca parole sensibili ////////////////////////////////////////////////////////////////////////////
	// primo passo è inserire nell'indice delle meta word i termini già presenti nei nomi dominio affinchè siano preservati da inutili ricerche di parole sensibili
	// fine ricerca parole sensibili

	if (thematic_ranking_out.ranked_rules == 0)
	{
		thematic_ranking_out.ranking = 0;

        	// Close and nullify all the filehandlers
		free( openidx->dupl_list ); openidx->dupl_list = NULL;
		free( openidx->meta_list ); openidx->meta_list = NULL;
		free( openidx->dupl_hash ); openidx->dupl_hash = NULL;
		free( openidx->meta_hash ); openidx->meta_hash = NULL;
		free( openidx->dupl ); openidx->dupl = NULL;
		free( openidx->meta ); openidx->meta = NULL;

		return thematic_ranking_out;
	}

	// debug of ranking
	unsigned long int average_rank = 0;
	unsigned long int second_rank = 0;
	unsigned short null_thematic_count = 0;

	struct null_struct {
		unsigned long int rank;
		unsigned short rule;
		unsigned short terms;
	} top_null_thematic, second_null_thematic;

	top_null_thematic.rank = 0;
	top_null_thematic.rule = 0;
	top_null_thematic.terms = 0;
	second_null_thematic.rank = 0;
	second_null_thematic.rule = 0;
	second_null_thematic.terms = 0;

	themid_t top_thematic = 0;

	unsigned short text_quality = (realmaxduplicates / logarithm(openidx->dupl_count,(double)2)); // Più e lungo un testo "più è probabile sia vago" 

	// assegna il punteggio alle tematiche
	for (unsigned char c = 0; c < RBSIZE; c++)
		if (ranking_buffer[c].rule < USHRT_MAX)
		{
			unsigned long int rank = (ranking_buffer[c].ranking / logarithm(main_structs[(ranking_buffer[c].rule)].terms,(double)2)) * text_quality;

			if (main_structs[(ranking_buffer[c].rule)].thematic > 1)
			{
				if (thematic_ranking[main_structs[(ranking_buffer[c].rule)].thematic] == 0 && ((rank + ranking_buffer[c].them_ranking) < UINT_MAX))
					rank = rank + ranking_buffer[c].them_ranking;
			}
			else
			{
				if ((rank + ranking_buffer[c].ranking) < UINT_MAX)
					rank = rank + ranking_buffer[c].ranking;
			}


			if (rank < UINT_MAX && rank > 0)
			{
				if (thematic_ranking[main_structs[(ranking_buffer[c].rule)].thematic] == 0 || main_structs[(ranking_buffer[c].rule)].thematic == 1)
					thematic_ranking_out.ranked_thematics++;

				if (main_structs[(ranking_buffer[c].rule)].thematic > 1)
					thematic_ranking[main_structs[(ranking_buffer[c].rule)].thematic] += rank;
				else
				{
					if (rank > top_null_thematic.rank)
					{
						
						second_null_thematic.rank = top_null_thematic.rank;
						second_null_thematic.rule = top_null_thematic.rule;
						second_null_thematic.terms = top_null_thematic.terms;
						top_null_thematic.rank = rank;
						top_null_thematic.rule = ranking_buffer[c].rule;
						top_null_thematic.terms = main_structs[ranking_buffer[c].rule].terms;
					}
					else if (rank > second_null_thematic.rank)
					{
						second_null_thematic.rank = rank;
						second_null_thematic.rule = ranking_buffer[c].rule;
						second_null_thematic.terms = main_structs[ranking_buffer[c].rule].terms;
					}
					// Calcola la media in 'tempo reale' per ogni punteggio aggiunto.
					double coefficent = ((double)null_thematic_count / ((double)null_thematic_count + 1));

					null_thematic_count++;

					average_rank = average_rank * coefficent + rank / null_thematic_count;
				}
			}

		}
		else
			break;

	// Se esistono tematiche nulle che influiscono sulla media occorre ricalcolare la stessa in base al numero totale di tematiche coinvolte nel ranking
	if (null_thematic_count > 0)
	{
		double coefficent = ((double)null_thematic_count / ((double)thematic_ranking_out.ranked_thematics));

		average_rank = average_rank * coefficent;
	}

	// trova la tematica (ad esclusione della nulla) con maggiore punteggio
	if (thematic_ranking_out.ranked_thematics > 0)
	{
		for (themid_t themid = 2; themid <= openidx->them_count; themid++)
		{
			average_rank += (thematic_ranking[themid] / thematic_ranking_out.ranked_thematics);

			if (thematic_ranking[themid] > thematic_ranking_out.ranking )
			{
				second_rank = thematic_ranking_out.ranking;
				thematic_ranking_out.ranking = thematic_ranking[themid];
				top_thematic = themid;
			}
			else if (thematic_ranking[themid] > second_rank)
				second_rank = thematic_ranking[themid];
		}
	}
	else
	{
		thematic_ranking_out.ranking = 0;

        	// Close and nullify all the filehandlers
		free( openidx->dupl_list ); openidx->dupl_list = NULL;
		free( openidx->meta_list ); openidx->meta_list = NULL;
		free( openidx->dupl_hash ); openidx->dupl_hash = NULL;
		free( openidx->meta_hash ); openidx->meta_hash = NULL;
		free( openidx->dupl ); openidx->dupl = NULL;
		free( openidx->meta ); openidx->meta = NULL;

		return thematic_ranking_out;
	}

	unsigned int top_thematic_terms = 0;

	// confronta le tematiche con eventuali tematiche nulle
	if (top_null_thematic.rank > thematic_ranking_out.ranking)
	{
		top_thematic_terms = main_structs[top_null_thematic.rule].terms;
		thematic_ranking_out.ranking = top_null_thematic.rank;
		top_thematic = 1;
	}
	else
	{
		// se è stata trovata una sola tematica occorre trovare il numero di termini totali utilizzati nella stessa tematica
		if (thematic_ranking_out.ranked_thematics == 1 && top_null_thematic.rank == 0)
			for (unsigned char c = 0; c < RBSIZE; c++)
				if (ranking_buffer[c].rule < USHRT_MAX)
				{
					if (main_structs[ranking_buffer[c].rule].thematic == top_thematic)
						top_thematic_terms += main_structs[ranking_buffer[c].rule].terms;
				}
				else
					break;
	}

	// Se sono state trovate tematiche nulle ma nessuna di queste è al top in classifica
	// cerca se eventualmente potrebbe avere il secondo punteggio
	if (top_thematic > 1 && null_thematic_count > 1)
	{
		if (top_null_thematic.rank > second_rank)
			second_rank = top_null_thematic.rank;
		else if (second_null_thematic.rank > second_rank)
			second_rank = second_null_thematic.rank;
	}
///////////////////////////////// da continuare //////////////////////////////////////

	// se è stata trovata più di una tematica la media non deve essere influenzata dal punteggio assegnato a top_thematic
	unsigned int *ranking = &thematic_ranking_out.ranking;
	themid_t *rt = &thematic_ranking_out.ranked_thematics;

	if (thematic_ranking_out.ranked_thematics > 1)
		average_rank = (average_rank - (*ranking / *rt)) / (*rt - 1) * (*rt);

	if (top_thematic > 0 && top_thematic <= openidx->them_count && ((*rt > 1 && (*ranking > (second_rank * SR_CONST)) && (*ranking >= (average_rank * FM))) || ((*rt == 1 && (*ranking >= ((USHRT_MAX / logarithm(top_thematic_terms,(double)2)) * text_quality * FM))))))
	{
		unsigned char amount_rules = 0;

		if (top_thematic > 1)
		{
			if (top_thematic < openidx->them_count)
				amount_rules = (th_dist_st[top_thematic + 1].th_dist_offset - th_dist_st[top_thematic].th_dist_offset);
			else
				amount_rules = (thematics_counter - th_dist_st[top_thematic].th_dist_offset);
		}
		else
			amount_rules = 1;

		//cout << "top thematic " << top_thematic << " ranking " << *ranking << " thematics " << *rt << " second " << second_rank << " average " << average_rank << " amount rules " << (int)amount_rules << endl;

		if (amount_rules > 0)
		{
			if (top_thematic > 1) // se diversa da null ricava il nome della tematica
				themidx_them_by_themid(top_thematic, thematic_ranking_out.thematic);

			size_t storic_size = 0;

			if (top_thematic > 1)
			{
				for (unsigned char a = 0; a < amount_rules; a++)
				{
					unsigned short rule = th_dist[(th_dist_st[top_thematic].th_dist_offset + a)];

					storic_size += ((rule < (mcrule - 1)) ? main_structs[(rule + 1)].rule_offset : terms_counter) - main_structs[rule].rule_offset;
				}
			}
			else
				storic_size = top_null_thematic.terms;
		}

		// DA UN'INDICAZIONE REALE SU QUANTO VALE IL RANKING (questo dato è utile al motore di ricerca)
		// Al ranking finale viene sottratta la media (per capire quanto prevale su di essa) e
		// la differenza tra il ranking e il second_ranking divisa per la radice quadrata del numero delle tematiche totali trovate
		//
		if (thematic_ranking_out.ranked_thematics > 1)
		{
			unsigned int val = *ranking - ((average_rank + (*ranking - second_rank)) / sqrt(*rt));

			if (val > THEMTHRESHOLD)
				val = THEMTHRESHOLD;

			// pseudo normalizzazione del ranking della tematica riferita appunto a THEMTHRESHOLD
			thematic_ranking_out.ranking = ((float)val / (float)THEMTHRESHOLD) * THEMRANK_MAX;
		}
		else
			thematic_ranking_out.ranking = ((float)*ranking / (float)THEMTHRESHOLD) * THEMRANK_MAX;
			// pseudo normalizzazione del ranking della tematica riferita appunto a THEMTHRESHOLD
	}
	else
		thematic_ranking_out.ranking = 0;

	// Close and nullify all the filehandlers
	free( openidx->dupl_list ); openidx->dupl_list = NULL;
	free( openidx->meta_list ); openidx->meta_list = NULL;
	free( openidx->dupl_hash ); openidx->dupl_hash = NULL;
	free( openidx->meta_hash ); openidx->meta_hash = NULL;
	free( openidx->dupl ); openidx->dupl = NULL;
	free( openidx->meta ); openidx->meta = NULL;

	return thematic_ranking_out;
}

void Languages::free_dupl_index (void) const
{
	free (thematic_ranking_out.thematic);
	// Close and nullify all the filehandlers
	free( openidx->dupl_list ); openidx->dupl_list = NULL;
	free( openidx->dupl_hash ); openidx->dupl_hash = NULL;
	free( openidx->dupl ); openidx->dupl = NULL;
}

void Languages::index_open (void)
{
	cerr << "Open word indexes for elaboration " << endl;
	themidx_new(); // themidx_open() non necessaria se non si lavora su disco
	assert( openidx != NULL );
}

void Languages::index_close (bool close_all)
{
	cerr << "Close word indexes." << endl;
	themidx_close();

	if (close_all == true)
	{
		sb_stemmer_delete(stemmer);
		free (wordform_struct);
		free (main_buffer);
		free (main_structs);
		free (th_dist_st);
		free (th_dist);
		free (st_dist_st);
		free (st_dist);

		if (ranking_buffer != NULL)
			free (ranking_buffer);

		if (thematic_ranking != NULL)
			free (thematic_ranking);
	}
}

//
// Name: themidx_new
//
// Description:
//   Creates a new index in the given directory
//
// Input:
//   dirname - directory to create url index
//
// Return:
//   urlindex structure
//
void Languages::themidx_new( void ) {

	openidx = (themidx_t *)malloc(sizeof(themidx_t));

	assert( openidx!=NULL);

	assert( CONF_OK );

	openidx->them_hash = (off64_t *)malloc(sizeof(off64_t)*MAXTHEMATICS);
	assert( openidx->them_hash != NULL );

	openidx->stem_hash = (off64_t *)malloc(sizeof(off64_t)*MAXSTEMMING);
	assert( openidx->stem_hash != NULL );

	openidx->word_hash = (off64_t *)malloc(sizeof(off64_t)*MAXWORDS);
	assert( openidx->word_hash != NULL );

	// Clean hash tables
	for( themid_t i=0; i<MAXTHEMATICS; i++ ) {
		openidx->them_hash[i] = (off64_t)0;
	}

	// Clean hash tables
	for( stemid_t i=0; i<MAXSTEMMING; i++ ) {
		openidx->stem_hash[i] = (off64_t)0;
	}

	// Clean hash tables
	for( wordid_t i=0; i<MAXWORDS; i++ ) {
		openidx->word_hash[i] = (off64_t)0;
	}

	// Set default values
	openidx->them_count = 0;
	openidx->them_next_char = 1; // start in 1
	openidx->stem_count = 0;
	openidx->stem_next_char = 1; // start in 1
	openidx->word_count = 0;
	openidx->word_next_char = 1; // start in 1

	// them_list
	openidx->them_list = (off64_t *) malloc ((MAXTHEMATICS + 1) * sizeof(off64_t));

	// stem_list
	openidx->stem_list = (off64_t *) malloc ((MAXSTEMMING + 1) * sizeof(off64_t));

	// word_list
	openidx->word_list = (off64_t *) malloc ((MAXWORDS + 1) * sizeof(off64_t));

	// Create memory area for thematics word names
	THEMIDX_THEM_SIZE = THEMIDX_EXPECTED_THEM_SIZE * MAXTHEMATICS;
	openidx->them = (char *)malloc((sizeof(char))*THEMIDX_THEM_SIZE);
	assert( openidx->them != NULL );
	openidx->them[0] = '\0';

	// Create memory area for word names
	THEMIDX_STEM_SIZE = THEMIDX_EXPECTED_STEM_SIZE * MAXSTEMMING;
	openidx->stem = (char *)malloc((sizeof(char))*THEMIDX_STEM_SIZE);
	assert( openidx->stem != NULL );
	openidx->stem[0] = '\0';

	// Create memory area for word names
	THEMIDX_WORD_SIZE = THEMIDX_EXPECTED_WORD_SIZE * MAXWORDS;
	openidx->word = (char *)malloc((sizeof(char))*THEMIDX_WORD_SIZE);
	assert( openidx->word != NULL );
	openidx->word[0] = '\0';
} 
                                            
//
// Name: themidx_resolve_them
//
// Description:
//   Verify a stemming of word name and add it whole word if necessary
//
// Input:
//   themidx - the url index structure
//   them - the thematic to check
//
// Output:
//   themid - themid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the thematic existed
//   THEMIDX_CREATED_THEM - the thematic word was added
//   THEMIDX_NOT_FOUND - the thematic word is not known and was not created
//
themidx_status_t Languages:: themidx_resolve_them( const char *original, const char *them, themid_t *themid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( them != NULL );

	if (them == NULL)
		return THEMIDX_NOT_FOUND;

	size_t olen = 0;

	if (readonly == false)
	{
		assert( original != NULL );
		olen = strlen(original);
		assert( olen > 0 );
	}

	themid_t bucket;

	// Check if the them exists
	// Check if the stemming of original word exists

	themid_t themid_check = themidx_check_them( them, &(bucket) );

	if( themid_check > 0 ) {
		if( themid != NULL ) {
			*themid	= themid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next themid
		*themid = ++(openidx->them_count);

		//cout << "Result 0 o 2, Sito:   " << them << "       Recupero il primo themid disponibile " << openidx->them_count << '-' << bucket << endl;
		if( openidx->them_count > MAXTHEMATICS ) {
			die( "Maximum number of thems exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->them_hash)[bucket] = (openidx->them_next_char);
//		cout << "Inserisco " << (openidx->them_next_char) << " in (openidx->them_hash)[" << bucket << "]" << " conferma " << (openidx->them_hash)[bucket] << endl;

		// Save in list of thems
		openidx->them_list[*themid - 1] = openidx->them_next_char;

		// Store string
		memcpy( openidx->them + openidx->them_next_char, original, olen + 1 );

		// Store themid
		memcpy( openidx->them + openidx->them_next_char + olen + 1, themid, sizeof(themid_t) );

		// Move char pointer
		openidx->them_next_char = openidx->them_next_char + olen + 1 + sizeof(themid_t);
		if( openidx->them_next_char > THEMIDX_THEM_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXTHEMATICS or EXPECTED_THEM_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_THEM;
}

//
// Name: themidx_resolve_stem
//
// Description:
//   Verify a stemming of word name and add it whole word if necessary
//   For pratical and performance reason, stemming was elaborate out of function.
//
// Input:
//   themidx - the url index structure
//   stem - the stem to check
//
// Output:
//   stemid - stemid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the site existed
//   THEMIDX_CREATED_STEM - the stemmed word was added
//   THEMIDX_NOT_FOUND - the second level stem is not known and was not created
//
themidx_status_t Languages::themidx_resolve_stem( const char *original, const char *stem, stemid_t *stemid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( stem != NULL );

	if (stem == NULL)
		return THEMIDX_NOT_FOUND;

	size_t olen = 0;

	if (readonly == false)
	{
		assert( original != NULL );
		olen = strlen(original);
		assert( olen > 0 );
	}

	stemid_t bucket;

	// Check if the stem exists
	// Check if the stemming of original word exists

	stemid_t stemid_check = themidx_check_stem( stem, &(bucket) );

	if( stemid_check > 0 ) {
		if( stemid != NULL ) {
			*stemid	= stemid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next stemid
		*stemid = ++(openidx->stem_count);

		//cout << "Result 0 o 2, Sito:   " << stem << "       Recupero il primo stemid disponibile " << openidx->stem_count << '-' << bucket << endl;
		if( openidx->stem_count > MAXSTEMMING ) {
			die( "Maximum number of stems exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->stem_hash)[bucket] = (openidx->stem_next_char);
//		cout << "Inserisco " << (openidx->stem_next_char) << " in (openidx->stem_hash)[" << bucket << "]" << " conferma " << (openidx->stem_hash)[bucket] << endl;

		// Save in list of stems
		openidx->stem_list[*stemid - 1] = openidx->stem_next_char;

		// Store string
		memcpy( openidx->stem + openidx->stem_next_char, original, olen + 1 );

		// Store stemid
		memcpy( openidx->stem + openidx->stem_next_char + olen + 1, stemid, sizeof(stemid_t) );

		// Move char pointer
		openidx->stem_next_char = openidx->stem_next_char + olen + 1 + sizeof(stemid_t);
		if( openidx->stem_next_char > THEMIDX_STEM_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXSTEMMING or EXPECTED_STEM_SIZE" << endl;
			return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_STEM;
}

//
// Name: themidx_resolve_word
//
// Description:
//   Verify a word name and add it if necessary
//
// Input:
//   themidx - the url index structure
//   word - the word to check
//
// Output:
//   wordid - wordid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the word existed
//   THEMIDX_CREATED_WORD - the word was added
//   THEMIDX_NOT_FOUND - the word is not known and was not created
//
themidx_status_t Languages::themidx_resolve_word( const char *word, wordid_t *wordid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( word != NULL );

	if (word == NULL)
		return THEMIDX_NOT_FOUND;

	size_t wlen = strlen(word);
	assert( wlen > 0 );

	wordid_t bucket;
	wordid_t wordid_check;

	// Check if the word exists
	wordid_check = themidx_check_word( word, &(bucket) );

	if( wordid_check > 0 ) {
		if( wordid != NULL ) {
			*wordid	= wordid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next wordid
		*wordid = ++(openidx->word_count);
		//cout << "Result 0 o 2, Sito:   " << word << "       Recupero il primo wordid disponibile " << openidx->word_count << '-' << bucket << endl;
		if( openidx->word_count > MAXWORDS ) {
			die( "Maximum number of words exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->word_hash)[bucket] = (openidx->word_next_char);
//		cout << "Inserisco " << (openidx->word_next_char) << " in (openidx->word_hash)[" << bucket << "]" << " conferma " << (openidx->word_hash)[bucket] << endl;

		// Save in list of words
		openidx->word_list[*wordid - 1] = openidx->word_next_char;

		// Store string
		memcpy( openidx->word + openidx->word_next_char, word, wlen + 1 );

		// Store wordid
		memcpy( openidx->word + openidx->word_next_char + wlen + 1, wordid, sizeof(wordid_t) );

		// Move char pointer
		openidx->word_next_char = openidx->word_next_char + wlen + 1 + sizeof(wordid_t);
		if( openidx->word_next_char > THEMIDX_WORD_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXWORDS or EXPECTED_WORD_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_WORD;
}

//
// Name: themidx_resolve_dupl
//
// Description:
//   Verify a dupl name and add it if necessary
//
// Input:
//   themidx - the url index structure
//   dupl - the dupl to check
//
// Output:
//   duplid - duplid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the duplatic existed
//   THEMIDX_CREATED_DUPL - the duplatic dupl was added
//   THEMIDX_NOT_FOUND - the duplatic dupl is not known and was not created
//
themidx_status_t Languages::themidx_resolve_dupl( const char *original, const char *dupl, duplid_t *duplid, bool readonly ) const {
	assert( openidx != NULL );

	if (dupl == NULL)
		return THEMIDX_NOT_FOUND;

	size_t olen = 0;

	if (readonly == false)
	{
		assert( original != NULL );
		olen = strlen(original);
		assert( olen > 0 );
	}

	duplid_t bucket;

	// Check if the stemming of original word exists
	duplid_t duplid_check = themidx_check_dupl( dupl, &(bucket) );
	
	if( duplid_check > 0 ) {
		if( duplid != NULL ) {
			*duplid	= duplid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next duplid
		*duplid = ++(openidx->dupl_count);
		//cout << "Result 0 o 2, Sito:   " << dupl << "       Recupero il primo duplid disponibile " << openidx->dupl_count << '-' << bucket << endl;
		if( openidx->dupl_count > MAXDUPLICATES ) {
			die( "Maximum number of duplicates exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->dupl_hash)[bucket] = (openidx->dupl_next_char);
//		cout << "Inserisco " << (openidx->dupl_next_char) << " in (openidx->dupl_hash)[" << bucket << "]" << " conferma " << (openidx->dupl_hash)[bucket] << endl;

		// Save in list of dupls
		openidx->dupl_list[*duplid - 1] = openidx->dupl_next_char;

		// Store string
		memcpy( openidx->dupl + openidx->dupl_next_char, original, olen + 1 );

		// Store duplid
		memcpy( openidx->dupl + openidx->dupl_next_char + olen + 1, duplid, sizeof(duplid_t) );

		// Move char pointer
		openidx->dupl_next_char = openidx->dupl_next_char + olen + 1 + sizeof(duplid_t);
		if( openidx->dupl_next_char > THEMIDX_DUPL_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXDUPLICATES or EXPECTED_DUPL_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_DUPL;
}

//
// Name: themidx_resolve_meta
//
// Description:
//   Verify a meta name and add it if necessary
//
// Input:
//   themidx - the url index structure
//   meta - the meta to check
//
// Output:
//   metaid - metaid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   THEMIDX_EXISTENT - the meta word existed
//   THEMIDX_CREATED_DUPL - the meta word was added
//   THEMIDX_NOT_FOUND - the meta word is not known and was not created
//
themidx_status_t Languages::themidx_resolve_meta( const char *meta, metaid_t *metaid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( meta != NULL );

	if (meta == NULL)
		return THEMIDX_NOT_FOUND;

	size_t mlen = strlen(meta);
	assert( mlen > 0 );

	metaid_t bucket;
	metaid_t metaid_check;

	// Check if the meta exists
	metaid_check = themidx_check_meta( meta, &(bucket) );

	if( metaid_check > 0 ) {
		if( metaid != NULL ) {
			*metaid	= metaid_check;
		}
		return THEMIDX_EXISTENT;
	}

	if( readonly == true )
		return THEMIDX_NOT_FOUND;
	else {
		// Get the next metaid

		// Save in list of metas
		*metaid = ++(openidx->meta_count);
		//cout << "Result 0 o 2, Sito:   " << meta << "       Recupero il primo metaid disponibile " << openidx->meta_count << '-' << bucket << endl;
		if( openidx->meta_count > MAXMETA ) {
			die( "Maximum number of metaicates exceeded, increase in configuration file"  );
		}


		// Save in list of metas
		// Put in bucket
		(openidx->meta_hash)[bucket] = (openidx->meta_next_char);
//		cout << "Inserisco " << (openidx->meta_next_char) << " in (openidx->meta_hash)[" << bucket << "]" << " conferma " << (openidx->meta_hash)[bucket] << endl;

		// Save in list of meta words
		openidx->meta_list[*metaid - 1] = openidx->meta_next_char;

		// Store string
		memcpy( openidx->meta + openidx->meta_next_char, meta, mlen + 1 );

		// Store metaid
		memcpy( openidx->meta + openidx->meta_next_char + mlen + 1, metaid, sizeof(metaid_t) );

		// Move char pointer
		openidx->meta_next_char = openidx->meta_next_char + mlen + 1 + sizeof(metaid_t);
		if( openidx->meta_next_char > THEMIDX_META_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXMETA or EXPECTED_META_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(THEMIDX_ERROR);
		}
	}

	// Return
	return THEMIDX_CREATED_META;
}

//
// Name: themidx_check_them
//
// Description:
//   Check if a word exists
//
// Input:
//   themidx - the thematic index structure
//   them - the thematic name to check
//   bucket - the bucket in which this was found
//
// Return
//   a wordid if resolved
//   0 if not found
//
themid_t Languages::themidx_check_them( const char *them, themid_t *bucket ) const {
	assert( openidx != NULL );
	assert( them != NULL );
	assert( strlen( them ) > 0 );

	// First attempt to find bucket (debug purpose)
	//themid_t test = Url.hashing_them( them );
	//cout << "DOMAIN " << them << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_them( them );

	// Linear probing
	while( openidx->them_hash[(*bucket)] > 0 ) {

		off64_t position = (openidx->them_hash)[(*bucket)];
		// See if it's the same
		size_t len = strlen((openidx->them) + position);

		char *stemming = doStemming((openidx->them) + position, len, (len + 1));

		char *startpointer = stemming; // indirizzo iniziale che serve per liberare le risorse successivamente

		const char *input = them;

		if( stemming != NULL ) {
			// confronta passo-passo il termine originale con quello fornito come argomento
			while (*(stemming) != '\0' && *(input) != '\0' && *(stemming) == *(input) && *(stemming++) && *(input++));

			if (*stemming == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
			{
				free (startpointer);

				return *((themid_t *)((openidx->them) + position + len + 1)); // restituisce l'id
			}

			free (startpointer);
		}
		(*bucket) = ((*bucket) + 1) % MAXTHEMATICS;
	}

	return (themid_t)0;
}

//
// Name: urlddx_check_stem
//
// Description:
//   Check if a stem exists
//
// Input:
//   themidx - the stem index structure
//   stem - the stem name to check
//   bucket - the bucket in which this was found
//
// Return
//   a stemid if resolved
//   0 if not found
//
stemid_t Languages::themidx_check_stem( const char *stem, stemid_t *bucket ) const {
	assert( openidx != NULL );
	assert( stem != NULL );
	assert( strlen( stem ) > 0 );

	// First attempt to find bucket (debug purpose)
	//stemid_t test = Url.hashing_them( stem );
	//cout << "DOMAIN " << stem << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_stem( stem );

	// Linear probing
	while( openidx->stem_hash[(*bucket)] > 0 ) {

		off64_t position = (openidx->stem_hash)[(*bucket)];
		// See if it's the same
		size_t len = strlen((openidx->stem) + position);

		char *stemming = doStemming((openidx->stem) + position, len, (len + 1));

		char *startpointer = stemming; // indirizzo iniziale che serve per liberare le risorse successivamente

		const char *input = stem;

		if( stemming != NULL ) {
			// confronta passo-passo il termine originale con quello fornito come argomento
			while (*(stemming) != '\0' && *(input) != '\0' && *(stemming) == *(input) && *(stemming++) && *(input++));

			if (*stemming == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
			{
				free (startpointer);

				return *((stemid_t *)((openidx->stem) + position + len + 1)); // restituisce l'id
			}

			free (startpointer);
		}
		(*bucket) = ((*bucket) + 1) % MAXSTEMMING;
	}

	return (stemid_t)0;
}

//
// Name: urlddx_check_word
//
// Description:
//   Check if a word exists
//
// Input:
//   themidx - the word index structure
//   word - the word name to check
//   bucket - the bucket in which this was found
//
// Return
//   a wordid if resolved
//   0 if not found
//
wordid_t Languages::themidx_check_word( const char *word, wordid_t *bucket ) const {
	assert( openidx != NULL );
	assert( word != NULL );
	assert( strlen( word ) > 0 );


	// First attempt to find bucket (debug purpose)
	//wordid_t test = Url.hashing_them( word );
	//cout << "DOMAIN " << word << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_word( word );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( openidx->word_hash[(*bucket)] > 0 ) {

		char *pidx = openidx->word + openidx->word_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = word;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != '\0' && *(input) != '\0' && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
			return *((wordid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % MAXWORDS;
	}

	return (wordid_t)0;
}

//
// Name: urlddx_check_dupl
//
// Description:
//   Check if a word exist
//
// Input:
//   themidx - the word index structure
//   dupl - the duplicate name to check
//   bucket - the bucket in which this was found
//
// Return
//   a duplid if resolved
//   0 if not found
//
duplid_t Languages::themidx_check_dupl( const char *dupl, duplid_t *bucket ) const {
	assert( openidx != NULL );
	assert( dupl != NULL );
	assert( strlen( dupl ) > 0 );


	// First attempt to find bucket (debug purpose)
	//duplid_t test = Url.hashing_them( dupl );
	//cout << "DOMAIN " << dupl << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_dupl( dupl );

	// Linear probing
	while( openidx->dupl_hash[(*bucket)] > 0 ) {

		off64_t position = (openidx->dupl_hash)[(*bucket)];
		// See if it's the same
		size_t len = strlen((openidx->dupl) + position); // misura da 'position' al primo carattere null

		char *stemming = doStemming((openidx->dupl) + position, len, (len + 1));

		char *startpointer = stemming; // indirizzo iniziale che serve per liberare le risorse successivamente

		const char *input = dupl;

		if( stemming != NULL ) {
			// confronta passo-passo il termine originale con quello fornito come argomento
			while (*(stemming) != '\0' && *(input) != '\0' && *(stemming) == *(input) && *(stemming++) && *(input++));

			if (*stemming == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
			{
				free (startpointer);

				return *((duplid_t *)((openidx->dupl) + position + len + 1)); // restituisce l'id
			}

			free (startpointer);
		}
		(*bucket) = ((*bucket) + 1) % MAXDUPLICATES;
	}

	return (duplid_t)0;
}

//
// Name: urlddx_check_meta
//
// Description:
//   Check if a word exist
//
// Input:
//   themidx - the word index structure
//   meta - the meta name to check
//   bucket - the bucket in which this was found
//
// Return
//   a metaid if resolved
//   0 if not found
//
metaid_t Languages::themidx_check_meta( const char *meta, metaid_t *bucket ) const {
	assert( openidx != NULL );
	assert( meta != NULL );
	assert( strlen( meta ) > 0 );


	// First attempt to find bucket (debug purpose)
	//metaid_t test = Url.hashing_them( meta );
	//cout << "DOMAIN " << meta << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = themidx_hashing_meta( meta );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( openidx->meta_hash[(*bucket)] > 0 ) {

		char *pidx = openidx->meta + openidx->meta_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = meta;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != '\0' && *(input) != '\0' && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == '\0' && *input == '\0') // fine del termine dentro il puntatore a caratteri
			return *((metaid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % MAXDUPLICATES;
	}

	return (metaid_t)0;
}

// Hashing Functions for thematic words
themid_t Languages::themidx_hashing_them( const char *text ) const {
	themid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXTHEMATICS );
	}
	return val;
}

// Hashing Functions for stemming words
stemid_t Languages::themidx_hashing_stem( const char *text ) const {
	stemid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXSTEMMING );
	}
	return val;
}

// Hashing Functions for whole words
wordid_t Languages::themidx_hashing_word( const char *text ) const {
	wordid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXWORDS );
	}
	return val;
}

// Hashing Functions for duplicated words
duplid_t Languages::themidx_hashing_dupl( const char *text ) const {
	duplid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXDUPLICATES );
	}
	return val;
}

// Hashing Functions for meta words
metaid_t Languages::themidx_hashing_meta( const char *text ) const {
	metaid_t val;
	for( val=0; *text; text++ ) {
		val = ( (131 * (val == 0 ? 1 : val) + *text) % MAXMETA );
	}
	return val;
}

// Name: themidx_them_by_themid
//
// Description:
//   Get the name of a word based on its id
//
//	TODO: This function must fail in an error condition.
//
void Languages::themidx_them_by_themid(themid_t themid, char *themname ) const {

	if ( themid > 0 && themid <= openidx->them_count)
	{
		// Read offset
		off64_t offset;
		offset = openidx->them_list[(themid - 1)];

		// Copy
		assert( strlen( (openidx->them) + offset ) < MAX_WORD_LEN );
		strcpy( themname, (openidx->them) + offset );
	}
	else
		themname[0] = '\0';
}

// Name: themidx_stem_by_stemid
//
// Description:
//   Get the name of a stem based on its id
//
//	TODO: This function must fail in an error condition.
//
void Languages::themidx_stem_by_stemid( stemid_t stemid, char *stemname ) const {

	if ( stemid > 0 && stemid <= openidx->stem_count)
	{
		// Read offset
		off64_t offset;
		offset = openidx->stem_list[(stemid - 1)];

		// Copy
		assert( strlen( (openidx->stem) + offset ) < MAX_WORD_LEN );
		strcpy( stemname, (openidx->stem) + offset );
	}
	else
		stemname[0] = '\0';
}

// Name: themidx_word_by_wordid
//
// Description:
//   Get the name of a word based on its id
//
//	TODO: This function must fail in an error condition.
//
void Languages::themidx_word_by_wordid( wordid_t wordid, char *wordname ) const {

	if ( wordid > 0 && wordid <= openidx->word_count)
	{
		// Read offset
		off64_t offset;
		offset = openidx->word_list[(wordid - 1)];

		// Copy
		assert( strlen( (openidx->word) + offset ) < MAX_WORD_LEN );
		strcpy( wordname, (openidx->word) + offset );
	}
	else
		wordname[0] = '\0';
}

// Name: themidx_dupl_by_duplid
//
// Description:
//   Get the name of a duplicated word in a page based on its id
//
//	TODO: This function must fail in an error condition.
//
void Languages::themidx_dupl_by_duplid( duplid_t duplid, char *duplname ) const {

	if ( duplid > 0 && duplid <= openidx->dupl_count)
	{
		// Read offset
		off64_t offset;
		offset = openidx->dupl_list[(duplid - 1)];

		// Copy
		assert( strlen( (openidx->dupl) + offset ) < MAX_WORD_LEN );
		strcpy( duplname, (openidx->dupl) + offset );
	}
	else
		duplname[0] = '\0';
}

// Name: themidx_meta_by_metaid
//
// Description:
//   Get the name of a meta word in a page based on its id
//
//	TODO: This function must fail in an error condition.
//
void Languages::themidx_meta_by_metaid( metaid_t metaid, char *metaname ) const {

	if ( metaid > 0 && metaid <= openidx->meta_count)
	{
		// Read offset
		off64_t offset;
		offset = openidx->meta_list[(metaid - 1)];

		// Copy
		assert( strlen( (openidx->meta) + offset ) < MAX_WORD_LEN );
		strcpy( metaname, (openidx->meta) + offset );
	}
	else
		metaname[0] = '\0';
}

//
// Name: themidx_close
//
// Description:
//   Closes the url index, saving data to disk
//
// Input:
//   themidx - the url index structure
//
void Languages::themidx_close(void) {
	// Check what i'm going to close
	assert( openidx != NULL );

	// Close and nullify all the static filehandlers
	free( openidx->them_list ); openidx->them_list = NULL;
	free( openidx->stem_list ); openidx->stem_list = NULL;
	free( openidx->word_list ); openidx->word_list = NULL;
	free( openidx->them_hash ); openidx->them_hash = NULL;
	free( openidx->stem_hash ); openidx->stem_hash = NULL;
	free( openidx->word_hash ); openidx->word_hash = NULL;
	free( openidx->them ); openidx->them = NULL;
	free( openidx->stem ); openidx->stem = NULL;
	free( openidx->word ); openidx->word = NULL;
	free( openidx ); openidx = NULL;
}
