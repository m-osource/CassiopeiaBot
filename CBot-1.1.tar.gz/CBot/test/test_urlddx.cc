/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "config.h"
#include "const.h"
#include "xmlconf.h"
#include "xmlconf-main.h"
#include "utils.h"
#include "perfect_hash.h"
#include "Url.h"

// Globals

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

Url *url	= NULL;

void do_urlddx_path_to_absolute_test (int testnum, char *src, char *dst, char *expected){
	char newurl[MAX_STR_LEN];
	newurl[0]='/';
	newurl[1]='\0';
	url->relative_path_to_absolute(src, dst, newurl);
	cerr <<"test "<<testnum<<":	";
	if (strcmp(newurl,expected)!=0){
		cerr <<" [ERROR]"<<endl;
		cerr <<"\t       source:	"<<src<<endl;
		cerr <<"\t          dst:	"<<dst<<endl;
		cerr <<"\tabsolute path:	"<<newurl<<endl;
		cerr <<"\t     expected:	"<<expected<<endl;
	}
	else{
		cerr <<"[OK]"<<endl;
	}
	cerr<<endl;
}

#define MAX_SESSIONID_VARIABLES 255

int main( int argc, char **argv )
{
try
{
	cbot_start( "testurl" );

	url	= new Url (NULL, Url::RO);
	// We don't need open urlddx index, but we have the need to use only functions inside Url class.


	// perfhash_t extensions_dynamic;
	// extensions_dynamic.check_matches = true;

	// Create a table with variable names for better speed
	// int nvars	= 0;

	int cnt         = 0;
	do_urlddx_path_to_absolute_test( cnt++,(char *)"a.html", (char *)"b.html", (char *)"b.html");

	do_urlddx_path_to_absolute_test(cnt++, (char *)"src/path/a.html", (char *)"dst/path/b.html", (char *)"src/path/dst/path/b.html");

	do_urlddx_path_to_absolute_test(cnt++, (char *)"src/path/a.html?arg1=val1", (char *)"dst/path/b.html?arg2=val2", (char *)"src/path/dst/path/b.html?arg2=val2");
	do_urlddx_path_to_absolute_test(cnt++, (char *)"src/path/a.html?arg1=val1a/val1b", (char *)"dst/path/b.html?arg2=val2", (char *)"src/path/dst/path/b.html?arg2=val2");

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}

}

void cleanup() {

	if (url != NULL)
		delete url;
}

