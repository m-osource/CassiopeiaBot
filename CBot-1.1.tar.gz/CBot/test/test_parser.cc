/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include "test_parser.h"
#include "xmlconf-main.h"

int main (int argc, char **argv)
{
try
{
	cbot_start("testparser");
	parser_init();

	mime_type_t	mime_type		= MIME_TEXT_HTML;
	char robots_txt_url[MAX_STR_LEN]	= "";
	char filename[MAX_STR_LEN]	= "";
	bool verbose = false;
	bool html_first_stage = false;

	robots_txt_url[0] = ASCII_NUL;

	while(1) {

		if (argc == 1)
		{
			test_parser_usage();
			break;
		}

		int option_index = 0;
		
		static struct option long_options[] = {
			{"help", 0, 0, 0},
			{"verbose", 0, 0, 0},
			{"html", 1, 0, 0},
			{"html-first-stage", 1, 0, 0},
			{"pdf", 1, 0, 0},
			{"text", 1, 0, 0},
			{"robots-txt", 1, 0, 0},
			{"robots-txt-url", 1, 0, 0},
			{"sitemap-rdf", 1, 0, 0},
			{"sitemap-xml", 1, 0, 0},
			{"feed-atom", 1, 0, 0},
			{"feed-rss", 1, 0, 0},
			{0,0,0,0}
		};

		char c = getopt_long (argc, argv, "hv?", long_options, &option_index );

		if (c == -1)
			break;

		switch(c) {
			case 0:
				if(!strcmp(long_options[option_index].name, "html"))
				{
					strcpy(filename, optarg);
					mime_type	= MIME_TEXT_HTML;
				}
				else if (!strcmp(long_options[option_index].name, "html-first-stage"))
				{
					html_first_stage = true;
					strcpy(filename, optarg);
					mime_type	= MIME_TEXT_HTML;
				}
				else if (!strcmp(long_options[option_index].name, "pdf"))
				{
					strcpy(filename, optarg);
					mime_type	= MIME_APPLICATION_PDF;
				}
				else if (!strcmp(long_options[option_index].name, "text"))
				{
					strcpy(filename, optarg);
					mime_type	= MIME_TEXT_PLAIN;
				}
				else if (!strcmp(long_options[option_index].name, "robots-txt"))
				{
					strcpy(filename, optarg);
					mime_type	= MIME_ROBOTS_TXT;
				}
				else if (!strcmp(long_options[option_index].name, "robots-txt-url"))
				{
					if (optarg[0] != ASCII_SL)
					{
						test_parser_usage();
						break;
					}

					strcpy(robots_txt_url, optarg);
					mime_type	= MIME_ROBOTS_TXT;
				}
				else if (!strcmp(long_options[option_index].name, "sitemap-rdf"))
				{
					strcpy(filename, optarg);
					mime_type	= MIME_ROBOTS_RDF;
				}
				else if (!strcmp(long_options[option_index].name, "sitemap-xml"))
				{
					strcpy(filename, optarg);
					mime_type	= MIME_ROBOTS_XML;
				}
				else if (!strcmp(long_options[option_index].name, "feed-atom"))
				{
					strcpy(filename, optarg);
					mime_type	= MIME_FEEDS_ATOM_XML;
				}
				else if (!strcmp(long_options[option_index].name, "feed-rss"))
				{
					strcpy(filename, optarg);
					mime_type	= MIME_FEEDS_RSS_XML;
				}
				else if (!strcmp(long_options[option_index].name, "verbose"))
				{
					verbose		= true;
				}
				else if (!strcmp(long_options[option_index].name, "help"))
				{
					test_parser_usage();
				}
				break;
			case 'v':
				verbose       = true;
				break;
			case 'h':
				test_parser_usage();
				break;
			case '?':
				test_parser_usage();
				break;
		}
	}

	if( strlen(filename) == 0 || (verbose == true && argc == 2) ) {
		test_parser_usage();
	}

	FILE *links_download = NULL;
	FILE *links_log = NULL;
	FILE *links_stat = NULL;

	if (debugonly == false || mime_type == MIME_ROBOTS_TXT)
	{
		links_download = tmpfile();
		links_log = tmpfile();
		links_stat = tmpfile();
	}

	// Stat input file to check size
	struct stat64 statbuf;
	lstat64(filename, &statbuf);
	off64_t len = statbuf.st_size;

	if (errno > 0)
	{
		perror(filename);
		exit(1);
	}

	// Input file
	cerr << "Input filename            : " << filename << endl;
	assert( len > 0 );
	assert( len < MAX_DOC_LEN );

	// Prepare buffers
	cerr << "Requesting memory         : " << len << endl;

	// Prepare for parsing the file
	starter_t *starter = NULL;
	server_t *server = CBALLOC(server_t, MALLOC, 1);
	memset(server, 0, sizeof(server_t));
	server->hostname = CBALLOC(char, CALLOC, MAX_STR_LEN);
	strcpy(server->hostname, "null.null" );
	server->pages = CBALLOC(page_t, MALLOC, 1);;
	server->pages->src_path = NULL; // needed for 'instant' relocation
	server->pages->buffer_one = NULL;
	server->pages->bo_size = (len + 1);
	server->pages->buffer_two = NULL;
	server->pages->bt_size = 0;
	server->pages->buffer_links_download = NULL;
	server->pages->bld_size = 0;
	server->pages->buffer_links_log = NULL;
	server->pages->bll_size = 0;
	server->pages->relocation[0] = '\0';
	server->pages->attempts = 0;
	server->pages->is_fqdn_request = false;
	server->pages->redirect_with_invalid_path = false;
	strcpy(server->pages->path, "");
	server->pages->doc = CBALLOC(doc_t, MALLOC, 1);
	Meta *meta = new Meta (NULL, true);
	meta->doc_default(server->pages->doc);
	delete meta;
	server->pages->doc->docid				= 1;
	server->pages->doc->siteid				= 1;
	server->pages->doc->mime_type			= mime_type;
	server->pages->doc->http_status			= HTTP_OK;
	server->pages->doc->number_visits		= 0;
	server->pages->doc->number_visits_changed = 0;
	server->pages->doc->charset 			= CHARSET_UNKNOWN;
	server->pages->doc->content_encoding	= ENCODING_NONE;
	server->pages->doc->duplicate_of		= 0;
	server->pages->doc->raw_content_length	= len;

	server->pages->buffer_one = CBALLOC(char, CALLOC, server->pages->bo_size);

	off64_t raw_content_length = 0;
	bool valid_document = true;
	bool d_check = true;
	irudiko_sketch_t ist;
	// memset(ist.sketch, 0, IRUDIKO_SKETCHSIZE);
	// This is to ensure only significant sketches are returned 
	bool is_empty_sketch = true;

	// Read the input file
	cerr << "Reading                   : ";

	size_t rlen = read_file( filename, server->pages->buffer_one, (size_t)len );
	assert( rlen > 0 );
	assert( len == (off64_t)rlen );
	cerr << rlen << " bytes read" << endl;
	char *inbuf = server->pages->buffer_one;

	// Report if needed
	int rwritten = 0;
	size_t rspace = MAX_STR_LEN;
	char *report = NULL;

	// Check if document is too long
	if (valid_document == true)
		server_gatherer_getsize(server, &(raw_content_length));

	if( valid_document == true && inbuf != NULL && raw_content_length > 0 )
	{
		off64_t readed_bytes;

		inbuf = server_gatherer_dataclean(server, inbuf, &(raw_content_length), &(d_check), &(valid_document), &(readed_bytes));

		if (server->pages->doc->mime_type == MIME_TEXT_PLAIN && strlen(inbuf) == 0)
			valid_document = false;

		// See if it is necessary to search links
		// N.B. Da quì in poi tutti i documenti con speciale mime_type compresso (_GZ) sono in puro testo.
		if (valid_document == true && (HTTP_IS_OK(server->pages->doc->http_status)))
		{
			inbuf = server_gatherer_detect_charset(server, inbuf, &(valid_document), &(readed_bytes));

			siteid_t serverid = 0;

			server_t **servers = CBALLOC(server_t *, MALLOC, 1);
			servers[0] = server;

			starter = CBALLOC(starter_t, CALLOC, 1);
			starter->inst = 0;
			starter->harvest_status = STATUS_HARVEST_EMPTY;
			starter->links_download = links_download;
    		starter->links_log = links_log;
    		starter->links_stat = links_stat;
			starter->servers = servers[0];
    		starter->a_channel = NULL;
    		starter->a_options = NULL;
    		starter->a_optmask = NULL;
    		starter->server_locks_a = NULL;
    		starter->server_locks_b = NULL;
    		starter->server_rwlocks_b = NULL;
			starter->testing = true;
			starter->m_cookie = magic_open(MAGIC_ERROR|MAGIC_MIME_TYPE);

			// Load magic database to detect a file type
			if (starter->m_cookie == NULL)
				die("Harvester: unable to initialize magic library\n");
			else if (magic_load(starter->m_cookie, NULL) != 0)
			{
				const char *magic_err_str = magic_error(starter->m_cookie);
				magic_close(starter->m_cookie);

				if (magic_err_str)
					die("Harvest: cannot load magic database - %s\n", magic_err_str);
			}

			report = CBALLOC(char, MALLOC, rspace);
			report[0] = '\0';

			if (valid_document == true)
				server->pages->doc->content_length = parser_process(starter, serverid, inbuf, report, rwritten, rspace);
			else
			{
				server->pages->doc->content_length = 0;
				server->pages->buffer_two[server->pages->doc->content_length] = '\0';
			}

			// Close magic database to detect a file type
			magic_close(starter->m_cookie);

			servers[0] = NULL;

			free(servers);

			// Check maximum stored size
			if( server->pages->doc->content_length >= (off64_t)CONF_GATHERER_MAXSTOREDSIZE )
			{

				off64_t c = (CONF_GATHERER_MAXSTOREDSIZE - 1);

				if (server->pages->buffer_two[c] != ' ')
				{
					while (c > 0 && server->pages->buffer_two[c] != ' ')
						c--;
		
					while (c > 0 && server->pages->buffer_two[c] == ' ') // si ferma all'ultimo spazio partendo dalla coda di server->pages->buffer_two
						c--;

					c++;
				}

				server->pages->buffer_two[c] = '\0';
				server->pages->doc->content_length = c;
			}
		}
		else
		{
			// Neither OK nor redirect
			cerr << "- not acceptable -";
		}
	// Empty page
	} else {
		cerr << "empty";
	}

	cerr << endl;

	bool fail = false;

	if (server->pages->doc->mime_type == MIME_TEXT_HTML || server->pages->doc->mime_type == MIME_APPLICATION_PDF)
	{
		if (server->pages->doc->mime_type == MIME_TEXT_HTML)
		{
			if (html_first_stage == true)
			{
				cout << "---START-HTML-FIRST-STAGE-PARSING---";
				cout << server->pages->buffer_one;
				cout << "---END-HTML-FIRST-STAGE-PARSING---" << endl << endl;
			}
			else if (server->pages->doc->content_length > HTMLMETAPREFIXSIZE)
				show_content(server->pages->doc->mime_type, server->pages->doc->docid, server->pages->buffer_two, server->pages->doc->content_length);
			else
				fail = true;
		}
		else if (server->pages->doc->mime_type == MIME_APPLICATION_PDF && server->pages->doc->content_length > PDFMETAPREFIXSIZE)
			show_content(server->pages->doc->mime_type, server->pages->doc->docid, server->pages->buffer_two, server->pages->doc->content_length);
		else
			fail = true;
	}
	else if (server->pages->doc->mime_type == MIME_TEXT_PLAIN)
	{
		if (server->pages->doc->content_length > 0)
			show_content( server->pages->doc->mime_type, server->pages->doc->docid, server->pages->buffer_two, server->pages->doc->content_length );
		else
			fail = true;
	}

	if (fail == true)
	{
		cerr << "- not acceptable -" << endl << endl;

		if (debugonly == false)
		{
			fclose(links_download);
			fclose(links_log);
			fclose(links_stat);
		}

		if (server->pages->buffer_links_download != NULL)
			free(server->pages->buffer_links_download);
		if (server->pages->buffer_links_log != NULL)
			free(server->pages->buffer_links_log);
		if (server->pages->buffer_two != NULL)
			free(server->pages->buffer_two);
		if (server->pages->buffer_one != NULL)
			free(server->pages->buffer_one);

		free(server->pages->doc);
		free(server->pages);
		free(server->hostname);
		free(server);

		cbot_stop(0);
	}

	if (server->pages->doc->mime_type == MIME_ROBOTS_TXT && starter != NULL && starter->links_download != NULL)
	{
		cerr << "-------------- ROBOTS D/A RULES ----------------" << endl;

		robots_txt_display(server->pages->buffer_two, (size_t)server->pages->bt_size);

		if (strlen(robots_txt_url) > 0)
		{
			robots_txt_matched_t *winner = robots_txt_match(server->pages->buffer_two, (size_t)server->pages->bt_size, robots_txt_url);

			if (winner->vote > 0)
			{
				cout << endl << "Found match for " << robots_txt_url << " with: ";

				switch (winner->rule)
				{
						case (ROBOTS_ALLOW):
								cout << GRE << ROBOT_TXT_RULE_STR(winner->rule);
								break;
						case (ROBOTS_DISALLOW):
								cout << RED << ROBOT_TXT_RULE_STR(winner->rule);
								break;
						default:
								cout << "Unknown";
								break;
				};

				cout << ": (" << &winner->rulename[1] << ") (" << winner->vote << ')' << NOR << endl << endl;
			}

			free(winner);
		}

		cerr << "------------- LINKS TO SITEMAPS ----------------" << endl;

		rewind(links_download);

		int c;
  
		while ((c = fgetc(links_download)) != EOF) putchar (c);

		cerr << "----------- END LINKS TO SITEMAPS --------------" << endl;


		if (report != NULL)
			free(report);

		fclose(links_download);

		if (debugonly == false)
		{
			fclose(links_log);
			fclose(links_stat);
		}

		if (server->pages->buffer_two != NULL)
			free(server->pages->buffer_two);
		if (server->pages->buffer_one != NULL)
			free(server->pages->buffer_one);

		free(server->pages->doc);
		free(server->pages);
		free(server->hostname);
		free(server);
		free(starter);

		cbot_stop(0);
	}

	if (starter != NULL)
		free(starter);

	if (server->pages->buffer_links_download != NULL)
	{
		if (verbose == true)
		{
			cerr << "------------- LINKS TO DOWNLOAD ----------------" << endl;
			cerr << "---------- ONLY FOR SITES IN INDEX -------------" << endl;

			rewind(links_download);

			int c;
  
			while ((c = fgetc(links_download)) != EOF) putchar (c);

			cerr << server->pages->buffer_links_download << endl;
		}

		free (server->pages->buffer_links_download);
		server->pages->buffer_links_download = NULL;
	}
	if (server->pages->buffer_links_log != NULL)
	{
		if (verbose == true)
		{
			cerr << "--------------- LINKS TO LOG -------------------" << endl;
			cerr << "---------- ONLY FOR SITES IN INDEX -------------" << endl;

			rewind(links_log);

			int c;
  
			while ((c = fgetc(links_log)) != EOF) putchar (c);

			cerr << server->pages->buffer_links_log << endl;
		}

		free (server->pages->buffer_links_log);
		server->pages->buffer_links_log = NULL;
	}

	if (server->pages->doc->mime_type == MIME_TEXT_HTML
		|| server->pages->doc->mime_type == MIME_APPLICATION_PDF
		|| server->pages->doc->mime_type == MIME_TEXT_PLAIN)
	{
		if (verbose == true && html_first_stage == false)
		{
			cerr << "------------------ MD5 hash --------------------" << endl;

			char *hash = new char [(MD5LEN + 1)];
			cmd5_string( server->pages->buffer_two, server->pages->doc->content_length, hash );

			cerr << "[" << hash << "]" << endl;

			delete [] hash;

			if( CONF_MANAGER_SCORE_LIVERANK_WEIGHT )
			{
				IrudikoSimpleReader iread;

				if (server->pages->doc->mime_type == MIME_TEXT_PLAIN)
					iread.process_and_sketch(server->pages->buffer_two, server->pages->doc->content_length, ist.sketch, IRUDIKO_SKETCHSIZE, IRUDIKO_SELECTIONTYPE, IRUDIKO_SELECTIONPARAM);
				else if (server->pages->doc->mime_type == MIME_TEXT_HTML)
					iread.process_and_sketch(&server->pages->buffer_two[HTMLMETAPREFIXSIZE], (server->pages->doc->content_length - HTMLMETAPREFIXSIZE), ist.sketch, IRUDIKO_SKETCHSIZE, IRUDIKO_SELECTIONTYPE, IRUDIKO_SELECTIONPARAM);
				else if (server->pages->doc->mime_type == MIME_APPLICATION_PDF)
					iread.process_and_sketch(&server->pages->buffer_two[PDFMETAPREFIXSIZE], (server->pages->doc->content_length - PDFMETAPREFIXSIZE), ist.sketch, IRUDIKO_SKETCHSIZE, IRUDIKO_SELECTIONTYPE, IRUDIKO_SELECTIONPARAM);

				for(uint h = 0; h < IRUDIKO_SKETCHSIZE; ++h)
					if (ist.sketch[h]!=0)
					{
						is_empty_sketch = false;
						break;
					}
			      
				if( is_empty_sketch == false)
				{
					cerr << "------------------ LSH Sketch hash --------------------" << endl;
			
					for(unsigned short h = 0; h < (IRUDIKO_SKETCHSIZE - 1); h++)
						cerr << ist.sketch[h] << ',';

					cerr << ist.sketch[(IRUDIKO_SKETCHSIZE - 1)] << endl;
				}
			}
		}
	}
	      
	if (html_first_stage == false || rwritten > 0)
		cerr << "------------------------------------------------" << endl;

	if (rwritten > 0)
		cerr << report << endl;

	if (report != NULL)
		free(report);

	if (debugonly == false)
	{
		fclose(links_download);
		fclose(links_log);
		fclose(links_stat);
	}

	if (server->pages->buffer_two != NULL)
		free(server->pages->buffer_two);
	if (server->pages->buffer_one != NULL)
		free(server->pages->buffer_one);

	free(server->pages->doc);
	free(server->pages);
	free(server->hostname);
	free(server);

	// End
	if (thread_alarm == THREADS_OK)
		cbot_stop(0);
	else
		cbot_stop(1);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}
}

void cleanup() {
	parser_close();
}

//
// Name: test_parser_usage
//
// Description:
//   Shows an usage message
//

void test_parser_usage() {
	cerr << "Usage: program filename [OPTION]" << endl;
	cerr << "Warning: Some data are arbitary and must be ignored" << endl;
	cerr << "Tests the different parsers" << endl;
	cerr << endl;
	cerr << " filename                name of the file to parse (must have an absolute path)" << endl;
	cerr << " --html                  file type is html (default)" << endl;
	cerr << " --html-first-stage      file type is html and output is only first stage's parsing" << endl;
	cerr << " --pdf                   file type is pdf" << endl;
	cerr << " --text                  file type is plain text" << endl;
	cerr << " --robots-txt            file type is robots.txt format" << endl;
	cerr << " --sitemap-rdf           file type is sitemap.rdf format" << endl;
	cerr << " --sitemap-xml           file type is sitemap.xml format" << endl;
	cerr << " --feed-atom             file type is application/atom+xml format" << endl;
	cerr << " --feed-rss              file type is application/rss+xml format" << endl;
	cerr << " --robots-txt-url        absolute url path (without prefix protocol) for checking robots.txt file" << endl;
	cerr << " --verbose               output is verbose (work only with option --html)" << endl;
	cerr << " --help                  this help message" << endl;
	cerr << endl;
	cbot_stop(0);
}
