/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/


#include <config.h>

#include "const.h"
#include "utils.h"
#include "xmlconf.h"
#include "xmlconf-main.h"

// Globals

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

int main(int argc, char *argv[])
{
try
{
	regex_t preg;
	char *regex, *match;

	/* get input from user */
	if (argc != 3) {
		printf("Usage: %s <pattern> <string to match>\n", argv[0]);
		return 1;
	}
	regex = argv[1];
	match = argv[2];

	/* compile the regex */
	tokenizeToRegex( regex, &preg );

	/* match the regex */
	if (regexec(&preg, match, 0, NULL, 0) == 0)
		printf("match !\n");
	else
		printf("no match !\n");

	/* clean up */
	regfree(&preg);

	if (thread_alarm == THREADS_OK)
		return 0;
	else
		return 1;
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	return 1;
}
}

void cleanup() {

}
