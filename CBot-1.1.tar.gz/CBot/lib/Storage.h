/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _STORAGE_H_INCLUDED_
#define _STORAGE_H_INCLUDED_

#include <config.h>

// System libraries

#include <features.h>
#include <assert.h>
#include <stdio.h>
#include <fstream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include <queue>
#include <string>
#include <typeinfo>

using namespace std;

// Local libraries

#include "const.h"
#include "die.h"
#include "file.h"
#include "xmlconf.h"
#include "Meta.h"
#include "irudiko.h"

// Filenames

#define STORAGE_FILENAME_MAIN		"storage.main"
#define STORAGE_FILENAME_INDEX		"storage.index"
#define STORAGE_FILENAME_CONTENT	"storage.raw"
#define STORAGE_FILENAME_FREE		"storage.free"
#define STORAGE_FILENAME_DOC_HASH	"Storage.hash.docid_t"
#define STORAGE_FILENAME_DUPLICATES	"storage_duplicates.docid_t"
#define STORAGE_FILENAME_SKETCH		"storage.sketch"
#define STORAGE_FILENAME_SKETCH_GAP	"storage.sketch_gap" // sarebbe utile poi linkare il file su directory tmpfs

// Globals

// Records to create when eof reached
#define STORAGE_GROW_FACTOR	2

// Hash table size for duplicates, as a factor of CONF_COLLECTION_MAXDOC
#define STORAGE_DUPLICATE_HASH_FACTOR 2

// Max size of duplicates hash
#define STORAGE_HASH_MAX (CONF_COLLECTION_MAXDOC * STORAGE_DUPLICATE_HASH_FACTOR)

// Status

enum storage_status_t {
	STORAGE_OK			= 0,
	STORAGE_NOT_FOUND	= 1,
	STORAGE_DUPLICATE	= 2,
	STORAGE_UNCHANGED	= 3,
	STORAGE_ERROR
};

enum linear_probe_status_t {
	PROBE_ERROR			= 0,
	PROBE_CREATED		= 1,
	PROBE_DELETE		= 2,
	PROBE_EXISTENT		= 3,
	PROBE_NOT_FOUND		= 4
};

// Types
typedef struct {
    pthread_mutex_t *locka; //
    pthread_mutex_t *lockb;
    pthread_mutex_t *lockc;
    pthread_rwlock_t *rwlocka; // bucket instance read/write locks //
    pthread_rwlock_t *rwlockb; // bucket instance read/write locks
    pthread_rwlock_t *rwlockc; // bucket instance read/write locks
} strgmutex_t;

typedef struct {
	off64_t offset;
	off64_t size;
} storage_record_t;

enum storage_call_t {
	STORAGE_CREATE		= 0,
	STORAGE_OPEN		= 1,
	STORAGE_CLOSE		= 2,
	STORAGE_REMOVE		= 3
};

// Classes

class Storage
{
	// TODO Allo stato attuale lo storage (relativo a sitelink e linkidx) per instanza conterrà un numero di documenti pari a:
	// CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED per il numero di istanze
	// Queste dimensioni sono sicuramente necessarie per il calcolo del ranking (linkidx)
	typedef struct _storage_free_list_t {
		storage_record_t rec;
		_storage_free_list_t *next;
	} storage_free_list_t;

	typedef struct {
		char basedir[MAX_STR_LEN-1];
		docid_t max_offset;
		docid_t max_docid;
		doc_hash_t *doc_hash; // linear_probe: hash by docid
		docid_t *duplicates; // linear_probe: docid by hash offset
		doc_hash_t count_hash; // linear_probe: indicate the occupancy status of hashs on instance
		storage_free_list_t *free_list;
		int content_file; // per i documenti web ora si usa lo storage su file unix
		int index_file; // fd
		int sketch_file; // fd
		int sketch_gap_file; // fd
	} storage_t;

	// need to passing arguments to threads functions
	typedef struct {
    	instance_t inst;
	    Storage *obj;
		storage_call_t f; // corrisponde alla chiamata di determinate funzioni fatta da pthread_create
	} thread_args_t;

	storage_t *distributed;

	const char *dirname;
	bool readonly;

	strgmutex_t *lock; // mutex must be declared inside function that create threads

	docid_t max_docid;

	// Function required by st_create (pthread use)
	void *thread_function_create( void * );

	// Function required by st_open (pthread use)
	void *thread_function_open( void * );

	// Function required by st_close (pthread use)
	void *thread_function_close( void * );

	// Function required by st_remove (pthread use)
	void *thread_function_remove( void * );

	// Function to proxy to non-static function
	static void* thread_function_caller( void * );

	// Read index file
	storage_status_t read_index_record( instance_t &, docid_t, storage_record_t * );

	// Write index file
	void write_index_record( instance_t &, docid_t, storage_record_t * );

	// Move to rigth offset of index file
	void seek_index_record( instance_t &, docid_t );

	// Grows the index to allow at least docid
	storage_status_t exists( instance_t &, docid_t );

	// Grows the index to allow at least docid
	void grow( instance_t &, docid_t );

	// Hash Linear Probing: check if content of document is found on storage as duplicate or create a new bucket
	linear_probe_status_t linear_probe_resolve( doc_t *, char *, doc_hash_t & );

	// Hash Linear Probing: delete docid from array of duplicates and relative hash from array of hash
	linear_probe_status_t linear_probe_delete( doc_t * );

	// Hashing function
	doc_hash_t hashsum( off64_t, char * ) const;

	// Functions  block to lock/unlock mutexes
	void lock_a_dupl( instance_t & ) const;
	void rdlock_hashs( void ) const;
	void wrlock_hashs( void ) const;
	void rdlock_a_hash( instance_t & ) const;
	void wrlock_a_hash( instance_t & ) const;
	void unlock_a_dupl( instance_t & ) const;
	void unlock_hashs( void ) const;
	void unlock_a_hash( instance_t & ) const;
	//

	public:

	Storage (const char *_X, bool _Y) // ctor
		: distributed (CBALLOC(storage_t, NEW, CONF_COLLECTION_DISTRIBUTED))
		, dirname (_X)
		, readonly (_Y)
		, lock (NULL)
		, max_docid (0)
	{
		//assert( dirname != NULL );
		assert(CONF_OK);
		assert(CONF_COLLECTION_DISTRIBUTED < UCHAR_MAX); // if not, change type
		memset(distributed, 0, (sizeof(storage_t) * CONF_COLLECTION_DISTRIBUTED));
	}

	~Storage () // dtor
	{
		if (distributed != NULL)
		{
			delete [] distributed;
			distributed = NULL;
		}
	}

	// Function for allocate memory and create mutex
	void setmutex( strgmutex_t ** );

	// Function for allocate memory and create mutex
	void destroymutex( void );

	// Create storage with type dependent of basedir name
	void st_create( void );

	// Open storage
	void st_open( void );

	// Close storage
	void st_close( void );

	// Remove storage
	void st_remove( void );

	// Create main hierarchy directories structure
	void make_hierarchy ( instance_t &, const char * ) const;

	// For a docid gived return path where his text is found
	string find_path( docid_t ) const;

	// Return the total docs in the storage
	docid_t docid_count( void ) const;

	// Storage data read
	storage_status_t st_idx_read( instance_t &, docid_t, char *, off64_t & );

	// Storage data write
	storage_status_t st_idx_write( instance_t &, docid_t, char *, off64_t );

	// Storage data delete
	storage_status_t st_idx_delete( instance_t &, docid_t );

	// Write http content document
	storage_status_t write_document( doc_t *, char * );

	// Read http content of document
	storage_status_t read_document( doc_t *, char * );

	// Delete http document // TODO
	// WARNING: DOCUMENTS TO DELETE MUST BE INSERTED ON LIST
	// NOT ONLY: MUST BE ALSO DELETED FROM LINEAR PROBING
	// NVC DDX MUST BE SYNC
	storage_status_t delete_document( doc_t * );

	// (inline) Storage prepare for sequential reading
	storage_status_t prepare_sequential_read( instance_t & );

	// (inline) Storage sequential reading
	storage_status_t sequential_read( instance_t &, storage_record_t *, char * );

	// Write sketch (Irudiko-related function)
	storage_status_t write_sketch( docid_t, irudiko_t *);

	// Read sketch (Irudiko-related function)
	storage_status_t read_sketch( docid_t, irudiko_t *);

	// Write sketch gap (Irudiko-related function)
	storage_status_t write_sketch_gap( docid_t, unsigned char *);

	// Read sketch gap (Irudiko-related function)
	storage_status_t read_sketch_gap( docid_t, unsigned char *);

	// (inline) Skips a number of records in a sequential read process 
	void sequential_skip( instance_t &, unsigned int );

	// Show status of storage
	void dump_status( void );
};

// Functions

// INLINED FUNCTIONS (used by the linkidx also)

//
// Name: sequential_read
//
// Description:
//   Prepares the storage file for sequential reading
//   THIS WORKS only if there are no deletions
//
// Input:
//   st - the storage object
//
// Output:
//   buf - the readed object
//   len - the length
//   

inline storage_status_t Storage::sequential_read( instance_t &inst, storage_record_t *rec, char *buf )
{
	// Read the storage record
    ssize_t readed = read(distributed[inst].index_file, rec, sizeof( storage_record_t ));

	if (readed == 0)
	{
		// End of file, this is ok, this means that we've reached
		// the end of the storage file, and the next records are empty
		buf[0] = '\0';
		return STORAGE_NOT_FOUND;
	}

	if (readed < 0)
        die("storage sequential_read: couldn't read index_file %s\n", cberr());

	// Check for empty documents
	if (rec->size == -1)
	{
		buf[0] = '\0';
		return STORAGE_NOT_FOUND;
	}

	// Go to the content file address for that document
	if (lseek( distributed[inst].content_file, rec->offset, SEEK_SET ) != rec->offset)
        die("storage sequential_read: couldn't seek content_file (address %llu) %s\n", rec->offset, cberr());

	// Read the document
	if (read( distributed[inst].content_file, buf, rec->size ) != rec->size)
        die("storage sequential_read: couldn't read content_file %s\n", cberr());

	buf[rec->size] = '\0';

	return STORAGE_OK;
}

//
// Name: sequential_skip
//
// Description:
//   Skips a number of records in a sequential read process
//   this is useful if we already know that those records
//   are empty, etc.
//
// Input:
//   st - the storage object
//   skip - the number of records to skip
//

inline void Storage::sequential_skip( instance_t &inst, unsigned int skip )
{
	off64_t address = (off64_t)(sizeof(storage_record_t) * skip);

	// Read the storage record
	off64_t rc = lseek(distributed[inst].index_file, address, SEEK_CUR );

	if (rc < 0)
        die("storage sequential_skip: couldn't skip file (address %llu) %s\n", address, cberr());
}

#endif
