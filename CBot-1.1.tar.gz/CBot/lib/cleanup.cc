/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "cleanup.h"

//
// Name: cleanup_enable
//
// Description:
//   Enables all signal handlers to routine die()
//
void cleanup_enable(void)
{
	enable_signal_handler(signal_handler);
}

//
// Name: cleanup_disable
//
// Description:
//   Disables signal handlers
//
void cleanup_disable(void)
{
	disable_signal_handler();
}

//
// Description: join the trheads with excetions
//
// Input:
//  threads - the array of threads to join
//  size - the size of the array of messages
//
// Output: it can throw an exception
//
// Return:
//
void CBotjoin(pthread_t *threads, instance_t size)
{
	bool exception = false;
	char **msgs = CBALLOC(char *, NEW, size);

	for (instance_t inst = 0; inst < size; inst++)
	{
		CBotException *ex = NULL;
		msgs[inst] = NULL;

		pthread_join(threads[inst], (void **)&ex);

		if (ex)
		{
			if (exception == false)
				exception = true;

			msgs[inst] = (char *)ex->what();
		}
	}

	if (exception == true)
		throw CBotExitException(THREADS_STOP_ONERR, size, msgs);
	else
	{
		delete [] msgs;
		msgs = NULL;
	}
}

//
// Name: signal_handler
//
// Description:
//   Generic signal handler, calls die("Signal")
//
void signal_handler(int signum) {
	// (Try to) avoid repeated signals (typical on multi-thread programs)
	disable_signal_handler();


	#ifdef CONLOCK
		if (console_lock != NULL)
		{
			int rc = pthread_mutex_lock(console_lock);

			if (rc != 0)
				cerr << "cleanup signal_handler: cannot lock console_lock " <<  CBoterr(rc) << endl;
		}
	#endif

	// Report the signal number
	// strsignal() seems to lock under some circumstances, so we
	// don't use it here, and we don't use streams either
	fprintf(stderr, "** Got signal %d **\n", signum);

	#ifdef CONLOCK
		if (console_lock != NULL)
		{
			int rc = pthread_mutex_unlock(console_lock);

			if (rc != 0)
				cerr << "cleanup signel_handler: cannot unlock console_lock " <<  CBoterr(rc) << endl;
		}
	#endif

	// Die
	#ifdef DEBUG
		CBotdie(__DATE__, __TIME__, __FILE__, __LINE__, "Signal");
	#else
		CBotdie("Signal");
	#endif
}


//
// Name: enable_signal_handler
//
// Description:
//   Puts a function as a handler for all trapable signals
//
// Input:
//   sighandler - Function to call in response to signals
//
void enable_signal_handler(void (*sighandler)(int))
{
	//struct sigaction action;
	int rc;

	// Set parameters for sigaction
	action.sa_handler = sighandler;
	sigemptyset(&action.sa_mask);
	action.sa_flags = 0;

	// Enables the handlers
    rc = sigdelset(&action.sa_mask, SIGINT);
    assert( rc == 0 );
    rc = sigdelset(&action.sa_mask, SIGSEGV);
    assert( rc == 0 );
    rc = sigdelset(&action.sa_mask, SIGABRT);
    assert( rc == 0 );

	// Ignore SIGHUP, because it's usual
	// to run as a background process in a terminal that can be disconnected.
    rc = sigaddset(&action.sa_mask, SIGHUP);
    assert( rc == 0 );

	// Ignore SIGPIPE, because write() to network under older glibcs can
	// produce that signal
    rc = sigaddset(&action.sa_mask, SIGPIPE);
    assert( rc == 0 );

	// examine and change mask of blocked signals
    rc = pthread_sigmask(SIG_BLOCK, &action.sa_mask, NULL);
    assert( rc == 0 );
}

//
// Name: disable_signal_handler
//
// Description:
//   Uninstall the handlers of enable_signal_handler
//
void disable_signal_handler()
{
	struct sigaction new_action;
	int rc;

	// Set parameters for sigaction
	new_action.sa_handler = SIG_DFL;
    sigemptyset (&new_action.sa_mask);
    new_action.sa_flags = 0;

	// Enables the handlers
    rc = sigdelset(&new_action.sa_mask, SIGINT);
    assert( rc == 0 );
    rc = sigdelset(&new_action.sa_mask, SIGSEGV);
    assert( rc == 0 );
    rc = sigdelset(&new_action.sa_mask, SIGABRT);
    assert( rc == 0 );
    rc = sigdelset(&new_action.sa_mask, SIGHUP);
    assert( rc == 0 );

	// examine and change mask of blocked signals
    rc = pthread_sigmask(SIG_BLOCK, &new_action.sa_mask, NULL);
    assert( rc == 0 );
}

//
// Description: chooses the first thread ready for print same output
//  The functions that use this code must be identical
//
// Input: reference to count declared inside function
//
// Return: true if thread can print else false
//
bool SemaphorePrint::go_ahead ( instance_t &inst )
{
/*
	internal_long_uint_t check = _mprint;
	internal_long_uint_t new_check = (check + 1);

	if (_mprint.compare_exchange_strong(check, new_check) == true)
	{
	} */

	counts[inst]++;

	// Only first thread that change value of atomic 'mprint[offset]' return true (Atomic::exchange)
	if (counts[inst] < UCHAR_MAX && mprint[counts[inst]].exchange(true) == false)
		return true;

	return false;
}

//
// Description: reset counts
//  The functions that use this code must be identical
//  and this function MUST be called separated by go_ahead with thread_barrier
//
// Input: reference to count declared inside function
//
// Return: true if thread can print else false
//
void SemaphorePrint::reset ( instance_t &inst )
{
	counts[inst] = 0;

	for (unsigned char i = 0; i < UCHAR_MAX; i++) mprint[i] = false;

	return;
}
