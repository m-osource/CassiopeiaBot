/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#ifndef _METADDX_H_INCLUDED_
#define _METADDX_H_INCLUDED_

#include <config.h>

// System libraries

#include <features.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <iostream>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/stat.h>


#include <math.h>
#include <errno.h>
#include <queue>
#include <string>
#include <map>

using namespace std;

// Local libraries

#include "const.h"
#include "http_codes.h"
#include "xmlconf.h"
#include "die.h"
#include "utils.h"
#include "Url.h"
#include "http_charset.h"

// File names

#define METADDX_FILENAME_OPTMASK_SITE	"metaddx.optmasksite"
#define METADDX_FILENAME_SITE			"metaddx.site"
#define METADDX_FILENAME_DOC			"metaddx.doc"

#define LINK_NORMALIZATION	((pagerank_t)1)

// Meta index status

enum metaddx_status_t {
	METADDX_OK         = 0,
	METADDX_KO, // used only for optmask checking
	METADDX_ERROR,
	METADDX_EOF
};

// Status of a document (doc.status)

enum doc_status_t {
	STATUS_DOC_ALL			= 0,
	STATUS_DOC_NEW			= 1,
	STATUS_DOC_ASSIGNED		= 2,
	STATUS_DOC_GATHERED		= 3,
	STATUS_DOC_INDEXED		= 4,
	STATUS_DOC_FORBIDDEN	= 5,  // excluded through robots.txt's rules
	STATUS_DOC_EXCLUSION	= 6,  // excluded through crawler politics
	STATUS_DOC_IGNORED		= 99  // Must be ignored
};

#define DOC_STATUS_STR(x) (\
		x==0 ? "STATUS_DOC_ALL" :\
		x==1 ? "STATUS_DOC_NEW" :\
		x==2 ? "STATUS_DOC_ASSIGNED" :\
		x==3 ? "STATUS_DOC_GATHERED" :\
		x==4 ? "STATUS_DOC_INDEXED" :\
		x==5 ? "STATUS_DOC_FORBIDDEN" :\
		x==6 ? "STATUS_DOC_EXCLUSION" :\
		x==99 ? "STATUS_DOC_IGNORED" : "(invalid)" )

// Type of a document (doc.mime_type) ... uso interno crawler

enum mime_type_t {
	MIME_UNKNOWN				= 0,
	MIME_REDIRECT				= 1,
	MIME_ROBOTS_TXT				= 2,
	MIME_ROBOTS_RDF				= 3, // file con estensione gz non supportati (scelta amministrativa)
	MIME_ROBOTS_RDF_BROKEN		= 4,
	MIME_ROBOTS_XML				= 5,
	MIME_ROBOTS_XML_GZ			= 6,
	MIME_ROBOTS_XML_BROKEN		= 7, // spezzato
	MIME_FEEDS_ATOM_XML			= 8,
	MIME_FEEDS_ATOM_XML_GZ		= 9,
	MIME_FEEDS_ATOM_XML_BROKEN	= 10, // spezzato
	MIME_FEEDS_RSS_XML			= 11,
	MIME_FEEDS_RSS_XML_GZ		= 12,
	MIME_FEEDS_RSS_XML_BROKEN	= 13, // spezzato
	MIME_TEXT_HTML				= 14,
	MIME_TEXT_PLAIN				= 15,
	MIME_APPLICATION_XML		= 16,
	MIME_APPLICATION_ATOM_XML	= 17,
	MIME_APPLICATION_RSS_XML	= 18,
	MIME_APPLICATION_FLASH		= 19,
	MIME_APPLICATION_PDF		= 20,
	MIME_APPLICATION_PDF_BROKEN	= 21, // spezzato
	MIME_APPLICATION			= 22,
	MIME_AUDIO					= 23,
	MIME_IMAGE					= 24,
	MIME_VIDEO					= 25,
	MIME_TEXT_WAP				= 26,
	MIME_TEXT_RTF				= 27,
	MIME_TEXT_XML				= 28,
	MIME_TEXT_TEX				= 29,
	MIME_TEXT_CHDR				= 30,
	MIME_TEXT					= 31,
	MIME_MESSAGE				= 32,
	MIME_MODEL					= 33,
	MIME_EXAMPLE				= 34
};

#define MIME_TYPE_STR(x) (\
		x==MIME_UNKNOWN					? "MIME_UNKNOWN" :\
		x==MIME_REDIRECT				? "MIME_REDIRECT" :\
		x==MIME_ROBOTS_TXT				? "MIME_ROBOTS_TXT" :\
		x==MIME_ROBOTS_RDF				? "MIME_ROBOTS_RDF" :\
		x==MIME_ROBOTS_RDF_BROKEN		? "MIME_ROBOTS_RDF_BROKEN" :\
		x==MIME_ROBOTS_XML				? "MIME_ROBOTS_XML" :\
		x==MIME_ROBOTS_XML_GZ			? "MIME_ROBOTS_XML_GZ" :\
		x==MIME_ROBOTS_XML_BROKEN		? "MIME_ROBOTS_XML_BROKEN" :\
		x==MIME_FEEDS_ATOM_XML			? "MIME_FEEDS_ATOM_XML" :\
		x==MIME_FEEDS_ATOM_XML_GZ		? "MIME_FEEDS_ATOM_XML_GZ" :\
		x==MIME_FEEDS_ATOM_XML_BROKEN	? "MIME_FEEDS_ATOM_XML_BROKEN" :\
		x==MIME_FEEDS_RSS_XML			? "MIME_FEEDS_RSS_XML" :\
		x==MIME_FEEDS_RSS_XML_GZ		? "MIME_FEEDS_RSS_XML_GZ" :\
		x==MIME_FEEDS_RSS_XML_BROKEN	? "MIME_FEEDS_RSS_XML_BROKEN" :\
		x==MIME_TEXT_HTML				? "MIME_TEXT_HTML" :\
		x==MIME_TEXT_PLAIN				? "MIME_TEXT_PLAIN" :\
		x==MIME_APPLICATION_XML 		? "MIME_APPLICATION_XML" :\
		x==MIME_APPLICATION_ATOM_XML 	? "MIME_APPLICATION_ATOM_XML" :\
		x==MIME_APPLICATION_RSS_XML 	? "MIME_APPLICATION_RSS_XML" :\
		x==MIME_APPLICATION_FLASH		? "MIME_APPLICATION_FLASH" :\
		x==MIME_APPLICATION_PDF			? "MIME_APPLICATION_PDF" :\
		x==MIME_APPLICATION_PDF_BROKEN	? "MIME_APPLICATION_PDF_BROKEN" :\
		x==MIME_APPLICATION				? "MIME_APPLICATION" :\
		x==MIME_AUDIO					? "MIME_AUDIO" :\
		x==MIME_IMAGE					? "MIME_IMAGE" :\
		x==MIME_VIDEO					? "MIME_VIDEO" :\
		x==MIME_TEXT_WAP				? "MIME_TEXT_WAP" :\
		x==MIME_TEXT_RTF				? "MIME_TEXT_RTF" :\
		x==MIME_TEXT_XML				? "MIME_TEXT_XML" :\
		x==MIME_TEXT_TEX				? "MIME_TEXT_TEX" :\
		x==MIME_TEXT_CHDR				? "MIME_TEXT_CHDR" :\
		x==MIME_TEXT					? "MIME_TEXT" :\
		x==MIME_MESSAGE					? "MIME_MESSAGE" :\
		x==MIME_MODEL					? "MIME_MODEL" :\
		x==MIME_EXAMPLE					? "MIME_EXAMPLE" : "(invalid)" )

// Type for content encoding (supported)

enum content_encoding_t {
        ENCODING_NONE		= 0,
        ENCODING_DEFLATE	= 1,
        ENCODING_GZIP		= 2,
        ENCODING_UNKNOWN	= 3
};

#define CONTENT_ENCODING_STR(x) (\
		x==ENCODING_NONE		? "ENCODING_NONE" :\
		x==ENCODING_DEFLATE		? "ENCODING_DEFLATE" :\
		x==ENCODING_GZIP		? "ENCODING_GZIP" :\
		x==ENCODING_UNKNOWN		? "ENCODING_UNKNOWN" : "(invalid)" )

// Type for changefreq of sitemap's standard (supported)

enum sitemap_xml_changefreq_t {
		NONE	= 0, // non standard (only for internal use)
		ALWAYS	= 1,
		HOURLY	= 2,
		DAILY	= 3,
		WEEKLY	= 4,
		MONTHLY	= 5,
		YEARLY	= 6,
		NEVER	= 7
};

// Usato per memorizzare numeri relativi alle priority di sitemap.xml
// IMPORTANTE: Quando (priority == -1) significa che è quello di default e NON è necessario scriverlo sul file 'links_download'
// in questo modo si risparmiano anche inutili scritture su disco perchè il priority di default è quello più utilizzato
typedef char sitemap_xml_priority_t; // Da non confondere con 'priority_t'

#define CHANGEFREQ_STR(x) (\
		x==NONE			? "NONE" :\
		x==ALWAYS		? "ALWAYS" :\
		x==HOURLY		? "HOURLY" :\
		x==DAILY		? "DAILY" :\
		x==WEEKLY		? "WEEKLY" :\
		x==MONTHLY		? "MONTHLY" :\
		x==YEARLY		? "YEARLY" :\
		x==NEVER		? "NEVER" : "(invalid)" )

// Type for harvest indicator
/*
enum https_check_t {
        NOT_HARVESTED			= 0,
        HARVESTED_FIRST_CICLE		= 1,
        HARVESTED_SECOND_CICLE		= 2,
        HARVESTED_THIRD_CICLE		= 3,
        HARVESTED_FOURTH_CICLE		= 4,
        GOOD_HARVESTED			= 5,
        POOR_HARVESTED			= 6
};

#define HARVESTER_INDICATOR_STR(x) (\
		x==NOT_HARVESTED		? "NOT_HARVESTED" :\
		x==HARVESTED_FIRST_CICLE	? "HARVESTED_FIRST_CICLE" :\
		x==HARVESTED_SECOND_CICLE	? "HARVESTED_SECOND_CICLE" :\
		x==HARVESTED_THIRD_CICLE	? "HARVESTED_THIRD_CICLE" :\
		x==HARVESTED_FOURTH_CICLE	? "HARVESTED_FOURTH_CICLE" :\
		x==GOOD_HARVESTED		? "GOOD_HARVESTED (automatic migration protocol administratively denied)" :\
		x==POOR_HARVESTED		? "POOR_HARVESTED" : "(invalid)" )
*/

// Type for depth

typedef unsigned short int depth_t;

// Types for link ranking

typedef double siterank_t;
typedef double pagerank_t;
typedef double wlrank_t;
typedef double hubrank_t;
typedef double authrank_t;
typedef double liverank_t;

// Type for freshness

typedef double freshness_t;

// Type for priority

typedef double priority_t;

// Type for site_optmask
typedef uint8_t site_options_t;

// Type for doc_optmask (future use)
typedef uint8_t doc_options_t;

// Type for the metadata about a document

enum site_optmask_t : site_options_t {
		SITE_OPT_FALSE		= 0,	// can be use as "virtual negative value", or to set to 0 full optmask
		SITE_OPT_DENY		= 1,	// administratively deny 
		SITE_OPT_NEW		= 2,	// site is new
		SITE_OPT_VRTXT		= 4,	// valid robots.txt
		SITE_OPT_VSRDF		= 8,	// valid sitemap.rdf
		SITE_OPT_GUEST		= 16,	// guest site
		SITE_OPT_GICON		= 32,	// guest site have icon on SEO results (to have guest icon site must be a guest!)
		SITE_OPT__UNUSED	= 64,
		SITE_OPT___UNUSED	= 128
};

#define SITE_STATUS_STR(x) (\
		this->site_option_get(x, SITE_OPT_NEW, true) == METADDX_OK ? "STATUS_SITE_NEW" : "STATUS_SITE_VISITED" )

enum doc_optmask_t : doc_options_t {
		DOC_OPT_FALSE		= 0,	// can be use as "virtual negative value", or to set to 0 full optmask
		DOC_OPT_CANON		= 1,	// canonical page indicate in doc_t structure, else (if docid indication is valid) duplicated
		DOC_OPT_FFEED		= 2,	// page from feed
		DOC_OPT_VMIMET		= 4,	// valid feed or sitemap mimetype
		DOC_OPT_ABSLMOD		= 8,	// absolute last modified from feed or sitemap
		DOC_OPT_CHUNKED		= 16,	// http chunked
		DOC_OPT_DYNAMIC		= 32,	// doc is dynamic
		DOC_OPT_SNICONS		= 64,	// homepage and some other have guest icons in SEO
		DOC_OPT___UNUSED	= 128
};

enum doc_field_t {
	DOC_FIELD_UNDEF = 0,
	DOC_FIELD_DEPTH,
	DOC_FIELD_IN_DEGREE,
	DOC_FIELD_OUT_DEGREE,
	DOC_FIELD_HTTP_STATUS,
	DOC_FIELD_FEEDS
};

enum component_t {
	COMPONENT_UNDEF = 0,
	COMPONENT_MAIN_NORM,
	COMPONENT_MAIN_MAIN,
	COMPONENT_MAIN_IN,
	COMPONENT_MAIN_OUT,
	COMPONENT_IN,
	COMPONENT_OUT,
	COMPONENT_TIN,
	COMPONENT_TOUT,
	COMPONENT_TUNNEL,
	COMPONENT_ISLAND,
	COMPONENT_COUNT // 'COMPONENT_COUNT' must be the last
};

#define COMPONENT_STR(x) (\
	(x==COMPONENT_UNDEF)		? "COMPONENT_UNDEF" : \
	(x==COMPONENT_MAIN_NORM)	? "COMPONENT_MAIN_NORM" : \
	(x==COMPONENT_MAIN_MAIN)	? "COMPONENT_MAIN_MAIN" : \
	(x==COMPONENT_MAIN_IN)		? "COMPONENT_MAIN_IN" : \
	(x==COMPONENT_MAIN_OUT)		? "COMPONENT_MAIN_OUT" : \
	(x==COMPONENT_IN)			? "COMPONENT_IN" : \
	(x==COMPONENT_OUT)			? "COMPONENT_OUT" : \
	(x==COMPONENT_TIN)			? "COMPONENT_TIN" : \
	(x==COMPONENT_TOUT)			? "COMPONENT_TOUT" : \
	(x==COMPONENT_TUNNEL)		? "COMPONENT_TUNNEL" : \
	(x==COMPONENT_ISLAND)		? "COMPONENT_ISLAND" : "(invalid)" )

typedef struct {
	// Main parameters
	docid_t			docid;
	siteid_t		siteid;
	doc_status_t   	status;
	mime_type_t		mime_type;

	// Harvester parameters
	int				http_status;
	off64_t			raw_content_length;
	float          	effective_speed;
	uint			number_visits;
	uint			number_visits_changed;
	time_t         	time_unchanged;
	time_t			first_visit;
	time_t			last_visit;
	time_t			last_modified;
	bool			abs_last_modified;

	// Gatherer parameters
	off64_t			content_length;
	docid_t			duplicate_of;

	// Seeder parameters
	depth_t			depth;
	bool			is_dynamic;

	// Manager parameters
	uint			in_degree;
	uint			out_degree;

	pagerank_t		pagerank;
	wlrank_t        wlrank;
	hubrank_t       hubrank;
	authrank_t      authrank;

	freshness_t     freshness;

	priority_t		current_score;
	priority_t		future_score;
} doc_old_t;

typedef struct {
	// Main parameters
	docid_t							docid;
	siteid_t						siteid;
	siteid_t						domainid;
	doc_status_t					status;
	mime_type_t						mime_type;

	// Harvester parameters
	int								http_status;

	float							effective_speed;
	float							latency;

	time_t							time_unchanged;
	time_t							first_visit;
	time_t							last_visit;
	time_t							last_modified;

	// Gatherer parameters
	off64_t							raw_content_length;
	off64_t							content_length;
	doc_hash_t						hash_value_links; // media sulla sommatoria degli hash dei links relativi ai download
	docid_t							duplicate_of;
	char							last_modified_credits; // se last_modified non attendibili diventa negativo

	content_encoding_t				content_encoding;

	// Seeder parameters
	depth_t							depth;
	bool							is_dynamic;

	// Manager parameters
	unsigned int					in_degree;
	unsigned int					out_degree;

	pagerank_t						pagerank;
	wlrank_t						wlrank;
	hubrank_t						hubrank;
	authrank_t						authrank;
	liverank_t						liverank;

	freshness_t						freshness;

	priority_t						current_score;
	priority_t						future_score;

	float							latency_connect;	// used for measuring times

   	charset_t						charset; //4 Bytes
   	Language						language; //4 Bytes

	doc_options_t					options;

	bool							chunked;

	// sezione relativa alle sitemap.xml o feed
	bool							from_feed;
	bool							has_valid_mimetype;
	bool							abs_last_modified; // la data di ultima modifica viene impostata attraverso di lettura di sitemap o feed
	sitemap_xml_changefreq_t 		sitemap_changefreq;
	sitemap_xml_priority_t			sitemap_prio;

	unsigned int					number_visits;
	unsigned int					number_visits_changed;

	uint8_t							reserved[24]; //Originally of size 12

	// IMPORTANTE:
	// number_visits_changed, deve essere posizionato alla fine della struttura perchè serve a far capire a cbot-connector
	// se la scrittura da parte di metaddx_doc_store è terminata e dunque la struttura può essere letta
} doc_t;

// Type for the metadata about a site

typedef struct {
	siteid_t		siteid;
	siteid_t		domainid;
//	site_status_t	status;
	unsigned int	harvest_id;
//	https_check_t	https_check; // se GOOD_HARVESTED indica che il sito ha un numero di documenti sufficenti per non provare il protocollo https
	protocols_t		protocol; // specifica se il protocollo è http o https

	unsigned int	count_error;

	docid_t			count_doc;
	docid_t			count_doc_ok;
	docid_t			count_doc_static;
	docid_t			count_doc_dynamic;
	docid_t			count_doc_gathered;
	docid_t			count_doc_new;
	docid_t			count_doc_assigned;
	docid_t			count_doc_ignored;

	time_t			age_oldest_page;
	time_t			age_newest_page;
	time_t			age_average_page;
	off64_t			raw_content_length;

//	struct in_addr  addr;

	time_t			last_visit;
	time_t          last_resolved;
	time_t			last_checked_robots_txt;
	time_t			last_checked_sitemap_rdf;

	docid_t			docid_robots_txt;
	docid_t			docid_sitemap_rdf;

	bool			has_valid_robots_txt;
	bool			has_valid_sitemap_rdf;


	// Site graph structure
	siteid_t		in_degree;
	siteid_t		out_degree; 	
	depth_t			max_depth;
	component_t		component;
	siterank_t		siterank;
	docid_t			internal_links; // Internal links can be at most
									// the total number of documents, if
									// a website is completely internal links

	// Link rank summaries
	pagerank_t		sum_pagerank;
	wlrank_t		sum_wlrank;
	hubrank_t		sum_hubrank;
	authrank_t		sum_authrank;
	liverank_t		sum_liverank;

	// Bytes
	off64_t			bytes_in;
	off64_t			bytes_out;

	// Time
	float			resolver_latency;

	uint8_t			reserved[420];
} site_old_t;

typedef struct {
	siteid_t		siteid;
	siteid_t		domainid;
	unsigned int	harvest_id;
	protocols_t		protocol; // specifica se il protocollo è http o https

	unsigned int	count_error;

	docid_t			count_doc;
	docid_t			count_doc_ok;
	docid_t			count_doc_static;
	docid_t			count_doc_dynamic;
	docid_t			count_doc_gathered;
	docid_t			count_doc_new;
	docid_t			count_doc_assigned;
	docid_t			count_doc_ignored;

	time_t			age_oldest_page;
	time_t			age_newest_page;
	time_t			age_average_page;
	off64_t			raw_content_length;

	//struct in_addr  addr;
	//struct in6_addr addr6;

	time_t			last_visit;
	time_t          last_resolved;
	time_t			last_checked_robots_txt;
	time_t			last_checked_sitemap_rdf;

	docid_t			docid_robots_txt;
	docid_t			docid_sitemap_rdf;

	// Site graph structure
	siteid_t		in_degree;
	siteid_t		out_degree; 	
	depth_t			max_depth;
	component_t		component;
	siterank_t		siterank;
	docid_t			internal_links; // Internal links can be at most
									// the total number of documents, if
									// a website is completely internal links

	// Link rank summaries
	pagerank_t		sum_pagerank;
	wlrank_t		sum_wlrank;
	hubrank_t		sum_hubrank;
	authrank_t		sum_authrank;
	liverank_t		sum_liverank;

	// Bytes
	off64_t			bytes_in;
	off64_t			bytes_out;

	// Time
	float			resolver_latency;

	uint8_t			reserved[420];
} site_t;

typedef struct {
    pthread_mutex_t *locka;
} metamutex_t;

enum meta_call_t {
    META_OPEN      = 0,
    META_CLOSE     = 1,
    META_REMOVE    = 2
};
//

class Meta
{
	// Type for a metaindex
	// The document count is stored in doc[0].docid
	// The site count is stored in site[0].siteid
	typedef struct {
		int file_site; // fd
		int file_optmask_site; // fd
		int file_doc; // fd
		atomic<site_options_t> *optmask_site; // [memory] WARNING: CANNOT be set same bit on different status on concurrency operation
		char dirname[MAX_STR_LEN];
		siteid_t count_site;
		docid_t count_doc;
		// bool readonly;
	} mddx_t;

	typedef struct {
		mddx_t *distributed;
		atomic<siteid_t> count_site; // Counter reliable only in readonly mode true
		atomic<docid_t> count_doc; // Counter reliable only in readonly mode true
		bool readonly;
	} metaddx_t;

	// need to passing arguments to threads functions
	typedef struct {
    	instance_t inst;
	    Meta *obj;
    	char *d;
		meta_call_t f; // per determinate lettere corrisponde la chiamata a determinate funzioni fatta da pthread_create
	} thread_args_t;

	// main structure
	metaddx_t *m;
	const char* dirname;
	bool readonly;

	// Function required by metaddx_open (pthread use)
	void *thread_function_open(void *args);

	// Function required by metaddx_close (pthread use)
	void *thread_function_close( void * );

	// Function required by metaddx_remove (pthread use)
	void *thread_function_remove( void * );

	// Function to proxy to non-static function
	static void* thread_function_caller( void * );

	// Retreive site_t (the passage of the structure metaddx_t is required to skip the default work on special object 'this')
	metaddx_status_t site_retrieve( metaddx_t *, site_t * );

	// Retreive doc_t (the passage of the structure metaddx_t is required to skip the default work on special object 'this')
	metaddx_status_t doc_retrieve( metaddx_t *, doc_t * );

	public:

	Meta (const char *_X, bool _Y) // ctor
		: m (NULL)
		, dirname (_X)
		, readonly (_Y)
	{
	}

	~Meta () // dtor
	{
	}

	// Open metaddx
	void ddx_open( void );

	// Close metaddx
	metaddx_status_t ddx_close( void );

	// Remove metaddx
	void ddx_remove( void );

	// Blank site records
	void site_default( site_t * );

	// Blank doc records
	void doc_default( doc_t * );

	// Retreive site_t
	metaddx_status_t site_retrieve( site_t * );

	// Retreive more site_t on buffer
	metaddx_status_t site_retrieve_buffered( site_t *, size_t );

	// Retrieve site_optmask_t
	metaddx_status_t site_option_get( siteid_t, site_optmask_t, bool );

	// Retreive doc_t
	metaddx_status_t doc_retrieve( doc_t * );

	// Retreive more doc_t on buffer
	metaddx_status_t doc_retrieve_buffered( doc_t *, size_t );

	// Get number of sites
	siteid_t site_count( void ) const;

	// Get number of sites
	siteid_t instance_site_count( instance_t & ) const; // usato solo da harvest.cc

	// Get number of docs
	docid_t doc_count( void ) const;

	// Get number of docs
	docid_t instance_doc_count( instance_t & ) const; // usato solo da words_language_finder.cc

	// Store site_t
	metaddx_status_t site_store( site_t * );

	// Store more site_t from buffer
	metaddx_status_t site_store_buffered( site_t *, size_t );

	// Store site_optmask_t
	metaddx_status_t site_option_set( siteid_t, site_optmask_t, bool );

	// Store doc_t
	metaddx_status_t doc_store( doc_t * );

	// Store more doc_t from buffer
	metaddx_status_t doc_store_buffered( doc_t *, size_t );

	// Dump doc status
	void dump_doc_status( doc_t * );

	// Dump doc short status
	void dump_doc_short_status( doc_t * );

	// Dump site status
	void dump_site_status( site_t * );

	// Dump status
	void dump_status( void );

	// Dump doc header
	void dump_doc_header( FILE * );

	// Dump doc
	void dump_doc( doc_t *, FILE * );

	// Dump all sites
	void dump_sitelist( Url *, FILE * );

	// Dump site header
	void dump_site_header( FILE * );

	// Dump site
	void dump_site( site_t *, char *, FILE * );

	// Get mime type of a mime_string
	mime_type_t mime_type( char *, char * ) const;

	// Get content encoding of a encoding_string
	content_encoding_t content_encoding( char * );

	// Get changefreq of a changefreq_string
	sitemap_xml_changefreq_t sitemap_changefreq_encoding( char * );

	// Get priority of sitemap priority_string
	sitemap_xml_priority_t sitemap_priority_encoding( char * );

	// Convert old site struct to new
	void convert_old_site_file( char *, bool );

	// Convert old doc struct to new
	void convert_old_doc_file( char *, bool );
};

#endif
