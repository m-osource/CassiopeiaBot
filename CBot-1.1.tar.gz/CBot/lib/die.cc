/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "die.h"

//
// Name: CBotException constructor
//
// Description: keep the exception message inside CBotException class
//
// Input:
//   _C - the thread_alarm enumerator
//   _M - the message
//
CBotException::CBotException(thread_alarm_t _C, char *_M) // ctor
	: code (_C)
	, message (_M)
	, messages_size (0)
	, messages (NULL)
{
	thread_alarm.exchange(_C);
}

//
// Name: CBotException constructor
//
// Description: keep the exception messages from threads inside CBotException class
//
// Input:
//   _C - the thread_alarm enumerator
//   _S - the size of array of messages
//   _M - the messages by pointer of pointers
//
CBotException::CBotException(thread_alarm_t _C, instance_t _S, char **_M) // ctor
	: code (_C)
	, message (NULL)
	, messages_size (_S)
	, messages (_M)
{
	thread_alarm.exchange(_C);
}

//
// Name: CBotException destructor
//
// Description: show the messages and then delete allocated memory
//
CBotException::~CBotException() // dtor
{
	if (messages)
	{
		instance_t count = 0;

		for (instance_t i = 0; i < messages_size; i++)
			if (messages[i])
				count++;

		if (count > 1)
			cerr << RED << "Threads Exceptions:" << NOR << endl;
		else
			cerr << RED << "Thread Exception:" << NOR << endl;

		for (instance_t i = 0; i < messages_size; i++)
			if (messages[i])
			{
				cerr << "On instance " << (unsigned long int)i << " - " << LRE << messages[i] << NOR << endl;
				delete [] messages[i];
			}

		cerr << NOR;

		delete [] messages;
	}

	if (message)
	{
		cerr << RED << "Exception: " << LRE << message << NOR << endl;

		delete [] message;
	}
}

//
// Name: CBotExitException::Exception
//
// Description: Return the exception
//
// Return: the pointer to CBotException object
//
CBotException *CBotExitException::Exception( void ) const
{
	return ex; 
}

//
// Name: CBotExitException::DoThreadExit
//
// Description: Exit from thread passing the exception to 'pthread_join'
//
void CBotExitException::DoThreadExit( void ) const
{
	pthread_exit((void *)ex);
}

//
// Name: CBotExitException::DoThreadExit
//
// Description: Sync the threads and then exit from thread passing the exception to 'pthread_join'
//
void CBotExitException::DoThreadExit( pthread_barrier_t *barrier ) const
{
	if (sync_thread == true && barrier)
		pthread_barrier_wait(barrier); // no checking return status

	pthread_exit((void *)ex);
}

#ifdef DEBUG

//
// Name: die
//
// Description:
//   Prints a message, calls cleanup() and exit()
//   Writes to syslog
//
// Input:
//   args - String to print to screen
//
void CBotdie(const char *date, const char *time, const char *file, int line, const char *format, ...)
{
	cerr << endl;

	const unsigned char len = 200;
	char *buffer = NULL;

	va_list args;
    va_start(args, format);

	try
	{
		buffer = new char [len];
	}
	catch (std::bad_alloc& ba)
	{
    	cerr << "bad_alloc caught: " << ba.what() << endl;
		exit(1);
	}

	buffer[0] = ASCII_NUL;

	int n = vsnprintf (buffer, len, format, args);

	va_end(args);

	#ifdef CONLOCK
		if (console_lock != NULL)
		{
			int rc = pthread_mutex_lock(console_lock);

			if (rc != 0)
				cerr << "cleanup CBotdie: cannot lock console_lock " <<  CBoterr(rc) << endl;
		}
	#endif

	if (n >= 0 && n < len)
	{
		// Write to syslog
		syslog(LOG_ERR, "(%s, %s) die: %s at file %s line %d", date, time, buffer, file, line);
		// Report
//		fprintf(stderr, "\n(%s, %s) *** Error: %s at file %s line %d ***\n", date, time, buffer, file, line);
	}
	else if (n >= len)
	{
		// Truncate message
		strncat(&buffer[len - 5], "... ", 4);
		// Write to syslog
		syslog(LOG_ERR, "(%s, %s) die: %s at file %s line %d", date, time, buffer, file, line);
//		// Report
//		fprintf(stderr, "\n(%s, %s) *** Error: %s at file %s line %d ***\n", date, time, buffer, file, line);
	}
		
	// Report
	// fprintf(stderr, "*** Emergency cleanup ... ");
	// fprintf(stderr, " done, exit(1)\n");

	#ifdef CONLOCK
		if (console_lock != NULL)
		{
			int rc = pthread_mutex_unlock(console_lock);

			if (rc != 0)
				cerr << "cleanup CBotdie: cannot unlock console_lock " <<  CBoterr(rc) << endl;
		}
	#endif

	// Report the exception
	throw CBotExitException(THREADS_STOP_ONERR, buffer);
}

#else

//
// Name: die
//
// Description:
//   Prints a message, calls cleanup() and exit()
//   Writes to syslog
//
// Input:
//   args - String to print to screen
//
//void dieplus(const char* file, int line, time_t time, const char *format, ...) {
void CBotdie(const char *format, ...)
{
	cerr << endl;

	const unsigned char len = 200;
	char *buffer = NULL;

	va_list args;
    va_start(args, format);

	try
	{
		buffer = new char [len];
	}
	catch (std::bad_alloc& ba)
	{
    	cerr << "bad_alloc caught: " << ba.what() << endl;
		exit(1);
	}

	buffer[0] = ASCII_NUL;

	int n = vsnprintf (buffer, len, format, args);

	va_end(args);

	#ifdef CONLOCK
		if (console_lock != NULL)
		{
			int rc = pthread_mutex_lock(console_lock);

			if (rc != 0)
				cerr << "cleanup CBotdie: cannot lock console_lock " <<  CBoterr(rc) << endl;
		}
	#endif

	if (n >= 0 && n < len)
	{
		// Write to syslog
		syslog(LOG_ERR, "die: %s", buffer);
		// Report
	//	fprintf(stderr, "\n*** Error: %s ***\n", buffer);
	}
	else if (n >= len)
	{
		// Truncate message
		strncat(&buffer[len - 5], "... ", 4);
		// Write to syslog
		syslog(LOG_ERR, "die: %s", buffer);
		// Report
	//	fprintf(stderr, "\n*** Error: %s ***\n", buffer);
	}
		
	// Report
	// fprintf(stderr, "*** Emergency cleanup ... ");
	// fprintf(stderr, " done, exit(1)\n");

	#ifdef CONLOCK
		if (console_lock != NULL)
		{
			int rc = pthread_mutex_unlock(console_lock);

			if (rc != 0)
				cerr << "cleanup CBotdie: cannot unlock console_lock " <<  CBoterr(rc) << endl;
		}
	#endif

	// Report the exception
	throw CBotExitException(THREADS_STOP_ONERR, buffer);
}

#endif

//
// Description: return errno on string
//
// Input: errno - the errno status - this is thread local
//
// Output:
//
// Return: pointer to string error
//
char *CBoterr(int &_errno)
{
	const unsigned short errbuflen = 500;
	char errbuf[errbuflen];

	errbuf[0] = '\0';

	char *tse = strerror_r(_errno, errbuf, errbuflen);

	_errno = 0; // set errno for next checking

	return tse;
}
