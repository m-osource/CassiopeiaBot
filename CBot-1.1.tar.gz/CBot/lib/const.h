/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#if !defined(_CONST_H_INCLUDED_)
#define _CONST_H_INCLUDED_

#include <config.h>
#include <iostream>
#include <string>
#include <atomic>
#include <pthread.h>
#include <netinet/in.h>

// nome dello spider (è inserito quì e non nel file di configurazione per non essere modificato agevolmente)
// #define SPIDERNAME "Cbot"
// #define SPIDERNAME "Csspbot"
#define SPIDERNAME "Vspider"

// file presente nella directory temporanea che ha lo scopo
// mantenere informazione utili per l'esecuzione dei programmi
#define CRAWLER_FILENAME_STATS ".___crawler.stat"

// se definito è possibile ottenere da 'die' e da 'CBalloc' il numero di linea e il nome del file in cui questi sono stati invocati
// in caso di errore
#define DEBUG

// Maximum length of a string and a document
#define MAX_STR_LEN		1024       // 1Kb
#define MAX_DOC_LEN		524288    // 500Kb 
#define MAX_DOMAIN_LEN		256      // RFC 1035 tell us that the max length in byte of FQDN is equal at 255 byte (plus '\0' 256)
// #define MAX_DOC_LEN		1048576    // 1000Kb Increased due to charset conversion
// #define CONF_MAX_SITEMAP_FILE_SIZE 52428000 // by standard of 'sitemaps.org' - don't delete this value
#define CONF_MAX_SITEMAP_FILE_SIZE 10485760
// #define CONF_MAX_SITEMAP_URLS 50000 // by standard of 'sitemaps.org' - don't delete this value
#define CONF_MAX_SITEMAP_URLS 10000
#define MD5LEN 32
#define INET4_ADDRSTRLEN 16
#define INET6_ADDRSTRLEN 46

// Note that in some environments, just asking for
// "char buffer[MAX_DOC_LEN]" may silently fail
// use malloc() and assert() instead

// IT'S NOT ENOUGH TO MODIFY THE FOLLOWING TYPEDEFS HERE
// YOU HAVE TO MODIFY THEM ALSO IN SOME PARTS OF THE CODE
// (ie: printf "%l", atol())

#define internal_long_int_t long int
#define internal_long_uint_t unsigned long int
#define internal_long_double_t long double

// WARNING:
// For technical reasons, IDs cannot have values major of (it's theoretical max value - CONF_HASH_RESERVE)
// TODO insert checks inside 'cbot-reset'

// this doc types MUST BE unsigned
#define instance_t	unsigned char
#define siteid_t	unsigned int // unsigned long int // Note: siteid_t is used also for domains id
#define	docid_t		unsigned int // unsigned long int
#define wordid_t	unsigned int // unsigned long int
#define stemid_t	unsigned int // unsigned long int
#define gramid_t	unsigned int // unsigned long int
#define entityid_t	unsigned int

// Experimental
#define CONF_MAX_TWOLEVELDOMAINID 3221225472

// This has to be twice as more big than ((CONF_COLLECTION_MAX_DOC * CONF_COLLECTION_DISTRIBUTED) + CONF_DOC_HASH_RESERVE) if we are expecting
// to use all the addressable space of ((CONF_COLLECTION_MAX_DOC * CONF_COLLECTION_DISTRIBUTED) + CONF_DOC_HASH_RESERVE)
// This has to be twice as more big than (CONF_COLLECTION_MAX_DOC + CONF_DOC_HASH_RESERVE) if we are expecting		// single instance
// to use all the addressable space of (CONF_COLLECTION_MAX_DOC + CONF_DOC_HASH_RESERVE)							// single instance
#define site_hash_t  unsigned int
#define doc_hash_t  unsigned int

// Leaving some hash values for "possibly" next use
#define CONF_DOMAIN_HASH_RESERVE ((unsigned char)(~0))
#define CONF_SITE_HASH_RESERVE ((unsigned char)(~0))
#define CONF_DOC_HASH_RESERVE ((unsigned short)(~0))

// This hash is always definitive if not change the datatypes
#define CONF_HASH_DOMAIN_MAX_DEFINITIVE ((site_hash_t)(~0) - CONF_DOMAIN_HASH_RESERVE)
#define CONF_HASH_SITE_MAX_DEFINITIVE ((site_hash_t)(~0) - CONF_SITE_HASH_RESERVE)
#define CONF_HASH_DOC_MAX_DEFINITIVE ((doc_hash_t)(~0) - CONF_DOC_HASH_RESERVE)

// Create pid files for distributed standalone cooperations daemons.
// Only standalone daemons can remove pid angels but
// only local cbot-progname can create its.
// 0 -> no pid files was created
// 1 -> only cbot-progname's pid file was created on each instance
// 2 -> cbot-progname's pid file and angel's pid file was created on each instance
#define CONF_NFS_ANGELS 0 // enable it only for real works

// Loglevel constants
#define LOGLEVEL_QUIET	0
#define LOGLEVEL_NORMAL	1
#define LOGLEVEL_VERBOSE	2

// Collection typical dir
#define	COLLECTION_RUN			"run" // pid files for threads
#define	COLLECTION_TEXT			"text"
#define	COLLECTION_URL			"url"
#define COLLECTION_METADATA		"metadata"
#define COLLECTION_LINK			"link"
#define COLLECTION_ROBOTS		"robots"
#define COLLECTION_SITELINK		"sitelink"
#define COLLECTION_HARVEST		"harvest"
#define COLLECTION_ANALYSIS		"analysis"
#define COLLECTION_INDEX		"index"
#define COLLECTION_LOG			"log"
#define COLLECTION_SITES		"sites"
#define COLLECTION_DYM			"dym" // word languages association
#define COLLECTION_LANGDATA		"langdata"
#define COLLECTION_CONNDATA		"conndata"
#define COLLECTION_INFIXDATA	"infixed" // this data can be reset only from cbot-connector

// If we have a stable collection with a good age
// we can enable meta doc read/write operation with buffering (testing)
#define META_MAX_BUFFERING_SIZE	131072

#ifdef META_MAX_BUFFERING_SIZE
#define META_MIN_BUFFERING_SIZE 5 // if META_MAX_BUFFERING_SIZE is too small then use default count of 5 structures
#endif

// Cbot external indipendent parser module's socket path
#define SOCK_PATH "/tmp/.cbot_pdfd_%lu_socket"

// ANSI colors (for reporting)
#define RED "[31m"
#define LRE "[1;31m"
#define GRE "[32m"
#define LGR "[1;32m"
#define BRO "[33m"
#define LBR "[1;33m"
#define BLU "[34m"
#define LBL "[1;34m"
#define PUR "[35m"
#define LPU "[1;35m"
#define NOR "[0m"

// Numerical value of Non Blocking Space (multibyte char)
#define NBSP 160

// ASCII abbreviations
#define NUL 0 // Nul Character -> (semplificato per ragioni di leggibilita) dunque sostituirà: '\0'
#define ASCII_NUL  0 // NULL Char
#define ASCII_TB   9 // Orizzontal Tab
#define ASCII_NL  10 // New Line
#define ASCII_CR  13 // Carriage Return
#define ASCII_SP  32 // Space
#define ASCII_EM  33 // Exclamation mark (punto esclamativo)
#define ASCII_DQ  34 // Double quotes
#define ASCII_NU  35 // Number (cancelletto)
#define ASCII_DO  36 // Dollar
#define ASCII_PE  37 // Procenttecken (percentuale)
#define ASCII_AM  38 // Ampersand
#define ASCII_QU  39 // Quote
#define ASCII_AS  42 // Asterisk
#define ASCII_PL  43 // Plus (simbolo più)
#define ASCII_CM  44 // Comma (Virgola)
#define ASCII_HM  45 // Hyphen-minus/Score (simbolo meno)
#define ASCII_DT  46 // Dot (punto)
#define ASCII_SL  47 // Slash
#define ASCII_CO  58 // Double Point
#define ASCII_SC  59 // Semicolon (punto e virgola)
#define ASCII_MI  60 // Minor
#define ASCII_EQ  61 // Equal
#define ASCII_MA  62 // Major
#define ASCII_QM  63 // Question Mark (punto interrogativo)
#define ASCII_AT  64 // At (chiocciola)
#define ASCII_BS  92 // Back slash
#define ASCII_US  95 // UnderScore
#define ASCII_PP 124 // Pipe
#define ASCII_ST 126 // Single Tilde (comunemente chiamata tilde)

// WCHAR abbreviations whith multibyte len equal to 1
#define WCHAR_NUL L'\0' // NULL Char
#define WCHAR_TB L'\t' // Orizzontal Tab
#define WCHAR_NL L'\n' // New Line
#define WCHAR_CR L'\r' // Carriage Return
#define WCHAR_SP L' ' // Space
#define WCHAR_EM L'!' // Exclamation mark (punto esclamativo)
#define WCHAR_DQ L'"' // Double quotes
#define WCHAR_NU L'#' // Number (cancelletto)
#define WCHAR_DO L'$' // Dollar
#define WCHAR_PE L'%' // Procenttecken (percentuale)
#define WCHAR_AM L'&' // Ampersand
#define WCHAR_QU L'\'' // Quote
#define WCHAR_AS L'*' // Asterisk
#define WCHAR_PL L'+' // Plus (simbolo più)
#define WCHAR_CM L',' // Comma (Virgola)
#define WCHAR_HM L'-' // Hyphen-minus/Score (simbolo meno)
#define WCHAR_DT L'.' // Dot (punto)
#define WCHAR_SL L'/' // Slash
#define WCHAR_CO L':' // Double Point
#define WCHAR_SC L';' // Semicolon (punto e virgola)
#define WCHAR_MI L'<' // Minor
#define WCHAR_EQ L'=' // Equal
#define WCHAR_MA L'>' // Major
#define WCHAR_QM L'?' // Question Mark (punto interrogativo)
#define WCHAR_AT L'@' // At (chiocciola)
#define WCHAR_BS L'\\' // Back slash
#define WCHAR_US L'_' // UnderScore
#define WCHAR_PP L'|' // Pipe
#define WCHAR_ST L'~' // Single Tilde (comunemente chiamata tilde)

// Per ottimizzare il funzionamento del parser i caratteri multibyte convertiti provvisoriamente in tipo 'wchar_t' elencati nei define,
// devono poter essere convertiti in caratteri tipo 'char'
#define WCHAR_TO_CHAR(x) (\
    (x==L'\t')          ? '\t' :\
    (x==L'\n')          ? '\n' :\
    (x==L'\r')          ? '\r' :\
    (x==L' ')           ? ' ' :\
    (x==L'!')           ? '!' :\
    (x==L'"')           ? '"' :\
    (x==L'#')           ? '#' :\
    (x==L'$')           ? '$' :\
    (x==L'%')           ? '%' :\
    (x==L'&')           ? '&' :\
    (x==L'\'')          ? '\'' :\
    (x==L'*')           ? '*' :\
    (x==L'+')           ? '+' :\
    (x==L',')           ? ',' :\
    (x==L'-')           ? '-' :\
    (x==L'.')           ? '.' :\
    (x==L'/')           ? '/' :\
    (x==L':')           ? ':' :\
    (x==L';')           ? ';' :\
    (x==L'<')           ? '<' :\
    (x==L'>')           ? '>' :\
    (x==L'@')           ? '@' :\
    (x==L'\\')          ? '\\' :\
    (x==L'_')           ? '_' :\
    (x==L'|')           ? '|' :\
    (x==L'~')           ? '~' : 'Z' )


// parser-extended
// N.B. max 255
// il valore di char può essere al minimo '-127' e al massimo 127 considerando anche il valore 0,
// di conseguenza la differenza massima consentita è 255 (che corrisponde ad unsigned char max 'UCHAR_MAX')!
#define TITLESIZE 255
#define HEADINGSSIZE 255
#define DESCSIZE 255 // lunghezza massima contenuto meta tag description
#define KEYWSIZE 128 //const short KEYWSIZE = 80; // lunghezza massima contenuto meta tag keywords (si includono solo le chiavi che dovrebbero avere più importanza)
#define LMONSIZE 32 // lunghezza massima contenuto meta tag personalizzato 'cbotlocmon' per indicare uso monete locali com 'sardex' 

#define HTMLMETAPREFIXSIZE 4 // number of char prefix
#define PDFMETAPREFIXSIZE 4 // number of char prefix

#ifndef CONLOCK
#define CONLOCK 1
#define conlock pthread_mutex_lock(console_lock);
#define cunlock { *symshown = true; pthread_mutex_unlock(console_lock); }
#define mcout { pthread_mutex_lock(console_lock); if (*symshown == true) { std::cout << endl; } std::cout
#define mcerr { pthread_mutex_lock(console_lock); if (*symshown == true) { std::cerr << endl; } std::cerr
#define mclog { pthread_mutex_lock(console_lock); if (*symshown == true) { std::clog << endl; } std::clog
#define mendl std::endl; *symshown = false; pthread_mutex_unlock(console_lock); }
#define ccout if (sp->go_ahead(inst) == true) cout
#define ccerr if (sp->go_ahead(inst) == true) cerr
#define cclog if (sp->go_ahead(inst) == true) clog
#endif

// distribute load on each core and isolate threads
#define CPU_OPTIMIZE \
	if (inst < CONF_COLLECTION_DISTRIBUTED) { \
	CPU_ZERO(&system_cpus); \
	CPU_SET((int)inst, &system_cpus); \
	sched_setaffinity(0, sizeof(cpu_set_t), &system_cpus); \
	assert(inst == (instance_t)sched_getcpu()); }

typedef struct {
    time_t last_ranking;
    uint8_t unused[200];
} crawler_stats_t;

typedef struct // parser-extended struct
{
	enum lmon_t : uint8_t {
		SARDEX = 0,
		NO_LOCAL_MONETARY
	};

	char title[TITLESIZE + 1]; // 256
	char headings[HEADINGSSIZE + 1]; // 256
	char metadesc[DESCSIZE + 1]; // 256
	char metakeyw[KEYWSIZE + 1]; // 129
	lmon_t metalmon;
	char *content;
} pes_t;

// Type for protocol
enum protocols_t : uint8_t {
	HTTP                            = 0,
	HTTPS                           = 1,
	HTTP_TEMPORARY                  = 2,
	HTTPS_TEMPORARY                 = 3,
	NOT_DEFINED                     = 4
};

enum thread_alarm_t : uint8_t {
	THREADS_OK = 0,
	THREADS_STOP = 1,
	THREADS_STOP_ONERR = 2
};

enum robots_txt_rule_t : unsigned char {
	ROBOTS_ALLOW = 'a',
	ROBOTS_DISALLOW = 'd',
	ROBOTS_UNKNOWN
};

#define ROBOT_TXT_RULE_STR(x) (\
        (x==ROBOTS_ALLOW)               ? "Allow" :\
        (x==ROBOTS_DISALLOW)            ? "Disallow" : "(undefined)" )

// Collection typical dir

#endif
