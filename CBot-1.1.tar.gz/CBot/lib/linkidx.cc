/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "linkidx.h"

//
// Name: thread_function_caller
//
// Description:
//   A proxy function to pass non-static function at pthread_create
//   Note: function called by thread_function_caller need to have real class object passed through args
//
// Input:
//   args - void arguments
//
// Return:
//   pointer to void
//

void* Doclink::thread_function_caller(void *args)
{
	assert(args);

	Doclink::thread_args_t *arguments = (Doclink::thread_args_t *)args;

try
{
	Doclink *newObj = NULL;

	try
	{
		newObj = new Doclink (NULL, true); // Note function called work to 'this' temporary object and need to be deleted at the end of the same.
	}
	catch (std::bad_alloc& ba)
	{
		die("thread_function_caller bad_alloc caught: %s", ba.what());

		return NULL;
	}

	switch (arguments->f)
	{
		case DOCLINK_ANALYSIS_DOCRANK:
			newObj->thread_function_analysis_docrank(args);
			break;
		default:
			break;
	}

	delete newObj;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(arguments->obj->barrier); 
}

	// Each thread must exit with 'pthread_barrier_wait'
	// in normal condition
	if (arguments->obj->barrier)
	{
		int rc = pthread_barrier_wait(arguments->obj->barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	free(args);
	args = NULL;

	return NULL;
}

// threads sync
void Doclink::sync_threads(pthread_barrier_t *barrier)
{
	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		int rc = pthread_barrier_wait(barrier);

		assert ((rc == 0) || (rc == PTHREAD_BARRIER_SERIAL_THREAD));
	}

	if (thread_alarm != THREADS_OK)
		pthread_exit(NULL);
}

//
// Name: idx_connect
//
// Description:
//   check link index in a directory
//
// Input:
//
// Return:
//   true if storage exist
//

void Doclink::idx_connect(Storage *_lidx)
{
	assert(_lidx != NULL);

	lidx = _lidx;
}

//
// Name: linkidx_open
//
// Description:
//   opens or creates a link index in a directory
//
// Input:
//   dirname - name of the directory to be created
//
// Return:
//   the structure
//

Storage *linkidx_open(const char *dirname, bool readonly)
{
	if (thread_alarm != THREADS_OK)
		return NULL;

    // Check if there is all main files in storage
	bool storage_found = true;
	char filename[MAX_STR_LEN];

	Storage *lidx = NULL;

try
{
	for (unsigned int i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		// Copy directory name
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, i);
		assert(strlen(relative_rem_path) < MAX_STR_LEN);

        // Open the main files
		sprintf(filename, "%s/%s", relative_rem_path, STORAGE_FILENAME_MAIN);
		free(relative_rem_path);

		FILE *file_main = fopen64(filename, "r");

		if (file_main == NULL)
		{
			storage_found = false;
			break;
		}
		else
			fclose(file_main);
	}

	if (storage_found == false && readonly == true)
			die("Can't create linkidx in readonly mode");

	lidx = new Storage (dirname, readonly);

	if (lidx == NULL)
        die("Can't open linkidx");
}
catch (CBotExitException eex)
{
	CBotException *ex = eex.Exception();

	cerr << RED << "Exception: " << ex->what() << NOR << endl;

	delete ex;

	return NULL;
}

	if (storage_found == false)
		lidx->st_create();
	else
		lidx->st_open();

	// Returns
	return lidx;
}

//
// Name: linkidx_store
//
// Description:
//   Stores the links of a document
//
// Input:
//   linkidx - the structure
//   src - source of the link
//   dest[] - destinations of the link
//   outdegree - number of destinations
//
// Return:
//   status
//

linkidx_status_t linkidx_store(Storage *lidx, docid_t src_docid, out_link_t dest[], unsigned int out_degree)
{
	// We don't check the count to be less than LINK_MAX_OUTDEGREE,
	// as in some cases we will not be bound to this limit.
	// However, to use the link analysis functions for pagerank and
	// the link dumper, it is necessary to respect the limit.

	// Check the links before storing
	for (unsigned int i = 0; i < out_degree; i++)
	{
		if (dest[i].dest >= (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED))
		{
			cerr << "[linkidx: destination #" << i << " docid=" << dest[i].dest << " is larger than " << (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED) << endl;
			return LINKIDX_ERROR;
		}
	}

	instance_t inst = ((src_docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = (((src_docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// Write
	storage_status_t rc = lidx->st_idx_write(inst, id_offset, (char *)(dest), (sizeof(out_link_t)*out_degree));
	assert(rc == STORAGE_OK);

	return LINKIDX_OK;
}

//
// Name: linkidx_prepare_sequential_read
//
// Description:
//   Prepares the links file for sequential reading
//
// Input:
//   linkidx - the structure
//

void linkidx_prepare_sequential_read(Storage *lidx, instance_t &inst)
{
	lidx->prepare_sequential_read(inst);
}

// 
// Name: linkidx_retrieve_using_buffer
// 
// Description:
//   Retrieves the links of a document
//
// Input:
//   linkidx - the structure
//
// Output:
//   dest[] - destinations of links
//   outdegree - out degree
//
// Return:
//   status
// 


linkidx_status_t linkidx_retrieve_using_buffer(Storage *lidx, instance_t inst, char *buffer, docid_t src_docid, out_link_t dest[], unsigned int *out_degree)
{
	docid_t id_offset = (((src_docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// Read
	off64_t bytes;
	storage_status_t rc = lidx->st_idx_read(inst, id_offset, buffer, bytes);

	if ((rc == STORAGE_OK) && (bytes > 0))
	{
		// Get out_degree
		*out_degree = bytes/sizeof(out_link_t);

		memcpy(dest, buffer, bytes);

	}
	else *out_degree = 0; // No links

	// Return
	return LINKIDX_OK;
}

linkidx_status_t linkidx_retrieve(Storage *lidx, instance_t inst, docid_t src_docid, out_link_t dest[], unsigned int *out_degree)
{
	// Buffer
	char buffer[(sizeof(out_link_t) * LINK_MAX_OUTDEGREE) + 1];

	return linkidx_retrieve_using_buffer(lidx, inst, buffer, src_docid, dest, out_degree);
}


//
// Name: linkidx_show_links
//
// Description: 
//   Shows the links of a document
//

void linkidx_show_links(Storage *lidx, docid_t src_docid)
{
	// Report
	cout << "Doclinks for docid " << src_docid << " : ";

	// Get links
	out_link_t dest[LINK_MAX_OUTDEGREE];

	instance_t inst = ((src_docid - 1) % CONF_COLLECTION_DISTRIBUTED);

	unsigned int out_degree;

	linkidx_retrieve(lidx, inst, src_docid, dest, &(out_degree));

	// Show
	if (out_degree == 0)
		cout << "none." << endl;
	else
	{
	    cout << endl << "DESTID\tREL_POS\tTAG\tANCHOR_LENGTH" << endl;

		for (unsigned int i = 0; i < out_degree; i++)
				cout << dest[i].dest << "\t" << (int)dest[i].rel_pos << "\t" << (int)dest[i].tag << "\t" << (int)dest[i].anchor_length << endl;
	}
}

//
// Name: linkidx_dump_links
//
// Description: 
//   Dumps the links of a document, for analysis (in 1 line)
//

void linkidx_dump_links(Storage *lidx, docid_t src_docid)
{
	// Report
	cout << src_docid;

	// Get links
	out_link_t dest[LINK_MAX_OUTDEGREE];

	instance_t inst = ((src_docid - 1) % CONF_COLLECTION_DISTRIBUTED);

	unsigned int out_degree;

	linkidx_retrieve(lidx, inst, src_docid, dest, &(out_degree));

	// Show
	if (out_degree > 0)
		for (unsigned int i=0; i<out_degree; i++)
			cout << " " << dest[i].dest;

	cout << endl;
}

//
// Name: linkidx_dump_links_checking
//
// Description: 
//   Dumps the links of a document, for analysis (in 1 line)
//   receives an input with the docs it must show
//
// Input:
//   linkidx - the structure
//   docid - the source docid for the links
//   ok - a char array containing NULL for the documents that should not be shown
//

void linkidx_dump_links_checking(Storage *lidx, docid_t src_docid, char *ok)
{
	assert(ok[src_docid] != '\0');

	// Report
	cout << src_docid;

	// Get links
	out_link_t dest[LINK_MAX_OUTDEGREE];

	instance_t inst = ((src_docid - 1) % CONF_COLLECTION_DISTRIBUTED);

	unsigned int out_degree;

	linkidx_retrieve(lidx, inst, src_docid, dest, &(out_degree));

	// Show
	if (out_degree > 0)
	{
		for (unsigned int i=0; i<out_degree; i++)
			if (ok[dest[i].dest] != '\0')
				cout << " " << dest[i].dest;
	}

	cout << endl;
}

//
// Name: linkidx_dump_links_with_url
//
// Description: 
//   Dumps the links of a document; includes destination urls
//
// Input:
//   linkidx - the link index
//   url - class of urls
//   src_docid - the original docid
//

void linkidx_dump_links_with_url(Storage *lidx, Url *url, docid_t src_docid)
{
	assert(lidx != NULL);
	assert(url != NULL);
	assert(src_docid > 0);

	char _url[MAX_STR_LEN]	= "";
	url->url_by_docid(src_docid, _url);

	// Report
	cout << "Doclinks from " << src_docid << " " << _url << endl;

	// Get links
	out_link_t dest[LINK_MAX_OUTDEGREE];

	instance_t inst = ((src_docid - 1) % CONF_COLLECTION_DISTRIBUTED);

	unsigned int out_degree;

	linkidx_retrieve(lidx, inst, src_docid, dest, &(out_degree));

	// Show
	if (out_degree > 0)
	{
		for (unsigned int i = 0; i < out_degree; i++)
		{
			url->url_by_docid(dest[i].dest, _url);

			cout << "- " << dest[i].dest << " " << _url << " " << TAG_STR(dest[i].tag) << endl;
		}
	}

	if (out_degree == 0)
		cout << "No links" << endl;
	else
		cout << "Total: " << out_degree << " links" << endl;

	cout << endl;
}

// 
// Name: analysis_docrank
//
// Description:
//   Calculates the link-based statistics for all the documents
//
// Input:
//   meta - the metaddx structure to write data
//   url - the urlddx where get url information
//   strg - the storage needed for calculating liverank
//   lidx - the storage where out links are found
//   opt_calc_pagerank, opt_calc_wlrank, opt_calc_hits, opt_calc_liverank - bool value to indicate witch link scores to analyze
//   linearize -
//     true  = set the values of the score uniformily between 0 and 1
//     false = save the actual values - deprecated -
//
//   opt_fix_depths - recovery depths of all documents
//   opt_mark_dynamic - mark dynamic/static status of all documents
//   opt_mark_ignored - mark ignored documents with too high depth or
//                      document when are too many for site - at moment not supported -
//
// Output:
//   file containing link structure between sites is created
//   metadata of sites is updated to reflect internal and external links
//
void Doclink::analysis_docrank(Meta *meta, Url *url, Storage *strg, Storage *lidx, bool opt_calc_pagerank, bool opt_calc_wlrank, bool opt_calc_hits, bool opt_calc_liverank, bool opt_linearize, bool opt_fix_depths, bool opt_mark_dynamic, bool opt_mark_ignored)
{
	if (thread_alarm != THREADS_OK)
		return;

	//assert(dirname != NULL);
	assert(readonly == false);
	assert(meta != NULL);
	assert(strg != NULL);

	// Check if we were actually requested something
	assert(opt_calc_pagerank || opt_calc_wlrank || opt_calc_hits || opt_calc_liverank || opt_fix_depths || opt_mark_dynamic || opt_mark_ignored);

	int rc = 0;
    pthread_mutexattr_t attr;

	if (nsites == 0)
	{
		nsites	= meta->site_count();
		assert(nsites > 0);
	}

	if (ndocs == 0)
	{
		ndocs	= meta->doc_count();
		assert(ndocs > 0);
	}

	// Declare vectors for analysis
	in_degree = CBALLOC(docid_t, CALLOC, (ndocs + 1));
	out_degree = CBALLOC(docid_t, CALLOC, (ndocs + 1));
	in_degree_external = CBALLOC(docid_t, CALLOC, (ndocs + 1)); 
	out_degree_external = CBALLOC(docid_t, CALLOC, (ndocs + 1));;
	site_out_degree_external = CBALLOC(site_out_degree_t, CALLOC, (nsites + 1));;

	domainsid = CBALLOC(domains_t, MALLOC, (ndocs + 1));

	// Ask memory for pagerank calculation, only if necessary
	if (opt_calc_pagerank)
	{
		pagerank = CBALLOC(pagerank_t, MALLOC, (ndocs + 1));
		pagerankTmp = CBALLOC(pagerank_t, MALLOC, (ndocs + 1));
	}

	// Ask memory for wlrank, only if necessary
	if (opt_calc_wlrank)
	{
		sum_out_weight = CBALLOC(linkweight_t, MALLOC, (ndocs + 1));
		wlrank = CBALLOC(wlrank_t, MALLOC, (ndocs + 1));
		wlrankTmp = CBALLOC(wlrank_t, MALLOC, (ndocs + 1));
	}

	// Ask memory for hubs and authorities, only if necessary
	if (opt_calc_hits)
	{
		hub = CBALLOC(hubrank_t, MALLOC, (ndocs + 1));
		hubTmp = CBALLOC(hubrank_t, MALLOC, (ndocs + 1));
		auth = CBALLOC(authrank_t, MALLOC, (ndocs + 1));
		authTmp = CBALLOC(authrank_t, MALLOC, (ndocs + 1));
	}

	// Ask memory for liverank, only if necessary
	if (opt_calc_liverank)
	{	
		liverank = CBALLOC(liverank_t, MALLOC, (ndocs + 1));
	//	liverankTmp = CBALLOC(liverank_t, MALLOC, (ndocs + 1));
		last_sketch_gap = CBALLOC(unsigned char, MALLOC, (ndocs + 1));
	}

	cerr << GRE << "Link analysis will calculate:" \
		<< (opt_calc_pagerank	? " Pagerank" : "") \
		<< (opt_calc_wlrank ? " Cbotscore" : "") \
		<< (opt_calc_hits ? " Hits" : "") \
		<< (opt_calc_liverank ? " Liverank" : "") \
		<< (opt_fix_depths ? " Fix depths" : "") \
		<< (opt_mark_dynamic ? " Mark dynamic" : "") \
		<< (opt_mark_ignored ? " Mark ignored" : "")  << NOR << endl;

	// Ask memory for ignored documents
	is_ignored = CBALLOC(bool, MALLOC, (ndocs + 1));
	ndocs_active = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	max_gap = CBALLOC(unsigned char, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	max_liverank = CBALLOC(liverank_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	slocks = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
	dlocks = CBALLOC(pthread_mutex_t, MALLOC, (CONF_COLLECTION_DISTRIBUTED + 1));
	sum_pageranks = CBALLOC(pagerank_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	sum_wlranks = CBALLOC(wlrank_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	sum_hubs = CBALLOC(hubrank_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	sum_auths = CBALLOC(authrank_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	pagerank_delta = CBALLOC(double, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	wlrank_delta = CBALLOC(double, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	hub_delta = CBALLOC(double, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	auth_delta = CBALLOC(double, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	hub_gt_zero = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
	auth_gt_zero = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	// Ask memory for fixing depths
	if (opt_fix_depths) // Depth=-1 => Depth undefined
	{
		depth = CBALLOC(depth_t, MALLOC, (ndocs + 1));
		count_depth_undefined = CBALLOC(docid_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);
		nmarked = CBALLOC(atomic<docid_t>, CALLOC, nmarked_size);
	}

	perfhash_t *extensions_dynamic = NULL;;

	// Prepare list of dynamic extensions
	if (opt_mark_dynamic)
	{
		extensions_dynamic = new perfhash_t;
		extensions_dynamic->check_matches = true;
		perfhash_create(extensions_dynamic, CONF_SEEDER_LINK_DYNAMIC_EXTENSION);
	}

	atomic<docid_t> ndocs_marked_static_dynamic((docid_t)0);
	atomic<docid_t> ndocs_marked_dynamic_static ((docid_t)0);
	atomic<docid_t> ndocs_marked_depth_static ((docid_t)0);
	atomic<docid_t> ndocs_marked_depth_dynamic ((docid_t)0);
	atomic<docid_t> ndocs_marked_too_many ((docid_t)0);

	cerr << "Preparing |--------------------------------------------------|" << endl << "           ";

/*
	// WARNING: linearize can be applied only if siterank_t is double type
	if (linearize == true)
	{
		siterank[0] = 0;
		linearize_order[0] = &siterank[0];
		// Note: we move offset ahead to one because siteid == 0 DO NOT EXIST
		const siterank_t skip_count = 1;
		sortr = new CBotSort<siterank_t, siteid_t> (siterank, linearize_order, nsites, skip_count);
		sortr->barrier_init();
	}
*/
	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			slocks[i] = PTHREAD_MUTEX_INITIALIZER;

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			dlocks[i] = PTHREAD_MUTEX_INITIALIZER;

		barrier = CBALLOC(pthread_barrier_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

		pthread_barrier_init(barrier, NULL, CONF_COLLECTION_DISTRIBUTED);

		if ((rc = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK)) != 0)
			die("error setting mutex type %s", CBoterr(rc));

        if ((rc = pthread_mutexattr_init(&attr)) != 0)
			die("error creating mutex with attributes object %s", CBoterr(rc));
	}

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Doclink::thread_args_t *args = CBALLOC(Doclink::thread_args_t, MALLOC, 1);
	    args->inst = inst;
		args->obj = this;
		args->f = DOCLINK_ANALYSIS_DOCRANK;
		args->meta = meta;
		args->url = url;
		args->strg = strg;
		args->lidx = lidx;
		args->extensions_dynamic = extensions_dynamic;
		args->opt_calc_pagerank = opt_calc_pagerank;
		args->opt_calc_wlrank = opt_calc_wlrank;
		args->opt_calc_hits = opt_calc_hits;
		args->opt_calc_liverank = opt_calc_liverank;
		args->opt_linearize = opt_linearize;
		args->opt_fix_depths = opt_fix_depths;
		args->opt_mark_dynamic = opt_mark_dynamic;
		args->opt_mark_ignored = opt_mark_ignored;
		args->ndocs_marked_dynamic_static = &ndocs_marked_dynamic_static;
		args->ndocs_marked_static_dynamic = &ndocs_marked_static_dynamic;
		args->ndocs_marked_depth_static = &ndocs_marked_depth_static;
		args->ndocs_marked_depth_dynamic = &ndocs_marked_depth_dynamic;
		args->ndocs_marked_too_many = &ndocs_marked_too_many;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_analysis_docrank((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			if ((rc = pthread_mutex_destroy(&slocks[i])) != 0)
				die("error destroying slocks mutexes %s", CBoterr(rc));

		free(slocks);

		for (internal_long_uint_t i = 0; i <= CONF_COLLECTION_DISTRIBUTED; i++)
			if ((rc = pthread_mutex_destroy(&dlocks[i])) != 0)
				die("error destroying dlocks mutexes %s", CBoterr(rc));

		free(dlocks);

		free(threads);

		pthread_barrier_destroy(barrier);

		free(barrier); barrier = NULL;

		if ((rc = pthread_mutexattr_destroy(&(attr))) != 0)
			die("error destroying mutex with attributes object %s", CBoterr(rc));
	}

	if (opt_mark_dynamic == true)
	{
		perfhash_destroy(extensions_dynamic);
		delete extensions_dynamic;
	}

	if (opt_fix_depths)
	{
		free(count_depth_undefined);
		free(nmarked);
		free(depth);
	}

	free(auth_gt_zero);
	free(hub_gt_zero);
	free(auth_delta);
	free(hub_delta);
	free(wlrank_delta);
	free(pagerank_delta);
	free(sum_auths);
	free(sum_hubs);
	free(sum_wlranks);
	free(sum_pageranks);
	free(max_liverank);
	free(max_gap);
	free(ndocs_active);
	free(is_ignored);

	if (opt_linearize == false)
	{
		if (opt_calc_liverank)
		{
			free(last_sketch_gap);
//			if (liverankTmp != NULL) free(liverankTmp);
			free(liverank);
		}

		if (opt_calc_hits)
		{
			if (authTmp != NULL) free(authTmp);
			free(auth);
			if (hubTmp != NULL)	free(hubTmp);
			free(hub);
		}

		if (opt_calc_wlrank)
		{
			if (wlrankTmp != NULL) free(wlrankTmp);
			free(wlrank);
			if (sum_out_weight != NULL) free(sum_out_weight);
			sum_out_weight = NULL;
		}

		if (opt_calc_pagerank)
		{
			if (pagerankTmp != NULL) free(pagerankTmp);
			free(pagerank);
		}
	}
	else
	{
		if (opt_calc_liverank)
		{
			free(last_sketch_gap);
//			if (liverankTmp != NULL) free(liverankTmp);
			free(liverank);
		}

		if (opt_calc_hits)
		{
			if (authTmp != NULL) free(authTmp);
			free(auth);
			if (hubTmp != NULL)	free(hubTmp);
			free(hub);
		}

		if (opt_calc_wlrank)
		{
			if (wlrankTmp != NULL) free(wlrankTmp);
			free(wlrank);
			if (sum_out_weight != NULL) free(sum_out_weight);
			sum_out_weight = NULL;
		}

		if (opt_calc_pagerank)
		{
			if (pagerankTmp != NULL) free(pagerankTmp);
			free(pagerank);
		}
	}

	free(site_out_degree_external);
	free(out_degree_external);
	free(in_degree_external);
	free(out_degree);
	free(in_degree);
	free(domainsid);
}

//
// Name: thread_function_analysis_docrank
//
// Description:
//   Calculates the link-based statistics for all the documents
//
// Input: pointer to void
//
// Returns:
//
void *Doclink::thread_function_analysis_docrank(void *args)
{
	cpu_set_t system_cpus;

	Doclink::thread_args_t *arguments = (Doclink::thread_args_t *)args;

    instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

    Doclink *obj = arguments->obj;
    Meta *meta = arguments->meta;
   	Storage *strg = arguments->strg;
   	Storage *lidx = arguments->lidx;
   	Url *url = arguments->url;
	perfhash_t *extensions_dynamic = arguments->extensions_dynamic;
	bool opt_calc_pagerank = arguments->opt_calc_pagerank;
	bool opt_calc_wlrank = arguments->opt_calc_wlrank;
	bool opt_calc_hits = arguments->opt_calc_hits;
	bool opt_calc_liverank = arguments->opt_calc_liverank;
	bool opt_linearize = arguments->opt_linearize;
	bool opt_fix_depths = arguments->opt_fix_depths;
	bool opt_mark_dynamic = arguments->opt_mark_dynamic;
	bool opt_mark_ignored = arguments->opt_mark_ignored;
	atomic<docid_t> *ndocs_marked_dynamic_static = arguments->ndocs_marked_dynamic_static;
	atomic<docid_t> *ndocs_marked_static_dynamic = arguments->ndocs_marked_static_dynamic;
	atomic<docid_t> *ndocs_marked_depth_static = arguments->ndocs_marked_depth_static;
	atomic<docid_t> *ndocs_marked_depth_dynamic = arguments->ndocs_marked_depth_dynamic;
	atomic<docid_t>	*ndocs_marked_too_many = arguments->ndocs_marked_too_many;

	docid_t ndocs_div_50 = (ndocs/50);
	docid_t nsites_div_50 = (nsites/50);

	// Find Max Sketch Gap for apply linearization
	if (opt_calc_liverank == true)
	{
		for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
		{
			if (ndocs_div_50 > 0 && (docid % ndocs_div_50) == 0)
				cerr << ".";

			if (docid < strg->docid_count())
			{
				unsigned char gap = 0;
				strg->read_sketch_gap(docid, &gap);

				obj->last_sketch_gap[docid] = gap;

				if (gap > obj->max_gap[inst])
					obj->max_gap[inst] = gap;
			}
			else
				obj->last_sketch_gap[docid] = 0;

			obj->liverank[docid] = 0;
		}
	}

	sync_threads(obj->barrier);


	unsigned char _max_gap = 0;

    for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
        if (obj->max_gap[i] > _max_gap)
			_max_gap = obj->max_gap[i];
	}

	ccerr << "done." << endl << "Importing some data from sites |--------------------------------------------------|" << endl << "                                ";

	sync_threads(obj->barrier);


	site_t site;

	// Iterate to populate with count_site site_out_degree_external
#ifndef META_MAX_BUFFERING_SIZE
	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		internal_long_uint_t expected = (siteid / 10) * 10;
		internal_long_uint_t next = expected + 10;

		if (nsites_div_50 > 0 && (siteid % nsites_div_50 == 0) && this->print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
			cerr << ".";

		site.siteid	= siteid;
		meta->site_retrieve(&(site));
		assert(site.siteid == siteid);

		// Setting counter of all document for site
		if (meta->site_option_get(siteid, SITE_OPT_DENY, false) == METADDX_OK)
		{
			obj->site_out_degree_external[siteid].count = site.count_doc;
			obj->site_out_degree_external[siteid].out_link = (docid_t)0;
		}
	}
#else
	size_t size = (META_MAX_BUFFERING_SIZE > sizeof(site_t)) ? (META_MAX_BUFFERING_SIZE / sizeof(site_t)) : META_MIN_BUFFERING_SIZE;

	site_t *sites = CBALLOC(site_t, MALLOC, size);

	size_t o = 0;

	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		internal_long_uint_t expected = (siteid / 10) * 10;
		internal_long_uint_t next = expected + 10;

		if (nsites_div_50 > 0 && (siteid % nsites_div_50 == 0) && this->print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
			cerr << ".";

		sites[o].siteid = siteid;
		o++;

		if (o == size)
		{
			if (o > 1)
				assert(meta->site_retrieve_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_retrieve(&sites[0]) == METADDX_OK);

			for (size_t i = 0; i < o; i++)
			{
				assert(sites[i].siteid > 0);

				// Setting counter of all document for site
				if (meta->site_option_get(sites[i].siteid, SITE_OPT_DENY, false) == METADDX_OK)
				{
					obj->site_out_degree_external[sites[i].siteid].count = sites[i].count_doc;
					obj->site_out_degree_external[sites[i].siteid].out_link = (docid_t)0;
				}
			}

			o = 0;
		}
		else if ((siteid + CONF_COLLECTION_DISTRIBUTED) > obj->nsites)
		{
			if (o > 1)
				assert(meta->site_retrieve_buffered(sites, o) == METADDX_OK);
			else if (o > 0)
				assert(meta->site_retrieve(&sites[0]) == METADDX_OK);

			for (size_t i = 0; i < o; i++)
			{
				assert(sites[i].siteid > 0);

				// Setting counter of all document for site
				if (meta->site_option_get(sites[i].siteid, SITE_OPT_DENY, false) == METADDX_OK)
				{
					obj->site_out_degree_external[sites[i].siteid].count = sites[i].count_doc;
					obj->site_out_degree_external[sites[i].siteid].out_link = (docid_t)0;
				}
			}

			o = 0;
		}
	}

	free(sites);
#endif

	sync_threads(obj->barrier);


	doc_t doc;
	liverank_t _max_liverank = (liverank_t)0;

	// Iterate to check for ignored documents to keep a list of its
#ifndef META_MAX_BUFFERING_SIZE
	for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
	{
		internal_long_uint_t expected = (docid / 10) * 10;
		internal_long_uint_t next = expected + 10;

		// Report
		if (ndocs_div_50 > 0 && (docid % ndocs_div_50 == 0) && this->print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale

		doc.docid	= docid;
		meta->doc_retrieve(&(doc));
		assert(doc.docid == docid);

		// This is used when we want to mark some documents
		// as ignored in the collection
		if ((HTTP_IS_OK(doc.http_status) || HTTP_IS_REDIRECT(doc.http_status)))
		{
			obj->is_ignored[docid] = false;
			obj->ndocs_active[inst]++;
		}
		else
			obj->is_ignored[docid] = true;

		// We read siteids and domainids for applying the heuristic of
		// discarding internal links (inside the same host) and links of same second level domain
		obj->domainsid[docid].siteid = doc.siteid;
		obj->domainsid[docid].domainid = doc.domainid;

		// somma alla media del liverank l'ultimo sketch gap
		// N.B. '(last_sketch_gap[docid] / max_gap)' permette di ottenere il massimo liverank sempre uguale ad uno
		if (obj->is_ignored[docid] == false && opt_calc_liverank == true && docid < strg->docid_count())
		{
			bool is_robot = false;
			bool is_feed = false;

			if (doc.mime_type == MIME_ROBOTS_TXT)
				is_robot = true;
			else if (doc.mime_type == MIME_ROBOTS_RDF)
				is_robot = true;
			else if (doc.mime_type == MIME_ROBOTS_XML || doc.mime_type == MIME_ROBOTS_XML_GZ)
				is_robot = true;
			else if (doc.mime_type == MIME_FEEDS_ATOM_XML || doc.mime_type == MIME_FEEDS_ATOM_XML_GZ)
				is_feed = true;
			else if (doc.mime_type == MIME_FEEDS_RSS_XML || doc.mime_type == MIME_FEEDS_RSS_XML_GZ)
				is_feed = true;

			// going ahead in time liverank decrease if page are not update
			if (is_robot == false && is_feed == false)
			{
				unsigned int dnvc = CONF_MANAGER_SCORE_LIVERANK_STARTING_VISITS + doc.number_visits;

				if (doc.liverank == 0)
					doc.liverank = 1;

				if (_max_gap > 0)
				{
						if (obj->last_sketch_gap[docid] > 0)
							obj->liverank[docid] = (((liverank_t)(dnvc - 1) / dnvc) * doc.liverank + (((liverank_t)obj->last_sketch_gap[docid] / _max_gap) / dnvc));
						else
							obj->liverank[docid] = (((liverank_t)(dnvc - 1) / dnvc) * doc.liverank);
				}
				else
					obj->liverank[docid] = (((liverank_t)(dnvc - 1) / dnvc) * doc.liverank);
			}

			if (obj->liverank[docid] > obj->max_liverank[inst])
				obj->max_liverank[inst] = obj->liverank[docid];
		}
	}
#else
	size = (META_MAX_BUFFERING_SIZE > sizeof(doc_t)) ? (META_MAX_BUFFERING_SIZE / sizeof(doc_t)) : META_MIN_BUFFERING_SIZE;

	doc_t *docs = CBALLOC(doc_t, MALLOC, size);

	o = 0;

	for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
	{
		docid_t expected = (docid / 10) * 10;
		docid_t next = expected + 10;

		docs[o].docid = docid;
		o++;

		if (o > 1)
			assert(meta->doc_retrieve_buffered(docs, o) == METADDX_OK);
		else if (o > 0)
			assert(meta->doc_retrieve(&docs[0]) == METADDX_OK);


		for (size_t i = 0; i < o; i++)
		{
			assert(docs[i].docid > 0);

			// This is used when we want to mark some documents
			// as ignored in the collection
			if ((HTTP_IS_OK(docs[i].http_status) || HTTP_IS_REDIRECT(docs[i].http_status)))
			{
				// Ranking must work with supported document mime type
				if (docs[i].mime_type == MIME_TEXT_HTML || 
					docs[i].mime_type == MIME_TEXT || 
					docs[i].mime_type == MIME_APPLICATION_PDF) 
				{
					obj->is_ignored[docs[i].docid] = false;
					obj->ndocs_active[inst]++;
				}
				else
					obj->is_ignored[docs[i].docid] = true;
			}
			else
				obj->is_ignored[docs[i].docid] = true;

			// We read siteids and domainids for applying the heuristic of
			// discarding internal links (inside the same host) and links of same second level domain
			obj->domainsid[docs[i].docid].siteid = docs[i].siteid;
			obj->domainsid[docs[i].docid].domainid = docs[i].domainid;

			// somma alla media del liverank l'ultimo sketch gap
			// N.B. '(last_sketch_gap[docs[i].docid] / max_gap)' permette di ottenere il massimo liverank sempre uguale ad uno
			if (obj->is_ignored[docs[i].docid] == false && opt_calc_liverank == true && docs[i].docid < strg->docid_count())
			{
				bool is_robot = false;
				bool is_feed = false;

				if (docs[i].mime_type == MIME_ROBOTS_TXT)
					is_robot = true;
				else if (docs[i].mime_type == MIME_ROBOTS_RDF)
					is_robot = true;
				else if (docs[i].mime_type == MIME_ROBOTS_XML || docs[i].mime_type == MIME_ROBOTS_XML_GZ)
					is_robot = true;
				else if (docs[i].mime_type == MIME_FEEDS_ATOM_XML || docs[i].mime_type == MIME_FEEDS_ATOM_XML_GZ)
					is_feed = true;
				else if (docs[i].mime_type == MIME_FEEDS_RSS_XML || docs[i].mime_type == MIME_FEEDS_RSS_XML_GZ)
					is_feed = true;

				// going ahead in time liverank decrease if page are not update
				if (is_robot == false && is_feed == false)
				{
					unsigned int dnvc = CONF_MANAGER_SCORE_LIVERANK_STARTING_VISITS + docs[i].number_visits;

					if (docs[i].liverank == 0)
						docs[i].liverank = 1;

					if (_max_gap > 0)
					{
							if (obj->last_sketch_gap[docs[i].docid] > 0)
								obj->liverank[docs[i].docid] = (((liverank_t)(dnvc - 1) / dnvc) * docs[i].liverank + (((liverank_t)obj->last_sketch_gap[docs[i].docid] / _max_gap) / dnvc));
							else
								obj->liverank[docs[i].docid] = (((liverank_t)(dnvc - 1) / dnvc) * docs[i].liverank);
					}
					else
						obj->liverank[docs[i].docid] = (((liverank_t)(dnvc - 1) / dnvc) * docs[i].liverank);
				}

				if (obj->liverank[docs[i].docid] > obj->max_liverank[inst])
					obj->max_liverank[inst] = obj->liverank[docs[i].docid];
			}
		}

		o = 0;
	}

	free(docs);
#endif

	sync_threads(obj->barrier);


	docid_t _ndocs_active = 0;

    for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
			_ndocs_active += obj->ndocs_active[i];

			if (opt_calc_liverank == true && obj->max_liverank[i] > _max_liverank)
				_max_liverank = obj->max_liverank[i];
	}

	sync_threads(obj->barrier);



	// Initialize local vars
	// We have to do this loop again
	// because we don't know the number of active
	// documents until we read the entire metadata
	for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
	{
		obj->in_degree[docid] = 0;
		obj->out_degree[docid] = 0;

		if (opt_calc_pagerank == true)
		{
			if (obj->is_ignored[docid] == true)
				obj->pagerank[docid] = 0;
			else
				obj->pagerank[docid] = (pagerank_t)((pagerank_t)LINK_NORMALIZATION/(pagerank_t)_ndocs_active);
		}

		if (opt_calc_wlrank == true)
		{
			obj->sum_out_weight[docid] = 0;

			if (obj->is_ignored[docid] == true)
				obj->wlrank[docid] = 0;
			else
				obj->wlrank[docid] = (wlrank_t)((wlrank_t)1/(wlrank_t)_ndocs_active);
		}

		if (opt_calc_hits == true)
		{
			obj->in_degree_external[docid]	= 0;
			obj->out_degree_external[docid]	= 0;

			if (obj->is_ignored[docid] == true)
			{
				obj->hub[docid]	= 0;
				obj->auth[docid] = 0;
			}
			else
			{
				obj->hub[docid]	= ((hubrank_t)1);
				obj->auth[docid] = ((authrank_t)1);
			}
		}

		if (opt_calc_liverank); // do nothing
	}

	sync_threads(obj->barrier);


	ccerr << "done." << endl << "Calculating degree |--------------------------------------------------|" << endl << "                    ";

	// Iterate to calculate degrees
	out_link_t dest[(LINK_MAX_OUTDEGREE + 1)];
	unsigned int ndest = 0;

	linkidx_prepare_sequential_read(obj->lidx, inst);

	for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
	{
		internal_long_uint_t expected = (docid / 10) * 10;
		internal_long_uint_t next = expected + 10;

		// Report
		if (ndocs_div_50 > 0 && (docid % ndocs_div_50 == 0) && this->print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
			cerr << ".";

		// Get links. Always get links BEFORE skipping
		// Read the links and we retreive only the adiacency with destination docs relative to instance to avoid write collisions
		linkidx_sequential_read(obj->lidx, inst, dest, &(ndest));


//		sync_threads(obj->barrier);
//

		// See if it's necessary to skip
		if (obj->is_ignored[docid])
			continue;

		// Calculate in degree and out degree
		// Check for dests where relative siteid reminder is equal to instance, and add the link
		for (docid_t j = 0; j < ndest; j++)
		{
			if (dest[j].dest > obj->ndocs)
				continue;

			// Avoid self-links or links to ignored documents
			// If this is not a self-link, the destination document is not ignored and different FQDN have not same second level domain
			if ((dest[j].dest != docid) && !obj->is_ignored[dest[j].dest])
			{
				// TODO novitàda testare
				if (obj->domainsid[dest[j].dest].siteid == obj->domainsid[docid].siteid)
					obj->out_degree[docid] += CONF_MANAGER_SCORE_FACTOR_FQDN;
				else if (obj->domainsid[dest[j].dest].domainid == obj->domainsid[docid].domainid)
					obj->out_degree[docid] += CONF_MANAGER_SCORE_FACTOR_DOMAIN;
				else // externals links
				{
					obj->out_degree[docid] += CONF_MANAGER_SCORE_FACTOR_EXTERNAL;

					// Populating site_out_degree_external
					instance_t sinst = ((obj->domainsid[docid].siteid - 1) % CONF_COLLECTION_DISTRIBUTED);

					obj->lock(sinst, obj->slocks);

					site_out_degree_t *ptr = &obj->site_out_degree_external[obj->domainsid[docid].siteid];

					while (ptr)
					{
						if (ptr->out_link == dest[j].dest)
						{
							ptr->count++;
							break;
						}
						else if (ptr->next == NULL)
						{
							site_out_degree_t *node = CBALLOC(site_out_degree_t, MALLOC, 1);
							node->count = 1;
							node->out_link = dest[j].dest;
							node->next = NULL;
							ptr->next = node;
							break;
						}

						ptr = ptr->next;
					}

					obj->unlock(sinst, obj->slocks);
				}

				bool incr_in_degree_external = false;

				// Calculate internal and external links 
				// between documents in different hosts
				if (opt_calc_hits == true)
				{
					if (obj->domainsid[dest[j].dest].domainid != obj->domainsid[docid].domainid)
					{
						incr_in_degree_external = true;
						obj->out_degree_external[docid]++;
					}
				}

				// Calc weight for normalization
				if (opt_calc_wlrank == true)
					obj->sum_out_weight[docid] += calculate_link_weight(dest[j]);

				instance_t dinst = ((dest[j].dest - 1) % CONF_COLLECTION_DISTRIBUTED);

				if (incr_in_degree_external == true)
				{
					obj->lock(dinst, obj->dlocks);
					obj->in_degree[dest[j].dest]++;
					obj->in_degree_external[dest[j].dest]++;
					obj->unlock(dinst, obj->dlocks);
				}
				else
				{
					obj->lock(dinst, obj->dlocks);
					obj->in_degree[dest[j].dest]++;
					obj->unlock(dinst, obj->dlocks);
				}
			}
		}
	}

	sync_threads(obj->barrier);


//	ccerr << "done." << endl;

	if (opt_calc_pagerank || opt_calc_hits || opt_calc_wlrank)
	{
		// Calculate q and 1-q based on the dampening factor
		double omq	= (double)CONF_MANAGER_SCORE_PAGERANK_DAMPENING;
		double q	= (double)1 - omq;

		ccerr << "done." << endl << "* Calculating link scores (iterative)  q=" << q << endl << endl;

		// Iterate to calculate pagerank
		bool pagerank_delta_ok = (opt_calc_pagerank || opt_calc_wlrank) ? false : true;
		bool hits_delta_ok = (opt_calc_hits) ? false : true;
		unsigned int iteration = 0;

		// Parallel Iteration
		for (iteration = 0; iteration < LINK_SCORE_MAX_ITERATIONS; iteration++)
		{
			// Clear TMP
			for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
			{
				if (opt_calc_pagerank)
					obj->pagerankTmp[docid]	= (pagerank_t)0;

				if (opt_calc_wlrank)
					obj->wlrankTmp[docid]	= (wlrank_t)0;

				if (opt_calc_hits)
				{
					obj->authTmp[docid]		= (authrank_t)0;
					obj->hubTmp[docid]		= (hubrank_t)0;
				}
			} 

			sync_threads(obj->barrier);


			// set for next reuse
			this->print_winner2.exchange(0);
			assert(this->print_winner2 == 0);

			// Iteration
			linkidx_prepare_sequential_read(obj->lidx, inst);

			for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
			{
				internal_long_uint_t expected = (docid / 10) * 10;
				internal_long_uint_t next = expected + 10;

				// Skip empty lists
				if (obj->out_degree[docid] == 0 || obj->is_ignored[docid] == true)
				{
					unsigned int skip	= 1;

					docid += CONF_COLLECTION_DISTRIBUTED;

					while (docid <= obj->ndocs && (obj->out_degree[docid] == 0 || obj->is_ignored[docid] == true))
					{
						//if (sp->go_ahead(inst) == true && ndocs_div_50 > 0 && docid % ndocs_div_50 == 0)
						if (ndocs_div_50 > 0 && (docid % ndocs_div_50 == 0) && this->print_winner.compare_exchange_strong(expected, next) == true) // sperimentale
							cerr << ".";

						skip++;
						docid += CONF_COLLECTION_DISTRIBUTED;
					}

					// Skip a number of items
					linkidx_sequential_skip(obj->lidx, inst, skip);

					// See if it is necessary to get out of the cycle
					if (docid > obj->ndocs)
						continue;
				}

				// Read (sequential)
				linkidx_sequential_read(obj->lidx, inst, dest, &(ndest));

			//	if (sp->go_ahead(inst) == true && ndocs_div_50 > 0 && docid % ndocs_div_50 == 0)
				if (ndocs_div_50 > 0 && (docid % ndocs_div_50 == 0) && this->print_winner.compare_exchange_strong(expected, next) == true) // sperimentale
					cerr << ".";

				if (ndest > 0)
				{
					instance_t c = 0;
					instance_t b = inst;

					site_out_degree_t *psite_out_degree_external = &obj->site_out_degree_external[obj->domainsid[docid].siteid];

					// Skip the first node because used only as main site counter
					psite_out_degree_external = psite_out_degree_external->next;

					pagerank_t pr_fqdn_fraction = (pagerank_t)0;
					pagerank_t pr_domain_fraction = (pagerank_t)0;
					pagerank_t pr_external_fraction = (pagerank_t)0;
					wlrank_t wlr_fqdn_fraction = (wlrank_t)0;
					wlrank_t wlr_domain_fraction = (wlrank_t)0;
					wlrank_t wlr_external_fraction = (wlrank_t)0;
					hubrank_t hub_fraction = (hubrank_t)0;

					if (opt_calc_pagerank)
					{
						pagerank_t pr_fqdn_fraction = ((obj->pagerank[docid]/(pagerank_t)(obj->out_degree[docid])) * CONF_MANAGER_SCORE_FACTOR_FQDN);
						pagerank_t pr_domain_fraction = ((obj->pagerank[docid]/(pagerank_t)(obj->out_degree[docid])) * CONF_MANAGER_SCORE_FACTOR_DOMAIN);
						pagerank_t pr_external_fraction = ((obj->pagerank[docid]/(pagerank_t)(obj->out_degree[docid])) * CONF_MANAGER_SCORE_FACTOR_EXTERNAL);
					}

					if (opt_calc_wlrank)
					{
						wlrank_t wlr_fqdn_fraction = ((obj->wlrank[docid] / obj->sum_out_weight[docid]) * CONF_MANAGER_SCORE_FACTOR_FQDN);
						wlrank_t wlr_domain_fraction = ((obj->wlrank[docid] / obj->sum_out_weight[docid]) * CONF_MANAGER_SCORE_FACTOR_DOMAIN);
						wlrank_t wlr_external_fraction = ((obj->wlrank[docid] / obj->sum_out_weight[docid]) * CONF_MANAGER_SCORE_FACTOR_EXTERNAL);
					}

					if (opt_calc_hits)
						hubrank_t hub_fraction = (obj->hub[docid]/(authrank_t)(obj->out_degree_external[docid]));

					if (ndest > 0)
					{
						// Mark pointed pages as with more depth
						while (c < CONF_COLLECTION_DISTRIBUTED)
						{
							obj->lock(b, obj->dlocks);

							// Check the destinations of this link
							for (docid_t j = 0; j < ndest; j++)
							{
								if (dest[j].dest > obj->ndocs)
									continue;

								if (((dest[j].dest - 1) % CONF_COLLECTION_DISTRIBUTED) == b)
								{
									// If this is not a self-link, the destination document is not ignored
									if ((dest[j].dest != docid) && obj->is_ignored[dest[j].dest] == false)
									{
										assert(obj->out_degree[docid] > 0);

										docid_t out_link_count = 0;

										// find sum of link on site to same doc
										if (obj->domainsid[dest[j].dest].domainid != obj->domainsid[docid].domainid)
										{
											site_out_degree_t *ptr = psite_out_degree_external;

											while (ptr)
											{
												if (ptr->out_link == dest[j].dest)
												{
													out_link_count = ptr->count;
													break;
												}

												ptr = ptr->next;
											}
										}

										// TODO solo uso test, se non evidenzia problemi si puòrimuovere
										if (obj->domainsid[dest[j].dest].domainid != obj->domainsid[docid].domainid)
												assert(out_link_count);
	
										// TODO novitàda testare
										if (opt_calc_pagerank && (!pagerank_delta_ok))
										{
											if (obj->domainsid[dest[j].dest].siteid == obj->domainsid[docid].siteid)
												obj->pagerankTmp[dest[j].dest] += pr_fqdn_fraction;
											else if (obj->domainsid[dest[j].dest].domainid == obj->domainsid[docid].domainid)
												obj->pagerankTmp[dest[j].dest] += pr_domain_fraction;
											else // externals links (max ranking)
											//	obj->pagerankTmp[dest[j].dest] += pr_external_fraction;
												obj->pagerankTmp[dest[j].dest] += pr_external_fraction / out_link_count;
										}

								//		if (opt_calc_pagerank && (!pagerank_delta_ok))
								//			obj->pagerankTmp[dest[j].dest] += obj->pagerank[docid]/(pagerank_t)(obj->out_degree[docid]);

										// Different FQDN must not have same second level domain
										if (opt_calc_wlrank && (!pagerank_delta_ok))
										{
											assert(obj->sum_out_weight[docid] > 0);

											if (obj->domainsid[dest[j].dest].siteid == obj->domainsid[docid].siteid)
												obj->wlrankTmp[dest[j].dest] += (wlr_fqdn_fraction * calculate_link_weight(dest[j]));
											if (obj->domainsid[dest[j].dest].domainid == obj->domainsid[docid].domainid)
												obj->wlrankTmp[dest[j].dest] += (wlr_domain_fraction * calculate_link_weight(dest[j]));
											else
											//	obj->wlrankTmp[dest[j].dest] += (wlr_external_fraction * calculate_link_weight(dest[j]));
												obj->wlrankTmp[dest[j].dest] += (wlr_external_fraction * calculate_link_weight(dest[j]) / out_link_count);
										}

										if (opt_calc_hits && (!hits_delta_ok))
										{
											// Apply Bharat's heuristic (modified) : don't count
											// links inside the same host (second level domain)
											if (obj->domainsid[dest[j].dest].domainid != obj->domainsid[docid].domainid)
												obj->authTmp[dest[j].dest] += hub_fraction / out_link_count;
										}
									}
								}
							}

							obj->unlock(b, obj->dlocks);

							c++;
							b = ((b + 1) % CONF_COLLECTION_DISTRIBUTED);
						}
					}
				}
			}

			if (opt_calc_hits && (!hits_delta_ok))
			{

				sync_threads(obj->barrier);


				// set for next reuse
				this->print_winner.exchange(0);
				assert(this->print_winner == 0);

				// Make a second iteration for HITS
				linkidx_prepare_sequential_read(obj->lidx, inst);

				for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
				{
					internal_long_uint_t expected = (docid / 10) * 10;
					internal_long_uint_t next = expected + 10;

					// Skip empty lists
					if (obj->out_degree[docid] == 0 || obj->is_ignored[docid] == true)
					{
						unsigned int skip	= 1;

						docid += CONF_COLLECTION_DISTRIBUTED;

						while (docid <= obj->ndocs && (obj->out_degree[docid] == 0 || obj->is_ignored[docid] == true))
						{
							// if (sp->go_ahead(inst) == true && ndocs_div_50 > 0 && docid % ndocs_div_50 == 0)
							if (ndocs_div_50 > 0 && (docid % ndocs_div_50 == 0) && this->print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
								cerr << ".";

							skip++;
							docid += CONF_COLLECTION_DISTRIBUTED;
						}

						// Skip a number of items
						linkidx_sequential_skip(obj->lidx, inst, skip);

						// See if it is necessary to get out of the cycle
						if (docid > obj->ndocs)
							continue;
					}

					// Read (sequential)
					linkidx_sequential_read(obj->lidx, inst, dest, &(ndest));

					// if (sp->go_ahead(inst) == true && ndocs_div_50 > 0 && docid % ndocs_div_50 == 0)
					if (ndocs_div_50 > 0 && (docid % ndocs_div_50 == 0) && this->print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
						cerr << ".";

					// If this document is ignored, continue
					// NOTE that it is important to make the sequential read anyways (a mio parere non necessario perchè già eseguito a monte)
					//if (obj->is_ignored[docid]) 
					//	continue;

					hubrank_t _hubTmp = (hubrank_t)0; 

					if (ndest > 0)
					{
						instance_t c = 0;
						instance_t b = inst;

						// Mark pointed pages as with more depth
						while (c < CONF_COLLECTION_DISTRIBUTED)
						{
							obj->lock(b, obj->dlocks);

							// Check the destinations of this link
							for (unsigned int j = 0; j < ndest; j++)
							{
								if (dest[j].dest > obj->ndocs)
									continue;

								if (((dest[j].dest - 1) % CONF_COLLECTION_DISTRIBUTED) == b)
								{
									// If this is not a self-link, the destination document is not ignored and different FQDN have not same
									// second level domain
									if ((dest[j].dest != docid) && obj->is_ignored[dest[j].dest] == false && obj->in_degree_external[dest[j].dest] > 0)
									{
										// Apply Bharat's heuristic (modified): don't count
										// links inside the same host (second level domain)
										// Note here that we do the iteration directly, we don't normalize before doing the hub part
										if (obj->domainsid[dest[j].dest].domainid != obj->domainsid[docid].domainid)
											obj->hubTmp[docid] += obj->authTmp[dest[j].dest]/(hubrank_t)(obj->in_degree_external[dest[j].dest]);
									}
								}
							}

							obj->unlock(b, obj->dlocks);

							c++;
							b = ((b + 1) % CONF_COLLECTION_DISTRIBUTED);
						}
					}
				}
			}

			// Normalize TMP and COPY
			obj->sum_pageranks[inst] = 0;
			obj->sum_wlranks[inst] = 0;
			obj->sum_hubs[inst] = 0;
			obj->sum_auths[inst] = 0;

			sync_threads(obj->barrier);


			pagerank_t _sum_pageranks = 0;
			wlrank_t _sum_wlranks = 0;
			hubrank_t _sum_hubs = 0;
			authrank_t _sum_auths = 0;

			for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
			{
				if (obj->is_ignored[docid] == true)
					continue;

				if (opt_calc_pagerank && (!pagerank_delta_ok))
				{
					obj->pagerankTmp[docid] = ((q / (double)_ndocs_active * LINK_NORMALIZATION) + (omq * obj->pagerankTmp[docid]));
					obj->sum_pageranks[inst] += obj->pagerankTmp[docid];
				}

				if (opt_calc_wlrank && (!pagerank_delta_ok))
				{
					obj->wlrankTmp[docid] = ((q / (double)_ndocs_active * LINK_NORMALIZATION) + (omq * obj->wlrankTmp[docid]));
					obj->sum_wlranks[inst] += obj->wlrankTmp[docid];
				}

				if (opt_calc_hits && (!hits_delta_ok))
				{
					obj->sum_auths[inst] += obj->authTmp[docid];
					obj->sum_hubs[inst] += obj->hubTmp[docid];
				}
			}

			// Quadratic errors
			obj->pagerank_delta[inst] = 0;
			obj->wlrank_delta[inst] = 0;
			obj->hub_delta[inst] = 0;
			obj->auth_delta[inst] = 0;

			sync_threads(obj->barrier);


		    for (instance_t i  = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			{
				_sum_pageranks += obj->sum_pageranks[i];
				_sum_wlranks += obj->sum_wlranks[i];
				_sum_auths += obj->sum_auths[i];
				_sum_hubs += obj->sum_hubs[i];
			}

			// Quadratic errors again
			double _pagerank_delta = 0;
			double _wlrank_delta = 0;
			double _hub_delta = 0;
			double _auth_delta = 0;
			pagerank_t pagerank_aux = 0;
			wlrank_t wlrank_aux = 0;
			hubrank_t hubrank_aux = 0;
			authrank_t authrank_aux = 0;

			sync_threads(obj->barrier);


			for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
			{
				if (obj->is_ignored[docid] == true)
					continue;

				if (opt_calc_pagerank && (!pagerank_delta_ok))
				{
					pagerank_aux = (_sum_pageranks > 0) ? ((LINK_NORMALIZATION * obj->pagerankTmp[docid]) / _sum_pageranks) : (pagerank_t)0;
					obj->pagerank_delta[inst] += linkidx_calc_delta(pagerank_aux, obj->pagerank[docid]);
					obj->pagerank[docid] = pagerank_aux;
				}

				if (opt_calc_wlrank && (!pagerank_delta_ok))
				{
					wlrank_aux = (_sum_wlranks > 0) ? ((LINK_NORMALIZATION * obj->wlrankTmp[docid]) / _sum_wlranks) : (wlrank_t)0;
					obj->wlrank_delta[inst] += linkidx_calc_delta(wlrank_aux, obj->wlrank[docid]);
					obj->wlrank[docid] = wlrank_aux;
				}

				if (opt_calc_hits && (!hits_delta_ok))
				{
					authrank_aux = (_sum_auths > 0) ? ((LINK_NORMALIZATION * obj->authTmp[docid]) / _sum_auths) : (authrank_t)0;
					obj->auth_delta[inst] += linkidx_calc_delta(authrank_aux, obj->auth[docid]);
					obj->auth[docid] = authrank_aux;

					hubrank_aux = (_sum_hubs > 0) ? ((LINK_NORMALIZATION * obj->hubTmp[docid]) / _sum_hubs) : (hubrank_t)0;
					obj->hub_delta[inst] += linkidx_calc_delta(hubrank_aux, obj->hub[docid]);
					obj->hub[docid] = hubrank_aux;
				}
			}

			sync_threads(obj->barrier);


			//ccerr << " done." << endl;

			sp->reset(inst);

		    for (instance_t i  = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			{
				_pagerank_delta += obj->pagerank_delta[i];
				_wlrank_delta += obj->wlrank_delta[i];
				_auth_delta += obj->auth_delta[i];
				_hub_delta += obj->hub_delta[i];
			}

			sync_threads(obj->barrier);


			// Check delta for pagerank and wlrank
			bool both_ok = true;

			if (opt_calc_pagerank && (!pagerank_delta_ok))
			{
				_pagerank_delta /= _ndocs_active;

				if (_pagerank_delta > CONF_MANAGER_SCORE_PAGERANK_MAX_ERROR)
					both_ok	= false;
			}

			if (opt_calc_wlrank && (!pagerank_delta_ok))
			{
				_wlrank_delta /= _ndocs_active;

				if (_wlrank_delta > CONF_MANAGER_SCORE_PAGERANK_MAX_ERROR)
					both_ok	= false;
			}

			if (both_ok)
				pagerank_delta_ok = true;

			// Check hits
			if (opt_calc_hits && (!hits_delta_ok))
			{
				if (_hub_delta > 0 || _auth_delta > 0)
				{
					_hub_delta /= _ndocs_active;

					_auth_delta /= _ndocs_active;

					if (_hub_delta < CONF_MANAGER_SCORE_HITS_MAX_ERROR && _auth_delta < CONF_MANAGER_SCORE_HITS_MAX_ERROR)
						hits_delta_ok = true;
				}
				else
					hits_delta_ok = true; 
			}


			// Show status of ranking during iteration
			if (sp->go_ahead(inst) == true)
			{
					cerr << " - Iteration " << iteration << endl;

					if (opt_calc_pagerank && (!pagerank_delta_ok))
					{
						cerr << "    pagerank average error       = " << _pagerank_delta << " (target=" << CONF_MANAGER_SCORE_PAGERANK_MAX_ERROR << ")" << endl;
						cerr << "    pagerank sum values          = " << _sum_pageranks << endl;
					}

					if (opt_calc_wlrank && (!pagerank_delta_ok))
					{
						cerr << "    wlrank average error         = " << _wlrank_delta << " (target=" << CONF_MANAGER_SCORE_PAGERANK_MAX_ERROR << ")" << endl;
						cerr << "    wlrank sum values            = " << _sum_wlranks << endl;
					}

					if (opt_calc_hits && (!hits_delta_ok))
					{
						cerr << "    hubrank average error        = " << _hub_delta << " (target=" << CONF_MANAGER_SCORE_HITS_MAX_ERROR << ")" << endl;
						cerr << "    hubrank sum values           = " << _sum_hubs << endl;
						cerr << "    authrank average error       = " << _auth_delta << " (target=" << CONF_MANAGER_SCORE_HITS_MAX_ERROR << ")" << endl;
						cerr << "    authrank sum values          = " << _sum_auths << ' ' << endl;
					}
			}

			if (pagerank_delta_ok && hits_delta_ok)
				break;

			sync_threads(obj->barrier);


			// Check iteration
			// die is not needed because at this point all threads must exit here without other syncronization
			if (iteration == LINK_SCORE_MAX_ITERATIONS)
			{
				if (sp->go_ahead(inst) == true)
					die("Too many iterations without convergence.\nPossible cause: HITS algorithm enabled in configuration file!");
				else
					pthread_exit(NULL);
			}
		}
	}
	else
	{
		ccerr << "done." << endl;
	}

	// If there are threads each sorting is passed to it (one sorting for thread)
	// Note: if we have many threads consider migration of code to CBotSort algorithm skipping 'step_counter' method
	if (opt_linearize)
	{
		docid_t _hub_gt_zero = 0;
		docid_t _auth_gt_zero = 0;
	
		// Hits
		if (opt_calc_hits)
		{

			// For the hits algorithm, there might be many
			// documents with score=0.
			// For pagerank/wlrank, all documents have a positive score,
			// or at least a base score.
			for (docid_t i = (inst + 1); i <= obj->ndocs; i += CONF_COLLECTION_DISTRIBUTED)
			{
				if (obj->is_ignored[i] == true)
					continue;

				if (obj->hub[i] > 0)
					obj->hub_gt_zero[inst]++;

				if (obj->auth[i] > 0)
					obj->auth_gt_zero[inst]++;
			}

			sync_threads(obj->barrier);


			for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			{
					_hub_gt_zero += obj->hub_gt_zero[i];
					_auth_gt_zero += obj->auth_gt_zero[i];
			}

			sync_threads(obj->barrier);

		}

		// if (opt_calc_pagerank || opt_calc_wlrank || opt_calc_hits || opt_calc_liverank)
		if (opt_calc_pagerank || opt_calc_wlrank || opt_calc_hits)
		{
			if (opt_fix_depths)
			{
				ccerr << "Converting to uniformly-distributed values between 0 and 1 and fixing depths:" << endl;
			}
			else
			{
				ccerr << "Converting to uniformly-distributed values between 0 and 1:" << endl;
			}
		}

		instance_t step_counter = obj->static_random_inst;

		// Pagerank
		if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst && opt_calc_pagerank)
		{
			free(obj->pagerankTmp); obj->pagerankTmp = NULL;

			// cerr << " - Pagerank ordering, assigning, ";
			docid_t *order = CBALLOC(docid_t, MALLOC, (obj->ndocs + 1));
			obj->order_by_score<docid_t, pagerank_t>(order, obj->pagerank, obj->ndocs, _ndocs_active, obj->is_ignored, false);
			free(order);
			mcerr << " - Pagerank ordering, assigning, done." << mendl;
			// cerr << "done." << endl;
		}

		step_counter++;

		// WLrank
		if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst && opt_calc_wlrank)
		{
			free(obj->sum_out_weight); obj->sum_out_weight = NULL;
			free(obj->wlrankTmp); obj->wlrankTmp = NULL;

			// cerr << " - WLrank ordering, assigning, ";
			docid_t *order = CBALLOC(docid_t, MALLOC, (obj->ndocs + 1));
			obj->order_by_score<docid_t, wlrank_t>(order, obj->wlrank, obj->ndocs, _ndocs_active, obj->is_ignored, false);
			free(order);
			mcerr << " - WLrank ordering, assigning, done." << mendl;
			// cerr << "done." << endl;
		}

		step_counter++;

		// Hits
		if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst && _hub_gt_zero > 0)
		{
			free(obj->hubTmp); obj->hubTmp = NULL;

			// cerr << " - Hits ordering by hub, ";
			docid_t *order = CBALLOC(docid_t, MALLOC, (obj->ndocs + 1));
			obj->order_by_score<docid_t, hubrank_t>(order, obj->hub, obj->ndocs, _hub_gt_zero, obj->is_ignored, true);
			free(order);
			mcerr << " - Hits ordering by hub, done." << mendl;
			// cerr << "done." << endl;
		}

		step_counter++;

		// Authority
		if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst && _auth_gt_zero > 0)
		{
			free(obj->authTmp); obj->authTmp = NULL;

			// cerr << " - Authority ordering, assigning, ";
			docid_t *order = CBALLOC(docid_t, MALLOC, (obj->ndocs + 1));
			obj->order_by_score<docid_t, authrank_t>(order, obj->auth, obj->ndocs, _auth_gt_zero, obj->is_ignored, true);
			free(order);
			mcerr << " - Authority ordering, assigning, done." << mendl;
			// cerr << "done." << endl;
		}

		/* step_counter++;

		if ((step_counter % CONF_COLLECTION_DISTRIBUTED) == inst)
		{
			free(obj->liverankTmp); obj->liverankTmp = NULL;

			if (opt_calc_liverank)
			{
				//
			}
		} */
	}

	sync_threads(obj->barrier);


	// free linked list of site_out_degree_external in parallel mode
	for (siteid_t siteid = (inst + 1); siteid <= obj->nsites; siteid += CONF_COLLECTION_DISTRIBUTED)
	{
		site_out_degree_t *ptr = obj->site_out_degree_external[siteid].next;

		while (ptr)
		{
			site_out_degree_t *_ptr = ptr;

			ptr = ptr->next;

			free(_ptr);
		}
	}



	// Fixing depths
	if (opt_fix_depths)
	{
		assert(obj->depth);
		assert(obj->count_depth_undefined);

		for (docid_t i = (inst + 1); i <= obj->ndocs; i += CONF_COLLECTION_DISTRIBUTED)
		{
			internal_long_uint_t expected = (i / 10) * 10;
			internal_long_uint_t next = expected + 10;

			// if (sp->go_ahead(inst) == true && ndocs_div_50 > 0 && docid % ndocs_div_50 == 0)
			if (ndocs_div_50 > 0 && (i % ndocs_div_50 == 0) && this->print_winner2.compare_exchange_strong(expected, next) == true) // sperimentale
				cerr << ".";

			if (url->is_homepage(i))
				obj->depth[i] = 1;
			else
				obj->depth[i] = DEPTH_UNDEFINED;  // undefined depth
		}

		depth_t current_depth = 1;

		sync_threads(obj->barrier);


		// Check on each round if a page was found
		do {
			assert(current_depth < DEPTH_UNDEFINED);

			for (docid_t i = (inst + 1); i <= meta->doc_count(); i += CONF_COLLECTION_DISTRIBUTED)
			{
				// Check depth
				if (obj->depth[i] == current_depth)
				{
					docid_t ndest;

					// Retrieve links relative the instance
					linkidx_retrieve(lidx, inst, i, dest, &(ndest));

					if (ndest > 0)
					{
						instance_t c = 0;
						instance_t b = inst;

						// Mark pointed pages as with more depth
						while (c < CONF_COLLECTION_DISTRIBUTED)
						{
							obj->lock(b, obj->dlocks);

							for (docid_t j = 0; j < ndest; j++)
							{
								if (((dest[j].dest - 1) % CONF_COLLECTION_DISTRIBUTED) == b)
								{
									if (obj->depth[dest[j].dest] == DEPTH_UNDEFINED)
										obj->depth[dest[j].dest] = (current_depth + 1);
								}
							}

							obj->unlock(b, obj->dlocks);

							c++;
							b = ((b + 1) % CONF_COLLECTION_DISTRIBUTED);
						}
					}

					// Note that I found a page at this depth
					obj->nmarked[((current_depth - 1) % obj->nmarked_size)]++;
				}
			}

			current_depth++;

			sync_threads(obj->barrier);


			// Report
			if ((current_depth % CONF_COLLECTION_DISTRIBUTED) == inst)
			{
				if (current_depth == 2)
				{
					cerr << GRE << "Fixing depths" << NOR << endl;
					cerr << "Initial depth is set as 1 for home pages." << endl;
					cerr << "- Setting initial depth |--------------------------------------------------|" << endl;
					cerr << "                         ok" << endl;
					cerr << "- Iterating   |--------------------------------------------------|" << endl;
					cerr << "               depth=" << (current_depth - 1) << " (" << obj->nmarked[((current_depth - 2) % obj->nmarked_size)] << " pages)";
				}
				else if (current_depth > 2)
					cerr << ", depth=" << (current_depth - 1) << " (" << obj->nmarked[((current_depth - 2) % obj->nmarked_size)] << " pages)";

				// reset unused nmarked cache
				if ((current_depth - 3) > 0)
					obj->nmarked[(current_depth % obj->nmarked_size)] = 0;
			}
		}
		while ((obj->nmarked[((current_depth - 2) % obj->nmarked_size)] > 0) && (current_depth < CONF_MANAGER_MAXDEPTH_STATIC));

		sync_threads(obj->barrier);

	}

	// if (opt_calc_pagerank || opt_calc_wlrank || opt_calc_hits || opt_calc_liverank)
	if (opt_calc_pagerank || opt_calc_wlrank || opt_calc_hits)
	{
		if (opt_fix_depths)
		{
			ccerr << endl << " done calculating." << endl << "Writing all |--------------------------------------------------|" << endl << "              ";
		}
		else
		{
			ccerr << " done calculating." << endl << "Writing all |--------------------------------------------------|" << endl << "              ";
		}
	}
	else
	{
		if (opt_fix_depths)
		{
			ccerr << endl << "Writing all |--------------------------------------------------|" << endl << "              ";
		}
		else
		{
			ccerr << "Writing all |--------------------------------------------------|" << endl << "             ";
		}
	}

	char path[MAX_STR_LEN];

	//
	// Write metadata
	//
#ifndef META_MAX_BUFFERING_SIZE
	for (doc.docid = (inst + 1); doc.docid <= obj->ndocs; doc.docid += CONF_COLLECTION_DISTRIBUTED)
	{
		docid_t _docid = doc.docid;

		memset(&doc, 0, sizeof(doc_t));

		doc.docid = _docid;

		// Retrieve
		meta->doc_retrieve(&(doc));
		assert(doc.docid > 0);

		if (opt_fix_depths && obj->depth[doc.docid] == DEPTH_UNDEFINED)
			obj->count_depth_undefined[inst]++;

		if (obj->is_ignored[doc.docid])
		{
			if (opt_calc_pagerank)
				assert(obj->pagerank[doc.docid] == 0);

			if (opt_calc_wlrank)
				assert(obj->wlrank[doc.docid] == 0);

			if (opt_calc_hits)
			{
				assert(obj->hub[doc.docid] == 0);
				assert(obj->auth[doc.docid] == 0);
			}

			//	if (opt_calc_liverank)
			//		assert(liverank[doc.docid] == 0);
		}

		bool new_depth = false;
		bool new_dynamic_state = false;
		bool new_ignored_state = false;

		// Copy values required by external options regardless ranking results
		if (opt_fix_depths && obj->depth[doc.docid] != DEPTH_UNDEFINED)
		{
			if (doc.depth != obj->depth[doc.docid])
			{
				new_depth = true;
				doc.depth = obj->depth[doc.docid];
			}
		}

		if (opt_mark_dynamic)
		{
			path[0] = ASCII_NUL;

			// Read path
			url->path_by_docid(doc.docid, path);
			assert(path != NULL);

			bool old_dynamic_status = doc.is_dynamic;

			// Mark URL
			doc.is_dynamic = url->is_dynamic(extensions_dynamic, path );

			if (old_dynamic_status != doc.is_dynamic)
			{
				new_dynamic_state = true;
				doc.is_dynamic = url->is_dynamic(extensions_dynamic, path );
			}
		}

		if (opt_mark_ignored)
		{
			// We will only ignore documents that are new
			if( doc.status == STATUS_DOC_NEW )
			{
				if (doc.is_dynamic && (doc.depth > CONF_MANAGER_MAXDEPTH_DYNAMIC)) // Document is dynamic and too deep
					doc.status	= STATUS_DOC_IGNORED;
				else if ((!doc.is_dynamic) && (doc.depth > CONF_MANAGER_MAXDEPTH_STATIC)) // Document is static and too deep
					doc.status	= STATUS_DOC_IGNORED;
				/* else if (count_docs[doc.siteid] > CONF_SEEDER_MAX_URLS_PER_SITE) // TODO
					// There are too many documents from this server
					doc.status	= STATUS_DOC_IGNORED; */

				// Check if we must write this record
				if( doc.status == STATUS_DOC_IGNORED )
					new_ignored_state = true;
			}
		}

		if (obj->is_ignored[doc.docid])
		{
			// Store
			if (new_depth == true || new_dynamic_state == true || new_ignored_state == true)
				meta->doc_store(&(doc));

			continue;
		}
		
		// Copy values

		if (obj->is_ignored[doc.docid] == false)
		{
			if (opt_calc_pagerank)
				doc.pagerank = obj->pagerank[doc.docid];

			if (opt_calc_wlrank)
				doc.wlrank = obj->wlrank[doc.docid];

			if (opt_calc_hits)
			{
				doc.hubrank = obj->hub[doc.docid];
				doc.authrank = obj->auth[doc.docid];
			}

			if (opt_calc_liverank)
			{
				// if (obj->liverank[doc.docid] > 0 && obj->liverank[doc.docid] <= 1)
				if (obj->liverank[doc.docid] > 0)
					doc.liverank = (obj->liverank[doc.docid] / _max_liverank);
			}

			// Always write in/out degree also
			doc.in_degree	= obj->in_degree[doc.docid];
			doc.out_degree	= obj->out_degree[doc.docid];
		}

		// Store
		meta->doc_store(&(doc));
	}
#else
	size = (META_MAX_BUFFERING_SIZE > sizeof(doc_t)) ? (META_MAX_BUFFERING_SIZE / sizeof(doc_t)) : META_MIN_BUFFERING_SIZE;

	docs = CBALLOC(doc_t, MALLOC, size);

	o = 0;

	for (docid_t docid = (inst + 1); docid <= obj->ndocs; docid += CONF_COLLECTION_DISTRIBUTED)
	{
		docs[o].docid = docid;
		o++;

		if (o > 1)
			assert(meta->doc_retrieve_buffered(docs, o) == METADDX_OK);
		else if (o > 0)
			assert(meta->doc_retrieve(&docs[0]) == METADDX_OK);

		size_t buffer_chunk_offset = 0;
		size_t buffer_chunk_size = 0;

		for (size_t i = 0; i < o; i++)
		{
			assert(docs[i].docid > 0);

			if (opt_fix_depths && obj->depth[docs[i].docid] == DEPTH_UNDEFINED)
				obj->count_depth_undefined[inst]++;

			if (obj->is_ignored[docs[i].docid])
			{
				if (opt_calc_pagerank)
					assert(obj->pagerank[docs[i].docid] == 0);

				if (opt_calc_wlrank)
					assert(obj->wlrank[docs[i].docid] == 0);

				if (opt_calc_hits)
				{
					assert(obj->hub[docs[i].docid] == 0);
					assert(obj->auth[docs[i].docid] == 0);
				}

				//	if (opt_calc_liverank)
				//		assert(liverank[docs[i].docid] == 0);
			}

			// Copy values required by external options regardless ranking results
			if (opt_fix_depths && obj->depth[docs[i].docid] != DEPTH_UNDEFINED)
			{
				if (docs[i].depth != obj->depth[docs[i].docid])
					docs[i].depth = obj->depth[docs[i].docid];
			}

			if (opt_mark_dynamic)
			{
				path[0] = ASCII_NUL;

				// Read path
				url->path_by_docid(docs[i].docid, path);
				assert(path != NULL);

				bool old_dynamic_status = docs[i].is_dynamic;

				// Mark URL
				docs[i].is_dynamic = url->is_dynamic(extensions_dynamic, path );

				if (old_dynamic_status != docs[i].is_dynamic)
				{
					docs[i].is_dynamic = url->is_dynamic(extensions_dynamic, path );

					if (docs[i].is_dynamic == true)
						*ndocs_marked_dynamic_static++;
					else
						*ndocs_marked_static_dynamic++;
				}
			}

			if (opt_mark_ignored)
			{
			// We will only ignore documents that are new
				if( docs[i].status == STATUS_DOC_NEW )
				{
					if (docs[i].is_dynamic && (docs[i].depth > CONF_MANAGER_MAXDEPTH_DYNAMIC)) // Document is dynamic and too deep
					{
						doc.status	= STATUS_DOC_IGNORED;
						*ndocs_marked_depth_dynamic++;
					}
					else if ((!docs[i].is_dynamic) && (docs[i].depth > CONF_MANAGER_MAXDEPTH_STATIC)) // Document is static and too deep
					{
						docs[i].status	= STATUS_DOC_IGNORED;
						*ndocs_marked_depth_static++;
					}
					/* else if (count_docs[docs[i].siteid] > CONF_SEEDER_MAX_URLS_PER_SITE) // There are too many documents from this server
					{
						docs[i].status	= STATUS_DOC_IGNORED;
						*ndocs_marked_depth_static++;
					} */
				}
			}

			if (obj->is_ignored[docs[i].docid])
			{
				// increment the buffer's size of next storing
				buffer_chunk_size++;

				continue;
			}

			// Copy values

			if (obj->is_ignored[docs[i].docid] == false)
			{
				if (opt_calc_pagerank)
					docs[i].pagerank = obj->pagerank[docs[i].docid];

				if (opt_calc_wlrank)
					docs[i].wlrank = obj->wlrank[docs[i].docid];

				if (opt_calc_hits)
				{
					docs[i].hubrank = obj->hub[docs[i].docid];
					docs[i].authrank = obj->auth[docs[i].docid];
				}

				if (opt_calc_liverank)
				{
					// if (obj->liverank[docs[i].docid] > 0 && obj->liverank[docs[i].docid] <= 1)
					if (obj->liverank[docs[i].docid] > 0)
						docs[i].liverank = (obj->liverank[docs[i].docid] / _max_liverank);
				}

				// Always write in/out degree also
				docs[i].in_degree	= obj->in_degree[docs[i].docid];
				docs[i].out_degree	= obj->out_degree[docs[i].docid];
			}

			// increment the buffer's size of next storing
			buffer_chunk_size++;
		}

		// store full buffer or last chunck
		if (buffer_chunk_size > 1)
			assert(meta->doc_store_buffered(&docs[buffer_chunk_offset], buffer_chunk_size) == METADDX_OK);
		else if (buffer_chunk_size > 0)
			assert(meta->doc_store(&docs[buffer_chunk_offset]) == METADDX_OK);

		o = 0;
	}

	free(docs);
#endif

	sync_threads(obj->barrier);


	docid_t _count_depth_undefined = 0;

	if (opt_fix_depths)
		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			_count_depth_undefined += obj->count_depth_undefined[i];

	if (opt_mark_dynamic && opt_mark_ignored)
	{
		if (*ndocs_marked_too_many > 0)
		{
			if (opt_fix_depths)
			{
				ccerr << "done." << endl << GRE << "Fixing depths " << NOR << " - There were " << _count_depth_undefined << '/' << obj->ndocs << " docs with undefined depth and I left them untouched" << endl \
				<< GRE << endl \
				<< "Documents marked to dynamic or static : " << (*ndocs_marked_dynamic_static + *ndocs_marked_static_dynamic) << NOR << endl \
				<< "- Static documents to dynamic         : " << *ndocs_marked_dynamic_static << endl \
				<< "- Dynamic documents to static         : " << *ndocs_marked_static_dynamic << endl << endl \
				<< GRE << endl \
				<< "Documents marked for ignoring         : " << (*ndocs_marked_depth_static + *ndocs_marked_depth_dynamic + *ndocs_marked_too_many) << NOR << endl \
				<< "- Static documents too deep           : " << *ndocs_marked_depth_static << endl \
				<< "- Dynamic documents too deep          : " << *ndocs_marked_depth_dynamic << endl \
				<< "- Documents in large sites            : " << *ndocs_marked_too_many << endl << endl << endl;
			}
			else
			{
				ccerr << "done." << GRE << endl \
				<< "Documents marked to dynamic or static : " << (*ndocs_marked_dynamic_static + *ndocs_marked_static_dynamic) << NOR << endl \
				<< "- Static documents to dynamic         : " << *ndocs_marked_dynamic_static << endl \
				<< "- Dynamic documents to static         : " << *ndocs_marked_static_dynamic << endl << endl \
				<< GRE << endl \
				<< "Documents marked for ignoring         : " << (*ndocs_marked_depth_static + *ndocs_marked_depth_dynamic + *ndocs_marked_too_many) << NOR << endl \
				<< "- Static documents too deep           : " << *ndocs_marked_depth_static << endl \
				<< "- Dynamic documents too deep          : " << *ndocs_marked_depth_dynamic << endl \
				<< "- Documents in large sites            : " << *ndocs_marked_too_many << endl << endl << endl;
			}
		}
		else
		{
			if (opt_fix_depths)
			{
				ccerr << "done." << endl << GRE << "Fixing depths " << NOR << " - There were " << _count_depth_undefined << '/' << obj->ndocs << " docs with undefined depth and I left them untouched" << endl \
				<< GRE << endl \
				<< "Documents marked to dynamic or static : " << (*ndocs_marked_dynamic_static + *ndocs_marked_static_dynamic) << NOR << endl \
				<< "- Static documents to dynamic         : " << *ndocs_marked_dynamic_static << endl \
				<< "- Dynamic documents to static         : " << *ndocs_marked_static_dynamic << endl << endl \
				<< GRE << endl \
				<< "Documents marked for ignoring         : " << *ndocs_marked_depth_static + *ndocs_marked_depth_dynamic << NOR << endl \
				<< "- Static documents too deep           : " << *ndocs_marked_depth_static << endl \
				<< "- Dynamic documents too deep          : " << *ndocs_marked_depth_dynamic << endl << endl << endl;
			}
			else
			{
				ccerr << "done." << GRE << endl \
				<< "Documents marked to dynamic or static : " << (*ndocs_marked_dynamic_static + *ndocs_marked_static_dynamic) << NOR << endl \
				<< "- Static documents to dynamic         : " << *ndocs_marked_dynamic_static << endl \
				<< "- Dynamic documents to static         : " << *ndocs_marked_static_dynamic << endl << endl \
				<< GRE << endl \
				<< "Documents marked for ignoring         : " << *ndocs_marked_depth_static + *ndocs_marked_depth_dynamic << NOR << endl \
				<< "- Static documents too deep           : " << *ndocs_marked_depth_static << endl \
				<< "- Dynamic documents too deep          : " << *ndocs_marked_depth_dynamic << endl << endl << endl;
			}
		}
	}
	else if (opt_mark_dynamic)
	{
		if (opt_fix_depths)
		{
			ccerr << "done." << endl << GRE << "Fixing depths " << NOR << " - There were " << _count_depth_undefined << '/' << obj->ndocs << " docs with undefined depth and I left them untouched" << endl \
			<< GRE << endl \
			<< "Documents marked to dynamic or static : " << (*ndocs_marked_dynamic_static + *ndocs_marked_static_dynamic) << NOR << endl \
			<< "- Static documents to dynamic         : " << *ndocs_marked_dynamic_static << endl \
			<< "- Dynamic documents to static         : " << *ndocs_marked_static_dynamic << endl << endl  << endl;
		}
		else
		{
			ccerr << "done." << GRE << endl \
			<< "Documents marked to dynamic or static : " << (*ndocs_marked_dynamic_static + *ndocs_marked_static_dynamic) << NOR << endl \
			<< "- Static documents to dynamic         : " << *ndocs_marked_dynamic_static << endl \
			<< "- Dynamic documents to static         : " << *ndocs_marked_static_dynamic << endl << endl  << endl;
		}
	}
	else if (opt_mark_ignored)
	{
		if (*ndocs_marked_too_many > 0)
		{
			if (opt_fix_depths)
			{
				ccerr << "done." << endl << GRE << "Fixing depths " << NOR << " - There were " << _count_depth_undefined << '/' << obj->ndocs << " docs with undefined depth and I left them untouched" << endl \
				<< GRE << endl \
				<< "Documents marked for ignoring         : " << (*ndocs_marked_depth_static + *ndocs_marked_depth_dynamic + *ndocs_marked_too_many) << NOR << endl \
				<< "- Static documents too deep           : " << *ndocs_marked_depth_static << endl \
				<< "- Dynamic documents too deep          : " << *ndocs_marked_depth_dynamic << endl \
				<< "- Documents in large sites            : " << *ndocs_marked_too_many << endl << endl << endl;
			}
			else
			{
				ccerr << "done." << GRE << endl \
				<< "Documents marked for ignoring         : " << (*ndocs_marked_depth_static + *ndocs_marked_depth_dynamic + *ndocs_marked_too_many) << NOR << endl \
				<< "- Static documents too deep           : " << *ndocs_marked_depth_static << endl \
				<< "- Dynamic documents too deep          : " << *ndocs_marked_depth_dynamic << endl \
				<< "- Documents in large sites            : " << *ndocs_marked_too_many << endl << endl << endl;
			}
		}
		else
		{
			if (opt_fix_depths)
			{
				ccerr << "done." << endl << GRE << "Fixing depths " << NOR << " - There were " << _count_depth_undefined << '/' << obj->ndocs << " docs with undefined depth and I left them untouched" << endl \
				<< GRE << endl \
				<< "Documents marked for ignoring         : " << *ndocs_marked_depth_static + *ndocs_marked_depth_dynamic << endl \
				<< "- Static documents too deep           : " << *ndocs_marked_depth_static << endl \
				<< "- Dynamic documents too deep          : " << *ndocs_marked_depth_dynamic << endl << NOR << endl << endl;
			}
			else
			{
				ccerr << "done." << GRE << endl \
				<< "Documents marked for ignoring         : " << *ndocs_marked_depth_static + *ndocs_marked_depth_dynamic << endl \
				<< "- Static documents too deep           : " << *ndocs_marked_depth_static << endl \
				<< "- Dynamic documents too deep          : " << *ndocs_marked_depth_dynamic << endl << NOR << endl << endl;
			}
		}
	}
	else
	{
		ccerr << "done." << endl;
	}

	arguments->meta = NULL;
	arguments->strg = NULL;

    return NULL;
}

linkweight_t calculate_link_weight(out_link_t link)
{
    linkweight_t base = (linkweight_t)1;
    linkweight_t rel_pos_factor = (linkweight_t)1;
    linkweight_t tag_b_value = (linkweight_t)1;
    linkweight_t tag_h1_value = (linkweight_t)1;
    linkweight_t anchor_length_base = (linkweight_t)1;
    linkweight_t anchor_length_average = (linkweight_t)100;

	
	linkweight_t weight=base;


	// Contribution form the relative position of the link in the src document
	
	weight+=rel_pos_factor * (linkweight_t)((double)link.rel_pos/100.0);

    // Contribution from the tag where the link is embedded
	
	if (link.tag==TAG_B)
		weight+=tag_b_value;
	else if (link.tag==TAG_H1)
		weight+=tag_h1_value;

	// Contribution from the length or the anchor of the link
	
	weight+=anchor_length_base * (linkweight_t)link.anchor_length/anchor_length_average;
	return weight;
}
