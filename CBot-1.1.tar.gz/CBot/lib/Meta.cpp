/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "Meta.h"

//
// Name: thread_function_caller
//
// Description:
//   A proxy function to pass non-static function at pthread_create
//   Note: function called by thread_function_caller need to have real class object passed through args
//
// Input:
//   args - void arguments
//
// Return:
//   pointer to void
//

void *Meta::thread_function_caller(void *args)
{
	assert(args);

try
{
	Meta::thread_args_t *arguments = (Meta::thread_args_t *)args;

	Meta *newObj = NULL;

	try
	{
		newObj = new Meta (NULL, true); // Note function called work to 'this' temporary object and need to be deleted at the end of the same.
	}
	catch (std::bad_alloc& ba)
	{
		die("thread_function_caller bad_alloc caught: %s", ba.what());
	}

	switch (arguments->f)
	{
		case META_OPEN:
			newObj->thread_function_open(args);
			break;
		case META_CLOSE:
			newObj->thread_function_close(args);
			break;
		case META_REMOVE:
			newObj->thread_function_remove(args);
			break;
		default:
			break;
	}

	delete newObj;
}
catch (CBotExitException eex)
{
	// Some  function  indicated  that  we  should  exit  the  thread. 
	eex.DoThreadExit(NULL); 
}

	free(args);
	args = NULL;

	return NULL;
}

//
// Name: convert_old_site_file
//
// Description:
//
// Input:
//
// Return:
//
//
void Meta::convert_old_site_file(char *infile, bool quiet)
{
	char outfile[MAX_STR_LEN];
	sprintf(outfile, "%s.tmp", infile);

	if (quiet == false)
		cerr << "Converting site file ... ";

	// Create file
	FILE *in = fopen64(infile, "r");
	assert(in != NULL);
	FILE *out = fopen64(outfile, "w");
	assert(out != NULL);

	site_old_t site_old;
	site_t site_new;

	site_default(&(site_new));

	for(siteid_t i = 0; i <= CONF_COLLECTION_MAXSITE; i++) {
		fread(&site_old, sizeof(site_old_t), 1, in);
		site_new.siteid				= site_old.siteid;
		site_new.count_doc			= site_old.count_doc;
		site_new.count_error		= site_old.count_error;
		site_new.last_visit			= site_old.last_visit;
		site_new.last_resolved		= site_old.last_resolved;
		//memcpy(&(site_new.addr), &(site_old.addr), sizeof(struct in_addr));
		site_new.raw_content_length	= site_old.raw_content_length;
		site_new.harvest_id			= site_old.harvest_id;
//		site_new.has_valid_robots_txt		= site_old.has_valid_robots_txt;

		site_new.count_doc_ok		= site_old.count_doc_ok;
		site_new.count_doc_gathered	= site_old.count_doc_gathered;
		site_new.count_doc_new		= site_old.count_doc_new;
		site_new.count_doc_assigned	= site_old.count_doc_assigned;
		site_new.count_doc_static	= site_old.count_doc_static;
		site_new.count_doc_dynamic	= site_old.count_doc_dynamic;
		site_new.siterank			= site_old.siterank;
		site_new.age_oldest_page	= site_old.age_oldest_page;
		site_new.age_newest_page	= site_old.age_newest_page;
		site_new.age_average_page	= site_old.age_average_page;
		site_new.in_degree			= site_old.in_degree;
		site_new.max_depth			= site_old.max_depth;
		site_new.component			= site_old.component;
		site_new.internal_links		= site_old.internal_links;
		site_new.out_degree			= site_old.out_degree;
		site_new.count_doc_gathered			= site_old.count_doc_gathered;
		site_new.count_doc_new			= site_old.count_doc_new;
		site_new.count_doc_assigned			= site_old.count_doc_assigned;
		site_new.count_doc_ignored			= site_old.count_doc_ignored;

		site_new.sum_pagerank		= site_old.sum_pagerank;
		site_new.sum_hubrank		= site_old.sum_hubrank;
		site_new.sum_authrank		= site_old.sum_authrank;

		fwrite(&site_new, sizeof(site_t), 1, out);
	}

	if (quiet == false)
		cerr << "done" << endl;

	fclose(in);
	fclose(out);

	rename(outfile, infile);
}

void Meta::convert_old_doc_file(char *infile, bool quiet)
{
	char outfile[MAX_STR_LEN];
	sprintf(outfile, "%s.tmp", infile);

	if (quiet == false)
		cerr << "Converting doc file ... ";

	// Create file
	FILE *in = fopen64(infile, "r");
	assert(in != NULL);
	FILE *out = fopen64(outfile, "w");
	assert(out != NULL);

	doc_old_t doc_old;
	doc_t doc_new;

	doc_default(&(doc_new));

	for(siteid_t i = 0; i <= CONF_COLLECTION_MAXDOC; i++) {
		fread(&doc_old, sizeof(doc_old_t), 1, in);

		doc_new.docid				= doc_old.docid;
		doc_new.siteid				= doc_old.siteid;
		doc_new.status       	  	= doc_old.status;
		doc_new.mime_type			= doc_old.mime_type;
		doc_new.http_status        	= doc_old.http_status;

		doc_new.effective_speed    	= doc_old.effective_speed;
		doc_new.latency				= 0;
		doc_new.latency_connect		= 0;

		doc_new.number_visits      	= doc_old.number_visits;
		doc_new.number_visits_changed    = doc_old.number_visits_changed;

		doc_new.time_unchanged     	= doc_old.time_unchanged;
		doc_new.first_visit        	= doc_old.first_visit;
		doc_new.last_visit			= doc_old.last_visit;
		doc_new.last_modified      	= doc_old.last_modified;

		doc_new.raw_content_length 	= doc_old.raw_content_length;
		doc_new.content_length     	= doc_old.content_length;
		doc_new.duplicate_of		= doc_old.duplicate_of;

		doc_new.depth              	= doc_old.depth;
		doc_new.is_dynamic			= doc_old.is_dynamic;

		doc_new.in_degree			= doc_old.in_degree;
		doc_new.out_degree			= doc_old.out_degree;

		doc_new.pagerank			= doc_old.pagerank;
		doc_new.wlrank            	= doc_old.wlrank;
		doc_new.hubrank           	= doc_old.hubrank;
		doc_new.authrank          	= doc_old.authrank;

		doc_new.freshness			= doc_old.freshness;
		doc_new.current_score		= doc_old.current_score;
		doc_new.future_score		= doc_old.future_score;

		fwrite(&doc_new, sizeof(doc_t), 1, out);
	}

	if (quiet == false)
		cerr << "done" << endl;

	fclose(in);
	fclose(out);

	rename(outfile, infile);
}

void Meta::ddx_open(void)
{
	if (thread_alarm != THREADS_OK)
		return;

	// Request memory for the structure
	m = CBALLOC(metaddx_t, NEW, 1);

	m->count_site = 0;
	m->count_doc = 0;
	m->readonly = this->readonly;

	m->distributed = CBALLOC(mddx_t, CALLOC, CONF_COLLECTION_DISTRIBUTED);

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Meta::thread_args_t *args = CBALLOC(Meta::thread_args_t, MALLOC, 1);
	    args->inst = inst;
    	args->obj = this;
		args->d = (char *)this->dirname;
		args->f = META_OPEN;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_open((void *) args); // only one distribution, function is call without thread 
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
		{
			// Update site master counter
			m->count_site += m->distributed[inst].count_site;
			// Update doc master counter
			m->count_doc += m->distributed[inst].count_doc;
		}

		free(threads);
	}
	else
	{
			instance_t inst = (CONF_COLLECTION_DISTRIBUTED - 1);

			// Update site master counter
			m->count_site += m->distributed[inst].count_site;
			// Update doc master counter
			m->count_doc += m->distributed[inst].count_doc;
	}

	if (m->count_site > 0)
		cerr << endl << "Found " << m->count_site << " sites. " << endl;

	if (m->count_doc > 0)
		cerr << "Found " << m->count_doc << " documents." << endl;
}

//
// Name: thread_function_open
//
// Description: invoked by 'metaddx_open' as thread
//
// Arguments: a void pointer to thread_function_args_t type structure 
//
// Return: NULL
//
void *Meta::thread_function_open(void *args)
{
	cpu_set_t system_cpus;

	Meta::thread_args_t *arguments = (Meta::thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	char *dirname = arguments->d;
	Meta *obj = arguments->obj;
	assert(obj->m != NULL);
	metaddx_t *m = obj->m;

	char filename[MAX_STR_LEN];
	struct stat64 statbuf;

	// Copy directory name
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);
	assert(strlen(relative_rem_path) < MAX_STR_LEN);
	strcpy(m->distributed[inst].dirname, relative_rem_path);
	free(relative_rem_path);
	m->distributed[inst].file_site = -1;
	m->distributed[inst].file_optmask_site = -1;
	m->distributed[inst].file_doc = -1;
	m->distributed[inst].optmask_site = NULL;
	m->distributed[inst].count_site = 0;
	m->distributed[inst].count_doc = 0;

	// Go ahead to sites .... Create or open filename
	sprintf(filename, "%s/%s", m->distributed[inst].dirname, METADDX_FILENAME_SITE);

	errno = 0; // errno is thread-local

	if (stat64(filename, &statbuf) == 0)
	{
		// Verify file size
		if ((internal_long_uint_t)(statbuf.st_size) != (sizeof(site_t) * (CONF_COLLECTION_MAXSITE + 1)))
		{
			if ((internal_long_uint_t)(statbuf.st_size) != (sizeof(site_old_t) * (CONF_COLLECTION_MAXSITE + 1)))
			{
				cerr << "Inconsistency in site_t:" << endl;
				cerr << "- Distributed          : " << inst << endl;
				cerr << "- Sizeof(site_t)       : " << sizeof(site_t) << endl;
				cerr << "- Sizeof(site_old_t)   : " << sizeof(site_old_t) << endl;
				cerr << "- Maxsites             : " << CONF_COLLECTION_MAXSITE << endl;
				cerr << "- Size of current file : " << (internal_long_uint_t)(statbuf.st_size) << endl;
				cerr << "- Expected size        : " << (sizeof(site_t) * (CONF_COLLECTION_MAXSITE + 1)) << endl;
				die("Inconsistency in site_t on instance %lu", (unsigned long int)inst);
			}
			else
				convert_old_site_file(filename, false);
		}

		if (m->readonly)
			m->distributed[inst].file_site = open64(filename, O_RDONLY);
		else
			m->distributed[inst].file_site = open64(filename, O_RDWR, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (errno != 0)
			die("Meta ddx_open: couldn't open site file %s on %s\n", cberr(), filename);

		// Read the header site
		assert(lseek(m->distributed[inst].file_site, (off64_t)0, SEEK_SET) == 0);

		if (errno != 0)
			die("Meta ddx_open: couldn't seek site file %s on %s\n", cberr(), filename);

		site_t site_header;
		assert(read(m->distributed[inst].file_site, &(site_header), sizeof(site_t)) == sizeof(site_t));

		if (errno != 0)
			die("Meta ddx_open: couldn't read site file %s on %s\n", cberr(), filename);

		// Read data from it
		m->distributed[inst].count_site = site_header.siteid;
	}
	else
	{
		// Check readonly
		if (m->readonly)
			die("Couldn't create index: readonly mode enabled");

		// Create file
		m->distributed[inst].file_site = open64(filename, O_RDWR|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (m->distributed[inst].file_site == -1 && errno != 0)
			die("Meta ddx_open: couldn't open site file %s on %s\n", cberr(), filename);

		site_t site;

		memset(&site, 0, sizeof(site_t));

		for(siteid_t is = 0; is <= CONF_COLLECTION_MAXSITE; is++)
			write(m->distributed[inst].file_site, &site, sizeof(site_t));

		// Initialize
		m->distributed[inst].count_site = 0;
	}

	// Go ahead to documents .... Create or open filename
	sprintf(filename, "%s/%s", m->distributed[inst].dirname, METADDX_FILENAME_OPTMASK_SITE);

	if (stat64(filename, &statbuf) == 0)
	{
/*		// Verify file size
		if ((internal_long_uint_t)(statbuf.st_size) != (sizeof(site_t) * CONF_COLLECTION_MAXSITE))
		{
			if ((internal_long_uint_t)(statbuf.st_size) != (sizeof(site_old_t) * CONF_COLLECTION_MAXSITE))
			{
				cerr << "Inconsistency in site_t:" << endl;
				cerr << "- Distributed          : " << inst << endl;
				cerr << "- Sizeof(site_t)       : " << sizeof(site_t) << endl;
				cerr << "- Sizeof(site_old_t)   : " << sizeof(site_old_t) << endl;
				cerr << "- Maxsites             : " << CONF_COLLECTION_MAXSITE << endl;
				cerr << "- Size of current file : " << (internal_long_uint_t)(statbuf.st_size) << endl;
				cerr << "- Expected size        : " << sizeof(site_t) * CONF_COLLECTION_MAXSITE << endl;
				die("Inconsistency in site_t on instance %lu", (unsigned long int)inst);
			}
			else
				convert_old_site_file(filename, false);
		}
*/
		if (m->readonly)
		{
			m->distributed[inst].optmask_site = CBALLOC(atomic<site_options_t>, CALLOC, CONF_COLLECTION_MAXSITE);

			m->distributed[inst].file_optmask_site = open64(filename, O_RDONLY);

			if (errno != 0)
				die("Meta ddx_open: couldn't open optmask site file %s on %s\n", cberr(), filename);

			siteid_t opt_readed = read(m->distributed[inst].file_optmask_site, m->distributed[inst].optmask_site, (sizeof(atomic<site_options_t>) * CONF_COLLECTION_MAXSITE));
    		assert(opt_readed == CONF_COLLECTION_MAXSITE);

			int rc = close(m->distributed[inst].file_optmask_site);
			m->distributed[inst].file_optmask_site = -1;

			if (errno != 0)
				die("Meta ddx_open: couldn't close optmask site file %s on %s\n", cberr(), filename);

	        assert(rc == 0);

		}
		else
		{
			m->distributed[inst].optmask_site = CBALLOC(atomic<site_options_t>, CALLOC, CONF_COLLECTION_MAXSITE);

			m->distributed[inst].file_optmask_site = open64(filename, O_RDWR, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

			if (errno != 0)
				die("Meta ddx_open: couldn't open optmask site file %s on %s\n", cberr(), filename);

			siteid_t opt_readed = read(m->distributed[inst].file_optmask_site, m->distributed[inst].optmask_site, (sizeof(atomic<site_options_t>) * CONF_COLLECTION_MAXSITE));
    		assert(opt_readed == CONF_COLLECTION_MAXSITE);
		}
	}
	else
	{
		// Check readonly
		if (m->readonly)
			die("Couldn't create index: readonly mode enabled");

		// Prepare buffer for options of sites
		m->distributed[inst].optmask_site = CBALLOC(atomic<site_options_t>, CALLOC, CONF_COLLECTION_MAXSITE);

		// set default site options
		site_options_t options = SITE_OPT_FALSE;

		options += SITE_OPT_DENY;
		options += SITE_OPT_NEW;

		for(siteid_t address = 0; address < CONF_COLLECTION_MAXSITE; address++)
			m->distributed[inst].optmask_site[address] = options;

		// Create file
		m->distributed[inst].file_optmask_site = open64(filename, O_RDWR|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (m->distributed[inst].file_optmask_site == -1 && errno != 0)
			die("Meta ddx_open: couldn't open optmask site file %s on %s\n", cberr(), filename);
	}

	// Go ahead to documents .... Create or open filename
	sprintf(filename, "%s/%s", m->distributed[inst].dirname, METADDX_FILENAME_DOC);

	// Check if file exists
	if(stat64(filename, &statbuf) == 0)
	{
		// Verify file size
		if ((internal_long_uint_t)(statbuf.st_size) != (sizeof(doc_t) * (CONF_COLLECTION_MAXDOC + 1)))
		{
			if ((internal_long_uint_t)(statbuf.st_size) != (sizeof(doc_old_t) * (CONF_COLLECTION_MAXDOC + 1)))
			{
				cerr << "Inconsistency in doc_t:" << endl;
				cerr << "- Distributed          : " << inst << endl;
				cerr << "- Sizeof(doc_t)        : " << sizeof(doc_t) << endl;
				cerr << "- Sizeof(doc_old_t)    : " << sizeof(doc_old_t) << endl;
				cerr << "- Maxdocs              : " << CONF_COLLECTION_MAXDOC << endl;
				cerr << "- Size of current file : " << (internal_long_uint_t)(statbuf.st_size) << endl;
				cerr << "- Expected size        : " << (sizeof(doc_t) * (CONF_COLLECTION_MAXDOC + 1)) << endl;
				die("Inconsistency in doc_t on instance %lu", (unsigned long int)inst);
				// cerr << "The size of the file of metadata of documents is wrong" << endl;
				// cerr << "Probably you changed maxdoc in the configuration" << endl;
				// cerr << "Or the version of CBOT is wrong" << endl;
				// die("Inconsistency in the size of doc_t");
			}
			else
				convert_old_doc_file(filename, false);
		}

		if (m->readonly)
			m->distributed[inst].file_doc = open64(filename, O_RDONLY);
		else
			m->distributed[inst].file_doc = open64(filename, O_RDWR, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (errno != 0)
			die("Meta ddx_open: couldn't open doc file %s on %s\n", cberr(), filename);

		// Read the header document
		assert(lseek(m->distributed[inst].file_doc, (off64_t)0, SEEK_SET) == 0);

		if (errno != 0)
			die("Meta ddx_open: couldn't seek doc file %s on %s\n", cberr(), filename);

		doc_t doc_header;
		assert(read(m->distributed[inst].file_doc, &(doc_header), sizeof(doc_t)) == sizeof(doc_t));

		if (errno != 0)
			die("Meta ddx_open: couldn't read doc file %s on %s\n", cberr(), filename);

		// Read data from it
		m->distributed[inst].count_doc = doc_header.docid;
	}
	else
	{

		// Check readonly
		if(m->readonly)
			die("Couldn't create index: readonly mode enabled");

		// Create file
		m->distributed[inst].file_doc = open64(filename, O_RDWR|O_CREAT, S_IREAD|S_IWRITE|S_IRGRP|S_IROTH); // Open read/write

		if (m->distributed[inst].file_doc == -1 && errno != 0)
			die("Meta ddx_open: couldn't open doc file %s on %s\n", cberr(), filename);

		doc_t doc;

		memset(&doc, 0, sizeof(doc_t));

		for(docid_t is = 0; is <= CONF_COLLECTION_MAXDOC; is++)
			write(m->distributed[inst].file_doc, &doc, sizeof(doc_t));

		// Initialize data
		m->distributed[inst].count_doc = 0;
	}

	arguments->d = NULL;
	return NULL;
}

//
// Name: ddx_close
//
// Description:
//   Closes a structure. Writes data to disk.
//
// Input:
//   metaddx - the metaddx structure
//
// Return: 
//   status code
//
metaddx_status_t Meta::ddx_close(void)
{
	if (thread_alarm != THREADS_OK)
	    return METADDX_ERROR;

	pthread_t *threads = NULL;

	if (CONF_COLLECTION_DISTRIBUTED > 1)
		threads = CBALLOC(pthread_t, MALLOC, CONF_COLLECTION_DISTRIBUTED);

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		Meta::thread_args_t *args = CBALLOC(Meta::thread_args_t, MALLOC, 1);
	    args->inst = inst;
    	args->obj = this;
		args->d = NULL;
		args->f = META_CLOSE;

		if (CONF_COLLECTION_DISTRIBUTED > 1)
		{
			if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
				die("error creating thread!");
		}
		else
			thread_function_close((void *) args); // if only one distribution, function is call without thread
	}

	if (CONF_COLLECTION_DISTRIBUTED > 1)
	{
		CBotjoin(threads, CONF_COLLECTION_DISTRIBUTED);

		free(threads);
	}

	// Free
	free(m->distributed);
	delete [] m; m = NULL;

	return METADDX_OK;
}

//
// Name: thread_function_close
//
// Description: invoked by 'metaddx_close' as thread
//
// Arguments: a void pointer to Meta::thread_args_t type structure that contain instance and metaddx_t type structure 
//
// Return: NULL
//
void *Meta::thread_function_close(void *args)
{
	cpu_set_t system_cpus;

	Meta::thread_args_t *arguments = (Meta::thread_args_t *)args;

	instance_t inst = arguments->inst;

	CPU_OPTIMIZE;

	Meta *obj = arguments->obj;
	assert(obj->m != NULL);
	metaddx_t *m = obj->m;

	int rc = 0;

	errno = 0; // errno is thread-local

	// check if file descriptors are valid
	rc = fcntl(m->distributed[inst].file_site, F_GETFL);

	if (errno != 0)
		die("Meta ddx_close: sites do not have a valid file descriptor %s\n", cberr());

	if (rc == 1)
		die("Meta ddx_close: sites do not have a valid file descriptor (%d)\n", rc);

	rc = fcntl(m->distributed[inst].file_doc, F_GETFL);

	if (errno != 0)
		die("Meta ddx_close: documents do not have a valid file descriptor %s\n", cberr());

	if (rc == 1)
		die("Meta ddx_close: documents do not have a valid file descriptor (%d)\n", rc);

	if (m->readonly == true)
	{
		rc = close(m->distributed[inst].file_site);

		if (errno != 0)
			die("Meta ddx_close: error closing site file descriptor %s\n", cberr());

		if (rc != 0)
			die("Meta ddx_close: couldn't close site file because return invalid status");

		m->distributed[inst].file_site = 0;

		// free optmask buffer
		free(m->distributed[inst].optmask_site);
		m->distributed[inst].optmask_site = NULL;

		rc = close(m->distributed[inst].file_doc);

		if (errno != 0)
			die("Meta ddx_close: error closing doc file descriptor %s\n", cberr());

		if (rc != 0)
			die("Meta ddx_close: couldn't close doc file because return invalid status");

		m->distributed[inst].file_doc = 0;

			return NULL;
	}

	site_t site_header;
	memset(&site_header, 0, sizeof(site_t));
	doc_t doc_header;
	memset(&doc_header, 0, sizeof(doc_t));

	// Generate data for headers
	site_header.siteid = m->distributed[inst].count_site;
	doc_header.docid   = m->distributed[inst].count_doc;

	// Write headers
	assert(lseek(m->distributed[inst].file_site, (off64_t)0, SEEK_SET) == 0);

	if (errno != 0)
		die("Meta ddx_close: couldn't seek site file %s\n", cberr());

	assert(write(m->distributed[inst].file_site, &(site_header), sizeof(site_t)) == sizeof(site_t));

	if (errno != 0)
		die("Meta ddx_close: couldn't write site file %s\n", cberr());

	// Save buffer of site's options to disk
	assert(lseek(m->distributed[inst].file_optmask_site, (off64_t)0, SEEK_SET) == 0);

	assert(m->distributed[inst].file_optmask_site != -1);
	siteid_t opt_written = write(m->distributed[inst].file_optmask_site, m->distributed[inst].optmask_site, (sizeof(atomic<site_options_t>) * CONF_COLLECTION_MAXSITE));
   	assert(opt_written == (sizeof(atomic<site_options_t>) * CONF_COLLECTION_MAXSITE));

	// free optmask buffer
	free(m->distributed[inst].optmask_site);
	m->distributed[inst].optmask_site = NULL;

	// close optmask file
	rc = close(m->distributed[inst].file_optmask_site);

	if (errno != 0)
		die("Meta ddx_close: couldn't close optmask site file %s\n", cberr());

	if (rc != 0)
		die("Meta ddx_close: couldn't close optmask site file because return invalid status");

	m->distributed[inst].file_optmask_site = 0;

	assert(lseek(m->distributed[inst].file_doc, (off64_t)0, SEEK_SET) == 0);

	if (errno != 0)
		die("Meta ddx_close: couldn't seek doc file %s\n", cberr());

	assert(write(m->distributed[inst].file_doc, &(doc_header), sizeof(doc_t)) == sizeof(doc_t));

	if (errno != 0)
		die("Meta ddx_close: couldn't write doc file %s\n", cberr());

	// Test if there is corruption
	if(m->distributed[inst].count_site > 1)
	{
		site_t test;
		test.siteid = (siteid_t)(inst + 1);

		int rc = site_retrieve(m, &(test));

		if(rc != METADDX_OK)
			die("Meta ddx_close: corruption at closing time, the Meta.has more than 1 siteid but metadata of site 1 can not be read!");

		if(test.siteid != (siteid_t)(inst + 1))
			die("Meta ddx_close: corruption at closing time, document 1 was read but had the wrong docid!");
	}

	// Test if there is corruption
	if(m->distributed[inst].count_doc > 1)
	{
		doc_t test;
		test.docid = (docid_t)(inst + 1);

		int rc = doc_retrieve(m, &(test));
		if(rc != METADDX_OK)
			die("Meta ddx_close: corruption at closing time, the Meta.has more than 1 docid but metadata of document 1 can not be read!");

		if(test.docid != (docid_t)(inst + 1))
			die("Meta ddx_close: corruption at closing time, document 1 was read but had the wrong docid!");
	}
/*
	rc = fsync(m->distributed[inst].file_site);

	if (errno != 0)
		die("Meta ddx_close: error syncing site file descriptor %s\n", cberr());

	assert(rc == 0);
*/
	rc = close(m->distributed[inst].file_site);

	if (errno != 0)
		die("Meta ddx_close: error closing site file descriptor %s\n", cberr());

	if (rc != 0)
		die("Meta ddx_close: couldn't close site file because return invalid status");

	m->distributed[inst].file_site = 0;
/*
	rc = fsync(m->distributed[inst].file_doc);

	if (errno != 0)
		die("Meta ddx_close: error syncing doc file descriptor %s\n", cberr());

	assert(rc == 0);
*/
	rc = close(m->distributed[inst].file_doc);

	if (errno != 0)
		die("Meta ddx_close: error closing doc file descriptor %s\n", cberr());

	if (rc != 0)
		die("Meta ddx_close: couldn't close doc file because return invalid status");

	m->distributed[inst].file_doc = 0;

	return NULL;
}

//
// Name: ddx_remove
//
// Description:
//   Removes files into directories metaddx0, metaddx1... and optionally metaddx0, metaddx1... (unneeded)
//
// Input:
//   

void Meta::ddx_remove(void)
{
//	if (thread_alarm != THREADS_OK)
//		return;

	struct stat64 statbuf;

	pthread_t *threads = NULL;

	instance_t max_instances = 0;

	// check how many directory contain data to delete
	for (instance_t inst = 0; inst < ((instance_t)(~0)); inst++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, this->dirname, inst);

		if (stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
			max_instances++;
		else
		{
			free(relative_rem_path);
			break;
		}

		free(relative_rem_path);
	}

	if (max_instances > 1)
	{
		threads = CBALLOC(pthread_t, MALLOC, max_instances);

		for (instance_t inst = 0; inst < max_instances; inst++)
		{
			Meta::thread_args_t *args = CBALLOC(Meta::thread_args_t, MALLOC, 1);
		    args->inst = inst;
    		args->obj = NULL;
			args->d = (char *)this->dirname;
			args->f = META_REMOVE;

			if (max_instances > 1)
			{
				if (pthread_create(&threads[inst], NULL, thread_function_caller, (void *) args))
					die("error creating thread!");
			}
			else
				thread_function_remove((void *) args); // only one distribution, function is call without thread 
		}

		CBotjoin(threads, max_instances);

		free(threads);
	}
}

//
// Name: thread_function_remove
//
// Description: invoked by 'metaddx_remove' as thread
//
// Arguments: a void pointer to Meta::thread_args_t type structure 
//
// Return: NULL
//
void *Meta::thread_function_remove(void *args)
{
	cpu_set_t system_cpus;

	Meta::thread_args_t *arguments = (Meta::thread_args_t *)args;

	instance_t inst = arguments->inst;

//	CPU_OPTIMIZE;

	char *dirname = arguments->d;
	char *relative_rem_path = DataRetention::make(DataRetention::REMDR, dirname, inst);

	queue<string> files;

	// Push files
	files.push(METADDX_FILENAME_OPTMASK_SITE);
	files.push(METADDX_FILENAME_SITE);
	files.push(METADDX_FILENAME_DOC);

	errno = 0; // errno is thread-local

	// Delete
	while(! files.empty()) {

		// Create filename
		char filename[MAX_STR_LEN];
		sprintf(filename, "%s/%s", relative_rem_path, files.front().c_str());

		// Delete file
		int rc = unlink(filename);

		if(rc != 0 && errno != ENOENT)
			die("Couldn't unlink file %s %s", files.front().c_str(), cberr());

		// Remove file from queue
		files.pop();
	}

	errno = 0; // errno is thread-local

	if (inst >= CONF_COLLECTION_DISTRIBUTED)
	{
		// Delete dir (rimuove le directory metadata0, metadata1 ecc..)
		int rc = remove(relative_rem_path);

		if(rc != 0 && errno != ENOENT)
		{
			mcerr << RED << relative_rem_path << ' ' << cberr() << NOR << mendl; 
			// die("Couldn't remove directory");
		}
	}

	free(relative_rem_path);

	arguments->d = NULL;

	return NULL;
}

//
// Name: site_store
//
// Description:
//   Stores information about a site
//
// Input:
//    site - the site to be stored
// 
// Return:
//    status code
//
metaddx_status_t Meta::site_store(site_t *site)
{
	assert(site->siteid > 0);
	assert(site->domainid > 0);
	assert(site->siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));
	assert((site->domainid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED)) || (site->domainid > CONF_MAX_TWOLEVELDOMAINID));
	assert(!m->readonly);

	instance_t inst =	((site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t id_offset = (((site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	off64_t address = (off64_t)(sizeof(site_t) * id_offset);

	errno = 0; // errno is thread-local

	// Store
	ssize_t wr = pwrite64(m->distributed[inst].file_site, site, sizeof(site_t), address);

	if (errno != 0)
		die("Meta site_store: for siteid %llu couldn't write file (address %llu) %s\n", site->siteid, (unsigned long long int)address, cberr());

	assert(wr == (ssize_t)(sizeof(site_t)));

	// Update distributed count
	if (id_offset > m->distributed[inst].count_site)
		m->distributed[inst].count_site = id_offset;

	siteid_t check = m->count_site;

	// Update the counter in thread-safe mode
	while (true)
	{
		if (site->siteid > check)
		{	// if counter have value expected as 'check' it can be updated
			if (m->count_site.compare_exchange_strong(check, site->siteid) == true)
				break;
			else // else, check have new counter value updated from other threads during 'compare_exchange_strong' call
				continue;
		}
		else
			break;
	}

	return METADDX_OK;
}

//
// Name: site_store_buffered
//
// Description:
//   Stores information about a siteument
//
// Input:
//    metaddx - the metaddx structure
//    site - the siteument to be stored
//    old_site - the 'old_site' to be compared with the new (only update)
// 
// Return:
//    status code
//
metaddx_status_t Meta::site_store_buffered(site_t *sites, size_t size)
{
	assert(! m->readonly);
	assert(size > 0);

	for (size_t o = 0; o < size; o++)
	{
		assert(sites[o].siteid > 0);
		assert(sites[o].domainid > 0);
		assert(sites[o].siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));
		assert((sites[o].domainid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED)) || (sites[o].domainid > CONF_MAX_TWOLEVELDOMAINID));
	}

	instance_t inst = ((sites[0].siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t id_offset = (((sites[0].siteid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// Seek
	off64_t address = ((off64_t)sizeof(site_t)) * id_offset;

	errno = 0; // errno is thread-local

	// Store
	ssize_t wr = pwrite64(m->distributed[inst].file_site, sites, (sizeof(site_t) * size), address);

	if (errno != 0)
		die("Meta site_store_buffered: couldn't write file (address %llu) %s\n", (unsigned long long int)address, cberr());

	assert(wr == (ssize_t)((sizeof(site_t) * size)));

	// Update distributed count
	if ((id_offset + size - 1) > m->distributed[inst].count_site)
		m->distributed[inst].count_site = (id_offset + size);

	siteid_t check = m->count_site;

	// Update the counter in thread-safe mode
	while (true)
	{
		if (sites[(size - 1)].siteid > check)
		{	// if counter have value expected as 'check' it can be updated
			if (m->count_site.compare_exchange_strong(check, sites[(size - 1)].siteid) == true)
				break;
			else // else, check have new counter value updated from other threads during 'compare_exchange_strong' call
				continue;
		}
		else
			break;
	}

	return METADDX_OK;
}

//
// Name: site_option_set
//
// Description:
//    store option information about a site
//    Warning: this function IS NOT thread safe but value is written atomically.
//    Cuncurrecy writing CANNOT set the same bit to different value (eg. one to true and other to false)
//
// Input:
//    siteid - the siteid
//    optmask - the site_optmask_t value
//    boolean - true or false
//
// Return:
//    status code
//
metaddx_status_t Meta::site_option_set(siteid_t siteid, site_optmask_t optmask, bool boolean)
{
	assert(m->readonly == false);

	assert(siteid > 0 && siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));

	instance_t inst =	((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t id_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

	off64_t address = (off64_t)(sizeof(site_options_t) * id_offset);

	assert(m->distributed[inst].optmask_site != NULL);

	if ((bool)((m->distributed[inst].optmask_site[address] / optmask) % 2) == boolean)
		return METADDX_OK; // already set
	else
	{
		while (((bool)((m->distributed[inst].optmask_site[address] / optmask) % 2) != boolean))
		{
			if (boolean == true)
				m->distributed[inst].optmask_site[address] += optmask;
			else
				m->distributed[inst].optmask_site[address] -= optmask;
		}

		// if another thread have not change bit value to opposite value during this operation, return ok
		if ((bool)((m->distributed[inst].optmask_site[address] / optmask) % 2) == boolean)
			return METADDX_OK;
	}

	return METADDX_ERROR;
}

// 
// Name: site_retrieve
//
// Description:
//   Retrieves information about a site
//   This function is use only from 'ddx_close'
//
// Input:
//   metaddx - metaindex holding the information
//   site.siteid - site id of the retrieved site
//
// Output:
//   site - site
//
// Return:
//
metaddx_status_t Meta::site_retrieve(metaddx_t *m, site_t *site)
{
	assert(site->siteid > 0);

	instance_t inst =	((site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t id_offset = (((site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	off64_t address = (off64_t)(sizeof(site_t) * id_offset);

	// See if it's inside the range
	if (id_offset > m->distributed[inst].count_site)
		return METADDX_EOF;

	errno = 0; // errno is thread-local

	// Retrieve
	ssize_t wr = pread64(m->distributed[inst].file_site, site, sizeof(site_t), address);

	if (errno != 0)
		die("Meta site_retrieve: for siteid %llu couldn't read file %s\n", site->siteid, cberr());

	assert(wr == (ssize_t)(sizeof(site_t)));

	assert(site->siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));

	if (site->siteid == 0)
		return METADDX_EOF;

	return METADDX_OK;
}

// 
// Name: site_retrieve
//
// Description:
//   Retrieves information about a site
//
// Input:
//   site.siteid - site id of the retrieved site
//
// Output:
//   site - site
//
// Return:
//
metaddx_status_t Meta::site_retrieve(site_t *site)
{
	assert(site->siteid > 0);

	instance_t inst =	((site->siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t id_offset = (((site->siteid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	off64_t address = (off64_t)(sizeof(site_t) * id_offset);

	// See if it's inside the range
	if (id_offset > m->distributed[inst].count_site)
		return METADDX_EOF;

	errno = 0; // errno is thread-local

	// Retrieve
	ssize_t rd = pread64(m->distributed[inst].file_site, site, sizeof(site_t), address);

	if (errno != 0)
		die("Meta site_retrieve: for siteid %llu couldn't read file %s\n", site->siteid, cberr());

	assert(rd == (ssize_t)(sizeof(site_t)));

	assert(site->siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));

	if (site->siteid == 0)
		return METADDX_EOF;

	return METADDX_OK;
}

// 
// Name: site_retrieve_buffered
//
// Description:
//   Retrieves information about a siteument
//
// Input:
//   site.siteid - siteument id of the retrieved siteument
//
// Output:
//   site - siteument
//
// Return:
//   METADDX_OK - success
//   METADDX_EOF - siteid out of range
//
metaddx_status_t Meta::site_retrieve_buffered(site_t *sites, size_t size)
{
	assert(sites[0].siteid > 0);
	assert(size > 1);

	instance_t inst =	((sites[0].siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t id_offset = (((sites[0].siteid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// Seek
	off64_t address = ((off64_t)sizeof(site_t)) * id_offset;

	// See if last it's inside the range
	if ((id_offset + size - 1) > m->distributed[inst].count_site)
		return METADDX_EOF;

	errno = 0; // errno is thread-local

	// Retrieve
	ssize_t rd = pread64(m->distributed[inst].file_site, sites, (sizeof(site_t) * size), address);

	if (errno != 0)
		die("Meta site_retrieve_buffered: couldn't read file %s\n", cberr());

	assert(rd == (ssize_t)((sizeof(site_t) * size)));

	for (size_t o = 0; o < size; o++)
	{
		assert(sites[o].siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));
		assert((sites[o].domainid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED)) || (sites[o].domainid > CONF_MAX_TWOLEVELDOMAINID));

		if (sites[o].siteid == 0)
			return METADDX_EOF;
	}

	return METADDX_OK;
}

//
// Name: site_option_get
//
// Description:
//    retrieve option information about a site
//    Warning: this function IS NOT thread safe but value is written atomically.
//
// Input:
//    siteid - the siteid
//    optmask - the site_optmask_t value
//    boolean - the expected value
//
// Return:
//    status code
//
metaddx_status_t Meta::site_option_get(siteid_t siteid, site_optmask_t optmask, bool boolean)
{
	assert(siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));

	instance_t inst =	((siteid - 1) % CONF_COLLECTION_DISTRIBUTED);
	siteid_t id_offset = ((siteid - 1) / CONF_COLLECTION_DISTRIBUTED);

	off64_t address = (off64_t)(sizeof(site_options_t) * id_offset);

	if (m->readonly == true)
	{
		if ((bool)((m->distributed[inst].optmask_site[address].load(memory_order_relaxed) / optmask) % 2) == boolean) // using 'memory_order_relaxed' for R0 operations
			return METADDX_OK;
	}
	else
	{
		if ((bool)((m->distributed[inst].optmask_site[address] / optmask) % 2) == boolean)
			return METADDX_OK;
	}

	return METADDX_KO;
}

//
// Name: doc_store
//
// Description:
//   Stores information about a document
//   With 'old_doc' it compare byte to byte struct before write to disk (performances reasons).
//
// Input:
//    metaddx - the metaddx structure
//    doc - the document to be stored
//    old_doc - the 'old_doc' to be compared with the new (only update)
// 
// Return:
//    status code
//
metaddx_status_t Meta::doc_store(doc_t *doc)
{
	assert(!m->readonly);

	assert(doc->docid > 0);
	assert(doc->siteid > 0);
	assert(doc->docid <= (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));
	assert(doc->siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));

	instance_t inst =	((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = (((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// Seek
	off64_t address = ((off64_t)sizeof(doc_t)) * id_offset;

	errno = 0; // errno is thread-local

	// Store
	ssize_t wr = pwrite64(m->distributed[inst].file_doc, doc, sizeof(doc_t), address);

	if (errno != 0)
		die("Meta doc_store: for docid %llu couldn't write file (address %llu) %s\n", doc->docid, (unsigned long long int)address, cberr());

	assert(wr == (ssize_t)(sizeof(doc_t)));

	// Update distributed count
	if (id_offset > m->distributed[inst].count_doc)
		m->distributed[inst].count_doc = id_offset;

	docid_t check = m->count_doc;

	// Update the counter in thread-safe mode
	while (true)
	{
		if (doc->docid > check)
		{	// if counter have value expected as 'check' it can be updated
			if (m->count_doc.compare_exchange_strong(check, doc->docid) == true)
				break;
			else // else, check have new counter value updated from other threads during 'compare_exchange_strong' call
				continue;
		}
		else
			break;
	}

	return METADDX_OK;
}

//
// Name: doc_store_buffered
//
// Description:
//   Stores information about a document
//   With 'old_doc' it compare byte to byte struct before write to disk (performances reasons).
//
// Input:
//    metaddx - the metaddx structure
//    doc - the document to be stored
//    old_doc - the 'old_doc' to be compared with the new (only update)
// 
// Return:
//    status code
//
metaddx_status_t Meta::doc_store_buffered(doc_t *docs, size_t size)
{
	assert(! m->readonly);
	assert(size > 0);

	for (size_t o = 0; o < size; o++)
	{
		assert(docs[o].docid > 0);
		assert(docs[o].siteid > 0);
		assert(docs[o].docid <= (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));
		assert(docs[o].siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));
	}

	instance_t inst = ((docs[0].docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = (((docs[0].docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// Seek
	off64_t address = ((off64_t)sizeof(doc_t)) * id_offset;

	errno = 0; // errno is thread-local

	// Store
	ssize_t wr = pwrite64(m->distributed[inst].file_doc, docs, (sizeof(doc_t) * size), address);

	if (errno != 0)
		die("Meta doc_store_buffered: couldn't write file (address %llu) %s\n", (unsigned long long int)address, cberr());

	assert(wr == (ssize_t)((sizeof(doc_t) * size)));

	// Update distributed count
	if ((id_offset + size - 1) > m->distributed[inst].count_doc)
		m->distributed[inst].count_doc = (id_offset + size);

	docid_t check = m->count_doc;

	// Update the counter in thread-safe mode
	while (true)
	{
		if (docs[(size - 1)].docid > check)
		{	// if counter have value expected as 'check' it can be updated
			if (m->count_doc.compare_exchange_strong(check, docs[(size - 1)].docid) == true)
				break;
			else // else, check have new counter value updated from other threads during 'compare_exchange_strong' call
				continue;
		}
		else
			break;
	}

	return METADDX_OK;
}

// 
// Name: doc_retrieve
//
// Description:
//   Retrieves information about a document
//   This function is use only from 'ddx_close'
//
// Input:
//   metaddx - metaindex holding the information
//   doc.docid - document id of the retrieved document
//
// Output:
//   doc - document
//
// Return:
//   METADDX_OK - success
//   METADDX_EOF - docid out of range
//
metaddx_status_t Meta::doc_retrieve(metaddx_t *m, doc_t *doc)
{
	assert(doc->docid > 0);

	instance_t inst =	((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = (((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// Seek
	off64_t address = ((off64_t)sizeof(doc_t)) * id_offset;

	// See if it's inside the range
	if (id_offset > m->distributed[inst].count_doc)
		return METADDX_EOF;

	errno = 0; // errno is thread-local

	// Retrieve
	ssize_t wr = pread64(m->distributed[inst].file_doc, doc, sizeof(doc_t), address);

	if (errno != 0)
		die("Meta doc_retrieve: for docid %llu couldn't read file %s\n", doc->docid, cberr());

	assert(wr == (ssize_t)(sizeof(doc_t)));

	assert(doc->docid <= (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));
	assert(doc->siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));

	if(doc->docid == 0)
		return METADDX_EOF;

	return METADDX_OK;
}

// 
// Name: doc_retrieve
//
// Description:
//   Retrieves information about a document
//
// Input:
//   doc.docid - document id of the retrieved document
//
// Output:
//   doc - document
//
// Return:
//   METADDX_OK - success
//   METADDX_EOF - docid out of range
//
metaddx_status_t Meta::doc_retrieve(doc_t *doc)
{
	assert(doc->docid > 0);

	instance_t inst =	((doc->docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = (((doc->docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// Seek
	off64_t address = ((off64_t)sizeof(doc_t)) * id_offset;

	// See if it's inside the range
	if (id_offset > m->distributed[inst].count_doc)
		return METADDX_EOF;

	errno = 0; // errno is thread-local

	// Retrieve
	ssize_t rd = pread64(m->distributed[inst].file_doc, doc, sizeof(doc_t), address);

	if (errno != 0)
		die("Meta doc_retrieve: for docid %llu couldn't read file %s\n", doc->docid, cberr());

	assert(rd == (ssize_t)(sizeof(doc_t)));

	assert(doc->docid <= (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));
	assert(doc->siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));

	if(doc->docid == 0)
		return METADDX_EOF;

	return METADDX_OK;
}

// 
// Name: doc_retrieve_buffered
//
// Description:
//   Retrieves information about a document
//
// Input:
//   doc.docid - document id of the retrieved document
//
// Output:
//   doc - document
//
// Return:
//   METADDX_OK - success
//   METADDX_EOF - docid out of range
//
metaddx_status_t Meta::doc_retrieve_buffered(doc_t *docs, size_t size)
{
	assert(docs[0].docid > 0);
	assert(size > 1);

	instance_t inst =	((docs[0].docid - 1) % CONF_COLLECTION_DISTRIBUTED);
	docid_t id_offset = (((docs[0].docid - 1) / CONF_COLLECTION_DISTRIBUTED) + 1);

	// Seek
	off64_t address = ((off64_t)sizeof(doc_t)) * id_offset;

	// See if last it's inside the range
	if ((id_offset + size - 1) > m->distributed[inst].count_doc)
		return METADDX_EOF;

	errno = 0; // errno is thread-local

	// Retrieve
	ssize_t rd = pread64(m->distributed[inst].file_doc, docs, (sizeof(doc_t) * size), address);

	if (errno != 0)
		die("Meta doc_retrieve_buffered: couldn't read file %s\n", cberr());

	assert(rd == (ssize_t)((sizeof(doc_t) * size)));

	for (size_t o = 0; o < size; o++)
	{
		assert(docs[o].docid <= (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED));
		assert(docs[o].siteid <= (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED));

		if (docs[o].docid == 0)
			return METADDX_EOF;
	}

	return METADDX_OK;
}

//
// Name: site_count
//
// Description: Get number of sites in metaddx
//   
// Input:
//
// Return: Number of sites in metaddx
//

siteid_t Meta::site_count (void) const
{
	return m->count_site;
}

//
// Name: instance_site_count
//
// Description: Get number of sites in metaddx for a instance
//   
// Input: instance number
//
// Return: Number of sites in metaddx
//

siteid_t Meta::instance_site_count (instance_t &inst) const
{
	return m->distributed[inst].count_site;
}

//
// Name: doc_count
//
// Description: Get number of docs in metaddx
//   
// Input:
//
// Return: Number of docs in metaddx
//

docid_t Meta::doc_count (void) const
{
	return m->count_doc;
}

//
// Name: doc_count
//
// Description: Get number of docs in metaddx for a instance
//   
// Input: instance number
//
// Return: Number of docs in metaddx
//

docid_t Meta::instance_doc_count (instance_t &inst) const
{
	return m->distributed[inst].count_doc;
}

// 
// Name: dump_doc_status
//
// Description:
//   Prints the status of a document
//
// Input:
//   doc - document
//

void Meta::dump_doc_status(doc_t *doc)
{
	// Main variables
	cerr << "docid                 " << doc->docid << endl;
	cerr << "siteid                " << doc->siteid << endl;
	cerr << "domainid              " << doc->domainid << endl;
	cerr << "status                " << DOC_STATUS_STR(doc->status) << endl;
	cerr << "mime_type             " << MIME_TYPE_STR(doc->mime_type) << endl;

	// Harvester
	cerr << "http_status           " << doc->http_status
		<< " (" << HTTP_STR(doc->http_status) << ": "
		<<	HTTP_IS_STR(doc->http_status) << ")" << endl;
	cerr << "raw_content_length    " << doc->raw_content_length << endl;
	cerr << "effective_speed       " << doc->effective_speed << " bytes/sec" << endl;
	cerr << "latency               " << doc->latency << " sec" << endl;
	cerr << "latency_connect       " << doc->latency_connect << " sec" << endl;
	cerr << "number_visits         " << doc->number_visits << endl;
	cerr << "number_visits_changed " << doc->number_visits_changed << endl;
	cerr << "time_unchanged        " << doc->time_unchanged << " sec" << endl;
	cerr << "first_visit           " << ctime(&(doc->first_visit));
	cerr << "last_visit            " << ctime(&(doc->last_visit));
	cerr << "last_modified         " << ctime(&(doc->last_modified));

	// Gatherer
	cerr << "content_length        " << doc->content_length << endl;
	cerr << "hash_value_links      " << ((doc->hash_value_links == CONF_HASH_DOC_MAX_DEFINITIVE) ? (doc_hash_t)0 : doc->hash_value_links) << endl;
	cerr << "duplicate_of          " << doc->duplicate_of << endl;
	cerr << "content_encoding      " << CONTENT_ENCODING_STR(doc->content_encoding) << endl;
	cerr << "last_modified_credits " << (int)doc->last_modified_credits << endl;

	// Seeder
	cerr << "depth                 " << doc->depth << endl;
	cerr << "is_dynamic            " << (doc->is_dynamic ?"yes":"no")<< endl;

	// Manager
	cerr << "in_degree             " << doc->in_degree << endl;
	cerr << "pagerank              " << doc->pagerank << endl;
	cerr << "wlrank                " << doc->wlrank << endl;
	cerr << "hubrank               " << doc->hubrank << endl;
	cerr << "authrank              " << doc->authrank << endl;
	cerr << "liverank              " << doc->liverank << endl;
	cerr << "freshness             " << doc->freshness << endl;
	cerr << "current_score         " << doc->current_score << endl;
	cerr << "future_score          " << doc->future_score << endl;

	cerr << "charset               " << CHARSET_STR(doc->charset) << endl;

	if (doc->mime_type == MIME_TEXT_HTML)
	{
		if (doc->language != Language::UNKNOWN)
		{
			if (LANGUAGE_TO_STEMMING(doc->language) == Stemming::UNKNOWN)
				cerr << "language              " << LANGUAGE_STR(doc->language) << " (from meta tag)" << endl;
			else
				cerr << "language              " << LANGUAGE_STR(doc->language) << " (language detection)" << endl;
		}
	}
	else
		if (doc->language != Language::UNKNOWN)
			cerr << "language              " << LANGUAGE_STR(doc->language) << " (language detection)" << endl;

	cerr << "news                  " << (doc->from_feed ?"yes":"no")<< endl;

	if (doc->mime_type == MIME_ROBOTS_XML
		|| doc->mime_type == MIME_ROBOTS_XML_GZ
		|| doc->mime_type == MIME_FEEDS_ATOM_XML
		|| doc->mime_type == MIME_FEEDS_ATOM_XML_GZ
		|| doc->mime_type == MIME_FEEDS_RSS_XML
		|| doc->mime_type == MIME_FEEDS_RSS_XML_GZ)
		cerr << "has_valid_mimetype    " <<(doc->has_valid_mimetype ?"yes":"no")<< endl;

	if (doc->sitemap_changefreq != NONE)
	{
		cerr << "sitemap changefreq    " << CHANGEFREQ_STR(doc->sitemap_changefreq) << endl;

		cerr << "sitemap priority      ";
		switch ((int)(doc->sitemap_prio))
		{
			case -1:
				cerr << "0.5" << endl;
				break;
			case 0:
				cerr << "0.0" << endl;
				break;
			case 1:
				cerr << "0.1" << endl;
				break;
			case 2:
				cerr << "0.2" << endl;
				break;
			case 3:
				cerr << "0.3" << endl;
				break;
			case 4:
				cerr << "0.4" << endl;
				break;
			case 5: // N.B. 5 => "0.6"
				cerr << "0.6" << endl;
				break;
			case 6:
				cerr << "0.7" << endl;
				break;
			case 7:
				cerr << "0.8" << endl;
				break;
			case 8:
				cerr << "0.9" << endl;
				break;
			case 9:
				cerr << "1.0" << endl;
				break;
			default:
				cerr << "0.5" << endl;
				break;
		}
	}
}

// 
// Name: dump_doc_header
//
// Description:
//   Prints a line with the header data for dump_doc
//
// Input:
//   out - the output file handler
//

void Meta::dump_doc_header(FILE *out)
{
	assert(out != NULL);
	char buffer[MAX_STR_LEN];
    int wc = 0;
	
	// The order is very important. It must be consistent with dump_doc
	wc = snprintf(buffer, MAX_STR_LEN, "1docid,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "2siteid,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "3domainid,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "4status,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "5mime_type,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "6http_status,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "7raw_content_length,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "8effective_speed,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "9latency,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "10latency_connect,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "11number_visits,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "12number_visits_changed,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "13time_unchanged,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "14first_visit,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "15last_visit,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "16last_modified,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "17content_length,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "18duplicate_of,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "19content_encoding,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "20last_modified_credits,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "21depth,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "22is_dynamic,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "23in_degree,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "24out_degree,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "25pagerank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "26wlrank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "27hubrank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "28authrank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "29liverank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "30freshness,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "31current_score,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "32future_score,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "33from_feed,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "34has_valid_mimetype,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "35sitemap changefreq,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "36sitemap priority\n");

	fprintf(out, buffer);
}

// 
// Name: dump_doc
//
// Description:
//   Prints a line with the data about a document
//
// Input:
//   doc - document
//   out - the output file handler
//

void Meta::dump_doc(doc_t *doc, FILE *out)
{
	assert(doc != NULL);
	assert(out != NULL);

	char buffer[MAX_STR_LEN];
    int wc = 0;
	
	// The order is very important. It must be consistent with dump_doc_header
	wc = snprintf(buffer, MAX_STR_LEN, "%llu,",  (unsigned long long int)doc->docid);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,",  	(unsigned long int)doc->siteid);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,",  	(unsigned long int)doc->domainid);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->status));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->mime_type));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->http_status);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,",  	(long unsigned int)(doc->raw_content_length));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%f,",  	doc->effective_speed);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%f,",  	doc->latency);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%f,",  	doc->latency_connect);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->number_visits);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->number_visits_changed);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->time_unchanged));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->first_visit));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->last_visit));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->last_modified));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,",  	(long unsigned int)(doc->content_length));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,",  	(unsigned long int)doc->duplicate_of);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->content_encoding);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	(int)(doc->last_modified_credits));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->depth);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->is_dynamic);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->in_degree);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->out_degree);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->pagerank);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->wlrank);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->hubrank);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->authrank);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->liverank);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->freshness);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->current_score);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,",  	doc->future_score);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->from_feed);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->has_valid_mimetype);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,",  	doc->sitemap_changefreq);

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d\n",  	doc->sitemap_prio);

	fprintf(out, buffer);
}

// 
// Name: dump_doc_short_status
//
// Description:
//   Prints the status of a document in one line
//
// Input:
//   doc - document
//

void Meta::dump_doc_short_status(doc_t *doc)
{
	// Status
	cerr << DOC_STATUS_STR(doc->status) << " ";
	cerr << MIME_TYPE_STR(doc->mime_type) << " ";
	cerr << HTTP_STR(doc->http_status) << ":"
		<<	HTTP_IS_STR(doc->http_status) << " ";

	// Scores
	cerr << "in " << doc->in_degree << " ";
	cerr << "out " << doc->out_degree << " ";
	cerr << "pr " << doc->pagerank;
	cerr << "wl " << doc->wlrank;
	cerr << "lr " << doc->liverank;
}

// 
// Name: dump_site_status
//
// Description:
//   Prints the status of a site
//
// Input:
//   site
//

void Meta::dump_site_status(site_t *site)
{

	string proto;

	switch (site->protocol)
	{
		case HTTP:
			proto.assign("http");
			break;
		case HTTPS:
			proto.assign("https");
			break;
		case HTTP_TEMPORARY:
			proto.assign("http_temporary (this state is abnormal)"); // this can be only a volatile status
			break;
		case HTTPS_TEMPORARY:
			proto.assign("https_temporary (this state is abnormal"); // this can be only a volatile status
			break;
		case NOT_DEFINED:
			proto.assign("not defined");
			break;
	}

	cerr << "siteid             " << site->siteid << endl;
	cerr << "domainid           " << site->domainid << endl;
	cerr << "status             " << SITE_STATUS_STR(site->siteid);

	if (this->site_option_get(site->siteid, SITE_OPT_DENY, true) == METADDX_OK)
		cerr << " (" << RED << "DENY/EXCLUDED" << NOR << ')';

	cerr << endl;

//	cerr << "addr               " << inet_ntoa(site->addr) << endl;
	cerr << "protocol           " << proto << endl;

	cerr << endl;
	cerr << "count doc          " << site->count_doc << endl;
	cerr << "count doc static   " << site->count_doc_static << endl;
	cerr << "count doc dynamic  " << site->count_doc_dynamic << endl;
	cerr << "count doc ok       " << site->count_doc_ok << endl;
	cerr << "count error        " << site->count_error << endl;

	cerr << endl;
	cerr << "harvester id       " << site->harvest_id << endl;
//	cerr << "harvest status     " << HARVESTER_INDICATOR_STR(site->https_check) << endl;
	cerr << "last visited       " << ctime(&(site->last_visit));
	cerr << "last resolved      " << ctime(&(site->last_resolved));
	cerr << "resolver latency   " << site->resolver_latency << " sec" << endl;


	cerr << endl;
	cerr << "last checked r.txt " << ctime(&(site->last_checked_robots_txt));
	cerr << "last checked r.rdf " << ctime(&(site->last_checked_sitemap_rdf));

	cerr << "valid robots txt   " << ((this->site_option_get(site->siteid, SITE_OPT_VRTXT, true) == METADDX_OK) ? "yes" : "no") << endl;
	cerr << "valid sitemap rdf  " << ((this->site_option_get(site->siteid, SITE_OPT_VSRDF, true) == METADDX_OK) ? "yes" : "no") << endl;

//	cerr << "valid robots txt   " << (site->has_valid_robots_txt ? "yes" : "no") << endl;
//	cerr << "valid sitemap rdf  " << (site->has_valid_sitemap_rdf ? "yes" : "no") << endl;

	cerr << endl;
	cerr << "raw content length " << site->raw_content_length << endl;
	cerr << "bytes in           " << site->bytes_in << endl;
	cerr << "bytes out          " << site->bytes_out << endl;

	cerr << endl;
	cerr << "age oldest page    " << site->age_oldest_page << " (" << (site->age_oldest_page/(60*60*24)) << " days)" << endl;
	cerr << "age newest page    " << site->age_newest_page << " (" << (site->age_newest_page/(60*60*24)) << " days)" << endl;
	cerr << "age average page   " << site->age_average_page << " (" << (site->age_average_page/(60*60*24)) << " days)" << endl;

	cerr << endl;
	cerr << "sum pagerank       " << site->sum_pagerank << endl;
	cerr << "sum wlrank         " << site->sum_wlrank << endl;
	cerr << "sum hubrank        " << site->sum_hubrank << endl;
	cerr << "sum authrank       " << site->sum_authrank << endl;
	cerr << "sum liverank       " << site->sum_liverank << endl;
	cerr << "siterank           " << site->siterank << endl;
	cerr << "in degree          " << site->in_degree << endl;
	cerr << "out degree         " << site->out_degree << endl;
	cerr << "internal links     " << site->internal_links << endl;
	cerr << "max depth          " << site->max_depth << endl;
	cerr << "component          " << COMPONENT_STR(site->component) << endl;

}

//
// Name: dump_sitelist
//
// Description:
//   Writes the site metadata to a file
//
// Input:
//   metaddx - the metadata index
//   urlddx - an urlddx to extract site names
//

void Meta::dump_sitelist(Url *url, FILE *out)
{
	assert(m != NULL);
	assert(url != NULL);
	assert(out != NULL);

	site_t site;
	char sitename[MAX_STR_LEN];
	dump_site_header(out);

	for(site.siteid = 1; site.siteid <= m->count_site; site.siteid++)
	{
		site_retrieve(&(site));
		
		// The sitename is stored in the urlddx
		url->site_by_siteid(site.siteid, sitename);
		assert(sitename != NULL);

		dump_site(&(site), sitename, out);
	}
}

//
// Name: dump_site_header
//
// Description:
//   Shows the header for dump_site, MUST have fields
//   in the SAME order
//   

void Meta::dump_site_header(FILE *out)
{
	assert(out != NULL);

	char buffer[MAX_STR_LEN];
    int wc = 0;

	// The order must be consistent with the documentation
	wc = snprintf(buffer, MAX_STR_LEN, "1siteid,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "2domainid,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "3protocol,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "4count_doc,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "5count_error,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "6last_visit,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "7last_resolved,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "8raw_content_length,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "9harvest_id,");
/*
	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "10https_check,"); */ // can be included 'options'

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "11has_valid_robots_txt,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "12has_valid_sitemap_rdf,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "13count_doc_ok,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "14count_doc_gathered,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "15count_doc_new,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "16count_doc_assigned,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "17count_doc_static,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "18count_doc_dynamic,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "19count_doc_ignored,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "20siterank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "21age_oldest_page,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "22age_newest_page,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "23age_average_page,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "24in_degree,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "25out_degree,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "26sum_pagerank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "27sum_wlrank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "28sum_hubrank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "29sum_authrank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "30sum_liverank,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "31internal_links,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "32max_depth,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "33component,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "34bytes_in,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "35bytes_out,");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "36sitename");

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "\n");

	fprintf(out, buffer);
}


//
// Name: dump_site
//
// Description:
//   Dumps information about a site to a relational database
//
// Input:
//   site
//

void Meta::dump_site(site_t *site, char *sitename, FILE *out)
{
	assert(site != NULL);
	assert(sitename != NULL);
	assert(out != NULL);

	char buffer[MAX_STR_LEN];
    int wc = 0;

	// The order must be consistent with the documentation
	wc = snprintf(buffer, MAX_STR_LEN, "%lu,", (unsigned long int)site->siteid ); 

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,", (unsigned long int)site->domainid ); 

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", site->protocol ); 

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%llu,", (unsigned long long int)site->count_doc ); 

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", site->count_error ); 

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", (int)(site->last_visit) ); 

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", (int)(site->last_resolved) ); 

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,", (long unsigned int)(site->raw_content_length)); 

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", site->harvest_id ); 
/*
	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", site->https_check ); */

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", ((this->site_option_get(site->siteid, SITE_OPT_VRTXT, true) == METADDX_OK) ? true : false));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", ((this->site_option_get(site->siteid, SITE_OPT_VSRDF, true) == METADDX_OK) ? true : false));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%llu,", (unsigned long long int)site->count_doc_ok );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%llu,", (unsigned long long int)site->count_doc_gathered );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%llu,", (unsigned long long int)site->count_doc_new );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%llu,", (unsigned long long int)site->count_doc_assigned );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%llu,", (unsigned long long int)site->count_doc_static );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%llu,", (unsigned long long int)site->count_doc_dynamic );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%llu,", (unsigned long long int)site->count_doc_ignored );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,", site->siterank );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", (int)(site->age_oldest_page));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", (int)(site->age_newest_page));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", (int)(site->age_average_page));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,", (unsigned long int)site->in_degree );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,", (unsigned long int)site->out_degree );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,", site->sum_pagerank );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,", site->sum_wlrank );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,", site->sum_hubrank );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,", site->sum_authrank );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%e,", site->sum_liverank );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%lu,", (unsigned long int)site->internal_links );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%d,", site->max_depth );

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%s,", COMPONENT_STR(site->component));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%llu,", (unsigned long long int)(site->bytes_in));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%llu,", (unsigned long long int)(site->bytes_out));

	if (wc >= 0 && wc < MAX_STR_LEN)
		wc += snprintf(buffer + wc, (MAX_STR_LEN - wc), "%s\n", sitename);

	fprintf(out, buffer);
}

//
// Name: dump_status
// 
// Description:
//   Dumps the status of the metaddx
//

void Meta::dump_status(void)
{
	cerr << "Begin status dump for metaddx" << endl;

	for (instance_t inst = 0; inst < CONF_COLLECTION_DISTRIBUTED; inst++)
	{
		cerr << "- dirname on distributed    " << (unsigned long int)inst << " is " << m->distributed[inst].dirname << endl;
		cerr << "- count_doc on distributed  " << (unsigned long int)inst << " is " << m->distributed[inst].count_doc << endl;
		cerr << "- count_site on distributed " << (unsigned long int)inst << " is " << m->distributed[inst].count_site << endl;
	}

	cerr << "- count_doc       " << m->count_doc << endl;
	cerr << "- count_site      " << m->count_site << endl;
	cerr << "- bytes per doc   " << sizeof(doc_t) << endl;
	cerr << "- bytes per site  " << sizeof(site_t) << endl;
	cerr << "End status dump for metaddx" << endl;
}

//
// Name: site_default
//
// Description:
//   Fills all the default data about a site
//
// Input:
//   site - empty site object
//
// Output:
//   site - fill site object
//
void Meta::site_default(site_t *site)
{
	assert(site->siteid > 0);

	siteid_t siteid = site->siteid;

	memset(site, 0, sizeof(site_t)); // to prevent valdrind warning set all (but really all) bytes to 0 in structure

	site->siteid			= siteid;
	site->domainid			= (siteid_t)0;
	site->harvest_id		= 0;
	site->protocol			= NOT_DEFINED;

	site->count_doc				= 0;
	site->count_error		= 0;

	site->count_doc_static		= 0;
	site->count_doc_dynamic		= 0;
	site->count_doc_gathered	= 0;
	site->count_doc_new			= 0;
	site->count_doc_assigned	= 0;
	site->count_doc_ignored		= 0;

	site->age_oldest_page		= (time_t)0;
	site->age_newest_page		= (time_t)0;
	site->age_average_page		= (time_t)0;
	site->raw_content_length= (off64_t)0;

//	inet_aton("0.0.0.0", &(site->addr));
//	inet6_aton("0::0", &(site->addr6));

	site->last_visit		= (time_t)0;
	site->last_resolved 	= (time_t)0;
	site->last_checked_robots_txt 	= (time_t)0;
	site->last_checked_sitemap_rdf 	= (time_t)0;

	site->docid_robots_txt		= 0;
	site->docid_sitemap_rdf		= 0;

	assert(this->site_option_set(site->siteid, SITE_OPT_VRTXT, false) == METADDX_OK);
	assert(this->site_option_set(site->siteid, SITE_OPT_VSRDF, false) == METADDX_OK);

	site->in_degree			= 0;
	site->out_degree			= 0;
	site->component			= COMPONENT_UNDEF;
	site->siterank			= (pagerank_t)0;
	site->internal_links	= 0;

	site->sum_pagerank		= 0;
	site->sum_wlrank		= 0;
	site->sum_hubrank		= 0;
	site->sum_authrank		= 0;
	site->sum_liverank		= 0;

	site->bytes_in			= 0;
	site->bytes_out			= 0;
}

//
// Name: doc_default
//
// Description:
//   Fills all the default data about a doc
//
// Input:
//   doc - empty doc object
//
// Output:
//   doc - fill doc object
//
void Meta::doc_default(doc_t *doc)
{

	memset(doc, 0, sizeof(doc_t)); // to prevent valdrind warning set all (but really all) bytes to 0 in structure

	doc->docid					= (docid_t)0;
	// Siteid and domainid are not changed
	doc->status       			= STATUS_DOC_NEW;
	doc->mime_type				= MIME_UNKNOWN;
	doc->http_status			= 0;

	doc->effective_speed		= 0;
	doc->latency				= 0;
	doc->latency_connect		= (float)0;

	doc->number_visits      	= 0;
   	doc->number_visits_changed	= 0;

	doc->time_unchanged			= 0;
	doc->first_visit			= 0;
	doc->last_visit				= 0;
	doc->last_modified			= 0;

	doc->raw_content_length		= 0;
	doc->content_length			= 0;
	doc->hash_value_links		= CONF_HASH_DOC_MAX_DEFINITIVE;
	doc->duplicate_of			= 0;
	doc->content_encoding		= (content_encoding_t)0;
	doc->last_modified_credits	= 0;

	doc->depth					= (depth_t)1;
	doc->is_dynamic				= false;

	doc->in_degree				= 0;
	doc->out_degree				= 0;

	doc->pagerank				= (pagerank_t)0;
	doc->wlrank					= (wlrank_t)0;
	doc->hubrank				= (hubrank_t)0;
	doc->authrank				= (authrank_t)0;
	doc->liverank				= (liverank_t)0;

	doc->freshness				= 0;
	doc->current_score			= 0;
	doc->future_score			= 0;

	doc->charset				= CHARSET_UNKNOWN; //4 Bytes
	doc->language				= Language::UNKNOWN;

	doc->options				= (doc_options_t)0;

	doc->from_feed				= false;
	doc->has_valid_mimetype		= false;
	doc->abs_last_modified		= false;
	doc->sitemap_changefreq		= (sitemap_xml_changefreq_t)0;
	doc->sitemap_prio			= (sitemap_xml_priority_t)-1;

	doc->chunked				= false;
}

//
// Name: mime_type
//
// Description:
//   Converts a string to a mime_type_t number, we will base
//   1) in the path, e.g.: "robots.txt" has a special mime-type
//   2) in the mime-type header returned by the web server
//
// Input:
//   path - path of the file downloaded
//   mime_type - string containing (ie.: "text/htm")
// 
// Return:
//   mime_type_t enumerated type integer
//
mime_type_t Meta::mime_type(char *path, char *mime_str) const
{
	int len;

	// Check for special filenames
	if (path)
	{
		if(!strcmp(path, FILENAME_ROBOTS_RDF))
			return MIME_ROBOTS_RDF;
		else if(!strcmp(path, FILENAME_ROBOTS_TXT))
			return MIME_ROBOTS_TXT;
	}

	// Check if mime_str exists
	if (mime_str == NULL)
		return MIME_UNKNOWN;

	// Check prefixes
	len = strlen(mime_str);

	if(len >= 8 && !strncasecmp(mime_str, "text/htm", 8))
		return MIME_TEXT_HTML;
	else if(len >= 9 && !strncasecmp(mime_str, "multipart", 9))
		return MIME_TEXT_HTML;
	else if(len >= 10 && !strncasecmp(mime_str, "text/devil", 10))
		return MIME_TEXT_HTML;
	else if(len >= 9 && !strncasecmp(mime_str, "text/plai", 9))
		return MIME_TEXT_PLAIN;
	else if(len >= 15 && !strncasecmp(mime_str, "application/xml", 15))
	 	return MIME_APPLICATION_XML;
	else if(len >= 15 && !strncasecmp(mime_str, "application/atom+xml", 15))
	 	return MIME_APPLICATION_ATOM_XML;
	else if(len >= 15 && !strncasecmp(mime_str, "application/rss+xml", 15))
	 	return MIME_APPLICATION_RSS_XML;	
	else if(len >= 23 && !strncasecmp(mime_str, "application/x-shockwave", 23))
	 	return MIME_APPLICATION_FLASH;	
	else if(len >= 15 && !strncasecmp(mime_str, "application/pdf", 15))
	 	return MIME_APPLICATION_PDF;	
	else if(len >= 11 && !strncasecmp(mime_str, "application", 11))
		return MIME_APPLICATION;
	else if(len >= 5 && !strncasecmp(mime_str, "audio", 5))
		return MIME_AUDIO;
	else if(len >= 5 && !strncasecmp(mime_str, "image", 5))
		return MIME_IMAGE;
	else if(len >= 5 && !strncasecmp(mime_str, "video", 5))
		return MIME_VIDEO;
	else if(len >= 12 && !strncasecmp(mime_str, "text/vnd.wap", 12))
		return MIME_TEXT_WAP;
	else if(len >= 8 && !strncasecmp(mime_str, "text/rtf", 8))
		return MIME_TEXT_RTF;
	else if(len >= 8 && !strncasecmp(mime_str, "text/xml", 8))
		return MIME_TEXT_XML;
	else if(len >= 10 && strncasecmp(mime_str, "text/x-tex", 10))
		return MIME_TEXT_TEX;
	else if(len >= 11 && strncasecmp(mime_str, "text/x-chdr", 11))
		return MIME_TEXT_CHDR;
	else if(len >= 5 && strncasecmp(mime_str, "text", 4))
		return MIME_TEXT;
	else if(len >= 7 && strncasecmp(mime_str, "message", 7))
		return MIME_MESSAGE;
	else if(len >= 5 && strncasecmp(mime_str, "model", 5))
		return MIME_MODEL;
	else if(len >= 7 && strncasecmp(mime_str, "example", 7))
		return MIME_EXAMPLE;
	else
	{
		cerr << "[MIME '" << mime_str << "' UNKNOWN]";
		return MIME_UNKNOWN;
	}
}

//
// Name: changefreq_encoding
//
// Description:
//   Converts a string to a sitemap_xml_changefreq_t number.
//
// Input:
//   sitemap_xml_changefreq_t - string containing (ie.: "weekly")
// 
// Return:
//   sitemap_xml_changefreq_t enumerated type integer
//
sitemap_xml_changefreq_t Meta::sitemap_changefreq_encoding(char *encoding_str)
{
	int len;

	// Check if encoding_str exists
	if(encoding_str == NULL) {
		return NONE;
	}
   
	// Check prefixes
    len	= strlen(encoding_str);

	size_t f = (len - 1);
	while ((encoding_str[f] == ' ' || encoding_str[f] == '\n' || encoding_str[f] == '\r' || encoding_str[f] == '\t')) f--; // elimina i caratteri 'invisibili/inutili' in coda

	len = f;

	// pulisce encoding_str da eventuali caratteri 'invisibili/inutili' allo scopo
	unsigned char s = 0;
	while ((encoding_str[s] == ' ' || encoding_str[s] == '\n' || encoding_str[s] == '\r' || encoding_str[s] == '\t') && s < ((len / 2) + 2) && s < UCHAR_MAX) s++;

	if (s == UCHAR_MAX || s > (len / 2))
		return NONE; // troppi spazi iniziali maggiori addirittura del testo contenuto nella stringa. Ignorato

    if (s > 0)
		encoding_str = &(encoding_str[s]);
    // spazi iniziali

	len = (len - s + 1);

	if (len > 7)
		return NONE;

	if(len >= 6 && !strncasecmp(encoding_str, "ALWAYS", 6)) {
		return ALWAYS;

	} else if(len >= 6 && !strncasecmp(encoding_str, "HOURLY", 6)) {
		return HOURLY;

	} else if(len >= 5 && !strncasecmp(encoding_str, "DAILY", 5)) {
		return DAILY;

	} else if(len >= 6 && !strncasecmp(encoding_str, "WEEKLY", 6)) {
		return WEEKLY;

	} else if(len >= 7 && !strncasecmp(encoding_str, "MONTHLY", 7)) {
		return MONTHLY;

	} else if(len >= 6 && !strncasecmp(encoding_str, "YEARLY", 6)) {
		return YEARLY;

	} else if(len >= 5 && !strncasecmp(encoding_str, "NEVER", 5)) {
		return NEVER;

	} else {
		cerr << "[CHANGEFREQ NOT USED]";
		return NONE;
	}
}

//
// Name: changefreq_encoding
//
// Description:
//   Converts a string to a sitemap_xml_changefreq_t number.
//
// Input:
//   sitemap_xml_changefreq_t - string containing (ie.: "weekly")
// 
// Return:
//   sitemap_xml_changefreq_t enumerated type integer
//
sitemap_xml_priority_t Meta::sitemap_priority_encoding(char *encoding_str)
{
	int len;

	const sitemap_xml_priority_t priority_default = -1;

	// Check if encoding_str exists
	if(encoding_str == NULL) {
		return priority_default;
	}
   
	// Check prefixes
    len	= strlen(encoding_str);

	size_t f = (len - 1);
	while ((encoding_str[f] == ' ' || encoding_str[f] == '\n' || encoding_str[f] == '\r' || encoding_str[f] == '\t')) f--; // elimina i caratteri 'invisibili/inutili' in coda

	len = f;

	// pulisce encoding_str da eventuali caratteri 'invisibili/inutili' allo scopo
	unsigned char s = 0;
	while ((encoding_str[s] == ' ' || encoding_str[s] == '\n' || encoding_str[s] == '\r' || encoding_str[s] == '\t') && s < ((len / 2) + 2) && s < UCHAR_MAX) s++;

	if (s == UCHAR_MAX || s > (len / 2))
		return priority_default; // troppi spazi iniziali maggiori addirittura del testo contenuto nella stringa. Ignorato

    if (s > 0)
		encoding_str = &(encoding_str[s]);
    // spazi iniziali

	len = (len - s + 1);

	if (len > 3 || (encoding_str[0] != '0' && encoding_str[0] != '1') || encoding_str[1] != '.' || isdigit(encoding_str[2]) == false)
		return priority_default;

	if (encoding_str[0] == '1' && encoding_str[2] != '0') // se maggiore di "1.0"
		return priority_default;

	if (encoding_str[0] == '1' && encoding_str[2] == '0')
		return (sitemap_xml_priority_t)9;

	if (encoding_str[0] == '0')
	{
		switch (encoding_str[2])
		{
			case '0':
				return (sitemap_xml_priority_t)0;
				break;
			case '1':
				return (sitemap_xml_priority_t)1;
				break;
			case '2':
				return (sitemap_xml_priority_t)2;
				break;
			case '3':
				return (sitemap_xml_priority_t)3;
				break;
			case '4':
				return (sitemap_xml_priority_t)4;
				break;
			case '5':
				return priority_default;
				break;
			case '6':
				return (sitemap_xml_priority_t)5; // IMPORTANTE! I valori da 5 in poi vengono usati per indicare valori maggiori di "0.5"
				break;
			case '7':
				return (sitemap_xml_priority_t)6;
				break;
			case '8':
				return (sitemap_xml_priority_t)7;
				break;
			case '9':
				return (sitemap_xml_priority_t)8;
				break;
			default:
				return priority_default;
				break;
		}
	}

	return priority_default;
}

//
// Name: content_encoding
//
// Description:
//   Converts a string to a content_encoding_t number, we will base
//   1) in the content-encoding header returned by the web server
//
// Input:
//   content_encoding - string containing (ie.: "gzip")
// 
// Return:
//   content_encoding_t enumerated type integer
//
content_encoding_t Meta::content_encoding(char *encoding_str)
{
	int len;

	// Check if encoding_str exists
	if(encoding_str == NULL)
		return ENCODING_NONE;
   
	// Check prefixes
    len	= strlen(encoding_str);

	if(len >= 7 && !strncasecmp(encoding_str, "deflate", 7))
		return ENCODING_DEFLATE;
	else if(len >= 4 && !strncasecmp(encoding_str, "gzip", 4))
		return ENCODING_GZIP;
	else
	{
		cerr << "[ENCODING '" << encoding_str << "' UNKNOWN]";
		return ENCODING_UNKNOWN;
	}
}
