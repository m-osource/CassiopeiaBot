/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _XMLCONF_H_INCLUDED_
#define _XMLCONF_H_INCLUDED_

#include <config.h>

// System libraries

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xmlmemory.h>
#include <libxml/xpath.h>

using namespace std;

// Local libraries

#include "const.h"
#include "die.h"

// Filenames

#define XMLCONF_FILE_PATH		"./cbot.conf:/etc/cbot.conf:/usr/local/cbot/cbot.conf"
#define XMLCONF_ENVIRONMENT_VAR	"CBOT_CONF"

// List separators

#define XMLCONF_BASE_XPATH		"config"
#define	CONF_LIST_SEPARATOR	"\r\n,:\t "

// Vars
#define XMLCONF_EXTERNAL_DECLARATIONS
#include "xmlconf-vars.h"
#undef XMLCONF_EXTERNAL_DECLARATIONS

// Configuration readed
extern bool CONF_OK;
extern xmlDocPtr			xmlconf_document;
extern xmlXPathContextPtr	xmlconf_context;

#endif

