/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _METADDX_ANALYSIS_H_INCLUDED_
#define _METADDX_ANALYSIS_H_INCLUDED_

#include <config.h>

// System libraries

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <iostream>
#include <iomanip>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>


#include <math.h>
#include <errno.h>
#include <queue>
#include <string>
#include <map>

using namespace std;

// Local libraries

#include "const.h"
#include "http_codes.h"
#include "xmlconf.h"
#include "die.h"
#include "utils.h"
#include "Meta.h"
#include "pthread.h"
#include "sitelink.h"

// Variables

// Macros

#define ROUND_DOUBLE(x)          ( rint(x * (double)100000000) / (double)100000000 )

// Globals

enum analysis_call_t {
    ANALYSIS_SITE_STATISTICS		= 0,
    ANALYSIS_DOC_STATISTICS			= 1,
    ANALYSIS_CALCULATE_SCORES		= 2
};

// Classes
class Analysis
{
	// For docs summary statistics separate by instance
	typedef struct {
		map<doc_status_t, docid_t> doc_status_map;
		map<int,docid_t> http_status_map;
		map<depth_t,docid_t> depth_count;
		map<unsigned int,docid_t> in_degree_map;
		map<unsigned int,docid_t> out_degree_map;
		map<unsigned int,docid_t> content_length_kb_map;
		map<unsigned int,docid_t> raw_content_length_kb_map;
		map<mime_type_t,docid_t> mime_type_map;
		map<depth_t,pagerank_t> pagerank_depth;
		map<depth_t,wlrank_t> wlrank_depth;
		map<depth_t,hubrank_t> hubrank_depth;
		map<depth_t,authrank_t> authrank_depth;
		map<depth_t,liverank_t> liverank_depth;
		docid_t duplicates_count;
		docid_t dynamic_count;
		docid_t doc_count;
	} doc_stat_instance_t;

	// For docs summary statistics
	// This data cannot be distributed for each instance because map can be very big
	typedef struct {
		pthread_mutex_t lock;
		map<double,docid_t> pagerank_map;
		map<double,docid_t> wlrank_map;
		map<double,docid_t> hubrank_map;
		map<double,docid_t> authrank_map;
		map<double,docid_t> liverank_map;
		map<time_t,docid_t> age_hours_map;
		map<time_t,docid_t> age_months_map;
		map<time_t,docid_t> age_years_map;
	} doc_stat_t;

	//analysis_t *distributed;
	Meta *meta;
	pthread_barrier_t *barrier;
    instance_t static_random_inst;
	docid_t ndocs;
    siteid_t nsites;
	docid_t ***count_doc;
	docid_t ***count_doc_ok;
	docid_t ***count_doc_gathered;
	docid_t ***count_doc_ignored;
	docid_t ***count_doc_new;
	docid_t ***count_doc_assigned;
	docid_t ***count_doc_date_ok;
	docid_t ***count_doc_static;
	docid_t ***count_doc_dynamic;
	unsigned int ***max_depth;
    pagerank_t  ***sum_pagerank;
    hubrank_t   ***sum_hubrank;
    authrank_t  ***sum_authrank;
    liverank_t  ***sum_liverank;
	time_t ***age_oldest_page;
    time_t ***age_newest_page;
    double ***age_average_page;

	// For sites summary statistics
	map<site_optmask_t, siteid_t> *site_status_map;
	map<docid_t,siteid_t> *site_count_doc_map;
	map<unsigned int,siteid_t> *site_raw_content_length_mb;
	map<time_t,siteid_t> *site_age_oldest_page_months;
	map<time_t,siteid_t> *site_age_newest_page_months;
	map<time_t,siteid_t> *site_age_average_page_months;
	map<time_t,siteid_t> *site_age_oldest_page_years;
	map<time_t,siteid_t> *site_age_newest_page_years;
	map<time_t,siteid_t> *site_age_average_page_years;
	map<docid_t,siteid_t> *site_internal_links;
	map<unsigned int,siteid_t> *site_internal_links_by_ndocs;
	map<siteid_t,siteid_t> *site_in_degree;
	map<siteid_t,siteid_t> *site_out_degree;
	map<depth_t,siteid_t> *site_max_depth;
	map<double,docid_t>	*site_sum_pagerank;
	map<double,docid_t> *site_sum_hubrank;
	map<double,docid_t> *site_sum_authrank;
	map<double,docid_t> *site_sum_liverank;
	map<double,docid_t> *site_siterank;
	docid_t *sum_count_doc;
	docid_t *sum_count_doc_static;
	double *media_age_oldest_page_months;
	double *media_age_newest_page_months;
	double *media_age_average_page_months;
	double *media_in_degree;
	double *media_out_degree;
	double *media_internal_links;
	double *media_raw_content_length_mb;
	double *media_max_depth;
	siteid_t *nsites_age_valid;
	siteid_t *nsites_ok;

	// For docs summary statistics
	doc_stat_instance_t ***pdsi;
	doc_stat_t **pds;

	// Function required by site_statistics (pthread use)
	void *thread_function_site_statistics( void * );

	// Function required by doc_statistics (pthread use)
	void *thread_function_doc_statistics( void * );

	// Function called from 'thread_function_doc_statistics'
	void doc_statistics_sum(doc_stat_instance_t &, doc_stat_t &, doc_t &);

	//
	// Name: adder
	//
	// Description: sum values from instances
	//
	// Input: pointer to array
	//
	// Return: the sum
	//
	template <typename T> T adder( T *tosum )
	{
		T retvalue = 0;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			retvalue += tosum[i];

		return retvalue;
	}

	//
	// Name: media
	//
	// Description: calculate average
	//
	// Input: media, value, size
	//
	// Return:
	//
	template <typename T, typename Z, typename P> void media_( T &media, Z value, P &size )
	{
		assert(size >= 0);

		if (size == 0)
			media = (T)value;
		else
			media = (((media / size) * (size - 1)) + ((T)value / size));
	}

	//
	// Name: media
	//
	// Description: calculate average
	//
	// Input: media, value, size
	//
	// Return:
	//
	template <typename T, typename Z, typename P> void media( T &media, Z &value, P &size )
	{
		assert(size >= 0);

		if (size == 0)
			media = (T)value;
		else
			media = (((media / size) * (size - 1)) + ((T)value / size));
	}

	//
	// Name: joinmedia
	//
	// Description: join averages from instances
	//
	// Input: pointer to array of values for each instance, pointer to array of sizes
	//
	// Return: the sum
	//
	template <typename P> double joinmedia( double *to_join, P *size )
	{
		double main_media = 0;

		P main_size = adder<P>(size);

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			main_media += ((to_join[i] / main_size) * size[i]);

		return main_media;
	}

	// Function to proxy to non-static function
	static void* thread_function_caller( void * );

	// Syncronize threads with barrier
	void sync_threads( pthread_barrier_t * ) const;

	public:

	Analysis (Meta *_X)
		: meta (_X)
		, barrier (NULL)
		, static_random_inst (rand() % CONF_COLLECTION_DISTRIBUTED)
		, ndocs (0)
    	, nsites (0)
		, count_doc (NULL)
		, count_doc_ok (NULL)
		, count_doc_gathered (NULL)
		, count_doc_ignored (NULL)
		, count_doc_new (NULL)
		, count_doc_assigned (NULL)
		, count_doc_date_ok (NULL)
		, count_doc_static (NULL)
		, count_doc_dynamic (NULL)
		, max_depth (NULL)
		, sum_pagerank (NULL)
		, sum_hubrank (NULL)
		, sum_authrank (NULL)
		, sum_liverank (NULL)
		, age_oldest_page (NULL)
		, age_newest_page (NULL)
		, age_average_page (NULL)
		, site_status_map (NULL)
		, site_count_doc_map (NULL)
		, site_raw_content_length_mb (NULL)
		, site_age_oldest_page_months (NULL)
		, site_age_newest_page_months (NULL)
		, site_age_average_page_months (NULL)
		, site_age_oldest_page_years (NULL)
		, site_age_newest_page_years (NULL)
		, site_age_average_page_years (NULL)
		, site_internal_links (NULL)
		, site_internal_links_by_ndocs (NULL)
		, site_in_degree (NULL)
		, site_out_degree (NULL)
		, site_max_depth (NULL)
		, site_sum_pagerank (NULL)
		, site_sum_hubrank (NULL)
		, site_sum_authrank (NULL)
		, site_sum_liverank (NULL)
		, site_siterank (NULL) 
		, sum_count_doc (NULL)
		, sum_count_doc_static (NULL)
		, media_age_oldest_page_months (NULL)
		, media_age_newest_page_months (NULL)
		, media_age_average_page_months (NULL)
		, media_in_degree (NULL)
		, media_out_degree (NULL)
		, media_internal_links (NULL)
		, media_raw_content_length_mb (NULL)
		, media_max_depth (NULL)
		, nsites_age_valid (NULL)
		, nsites_ok (NULL)
		, pdsi (NULL)
		, pds (NULL)
	{
	}

	~Analysis () // dtor
	{
	}

	// need to passing arguments to threads functions
	// Because function call by pthread_create need to be pass first through 'thread_function_caller', these works with other temporary object
	typedef struct {
		instance_t inst;
		Analysis *obj;
		analysis_call_t f; // corrisponde alla chiamata di determinate funzioni fatta da pthread_create
	} thread_args_t;

	// Save to files statistics of sites
	void site_statistics( void );

	// Save to files statistics of docs
	void doc_statistics( void );
};

// Classes
class AnalysisManager
{
	Meta *meta;
	CBotSort<priority_t, docid_t> *sortp;
	priority_t *priority;
    docid_t *order;
    siteid_t *docid_to_siteid;
	bool opt_dont_generate;
	pthread_barrier_t *barrier;
    instance_t static_random_inst;
	docid_t ndocs;
    siteid_t nsites;

	// For calculate scores
	siterank_t *siterank;
	docid_t *queuesize;
	docid_t *max_queue_size;
	docid_t *skipped_successful_and_ok;
	docid_t *skipped_successful_but_not_ok;
	docid_t *skipped_unsuccessful;
	docid_t *skipped_exclusion;
	docid_t *skipped_forbidden;
	docid_t *skipped_ignored;
	docid_t *skipped_depth;
	docid_t *skipped_other;
	siteid_t *nsites_too_many_errors;
    siteid_t *nsites_data;
    siteid_t *nsites_assigned; 


	// Function required by calculate_score (pthread use)
	void *thread_function_calculate_scores( void * );

	//
	void doc_calculate_scores( doc_t *, siterank_t, docid_t ) const;

	//
	freshness_t doc_freshness( doc_t *doc ) const;

	//
	// Name: adder
	//
	// Description: sum values from instances
	//
	// Input: pointer to array
	//
	// Return: the sum
	//
	template <typename T> T adder( T *tosum )
	{
		T retvalue = 0;

		for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
			retvalue += tosum[i];

		return retvalue;
	}

	// Function to proxy to non-static function
	static void* thread_function_caller( void * );

	// Syncronize threads with barrier
	void sync_threads( pthread_barrier_t * ) const;

	public:

	AnalysisManager (Meta *_A, priority_t *_B, docid_t *_C, siteid_t *_D, bool &_E)
		: meta (_A)
		, sortp (NULL)
		, priority (_B)
    	, order (_C)
    	, docid_to_siteid (_D)
		, opt_dont_generate (_E)
		, barrier (NULL)
		, static_random_inst (rand() % CONF_COLLECTION_DISTRIBUTED)
		, ndocs (0)
    	, nsites (0)
		, siterank (NULL)
		, queuesize (NULL)
		, max_queue_size (NULL)
		, skipped_successful_and_ok (NULL)
		, skipped_successful_but_not_ok (NULL)
		, skipped_unsuccessful (NULL)
		, skipped_exclusion (NULL)
		, skipped_forbidden (NULL)
		, skipped_ignored (NULL)
		, skipped_depth (NULL)
		, skipped_other (NULL)
		, nsites_too_many_errors (NULL)
    	, nsites_data (NULL)
    	, nsites_assigned (NULL)
	{
	}

	~AnalysisManager () // dtor
	{
	}

	// need to passing arguments to threads functions
	// Because function call by pthread_create need to be pass first through 'thread_function_caller', these works with other temporary object
	typedef struct {
		instance_t inst;
		AnalysisManager *obj;
		analysis_call_t f; // corrisponde alla chiamata di determinate funzioni fatta da pthread_create
	} thread_args_t;

	// Calculate doc score for next harvesting
	void calculate_scores( void );
};


// Functions



//void metaddx_analysis_site_statistics( Meta *meta );
//void metaddx_analysis_doc_statistics( Meta *meta, doc_status_t status, uint static_dynamic );

//void metaddx_doc_calculate_scores( docid_t, doc_t *, siterank_t, docid_t );
//freshness_t metaddx_doc_freshness( doc_t *doc );


#endif
