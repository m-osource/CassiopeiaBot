#include "Entity.h"

off64_t ENTITYIDX_ENTITY_SIZE;

bool Entities::index_setup (const size_t min_word_len, bool showentities)
{
	string confpath(CONF_COLLECTION_BASE);

	// apertura degli indici
	index_open();

	entityidx_status_t erc = ENTITYIDX_ERROR;
	entityid_t entityid = 0;
	entityid_t maxid = 0;

	cerr << "Make ipertext entities index ..." << endl;

	string config_filename = (confpath + "/" + "entities.txt");

	if (config_filename.length() > 0)
	{
		unsigned int length;
		char *inbuf;
		char *inbuf2;
	
		ifstream inFile;  //input file stream variable
		inFile.open(config_filename); //open the input file

	 	if (inFile)
		{	
		// posiziona in cursore alla fine del file per rilevarne la lunghezza per poi riposizionarlo all'inizio:
			inFile.seekg (0, ios::end);
			length = inFile.tellg();
			inFile.seekg (0, ios::beg);
		
			// alloca la memoria del inbuf:
			inbuf = (char *) malloc ((length  + 1) * sizeof(char));
			inbuf2 = (char *) malloc ((length  + 1) * sizeof(char));
		
		
			// legge i dati in un unico blocco:
			inFile.read (inbuf,length);
			inbuf[length] = '\0';

			memcpy(inbuf2, inbuf, (length + 1));

			char *word = strtok( inbuf, CONF_LIST_SEPARATOR );

			while( word != NULL )
			{
				bool iscode = true;

				// Check if word is a code
				for (unsigned char o = 0; o < strlen(word); o++)
				{
					if (word[o] < 48 || word[o] > 57)
						iscode = false;
				}

				if (iscode == true)
				{
					entityid = (unsigned int)(strtoul (word, NULL, 0));

					if (entityid > maxid)
						maxid = entityid;
				}
				else
				{
					erc = entityidx_resolve_entity( word, &(entityid), false );

					if (erc != ENTITYIDX_CREATED_ENTITY)
						die ("error");
				}

				word = strtok( NULL, CONF_LIST_SEPARATOR );
			}

			free (inbuf);

			// Alloc and clean codes tables
			openidx->valid_codes = (bool *) calloc ((maxid + 1), sizeof(bool));
			assert( openidx->valid_codes != NULL );

			word = strtok( inbuf2, CONF_LIST_SEPARATOR );

			while( word != NULL )
			{
				bool iscode = true;

				// Check if word is a code
				for (unsigned char o = 0; o < strlen(word); o++)
				{
					if (word[o] < 48 || word[o] > 57)
						iscode = false;
				}

				if (iscode == true)
				{
					entityid = (unsigned int)(strtoul (word, NULL, 0));

					openidx->valid_codes[entityid] = true;
				}

				word = strtok( NULL, CONF_LIST_SEPARATOR );
			}

			free (inbuf2);
		}
		else
		{
			cerr << "Error: file " << config_filename << " not found!" << endl;
			index_close ();
			return false;
		}
	}

	return true;
}

void Entities::index_open (void)
{
	cerr << "Open word indexes for elaboration " << endl;
	entityidx_new(); // entityidx_open() non necessaria se non si lavora su disco
	assert( openidx != NULL );
}

void Entities::index_close (void)
{
	cerr << "Entities: Close word indexes." << endl;
	entityidx_close();
}

//
entityidx_status_t Entities::checkEntity(char *entity, entityid_t *entityid, entity_type_t *entity_type) const {

	entityidx_status_t erc = ENTITYIDX_ERROR;
	char code[20];
	const char *digit = NULL;
	unsigned char c = 0;

	switch (*entity_type)
	{
		case ENTITYIDX_ENTITY_ALPHANUM:
		
			erc = entityidx_resolve_entity( entity, entityid, true );

			break;

		case ENTITYIDX_ENTITY_DECIMAL:

			digit = entity;

        	while(c < 20 && isdigit(*(digit)))
            	code[c++] = *(digit++);

			code[c] = '\0';

	        if (c > 0 && c < 7 && *(digit) == ASCII_SC)
			{
	            *entityid = (entityid_t)(strtoul (code, NULL, 10));

				if (openidx->valid_codes[*entityid] == true)
					erc = ENTITYIDX_EXISTENT;
			}

			break;

		case ENTITYIDX_ENTITY_HEXDECIMAL:

			digit = entity;

        	while(c < 20 && isxdigit(*(digit)))
	            code[c++] = *(digit++);

			code[c] = '\0';

	        if (c > 0 && c < 7 && *(digit) == ASCII_SC)
			{
	            *entityid = (entityid_t)(strtoul (code, NULL, 16));

				if (openidx->valid_codes[*entityid] == true)
					erc = ENTITYIDX_EXISTENT;
			}

			break;

		default:

			break;
	}

	return erc;
}

//
// Name: entityidx_new
//
// Description:
//   Creates a new index in the given directory
//
// Input:
//   dirname - directory to create url index
//
// Return:
//   urlindex structure
//
void Entities::entityidx_new( void ) {

	openidx = (entityidx_t *)malloc(sizeof(entityidx_t));
	assert( openidx != NULL );

	assert( CONF_OK );

	// Alloc and clean hash tables
	openidx->entity_hash = (off64_t *) calloc (MAXENTITIES, sizeof(off64_t));
	assert( openidx->entity_hash != NULL );

	// Set default values
	openidx->entity_count = 0;
	openidx->entity_next_char = 1; // start in 1

	// Create memory area for entities word names
	ENTITYIDX_ENTITY_SIZE = ENTITYIDX_EXPECTED_ENTITY_SIZE * MAXENTITIES;
	openidx->entity = (char *)malloc((sizeof(char))*ENTITYIDX_ENTITY_SIZE);
	assert( openidx->entity != NULL );
	openidx->entity[0] = '\0';

	openidx->valid_codes = NULL;
} 
                                            
//
// Name: entityidx_resolve_entity
//
// Description:
//   Verify a entity name and add it if necessary
//   Note: this function was different from other 'index ...resolve...'
//
// Input:
//   entity - the entity by name to check
//   entityid - the number conversion of entity by name to check (WARNING: it can be univocal)
//
// Output:
//   entityid - entityid of the existent/created register, if NULL, don't create
//   if not found.
//
// Return:
//   ENTITYIDX_EXISTENT - the entity existed
//   ENTITYIDX_CREATED_ENTITY - the entity word was added
//   ENTITYIDX_NOT_FOUND - the entity word is not known and was not created
//
entityidx_status_t Entities::entityidx_resolve_entity( const char *entity, entityid_t *entityid, bool readonly ) const {
	assert( openidx != NULL );
	//assert( entity != NULL );

	if (entity == NULL)
		return ENTITYIDX_NOT_FOUND;

	if (readonly == false && entityid == 0) // in 'write index', entityid must be passed as argument and must be major of zero
		return ENTITYIDX_ERROR;

	size_t elen = strlen(entity);
	assert( elen > 0 );

	entityid_t bucket;
	entityid_t entityid_check;

	// Check if the entity exists
	entityid_check = entityidx_check_entity( entity, &(bucket), readonly );

	if( entityid_check > 0 ) {
		if( entityid != NULL ) {
			*entityid	= entityid_check;
		}
		return ENTITYIDX_EXISTENT;
	}

	if( readonly == true )
		return ENTITYIDX_NOT_FOUND;
	else {
		// Get the next entityid
		// *entityid = ++(openidx->entity_count);
		(openidx->entity_count)++;


		//cout << "Result 0 o 2, Sito:   " << entity << "       Recupero il primo entityid disponibile " << openidx->entity_count << '-' << bucket << endl;
		if( openidx->entity_count > MAXENTITIES ) {
			die( "Maximum number of entitys exceeded, increase in configuration file"  );
		}

		// Put in bucket
		(openidx->entity_hash)[bucket] = (openidx->entity_next_char);
//		cout << "Inserisco " << (openidx->entity_next_char) << " in (openidx->entity_hash)[" << bucket << "]" << " conferma " << (openidx->entity_hash)[bucket] << endl;

		// Store string
		memcpy( openidx->entity + openidx->entity_next_char, entity, elen + 1 );

		// Store entityid
		memcpy( openidx->entity + openidx->entity_next_char + elen + 1, entityid, sizeof(entityid_t) );

		// Move char pointer
		openidx->entity_next_char = openidx->entity_next_char + elen + 1 + sizeof(entityid_t);
		if( openidx->entity_next_char > ENTITYIDX_ENTITY_SIZE ) {
			cerr << "Word memory area full!" << endl;
			cerr << "Increase MAXENTITIES or EXPECTED_ENTITY_SIZE" << endl;
			die ("Exit forced!"); // Modificato solo per uso tematiche
			// return(ENTITYIDX_ERROR);
		}
	}

	// Return
	return ENTITYIDX_CREATED_ENTITY;
}

//
// Name: entityidx_check_entity
//
// Description:
//   Check if a word exists
//
// Input:
//   entity - the entity name to check
//   bucket - the bucket in which this was found
//
// Return
//   a wordid if resolved
//   0 if not found
//
entityid_t Entities::entityidx_check_entity( const char *entity, entityid_t *bucket, bool readonly ) const {
	assert( openidx != NULL );
	assert( entity != NULL );
	assert( strlen( entity ) > 0 );

	// First attempt to find bucket (debug purpose)
	//entityid_t test = urlidx_hashing_entity( entity );
	//cout << "DOMAIN " << entity << " BUCKET " << test << endl;
	//(*bucket) = (off64_t)test;
	
	// First attempt to find bucket
	(*bucket) = entityidx_hashing_entity( entity );

	// Linear probing
	// Verifica che il bucket sia presente e ad esso corrisponda un offset valido nel puntatore a caratteri
	while( openidx->entity_hash[(*bucket)] > 0 ) {

		char *pidx = openidx->entity + openidx->entity_hash[(*bucket)]; // puntatore all'offset indicato dall'hash

		const char *input = entity;

		// confronta passo-passo il termine originale con quello fornito come argomento
		while (*(pidx) != '\0' && *(input) != '\0' && *(pidx) == *(input) && *(pidx++) && *(input++));

		if (*pidx++ == '\0' && ((readonly == false && *input == '\0') || (readonly == true && *(input) == ASCII_SC))) // fine del termine dentro il puntatore a caratteri
			return *((entityid_t *)pidx); // restituisce l'id

		(*bucket) = ((*bucket) + 1) % MAXENTITIES;
	}

	return (entityid_t)0;
}

// Hashing Functions for entities
entityid_t Entities::entityidx_hashing_entity( const char *text ) const {
	entityid_t val = 0; // 'val' must be inizialized

	while (*(text) != '\0' && isalpha(*(text)))
		val = ( (131 * (val == 0 ? 1 : val) + *text++) % MAXENTITIES );

	return val;
}

//
// Name: entityidx_close
//
// Description:
//   Closes the url index, saving data to disk
//
// Input:
//   entityidx - the url index structure
//
void Entities::entityidx_close(void) {
	// Check what i'm going to close
	assert( openidx != NULL );

	// Close and nullify all the static filehandlers
	free( openidx->entity_hash ); openidx->entity_hash = NULL;
	free( openidx->entity ); openidx->entity = NULL;
	free( openidx->valid_codes ); openidx->valid_codes = NULL;
	free( openidx ); openidx = NULL;
}
