/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "perfect_hash.h"

//
// Name: perfhash_dump
//
// Description:
//   Dumps the state of a keyword check
//
// Input:
//   perfhash - the keyword checker object 
//

void perfhash_dump( perfhash_t *perfhash ) {
	fprintf( stderr, "BEGIN perfhash dump\n" );
	fprintf( stderr, "length        : %d\n", perfhash->length );
	fprintf( stderr, "count         : %d\n", perfhash->count );
	fprintf( stderr, "A             : %d\n", perfhash->A );
	fprintf( stderr, "B             : %d\n", perfhash->B );
	fprintf( stderr, "check_matches : %d\n", perfhash->check_matches );
	fprintf( stderr, "END perfhash dump\n" );
}

/*
 Name: perfhash_create

 Description:
   Creates a perfhash object

 Input:
   perfhash - space for a perfhash object
   perfhash->check_matches - 0:probabilistic (w/false positives) 1:exact
   keywords - a string containing a list of keywords separated by spaces
*/

void perfhash_create( perfhash_t *perfhash, char *in_keywords ) {
	assert( PERFHASH_MAX_WORD_LEN < MAX_STR_LEN );
	assert( ((PERFHASH_MAX_WORD_LEN + 1) * PERFHASH_MAX_WORDS) < MAX_DOC_LEN );
	assert( strlen(in_keywords) < ((PERFHASH_MAX_WORD_LEN + 1)*(PERFHASH_MAX_WORDS + 2)) );

	unsigned int randA = 0;
	unsigned int randB = 0;
	unsigned int length = 0;
	unsigned char ncounter = 0; // conta i primi 3 parametri numerici in 'in_keywords'

	// Copy the keywords
	char *copy_keywords = (char *)malloc(sizeof(char) * (PERFHASH_MAX_WORD_LEN + 1) * (PERFHASH_MAX_WORDS + 2));
	assert( copy_keywords != NULL );
	strcpy( copy_keywords, in_keywords );

	/* We will tokenize only once */
	perfhash->count = 0;

	char *word = strtok( copy_keywords, CONF_LIST_SEPARATOR );

	while( word != NULL ) {
		// Save and skip static random values
		if (ncounter == 0)
		{
			for (unsigned char o = 0; o < strlen(word); o++)
				assert(word[o] > 47 && word[o] < 58);

			if (CONF_COLLECTION_PERFHASH_STATIC_RANDOMS == true)
			{
				perfhash->A = (unsigned int)(strtoul (word, NULL, 0));
				randA = perfhash->A;
			}

			word = strtok( NULL, CONF_LIST_SEPARATOR );
			ncounter++;
			continue;
		}
		else if (ncounter == 1)
		{
			for (unsigned char o = 0; o < strlen(word); o++)
				assert(word[o] > 47 && word[o] < 58);

			if (CONF_COLLECTION_PERFHASH_STATIC_RANDOMS == true)
			{
				perfhash->B = (unsigned int)(strtoul (word, NULL, 0));
				randB = perfhash->B;
			}

			word = strtok( NULL, CONF_LIST_SEPARATOR );
			ncounter++;
			continue;
		}
		else if (ncounter == 2)
		{
			for (unsigned char o = 0; o < strlen(word); o++)
				assert(word[o] > 47 && word[o] < 58);

			if (CONF_COLLECTION_PERFHASH_STATIC_RANDOMS == true)
			{
				perfhash->length = (unsigned int)(strtoul (word, NULL, 0));
				length = perfhash->length;
			}

			word = strtok( NULL, CONF_LIST_SEPARATOR );
			ncounter++;
			continue;
		}

		unsigned int position = (perfhash->count + 1);

		int word_length = strlen(word);
		if( word_length >= PERFHASH_MAX_WORD_LEN ) {
			cerr << "This word is too long: '" << word << "'" << endl;
			assert( 0 );
		}

		// Store the keyword
		size_t len = strlen(word);
		assert( len < PERFHASH_MAX_WORD_LEN );
		perfhash->keywords[position] = (char *)malloc((len + 1) * sizeof(char));
		assert( perfhash->keywords[position] != NULL );
		strcpy( perfhash->keywords[position], word );

		// Next item
		perfhash->count++;
		assert( perfhash->count <= PERFHASH_MAX_WORDS );

		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}

	// Create a hash table with enough space
	// More space = Minor Collision

	if (CONF_COLLECTION_PERFHASH_STATIC_RANDOMS == true)
	{
		if (length == 0)
		{
			perfhash->length = (uint)((double)perfhash->count / (1.0 - PERFHASH_SECURITY_FACTOR));
			perfhash->length += (uint)(((double)rand() / (double)RAND_MAX) * perfhash->length);
			length = perfhash->length;
		}
	}
	else
	{
		perfhash->length = (uint)((double)perfhash->count / (1.0 - PERFHASH_SECURITY_FACTOR));
		perfhash->length += (uint)(((double)rand() / (double)RAND_MAX) * perfhash->length);
	}

	assert( perfhash->length > 0 );

	// Ask memory for the table
	perfhash->table = (unsigned int *) calloc ((perfhash->length+1), sizeof(unsigned int));
	assert( perfhash->table != NULL );

	// Try many times with random factors
	int retries = 1;
	char last_collision[MAX_STR_LEN] = "";
	bool get_static_randoms = false;

	if (CONF_COLLECTION_PERFHASH_STATIC_RANDOMS == true)
	{
		if (perfhash->A == 0 && perfhash->A == 0)
			get_static_randoms = true;
	}

	while (retries <= PERFHASH_MAX_RETRIES)
	{
		// Clear the table
		_perfhash_clear_table(perfhash);

		if (get_static_randoms == true)
		{
			perfhash->A = 0;
			perfhash->B = 0;
		}

		// Try with some parameters
		if (_perfhash_try_parameters(perfhash, last_collision, retries))
			break;
		else
			retries++; // If not successful, keep trying
	}

	// Check the number of tries
	if( retries >= PERFHASH_MAX_RETRIES ) {
		cerr << "Failed to create hash table for this after " << PERFHASH_MAX_RETRIES << " tries." << endl;
		for( uint i=0; i<perfhash->count; i++ ) {
			cerr << " - " << perfhash->keywords[i] << endl;
		}
		cerr << "Last collision was: '" << last_collision << "'" << endl;
		perfhash_dump( perfhash );
		assert(0);
	}

	/* We don't need to keep the keywords unless we check them */	
	if( perfhash->check_matches == false )
		for( unsigned int i = 1; i <= perfhash->count; i++ )
			free( perfhash->keywords[i] );

	// Validate that the table was created ok, and
	// that at least all its elements are ok.
	ncounter = 0;
	strcpy( copy_keywords, in_keywords );
	word = strtok( copy_keywords, CONF_LIST_SEPARATOR );
	while( word != NULL ) {
		// Skip static random values
		if (ncounter == 0)
		{
			word = strtok( NULL, CONF_LIST_SEPARATOR );
			ncounter++;
			continue;
		}
		else if (ncounter == 1)
		{
			word = strtok( NULL, CONF_LIST_SEPARATOR );
			ncounter++;
			continue;
		}
		else if (ncounter == 2)
		{
			word = strtok( NULL, CONF_LIST_SEPARATOR );
			ncounter++;
			continue;
		}

		if( ! perfhash_check( perfhash, word ) ) {
			cerr << endl;
			cerr << "Error! keyword not found: " << word << endl;
			cerr << "Original keywords were: " << in_keywords << endl;
			assert(0);

		}
		word = strtok( NULL, CONF_LIST_SEPARATOR );
	}
	free( copy_keywords );

	if (CONF_COLLECTION_PERFHASH_STATIC_RANDOMS == true && (randA == 0 || randB == 0 || length == 0))
	{
		char logbuf[MAX_STR_LEN];
		sprintf (logbuf, "You can use these values \"%u %u %u\" as into label 'perfhashstaticrandoms' of main configuration files", perfhash->A, perfhash->B, length);

		// Log
		syslog( LOG_NOTICE, (const char *)logbuf );

		sleep(10);
	}
}

/*
 Name: _perfhash_clear_table

 Description:
   Clears the hash table of a perfhash

 Input:
   perfhash.length - length of the table
*/

void _perfhash_clear_table( perfhash_t *perfhash ) {
	for( uint i=0; i<perfhash->length; i++ )
		(perfhash->table)[i] = 0;
}

/*
 Name: _perfhash_hash

 Description:
   Calculates the hash function for a given string

 Input:
   perfhash - the perfhash object
   word - the word to be hashed

 Output:
   hash1 - value of the hash function
   hash2 - other hash
*/

void _perfhash_hash( perfhash_t *perfhash, char *word, unsigned int *hash, unsigned int *hash2 ) {
    (*hash)		= 0; // bucket
    (*hash2)	= 0; // bucket

	for( ; (*word) != '\0'; word++ )
	{
		(*hash) = ((((perfhash->A) * (*hash + perfhash->B)) % UINT_MAX) + (unsigned char)(*word)) % UINT_MAX;
		(*hash2) = (((131 * (*hash2 == 0 ? 1 : *hash2)) % UINT_MAX) + (unsigned char)(*word)) % UINT_MAX;
	}

	(*hash) = (*hash) % perfhash->length; // perfhash->table position
//cout << "buckets " << *hash << ' ' << *hash2 << endl;
}

//
// Name: _perfhash_try_parameters
//
// Description:
//   Generates parameters and try to create a perfect hashing function
//   with them.
//
// Input:
//
// Output:
//
// Return:
//   true if perfect hash has not collision
//
bool _perfhash_try_parameters( perfhash_t *perfhash, char *last_collision, unsigned int retries )
{
	/* Randomized parameters, notice that they are not even primes */

	time_t now = time(NULL);
	srand((now + retries) % UINT_MAX);

	if (CONF_COLLECTION_PERFHASH_STATIC_RANDOMS == true)
	{
		if (perfhash->A == 0)
			perfhash->A = (unsigned int)rand();
	}
	else
		perfhash->A = (unsigned int)rand();

	if (CONF_COLLECTION_PERFHASH_STATIC_RANDOMS == true)
	{
		if (perfhash->B == 0)
			perfhash->B = (unsigned int)rand();
	}
	else
		perfhash->B = (unsigned int)rand();

	/* We will check for collisions */
	bool has_collisions = false;
	for( uint i=1; i <= perfhash->count; i++ ) {
		unsigned int position; // posizione (ottenuta attraverso bucket) nella tabella 'perfhash->table' in cui è presente l'indirizzo dell'array 'perfhash->keywords'
		unsigned int vrfy; // bucket per la comparazione numerica

		// crea la coppia di bucket relativi al termine (perfhash->keywords[i]) inserito
		_perfhash_hash( perfhash, perfhash->keywords[i], &(position), &(vrfy) );

		if( perfhash->check_matches == false )
		{
			if( perfhash->table[position] > 0 )
			{
				has_collisions = true;
				strcpy( last_collision, "Incomplete last collision, cause: 'perfhash table position is busy' !" );
			}


			perfhash->table[position] = vrfy; // Store a hash for verification (only number compare but with high performances)
		}
		else
		{ // al fine di assegnare un indirizzo dell'array 'perfhash->keyword', la posizione della tabella 'perfhash->table' deve essere libera (valore 0) 
			if( perfhash->table[position] > 0 )
			{
				has_collisions = true;
				assert( strlen(perfhash->keywords[i]) < PERFHASH_MAX_WORD_LEN );

				if (perfhash->table[position] <= (perfhash->count + 1))
				{
					strcpy( last_collision, perfhash->keywords[i] );
					strcat( last_collision, "/" );
					strcat( last_collision, perfhash->keywords[perfhash->table[position]] );
				}
				else
					strcpy( last_collision, "Incomplete last collision, cause: 'perfhash table position > perfhash count' !" );

				break;
			}
			else
				perfhash->table[position] = i; // Store the index of the keyword
		}
	}

	if( has_collisions )
		return false; // Parameter generation failed
	else
		return true; // Parameters ok
}

/*
 Name: perfhash_destroy

 Description:
   Destroy the table.

 Input:
   perfhash - the perfhash object

 Output:
   perfhash->table - is freed
   perfhash->length - is set to 0
   
*/

void perfhash_destroy( perfhash_t *perfhash ) {
	free( perfhash->table );
	perfhash->length = 0;

	/* It is necessary to clean keywords if they were stored */
	if( perfhash->check_matches == true )
		for( unsigned int i=1; i <= perfhash->count; i++ )
			free( perfhash->keywords[i] );

	perfhash->count  = 0;
}

/*
 Name: perfhash_check

 Description:
   Checks if a keyword is present; this is probabilistic and gives
   false-positives (unless check_matches=true), but is very fast.

 Input:
   perfhash - the perfhash object
   word - the word to check
*/

bool perfhash_check( perfhash_t *perfhash, char *word ) {
	assert( perfhash->length > 0 );
	unsigned int position;
	unsigned int vrfy;
	unsigned int table_content;

	_perfhash_hash( perfhash, word, &(position), &(vrfy) );

	table_content 	= perfhash->table[position];

	if( table_content == 0 )
		return false; // word not found

	if( perfhash->check_matches == true )
	{
		// We will check the word
		char *word_to_check = perfhash->keywords[table_content];

		size_t word_len = strlen(word);
		size_t word_to_check_len = strlen(word_to_check);

		// Compare, INCLUDING the '\0' at the end
		for( uint i=0; i<=word_len; i++ ) {
			if (i > word_to_check_len)
				return false;

			if( word_to_check[i] != word[i] )
				return false;
		}
		return true;
	}
	else
	{
		if( table_content == vrfy ) // This is fast, but it can generate false positives (with low prob).
			return true;
		else
			return false;
	}
}
