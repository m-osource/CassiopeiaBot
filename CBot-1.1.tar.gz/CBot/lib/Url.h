/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _URLDDX_H_
#define _URLDDX_H_

#include <config.h>

// System libraries

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <iostream>
#include <string.h>
#include <queue>
#include <string>
#include <errno.h>
#include <atomic>
#include <curl/curl.h>

using namespace std;

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "perfect_hash.h"
#include "utils.h"

// Constants

#define FILENAME_ROBOTS_TXT			"robots.txt"
#define FILENAME_ROBOTS_RDF			"sitemap.rdf"
#define FILENAME_ROBOTS_XML			"sitemap.xml"
#define FILENAME_ROBOTS_XML_GZ		"sitemap.xml.gz"

// Filenames
// CONF_MAX_TWOLEVELDOMAINID // temporaneo
#define URLDDX_FILENAME_SITE_LIST		"urlddx.sitelist"
#define URLDDX_FILENAME_DOMAIN_LIST		"urlddx.domainlist"
#define URLDDX_FILENAME_PATH_LIST  		"urlddx.pathlist"
#define URLDDX_FILENAME_SITE_BINST		"urlddx.sitebinst"
#define URLDDX_FILENAME_DOMAIN_BINST	"urlddx.domainbinst"
#define URLDDX_FILENAME_PATH_BINST		"urlddx.pathbinst"
#define URLDDX_FILENAME_PATH_HPAGE		"urlddx.pathhpage"
#define URLDDX_FILENAME_SITE			"urlddx.site"
#define URLDDX_FILENAME_DOMAIN			"urlddx.domain"
#define URLDDX_FILENAME_SDOMAIN			"urlddx.sdomain"
#define URLDDX_FILENAME_PATH			"urlddx.path"
#define URLDDX_FILENAME_SITE_HASH		"urlddx.sitehash"
#define URLDDX_FILENAME_DOMAIN_HASH		"urlddx.domainhash"
#define URLDDX_FILENAME_PATH_HASH  		"urlddx.pathhash"
#define URLDDX_FILENAME_ALL        		"urlddx.main"

// domainid + "(Third Level Domain)\0" + siteid <- note: nul char must be inside string of MAX_DOMAIN_LEN
#define URLDDX_SDOMAIN_LEN (sizeof(siteid_t) + MAX_DOMAIN_LEN)

// domainid + "(fqdn domain less)\0" + siteid <- note: nul char must be inside string of MAX_DOMAIN_LEN
// #define URLDDX_SITE_LEN (sizeof(siteid_t) + MAX_DOMAIN_LEN + sizeof(siteid_t))
#define URLDDX_SITE_LEN (MAX_DOMAIN_LEN + sizeof(siteid_t))

// siteid + "path\0" + docid <- note: nul char must be inside string of MAX_STR_LEN length
#define URLDDX_PATH_LEN (sizeof(siteid_t) + MAX_STR_LEN + sizeof(docid_t))

#define URLDDX_MAX_OCCUPANCY (float)((float)1.25)

#define URLDDX_DOMAIN_HASH_SIZE (internal_long_uint_t)(CONF_COLLECTION_MAXDOMAIN * URLDDX_MAX_OCCUPANCY)
#define URLDDX_SITE_HASH_SIZE (internal_long_uint_t)(CONF_COLLECTION_MAXSITE * URLDDX_MAX_OCCUPANCY)
#define URLDDX_PATH_HASH_SIZE (internal_long_uint_t)(CONF_COLLECTION_MAXDOC * URLDDX_MAX_OCCUPANCY)

const uint8_t BYTE_BIT = 8;

#define URLDDX_HOMEPAGE_SIZE ((CONF_COLLECTION_MAXDOC / BYTE_BIT) + 1)

// Status

enum urlddx_status_t { 
	URLDDX_ERROR 			= 0,
	URLDDX_CREATED_SITE		= 1,
	URLDDX_CREATED_DOMAIN	= 2,
	URLDDX_CREATED_PATH		= 3,
	URLDDX_EXISTENT			= 4,
	URLDDX_NOT_FOUND		= 5,
	URLDDX_HASH_FULL		= 6,
	URLDDX_FULL				= 7
};

typedef struct {
	pthread_mutex_t *locka; 
	pthread_mutex_t *lockb; 
	pthread_mutex_t *lockc; 
	pthread_rwlock_t *rwlocka; // bucket instance read/write locks
	pthread_rwlock_t *rwlockb; // bucket instance read/write locks
	pthread_rwlock_t *rwlockc; // bucket instance read/write locks

//	extern bool symshown;
//	extern pthread_mutex_t *console_lock;

} urlmutex_t;

enum url_call_t {
    URL_NEW       = 0,
    URL_OPEN      = 1,
    URL_CLOSE     = 2,
    URL_REMOVE    = 3
};

// Classes

class Url
{
	// domain hash with domainid inside
	typedef struct {
    	off64_t offset;
		siteid_t domainid;
	} domain_hash_t;

	// Urlidx structure
	// Note that this is saved "as-is" to disk, so if you change it,
	// it will misbehave.
	
	typedef struct {
		// Sites
		char *site;								// Strings        [memory] // for intensive readonly operations
		int site_file;							// Strings        [disk] (fd) // for instant access in readwrite mode
		siteid_t site_hash_count;				// Count buckets  [memory]
		off64_t *site_hash;						// Hash table     [memory]
		siteid_t site_count;					// Count          [memory]
		off64_t site_next_char;					// String Pos     [memory]
		off64_t *site_list;						// List           [memory]
		instance_t *site_bucket_instance;		// List           [memory]
	
		// Domains
		int domain_file;						// Strings        [disk] (fd) // for instant access
		siteid_t domain_hash_count;				// Count buckets  [memory]
		domain_hash_t *domain_hash;					// Hash table     [memory]
		siteid_t domain_count;					// Count          [memory]
		off64_t domain_next_char;				// String Pos     [memory]
		off64_t *domain_list;					// List           [memory]
		instance_t *domain_bucket_instance;		// List           [memory]
	
		// Special Domains - as part of domains -
		int sdomain_file;						// Strings        [disk] (fd) // for instant access
//		siteid_t sdomain_hash_count;			// Count buckets  [memory]
//		domain_hash_t *sdomain_hash;			// Hash table     [memory]
		siteid_t sdomain_count;					// Count          [memory]
		off64_t sdomain_next_char;				// String Pos     [memory]
//		off64_t *sdomain_list;					// List           [memory]
//		instance_t *sdomain_bucket_instance;	// List           [memory]
	
		// Path
		int path_file;							// Strings        [disk] (fd) // for instant access
		docid_t path_hash_count;				// Count buckets  [memory]
		off64_t *path_hash;						// Hash table     [memory]
		docid_t path_count;						// Count          [memory]
		off64_t path_next_char;					// String Pos     [memory]
		off64_t *path_list;						// List           [memory]
		instance_t *path_bucket_instance;		// List           [memory]
		uint8_t *path_homepage;					// Bytemask       [memory]
	
		// Info
		char locdrpathname[MAX_STR_LEN];
		char remdrpathname[MAX_STR_LEN];
		// bool readonly;
	} urlddx_t;

	// need to passing arguments to threads functions
	// Because function call by pthread_create need to be pass first through 'urlddx_thread_function_caller', these works with other temporary object
	typedef struct {
    	instance_t inst;
		Url *obj;
		url_call_t f; // corrisponde alla chiamata di determinate funzioni fatta da pthread_create
	} thread_args_t;

	public:

	enum url_open_t {
    	WR			= 0, // Write only needed when index must be created by reset program
    	RW			= 1,
	    RO			= 2,
    	RO_MEMORY	= 3 // only for intensive use of functions 'resolve_site' or 'site_by_siteid' in readonly mode with volatile sitenames
	};

	private:
	
	urlddx_t *distributed;
	const char* dirname;
	url_open_t openmode;

	// url_open_t open_mode;

	urlmutex_t *slock; // mutex must be declared inside function that create threads
	urlmutex_t *dlock; // mutex must be declared inside function that create threads
	urlmutex_t *plock; // mutex must be declared inside function that create threads
	std::atomic<siteid_t> domain_count; // (share data) in caso di multithread questi contatori devo essere poter letti durante la fase di scrittura di nuovi id
	std::atomic<siteid_t> sdomain_count; // (share data) in caso di multithread questi contatori devo essere poter letti durante la fase di scrittura di nuovi id
	std::atomic<siteid_t> site_count; // (share data) in caso di multithread questi contatori devo essere poter letti durante la fase di scrittura di nuovi id
	std::atomic<docid_t> path_count; // (share data) in caso di multithread questi contatori devo essere poter letti durante la fase di scrittura di nuovi id

	// New URL index
	void ddx_new( void );

	// Function required by urlddx_new (pthread use)
	void *thread_function_new( void * );

	// Function required by urlddx_open (pthread use)
	void *thread_function_open( void * );

	// Function required by urlddx_close (pthread use)
	void *thread_function_close( void * );

	// Function required by urlddx_remove (pthread use)
	void *thread_function_remove( void * );

	// Get the domainid for a special domain
	siteid_t check_sdomain( const char *, size_t, instance_t &, siteid_t &, bool ) const; // new

	// Get the domainid for a domain
	siteid_t check_domain( const char *, instance_t &, siteid_t &, bool ) const; // new

	// Get the siteid for a site
	siteid_t check_site( const char *, size_t, instance_t &, siteid_t &, bool ) const; // new

	// Get the siteid for a site
	siteid_t check_site( const char *, instance_t &, siteid_t &, bool ) const;

	// Hash function
	docid_t hashing_sdomain( const char *, size_t, instance_t & ) const; // new

	// Hash function
	docid_t hashing_site( const char *, size_t, instance_t & ) const; // new
	
	// Hash function
	siteid_t hashing_site( const char *, instance_t & ) const;

	// Hash function
	docid_t hashing_path( const char *, int &, instance_t & ) const;

	// Set bit true inside path_homepage
	void setbit_true( instance_t &, docid_t & );

	// Set bit false inside path_homepage
	void setbit_false( instance_t &, docid_t & );

	// Get bit value from path_homepage
	bool getbit_value( instance_t &, docid_t &) const;

	// Function to proxy to non-static function
	static void* thread_function_caller( void * );

	// Functions  block to lock/unlock mutexes
	void lock_b_path( instance_t & ) const; // not needed
	void wrlock_a_site( instance_t & ) const;
	void wrlock_b_site( instance_t & ) const;
	void wrlock_c_site( instance_t & ) const;
	void wrlock_a_domain( instance_t & ) const;
	void wrlock_b_domain( instance_t & ) const;
	void wrlock_c_domain( instance_t & ) const;
	void wrlock_a_path( instance_t & ) const;
	void wrlock_b_path( instance_t & ) const;
	void wrlock_c_path( instance_t & ) const;
	void rdlock_a_site( instance_t & ) const;
	void rdlock_b_site( instance_t & ) const;
	void rdlock_c_site( instance_t & ) const;
	void rdlock_a_domain( instance_t & ) const;
	void rdlock_b_domain( instance_t & ) const;
	void rdlock_c_domain( instance_t & ) const;
	void rdlock_a_path( instance_t & ) const;
	void rdlock_b_path( instance_t & ) const;
	void rdlock_c_path( instance_t & ) const;
	void unlock_a_site( instance_t & ) const;
	void unlock_b_site( instance_t & ) const;
	void unlock_c_site( instance_t & ) const;
	void unlock_a_domain( instance_t & ) const;
	void unlock_b_domain( instance_t & ) const;
	void unlock_c_domain( instance_t & ) const;
	void unlock_a_path( instance_t & ) const;
	void unlock_b_path( instance_t &, bool ) const; // not needed
	void unlock_c_path( instance_t & ) const;
	// end of block

	public:

	Url (const char *_X, url_open_t _Y) // ctor
		: distributed (CBALLOC(urlddx_t, NEW, CONF_COLLECTION_DISTRIBUTED))
		, dirname (_X)
		, openmode (_Y)
		, slock (NULL)
		, dlock (NULL)
		, plock (NULL)
		, domain_count (0)
		, sdomain_count (CONF_MAX_TWOLEVELDOMAINID)
		, site_count (0)
		, path_count (0)
	{
		if (URLDDX_SITE_HASH_SIZE >= CONF_HASH_SITE_MAX_DEFINITIVE)
		{
			delete [] distributed;
			distributed = NULL;
			die("Url: unaddressable site hash (%llu) when the limit is %llu.", URLDDX_SITE_HASH_SIZE, CONF_HASH_SITE_MAX_DEFINITIVE);
		}

		if (URLDDX_PATH_HASH_SIZE >= CONF_HASH_DOC_MAX_DEFINITIVE)
		{
			delete [] distributed;
			distributed = NULL;
			die("Url: unaddressable site hash (%llu) when the limit is %llu.", URLDDX_PATH_HASH_SIZE, CONF_HASH_DOC_MAX_DEFINITIVE);
		}
	}

	~Url () // dtor
	{
		if (distributed != NULL)
		{
			delete [] distributed;
			distributed = NULL;
		}
	}

	// New URL index
	// Create a new index
	// dictddx_t **dictddx_new( const char *maindir );
	//
	// // Open a URL index
	// dictddx_t **dictddx_open( const char *maindir, bool readonly );
	//
	//void new( const char * );

	// Function for allocate memory and create mutex
	void setmutex( urlmutex_t **, urlmutex_t **,urlmutex_t ** );

	// Function for allocate memory and create mutex
	void destroymutex( void );

	// Open a URL index
	void ddx_open( void );

	// Close an URL index
	void ddx_close( void );

	// Removes a URL index
	void ddx_remove( void );

	// Dumps the URL index status
	void dump_status( void );

	// Get the domainid for a domain
	urlddx_status_t resolve_domain( const char *, siteid_t *, siteid_t *, perfhash_t );

	// Get the siteid for a site and save it if not found
	urlddx_status_t resolve_site( const char *, siteid_t, siteid_t *, protocols_t );

	// Get the siteid for a site
	urlddx_status_t resolve_site( const char *, siteid_t *, protocols_t );

	// Get number of sites in urlddx
	siteid_t sitecount( void ) const;

	// Get number of seconde level domains in urlddx
	siteid_t domaincount( void ) const;

	// Get number of paths in urlddx
	docid_t pathcount( void ) const;

	// Get a docid for a path
	urlddx_status_t resolve_path( siteid_t, const char *, docid_t * );

	// Only check if path is saved for a siteid
	urlddx_status_t contains_path( siteid_t, const char *, docid_t * ) const;

	// Get a siteid and docid for a "site/path"
	urlddx_status_t resolve_url( char *, siteid_t *, docid_t *, protocols_t );

	// Get a sitename from a siteid
	void site_by_siteid( siteid_t, char * ) const;

	// Get a "site/path" from a docid
	void url_by_docid( docid_t,  char * );

	// Get the siteid of a docid, useful for double-checking
	siteid_t siteid_by_docid( docid_t docid ) const;

	// Get a path from a docid
	void path_by_docid( docid_t docid, char *path ) const;

	// Check if a docid is a homepage
	bool is_homepage( docid_t & ) const;

	// Operations on paths
	
	// Convert path to canonical path
	void canonicalize_path( char *, char * ) const;
	
	// Check if site have alternative name
	int resolve_www_prefix(const char *, char *, protocols_t ) const;
	
	// Check is url is dynamic
	bool is_dynamic( perfhash_t *, char * ) const;
	
	// Parse absolute url
	bool parse_complete_url( char *, char *, char *, char * ) const;
	
	// Convert url to absolute
	void relative_path_to_absolute( char *, char *, char * ) const;
	
	// Sanitize the URL and remove sessionids
	void remove_variable( char *, const char * ) const;
	void sanitize_url( char * ) const;
	void remove_sessionids_heuristic( char * ) const;
	
	// Get the extension of a string
	void get_lowercase_extension( char *, char * ) const;
};

#endif
