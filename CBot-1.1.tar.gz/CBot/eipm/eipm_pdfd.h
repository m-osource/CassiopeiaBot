/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/
#include <config.h>

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <stddef.h>
#include <fstream>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>

// Local Libraries

#include "const.h"
// #include "xmlconf.h"
// #include "xmlconf-main.h"
// #include "utils.h"
// #include "cleanup.h"


#include "GlobalParams.h"
#include "Object.h"
#include "PDFDocFactory.h"
#include "TextOutputDev.h"
#include "UnicodeMap.h"
#include "PDFDocEncoding.h"

//#define MAX_STR_LEN 2000
//#define MAX_DOC_LEN 500000
#define CONF_MAX_FILE_SIZE 2000000 // IMPORTANTE: DEVE ESSERE UGUALE O SUPERIORE alle variabile presente nel file di configurazione principale
									// allo stato attuale occorrerebbe abilitare selinux a far leggere... dentro la main directory. Ora non ne vale la pena.
#define MAX_CICLES 20 // indica il numero massimo teorico superiore alla media, di cicli (in ricezione data) per ogni sessione oltre il quale non si può andare
#define MEM_LEAK_LIMIT 20000000 // to protect from memory leak of poppler library (BUG)

using namespace std;

void setSockTimeouts( int, double );
static string myStringReplace( const string &, const string &, const string & );
static string myXmlTokenReplace( const char * );
static string infoString( Dict *, const char *, UnicodeMap * );
off64_t parser_process_pdf( char *, off64_t, char * );
void eipm_pdfd_usage( void );
