/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _INFO_H_INCLUDED_
#define _INFO_H_INCLUDED_

#include <config.h>

// System libraries

#include <iostream>
#include <assert.h>
#include <string>
#include <readline/readline.h>
#include <readline/history.h>


using namespace std;

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "xmlconf-main.h"
#include "utils.h"
#include "Url.h"
#include "Meta.h"
#include "harvestidx.h"
#include "Storage.h"
#include "cleanup.h"
#include "linkidx.h"
#include "roboidx.h"
#include "dymddx.h"
#include "langddx.h"
#include "sitelink.h"
#include "show.h"

// Globals

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

Meta *meta				= NULL;
Url *url				= NULL;
Storage *strg			= NULL;
Storage *lidx			= NULL;
Storage *ridx			= NULL;
Harvest *harv			= NULL;
dymddx_t *dymddx		= NULL;
langddx_t *langddx		= NULL;

//const char *cmd[] ={ "help", "quit", "urlddx", "dymddx", "harvest", "read", "linkidx", "metaddx", "langddx", "summary", "links", "storage", "site", "doc" ,"word", "find", "depth", "in_degree", "out_degree", "http_status", "feeds", "sitedocs", "sitelinks", "siterevlinks", "site", " " };

const char *cmd[] ={"help", "quit", "urlddx", "dymddx", "harvest", "read", "linkidx", "roboidx", "metaddx", "langddx", "summary", "links", "storage", "site", "doc" ,"word", "find", "sitedocs", "sitelinks", "siterevlinks", "site", " "};


// Functions

void shell_help();
siteid_t shell_get_siteid( char * );
bool shell_parser( char * );

static char **shell_completion( const char *, int,  int );
char *shell_generator( const char *, int );
char *shell_dupstr ( char * );

#endif
