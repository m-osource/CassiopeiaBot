/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _LANG_H_INCLUDED_
#define _LANG_H_INCLUDED_

#include <config.h>

// System libraries

#include <stdio.h>
#include <ctype.h>
#include <fstream>
#include <locale.h>

// Local libraries

#include "const.h"
#include "xmlconf.h"
#include "utils.h"
#include "Storage.h"
#include "Meta.h"
#include "perfect_hash.h"
#include "cleanup.h"

// Constants

#define LANG_MAX_COUNT  20

// Globals

extern Storage *strg;
extern Meta *meta;

// Functions

void lang_init();
int lang_identify_document( char *buffer, off64_t buffer_length, FILE *output, uint *word_count );
int lang_check_word( char *word );
bool lang_is_separator( char c );
void lang_analyze();

#endif
