/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _PARSER_H_INCLUDED_
#define _PARSER_H_INCLUDED_

#include <config.h>

// System libraries

#include <fstream>
#include <map>
#include <string>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xmlmemory.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>
#include <stack>
#include <limits.h>
#include <sys/un.h> // for structure 'sockaddr_un' inside of eipm

// Local libraries

#include "perfect_hash.h"
#include "const.h"
#include "xmlconf.h"
#include "utils.h"
#include "Meta.h"
#include "linkidx.h"
#include "die.h"
#include "int_stack.h"
#include "Url.h"
#include "roboidx.h"
#include "http_charset.h"
#include "server.h"
#include "Entity.h"
#include "string_list.h"

// Constants

// Maximum number of parsed attributes in a html element
#define MAX_HTML_ATTRIBUTES 50
#define MAX_GOODWORDS 400
#define MAXWLWORDS 6

#define MAX_CICLES 20 // indica il numero massimo teorico superiore alla media, di cicli (in ricezione data) per ogni sessione oltre il quale non si può andare

#ifndef MAX_PATH
#define MAX_PATH 512
#endif // MAX_PATH

using namespace std;

extern Meta *meta;
extern Storage  *lidx;
extern Url  *url;
extern bool debugonly;
extern SemaphorePrint *sp;
extern off64_t htmlParser( server_t *, char *inbuf, instance_t );
extern char ***robots_txt_rules;
extern ssize_t **robots_txt_rules_size;
extern pthread_mutex_t     *parser_mutex; // using for writing linkidx

// Structures and types

// Enumeration for the html event (SAX-like) parser
enum event_t {
    EVENT_UNDEF,
    EVENT_START_TAG,
    EVENT_END_TAG,
    EVENT_EMPTY_TAG,
    EVENT_TEXT,
    EVENT_EOF
};

// Status for the html parser
enum status_t {
    STATUS_NORMAL,
    STATUS_IGNORE,
    STATUS_INANCHOR
};

// Type of link
enum extension_type_t {
	EXTENSION_NORMAL,
	EXTENSION_IGNORE,
	EXTENSION_LOG,
	EXTENSION_STAT
};

// Structure for a html attribute
typedef struct {
    char    name[MAX_STR_LEN];
    char    value[MAX_STR_LEN];
} attribute_t;

// Structure for a html tag with an attributes list
typedef struct {
    char    name[MAX_STR_LEN];
    attribute_t attributes[MAX_HTML_ATTRIBUTES];
    int attnum;
} tag_t;

// once initialized this value are read-only (Thread-safe)
char **partial_path = NULL; // se url 'www.sito.it/it/lista/polo.pl' partial_path conterrà 'it/lista'
const short NUMCOLS = 256;
const int NUMROWS = 200000;
unsigned int nrwl = 0;
unsigned int nrbl = 0;
unsigned int nrgw = 0;
char **pwl = NULL; // per creare un puntatore ad array bidimensionale occorre lavorare con puntatori di puntatori (ad array finali)
char **pbl = NULL; // per creare un puntatore ad array bidimensionale occorre lavorare con puntatori di puntatori (ad array finali)
char **pgw = NULL; // puntatore di puntatore ad array per contenere le goodwords

// Variabili relative al calcolo dell'hashing degli url
// Attraverso la media degli hashing relativi ad ogni pagina è possibile sapere
// se i link dentro una pagina sono cambiati dall'ultimo salvataggio (l'ordine è indifferente)
// Infine la media se diversa viene salvata nei metadati
// Note: Three static values for each instance
static unsigned short *number_lines_download = NULL;
static unsigned short *number_lines_log = NULL;

// linkidx structure
static bool *adjacency_list_new_link;
static unsigned int *adjacency_list_length = NULL;
static out_link_t **adjacency_list = NULL;

// Functions

void parser_init( void );
void parser_close( void );
void parser_lock_linkidx( instance_t & );
void parser_unlock_linkidx( instance_t & );
off64_t parser_process( starter_t *, siteid_t, char *,  char *, int &, size_t & );
void parser_init_link_attributes( char * );

void parser_analyze_link( starter_t *, siteid_t, char *, char *, double, em_tag_t, char * );
bool parser_analyze_link_sitemap( starter_t *, siteid_t, char *, bool, time_t, sitemap_xml_changefreq_t, sitemap_xml_priority_t );
bool parser_analyze_link_feeds( starter_t *, siteid_t, char *, char *, bool, time_t, char * );
int parser_analyze_line( starter_t *, siteid_t, siteid_t );
bool parser_compare_adjacency_list(instance_t, doc_t *src_doc, out_link_t [], unsigned int );
void parser_save_links( doc_t *, out_link_t [], unsigned int );


charset_t parser_charset_metadata(server_t *server, char *inbuf);

// Parsers

off64_t parser_process_html( starter_t *, siteid_t, char *, char *, int &, size_t & );
unsigned int parser_process_robotstxt( starter_t *, siteid_t, char * );
off64_t parser_process_robotsrdf( starter_t *, siteid_t, char *, char *, int &, size_t & );
off64_t parser_process_robotsxml( starter_t *, siteid_t, char *, char *, int &, size_t & );
off64_t parser_process_atom_feedsxml( starter_t *, siteid_t, char *, char *, int &, size_t & );
off64_t parser_process_rss_feedsxml( starter_t *, siteid_t, char *, char *, int &, size_t & );


// Tags
void update_tag_stack(int_stack_t *, char *, event_t );

// Extensions
extension_type_t parser_check_extension( char *, char * );

// Save
void parser_save_extensions_stats( FILE * );

// Hashing
doc_hash_t parser_hash( off64_t, char * );
doc_hash_t parser_hash_adjacency_list( unsigned int, out_link_t * );

// External Indipendent Parser Module
off64_t eipm( const char *, const double, char *, off64_t, char * );

// Check for presence of path in robots.txt
bool parser_check_robotstxt( server_t * );
bool parser_check_robotstxt( server_t *, char * );
void parser_check_robotstxt( server_t *, bool &, int &, int &, siteid_t & );

// Whitelist check
short find_domain_extended( char **, unsigned int, short *, const char &, unsigned short &, unsigned int [] );
bool checkgword( char [] );
bool checkname( const char *, char **, unsigned int, bool );

#endif
