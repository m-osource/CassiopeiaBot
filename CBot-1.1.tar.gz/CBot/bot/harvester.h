/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#ifndef _HARVESTER_H_
#define _HARVESTER_H_

#include <config.h>

// System libraries

#include <getopt.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/poll.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <ares.h>
#include <sys/utsname.h>
//#include <mbedtls/net.h>
//#include <mbedtls/ssl.h>
//#include <mbedtls/entropy.h>
//#include <mbedtls/ctr_drbg.h>


// Local libraries

#include "perfect_hash.h"
#include "xmlconf.h"
#include "const.h"
#include "utils.h"
#include "cleanup.h"
#include "http_codes.h"
#include "harvestidx.h"
#include "Meta.h"
#include "pollvec.h"
#include "activepool.h"
#include "waitq.h"
#include "server.h"
#include "Storage.h"
#include "roboidx.h"
#include "page.h"

// need to passing arguments to threads functions
typedef struct {
	instance_t inst;
	harvest_status_t status;
	ares_channel *a_channel;
    const struct ares_options *a_options;
    const int *a_optmask;
	perfhash_t *blocked_ip;
	perfhash_t *accept_protocol;
} harvester_thread_args_t;

// Globals

Meta *meta				= NULL;
Url *url				= NULL;
Storage *strg			= NULL;	// storage for documents
Storage *ridx			= NULL; // storage for robots.txt's rules
Storage *lidx			= NULL; // storage for adjacency_list
Harvest *harv			= NULL;

atomic<bool> downloads_ok (false);
atomic<docid_t> harvester_harvest_doc_count;
pthread_barrier_t *harvester_barrier = NULL;

char ***robots_txt_rules = NULL;
ssize_t **robots_txt_rules_size = NULL;
atomic<docid_t> robots_txt_ndocs_done; // number of robots.txt's rules loaded (or not because file have had syntax errors) on instance

// more mutex less slow
strgmutex_t			*strglock = NULL; // mutex selettivi (uno per istanza) con l'ultimo generico
pthread_mutex_t		*parser_mutex = NULL; // using for saving adjacency_list in multithread mode

// init thread-safe console outputs
SemaphorePrint *sp = NULL;
bool *symshown = NULL;
pthread_mutex_t *console_lock = NULL;

// init signal alarms
struct sigaction action;

// init thread alarms
atomic<thread_alarm_t> thread_alarm (THREADS_OK);

extern void parser_init();
extern void parser_close();
extern bool parser_check_robotstxt( server_t * );
//extern off64_t parser_process( doc_t *doc, char *inbuf, char *outbuf, string site, string path );
//extern void parser_save_extensions_stats( FILE *links_stat );
//extern charset_t parser_charset_metadata(doc_t *doc, char *inbuf);

FILE **links_download;
FILE **links_log;
FILE **links_stat;

int CAlen = 0;
char *CA = NULL;
bool debugonly = false;
bool showlanguages = false;
time_t deltatimezone; // differenza in secondi dall'ora UTC (daylight compreso)

off64_t max_outbuf_len;

// Functions

void harvester_sync_threads( pthread_barrier_t * );
void *harvester_thread_function_main_setup( void * );
void harvester_usage( void );

#endif
