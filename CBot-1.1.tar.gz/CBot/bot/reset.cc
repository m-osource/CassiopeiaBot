/***************************************************************************
 *          (C) Copyright 2011 - Nic.br                                    *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2011 - Center for Web Research                   *
 ***************************************************************************
 ***************************************************************************
 *          (C) Copyright 2017 - Marco Giuseppe Spiga                      *
 ***************************************************************************
 *                                                                         *
 *  This file is part of CBot.                                             *
 *                                                                         *
 *  CBot is free software: you can redistribute it and/or modify           *
 *  it under the terms of the GNU General Public License as published by   *
 *  the Free Software Foundation, either version 2 of the License, or      *
 *  any later version.                                                     *
 *                                                                         *
 *  CBot is distributed in the hope that it will be useful,                *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with CBOT.  If not, see <http://www.gnu.org/licenses/>.          *
 *                                                                         *
 **************************************************************************/

#include "reset.h"

//
// Name: main
//
// Description:
//   Deletes files from all directories of the crawler
//

int main(void)
{
	assert((instance_t)~0 < (unsigned int)~0);

try
{
	// Init
	cbot_start( "reset" );

	if (CONF_HASH_SITE_MAX_DEFINITIVE < (CONF_COLLECTION_MAXSITE * CONF_COLLECTION_DISTRIBUTED * 2))
		die( "in configuration file ('maxsite' * 'distributed') must be at most, half value of macro 'CONF_HASH_SITE_MAX_DEFINITIVE' (%llu) in 'lib/const.h'. Change it or change datatypes in source code!", CONF_HASH_SITE_MAX_DEFINITIVE);

	if (CONF_HASH_DOC_MAX_DEFINITIVE < (CONF_COLLECTION_MAXDOC * CONF_COLLECTION_DISTRIBUTED * 2))
		die( "in configuration file ('maxdoc' * 'distributed') must be at most, half value of macro 'CONF_HASH_DOC_MAX_DEFINITIVE' (%llu) in 'lib/const.h'. Change it or change datatypes in source code!", CONF_HASH_DOC_MAX_DEFINITIVE);

	if (CONF_COLLECTION_DISTRIBUTED < 2)
		die( "in configuration file 'distributed' cannot be minor of 2. Change it!");

	instance_t t = 2;
	internal_long_uint_t max = ((internal_long_uint_t)((instance_t)~0) + 1);
	bool distributed_ok = false;

	for (; t <= max; t *= 2)
	{
		if (t == 0) break;

		if (t == CONF_COLLECTION_DISTRIBUTED)
		{
			distributed_ok = true;
			break;
		}
	}

	if (max == CONF_COLLECTION_DISTRIBUTED)
		distributed_ok = true;

	if (distributed_ok == false)
		die( "in configuration file 'distributed' have a bad value because must be inferior at %llu and power of 2. Change it!", (max + 1));

	TALARM;

	if ((CONF_COLLECTION_MAXDOC % CONF_COLLECTION_DISTRIBUTED) != 0)
		die( "in configuration file 'maxdoc' must be multiple of 'distributed'. Change it!");

	if ((CONF_COLLECTION_MAXSITE % CONF_COLLECTION_DISTRIBUTED) != 0)
		die( "in configuration file 'maxsite' must be multiple of 'distributed'. Change it!");

	if ((CONF_COLLECTION_MAXWORD % CONF_COLLECTION_DISTRIBUTED) != 0)
		die( "in configuration file 'maxword' must be multiple of 'distributed'. Change it!");

	if ((CONF_COLLECTION_MAXSTEM % CONF_COLLECTION_DISTRIBUTED) != 0)
		die( "in configuration file 'maxstem' must be multiple of 'distributed'. Change it!");

	if ((CONF_COLLECTION_MAXGRAM % CONF_COLLECTION_DISTRIBUTED) != 0)
		die( "in configuration file 'maxngram' must be multiple of 'distributed'. Change it!");

	if ((CONF_SEEDER_MAX_URLS_PER_SITE < (CONF_COLLECTION_DISTRIBUTED * 200)) != 0)
		die( "in configuration file 'max-urls-per-site' must be at least %d. Change it!", (CONF_COLLECTION_DISTRIBUTED * 200));

	TALARM;

	cerr << "Initializing mappings only for testing purpose: ";

	perfhash_t keep_tag;       // HTML elements keepd
	perfhash_t keep_attribute; // HTML attrs keepd
	perfhash_t accept_protocol; // Protocols to accept 
	perfhash_t blocked_ip; // Ip address to block
	perfhash_t keep_special;    // Special domains keepd (see domainid) 
	perfhash_t discard_content;    // Elements whose content is discarded
	perfhash_t extensions_ignore;  // Extensions to ignore
	perfhash_t extensions_log;     // Extensions to log, but not to download
	perfhash_t extensions_stat;    // Extensions to count, but neither log nor download

	// Can be set to false for better speed, but less reliability
	// while discarding tags
	bool double_check_kept_markup = false;

	/* We don't want to loose text accidentaly */
	cerr << "discard_content, ";
	discard_content.check_matches = true;
	perfhash_create( &(discard_content), CONF_GATHERER_DISCARD_CONTENT );

	cerr << "keep tags, ";
	keep_tag.check_matches = double_check_kept_markup;
	perfhash_create( &(keep_tag), CONF_GATHERER_KEEP_TAG );

	cerr << "keep attributes, ";
	keep_attribute.check_matches = double_check_kept_markup;
	perfhash_create( &(keep_attribute), CONF_GATHERER_KEEP_ATTRIBUTE );

	cerr << "accepted protocols, ";
	accept_protocol.check_matches = true;
	perfhash_create( &(accept_protocol), CONF_SEEDER_LINK_ACCEPT_PROTOCOL );

	cerr << "blocked ip, ";
	blocked_ip.check_matches = true;
	perfhash_create( &(blocked_ip), CONF_HARVESTER_BLOCKED_IP );

	cerr << "keep special domains, ";
	keep_special.check_matches = true;
	perfhash_create( &(keep_special), CONF_COLLECTION_IT_SPECIAL_DOMAINS );

	cerr << "extensions to ignore, ";
	extensions_ignore.check_matches = true;
	perfhash_create( &(extensions_ignore), CONF_SEEDER_LINK_EXTENSIONS_IGNORE );

	cerr << "extensions to log, ";
	extensions_log.check_matches = true;
	perfhash_create( &(extensions_log), CONF_SEEDER_LINK_EXTENSIONS_LOG );

	cerr << "extensions to stat, ";
	extensions_stat.check_matches = true;
	perfhash_create( &(extensions_stat), CONF_SEEDER_LINK_EXTENSIONS_STAT );

    perfhash_destroy( &(discard_content) );
    perfhash_destroy( &(keep_tag) );
    perfhash_destroy( &(keep_attribute) );
    perfhash_destroy( &(accept_protocol) );
    perfhash_destroy( &(blocked_ip) );
    perfhash_destroy( &(keep_special) );
    perfhash_destroy( &(extensions_ignore) );
    perfhash_destroy( &(extensions_log) );
    perfhash_destroy( &(extensions_stat) );

	cerr << endl;
	cerr << "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" << endl;
	cerr << "*** About to DELETE ALL FILES from the collection ***" << endl;
	// assert(strncmp(get_current_dir_name(), (const char *)CONF_COLLECTION_BASE, strlen((const char *)CONF_COLLECTION_BASE)) == 0); // solo uso test (al momento fino alle verifiche con valgrind)
	cerr << "*** Directory: " << CONF_COLLECTION_BASE << endl;
	cerr << endl;
	cerr << "Waiting 2 seconds (Press Ctrl-C to abort)" << endl;
	for( uint i=2; i>0; i-- ) {
		cerr << " Delete all subdirs of " << CONF_COLLECTION_BASE << " in " << i << " sec., Ctrl-C to abort" << endl;
		sleep(1);
	}
	sleep(1);
	cerr << "continuing." << endl;

	// Remove indexes */
	cerr << "Removing indexes ... ";

	// declare all needed classes
	Monitor *monitor = new Monitor (false);
	Url *url = new Url (COLLECTION_URL, Url::WR);
	Meta *meta = new Meta (COLLECTION_METADATA, false);
	Harvest *harv = new Harvest (COLLECTION_HARVEST, false);
	Storage *strg = new Storage (COLLECTION_TEXT, false);
	Storage *lidx = new Storage (COLLECTION_LINK, false); // index of outgoing links needed for ranking
	Storage *sidx = new Storage (COLLECTION_SITELINK, false); // index of outgoing links needed for ranking
	Storage *ridx = new Storage (COLLECTION_ROBOTS, false); // index of outgoing links needed for store robots.txt rules

	monitor->remove();

	TALARM;

	url->ddx_remove();

	TALARM;

	meta->ddx_remove();

	TALARM;

	harv->hv_remove_all();
	delete harv;

	TALARM;

	strg->st_remove();

	TALARM;

	lidx->st_remove();

	TALARM;

	sidx->st_remove();

	TALARM;

	ridx->st_remove();

	TALARM;

	dymddx_remove( COLLECTION_DYM );

	TALARM;

	langddx_remove( COLLECTION_LANGDATA );

	TALARM;

	connddx_remove( COLLECTION_CONNDATA );

	TALARM;

	struct stat64 statbuf;

	// check how many empty not valid directory delete
	for (unsigned int i = 0; i < UINT_MAX; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::LOCDR, i);

		if ((i + 1) >= CONF_COLLECTION_DISTRIBUTED && stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
		{
			if ((i + 1) > CONF_COLLECTION_DISTRIBUTED)
			{
				// Delete dir (rimuove la directory word ...)
				int rc = remove( relative_rem_path );
				if( rc != 0 && errno != ENOENT )
				{
					perror( relative_rem_path ); 
					die( "Couldn't remove directory" );
				}
			}
		}
		else
		{
			free(relative_rem_path);
			break;
		}

		free(relative_rem_path);
	}

	// check how many empty not valid directory delete
	for (unsigned int i = 0; i < UINT_MAX; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, i);

		if ((i + 1) >= CONF_COLLECTION_DISTRIBUTED && stat64(relative_rem_path, &statbuf) == 0 && S_ISDIR(statbuf.st_mode))
		{
			if ((i + 1) > CONF_COLLECTION_DISTRIBUTED)
			{
				// Delete dir (rimuove la directory word ...)
				int rc = remove( relative_rem_path );
				if( rc != 0 && errno != ENOENT )
				{
					perror( relative_rem_path ); 
					die( "Couldn't remove directory" );
				}
			}
		}
		else
		{
			free(relative_rem_path);
			break;
		}

		free(relative_rem_path);
	}

	cerr << "done." << endl;

	// Create directories
	cerr << "Creating directories ... ";
	queue <string> dirs;

	dirs.push(DataRetention::drdir(DataRetention::LOCDR));

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_loc_path = DataRetention::make(DataRetention::LOCDR, i);
		dirs.push( relative_loc_path );
		free(relative_loc_path);
	}

	dirs.push(DataRetention::drdir(DataRetention::REMDR));

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_RUN, i);
		dirs.push( relative_rem_path );

		// remove directory and all pid files inside it
        char command[MAX_STR_LEN] = "rm -rf ";
        strcat(command, relative_rem_path);
        system (command);

		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{	// note that some binary data from Url duplicate index can reside on locale solid state disk storage
		char *relative_loc_path = DataRetention::make(DataRetention::LOCDR, COLLECTION_URL, i);
		dirs.push( relative_loc_path );
		free(relative_loc_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_URL, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_TEXT, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_LINK, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_SITELINK, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_ROBOTS, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_HARVEST, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char collection_harvest_links[MAX_STR_LEN];
		sprintf( collection_harvest_links, "%s/%s", COLLECTION_HARVEST, COLLECTION_LINK );
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, collection_harvest_links, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_METADATA, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_DYM, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_LANGDATA, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_CONNDATA, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}
	// Directory on infixdata must delete manually when needed because his data can be used for other collections
	for (instance_t i = 0; i < CONF_COLLECTION_DISTRIBUTED; i++)
	{
		char *relative_rem_path = DataRetention::make(DataRetention::REMDR, COLLECTION_INFIXDATA, i);
		dirs.push( relative_rem_path );
		free(relative_rem_path);
	}

	// the only one single index
	dirs.push( COLLECTION_ANALYSIS );

	while (! dirs.empty())
	{
		char dirname[MAX_STR_LEN];
		sprintf( dirname, "%s", dirs.front().c_str() );

		int rc = mkdir( dirname, 0777 );

		if (rc != 0 && errno != EEXIST)
		{
			perror( dirname );
			die( "Failed to create directory" );
		}

		dirs.pop();
	}

	cerr << "done." << endl;

	// Create indexes again
	cerr << "Creating indexes ... ";

	cerr << "[monitor] ";
	monitor->open();

	TALARM;

	monitor->close();
	delete monitor;

	TALARM;

	cerr << "[metaddx] ";
	meta->ddx_open();

	TALARM;

	meta->ddx_close();
	delete meta;

	TALARM;

	cerr << "[linkidx] ";
	lidx->st_create();

	TALARM;

	lidx->st_close();
	delete lidx;

	TALARM;

	cerr << "[siteidx] ";
	sidx->st_create();

	TALARM;

	sidx->st_close();
	delete sidx;

	TALARM;

	cerr << "[robotsidx] ";
	ridx->st_create();

	TALARM;

	ridx->st_close();
	delete ridx;

	TALARM;

	cerr << "[urlddx] ";
	url->ddx_open();

	TALARM;

	url->ddx_close();
	delete url;

	TALARM;

	cerr << "[storage] ";
	strg->st_create();

	TALARM;

	strg->st_close();
	delete strg;

	cerr << "[dymddx] ";
	dymddx_t *dymddx = dymddx_open( COLLECTION_DYM, false );
	assert( dymddx != NULL );

	TALARM;

	dymddx_close( dymddx );

	cerr << "[langddx] ";
	langddx_t *langddx = langddx_open( COLLECTION_LANGDATA, false );
	assert( langddx != NULL );

	TALARM;

	langddx_close( langddx );

	cerr << "[connddx] ";
	connddx_t *connddx = connddx_open( COLLECTION_CONNDATA, false );
	assert( connddx != NULL );

	TALARM;

	connddx_close( connddx );

	TALARM;

	cerr << "done." << endl;

	// Log
	syslog( LOG_NOTICE, "reset deleted and created all indexes" );

	cerr << "The next step should be to use the seeder program to load start URLs" << endl;

	// End
	cbot_stop(0);
}
catch (CBotExitException eex)
{
	delete eex.Exception();

	cbot_stop(1);
}
}

//
// Name: cleanup
//
// Description:
//   Closes files and clean everything
//

void cleanup() {
}

